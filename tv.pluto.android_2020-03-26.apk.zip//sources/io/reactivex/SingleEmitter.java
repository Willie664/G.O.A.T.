package io.reactivex;

public interface SingleEmitter<T> {
    void onSuccess(T t);
}
