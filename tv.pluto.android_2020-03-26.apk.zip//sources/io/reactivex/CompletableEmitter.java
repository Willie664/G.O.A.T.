package io.reactivex;

import io.reactivex.functions.Cancellable;

public interface CompletableEmitter {
    void onComplete();

    void setCancellable(Cancellable cancellable);
}
