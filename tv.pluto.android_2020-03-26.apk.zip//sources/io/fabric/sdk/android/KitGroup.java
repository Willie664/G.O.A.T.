package io.fabric.sdk.android;

import java.util.Collection;

public interface KitGroup {
    Collection<? extends Kit> getKits();
}
