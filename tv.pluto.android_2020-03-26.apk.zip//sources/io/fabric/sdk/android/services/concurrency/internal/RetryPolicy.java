package io.fabric.sdk.android.services.concurrency.internal;

public interface RetryPolicy {
}
