package io.fabric.sdk.android.services.settings;

public class SettingsJsonConstants {
    public static final String BETA_UPDATE_ENDPOINT_DEFAULT = null;
}
