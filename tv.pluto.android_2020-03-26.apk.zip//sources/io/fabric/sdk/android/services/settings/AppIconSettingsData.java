package io.fabric.sdk.android.services.settings;

class AppIconSettingsData {
    public final String hash;
    public final int height;
    public final int width;

    public AppIconSettingsData(String str, int i, int i2) {
        this.hash = str;
        this.width = i;
        this.height = i2;
    }
}
