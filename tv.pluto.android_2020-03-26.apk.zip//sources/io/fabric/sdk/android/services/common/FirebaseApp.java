package io.fabric.sdk.android.services.common;

interface FirebaseApp {
    boolean isDataCollectionDefaultEnabled();
}
