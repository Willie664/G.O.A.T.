package io.fabric.sdk.android.services.settings;

public enum SettingsCacheBehavior {
    USE_CACHE,
    SKIP_CACHE_LOOKUP,
    IGNORE_CACHE_EXPIRATION
}
