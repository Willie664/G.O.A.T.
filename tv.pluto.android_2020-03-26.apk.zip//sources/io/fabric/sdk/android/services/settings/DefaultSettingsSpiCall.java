package io.fabric.sdk.android.services.settings;

import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.Kit;
import io.fabric.sdk.android.Logger;
import io.fabric.sdk.android.services.common.AbstractSpiCall;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.network.HttpMethod;
import io.fabric.sdk.android.services.network.HttpRequest;
import io.fabric.sdk.android.services.network.HttpRequestFactory;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

class DefaultSettingsSpiCall extends AbstractSpiCall implements SettingsSpiCall {
    /* access modifiers changed from: package-private */
    public boolean requestWasSuccessful(int i) {
        return i == 200 || i == 201 || i == 202 || i == 203;
    }

    public DefaultSettingsSpiCall(Kit kit, String str, String str2, HttpRequestFactory httpRequestFactory) {
        this(kit, str, str2, httpRequestFactory, HttpMethod.GET);
    }

    DefaultSettingsSpiCall(Kit kit, String str, String str2, HttpRequestFactory httpRequestFactory, HttpMethod httpMethod) {
        super(kit, str, str2, httpRequestFactory, httpMethod);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0090  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.json.JSONObject invoke(io.fabric.sdk.android.services.settings.SettingsRequest r10) {
        /*
            r9 = this;
            java.lang.String r0 = "X-REQUEST-ID"
            java.lang.String r1 = "Settings request ID: "
            java.lang.String r2 = "Fabric"
            r3 = 0
            java.util.Map r4 = r9.getQueryParamsFor(r10)     // Catch:{ HttpRequestException -> 0x0075, all -> 0x0070 }
            io.fabric.sdk.android.services.network.HttpRequest r5 = r9.getHttpRequest(r4)     // Catch:{ HttpRequestException -> 0x0075, all -> 0x0070 }
            io.fabric.sdk.android.services.network.HttpRequest r10 = r9.applyHeadersTo(r5, r10)     // Catch:{ HttpRequestException -> 0x006d, all -> 0x006a }
            io.fabric.sdk.android.Logger r5 = io.fabric.sdk.android.Fabric.getLogger()     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ HttpRequestException -> 0x0068 }
            r6.<init>()     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.String r7 = "Requesting settings from "
            r6.append(r7)     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.String r7 = r9.getUrl()     // Catch:{ HttpRequestException -> 0x0068 }
            r6.append(r7)     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.String r6 = r6.toString()     // Catch:{ HttpRequestException -> 0x0068 }
            r5.d(r2, r6)     // Catch:{ HttpRequestException -> 0x0068 }
            io.fabric.sdk.android.Logger r5 = io.fabric.sdk.android.Fabric.getLogger()     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ HttpRequestException -> 0x0068 }
            r6.<init>()     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.String r7 = "Settings query params were: "
            r6.append(r7)     // Catch:{ HttpRequestException -> 0x0068 }
            r6.append(r4)     // Catch:{ HttpRequestException -> 0x0068 }
            java.lang.String r4 = r6.toString()     // Catch:{ HttpRequestException -> 0x0068 }
            r5.d(r2, r4)     // Catch:{ HttpRequestException -> 0x0068 }
            org.json.JSONObject r3 = r9.handleResponse(r10)     // Catch:{ HttpRequestException -> 0x0068 }
            if (r10 == 0) goto L_0x008c
            io.fabric.sdk.android.Logger r4 = io.fabric.sdk.android.Fabric.getLogger()
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
        L_0x0056:
            r5.append(r1)
            java.lang.String r10 = r10.header((java.lang.String) r0)
            r5.append(r10)
            java.lang.String r10 = r5.toString()
            r4.d(r2, r10)
            goto L_0x008c
        L_0x0068:
            r4 = move-exception
            goto L_0x0077
        L_0x006a:
            r3 = move-exception
            r10 = r5
            goto L_0x008e
        L_0x006d:
            r4 = move-exception
            r10 = r5
            goto L_0x0077
        L_0x0070:
            r10 = move-exception
            r8 = r3
            r3 = r10
            r10 = r8
            goto L_0x008e
        L_0x0075:
            r4 = move-exception
            r10 = r3
        L_0x0077:
            io.fabric.sdk.android.Logger r5 = io.fabric.sdk.android.Fabric.getLogger()     // Catch:{ all -> 0x008d }
            java.lang.String r6 = "Settings request failed."
            r5.e(r2, r6, r4)     // Catch:{ all -> 0x008d }
            if (r10 == 0) goto L_0x008c
            io.fabric.sdk.android.Logger r4 = io.fabric.sdk.android.Fabric.getLogger()
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            goto L_0x0056
        L_0x008c:
            return r3
        L_0x008d:
            r3 = move-exception
        L_0x008e:
            if (r10 == 0) goto L_0x00aa
            io.fabric.sdk.android.Logger r4 = io.fabric.sdk.android.Fabric.getLogger()
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            r5.append(r1)
            java.lang.String r10 = r10.header((java.lang.String) r0)
            r5.append(r10)
            java.lang.String r10 = r5.toString()
            r4.d(r2, r10)
        L_0x00aa:
            goto L_0x00ac
        L_0x00ab:
            throw r3
        L_0x00ac:
            goto L_0x00ab
        */
        throw new UnsupportedOperationException("Method not decompiled: io.fabric.sdk.android.services.settings.DefaultSettingsSpiCall.invoke(io.fabric.sdk.android.services.settings.SettingsRequest):org.json.JSONObject");
    }

    /* access modifiers changed from: package-private */
    public JSONObject handleResponse(HttpRequest httpRequest) {
        int code = httpRequest.code();
        Logger logger = Fabric.getLogger();
        logger.d("Fabric", "Settings result was: " + code);
        if (requestWasSuccessful(code)) {
            return getJsonObjectFrom(httpRequest.body());
        }
        Logger logger2 = Fabric.getLogger();
        logger2.e("Fabric", "Failed to retrieve settings from " + getUrl());
        return null;
    }

    private JSONObject getJsonObjectFrom(String str) {
        try {
            return new JSONObject(str);
        } catch (Exception e) {
            Logger logger = Fabric.getLogger();
            logger.d("Fabric", "Failed to parse settings JSON from " + getUrl(), e);
            Logger logger2 = Fabric.getLogger();
            logger2.d("Fabric", "Settings response " + str);
            return null;
        }
    }

    private Map<String, String> getQueryParamsFor(SettingsRequest settingsRequest) {
        HashMap hashMap = new HashMap();
        hashMap.put("build_version", settingsRequest.buildVersion);
        hashMap.put("display_version", settingsRequest.displayVersion);
        hashMap.put("source", Integer.toString(settingsRequest.source));
        if (settingsRequest.iconHash != null) {
            hashMap.put("icon_hash", settingsRequest.iconHash);
        }
        String str = settingsRequest.instanceId;
        if (!CommonUtils.isNullOrEmpty(str)) {
            hashMap.put("instance", str);
        }
        return hashMap;
    }

    private HttpRequest applyHeadersTo(HttpRequest httpRequest, SettingsRequest settingsRequest) {
        applyNonNullHeader(httpRequest, AbstractSpiCall.HEADER_API_KEY, settingsRequest.apiKey);
        applyNonNullHeader(httpRequest, AbstractSpiCall.HEADER_CLIENT_TYPE, "android");
        applyNonNullHeader(httpRequest, AbstractSpiCall.HEADER_CLIENT_VERSION, this.kit.getVersion());
        applyNonNullHeader(httpRequest, AbstractSpiCall.HEADER_ACCEPT, AbstractSpiCall.ACCEPT_JSON_VALUE);
        applyNonNullHeader(httpRequest, "X-CRASHLYTICS-DEVICE-MODEL", settingsRequest.deviceModel);
        applyNonNullHeader(httpRequest, "X-CRASHLYTICS-OS-BUILD-VERSION", settingsRequest.osBuildVersion);
        applyNonNullHeader(httpRequest, "X-CRASHLYTICS-OS-DISPLAY-VERSION", settingsRequest.osDisplayVersion);
        applyNonNullHeader(httpRequest, "X-CRASHLYTICS-INSTALLATION-ID", settingsRequest.installationId);
        return httpRequest;
    }

    private void applyNonNullHeader(HttpRequest httpRequest, String str, String str2) {
        if (str2 != null) {
            httpRequest.header(str, str2);
        }
    }
}
