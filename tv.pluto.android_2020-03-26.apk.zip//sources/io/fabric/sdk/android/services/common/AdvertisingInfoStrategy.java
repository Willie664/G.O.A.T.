package io.fabric.sdk.android.services.common;

public interface AdvertisingInfoStrategy {
    AdvertisingInfo getAdvertisingInfo();
}
