package io.fabric.sdk.android.services.settings;

import android.content.res.Resources;
import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.Kit;
import io.fabric.sdk.android.KitInfo;
import io.fabric.sdk.android.Logger;
import io.fabric.sdk.android.services.common.AbstractSpiCall;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.common.ResponseParser;
import io.fabric.sdk.android.services.network.HttpMethod;
import io.fabric.sdk.android.services.network.HttpRequest;
import io.fabric.sdk.android.services.network.HttpRequestFactory;
import java.io.InputStream;
import java.util.Locale;

abstract class AbstractAppSpiCall extends AbstractSpiCall {
    public AbstractAppSpiCall(Kit kit, String str, String str2, HttpRequestFactory httpRequestFactory, HttpMethod httpMethod) {
        super(kit, str, str2, httpRequestFactory, httpMethod);
    }

    public boolean invoke(AppRequestData appRequestData) {
        HttpRequest applyMultipartDataTo = applyMultipartDataTo(applyHeadersTo(getHttpRequest(), appRequestData), appRequestData);
        Logger logger = Fabric.getLogger();
        logger.d("Fabric", "Sending app info to " + getUrl());
        if (appRequestData.icon != null) {
            Logger logger2 = Fabric.getLogger();
            logger2.d("Fabric", "App icon hash is " + appRequestData.icon.hash);
            Logger logger3 = Fabric.getLogger();
            logger3.d("Fabric", "App icon size is " + appRequestData.icon.width + "x" + appRequestData.icon.height);
        }
        int code = applyMultipartDataTo.code();
        String str = "POST".equals(applyMultipartDataTo.method()) ? "Create" : "Update";
        Logger logger4 = Fabric.getLogger();
        logger4.d("Fabric", str + " app request ID: " + applyMultipartDataTo.header(AbstractSpiCall.HEADER_REQUEST_ID));
        Logger logger5 = Fabric.getLogger();
        logger5.d("Fabric", "Result was " + code);
        return ResponseParser.parse(code) == 0;
    }

    private HttpRequest applyHeadersTo(HttpRequest httpRequest, AppRequestData appRequestData) {
        return httpRequest.header(AbstractSpiCall.HEADER_API_KEY, appRequestData.apiKey).header(AbstractSpiCall.HEADER_CLIENT_TYPE, "android").header(AbstractSpiCall.HEADER_CLIENT_VERSION, this.kit.getVersion());
    }

    private HttpRequest applyMultipartDataTo(HttpRequest httpRequest, AppRequestData appRequestData) {
        HttpRequest part = httpRequest.part("app[identifier]", appRequestData.appId).part("app[name]", appRequestData.name).part("app[display_version]", appRequestData.displayVersion).part("app[build_version]", appRequestData.buildVersion).part("app[source]", (Number) Integer.valueOf(appRequestData.source)).part("app[minimum_sdk_version]", appRequestData.minSdkVersion).part("app[built_sdk_version]", appRequestData.builtSdkVersion);
        if (!CommonUtils.isNullOrEmpty(appRequestData.instanceIdentifier)) {
            part.part("app[instance_identifier]", appRequestData.instanceIdentifier);
        }
        if (appRequestData.icon != null) {
            InputStream inputStream = null;
            try {
                inputStream = this.kit.getContext().getResources().openRawResource(appRequestData.icon.iconResourceId);
                part.part("app[icon][hash]", appRequestData.icon.hash).part("app[icon][data]", "icon.png", "application/octet-stream", inputStream).part("app[icon][width]", (Number) Integer.valueOf(appRequestData.icon.width)).part("app[icon][height]", (Number) Integer.valueOf(appRequestData.icon.height));
            } catch (Resources.NotFoundException e) {
                Logger logger = Fabric.getLogger();
                logger.e("Fabric", "Failed to find app icon with resource ID: " + appRequestData.icon.iconResourceId, e);
            } catch (Throwable th) {
                CommonUtils.closeOrLog(inputStream, "Failed to close app icon InputStream.");
                throw th;
            }
            CommonUtils.closeOrLog(inputStream, "Failed to close app icon InputStream.");
        }
        if (appRequestData.sdkKits != null) {
            for (KitInfo next : appRequestData.sdkKits) {
                part.part(getKitVersionKey(next), next.getVersion());
                part.part(getKitBuildTypeKey(next), next.getBuildType());
            }
        }
        return part;
    }

    /* access modifiers changed from: package-private */
    public String getKitVersionKey(KitInfo kitInfo) {
        return String.format(Locale.US, "app[build][libraries][%s][version]", new Object[]{kitInfo.getIdentifier()});
    }

    /* access modifiers changed from: package-private */
    public String getKitBuildTypeKey(KitInfo kitInfo) {
        return String.format(Locale.US, "app[build][libraries][%s][type]", new Object[]{kitInfo.getIdentifier()});
    }
}
