package io.fabric.sdk.android.services.network;

public enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE
}
