package io.rx_cache2;

public class DynamicKey {
    private final Object dynamicKey;

    public DynamicKey(Object obj) {
        this.dynamicKey = obj;
    }

    public Object getDynamicKey() {
        return this.dynamicKey;
    }
}
