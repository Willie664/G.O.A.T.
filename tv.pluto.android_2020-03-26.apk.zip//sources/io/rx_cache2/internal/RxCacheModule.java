package io.rx_cache2.internal;

import io.rx_cache2.MigrationCache;
import io.rx_cache2.internal.cache.memory.ReferenceMapMemory;
import io.rx_cache2.internal.encrypt.BuiltInEncryptor;
import io.rx_cache2.internal.encrypt.Encryptor;
import io.victoralbertos.jolyglot.JolyglotGenerics;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Singleton;

public final class RxCacheModule {
    private final File cacheDirectory;
    private final String encryptKey;
    private final JolyglotGenerics jolyglot;
    private final Integer maxMgPersistenceCache;
    private final List<MigrationCache> migrations;
    private final boolean useExpiredDataIfLoaderNotAvailable;

    /* access modifiers changed from: package-private */
    @Singleton
    public Persistence providePersistence(Disk disk) {
        return disk;
    }

    /* access modifiers changed from: package-private */
    public ProcessorProviders provideProcessorProviders(ProcessorProvidersBehaviour processorProvidersBehaviour) {
        return processorProvidersBehaviour;
    }

    public RxCacheModule(File file, Boolean bool, Integer num, String str, List<MigrationCache> list, JolyglotGenerics jolyglotGenerics) {
        this.cacheDirectory = file;
        this.useExpiredDataIfLoaderNotAvailable = bool.booleanValue();
        this.maxMgPersistenceCache = num;
        this.encryptKey = str;
        this.migrations = list;
        this.jolyglot = jolyglotGenerics;
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public File provideCacheDirectory() {
        return this.cacheDirectory;
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public Boolean useExpiredDataIfLoaderNotAvailable() {
        return Boolean.valueOf(this.useExpiredDataIfLoaderNotAvailable);
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public Memory provideMemory() {
        return new ReferenceMapMemory();
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public Integer maxMbPersistenceCache() {
        Integer num = this.maxMgPersistenceCache;
        return Integer.valueOf(num != null ? num.intValue() : 100);
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public Encryptor provideEncryptor() {
        return new BuiltInEncryptor();
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public String provideEncryptKey() {
        String str = this.encryptKey;
        return str != null ? str : "";
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public List<MigrationCache> provideMigrations() {
        List<MigrationCache> list = this.migrations;
        return list != null ? list : new ArrayList();
    }

    /* access modifiers changed from: package-private */
    @Singleton
    public JolyglotGenerics provideJolyglot() {
        return this.jolyglot;
    }
}
