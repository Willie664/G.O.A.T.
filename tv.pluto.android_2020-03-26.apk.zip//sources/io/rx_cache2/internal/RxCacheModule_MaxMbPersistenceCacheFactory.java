package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class RxCacheModule_MaxMbPersistenceCacheFactory implements Factory<Integer> {
    private final RxCacheModule module;

    public RxCacheModule_MaxMbPersistenceCacheFactory(RxCacheModule rxCacheModule) {
        this.module = rxCacheModule;
    }

    public Integer get() {
        return (Integer) Preconditions.checkNotNull(this.module.maxMbPersistenceCache(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static RxCacheModule_MaxMbPersistenceCacheFactory create(RxCacheModule rxCacheModule) {
        return new RxCacheModule_MaxMbPersistenceCacheFactory(rxCacheModule);
    }
}
