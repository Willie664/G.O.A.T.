package io.rx_cache2.internal;

import javax.inject.Singleton;

@Singleton
public interface RxCacheComponent {
    ProcessorProviders providers();
}
