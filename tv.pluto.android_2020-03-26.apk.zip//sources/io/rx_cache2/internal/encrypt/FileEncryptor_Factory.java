package io.rx_cache2.internal.encrypt;

import dagger.internal.Factory;
import javax.inject.Provider;

public final class FileEncryptor_Factory implements Factory<FileEncryptor> {
    private final Provider<Encryptor> encryptorProvider;

    public FileEncryptor_Factory(Provider<Encryptor> provider) {
        this.encryptorProvider = provider;
    }

    public FileEncryptor get() {
        return new FileEncryptor(this.encryptorProvider.get());
    }

    public static FileEncryptor_Factory create(Provider<Encryptor> provider) {
        return new FileEncryptor_Factory(provider);
    }
}
