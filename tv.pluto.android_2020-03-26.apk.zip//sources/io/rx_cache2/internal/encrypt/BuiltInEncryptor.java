package io.rx_cache2.internal.encrypt;

import com.appnexus.opensdk.ut.UTConstants;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public final class BuiltInEncryptor implements Encryptor {
    private Cipher decryptCipher;
    private Cipher encryptCipher;

    public void encrypt(String str, File file, File file2) {
        initCiphers(str);
        try {
            write(new CipherInputStream(new FileInputStream(file), this.encryptCipher), new FileOutputStream(file2));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void decrypt(String str, File file, File file2) {
        initCiphers(str);
        try {
            write(new FileInputStream(file), new CipherOutputStream(new FileOutputStream(file2), this.decryptCipher));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initCiphers(String str) {
        try {
            SecretKeySpec generateSecretKey = generateSecretKey(str);
            this.encryptCipher = Cipher.getInstance("AES");
            this.encryptCipher.init(1, generateSecretKey);
            this.decryptCipher = Cipher.getInstance("AES");
            this.decryptCipher.init(2, generateSecretKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private SecretKeySpec generateSecretKey(String str) throws Exception {
        SecureRandom instance = SecureRandom.getInstance("SHA1PRNG");
        instance.setSeed(str.getBytes(UTConstants.UTF_8));
        KeyGenerator instance2 = KeyGenerator.getInstance("AES");
        instance2.init(128, instance);
        return new SecretKeySpec(instance2.generateKey().getEncoded(), "AES");
    }

    private void write(InputStream inputStream, OutputStream outputStream) {
        byte[] bArr = new byte[1024];
        while (true) {
            try {
                int read = inputStream.read(bArr);
                if (read != -1) {
                    outputStream.write(bArr, 0, read);
                } else {
                    try {
                        inputStream.close();
                        outputStream.flush();
                        outputStream.close();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
            } catch (IOException e2) {
                e2.printStackTrace();
                inputStream.close();
                outputStream.flush();
                outputStream.close();
                return;
            } catch (Throwable th) {
                try {
                    inputStream.close();
                    outputStream.flush();
                    outputStream.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                throw th;
            }
        }
    }
}
