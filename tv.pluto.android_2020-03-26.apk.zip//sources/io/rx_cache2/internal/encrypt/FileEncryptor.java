package io.rx_cache2.internal.encrypt;

import java.io.File;
import javax.inject.Inject;

public final class FileEncryptor {
    private final Encryptor encryptor;

    @Inject
    public FileEncryptor(Encryptor encryptor2) {
        this.encryptor = encryptor2;
    }

    public File encrypt(String str, File file) {
        if (!file.exists()) {
            return file;
        }
        String absolutePath = file.getAbsolutePath();
        File rename = rename(file, new File(absolutePath + "-tmp"));
        File file2 = new File(absolutePath);
        this.encryptor.encrypt(str, rename, file2);
        rename.delete();
        return file2;
    }

    public File decrypt(String str, File file) {
        if (!file.exists()) {
            return file;
        }
        String absolutePath = file.getAbsolutePath();
        File file2 = new File(absolutePath + "-tmp");
        this.encryptor.decrypt(str, file, file2);
        return file2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x003d A[SYNTHETIC, Splitter:B:20:0x003d] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0045 A[Catch:{ Exception -> 0x0041 }] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0053 A[SYNTHETIC, Splitter:B:31:0x0053] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x005b A[Catch:{ Exception -> 0x0057 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.io.File rename(java.io.File r10, java.io.File r11) {
        /*
            r9 = this;
            r0 = 0
            java.io.FileInputStream r1 = new java.io.FileInputStream     // Catch:{ Exception -> 0x0036, all -> 0x0033 }
            r1.<init>(r10)     // Catch:{ Exception -> 0x0036, all -> 0x0033 }
            java.nio.channels.FileChannel r1 = r1.getChannel()     // Catch:{ Exception -> 0x0036, all -> 0x0033 }
            java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            r2.<init>(r11)     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            java.nio.channels.FileChannel r0 = r2.getChannel()     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            r3 = 0
            long r5 = r1.size()     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            r2 = r1
            r7 = r0
            r2.transferTo(r3, r5, r7)     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            r10.delete()     // Catch:{ Exception -> 0x002e, all -> 0x002c }
            if (r1 == 0) goto L_0x0026
            r1.close()     // Catch:{ Exception -> 0x0041 }
        L_0x0026:
            if (r0 == 0) goto L_0x004c
            r0.close()     // Catch:{ Exception -> 0x0041 }
            goto L_0x004c
        L_0x002c:
            r10 = move-exception
            goto L_0x0051
        L_0x002e:
            r10 = move-exception
            r8 = r1
            r1 = r0
            r0 = r8
            goto L_0x0038
        L_0x0033:
            r10 = move-exception
            r1 = r0
            goto L_0x0051
        L_0x0036:
            r10 = move-exception
            r1 = r0
        L_0x0038:
            r10.printStackTrace()     // Catch:{ all -> 0x004d }
            if (r0 == 0) goto L_0x0043
            r0.close()     // Catch:{ Exception -> 0x0041 }
            goto L_0x0043
        L_0x0041:
            r10 = move-exception
            goto L_0x0049
        L_0x0043:
            if (r1 == 0) goto L_0x004c
            r1.close()     // Catch:{ Exception -> 0x0041 }
            goto L_0x004c
        L_0x0049:
            r10.printStackTrace()
        L_0x004c:
            return r11
        L_0x004d:
            r10 = move-exception
            r8 = r1
            r1 = r0
            r0 = r8
        L_0x0051:
            if (r1 == 0) goto L_0x0059
            r1.close()     // Catch:{ Exception -> 0x0057 }
            goto L_0x0059
        L_0x0057:
            r11 = move-exception
            goto L_0x005f
        L_0x0059:
            if (r0 == 0) goto L_0x0062
            r0.close()     // Catch:{ Exception -> 0x0057 }
            goto L_0x0062
        L_0x005f:
            r11.printStackTrace()
        L_0x0062:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: io.rx_cache2.internal.encrypt.FileEncryptor.rename(java.io.File, java.io.File):java.io.File");
    }
}
