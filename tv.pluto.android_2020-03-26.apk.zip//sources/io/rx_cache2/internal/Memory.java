package io.rx_cache2.internal;

import java.util.Set;

public interface Memory {
    void evict(String str);

    <T> Record<T> getIfPresent(String str);

    Set<String> keySet();

    <T> void put(String str, Record<T> record);
}
