package io.rx_cache2.internal;

import io.victoralbertos.jolyglot.JolyglotGenerics;
import java.io.File;
import java.lang.reflect.Proxy;
import java.security.InvalidParameterException;

public final class RxCache {
    private final Builder builder;
    private ProxyProviders proxyProviders;

    private RxCache(Builder builder2) {
        this.builder = builder2;
    }

    public <T> T using(Class<T> cls) {
        this.proxyProviders = new ProxyProviders(this.builder, cls);
        return Proxy.newProxyInstance(cls.getClassLoader(), new Class[]{cls}, this.proxyProviders);
    }

    public static class Builder {
        private File cacheDirectory;
        private JolyglotGenerics jolyglot;
        private Integer maxMBPersistenceCache;
        private boolean useExpiredDataIfLoaderNotAvailable;

        public Builder setMaxMBPersistenceCache(Integer num) {
            this.maxMBPersistenceCache = num;
            return this;
        }

        public RxCache persistence(File file, JolyglotGenerics jolyglotGenerics) {
            if (file == null) {
                throw new InvalidParameterException("File cache directory can not be null");
            } else if (!file.exists()) {
                throw new InvalidParameterException("File cache directory does not exist");
            } else if (!file.canWrite()) {
                throw new InvalidParameterException("File cache directory is not writable");
            } else if (jolyglotGenerics != null) {
                this.cacheDirectory = file;
                this.jolyglot = jolyglotGenerics;
                return new RxCache(this);
            } else {
                throw new InvalidParameterException("JsonConverter can not be null");
            }
        }

        public boolean useExpiredDataIfLoaderNotAvailable() {
            return this.useExpiredDataIfLoaderNotAvailable;
        }

        public Integer getMaxMBPersistenceCache() {
            return this.maxMBPersistenceCache;
        }

        public File getCacheDirectory() {
            return this.cacheDirectory;
        }

        public JolyglotGenerics getJolyglot() {
            return this.jolyglot;
        }
    }
}
