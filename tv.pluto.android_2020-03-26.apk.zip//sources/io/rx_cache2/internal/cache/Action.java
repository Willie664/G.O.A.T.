package io.rx_cache2.internal.cache;

import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Persistence;
import java.util.ArrayList;
import java.util.List;

abstract class Action {
    protected final Memory memory;
    protected final Persistence persistence;

    public Action(Memory memory2, Persistence persistence2) {
        this.memory = memory2;
        this.persistence = persistence2;
    }

    /* access modifiers changed from: protected */
    public String composeKey(String str, String str2, String str3) {
        return str + "$d$d$d$" + str2 + "$g$g$g$" + str3;
    }

    /* access modifiers changed from: protected */
    public List<String> getKeysOnMemoryMatchingProviderKey(String str) {
        ArrayList arrayList = new ArrayList();
        for (String next : this.memory.keySet()) {
            if (str.equals(next.substring(0, next.lastIndexOf("$d$d$d$")))) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public List<String> getKeysOnMemoryMatchingDynamicKey(String str, String str2) {
        ArrayList arrayList = new ArrayList();
        String str3 = str + "$d$d$d$" + str2;
        for (String next : this.memory.keySet()) {
            if (str3.equals(next.substring(0, next.lastIndexOf("$g$g$g$")))) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public String getKeyOnMemoryMatchingDynamicKeyGroup(String str, String str2, String str3) {
        return composeKey(str, str2, str3);
    }
}
