package io.rx_cache2.internal.cache;

import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Persistence;
import javax.inject.Inject;

public final class EvictRecord extends Action {
    @Inject
    public EvictRecord(Memory memory, Persistence persistence) {
        super(memory, persistence);
    }

    /* access modifiers changed from: package-private */
    public void evictRecordsMatchingProviderKey(String str) {
        for (String next : getKeysOnMemoryMatchingProviderKey(str)) {
            this.memory.evict(next);
            this.persistence.evict(next);
        }
    }

    /* access modifiers changed from: package-private */
    public void evictRecordsMatchingDynamicKey(String str, String str2) {
        for (String next : getKeysOnMemoryMatchingDynamicKey(str, str2)) {
            this.memory.evict(next);
            this.persistence.evict(next);
        }
    }

    /* access modifiers changed from: package-private */
    public void evictRecordMatchingDynamicKeyGroup(String str, String str2, String str3) {
        String keyOnMemoryMatchingDynamicKeyGroup = getKeyOnMemoryMatchingDynamicKeyGroup(str, str2, str3);
        this.memory.evict(keyOnMemoryMatchingDynamicKeyGroup);
        this.persistence.evict(keyOnMemoryMatchingDynamicKeyGroup);
    }
}
