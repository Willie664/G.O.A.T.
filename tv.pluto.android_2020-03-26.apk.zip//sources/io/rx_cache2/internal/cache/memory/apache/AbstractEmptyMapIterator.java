package io.rx_cache2.internal.cache.memory.apache;

public abstract class AbstractEmptyMapIterator<K, V> extends AbstractEmptyIterator<K> {
    public /* bridge */ /* synthetic */ boolean hasNext() {
        return super.hasNext();
    }

    public /* bridge */ /* synthetic */ Object next() {
        return super.next();
    }

    public /* bridge */ /* synthetic */ void remove() {
        super.remove();
    }

    public V getValue() {
        throw new IllegalStateException("Iterator contains no elements");
    }
}
