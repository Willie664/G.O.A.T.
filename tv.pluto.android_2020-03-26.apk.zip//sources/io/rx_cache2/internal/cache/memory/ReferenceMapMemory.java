package io.rx_cache2.internal.cache.memory;

import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Record;
import io.rx_cache2.internal.cache.memory.apache.ReferenceMap;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

public final class ReferenceMapMemory implements Memory {
    private final Map<String, Record> referenceMap = Collections.synchronizedMap(new ReferenceMap());

    public <T> Record<T> getIfPresent(String str) {
        return this.referenceMap.get(str);
    }

    public <T> void put(String str, Record<T> record) {
        this.referenceMap.put(str, record);
    }

    public Set<String> keySet() {
        return this.referenceMap.keySet();
    }

    public void evict(String str) {
        this.referenceMap.remove(str);
    }
}
