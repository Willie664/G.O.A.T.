package io.rx_cache2.internal.cache.memory.apache;

import java.util.NoSuchElementException;

abstract class AbstractEmptyIterator<E> {
    public boolean hasNext() {
        return false;
    }

    protected AbstractEmptyIterator() {
    }

    public E next() {
        throw new NoSuchElementException("Iterator contains no elements");
    }

    public void remove() {
        throw new IllegalStateException("Iterator contains no elements");
    }
}
