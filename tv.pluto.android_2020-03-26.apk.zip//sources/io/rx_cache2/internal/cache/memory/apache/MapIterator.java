package io.rx_cache2.internal.cache.memory.apache;

import java.util.Iterator;

public interface MapIterator<K, V> extends Iterator<K> {
    V getValue();

    boolean hasNext();

    K next();
}
