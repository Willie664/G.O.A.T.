package io.rx_cache2.internal.cache.memory.apache;

import java.util.Map;

public interface IterableMap extends Map {
}
