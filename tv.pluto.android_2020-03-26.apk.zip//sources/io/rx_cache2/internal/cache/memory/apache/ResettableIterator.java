package io.rx_cache2.internal.cache.memory.apache;

import java.util.Iterator;

public interface ResettableIterator<E> extends Iterator<E> {
}
