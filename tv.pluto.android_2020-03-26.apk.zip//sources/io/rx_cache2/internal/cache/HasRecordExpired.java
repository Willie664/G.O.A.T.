package io.rx_cache2.internal.cache;

import io.rx_cache2.internal.Record;

public final class HasRecordExpired {
    public boolean hasRecordExpired(Record record) {
        long currentTimeMillis = System.currentTimeMillis();
        Long lifeTime = record.getLifeTime();
        if (lifeTime != null && currentTimeMillis > record.getTimeAtWhichWasPersisted() + lifeTime.longValue()) {
            return true;
        }
        return false;
    }
}
