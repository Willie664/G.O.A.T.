package io.rx_cache2.internal.cache;

import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Persistence;
import io.victoralbertos.jolyglot.JolyglotGenerics;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

public final class GetDeepCopy extends Action {
    private final JolyglotGenerics jolyglot;

    @Inject
    public GetDeepCopy(Memory memory, Persistence persistence, JolyglotGenerics jolyglotGenerics) {
        super(memory, persistence);
        this.jolyglot = jolyglotGenerics;
    }

    public <T> T deepCopy(T t) {
        try {
            Class<?> cls = t.getClass();
            boolean isAssignableFrom = Collection.class.isAssignableFrom(cls);
            boolean isArray = cls.isArray();
            boolean isAssignableFrom2 = Map.class.isAssignableFrom(cls);
            if (isAssignableFrom) {
                return getDeepCopyCollection(t);
            }
            if (isArray) {
                return getDeepCopyArray(t);
            }
            if (isAssignableFrom2) {
                return getDeepCopyMap(t);
            }
            return getDeepCopyObject(t);
        } catch (Exception unused) {
            return t;
        }
    }

    private <T> T getDeepCopyCollection(T t) {
        Collection collection = (Collection) t;
        if (collection.isEmpty()) {
            return t;
        }
        Class cls = t.getClass();
        if (List.class.isAssignableFrom(cls)) {
            cls = List.class;
        }
        Class<?> cls2 = collection.toArray()[0].getClass();
        ParameterizedType newParameterizedType = this.jolyglot.newParameterizedType(cls, cls2);
        return this.jolyglot.fromJson(this.jolyglot.toJson(t), (Type) newParameterizedType);
    }

    private <T> T getDeepCopyArray(T t) {
        Object[] objArr = (Object[]) t;
        if (objArr.length == 0) {
            return t;
        }
        GenericArrayType arrayOf = this.jolyglot.arrayOf(objArr[0].getClass());
        return this.jolyglot.fromJson(this.jolyglot.toJson(t), (Type) arrayOf);
    }

    private <T, K, V> T getDeepCopyMap(T t) {
        Map map = (Map) t;
        if (map.isEmpty()) {
            return t;
        }
        Class<?> cls = map.values().toArray()[0].getClass();
        Class<?> cls2 = map.keySet().toArray()[0].getClass();
        ParameterizedType newParameterizedType = this.jolyglot.newParameterizedType(Map.class, cls2, cls);
        return this.jolyglot.fromJson(this.jolyglot.toJson(t), (Type) newParameterizedType);
    }

    private <T> T getDeepCopyObject(T t) {
        if (t == null) {
            return t;
        }
        ParameterizedType newParameterizedType = this.jolyglot.newParameterizedType(t.getClass(), new Type[0]);
        return this.jolyglot.fromJson(this.jolyglot.toJson(t), (Type) newParameterizedType);
    }
}
