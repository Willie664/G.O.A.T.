package io.rx_cache2.internal.cache;

import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Persistence;
import io.rx_cache2.internal.Record;
import javax.inject.Inject;

public final class SaveRecord extends Action {
    private final String encryptKey;
    private final EvictExpirableRecordsPersistence evictExpirableRecordsPersistence;
    private final Integer maxMgPersistenceCache;

    @Inject
    public SaveRecord(Memory memory, Persistence persistence, Integer num, EvictExpirableRecordsPersistence evictExpirableRecordsPersistence2, String str) {
        super(memory, persistence);
        this.maxMgPersistenceCache = num;
        this.evictExpirableRecordsPersistence = evictExpirableRecordsPersistence2;
        this.encryptKey = str;
    }

    /* access modifiers changed from: package-private */
    public void save(String str, String str2, String str3, Object obj, Long l, boolean z, boolean z2) {
        String composeKey = composeKey(str, str2, str3);
        Record record = new Record(obj, Boolean.valueOf(z), l);
        this.memory.put(composeKey, record);
        if (this.persistence.storedMB() >= this.maxMgPersistenceCache.intValue()) {
            System.out.println("RxCache -> Record can not be persisted because it would exceed the max limit megabytes settled down");
        } else {
            this.persistence.saveRecord(composeKey, record, z2, this.encryptKey);
        }
        this.evictExpirableRecordsPersistence.startTaskIfNeeded(z2);
    }
}
