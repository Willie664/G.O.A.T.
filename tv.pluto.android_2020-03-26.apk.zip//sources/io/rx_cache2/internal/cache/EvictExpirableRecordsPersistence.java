package io.rx_cache2.internal.cache;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.rx_cache2.internal.Memory;
import io.rx_cache2.internal.Persistence;
import io.rx_cache2.internal.Record;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public final class EvictExpirableRecordsPersistence extends Action {
    /* access modifiers changed from: private */
    public boolean couldBeExpirableRecords = true;
    /* access modifiers changed from: private */
    public final String encryptKey;
    /* access modifiers changed from: private */
    public boolean isEncrypted;
    private final Integer maxMgPersistenceCache;
    private final Observable<String> oEvictingTask = oEvictingTask();

    @Inject
    public EvictExpirableRecordsPersistence(Memory memory, Persistence persistence, Integer num, String str) {
        super(memory, persistence);
        this.maxMgPersistenceCache = num;
        this.encryptKey = str;
    }

    /* access modifiers changed from: package-private */
    public Observable<String> startTaskIfNeeded(boolean z) {
        this.isEncrypted = z;
        this.oEvictingTask.subscribe();
        return this.oEvictingTask;
    }

    private Observable<String> oEvictingTask() {
        return Observable.create(new ObservableOnSubscribe<String>() {
            public void subscribe(ObservableEmitter<String> observableEmitter) throws Exception {
                if (!EvictExpirableRecordsPersistence.this.couldBeExpirableRecords) {
                    observableEmitter.onNext("Records can not be evicted because no one is expirable");
                    observableEmitter.onComplete();
                    return;
                }
                int storedMB = EvictExpirableRecordsPersistence.this.persistence.storedMB();
                if (!EvictExpirableRecordsPersistence.this.reachedPercentageMemoryToStart(storedMB)) {
                    observableEmitter.onComplete();
                    return;
                }
                float f = 0.0f;
                for (String next : EvictExpirableRecordsPersistence.this.persistence.allKeys()) {
                    if (EvictExpirableRecordsPersistence.this.reachedPercentageMemoryToStop(storedMB, f)) {
                        break;
                    }
                    Record retrieveRecord = EvictExpirableRecordsPersistence.this.persistence.retrieveRecord(next, EvictExpirableRecordsPersistence.this.isEncrypted, EvictExpirableRecordsPersistence.this.encryptKey);
                    if (retrieveRecord != null && retrieveRecord.getExpirable().booleanValue()) {
                        EvictExpirableRecordsPersistence.this.persistence.evict(next);
                        observableEmitter.onNext(next);
                        f += retrieveRecord.getSizeOnMb();
                    }
                }
                EvictExpirableRecordsPersistence evictExpirableRecordsPersistence = EvictExpirableRecordsPersistence.this;
                boolean unused = evictExpirableRecordsPersistence.couldBeExpirableRecords = evictExpirableRecordsPersistence.reachedPercentageMemoryToStop(storedMB, f);
                observableEmitter.onComplete();
            }
        }).subscribeOn(Schedulers.io()).observeOn(Schedulers.io()).doOnError(new Consumer<Throwable>() {
            public void accept(Throwable th) throws Exception {
                th.printStackTrace();
            }
        }).share();
    }

    /* access modifiers changed from: private */
    public boolean reachedPercentageMemoryToStop(int i, float f) {
        return ((float) i) - f <= ((float) this.maxMgPersistenceCache.intValue()) * 0.7f;
    }

    /* access modifiers changed from: private */
    public boolean reachedPercentageMemoryToStart(int i) {
        return i >= ((int) (((float) this.maxMgPersistenceCache.intValue()) * 0.95f));
    }
}
