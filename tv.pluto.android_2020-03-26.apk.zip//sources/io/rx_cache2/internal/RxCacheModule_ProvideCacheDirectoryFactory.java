package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;
import java.io.File;

public final class RxCacheModule_ProvideCacheDirectoryFactory implements Factory<File> {
    private final RxCacheModule module;

    public RxCacheModule_ProvideCacheDirectoryFactory(RxCacheModule rxCacheModule) {
        this.module = rxCacheModule;
    }

    public File get() {
        return (File) Preconditions.checkNotNull(this.module.provideCacheDirectory(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static RxCacheModule_ProvideCacheDirectoryFactory create(RxCacheModule rxCacheModule) {
        return new RxCacheModule_ProvideCacheDirectoryFactory(rxCacheModule);
    }
}
