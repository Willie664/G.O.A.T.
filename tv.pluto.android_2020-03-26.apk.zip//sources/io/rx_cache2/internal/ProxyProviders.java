package io.rx_cache2.internal;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.Single;
import io.rx_cache2.EncryptKey;
import io.rx_cache2.Migration;
import io.rx_cache2.MigrationCache;
import io.rx_cache2.SchemeMigration;
import io.rx_cache2.internal.RxCache;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public final class ProxyProviders implements InvocationHandler {
    /* access modifiers changed from: private */
    public final ProcessorProviders processorProviders;
    /* access modifiers changed from: private */
    public final ProxyTranslator proxyTranslator = new ProxyTranslator();

    public ProxyProviders(RxCache.Builder builder, Class<?> cls) {
        this.processorProviders = DaggerRxCacheComponent.builder().rxCacheModule(new RxCacheModule(builder.getCacheDirectory(), Boolean.valueOf(builder.useExpiredDataIfLoaderNotAvailable()), builder.getMaxMBPersistenceCache(), getEncryptKey(cls), getMigrations(cls), builder.getJolyglot())).build().providers();
    }

    public String getEncryptKey(Class<?> cls) {
        EncryptKey encryptKey = (EncryptKey) cls.getAnnotation(EncryptKey.class);
        if (encryptKey == null) {
            return null;
        }
        return encryptKey.value();
    }

    public List<MigrationCache> getMigrations(Class<?> cls) {
        ArrayList arrayList = new ArrayList();
        Annotation annotation = cls.getAnnotation(SchemeMigration.class);
        if (annotation == null) {
            return arrayList;
        }
        for (Migration migration : ((SchemeMigration) annotation).value()) {
            arrayList.add(new MigrationCache(migration.version(), migration.evictClasses()));
        }
        return arrayList;
    }

    public Object invoke(Object obj, final Method method, final Object[] objArr) throws Throwable {
        return Observable.defer(new Callable<ObservableSource<?>>() {
            public ObservableSource<?> call() throws Exception {
                Observable process = ProxyProviders.this.processorProviders.process(ProxyProviders.this.proxyTranslator.processMethod(method, objArr));
                Class<?> returnType = method.getReturnType();
                if (returnType == Observable.class) {
                    return Observable.just(process);
                }
                if (returnType == Single.class) {
                    return Observable.just(Single.fromObservable(process));
                }
                if (returnType == Maybe.class) {
                    return Observable.just(Maybe.fromSingle(Single.fromObservable(process)));
                }
                if (method.getReturnType() == Flowable.class) {
                    return Observable.just(process.toFlowable(BackpressureStrategy.MISSING));
                }
                throw new RuntimeException(method.getName() + " needs to return one of the next reactive types: observable, single, maybe or flowable");
            }
        }).blockingFirst();
    }
}
