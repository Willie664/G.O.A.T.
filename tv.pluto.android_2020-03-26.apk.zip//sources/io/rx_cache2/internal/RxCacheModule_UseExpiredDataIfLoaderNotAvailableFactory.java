package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class RxCacheModule_UseExpiredDataIfLoaderNotAvailableFactory implements Factory<Boolean> {
    private final RxCacheModule module;

    public RxCacheModule_UseExpiredDataIfLoaderNotAvailableFactory(RxCacheModule rxCacheModule) {
        this.module = rxCacheModule;
    }

    public Boolean get() {
        return (Boolean) Preconditions.checkNotNull(this.module.useExpiredDataIfLoaderNotAvailable(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static RxCacheModule_UseExpiredDataIfLoaderNotAvailableFactory create(RxCacheModule rxCacheModule) {
        return new RxCacheModule_UseExpiredDataIfLoaderNotAvailableFactory(rxCacheModule);
    }
}
