package io.rx_cache2.internal;

import io.reactivex.Observable;
import io.rx_cache2.ConfigProvider;

public interface ProcessorProviders {
    <T> Observable<T> process(ConfigProvider configProvider);
}
