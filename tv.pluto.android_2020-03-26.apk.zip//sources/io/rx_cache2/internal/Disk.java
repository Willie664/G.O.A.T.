package io.rx_cache2.internal;

import com.appsflyer.share.Constants;
import io.fabric.sdk.android.services.events.EventsFilesManager;
import io.rx_cache2.internal.encrypt.FileEncryptor;
import io.victoralbertos.jolyglot.JolyglotGenerics;
import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

public final class Disk implements Persistence {
    private final File cacheDirectory;
    private final FileEncryptor fileEncryptor;
    private final JolyglotGenerics jolyglot;

    @Inject
    public Disk(File file, FileEncryptor fileEncryptor2, JolyglotGenerics jolyglotGenerics) {
        this.cacheDirectory = file;
        this.fileEncryptor = fileEncryptor2;
        this.jolyglot = jolyglotGenerics;
    }

    public void saveRecord(String str, Record record, boolean z, String str2) {
        save(str, record, z, str2);
    }

    public List<String> allKeys() {
        ArrayList arrayList = new ArrayList();
        File[] listFiles = this.cacheDirectory.listFiles();
        if (listFiles == null) {
            return arrayList;
        }
        for (File file : listFiles) {
            if (file.isFile()) {
                arrayList.add(file.getName());
            }
        }
        return arrayList;
    }

    public int storedMB() {
        File[] listFiles = this.cacheDirectory.listFiles();
        if (listFiles == null) {
            return 0;
        }
        long j = 0;
        for (File length : listFiles) {
            j += length.length();
        }
        double d = (double) j;
        Double.isNaN(d);
        return (int) Math.ceil((d / 1024.0d) / 1024.0d);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x005d A[SYNTHETIC, Splitter:B:22:0x005d] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void save(java.lang.String r6, java.lang.Object r7, boolean r8, java.lang.String r9) {
        /*
            r5 = this;
            java.lang.String r6 = r5.safetyKey(r6)
            boolean r0 = r7 instanceof io.rx_cache2.internal.Record
            r1 = 0
            if (r0 == 0) goto L_0x0021
            io.victoralbertos.jolyglot.JolyglotGenerics r0 = r5.jolyglot
            java.lang.Class r2 = r7.getClass()
            r3 = 1
            java.lang.reflect.Type[] r3 = new java.lang.reflect.Type[r3]
            java.lang.Class<java.lang.Object> r4 = java.lang.Object.class
            r3[r1] = r4
            java.lang.reflect.ParameterizedType r0 = r0.newParameterizedType(r2, r3)
            io.victoralbertos.jolyglot.JolyglotGenerics r2 = r5.jolyglot
            java.lang.String r7 = r2.toJson(r7, r0)
            goto L_0x0027
        L_0x0021:
            io.victoralbertos.jolyglot.JolyglotGenerics r0 = r5.jolyglot
            java.lang.String r7 = r0.toJson(r7)
        L_0x0027:
            r0 = 0
            java.io.File r2 = new java.io.File     // Catch:{ Exception -> 0x0054 }
            java.io.File r3 = r5.cacheDirectory     // Catch:{ Exception -> 0x0054 }
            r2.<init>(r3, r6)     // Catch:{ Exception -> 0x0054 }
            java.io.FileWriter r3 = new java.io.FileWriter     // Catch:{ Exception -> 0x0054 }
            r3.<init>(r2, r1)     // Catch:{ Exception -> 0x0054 }
            r3.write(r7)     // Catch:{ Exception -> 0x004f, all -> 0x004c }
            r3.flush()     // Catch:{ Exception -> 0x004f, all -> 0x004c }
            r3.close()     // Catch:{ Exception -> 0x004f, all -> 0x004c }
            if (r8 == 0) goto L_0x004b
            io.rx_cache2.internal.encrypt.FileEncryptor r7 = r5.fileEncryptor     // Catch:{ Exception -> 0x0054 }
            java.io.File r8 = new java.io.File     // Catch:{ Exception -> 0x0054 }
            java.io.File r1 = r5.cacheDirectory     // Catch:{ Exception -> 0x0054 }
            r8.<init>(r1, r6)     // Catch:{ Exception -> 0x0054 }
            r7.encrypt(r9, r8)     // Catch:{ Exception -> 0x0054 }
        L_0x004b:
            return
        L_0x004c:
            r6 = move-exception
            r0 = r3
            goto L_0x005b
        L_0x004f:
            r6 = move-exception
            r0 = r3
            goto L_0x0055
        L_0x0052:
            r6 = move-exception
            goto L_0x005b
        L_0x0054:
            r6 = move-exception
        L_0x0055:
            java.lang.RuntimeException r7 = new java.lang.RuntimeException     // Catch:{ all -> 0x0052 }
            r7.<init>(r6)     // Catch:{ all -> 0x0052 }
            throw r7     // Catch:{ all -> 0x0052 }
        L_0x005b:
            if (r0 == 0) goto L_0x0068
            r0.flush()     // Catch:{ IOException -> 0x0064 }
            r0.close()     // Catch:{ IOException -> 0x0064 }
            goto L_0x0068
        L_0x0064:
            r7 = move-exception
            r7.printStackTrace()
        L_0x0068:
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: io.rx_cache2.internal.Disk.save(java.lang.String, java.lang.Object, boolean, java.lang.String):void");
    }

    public void evict(String str) {
        new File(this.cacheDirectory, safetyKey(str)).delete();
    }

    public <T> T retrieve(String str, Class<T> cls, boolean z, String str2) {
        File file = new File(this.cacheDirectory, safetyKey(str));
        if (z) {
            file = this.fileEncryptor.decrypt(str2, file);
        }
        try {
            T fromJson = this.jolyglot.fromJson(file, cls);
            if (z) {
                file.delete();
            }
            return fromJson;
        } catch (Exception unused) {
            if (z) {
                file.delete();
            }
            return null;
        } catch (Throwable th) {
            if (z) {
                file.delete();
            }
            throw th;
        }
    }

    public <T> Record<T> retrieveRecord(String str, boolean z, String str2) {
        Type type;
        Class cls;
        Record<T> record;
        File file = new File(this.cacheDirectory, safetyKey(str));
        if (z) {
            try {
                file = this.fileEncryptor.decrypt(str2, file);
            } catch (Exception unused) {
                if (z) {
                    file.delete();
                }
                return null;
            } catch (Throwable th) {
                if (z) {
                    file.delete();
                }
                throw th;
            }
        }
        Record record2 = (Record) this.jolyglot.fromJson(file, (Type) this.jolyglot.newParameterizedType(Record.class, Object.class));
        if (record2.getDataClassName() == null) {
            type = Object.class;
        } else {
            type = Class.forName(record2.getDataClassName());
        }
        if (record2.getDataCollectionClassName() == null) {
            cls = Object.class;
        } else {
            cls = Class.forName(record2.getDataCollectionClassName());
        }
        boolean isAssignableFrom = Collection.class.isAssignableFrom(cls);
        boolean isArray = cls.isArray();
        boolean isAssignableFrom2 = Map.class.isAssignableFrom(cls);
        if (isAssignableFrom) {
            record = (Record) this.jolyglot.fromJson(file.getAbsoluteFile(), (Type) this.jolyglot.newParameterizedType(Record.class, this.jolyglot.newParameterizedType(cls, type)));
        } else if (isArray) {
            record = (Record) this.jolyglot.fromJson(file.getAbsoluteFile(), (Type) this.jolyglot.newParameterizedType(Record.class, cls));
        } else if (isAssignableFrom2) {
            Class<?> cls2 = Class.forName(record2.getDataKeyMapClassName());
            record = (Record) this.jolyglot.fromJson(file.getAbsoluteFile(), (Type) this.jolyglot.newParameterizedType(Record.class, this.jolyglot.newParameterizedType(cls, cls2, type)));
        } else {
            record = (Record) this.jolyglot.fromJson(file.getAbsoluteFile(), (Type) this.jolyglot.newParameterizedType(Record.class, type));
        }
        record.setSizeOnMb((((float) file.length()) / 1024.0f) / 1024.0f);
        if (z) {
            file.delete();
        }
        return record;
    }

    private String safetyKey(String str) {
        return str.replaceAll(Constants.URL_PATH_DELIMITER, EventsFilesManager.ROLL_OVER_FILE_NAME_SEPARATOR);
    }
}
