package io.rx_cache2.internal.migration;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Function;
import io.rx_cache2.MigrationCache;
import io.rx_cache2.internal.Persistence;
import java.util.List;
import javax.inject.Inject;

public final class DoMigrations {
    /* access modifiers changed from: private */
    public final DeleteRecordMatchingClassName deleteRecordMatchingClassName;
    private final GetCacheVersion getCacheVersion;
    /* access modifiers changed from: private */
    public final GetClassesToEvictFromMigrations getClassesToEvictFromMigrations = new GetClassesToEvictFromMigrations();
    /* access modifiers changed from: private */
    public final GetPendingMigrations getPendingMigrations;
    /* access modifiers changed from: private */
    public final List<MigrationCache> migrations;
    /* access modifiers changed from: private */
    public final UpgradeCacheVersion upgradeCacheVersion;

    @Inject
    public DoMigrations(Persistence persistence, List<MigrationCache> list, String str) {
        this.getCacheVersion = new GetCacheVersion(persistence);
        this.getPendingMigrations = new GetPendingMigrations();
        this.migrations = list;
        this.upgradeCacheVersion = new UpgradeCacheVersion(persistence);
        this.deleteRecordMatchingClassName = new DeleteRecordMatchingClassName(persistence, str);
    }

    public Observable<Integer> react() {
        return this.getCacheVersion.react().flatMap(new Function<Integer, ObservableSource<List<MigrationCache>>>() {
            public ObservableSource<List<MigrationCache>> apply(Integer num) throws Exception {
                return DoMigrations.this.getPendingMigrations.with(num.intValue(), DoMigrations.this.migrations).react();
            }
        }).flatMap(new Function<List<MigrationCache>, ObservableSource<List<Class>>>() {
            public ObservableSource<List<Class>> apply(List<MigrationCache> list) throws Exception {
                return DoMigrations.this.getClassesToEvictFromMigrations.with(list).react();
            }
        }).flatMap(new Function<List<Class>, ObservableSource<Integer>>() {
            public ObservableSource<Integer> apply(List<Class> list) throws Exception {
                return DoMigrations.this.deleteRecordMatchingClassName.with(list).react();
            }
        }).flatMap(new Function<Integer, ObservableSource<Integer>>() {
            public ObservableSource<Integer> apply(Integer num) throws Exception {
                return DoMigrations.this.upgradeCacheVersion.with(DoMigrations.this.migrations).react();
            }
        });
    }
}
