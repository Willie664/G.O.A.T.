package io.rx_cache2.internal.migration;

import io.reactivex.Observable;
import io.rx_cache2.MigrationCache;
import java.util.ArrayList;
import java.util.List;

final class GetClassesToEvictFromMigrations {
    private List<MigrationCache> migrations;

    /* access modifiers changed from: package-private */
    public GetClassesToEvictFromMigrations with(List<MigrationCache> list) {
        this.migrations = list;
        return this;
    }

    /* access modifiers changed from: package-private */
    public Observable<List<Class>> react() {
        ArrayList arrayList = new ArrayList();
        for (MigrationCache evictClasses : this.migrations) {
            for (Class cls : evictClasses.evictClasses()) {
                if (!isAlreadyAdded(arrayList, cls)) {
                    arrayList.add(cls);
                }
            }
        }
        return Observable.just(arrayList);
    }

    private boolean isAlreadyAdded(List<Class> list, Class cls) {
        for (Class name : list) {
            if (name.getName().equals(cls.getName())) {
                return true;
            }
        }
        return false;
    }
}
