package io.rx_cache2.internal.migration;

import io.reactivex.Observable;
import io.rx_cache2.internal.Persistence;
import io.rx_cache2.internal.Record;
import java.util.List;
import javax.inject.Inject;

public final class DeleteRecordMatchingClassName {
    private List<Class> classes;
    private final String encryptKey;
    private final Persistence persistence;

    @Inject
    public DeleteRecordMatchingClassName(Persistence persistence2, String str) {
        this.persistence = persistence2;
        this.encryptKey = str;
    }

    public DeleteRecordMatchingClassName with(List<Class> list) {
        this.classes = list;
        return this;
    }

    public Observable<Integer> react() {
        if (this.classes.isEmpty()) {
            return Observable.just(1);
        }
        for (String next : this.persistence.allKeys()) {
            Record retrieveRecord = this.persistence.retrieveRecord(next, false, this.encryptKey);
            if (retrieveRecord == null) {
                retrieveRecord = this.persistence.retrieveRecord(next, true, this.encryptKey);
            }
            if (evictRecord(retrieveRecord)) {
                this.persistence.evict(next);
            }
        }
        return Observable.just(1);
    }

    private boolean evictRecord(Record record) {
        String dataClassName = record.getDataClassName();
        for (Class name : this.classes) {
            if (name.getName().equals(dataClassName)) {
                return true;
            }
        }
        return false;
    }
}
