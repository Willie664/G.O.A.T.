package io.rx_cache2.internal.migration;

import io.reactivex.Observable;
import io.rx_cache2.internal.Persistence;
import javax.inject.Inject;

final class GetCacheVersion extends CacheVersion {
    @Inject
    public GetCacheVersion(Persistence persistence) {
        super(persistence);
    }

    /* access modifiers changed from: package-private */
    public Observable<Integer> react() {
        int i = 0;
        Integer num = (Integer) this.persistence.retrieve("key_cache_version", Integer.class, false, (String) null);
        if (num != null) {
            i = num.intValue();
        }
        return Observable.just(Integer.valueOf(i));
    }
}
