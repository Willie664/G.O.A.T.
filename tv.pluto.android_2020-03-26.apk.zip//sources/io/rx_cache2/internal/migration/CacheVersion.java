package io.rx_cache2.internal.migration;

import io.rx_cache2.internal.Persistence;

abstract class CacheVersion {
    protected final Persistence persistence;

    public CacheVersion(Persistence persistence2) {
        this.persistence = persistence2;
    }
}
