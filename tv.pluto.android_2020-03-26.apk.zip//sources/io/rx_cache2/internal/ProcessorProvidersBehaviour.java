package io.rx_cache2.internal;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import io.rx_cache2.ConfigProvider;
import io.rx_cache2.EvictDynamicKey;
import io.rx_cache2.EvictDynamicKeyGroup;
import io.rx_cache2.Reply;
import io.rx_cache2.RxCacheException;
import io.rx_cache2.Source;
import io.rx_cache2.internal.cache.EvictExpiredRecordsPersistence;
import io.rx_cache2.internal.cache.GetDeepCopy;
import io.rx_cache2.internal.cache.TwoLayersCache;
import io.rx_cache2.internal.migration.DoMigrations;
import java.util.concurrent.Callable;
import javax.inject.Inject;

public final class ProcessorProvidersBehaviour implements ProcessorProviders {
    private final GetDeepCopy getDeepCopy;
    /* access modifiers changed from: private */
    public volatile Boolean hasProcessesEnded = false;
    /* access modifiers changed from: private */
    public final Observable<Integer> oProcesses;
    /* access modifiers changed from: private */
    public final TwoLayersCache twoLayersCache;
    /* access modifiers changed from: private */
    public final Boolean useExpiredDataIfLoaderNotAvailable;

    @Inject
    public ProcessorProvidersBehaviour(TwoLayersCache twoLayersCache2, Boolean bool, EvictExpiredRecordsPersistence evictExpiredRecordsPersistence, GetDeepCopy getDeepCopy2, DoMigrations doMigrations) {
        this.twoLayersCache = twoLayersCache2;
        this.useExpiredDataIfLoaderNotAvailable = bool;
        this.getDeepCopy = getDeepCopy2;
        this.oProcesses = startProcesses(doMigrations, evictExpiredRecordsPersistence);
    }

    private Observable<Integer> startProcesses(DoMigrations doMigrations, final EvictExpiredRecordsPersistence evictExpiredRecordsPersistence) {
        Observable<R> share = doMigrations.react().flatMap(new Function<Integer, ObservableSource<Integer>>() {
            public ObservableSource<Integer> apply(Integer num) throws Exception {
                return evictExpiredRecordsPersistence.startEvictingExpiredRecords();
            }
        }).subscribeOn(Schedulers.io()).observeOn(Schedulers.io()).share();
        share.subscribe((Consumer<? super R>) new Consumer<Integer>() {
            public void accept(Integer num) throws Exception {
                Boolean unused = ProcessorProvidersBehaviour.this.hasProcessesEnded = true;
            }
        });
        return share;
    }

    public <T> Observable<T> process(final ConfigProvider configProvider) {
        return Observable.defer(new Callable<ObservableSource<? extends T>>() {
            public ObservableSource<? extends T> call() throws Exception {
                if (ProcessorProvidersBehaviour.this.hasProcessesEnded.booleanValue()) {
                    return ProcessorProvidersBehaviour.this.getData(configProvider);
                }
                return ProcessorProvidersBehaviour.this.oProcesses.flatMap(new Function<Integer, ObservableSource<? extends T>>() {
                    public ObservableSource<? extends T> apply(Integer num) throws Exception {
                        return ProcessorProvidersBehaviour.this.getData(configProvider);
                    }
                });
            }
        });
    }

    /* access modifiers changed from: package-private */
    public <T> Observable<T> getData(final ConfigProvider configProvider) {
        Observable<Reply> observable;
        Record retrieve = this.twoLayersCache.retrieve(configProvider.getProviderKey(), configProvider.getDynamicKey(), configProvider.getDynamicKeyGroup(), this.useExpiredDataIfLoaderNotAvailable.booleanValue(), configProvider.getLifeTimeMillis(), configProvider.isEncrypted());
        if (retrieve == null || configProvider.evictProvider().evict()) {
            observable = getDataFromLoader(configProvider, retrieve);
        } else {
            observable = Observable.just(new Reply(retrieve.getData(), retrieve.getSource(), configProvider.isEncrypted()));
        }
        return observable.map(new Function<Reply, Object>() {
            public Object apply(Reply reply) throws Exception {
                return ProcessorProvidersBehaviour.this.getReturnType(configProvider, reply);
            }
        });
    }

    private Observable<Reply> getDataFromLoader(final ConfigProvider configProvider, final Record record) {
        return configProvider.getLoaderObservable().map(new Function<Object, Reply>() {
            public Reply apply(Object obj) throws Exception {
                Boolean bool;
                Record record;
                if (configProvider.useExpiredDataIfNotLoaderAvailable() != null) {
                    bool = configProvider.useExpiredDataIfNotLoaderAvailable();
                } else {
                    bool = ProcessorProvidersBehaviour.this.useExpiredDataIfLoaderNotAvailable;
                }
                boolean booleanValue = bool.booleanValue();
                if (obj == null && booleanValue && (record = record) != null) {
                    return new Reply(record.getData(), record.getSource(), configProvider.isEncrypted());
                }
                ProcessorProvidersBehaviour.this.clearKeyIfNeeded(configProvider);
                if (obj != null) {
                    ProcessorProvidersBehaviour.this.twoLayersCache.save(configProvider.getProviderKey(), configProvider.getDynamicKey(), configProvider.getDynamicKeyGroup(), obj, configProvider.getLifeTimeMillis(), configProvider.isExpirable(), configProvider.isEncrypted());
                    return new Reply(obj, Source.CLOUD, configProvider.isEncrypted());
                }
                throw new RxCacheException("The Loader provided did not return any data and there is not data to load from the Cache " + configProvider.getProviderKey());
            }
        }).onErrorReturn(new Function<Object, Object>() {
            public Object apply(Object obj) throws Exception {
                Boolean bool;
                Record record;
                ProcessorProvidersBehaviour.this.clearKeyIfNeeded(configProvider);
                if (configProvider.useExpiredDataIfNotLoaderAvailable() != null) {
                    bool = configProvider.useExpiredDataIfNotLoaderAvailable();
                } else {
                    bool = ProcessorProvidersBehaviour.this.useExpiredDataIfLoaderNotAvailable;
                }
                if (bool.booleanValue() && (record = record) != null) {
                    return new Reply(record.getData(), record.getSource(), configProvider.isEncrypted());
                }
                throw new RxCacheException("The Loader provided did not return any data and there is not data to load from the Cache " + configProvider.getProviderKey(), (Throwable) obj);
            }
        });
    }

    /* access modifiers changed from: private */
    public void clearKeyIfNeeded(ConfigProvider configProvider) {
        if (configProvider.evictProvider().evict()) {
            if (configProvider.evictProvider() instanceof EvictDynamicKeyGroup) {
                this.twoLayersCache.evictDynamicKeyGroup(configProvider.getProviderKey(), configProvider.getDynamicKey().toString(), configProvider.getDynamicKeyGroup().toString());
            } else if (configProvider.evictProvider() instanceof EvictDynamicKey) {
                this.twoLayersCache.evictDynamicKey(configProvider.getProviderKey(), configProvider.getDynamicKey().toString());
            } else {
                this.twoLayersCache.evictProviderKey(configProvider.getProviderKey());
            }
        }
    }

    /* access modifiers changed from: private */
    public Object getReturnType(ConfigProvider configProvider, Reply reply) {
        Object deepCopy = this.getDeepCopy.deepCopy(reply.getData());
        return configProvider.requiredDetailedResponse() ? new Reply(deepCopy, reply.getSource(), configProvider.isEncrypted()) : deepCopy;
    }
}
