package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;
import io.rx_cache2.MigrationCache;
import java.util.List;

public final class RxCacheModule_ProvideMigrationsFactory implements Factory<List<MigrationCache>> {
    private final RxCacheModule module;

    public RxCacheModule_ProvideMigrationsFactory(RxCacheModule rxCacheModule) {
        this.module = rxCacheModule;
    }

    public List<MigrationCache> get() {
        return (List) Preconditions.checkNotNull(this.module.provideMigrations(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static RxCacheModule_ProvideMigrationsFactory create(RxCacheModule rxCacheModule) {
        return new RxCacheModule_ProvideMigrationsFactory(rxCacheModule);
    }
}
