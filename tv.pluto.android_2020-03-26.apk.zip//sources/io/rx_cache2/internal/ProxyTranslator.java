package io.rx_cache2.internal;

import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.rx_cache2.ConfigProvider;
import io.rx_cache2.DynamicKey;
import io.rx_cache2.DynamicKeyGroup;
import io.rx_cache2.Encrypt;
import io.rx_cache2.EvictProvider;
import io.rx_cache2.Expirable;
import io.rx_cache2.LifeCache;
import io.rx_cache2.ProviderKey;
import io.rx_cache2.Reply;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;

public final class ProxyTranslator {
    private final Map<Method, ConfigProvider> configProviderMethodCache = new HashMap();

    @Inject
    ProxyTranslator() {
    }

    /* access modifiers changed from: package-private */
    public ConfigProvider processMethod(Method method, Object[] objArr) {
        ConfigProvider loadConfigProviderMethod = loadConfigProviderMethod(method);
        return new ConfigProvider(loadConfigProviderMethod.getProviderKey(), (Boolean) null, loadConfigProviderMethod.getLifeTimeMillis(), loadConfigProviderMethod.requiredDetailedResponse(), loadConfigProviderMethod.isExpirable(), loadConfigProviderMethod.isEncrypted(), getDynamicKey(method, objArr), getDynamicKeyGroup(method, objArr), getLoaderObservable(method, objArr), evictProvider(method, objArr));
    }

    private String getProviderKey(Method method) {
        ProviderKey providerKey = (ProviderKey) method.getAnnotation(ProviderKey.class);
        if (providerKey != null) {
            return providerKey.value();
        }
        return method.getName();
    }

    private String getDynamicKey(Method method, Object[] objArr) {
        DynamicKey dynamicKey = (DynamicKey) getObjectFromMethodParam(method, DynamicKey.class, objArr);
        if (dynamicKey != null) {
            return dynamicKey.getDynamicKey().toString();
        }
        DynamicKeyGroup dynamicKeyGroup = (DynamicKeyGroup) getObjectFromMethodParam(method, DynamicKeyGroup.class, objArr);
        return dynamicKeyGroup != null ? dynamicKeyGroup.getDynamicKey().toString() : "";
    }

    private String getDynamicKeyGroup(Method method, Object[] objArr) {
        DynamicKeyGroup dynamicKeyGroup = (DynamicKeyGroup) getObjectFromMethodParam(method, DynamicKeyGroup.class, objArr);
        return dynamicKeyGroup != null ? dynamicKeyGroup.getGroup().toString() : "";
    }

    private Observable getLoaderObservable(Method method, Object[] objArr) {
        Observable observable = (Observable) getObjectFromMethodParam(method, Observable.class, objArr);
        if (observable != null) {
            return observable;
        }
        Single single = (Single) getObjectFromMethodParam(method, Single.class, objArr);
        if (single != null) {
            return single.toObservable();
        }
        Maybe maybe = (Maybe) getObjectFromMethodParam(method, Maybe.class, objArr);
        if (maybe != null) {
            return maybe.toObservable();
        }
        Flowable flowable = (Flowable) getObjectFromMethodParam(method, Flowable.class, objArr);
        if (flowable != null) {
            return flowable.toObservable();
        }
        throw new IllegalArgumentException(method.getName() + " requires an instance of one of the next reactive types: observable, single, maybe or flowable");
    }

    private Long getLifeTimeCache(Method method) {
        LifeCache lifeCache = (LifeCache) method.getAnnotation(LifeCache.class);
        if (lifeCache == null) {
            return null;
        }
        return Long.valueOf(lifeCache.timeUnit().toMillis(lifeCache.duration()));
    }

    private boolean getExpirable(Method method) {
        Expirable expirable = (Expirable) method.getAnnotation(Expirable.class);
        if (expirable != null) {
            return expirable.value();
        }
        return true;
    }

    private boolean isEncrypted(Method method) {
        return ((Encrypt) method.getAnnotation(Encrypt.class)) != null;
    }

    private boolean requiredDetailResponse(Method method) {
        if (method.getReturnType() == Observable.class || method.getReturnType() == Single.class || method.getReturnType() == Maybe.class || method.getReturnType() == Flowable.class) {
            return method.getGenericReturnType().toString().contains(Reply.class.getName());
        }
        throw new IllegalArgumentException(method.getName() + " needs to return one of the next reactive types: observable, single, maybe or flowable");
    }

    private EvictProvider evictProvider(Method method, Object[] objArr) {
        EvictProvider evictProvider = (EvictProvider) getObjectFromMethodParam(method, EvictProvider.class, objArr);
        if (evictProvider != null) {
            return evictProvider;
        }
        return new EvictProvider(false);
    }

    private <T> T getObjectFromMethodParam(Method method, Class<T> cls, Object[] objArr) {
        T t = null;
        int i = 0;
        for (T t2 : objArr) {
            if (cls.isAssignableFrom(t2.getClass())) {
                i++;
                t = t2;
            }
        }
        if (i <= 1) {
            return t;
        }
        throw new IllegalArgumentException(method.getName() + " requires just one instance of type " + t.getClass().getSimpleName());
    }

    private ConfigProvider loadConfigProviderMethod(Method method) {
        ConfigProvider configProvider;
        synchronized (this.configProviderMethodCache) {
            configProvider = this.configProviderMethodCache.get(method);
            if (configProvider == null) {
                configProvider = new ConfigProvider(getProviderKey(method), (Boolean) null, getLifeTimeCache(method), requiredDetailResponse(method), getExpirable(method), isEncrypted(method), (String) null, (String) null, (Observable) null, (EvictProvider) null);
                this.configProviderMethodCache.put(method, configProvider);
            }
        }
        return configProvider;
    }
}
