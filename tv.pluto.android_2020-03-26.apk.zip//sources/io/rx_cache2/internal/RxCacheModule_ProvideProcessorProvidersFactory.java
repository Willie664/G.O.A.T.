package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;
import javax.inject.Provider;

public final class RxCacheModule_ProvideProcessorProvidersFactory implements Factory<ProcessorProviders> {
    private final RxCacheModule module;
    private final Provider<ProcessorProvidersBehaviour> processorProvidersBehaviourProvider;

    public ProcessorProviders get() {
        return (ProcessorProviders) Preconditions.checkNotNull(this.module.provideProcessorProviders(this.processorProvidersBehaviourProvider.get()), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static ProcessorProviders proxyProvideProcessorProviders(RxCacheModule rxCacheModule, ProcessorProvidersBehaviour processorProvidersBehaviour) {
        return (ProcessorProviders) Preconditions.checkNotNull(rxCacheModule.provideProcessorProviders(processorProvidersBehaviour), "Cannot return null from a non-@Nullable @Provides method");
    }
}
