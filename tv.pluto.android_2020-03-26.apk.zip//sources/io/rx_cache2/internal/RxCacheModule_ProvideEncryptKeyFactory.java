package io.rx_cache2.internal;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class RxCacheModule_ProvideEncryptKeyFactory implements Factory<String> {
    private final RxCacheModule module;

    public RxCacheModule_ProvideEncryptKeyFactory(RxCacheModule rxCacheModule) {
        this.module = rxCacheModule;
    }

    public String get() {
        return (String) Preconditions.checkNotNull(this.module.provideEncryptKey(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static RxCacheModule_ProvideEncryptKeyFactory create(RxCacheModule rxCacheModule) {
        return new RxCacheModule_ProvideEncryptKeyFactory(rxCacheModule);
    }
}
