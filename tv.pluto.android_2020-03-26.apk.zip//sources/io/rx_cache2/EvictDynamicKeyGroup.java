package io.rx_cache2;

public class EvictDynamicKeyGroup extends EvictDynamicKey {
}
