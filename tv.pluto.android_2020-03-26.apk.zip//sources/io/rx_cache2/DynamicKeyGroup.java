package io.rx_cache2;

public class DynamicKeyGroup {
    private final Object dynamicKey;
    private final Object group;

    public Object getDynamicKey() {
        return this.dynamicKey;
    }

    public Object getGroup() {
        return this.group;
    }
}
