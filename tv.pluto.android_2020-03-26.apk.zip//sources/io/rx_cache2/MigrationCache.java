package io.rx_cache2;

public final class MigrationCache {
    private final Class[] evictClasses;
    private final int version;

    public MigrationCache(int i, Class[] clsArr) {
        this.version = i;
        this.evictClasses = clsArr;
    }

    public int version() {
        return this.version;
    }

    public Class[] evictClasses() {
        return this.evictClasses;
    }
}
