package io.rx_cache2;

public final class RxCacheException extends RuntimeException {
    public RxCacheException(String str) {
        super(str);
    }

    public RxCacheException(String str, Throwable th) {
        super(str, th);
    }
}
