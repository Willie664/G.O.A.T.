package io.rx_cache2;

public enum Source {
    MEMORY,
    PERSISTENCE,
    CLOUD
}
