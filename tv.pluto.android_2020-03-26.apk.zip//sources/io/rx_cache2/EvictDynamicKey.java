package io.rx_cache2;

public class EvictDynamicKey extends EvictProvider {
}
