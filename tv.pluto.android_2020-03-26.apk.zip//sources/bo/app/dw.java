package bo.app;

public interface dw<T> {
    void a(String str);

    void b(String str);

    void c(String str);

    void d(String str);
}
