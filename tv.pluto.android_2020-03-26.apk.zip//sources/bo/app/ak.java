package bo.app;

public final class ak {
    private final cw a;

    public ak(cw cwVar) {
        this.a = cwVar;
    }

    public cw a() {
        return this.a;
    }
}
