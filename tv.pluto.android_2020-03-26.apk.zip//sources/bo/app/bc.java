package bo.app;

import android.graphics.Bitmap;
import bo.app.bd;
import com.appboy.support.AppboyLogger;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

public class bc {
    private static final String a = AppboyLogger.getAppboyLogTag(bc.class);
    private final bd b;

    public bc(File file, int i, int i2, long j) {
        this.b = bd.a(file, i, i2, j);
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0036 A[DONT_GENERATE] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Bitmap a(java.lang.String r7) {
        /*
            r6 = this;
            java.lang.String r7 = r6.c(r7)
            r0 = 0
            bo.app.bd r1 = r6.b     // Catch:{ all -> 0x001c }
            bo.app.bd$b r1 = r1.a((java.lang.String) r7)     // Catch:{ all -> 0x001c }
            r2 = 0
            java.io.InputStream r2 = r1.a(r2)     // Catch:{ all -> 0x001a }
            android.graphics.Bitmap r7 = android.graphics.BitmapFactory.decodeStream(r2)     // Catch:{ all -> 0x001a }
            if (r1 == 0) goto L_0x0019
            r1.close()
        L_0x0019:
            return r7
        L_0x001a:
            r2 = move-exception
            goto L_0x001e
        L_0x001c:
            r2 = move-exception
            r1 = r0
        L_0x001e:
            java.lang.String r3 = a     // Catch:{ all -> 0x0050 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0050 }
            r4.<init>()     // Catch:{ all -> 0x0050 }
            java.lang.String r5 = "Failed to get bitmap from disk cache for key "
            r4.append(r5)     // Catch:{ all -> 0x0050 }
            r4.append(r7)     // Catch:{ all -> 0x0050 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0050 }
            com.appboy.support.AppboyLogger.e(r3, r4, r2)     // Catch:{ all -> 0x0050 }
            if (r1 == 0) goto L_0x0039
            r1.close()
        L_0x0039:
            java.lang.String r1 = a
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Failed to load image from disk cache: "
            r2.append(r3)
            r2.append(r7)
            java.lang.String r7 = r2.toString()
            com.appboy.support.AppboyLogger.d(r1, r7)
            return r0
        L_0x0050:
            r7 = move-exception
            if (r1 == 0) goto L_0x0056
            r1.close()
        L_0x0056:
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.bc.a(java.lang.String):android.graphics.Bitmap");
    }

    public void a(String str, Bitmap bitmap) {
        String str2;
        StringBuilder sb;
        String c = c(str);
        OutputStream outputStream = null;
        try {
            bd.a b2 = this.b.b(c);
            outputStream = b2.a(0);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            b2.a();
            if (outputStream != null) {
                try {
                    outputStream.close();
                    return;
                } catch (IOException e) {
                    e = e;
                    str2 = a;
                    sb = new StringBuilder();
                }
            } else {
                return;
            }
            sb.append("Exception while closing disk cache output stream for key");
            sb.append(c);
            AppboyLogger.e(str2, sb.toString(), e);
        } catch (Throwable th) {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e2) {
                    String str3 = a;
                    AppboyLogger.e(str3, "Exception while closing disk cache output stream for key" + c, e2);
                }
            }
            throw th;
        }
    }

    public boolean b(String str) {
        String c = c(str);
        boolean z = false;
        try {
            bd.b a2 = this.b.a(c);
            if (a2 != null) {
                z = true;
            }
            if (a2 != null) {
                a2.close();
            }
            return z;
        } catch (Throwable th) {
            String str2 = a;
            AppboyLogger.e(str2, "Error while retrieving disk for key " + c, th);
            return false;
        }
    }

    private String c(String str) {
        return Integer.toString(str.hashCode());
    }
}
