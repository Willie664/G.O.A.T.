package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class dm {
    private static final String a = AppboyLogger.getAppboyLogTag(dm.class);
    private final Random b;
    private final int c;
    private final int d;
    private int e;

    public dm(int i) {
        this(i, (int) TimeUnit.SECONDS.toMillis(1));
    }

    public dm(int i, int i2) {
        this.b = new Random();
        this.e = 0;
        this.c = i;
        this.d = i2;
    }

    public void a() {
        this.e = 0;
    }

    public boolean b() {
        return this.e != 0;
    }

    public int c() {
        return a(this.d);
    }

    public int a(int i) {
        String str = a;
        AppboyLogger.d(str, "Computing new sleep delay. Previous sleep delay: " + this.e);
        this.e = Math.min(this.c, a(this.b, i, this.e * 3));
        String str2 = a;
        AppboyLogger.d(str2, "New sleep duration: " + this.e + " ms. Default sleep duration: " + i + " ms. Max sleep: " + this.c + " ms.");
        return this.e;
    }

    static int a(Random random, int i, int i2) {
        return random.nextInt(Math.abs(i - i2)) + Math.min(i, i2);
    }
}
