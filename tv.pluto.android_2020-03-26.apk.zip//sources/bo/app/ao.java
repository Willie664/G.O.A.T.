package bo.app;

public final class ao {
    public static final ao a = new ao();
}
