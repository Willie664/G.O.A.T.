package bo.app;

public class af {
    private final df a;

    public af(df dfVar) {
        if (dfVar != null) {
            this.a = dfVar;
            return;
        }
        throw new NullPointerException();
    }
}
