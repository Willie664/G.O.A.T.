package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class eb implements dv {
    private static final String a = AppboyLogger.getAppboyLogTag(eb.class);
    private boolean b = false;
    private final SharedPreferences c;

    public eb(Context context, String str, String str2) {
        this.c = context.getSharedPreferences("com.appboy.storage.appboy_event_storage" + StringUtils.getCacheFileSuffix(context, str, str2), 0);
    }

    public void a(cc ccVar) {
        if (this.b) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding event: " + ccVar);
            return;
        }
        SharedPreferences.Editor edit = this.c.edit();
        String str2 = a;
        AppboyLogger.d(str2, "Adding event to storage with uid " + ccVar.d(), false);
        edit.putString(ccVar.d(), ccVar.e());
        edit.apply();
    }

    public void a(List<cc> list) {
        if (this.b) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding events: " + list);
            return;
        }
        SharedPreferences.Editor edit = this.c.edit();
        for (cc next : list) {
            String str2 = a;
            AppboyLogger.d(str2, "Adding event to storage with uid " + next.d(), false);
            edit.putString(next.d(), next.e());
        }
        edit.apply();
    }

    public Collection<cc> a() {
        if (this.b) {
            AppboyLogger.w(a, "Storage provider is closed. Not getting all events.");
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (Map.Entry next : this.c.getAll().entrySet()) {
            String str = (String) next.getKey();
            String str2 = (String) next.getValue();
            try {
                arrayList.add(cn.i(str2, str));
            } catch (Exception e) {
                String str3 = a;
                AppboyLogger.e(str3, "Could not create AppboyEvent from [serialized event string=" + str2 + ", unique identifier=" + str + "] ... Deleting!", e);
                a(str);
            }
        }
        return arrayList;
    }

    public void b(List<cc> list) {
        if (this.b) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not deleting events: " + list);
            return;
        }
        SharedPreferences.Editor edit = this.c.edit();
        for (cc d : list) {
            String d2 = d.d();
            String str2 = a;
            AppboyLogger.d(str2, "Deleting event from storage with uid " + d2, false);
            edit.remove(d2);
        }
        edit.apply();
    }

    public void b() {
        AppboyLogger.w(a, "Setting this provider to closed.");
        this.b = true;
    }

    /* access modifiers changed from: package-private */
    public void a(String str) {
        SharedPreferences.Editor edit = this.c.edit();
        edit.remove(str);
        edit.apply();
    }
}
