package bo.app;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class gk {
    private final PriorityQueue<et> a = new PriorityQueue<>(16, b());

    public gk(List<et> list) {
        this.a.addAll(list);
    }

    public et a() {
        return this.a.poll();
    }

    private static Comparator<et> b() {
        return new Comparator<et>() {
            /* renamed from: a */
            public int compare(et etVar, et etVar2) {
                int c = etVar.c().c();
                int c2 = etVar2.c().c();
                if (c > c2) {
                    return -1;
                }
                if (c < c2) {
                    return 1;
                }
                return etVar.b().compareTo(etVar2.b());
            }
        };
    }
}
