package bo.app;

public final class gj {
    private final fr a;
    private final String b;

    public gj(fr frVar, String str) {
        this.a = frVar;
        this.b = str;
    }

    public fr a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}
