package bo.app;

import java.util.concurrent.Executor;

public class dj implements dh {
    private final d a;
    private final g b;
    private final ac c;
    private final ac d;
    private final Executor e;
    private final du f;
    private final ea g;
    private final dq h;
    private bt i;

    public dj(d dVar, g gVar, ac acVar, ac acVar2, Executor executor, du duVar, ea eaVar, dq dqVar) {
        this.a = dVar;
        this.b = gVar;
        this.c = acVar;
        this.d = acVar2;
        this.e = executor;
        this.f = duVar;
        this.g = eaVar;
        this.h = dqVar;
    }

    public void a(dg dgVar) {
        this.e.execute(a((df) dgVar));
    }

    public void b(dg dgVar) {
        a((df) dgVar).run();
    }

    public void a(bt btVar) {
        this.i = btVar;
    }

    private cy a(df dfVar) {
        return new cy(dfVar, this.a, this.b, this.c, this.d, this.f, this.i, this.g, this.h);
    }
}
