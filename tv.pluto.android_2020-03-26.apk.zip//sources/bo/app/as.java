package bo.app;

public final class as {
    private final ft a;

    public as(ft ftVar) {
        this.a = ftVar;
    }

    public ft a() {
        return this.a;
    }
}
