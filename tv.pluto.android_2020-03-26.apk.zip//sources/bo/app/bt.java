package bo.app;

import bo.app.cl;
import java.util.List;

public interface bt {
    void a(cd cdVar);

    void a(cl.a aVar);

    void a(df dfVar);

    void a(ev evVar, ft ftVar);

    void a(ft ftVar);

    void a(Throwable th);

    void a(List<String> list, long j);

    boolean a(cc ccVar);

    void b(cc ccVar);

    void b(Throwable th);

    String e();
}
