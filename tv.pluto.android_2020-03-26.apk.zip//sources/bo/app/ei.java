package bo.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import androidx.core.view.PointerIconCompat;
import com.appboy.models.AppboyGeofence;
import com.appboy.support.AppboyLogger;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class ei {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(ei.class);

    public static void a(Context context, List<AppboyGeofence> list, PendingIntent pendingIntent) {
        try {
            List<AppboyGeofence> a2 = eh.a(b(context));
            if (list.isEmpty()) {
                ArrayList arrayList = new ArrayList();
                for (AppboyGeofence next : a2) {
                    arrayList.add(next.getId());
                    String str = a;
                    AppboyLogger.d(str, "Obsolete geofence will be un-registered: " + next.getId());
                }
                if (!arrayList.isEmpty()) {
                    c(context, arrayList);
                    String str2 = a;
                    AppboyLogger.d(str2, "No new geofences to register. Cleared " + a2.size() + " previously registered geofences.");
                    return;
                }
                AppboyLogger.d(a, "No new geofences to register. No geofences are currently registered.");
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            HashSet hashSet = new HashSet();
            for (AppboyGeofence next2 : list) {
                hashSet.add(next2.getId());
                boolean z = true;
                for (AppboyGeofence next3 : a2) {
                    if (next2.getId().equals(next3.getId()) && next2.equivalentServerData(next3)) {
                        z = false;
                    }
                }
                if (z) {
                    String str3 = a;
                    AppboyLogger.d(str3, "New geofence will be registered: " + next2.getId());
                    arrayList2.add(next2);
                }
            }
            ArrayList arrayList3 = new ArrayList();
            for (AppboyGeofence next4 : a2) {
                if (!hashSet.contains(next4.getId())) {
                    arrayList3.add(next4.getId());
                    String str4 = a;
                    AppboyLogger.d(str4, "Obsolete geofence will be un-registered: " + next4.getId());
                }
            }
            if (!arrayList3.isEmpty()) {
                String str5 = a;
                AppboyLogger.d(str5, "Un-registering " + arrayList3.size() + " obsolete geofences from Google Play Services.");
                c(context, arrayList3);
            } else {
                AppboyLogger.d(a, "No obsolete geofences need to be unregistered from Google Play Services.");
            }
            if (!arrayList2.isEmpty()) {
                String str6 = a;
                AppboyLogger.d(str6, "Registering " + arrayList2.size() + " new geofences with Google Play Services.");
                b(context, arrayList2, pendingIntent);
                return;
            }
            AppboyLogger.d(a, "No new geofences need to be registered with Google Play Services.");
        } catch (SecurityException e) {
            AppboyLogger.e(a, "Security exception while adding geofences.", e);
        } catch (Exception e2) {
            AppboyLogger.e(a, "Exception while adding geofences.", e2);
        }
    }

    public static void a(Context context, PendingIntent pendingIntent, final bs bsVar) {
        try {
            AppboyLogger.d(a, "Requesting single location update from Google Play Services.");
            LocationRequest create = LocationRequest.create();
            create.setPriority(100);
            create.setNumUpdates(1);
            if (Looper.myLooper() == null) {
                Looper.prepare();
            }
            LocationServices.getFusedLocationProviderClient(context).requestLocationUpdates(create, pendingIntent).addOnSuccessListener(new OnSuccessListener<Void>() {
                /* renamed from: a */
                public void onSuccess(Void voidR) {
                    AppboyLogger.v(ei.a, "Single location request from Google Play services was successful.");
                    bsVar.c(true);
                }
            }).addOnFailureListener(new OnFailureListener() {
                public void onFailure(Exception exc) {
                    AppboyLogger.e(ei.a, "Failed to get single location update from Google Play services.", exc);
                    bsVar.c(false);
                }
            });
        } catch (SecurityException e) {
            AppboyLogger.w(a, "Failed to request location update due to security exception from insufficient permissions.", e);
        } catch (Exception e2) {
            AppboyLogger.w(a, "Failed to request location update due to exception.", e2);
        }
    }

    public static void a(Context context) {
        AppboyLogger.d(a, "Deleting registered geofence cache.");
        SharedPreferences.Editor edit = b(context).edit();
        edit.clear();
        edit.apply();
    }

    private static void b(final Context context, final List<AppboyGeofence> list, PendingIntent pendingIntent) {
        ArrayList arrayList = new ArrayList();
        for (AppboyGeofence geofence : list) {
            arrayList.add(geofence.toGeofence());
        }
        LocationServices.getGeofencingClient(context).addGeofences(new GeofencingRequest.Builder().addGeofences(arrayList).setInitialTrigger(0).build(), pendingIntent).addOnSuccessListener(new OnSuccessListener<Void>() {
            /* renamed from: a */
            public void onSuccess(Void voidR) {
                AppboyLogger.d(ei.a, "Geofences successfully registered with Google Play Services.");
                ei.d(context, list);
            }
        }).addOnFailureListener(new OnFailureListener() {
            public void onFailure(Exception exc) {
                if (exc instanceof ApiException) {
                    int statusCode = ((ApiException) exc).getStatusCode();
                    if (statusCode != 0) {
                        switch (statusCode) {
                            case 1000:
                                String a = ei.a;
                                AppboyLogger.w(a, "Geofences not registered with Google Play Services due to GEOFENCE_NOT_AVAILABLE: " + statusCode);
                                return;
                            case PointerIconCompat.TYPE_CONTEXT_MENU:
                                String a2 = ei.a;
                                AppboyLogger.w(a2, "Geofences not registered with Google Play Services due to GEOFENCE_TOO_MANY_GEOFENCES: " + statusCode);
                                return;
                            case PointerIconCompat.TYPE_HAND:
                                String a3 = ei.a;
                                AppboyLogger.w(a3, "Geofences not registered with Google Play Services due to GEOFENCE_TOO_MANY_PENDING_INTENTS: " + statusCode);
                                return;
                            default:
                                String a4 = ei.a;
                                AppboyLogger.w(a4, "Geofence pending result returned unknown status code: " + statusCode);
                                return;
                        }
                    } else {
                        AppboyLogger.d(ei.a, "Received Geofence registration success code in failure block with Google Play Services.");
                    }
                } else {
                    AppboyLogger.e(ei.a, "Geofence exception encountered while adding geofences.", exc);
                }
            }
        });
    }

    private static void c(final Context context, final List<String> list) {
        LocationServices.getGeofencingClient(context).removeGeofences(list).addOnSuccessListener(new OnSuccessListener<Void>() {
            /* renamed from: a */
            public void onSuccess(Void voidR) {
                AppboyLogger.d(ei.a, "Geofences successfully un-registered with Google Play Services.");
                ei.e(context, list);
            }
        }).addOnFailureListener(new OnFailureListener() {
            public void onFailure(Exception exc) {
                if (exc instanceof ApiException) {
                    int statusCode = ((ApiException) exc).getStatusCode();
                    if (statusCode != 0) {
                        switch (statusCode) {
                            case 1000:
                                String a = ei.a;
                                AppboyLogger.w(a, "Geofences cannot be un-registered with Google Play Services due to GEOFENCE_NOT_AVAILABLE: " + statusCode);
                                return;
                            case PointerIconCompat.TYPE_CONTEXT_MENU:
                                String a2 = ei.a;
                                AppboyLogger.w(a2, "Geofences cannot be un-registered with Google Play Services due to GEOFENCE_TOO_MANY_GEOFENCES: " + statusCode);
                                return;
                            case PointerIconCompat.TYPE_HAND:
                                String a3 = ei.a;
                                AppboyLogger.w(a3, "Geofences cannot be un-registered with Google Play Services due to GEOFENCE_TOO_MANY_PENDING_INTENTS: " + statusCode);
                                return;
                            default:
                                String a4 = ei.a;
                                AppboyLogger.w(a4, "Geofence pending result returned unknown status code: " + statusCode);
                                return;
                        }
                    } else {
                        AppboyLogger.d(ei.a, "Received Geofence un-registration success code in failure block with Google Play Services.");
                    }
                } else {
                    AppboyLogger.e(ei.a, "Geofence exception encountered while removing geofences.", exc);
                }
            }
        });
    }

    private static SharedPreferences b(Context context) {
        return context.getSharedPreferences("com.appboy.support.geofences", 0);
    }

    /* access modifiers changed from: private */
    public static void d(Context context, List<AppboyGeofence> list) {
        SharedPreferences.Editor edit = b(context).edit();
        for (AppboyGeofence next : list) {
            edit.putString(next.getId(), next.forJsonPut().toString());
            String str = a;
            AppboyLogger.v(str, "Geofence with id: " + next.getId() + " added to shared preferences.");
        }
        edit.apply();
    }

    /* access modifiers changed from: private */
    public static void e(Context context, List<String> list) {
        SharedPreferences.Editor edit = b(context).edit();
        for (String next : list) {
            edit.remove(next);
            String str = a;
            AppboyLogger.v(str, "Geofence with id: " + next + " removed from shared preferences.");
        }
        edit.apply();
    }
}
