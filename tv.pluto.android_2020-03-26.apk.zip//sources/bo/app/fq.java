package bo.app;

public enum fq {
    STRING,
    DATE,
    NUMBER,
    BOOLEAN,
    UNKNOWN
}
