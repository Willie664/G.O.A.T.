package bo.app;

public class cv implements cu {
    private final String a;

    public cv(String str) {
        this.a = str;
    }

    public String a() {
        return this.a;
    }
}
