package bo.app;

public class ag {
    private final df a;

    public ag(df dfVar) {
        this.a = dfVar;
    }
}
