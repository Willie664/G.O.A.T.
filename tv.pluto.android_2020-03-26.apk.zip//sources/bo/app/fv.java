package bo.app;

public class fv extends ga implements ft {
    private String a;
    private String b;

    public String b() {
        return "iam_click";
    }

    public fv(String str) {
        this.a = a(str);
    }

    public fv(String str, String str2) {
        this(str);
        this.b = str2;
    }

    public String a() {
        return this.a;
    }

    public String f() {
        return this.b;
    }
}
