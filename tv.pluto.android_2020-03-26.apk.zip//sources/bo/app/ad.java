package bo.app;

public final class ad {
    private final df a;

    public ad(df dfVar) {
        if (dfVar != null) {
            this.a = dfVar;
            return;
        }
        throw new NullPointerException();
    }

    public df a() {
        return this.a;
    }
}
