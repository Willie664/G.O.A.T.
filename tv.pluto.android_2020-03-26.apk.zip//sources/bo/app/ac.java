package bo.app;

public interface ac {
    <T> void a(T t, Class<T> cls);
}
