package bo.app;

public class fz extends ga implements ft {
    public String b() {
        return "test";
    }
}
