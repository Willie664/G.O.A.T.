package bo.app;

import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;
import java.util.concurrent.ThreadFactory;

public class n implements t {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(n.class);
    private final AppboyConfigurationProvider b;
    private final dh c;
    /* access modifiers changed from: private */
    public final r d;
    private final Object e = new Object();
    private volatile boolean f = false;
    private volatile Thread g;
    /* access modifiers changed from: private */
    public volatile boolean h = true;
    private db i;
    private boolean j = false;

    public n(AppboyConfigurationProvider appboyConfigurationProvider, ac acVar, dh dhVar, r rVar, ThreadFactory threadFactory, boolean z) {
        this.b = appboyConfigurationProvider;
        this.c = dhVar;
        this.d = rVar;
        this.g = threadFactory.newThread(new a());
        this.i = new db(acVar);
        this.j = z;
    }

    public void a(cc ccVar) {
        this.d.a(ccVar);
    }

    public void a(ac acVar, df dfVar) {
        this.d.a(acVar, dfVar);
    }

    public void b(cc ccVar) {
        this.d.b(ccVar);
    }

    public void a(cg cgVar) {
        this.d.a(cgVar);
    }

    public void a(ab abVar) {
        synchronized (this.e) {
            this.h = false;
            this.g.interrupt();
            this.g = null;
        }
        if (!this.d.a()) {
            this.d.a(abVar, c());
        }
        df c2 = this.d.c();
        if (c2 != null) {
            b(c2);
        }
        abVar.a();
    }

    public void a() {
        synchronized (this.e) {
            if (this.f) {
                AppboyLogger.d(a, "Automatic request execution start was previously requested, continuing without action.");
                return;
            }
            if (this.g != null) {
                this.g.start();
            }
            this.f = true;
        }
    }

    private da c() {
        return new da(this.b.getBaseUrlForRequests());
    }

    class a implements Runnable {
        private a() {
        }

        public void run() {
            while (n.this.h) {
                try {
                    n.this.a(n.this.d.b());
                } catch (InterruptedException e) {
                    String b = n.a;
                    AppboyLogger.e(b, "Automatic thread interrupted! This is usually the result of calling changeUser(). [" + e.toString() + "]");
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public void a(df dfVar) {
        if (dfVar.i() || this.j) {
            this.i.a(dfVar);
        } else {
            this.c.a(dfVar);
        }
    }

    private void b(df dfVar) {
        if (dfVar.i() || this.j) {
            this.i.b(dfVar);
        } else {
            this.c.b(dfVar);
        }
    }
}
