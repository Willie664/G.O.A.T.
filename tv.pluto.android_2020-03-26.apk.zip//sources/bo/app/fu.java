package bo.app;

import com.appboy.models.outgoing.AppboyProperties;

public interface fu extends ft {
    AppboyProperties f();
}
