package bo.app;

import com.appboy.models.IPutIntoJson;
import org.json.JSONObject;

public interface fm extends IPutIntoJson<JSONObject> {
    boolean a();

    boolean b();

    Integer c();
}
