package bo.app;

public interface fa extends ez {
    boolean a(ft ftVar);
}
