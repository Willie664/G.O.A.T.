package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class ec implements dx {
    private static final String a = AppboyLogger.getAppboyLogTag(ec.class);
    private final SharedPreferences b;

    public ec(Context context, String str, String str2) {
        this.b = context.getSharedPreferences("com.appboy.storage.session_storage" + StringUtils.getCacheFileSuffix(context, str, str2), 0);
    }

    public void a(cf cfVar) {
        String cgVar = cfVar.a().toString();
        JSONObject g = cfVar.forJsonPut();
        SharedPreferences.Editor edit = this.b.edit();
        a(g);
        edit.putString(cgVar, g.toString());
        if (!cfVar.d()) {
            edit.putString("current_open_session", cgVar);
        } else if (this.b.getString("current_open_session", "").equals(cgVar)) {
            edit.remove("current_open_session");
        }
        edit.apply();
    }

    public cf a() {
        JSONObject jSONObject;
        String str;
        if (!this.b.contains("current_open_session")) {
            AppboyLogger.d(a, "No stored open session in storage.");
            return null;
        }
        try {
            str = this.b.getString("current_open_session", "");
            try {
                jSONObject = new JSONObject(this.b.getString(str, ""));
            } catch (JSONException e) {
                e = e;
                jSONObject = null;
                AppboyLogger.e(a, "Could not create new mutable session for open session with id: " + str + " and json data: " + jSONObject, e);
                return null;
            }
            try {
                return new cf(jSONObject);
            } catch (JSONException e2) {
                e = e2;
                AppboyLogger.e(a, "Could not create new mutable session for open session with id: " + str + " and json data: " + jSONObject, e);
                return null;
            }
        } catch (JSONException e3) {
            e = e3;
            str = null;
            jSONObject = null;
            AppboyLogger.e(a, "Could not create new mutable session for open session with id: " + str + " and json data: " + jSONObject, e);
            return null;
        }
    }

    public void b(cf cfVar) {
        String string = this.b.getString("current_open_session", (String) null);
        String cgVar = cfVar.a().toString();
        SharedPreferences.Editor edit = this.b.edit();
        edit.remove(cgVar);
        if (cgVar.equals(string)) {
            edit.remove("current_open_session");
        }
        edit.apply();
    }

    private void a(JSONObject jSONObject) {
        if (!jSONObject.has("end_time")) {
            try {
                jSONObject.put("end_time", ee.b());
            } catch (JSONException unused) {
                AppboyLogger.e(a, "Failed to set end time to now for session json data");
            }
        }
    }
}
