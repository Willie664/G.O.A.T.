package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import com.appboy.support.AppboyFileUtils;
import com.appboy.support.AppboyLogger;
import com.appboy.support.IntentUtils;
import com.appboy.support.StringUtils;
import com.appboy.support.WebContentUtils;
import com.appsflyer.share.Constants;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class gg implements gc {
    private static final String a = AppboyLogger.getAppboyLogTag(gg.class);
    private final Context b;
    private final SharedPreferences c;
    private Map<String, String> d;
    private Map<String, String> e = new HashMap();

    public gg(Context context, String str) {
        this.b = context;
        this.c = context.getSharedPreferences("com.appboy.storage.triggers.local_assets." + str, 0);
        this.d = a(this.c);
    }

    public void a(List<et> list) {
        HashSet<gj> hashSet = new HashSet<>();
        HashSet hashSet2 = new HashSet();
        a(list, hashSet, hashSet2);
        SharedPreferences.Editor edit = this.c.edit();
        a(hashSet2, edit, this.d, this.e);
        b();
        for (gj gjVar : hashSet) {
            String b2 = gjVar.b();
            if (this.d.containsKey(b2)) {
                String str = a;
                AppboyLogger.d(str, "Local assets already contains remote path string: " + b2);
            } else {
                try {
                    String a2 = a(gjVar);
                    if (!StringUtils.isNullOrBlank(a2)) {
                        String str2 = a;
                        AppboyLogger.d(str2, "Adding new local path " + a2 + " for remote path " + b2 + " to cache.");
                        this.d.put(b2, a2);
                        edit.putString(b2, a2);
                        edit.apply();
                    }
                } catch (Exception e2) {
                    String str3 = a;
                    AppboyLogger.e(str3, "Failed to add new local path for remote path " + b2, e2);
                }
            }
        }
    }

    public String a(et etVar) {
        if (!etVar.a()) {
            AppboyLogger.d(a, "Prefetch turned off for this triggered action. Not retrieving local asset path.");
            return null;
        }
        gj d2 = etVar.d();
        if (d2 == null) {
            AppboyLogger.i(a, "Remote path was null or blank. Not retrieving local asset path.");
            return null;
        }
        String b2 = d2.b();
        if (StringUtils.isNullOrBlank(b2)) {
            AppboyLogger.w(a, "Remote asset path string was null or blank. Not retrieving local asset path.");
            return null;
        } else if (this.d.containsKey(b2)) {
            String str = this.d.get(b2);
            if (!new File(str).exists()) {
                String str2 = a;
                AppboyLogger.w(str2, "Local asset for remote asset path did not exist: " + b2);
                return null;
            }
            String str3 = a;
            AppboyLogger.i(str3, "Retrieving local asset path for remote asset path: " + b2);
            this.e.put(b2, str);
            return str;
        } else {
            String str4 = a;
            AppboyLogger.w(str4, "No local asset path found for remote asset path: " + b2);
            return null;
        }
    }

    public static void a(Context context) {
        File file = new File(context.getCacheDir(), "ab_triggers");
        String str = a;
        AppboyLogger.v(str, "Deleting triggers directory at: " + file.getAbsolutePath());
        AppboyFileUtils.deleteFileOrDirectory(file);
    }

    /* access modifiers changed from: package-private */
    public String a(gj gjVar) {
        File a2 = a();
        String b2 = gjVar.b();
        if (gjVar.a().equals(fr.ZIP)) {
            String localHtmlUrlFromRemoteUrl = WebContentUtils.getLocalHtmlUrlFromRemoteUrl(a2, b2);
            if (!StringUtils.isNullOrBlank(localHtmlUrlFromRemoteUrl)) {
                String str = a;
                AppboyLogger.i(str, "Storing local triggered action html zip asset at local path " + localHtmlUrlFromRemoteUrl + " for remote path " + b2);
                return localHtmlUrlFromRemoteUrl;
            }
            String str2 = a;
            AppboyLogger.d(str2, "Failed to store html zip asset for remote path " + b2 + ". Not storing local asset");
            return null;
        }
        File downloadFileToPath = AppboyFileUtils.downloadFileToPath(a2.toString(), b2, Integer.toString(IntentUtils.getRequestCode()), (String) null);
        if (downloadFileToPath != null) {
            Uri fromFile = Uri.fromFile(downloadFileToPath);
            if (fromFile != null) {
                String str3 = a;
                AppboyLogger.i(str3, "Storing local triggered action image asset at local path " + fromFile.getPath() + " for remote path " + b2);
                return fromFile.getPath();
            }
            String str4 = a;
            AppboyLogger.d(str4, "Failed to store image asset for remote path " + b2 + ". Not storing local asset");
        }
        return null;
    }

    private static Map<String, String> a(SharedPreferences sharedPreferences) {
        Set<String> keySet;
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        Map<String, ?> all = sharedPreferences.getAll();
        if (!(all == null || all.size() == 0 || (keySet = all.keySet()) == null || keySet.size() == 0)) {
            try {
                for (String next : keySet) {
                    String string = sharedPreferences.getString(next, (String) null);
                    if (!StringUtils.isNullOrBlank(string)) {
                        String str = a;
                        AppboyLogger.d(str, "Retrieving trigger local asset path " + string + " from local storage for remote path " + next + ".");
                        concurrentHashMap.put(next, string);
                    }
                }
            } catch (Exception e2) {
                AppboyLogger.e(a, "Encountered unexpected exception while parsing stored triggered action local assets.", e2);
            }
        }
        return concurrentHashMap;
    }

    /* access modifiers changed from: package-private */
    public File a() {
        return new File(this.b.getCacheDir().getPath() + Constants.URL_PATH_DELIMITER + "ab_triggers");
    }

    private void b() {
        try {
            File[] listFiles = a().listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    String path = file.getPath();
                    if (this.d.containsValue(path)) {
                        AppboyLogger.d(a, "Asset " + path + " is not obsolete. Not deleting.");
                    } else if (!this.e.containsValue(path)) {
                        AppboyLogger.d(a, "Deleting obsolete asset " + path + " from filesystem.");
                        AppboyFileUtils.deleteFileOrDirectory(file);
                    } else {
                        AppboyLogger.d(a, "Asset " + path + " is being preserved. Not deleting.");
                    }
                }
            }
        } catch (Exception e2) {
            AppboyLogger.d(a, "Exception while deleting obsolete assets from filesystem.", (Throwable) e2);
        }
    }

    private static void a(Set<String> set, SharedPreferences.Editor editor, Map<String, String> map, Map<String, String> map2) {
        for (String str : new HashSet(map.keySet())) {
            if (map2.containsKey(str)) {
                String str2 = a;
                AppboyLogger.d(str2, "Not removing local path for remote path " + str + " from cache because it is being preserved until the end of the app run.");
            } else if (!set.contains(str)) {
                String str3 = map.get(str);
                map.remove(str);
                editor.remove(str);
                if (!StringUtils.isNullOrBlank(str3)) {
                    String str4 = a;
                    AppboyLogger.d(str4, "Removing obsolete local path " + str3 + " for obsolete remote path " + str + " from cache.");
                    AppboyFileUtils.deleteFileOrDirectory(new File(str3));
                }
            }
        }
        editor.apply();
    }

    private static void a(List<et> list, Set<gj> set, Set<String> set2) {
        for (et next : list) {
            gj d2 = next.d();
            if (d2 != null && !StringUtils.isNullOrBlank(d2.b())) {
                if (next.a()) {
                    String str = a;
                    AppboyLogger.d(str, "Received new remote path for triggered action " + next.b() + " at " + d2.b() + ".");
                    set.add(d2);
                    set2.add(d2.b());
                } else {
                    String str2 = a;
                    AppboyLogger.d(str2, "Pre-fetch off for triggered action " + next.b() + ". Not pre-fetching assets at remote path " + d2.b() + ".");
                }
            }
        }
    }
}
