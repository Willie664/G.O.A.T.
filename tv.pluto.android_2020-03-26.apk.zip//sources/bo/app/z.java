package bo.app;

public enum z {
    OPEN_SESSION,
    NO_SESSION
}
