package bo.app;

public final class ap {
    private final df a;

    public ap(df dfVar) {
        this.a = dfVar;
    }
}
