package bo.app;

import com.appboy.models.InAppMessageBase;
import org.json.JSONException;
import org.json.JSONObject;

public final class fc implements fa {
    public boolean a(ft ftVar) {
        return ftVar instanceof fw;
    }

    /* renamed from: a */
    public JSONObject forJsonPut() {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(InAppMessageBase.TYPE, "open");
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }
}
