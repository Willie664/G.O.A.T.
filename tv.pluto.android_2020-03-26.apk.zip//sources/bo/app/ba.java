package bo.app;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public final class ba extends ay {
    public ba(String str, ThreadFactory threadFactory) {
        super(str, er.a(), er.b(), er.c(), TimeUnit.SECONDS, er.d(), threadFactory);
    }
}
