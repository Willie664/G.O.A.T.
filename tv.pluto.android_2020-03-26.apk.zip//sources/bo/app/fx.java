package bo.app;

import com.appboy.models.outgoing.AppboyProperties;

public class fx extends gb {
    private String a;

    public String b() {
        return "purchase";
    }

    public fx(String str, AppboyProperties appboyProperties, cc ccVar) {
        super(appboyProperties, ccVar);
        this.a = str;
    }

    public String a() {
        return this.a;
    }
}
