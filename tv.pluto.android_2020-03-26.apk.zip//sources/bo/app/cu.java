package bo.app;

public interface cu {
    String a();
}
