package bo.app;

import com.appboy.support.AppboyLogger;
import com.appnexus.opensdk.ut.UTConstants;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;
import org.json.JSONObject;

public final class f implements g {
    private static final String a = AppboyLogger.getAppboyLogTag(f.class);
    private static final int b = ((int) TimeUnit.SECONDS.toMillis(15));
    private final int c;

    public f(int i) {
        this.c = i;
    }

    public JSONObject a(URI uri, Map<String, String> map) {
        return a(uri, (JSONObject) null, map, x.GET);
    }

    public JSONObject a(URI uri, Map<String, String> map, JSONObject jSONObject) {
        return a(uri, jSONObject, map, x.POST);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v11, resolved type: java.net.HttpURLConnection} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: java.io.InputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v16, resolved type: java.net.HttpURLConnection} */
    /* JADX WARNING: type inference failed for: r9v1, types: [java.net.HttpURLConnection] */
    /* JADX WARNING: type inference failed for: r9v4 */
    /* JADX WARNING: type inference failed for: r9v10 */
    /* JADX WARNING: type inference failed for: r9v18 */
    /* JADX WARNING: type inference failed for: r9v20 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00a7  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ac A[SYNTHETIC, Splitter:B:44:0x00ac] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x010c A[SYNTHETIC, Splitter:B:62:0x010c] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private org.json.JSONObject a(java.net.URI r8, org.json.JSONObject r9, java.util.Map<java.lang.String, java.lang.String> r10, bo.app.x r11) {
        /*
            r7 = this;
            java.lang.String r0 = "]"
            java.lang.String r1 = "Caught an error trying to close an InputStream"
            r2 = 1337(0x539, float:1.874E-42)
            android.net.TrafficStats.setThreadStatsTag(r2)
            java.net.URL r8 = bo.app.el.a((java.net.URI) r8)
            r2 = 0
            if (r8 != 0) goto L_0x0018
            java.lang.String r8 = a
            java.lang.String r9 = "Got null URL after converting Uri to URL. Ending request."
            com.appboy.support.AppboyLogger.w((java.lang.String) r8, (java.lang.String) r9)
            return r2
        L_0x0018:
            java.net.HttpURLConnection r9 = r7.a((java.net.URL) r8, (org.json.JSONObject) r9, (java.util.Map<java.lang.String, java.lang.String>) r10, (bo.app.x) r11)     // Catch:{ IOException -> 0x00d5, JSONException -> 0x0089, all -> 0x0085 }
            if (r9 != 0) goto L_0x0041
            java.lang.String r10 = a     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            r11.<init>()     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            java.lang.String r3 = "Failed to setup connection to ["
            r11.append(r3)     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            java.lang.String r3 = r8.toString()     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            r11.append(r3)     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            r11.append(r0)     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            java.lang.String r11 = r11.toString()     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            com.appboy.support.AppboyLogger.w((java.lang.String) r10, (java.lang.String) r11)     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            if (r9 == 0) goto L_0x0040
            r9.disconnect()
        L_0x0040:
            return r2
        L_0x0041:
            java.io.InputStream r10 = r7.a((java.net.HttpURLConnection) r9)     // Catch:{ IOException -> 0x0080, JSONException -> 0x007d, all -> 0x007a }
            java.io.BufferedReader r11 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            java.lang.String r4 = "UTF-8"
            r3.<init>(r10, r4)     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            r11.<init>(r3)     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            java.lang.String r11 = a((java.io.BufferedReader) r11)     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            r3.<init>(r11)     // Catch:{ IOException -> 0x0075, JSONException -> 0x0070, all -> 0x006c }
            if (r9 == 0) goto L_0x005f
            r9.disconnect()
        L_0x005f:
            if (r10 == 0) goto L_0x006b
            r10.close()     // Catch:{ Exception -> 0x0065 }
            goto L_0x006b
        L_0x0065:
            r8 = move-exception
            java.lang.String r9 = a
            com.appboy.support.AppboyLogger.e(r9, r1, r8)
        L_0x006b:
            return r3
        L_0x006c:
            r8 = move-exception
            r2 = r10
            goto L_0x0105
        L_0x0070:
            r11 = move-exception
            r6 = r11
            r11 = r10
            r10 = r6
            goto L_0x008c
        L_0x0075:
            r11 = move-exception
            r2 = r9
            r9 = r10
            r10 = r11
            goto L_0x00d7
        L_0x007a:
            r8 = move-exception
            goto L_0x0105
        L_0x007d:
            r10 = move-exception
            r11 = r2
            goto L_0x008c
        L_0x0080:
            r10 = move-exception
            r6 = r2
            r2 = r9
            r9 = r6
            goto L_0x00d7
        L_0x0085:
            r8 = move-exception
            r9 = r2
            goto L_0x0105
        L_0x0089:
            r10 = move-exception
            r9 = r2
            r11 = r9
        L_0x008c:
            java.lang.String r3 = a     // Catch:{ all -> 0x00d2 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00d2 }
            r4.<init>()     // Catch:{ all -> 0x00d2 }
            java.lang.String r5 = "Unable to parse json response from server. Response: ["
            r4.append(r5)     // Catch:{ all -> 0x00d2 }
            r4.append(r10)     // Catch:{ all -> 0x00d2 }
            r4.append(r0)     // Catch:{ all -> 0x00d2 }
            java.lang.String r0 = r4.toString()     // Catch:{ all -> 0x00d2 }
            com.appboy.support.AppboyLogger.e(r3, r0, r10)     // Catch:{ all -> 0x00d2 }
            if (r9 == 0) goto L_0x00aa
            r9.disconnect()
        L_0x00aa:
            if (r11 == 0) goto L_0x00b6
            r11.close()     // Catch:{ Exception -> 0x00b0 }
            goto L_0x00b6
        L_0x00b0:
            r9 = move-exception
            java.lang.String r10 = a
            com.appboy.support.AppboyLogger.e(r10, r1, r9)
        L_0x00b6:
            java.lang.String r9 = a
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "Failed to get result from ["
            r10.append(r11)
            r10.append(r8)
            java.lang.String r8 = "]."
            r10.append(r8)
            java.lang.String r8 = r10.toString()
            com.appboy.support.AppboyLogger.w((java.lang.String) r9, (java.lang.String) r8)
            return r2
        L_0x00d2:
            r8 = move-exception
            r2 = r11
            goto L_0x0105
        L_0x00d5:
            r10 = move-exception
            r9 = r2
        L_0x00d7:
            bo.app.av r11 = new bo.app.av     // Catch:{ all -> 0x0101 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0101 }
            r3.<init>()     // Catch:{ all -> 0x0101 }
            java.lang.String r4 = "Failed request to ["
            r3.append(r4)     // Catch:{ all -> 0x0101 }
            java.lang.String r8 = r8.toString()     // Catch:{ all -> 0x0101 }
            r3.append(r8)     // Catch:{ all -> 0x0101 }
            java.lang.String r8 = "], with message: ["
            r3.append(r8)     // Catch:{ all -> 0x0101 }
            java.lang.String r8 = r10.getMessage()     // Catch:{ all -> 0x0101 }
            r3.append(r8)     // Catch:{ all -> 0x0101 }
            r3.append(r0)     // Catch:{ all -> 0x0101 }
            java.lang.String r8 = r3.toString()     // Catch:{ all -> 0x0101 }
            r11.<init>(r8, r10)     // Catch:{ all -> 0x0101 }
            throw r11     // Catch:{ all -> 0x0101 }
        L_0x0101:
            r8 = move-exception
            r6 = r2
            r2 = r9
            r9 = r6
        L_0x0105:
            if (r9 == 0) goto L_0x010a
            r9.disconnect()
        L_0x010a:
            if (r2 == 0) goto L_0x0116
            r2.close()     // Catch:{ Exception -> 0x0110 }
            goto L_0x0116
        L_0x0110:
            r9 = move-exception
            java.lang.String r10 = a
            com.appboy.support.AppboyLogger.e(r10, r1, r9)
        L_0x0116:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.f.a(java.net.URI, org.json.JSONObject, java.util.Map, bo.app.x):org.json.JSONObject");
    }

    private InputStream a(HttpURLConnection httpURLConnection) {
        httpURLConnection.connect();
        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode / 100 != 2) {
            throw new av("Bad HTTP response code from Braze: [" + responseCode + "] to url: " + httpURLConnection.getURL());
        } else if ("gzip".equalsIgnoreCase(httpURLConnection.getContentEncoding())) {
            return new GZIPInputStream(httpURLConnection.getInputStream());
        } else {
            return new BufferedInputStream(httpURLConnection.getInputStream());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0061  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.net.HttpURLConnection a(java.net.URL r3, org.json.JSONObject r4, java.util.Map<java.lang.String, java.lang.String> r5, bo.app.x r6) {
        /*
            r2 = this;
            r0 = 0
            java.net.URLConnection r1 = bo.app.k.a(r3)     // Catch:{ IOException -> 0x0032 }
            java.net.HttpURLConnection r1 = (java.net.HttpURLConnection) r1     // Catch:{ IOException -> 0x0032 }
            int r0 = b     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            r1.setConnectTimeout(r0)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            int r0 = r2.c     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            r1.setReadTimeout(r0)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            r0 = 0
            r1.setUseCaches(r0)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            r1.setInstanceFollowRedirects(r0)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            java.lang.String r0 = r6.toString()     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            r1.setRequestMethod(r0)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            a((java.net.HttpURLConnection) r1, (java.util.Map<java.lang.String, java.lang.String>) r5)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            bo.app.x r5 = bo.app.x.POST     // Catch:{ IOException -> 0x002d, all -> 0x002a }
            if (r6 != r5) goto L_0x0029
            a((java.net.HttpURLConnection) r1, (org.json.JSONObject) r4)     // Catch:{ IOException -> 0x002d, all -> 0x002a }
        L_0x0029:
            return r1
        L_0x002a:
            r3 = move-exception
            r0 = r1
            goto L_0x005f
        L_0x002d:
            r4 = move-exception
            r0 = r1
            goto L_0x0033
        L_0x0030:
            r3 = move-exception
            goto L_0x005f
        L_0x0032:
            r4 = move-exception
        L_0x0033:
            bo.app.av r5 = new bo.app.av     // Catch:{ all -> 0x0030 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ all -> 0x0030 }
            r6.<init>()     // Catch:{ all -> 0x0030 }
            java.lang.String r1 = "Could not set up connection ["
            r6.append(r1)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0030 }
            r6.append(r3)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "] ["
            r6.append(r3)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = r4.getMessage()     // Catch:{ all -> 0x0030 }
            r6.append(r3)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = "].  Braze will try to reconnect periodically."
            r6.append(r3)     // Catch:{ all -> 0x0030 }
            java.lang.String r3 = r6.toString()     // Catch:{ all -> 0x0030 }
            r5.<init>(r3, r4)     // Catch:{ all -> 0x0030 }
            throw r5     // Catch:{ all -> 0x0030 }
        L_0x005f:
            if (r0 == 0) goto L_0x0064
            r0.disconnect()
        L_0x0064:
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.f.a(java.net.URL, org.json.JSONObject, java.util.Map, bo.app.x):java.net.HttpURLConnection");
    }

    static void a(HttpURLConnection httpURLConnection, Map<String, String> map) {
        for (Map.Entry next : map.entrySet()) {
            httpURLConnection.setRequestProperty((String) next.getKey(), (String) next.getValue());
        }
    }

    private static void a(HttpURLConnection httpURLConnection, JSONObject jSONObject) {
        byte[] bytes = jSONObject.toString().getBytes(UTConstants.UTF_8);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setFixedLengthStreamingMode(bytes.length);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
        bufferedOutputStream.write(bytes);
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
    }

    private static String a(BufferedReader bufferedReader) {
        StringBuilder sb = new StringBuilder();
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                return sb.toString();
            }
            sb.append(readLine);
        }
    }
}
