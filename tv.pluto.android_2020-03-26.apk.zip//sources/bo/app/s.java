package bo.app;

import android.content.Intent;
import android.net.ConnectivityManager;

public interface s {
    y a();

    void a(Intent intent, ConnectivityManager connectivityManager);
}
