package bo.app;

import com.appboy.models.InAppMessageBase;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class ex implements fa {
    private String a;

    public ex(JSONObject jSONObject) {
        this.a = jSONObject.getJSONObject("data").getString("event_name");
    }

    public boolean a(ft ftVar) {
        if (!(ftVar instanceof fs)) {
            return false;
        }
        fs fsVar = (fs) ftVar;
        return !StringUtils.isNullOrBlank(fsVar.a()) && fsVar.a().equals(this.a);
    }

    /* renamed from: a */
    public JSONObject forJsonPut() {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(InAppMessageBase.TYPE, "custom_event");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("event_name", this.a);
            jSONObject.put("data", jSONObject2);
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }
}
