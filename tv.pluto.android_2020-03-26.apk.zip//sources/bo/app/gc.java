package bo.app;

public interface gc extends ge {
    String a(et etVar);
}
