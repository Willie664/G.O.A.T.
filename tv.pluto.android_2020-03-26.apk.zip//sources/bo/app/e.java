package bo.app;

import java.util.concurrent.TimeUnit;

public class e {
    private static final int a = ((int) TimeUnit.SECONDS.toMillis(5));

    public static g a(int i) {
        return new h(new j(new f(i)));
    }

    public static g a() {
        return a(a);
    }
}
