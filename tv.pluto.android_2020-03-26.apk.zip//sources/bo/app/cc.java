package bo.app;

import com.appboy.models.IPutIntoJson;
import org.json.JSONObject;

public interface cc extends IPutIntoJson<JSONObject> {
    double a();

    void a(cg cgVar);

    void a(String str);

    v b();

    JSONObject c();

    String d();

    String e();

    String f();

    cg g();

    boolean h();
}
