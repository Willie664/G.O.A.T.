package bo.app;

public interface dx {
    cf a();

    void a(cf cfVar);

    void b(cf cfVar);
}
