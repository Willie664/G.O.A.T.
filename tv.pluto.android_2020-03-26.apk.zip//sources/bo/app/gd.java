package bo.app;

public interface gd extends ge {
    void a(long j);

    void a(ft ftVar);

    void a(ft ftVar, et etVar);
}
