package bo.app;

public interface ce {
    boolean b();
}
