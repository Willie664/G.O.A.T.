package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public abstract class ay extends ThreadPoolExecutor {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(ay.class);
    private bt b;
    /* access modifiers changed from: private */
    public List<Runnable> c = new CopyOnWriteArrayList();
    /* access modifiers changed from: private */
    public Map<Runnable, Thread> d = new HashMap();
    /* access modifiers changed from: private */
    public String e;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ay(String str, int i, int i2, long j, TimeUnit timeUnit, BlockingQueue<Runnable> blockingQueue, ThreadFactory threadFactory) {
        super(i, i2, j, timeUnit, blockingQueue, threadFactory);
        this.e = str;
        setRejectedExecutionHandler(new a());
    }

    /* access modifiers changed from: protected */
    public void beforeExecute(Thread thread, Runnable runnable) {
        this.c.add(runnable);
        this.d.put(runnable, thread);
        super.beforeExecute(thread, runnable);
    }

    /* access modifiers changed from: protected */
    public void afterExecute(Runnable runnable, Throwable th) {
        this.c.remove(runnable);
        this.d.remove(runnable);
        super.afterExecute(runnable, th);
    }

    public void a(bt btVar) {
        this.b = btVar;
    }

    /* access modifiers changed from: private */
    public void a(Exception exc) {
        String str = a;
        AppboyLogger.e(str, "Attempting to publish exception. ID: " + this.e, exc);
        bt btVar = this.b;
        if (btVar != null) {
            btVar.b((Throwable) exc);
        }
    }

    /* access modifiers changed from: private */
    public String b() {
        try {
            if (this.c.size() != getActiveCount()) {
                String str = a;
                AppboyLogger.d(str, "Running task count does not match ThreadPoolExecutor active count. Returning null description.  runningTasks.size(): " + this.c.size() + " getActiveCount(): " + getActiveCount() + " ID: " + this.e);
                return null;
            }
            StringBuilder sb = new StringBuilder(1024);
            sb.append("There are ");
            sb.append(this.c.size());
            sb.append(" known running tasks. Active thread dumps: [\n");
            for (Thread next : this.d.values()) {
                try {
                    sb.append(a(next.getStackTrace()));
                    sb.append("\n,");
                } catch (Exception e2) {
                    String str2 = a;
                    AppboyLogger.e(str2, "Failed to create description for active thread: " + next + " ID: " + this.e, e2);
                }
            }
            sb.append("]\nExecutor ID: ");
            sb.append(this.e);
            sb.append(" state: ");
            sb.append(toString());
            return sb.toString();
        } catch (Exception e3) {
            String str3 = a;
            AppboyLogger.e(str3, "Failed to create running tasks description. ID: " + this.e, e3);
            return null;
        }
    }

    private static String a(StackTraceElement[] stackTraceElementArr) {
        if (stackTraceElementArr.length == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement append : stackTraceElementArr) {
            sb.append("\nat ");
            sb.append(append);
        }
        return sb.toString();
    }

    class a implements RejectedExecutionHandler {
        private a() {
        }

        public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
            String a2 = ay.a;
            AppboyLogger.d(a2, "Rejected execution on runnable: " + runnable + " . ID: " + ay.this.e);
            if (threadPoolExecutor.isShutdown() || threadPoolExecutor.isTerminating()) {
                String a3 = ay.a;
                AppboyLogger.i(a3, "ThreadPoolExecutor is shutdown. Dropping rejected task. ID: " + ay.this.e);
                return;
            }
            String b = ay.this.b();
            try {
                if (!ay.this.c.isEmpty()) {
                    Runnable runnable2 = (Runnable) ay.this.c.get(0);
                    if (runnable2 instanceof Future) {
                        ((Future) runnable2).cancel(true);
                    } else {
                        Thread thread = (Thread) ay.this.d.get(runnable2);
                        if (thread != null) {
                            thread.interrupt();
                        }
                    }
                    ay.this.c.remove(runnable2);
                    ay.this.d.remove(runnable2);
                }
                Runnable runnable3 = (Runnable) threadPoolExecutor.getQueue().poll();
                if (runnable3 != null) {
                    String a4 = ay.a;
                    AppboyLogger.v(a4, "Running head of queue on caller thread: " + runnable3 + " . ID: " + ay.this.e);
                    Executors.newSingleThreadExecutor().invokeAll(Collections.singletonList(Executors.callable(runnable3)), 200, TimeUnit.MILLISECONDS);
                }
                String a5 = ay.a;
                AppboyLogger.v(a5, "Re-adding rejected task to queue: " + runnable + " . ID: " + ay.this.e);
                threadPoolExecutor.execute(runnable);
            } catch (Exception e) {
                String a6 = ay.a;
                AppboyLogger.d(a6, "Caught exception in rejected execution handler for incoming task: " + runnable + " . Running tasks description: " + b, (Throwable) e);
            }
            if (b != null) {
                ay ayVar = ay.this;
                ayVar.a(new Exception("Handled rejected execution on incoming task: " + b));
            }
        }
    }
}
