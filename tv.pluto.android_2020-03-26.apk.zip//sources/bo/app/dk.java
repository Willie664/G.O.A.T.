package bo.app;

import android.net.Uri;
import bo.app.cl;
import com.appboy.enums.inappmessage.InAppMessageFailureType;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class dk extends cx {
    /* access modifiers changed from: private */
    public static final String b = AppboyLogger.getAppboyLogTag(dk.class);
    private final String c;
    private final long d;
    private final String e;
    private final ft f;
    private final ev g;
    private final cl h;
    /* access modifiers changed from: private */
    public final bt i;
    private final dm j = p();
    private final long k = a(this.g.c());

    public boolean i() {
        return false;
    }

    public dk(String str, ev evVar, ft ftVar, bt btVar, String str2) {
        super(Uri.parse(str + "template"), (Map<String, String>) null);
        this.c = evVar.h();
        this.d = evVar.g();
        this.e = evVar.i();
        this.f = ftVar;
        this.h = new cl.a().a(str2).c();
        this.i = btVar;
        this.g = evVar;
    }

    public x j() {
        return x.POST;
    }

    public void a(ac acVar, cs csVar) {
        this.j.a();
        if (csVar == null || !csVar.b()) {
            n();
        } else if (!StringUtils.isNullOrBlank(this.e)) {
            csVar.i().setLocalAssetPathForPrefetch(this.e);
        }
    }

    public void a(ac acVar, ac acVar2, cu cuVar) {
        super.a(acVar, acVar2, cuVar);
        n();
        if (cuVar instanceof cr) {
            acVar.a(new at(this.f, this.g), at.class);
        } else if (cuVar instanceof cv) {
            AppboyLogger.v(b, "Response error was a server failure. Retrying request after some delay if not expired.");
            long d2 = this.f.d() + this.k;
            if (ee.c() < d2) {
                int c2 = this.j.c();
                String str = b;
                AppboyLogger.d(str, "Retrying template request after delay of " + c2 + " ms");
                ek.a().postDelayed(new Runnable() {
                    public void run() {
                        AppboyLogger.d(dk.b, "Adding request to dispatch");
                        dk.this.i.a(this);
                    }
                }, (long) c2);
                return;
            }
            String str2 = b;
            AppboyLogger.d(str2, "Template request expired at time: " + d2 + " and is not eligible for a backoff response. Not retrying or performing any fallback triggers");
        }
    }

    public long l() {
        return this.d;
    }

    public JSONObject h() {
        JSONObject h2 = super.h();
        if (h2 == null) {
            return null;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("trigger_id", this.c);
            jSONObject.put("trigger_event_type", this.f.b());
            if (this.f.e() != null) {
                jSONObject.put("data", this.f.e().forJsonPut());
            }
            h2.put("template", jSONObject);
            if (this.h.f()) {
                h2.put("respond_with", this.h.forJsonPut());
            }
            return h2;
        } catch (JSONException e2) {
            AppboyLogger.w(b, "Experienced JSONException while retrieving parameters. Returning null.", e2);
            return null;
        }
    }

    public et m() {
        return this.g;
    }

    /* access modifiers changed from: package-private */
    public void n() {
        AppboyLogger.i(b, "Template request failed. Attempting to log in-app message template request failure.");
        if (StringUtils.isNullOrBlank(this.c)) {
            AppboyLogger.d(b, "Trigger ID not found. Not logging in-app message template request failure.");
        } else if (this.i == null) {
            AppboyLogger.e(b, "Cannot log an in-app message template request failure because the IAppboyManager is null.");
        } else {
            try {
                this.i.a((cc) cn.a((String) null, this.c, InAppMessageFailureType.TEMPLATE_REQUEST));
            } catch (JSONException e2) {
                this.i.a((Throwable) e2);
            }
        }
    }

    private dm p() {
        return new dm((int) Math.min(this.k, TimeUnit.MINUTES.toMillis(1)), (int) TimeUnit.SECONDS.toMillis(1));
    }

    private long a(fn fnVar) {
        if (fnVar.e() == -1) {
            return TimeUnit.SECONDS.toMillis((long) (fnVar.d() + 30));
        }
        return (long) fnVar.e();
    }
}
