package bo.app;

import com.appboy.support.AppboyLogger;

public class dt implements dx {
    private static final String a = AppboyLogger.getAppboyLogTag(dt.class);
    private final dx b;
    private final ac c;

    public dt(dx dxVar, ac acVar) {
        this.b = dxVar;
        this.c = acVar;
    }

    public void a(cf cfVar) {
        try {
            this.b.a(cfVar);
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to upsert active session in the storage.", e);
            a(this.c, e);
        }
    }

    public cf a() {
        try {
            return this.b.a();
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to get the active session from the storage.", e);
            a(this.c, e);
            return null;
        }
    }

    public void b(cf cfVar) {
        try {
            this.b.b(cfVar);
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to delete the sealed session from the storage.", e);
            a(this.c, e);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(ac acVar, Throwable th) {
        try {
            acVar.a(new aw("A storage exception has occurred. Please view the stack trace for more details.", th), aw.class);
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to log throwable.", e);
        }
    }
}
