package bo.app;

import com.appboy.models.outgoing.AppboyProperties;

public abstract class gb extends ga implements fu {
    private AppboyProperties a;

    protected gb(AppboyProperties appboyProperties, cc ccVar) {
        super(ccVar);
        this.a = appboyProperties;
    }

    public AppboyProperties f() {
        return this.a;
    }
}
