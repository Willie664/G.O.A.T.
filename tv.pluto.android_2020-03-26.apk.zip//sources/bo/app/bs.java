package bo.app;

public interface bs {
    void c(boolean z);
}
