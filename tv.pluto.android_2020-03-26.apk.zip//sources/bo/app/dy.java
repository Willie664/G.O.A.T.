package bo.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.appboy.models.InAppMessageBase;
import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONException;

@Deprecated
public class dy implements dv {
    private static final String a = AppboyLogger.getAppboyLogTag(dy.class);
    private static final String[] b = {"session_id", "user_id", "event_type", "event_data", "event_guid", "timestamp"};
    private SQLiteDatabase c;
    private boolean d = false;
    private final Cdo e;

    public dy(Cdo doVar) {
        this.e = doVar;
    }

    public synchronized SQLiteDatabase c() {
        if (this.c == null || !this.c.isOpen()) {
            this.c = this.e.getWritableDatabase();
        }
        return this.c;
    }

    public void a(cc ccVar) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding event: " + ccVar);
            return;
        }
        if (c().insert("ab_events", (String) null, b(ccVar)) == -1) {
            String str2 = a;
            AppboyLogger.w(str2, "Failed to add event [" + ccVar.toString() + "] to storage");
        }
    }

    public void a(List<cc> list) {
        throw new UnsupportedOperationException("Batch SQL event add is not supported");
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [java.util.Collection<bo.app.cc>, android.database.Cursor] */
    public Collection<cc> a() {
        Cursor cursor = 0;
        if (this.d) {
            AppboyLogger.w(a, "Storage provider is closed. Not getting all events.");
            return cursor;
        }
        try {
            cursor = c().query("ab_events", b, (String) null, (String[]) null, (String) null, (String) null, (String) null);
            return a(cursor);
        } finally {
            if (cursor != 0) {
                cursor.close();
            }
        }
    }

    public void b(List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not deleting events: " + list);
            return;
        }
        AppboyLogger.d(a, "Running batch deletion for SQL table.");
        if (list.size() > 999) {
            b(list.subList(InAppMessageBase.INAPP_MESSAGE_DURATION_MIN_MILLIS, list.size()));
            list = list.subList(0, InAppMessageBase.INAPP_MESSAGE_DURATION_MIN_MILLIS);
        }
        c().beginTransaction();
        try {
            StringBuilder sb = new StringBuilder("event_guid");
            sb.append(" in (");
            String[] strArr = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                strArr[i] = list.get(i).d();
                sb.append('?');
                if (i < list.size() - 1) {
                    sb.append(',');
                }
            }
            sb.append(')');
            int delete = c().delete("ab_events", sb.toString(), strArr);
            String str2 = a;
            AppboyLogger.d(str2, "Deleting events removed " + delete + " row(s).", false);
            c().setTransactionSuccessful();
        } finally {
            c().endTransaction();
        }
    }

    public void b() {
        AppboyLogger.w(a, "Closing SQL database and setting this provider to closed.");
        this.d = true;
        c().close();
    }

    private ContentValues b(cc ccVar) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("event_type", ccVar.b().forJsonPut());
        contentValues.put("event_data", ccVar.c().toString());
        contentValues.put("timestamp", Double.valueOf(ccVar.a()));
        if (ccVar.g() != null) {
            contentValues.put("session_id", ccVar.g().toString());
        }
        if (ccVar.f() != null) {
            contentValues.put("user_id", ccVar.f());
        }
        if (ccVar.d() != null) {
            contentValues.put("event_guid", ccVar.d());
        }
        return contentValues;
    }

    private Collection<cc> a(Cursor cursor) {
        Cursor cursor2 = cursor;
        ArrayList arrayList = new ArrayList();
        int columnIndex = cursor2.getColumnIndex("session_id");
        int columnIndex2 = cursor2.getColumnIndex("user_id");
        int columnIndex3 = cursor2.getColumnIndex("event_type");
        int columnIndex4 = cursor2.getColumnIndex("event_data");
        int columnIndex5 = cursor2.getColumnIndex("event_guid");
        int columnIndex6 = cursor2.getColumnIndex("timestamp");
        while (cursor.moveToNext()) {
            String string = cursor2.getString(columnIndex3);
            String string2 = cursor2.getString(columnIndex4);
            double d2 = cursor2.getDouble(columnIndex6);
            String string3 = cursor2.getString(columnIndex5);
            String string4 = cursor2.getString(columnIndex2);
            String str = string;
            String string5 = cursor2.getString(columnIndex);
            String str2 = string3;
            String str3 = string4;
            int i = columnIndex;
            int i2 = columnIndex2;
            double d3 = d2;
            String str4 = string2;
            try {
                arrayList.add(cn.a(str, string2, d2, str2, str3, string5));
            } catch (JSONException unused) {
                String str5 = a;
                AppboyLogger.e(str5, "Could not create AppboyEvent from [type=" + string + ", data=" + str4 + ", timestamp=" + d3 + ", uniqueId=" + str2 + ", userId=" + str3 + ", sessionId=" + string5 + "] ... Skipping");
            }
            cursor2 = cursor;
            columnIndex = i;
            columnIndex2 = i2;
        }
        return arrayList;
    }
}
