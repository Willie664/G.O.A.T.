package bo.app;

import org.json.JSONArray;
import org.json.JSONObject;

public final class gp {
    private static gv a(gq gqVar) {
        return new gu(gqVar);
    }

    public static gr a(String str, String str2, gv gvVar) {
        Object a = gs.a(str);
        Object a2 = gs.a(str2);
        boolean z = a instanceof JSONObject;
        if (z && (a2 instanceof JSONObject)) {
            return a((JSONObject) a, (JSONObject) a2, gvVar);
        }
        if ((a instanceof JSONArray) && (a2 instanceof JSONArray)) {
            return a((JSONArray) a, (JSONArray) a2, gvVar);
        }
        if ((a instanceof gm) && (a2 instanceof gm)) {
            return a((gm) a, (gm) a2);
        }
        if (z) {
            return new gr().a("", a, a2);
        }
        return new gr().a("", a, a2);
    }

    public static gr a(JSONObject jSONObject, JSONObject jSONObject2, gv gvVar) {
        return gvVar.a(jSONObject, jSONObject2);
    }

    public static gr a(JSONArray jSONArray, JSONArray jSONArray2, gv gvVar) {
        return gvVar.a(jSONArray, jSONArray2);
    }

    public static gr a(gm gmVar, gm gmVar2) {
        gr grVar = new gr();
        if (!gmVar.a().equals(gmVar2.a())) {
            grVar.a("");
        }
        return grVar;
    }

    public static gr a(String str, String str2, gq gqVar) {
        return a(str, str2, a(gqVar));
    }

    public static gr a(JSONObject jSONObject, JSONObject jSONObject2, gq gqVar) {
        return a(jSONObject, jSONObject2, a(gqVar));
    }
}
