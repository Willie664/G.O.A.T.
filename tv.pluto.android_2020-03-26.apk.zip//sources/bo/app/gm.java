package bo.app;

public interface gm {
    String a();
}
