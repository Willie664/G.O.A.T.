package bo.app;

import android.util.Base64;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import io.fabric.sdk.android.services.events.EventsFilesManager;

public abstract class ga implements ft {
    private static final String a = AppboyLogger.getAppboyLogTag(ga.class);
    private long b;
    private long c;
    private cc d;

    protected ga() {
        this.c = ee.c();
        this.b = this.c / 1000;
    }

    protected ga(cc ccVar) {
        this();
        this.d = ccVar;
    }

    public long c() {
        return this.b;
    }

    public long d() {
        return this.c;
    }

    public cc e() {
        return this.d;
    }

    /* access modifiers changed from: protected */
    public String a(String str) {
        if (StringUtils.isNullOrBlank(str)) {
            return null;
        }
        try {
            return new String(Base64.decode(str, 0)).split(EventsFilesManager.ROLL_OVER_FILE_NAME_SEPARATOR)[0];
        } catch (Exception e) {
            String str2 = a;
            AppboyLogger.e(str2, "Unexpected error decoding Base64 encoded campaign Id " + str, e);
            return null;
        }
    }
}
