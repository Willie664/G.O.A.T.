package bo.app;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public final class bb extends ay {
    private static final TimeUnit a = TimeUnit.MILLISECONDS;

    public bb(String str, ThreadFactory threadFactory) {
        super(str, 1, 1, 0, a, er.d(), threadFactory);
    }
}
