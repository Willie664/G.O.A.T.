package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;

public class by implements bx {
    private static final String b = AppboyLogger.getAppboyLogTag(by.class);
    final SharedPreferences a;
    private final AppboyConfigurationProvider c;

    public by(Context context, AppboyConfigurationProvider appboyConfigurationProvider) {
        this.c = appboyConfigurationProvider;
        this.a = context.getSharedPreferences("com.appboy.push_registration", 0);
    }

    public synchronized String a() {
        int versionCode;
        int i;
        if (!b() || !this.a.contains("version_code") || (versionCode = this.c.getVersionCode()) == (i = this.a.getInt("version_code", Integer.MIN_VALUE))) {
            if (this.a.contains("device_identifier")) {
                if (!bi.b().equals(this.a.getString("device_identifier", ""))) {
                    AppboyLogger.i(b, "Device identifier differs from saved device identifier. Returning null token.");
                    return null;
                }
            }
            return this.a.getString("registration_id", (String) null);
        }
        String str = b;
        AppboyLogger.v(str, "Stored push registration ID version code " + i + " does not match live version code " + versionCode + ". Not returning saved registration ID.");
        return null;
    }

    public synchronized void a(String str) {
        if (str != null) {
            SharedPreferences.Editor edit = this.a.edit();
            edit.putString("registration_id", str);
            edit.putInt("version_code", this.c.getVersionCode());
            edit.putString("device_identifier", bi.b());
            edit.apply();
        } else {
            throw new NullPointerException();
        }
    }

    private boolean b() {
        return this.c.isAdmMessagingRegistrationEnabled() || this.c.isFirebaseCloudMessagingRegistrationEnabled();
    }
}
