package bo.app;

import com.appboy.models.IPutIntoJson;

public class ch implements IPutIntoJson<String> {
    private final String a;

    public ch(String str) {
        this.a = str;
    }

    public String toString() {
        return this.a;
    }

    /* renamed from: a */
    public String forJsonPut() {
        return this.a;
    }
}
