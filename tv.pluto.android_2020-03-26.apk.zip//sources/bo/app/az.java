package bo.app;

import com.appboy.support.AppboyLogger;
import java.lang.Thread;

public class az implements Thread.UncaughtExceptionHandler {
    private static final String a = AppboyLogger.getAppboyLogTag(az.class);
    private ac b;

    public az() {
    }

    public az(ac acVar) {
        this.b = acVar;
    }

    public void a(ac acVar) {
        this.b = acVar;
    }

    public void uncaughtException(Thread thread, Throwable th) {
        try {
            if (this.b != null) {
                AppboyLogger.w(a, "Uncaught exception from thread. Publishing as Throwable event.", th);
                this.b.a(th, Throwable.class);
            }
        } catch (Exception e) {
            AppboyLogger.w(a, "Failed to log throwable.", e);
        }
    }
}
