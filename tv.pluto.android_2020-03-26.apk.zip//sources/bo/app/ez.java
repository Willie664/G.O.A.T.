package bo.app;

import com.appboy.models.IPutIntoJson;

public interface ez extends IPutIntoJson {
    boolean a(ft ftVar);
}
