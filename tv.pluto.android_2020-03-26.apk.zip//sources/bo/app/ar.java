package bo.app;

public final class ar {
    private cc a;
    private final String b;

    public ar(String str, cc ccVar) {
        this.b = str;
        this.a = ccVar;
    }

    public String a() {
        return this.b;
    }

    public cc b() {
        return this.a;
    }
}
