package bo.app;

import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.comscore.android.id.IdHelperAndroid;
import java.net.URI;
import java.util.ArrayList;
import java.util.Map;
import org.json.JSONObject;

final class h implements g {
    private static final String a = AppboyLogger.getAppboyLogTag(h.class);
    private final g b;

    public h(g gVar) {
        this.b = gVar;
    }

    public JSONObject a(URI uri, Map<String, String> map) {
        String a2 = el.a(uri, map, x.GET);
        a(uri, map, a2);
        JSONObject a3 = this.b.a(uri, map);
        a(a3, a2);
        return a3;
    }

    public JSONObject a(URI uri, Map<String, String> map, JSONObject jSONObject) {
        String a2 = el.a(uri, map, jSONObject, x.POST);
        a(uri, map, jSONObject, a2);
        JSONObject a3 = this.b.a(uri, map, jSONObject);
        a(a3, a2);
        return a3;
    }

    private void a(URI uri, Map<String, String> map, String str) {
        try {
            String str2 = a;
            AppboyLogger.d(str2, "Making request(id = " + str + ") to [" + uri.toString() + "] \nwith headers: [" + a(map) + "]");
        } catch (Exception e) {
            AppboyLogger.d(a, "Exception while logging request: ", (Throwable) e);
        }
    }

    private void a(URI uri, Map<String, String> map, JSONObject jSONObject, String str) {
        try {
            String str2 = a;
            AppboyLogger.d(str2, "Making request(id = " + str + ") to [" + uri.toString() + "] \nwith headers: [" + a(map) + "] \nand JSON parameters: \n[" + JsonUtils.getPrettyPrintedString(jSONObject) + "]");
        } catch (Exception e) {
            AppboyLogger.d(a, "Exception while logging request: ", (Throwable) e);
        }
    }

    private void a(JSONObject jSONObject, String str) {
        String str2;
        if (jSONObject == null) {
            str2 = IdHelperAndroid.NO_ID_AVAILABLE;
        } else {
            try {
                str2 = JsonUtils.getPrettyPrintedString(jSONObject);
            } catch (Exception e) {
                AppboyLogger.d(a, "Exception while logging result: ", (Throwable) e);
                return;
            }
        }
        String str3 = a;
        AppboyLogger.d(str3, "Result(id = " + str + ") \n[" + str2 + "]");
    }

    private String a(Map<String, String> map) {
        ArrayList<String> arrayList = new ArrayList<>();
        for (Map.Entry next : map.entrySet()) {
            arrayList.add("(" + ((String) next.getKey()) + " / " + ((String) next.getValue()) + ")");
        }
        StringBuilder sb = new StringBuilder();
        for (String append : arrayList) {
            sb.append(append);
            sb.append(", ");
        }
        if (sb.length() == 0) {
            return "";
        }
        return sb.substring(0, sb.length() - 2);
    }
}
