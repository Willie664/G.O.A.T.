package bo.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import com.appboy.Constants;
import com.appboy.events.IEventSubscriber;
import com.appboy.receivers.AppboyActionReceiver;
import com.appboy.support.AppboyLogger;
import java.util.concurrent.TimeUnit;

public class q {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(q.class);
    private final Context b;
    /* access modifiers changed from: private */
    public final s c;
    private final AlarmManager d;
    private final p e;
    private final BroadcastReceiver f;
    private final PendingIntent g;
    /* access modifiers changed from: private */
    public z h;
    /* access modifiers changed from: private */
    public long i;
    private boolean j;
    /* access modifiers changed from: private */
    public final dm k;
    private volatile boolean l = false;

    public q(Context context, final ac acVar, s sVar, AlarmManager alarmManager, p pVar, String str) {
        this.b = context;
        this.c = sVar;
        this.d = alarmManager;
        this.e = pVar;
        this.h = z.NO_SESSION;
        this.i = -1;
        this.k = new dm((int) TimeUnit.MINUTES.toMillis(5));
        this.g = PendingIntent.getBroadcast(this.b, str.hashCode(), new Intent(Constants.APPBOY_ACTION_RECEIVER_DATA_SYNC_INTENT_ACTION).setClass(context, AppboyActionReceiver.class), 134217728);
        this.f = new BroadcastReceiver() {
            public void onReceive(final Context context, final Intent intent) {
                final BroadcastReceiver.PendingResult goAsync = goAsync();
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            q.this.c.a(intent, (ConnectivityManager) context.getSystemService("connectivity"));
                            q.this.c();
                        } catch (Exception e) {
                            AppboyLogger.e(q.a, "Failed to process connectivity event.", e);
                            q.this.a(acVar, (Throwable) e);
                        }
                        goAsync.finish();
                    }
                }).start();
            }
        };
        AppboyLogger.d(a, "Registered broadcast filters");
    }

    public void a(ab abVar) {
        abVar.b(new IEventSubscriber<an>() {
            /* renamed from: a */
            public void trigger(an anVar) {
                z unused = q.this.h = z.OPEN_SESSION;
                q.this.c();
            }
        }, an.class);
        abVar.b(new IEventSubscriber<ao>() {
            /* renamed from: a */
            public void trigger(ao aoVar) {
                z unused = q.this.h = z.NO_SESSION;
                q.this.c();
            }
        }, ao.class);
        abVar.b(new IEventSubscriber<af>() {
            /* renamed from: a */
            public void trigger(af afVar) {
                q qVar = q.this;
                qVar.a(qVar.i + ((long) q.this.k.a((int) q.this.i)));
            }
        }, af.class);
        abVar.b(new IEventSubscriber<ag>() {
            /* renamed from: a */
            public void trigger(ag agVar) {
                if (q.this.k.b()) {
                    q.this.k.a();
                    String f = q.a;
                    AppboyLogger.d(f, "Received successful request flush. Default flush interval reset to " + q.this.i);
                    q qVar = q.this;
                    qVar.a(qVar.i);
                }
            }
        }, ag.class);
    }

    public synchronized void a(boolean z) {
        this.j = z;
        c();
        if (z) {
            b();
        } else {
            a();
        }
    }

    public synchronized boolean a() {
        if (this.l) {
            AppboyLogger.d(a, "The data sync policy is already running. Ignoring request.");
            return false;
        }
        AppboyLogger.d(a, "Data sync started");
        d();
        a(3000);
        this.l = true;
        return true;
    }

    public synchronized boolean b() {
        if (!this.l) {
            AppboyLogger.d(a, "The data sync policy is not running. Ignoring request.");
            return false;
        }
        AppboyLogger.d(a, "Data sync stopped");
        g();
        e();
        this.l = false;
        return true;
    }

    /* access modifiers changed from: protected */
    public void c() {
        long j2 = this.i;
        if (this.h == z.NO_SESSION || this.j) {
            this.i = -1;
        } else {
            int i2 = AnonymousClass6.a[this.c.a().ordinal()];
            if (i2 == 1) {
                this.i = -1;
            } else if (i2 == 2) {
                this.i = this.e.a();
            } else if (i2 == 3 || i2 == 4) {
                this.i = this.e.c();
            } else {
                this.i = this.e.b();
            }
        }
        long j3 = this.i;
        if (j2 != j3) {
            a(j3);
            String str = a;
            AppboyLogger.d(str, "Dispatch state has changed from " + j2 + " to " + this.i + ".");
        }
    }

    /* renamed from: bo.app.q$6  reason: invalid class name */
    static /* synthetic */ class AnonymousClass6 {
        static final /* synthetic */ int[] a = new int[y.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0014 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x002a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0035 */
        static {
            /*
                bo.app.y[] r0 = bo.app.y.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0014 }
                bo.app.y r1 = bo.app.y.NONE     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001f }
                bo.app.y r1 = bo.app.y.TWO_G     // Catch:{ NoSuchFieldError -> 0x001f }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x002a }
                bo.app.y r1 = bo.app.y.FOUR_G     // Catch:{ NoSuchFieldError -> 0x002a }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x002a }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0035 }
                bo.app.y r1 = bo.app.y.WIFI     // Catch:{ NoSuchFieldError -> 0x0035 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0035 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0035 }
            L_0x0035:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0040 }
                bo.app.y r1 = bo.app.y.THREE_G     // Catch:{ NoSuchFieldError -> 0x0040 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0040 }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0040 }
            L_0x0040:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: bo.app.q.AnonymousClass6.<clinit>():void");
        }
    }

    /* access modifiers changed from: protected */
    public void d() {
        this.b.registerReceiver(this.f, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    /* access modifiers changed from: protected */
    public void e() {
        this.b.unregisterReceiver(this.f);
    }

    private void a(long j2, long j3) {
        this.d.setInexactRepeating(1, j2, j3, this.g);
    }

    private void g() {
        PendingIntent pendingIntent = this.g;
        if (pendingIntent != null) {
            this.d.cancel(pendingIntent);
        }
    }

    /* access modifiers changed from: private */
    public void a(ac acVar, Throwable th) {
        try {
            acVar.a(th, Throwable.class);
        } catch (Exception e2) {
            AppboyLogger.e(a, "Failed to log throwable.", e2);
        }
    }

    /* access modifiers changed from: package-private */
    public void a(long j2) {
        if (this.d == null) {
            AppboyLogger.d(a, "Alarm manager was null. Ignoring request to reset it.");
        } else if (this.i <= 0) {
            AppboyLogger.d(a, "Cancelling alarm because delay value was not positive.");
            g();
        } else {
            a(ee.c() + j2, this.i);
        }
    }
}
