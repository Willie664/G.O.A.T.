package bo.app;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class er {
    private static final int a = Runtime.getRuntime().availableProcessors();
    private static final int b = Math.max(2, a - 1);

    public static int a() {
        return 2;
    }

    public static long c() {
        return 1;
    }

    public static int b() {
        return b;
    }

    public static BlockingQueue<Runnable> d() {
        return new LinkedBlockingQueue(64);
    }

    public static int e() {
        return a;
    }
}
