package bo.app;

import com.appboy.Constants;
import com.appboy.enums.inappmessage.InAppMessageFailureType;
import com.appboy.models.MessageButton;
import com.appboy.models.outgoing.AppboyProperties;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import com.appboy.ui.inappmessage.jsinterface.AppboyInAppMessageHtmlUserJavascriptInterface;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class cn implements cc {
    private static final String a = AppboyLogger.getAppboyLogTag(cn.class);
    private final v b;
    private final JSONObject c;
    private final double d;
    private final String e;
    private String f;
    private cg g;

    protected cn(v vVar, JSONObject jSONObject) {
        this(vVar, jSONObject, ee.b());
    }

    protected cn(v vVar, JSONObject jSONObject, double d2) {
        this(vVar, jSONObject, d2, UUID.randomUUID().toString());
    }

    protected cn(v vVar, JSONObject jSONObject, double d2, String str) {
        this.f = null;
        this.g = null;
        if (jSONObject == null) {
            throw new NullPointerException("Event data cannot be null");
        } else if (vVar.forJsonPut() != null) {
            this.b = vVar;
            this.c = jSONObject;
            this.d = d2;
            this.e = str;
        } else {
            throw new NullPointerException("Event type cannot be null");
        }
    }

    protected cn(v vVar, JSONObject jSONObject, double d2, String str, String str2, String str3) {
        this.f = null;
        this.g = null;
        if (jSONObject == null) {
            throw new NullPointerException("Event data cannot be null");
        } else if (vVar.forJsonPut() != null) {
            this.b = vVar;
            this.c = jSONObject;
            this.d = d2;
            this.e = str;
            this.f = str2;
            if (str3 != null) {
                this.g = cg.a(str3);
            }
        } else {
            throw new NullPointerException("Event type cannot be null");
        }
    }

    public static cn a(String str, AppboyProperties appboyProperties) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(Constants.APPBOY_PUSH_CUSTOM_NOTIFICATION_ID, StringUtils.checkNotNullOrEmpty(str));
        if (appboyProperties != null && appboyProperties.size() > 0) {
            jSONObject.put(Constants.APPBOY_PUSH_PRIORITY_KEY, appboyProperties.forJsonPut());
        }
        return new cn(v.CUSTOM_EVENT, jSONObject);
    }

    public static cn a(String str, String str2, BigDecimal bigDecimal, int i, AppboyProperties appboyProperties) {
        BigDecimal a2 = eo.a(bigDecimal);
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(com.appsflyer.share.Constants.URL_MEDIA_SOURCE, str);
        jSONObject.put(com.appsflyer.share.Constants.URL_CAMPAIGN, str2);
        jSONObject.put(Constants.APPBOY_PUSH_PRIORITY_KEY, a2.doubleValue());
        jSONObject.put("q", i);
        if (appboyProperties != null && appboyProperties.size() > 0) {
            jSONObject.put("pr", appboyProperties.forJsonPut());
        }
        return new cn(v.PURCHASE, jSONObject);
    }

    public static cn a(cd cdVar) {
        return new cn(v.LOCATION_RECORDED, (JSONObject) cdVar.forJsonPut());
    }

    public static cn a(Throwable th, cg cgVar, boolean z) {
        String str = a(th, cgVar) + "\n" + a(th);
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("e", str);
        if (!z) {
            jSONObject.put("nop", true);
        }
        return new cn(v.INTERNAL_ERROR, jSONObject);
    }

    public static cn a(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(Constants.APPBOY_PUSH_CONTENT_KEY, str);
        jSONObject.put("l", str2);
        return new cn(v.USER_ALIAS, jSONObject);
    }

    public static cn b(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.NEWS_FEED_CARD_IMPRESSION, jSONObject);
    }

    public static cn c(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.NEWS_FEED_CARD_CLICK, jSONObject);
    }

    public static cn d(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.CONTENT_CARDS_IMPRESSION, jSONObject);
    }

    public static cn e(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.CONTENT_CARDS_CONTROL_IMPRESSION, jSONObject);
    }

    public static cn f(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.CONTENT_CARDS_CLICK, jSONObject);
    }

    public static cn g(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(str);
        jSONObject.put("ids", jSONArray);
        return new cn(v.CONTENT_CARDS_DISMISS, jSONObject);
    }

    public static cn b(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("geo_id", str);
        jSONObject.put("event_type", str2);
        return new cn(v.GEOFENCE, jSONObject);
    }

    public static cn c(String str, String str2) {
        return new cn(v.INAPP_MESSAGE_CONTROL_IMPRESSION, f(str, str2));
    }

    public static cn d(String str, String str2) {
        return new cn(v.INAPP_MESSAGE_IMPRESSION, f(str, str2));
    }

    public static cn e(String str, String str2) {
        return new cn(v.INAPP_MESSAGE_CLICK, f(str, str2));
    }

    public static cn a(String str, String str2, MessageButton messageButton) {
        return new cn(v.INAPP_MESSAGE_BUTTON_CLICK, a(str, str2, a(messageButton), (InAppMessageFailureType) null));
    }

    public static cn a(String str, String str2, String str3) {
        return new cn(v.INAPP_MESSAGE_BUTTON_CLICK, a(str, str2, str3, (InAppMessageFailureType) null));
    }

    public static cn a(String str, String str2, InAppMessageFailureType inAppMessageFailureType) {
        return new cn(v.INAPP_MESSAGE_DISPLAY_FAILURE, b(str, str2, inAppMessageFailureType));
    }

    static JSONObject f(String str, String str2) {
        return a(str, str2, (String) null, (InAppMessageFailureType) null);
    }

    static JSONObject b(String str, String str2, InAppMessageFailureType inAppMessageFailureType) {
        return a(str, str2, (String) null, inAppMessageFailureType);
    }

    static JSONObject a(String str, String str2, String str3, InAppMessageFailureType inAppMessageFailureType) {
        JSONObject jSONObject = new JSONObject();
        if (!StringUtils.isNullOrEmpty(str)) {
            JSONArray jSONArray = new JSONArray();
            jSONArray.put(str);
            jSONObject.put("card_ids", jSONArray);
        }
        if (!StringUtils.isNullOrEmpty(str2)) {
            JSONArray jSONArray2 = new JSONArray();
            jSONArray2.put(str2);
            jSONObject.put("trigger_ids", jSONArray2);
        }
        if (!StringUtils.isNullOrEmpty(str3)) {
            jSONObject.put("bid", str3);
        }
        if (inAppMessageFailureType != null) {
            String forJsonPut = inAppMessageFailureType.forJsonPut();
            if (!StringUtils.isNullOrEmpty(forJsonPut)) {
                jSONObject.put("error_code", forJsonPut);
            }
        }
        return jSONObject;
    }

    public static String a(MessageButton messageButton) {
        if (messageButton != null) {
            return String.valueOf(messageButton.getId());
        }
        return null;
    }

    public static cn i() {
        return h("content_cards_displayed");
    }

    public static cn j() {
        return h("feed_displayed");
    }

    @Deprecated
    public static cn k() {
        return h("feedback_displayed");
    }

    public static cn h(String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(Constants.APPBOY_PUSH_CUSTOM_NOTIFICATION_ID, str);
        return new cn(v.INTERNAL, jSONObject);
    }

    public static cn a(String str, int i) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        jSONObject.put(AppboyInAppMessageHtmlUserJavascriptInterface.JS_BRIDGE_ATTRIBUTE_VALUE, i);
        return new cn(v.INCREMENT, jSONObject);
    }

    public static cn g(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        jSONObject.put(AppboyInAppMessageHtmlUserJavascriptInterface.JS_BRIDGE_ATTRIBUTE_VALUE, str2);
        return new cn(v.ADD_TO_CUSTOM_ATTRIBUTE_ARRAY, jSONObject);
    }

    public static cn h(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        jSONObject.put(AppboyInAppMessageHtmlUserJavascriptInterface.JS_BRIDGE_ATTRIBUTE_VALUE, str2);
        return new cn(v.REMOVE_FROM_CUSTOM_ATTRIBUTE_ARRAY, jSONObject);
    }

    public static cn a(String str, String[] strArr) {
        JSONArray jSONArray = strArr == null ? null : new JSONArray();
        if (strArr != null) {
            for (String put : strArr) {
                jSONArray.put(put);
            }
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        if (strArr == null) {
            jSONObject.put(AppboyInAppMessageHtmlUserJavascriptInterface.JS_BRIDGE_ATTRIBUTE_VALUE, JSONObject.NULL);
        } else {
            jSONObject.put(AppboyInAppMessageHtmlUserJavascriptInterface.JS_BRIDGE_ATTRIBUTE_VALUE, jSONArray);
        }
        return new cn(v.SET_CUSTOM_ATTRIBUTE_ARRAY, jSONObject);
    }

    public static cn l() {
        return new cn(v.SESSION_START, new JSONObject());
    }

    public static cn a(long j) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(Constants.APPBOY_PUSH_NOTIFICATION_SOUND_DEFAULT_VALUE, j);
        return new cn(v.SESSION_END, jSONObject);
    }

    public static cn i(String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("cid", str);
        return new cn(v.PUSH_DELIVERY, jSONObject);
    }

    public static cn a(String str, double d2, double d3) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        jSONObject.put("latitude", d2);
        jSONObject.put("longitude", d3);
        return new cn(v.LOCATION_CUSTOM_ATTRIBUTE_ADD, jSONObject);
    }

    public static cn j(String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("key", str);
        return new cn(v.LOCATION_CUSTOM_ATTRIBUTE_REMOVE, jSONObject);
    }

    public static cc i(String str, String str2) {
        JSONObject jSONObject = new JSONObject(str);
        String string = jSONObject.getString("name");
        v a2 = v.a(string);
        if (a2 != null) {
            return new cn(a2, jSONObject.getJSONObject("data"), jSONObject.getDouble("time"), str2, jSONObject.optString("user_id", (String) null), jSONObject.optString("session_id", (String) null));
        }
        throw new IllegalArgumentException("Cannot parse eventType " + string + ". Event json: " + jSONObject);
    }

    public static cn a(String str, String str2, double d2, String str3, String str4, String str5) {
        v a2 = v.a(str);
        if (a2 != null) {
            return new cn(a2, new JSONObject(str2), d2, str3, str4, str5);
        }
        throw new IllegalArgumentException("Cannot parse eventType " + str);
    }

    public v b() {
        return this.b;
    }

    public JSONObject c() {
        return this.c;
    }

    public double a() {
        return this.d;
    }

    public String e() {
        return forJsonPut().toString();
    }

    static String a(Throwable th, cg cgVar) {
        StringBuilder sb = new StringBuilder();
        String name = th.getClass().getName();
        sb.append("\nexception_class: ");
        sb.append(name);
        sb.append("\navailable_cpus: ");
        sb.append(er.e());
        if (cgVar != null) {
            sb.append("\nsession_id: ");
            sb.append(cgVar);
        }
        return sb.toString();
    }

    static String a(Throwable th) {
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        String obj = stringWriter.toString();
        return obj.length() > 5000 ? obj.substring(0, 5000) : obj;
    }

    public void a(cg cgVar) {
        if (this.g == null) {
            this.g = cgVar;
            return;
        }
        String str = a;
        AppboyLogger.d(str, "Session id can only be set once. Doing nothing. Given session id: " + cgVar);
    }

    public void a(String str) {
        if (this.f == null) {
            this.f = str;
            return;
        }
        String str2 = a;
        AppboyLogger.d(str2, "User id can only be set once. Doing nothing. Given user id: " + str);
    }

    public cg g() {
        return this.g;
    }

    public String f() {
        return this.f;
    }

    public String d() {
        return this.e;
    }

    public boolean h() {
        if (this.b != v.INTERNAL_ERROR || !this.c.optBoolean("nop", false)) {
            return false;
        }
        return true;
    }

    /* renamed from: m */
    public JSONObject forJsonPut() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("name", this.b.forJsonPut());
            jSONObject.put("data", this.c);
            jSONObject.put("time", this.d);
            if (!StringUtils.isNullOrEmpty(this.f)) {
                jSONObject.put("user_id", this.f);
            }
            if (this.g != null) {
                jSONObject.put("session_id", this.g.forJsonPut());
            }
        } catch (JSONException e2) {
            AppboyLogger.e(a, "Caught exception creating Braze event Json.", e2);
        }
        return jSONObject;
    }

    public String toString() {
        JSONObject m = forJsonPut();
        return (m == null || m.length() <= 0) ? "" : m.toString();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.e.equals(((cn) obj).e);
    }

    public int hashCode() {
        return this.e.hashCode();
    }
}
