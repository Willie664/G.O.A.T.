package bo.app;

public class aw extends Exception {
    public aw(String str, Throwable th) {
        super(str, th);
    }
}
