package bo.app;

import android.net.Uri;
import java.util.Map;

public abstract class di implements dg {
    public final Uri a;
    private Map<String, String> b;

    protected di(Uri uri, Map<String, String> map) {
        this.b = map;
        this.a = Uri.parse(uri + k());
    }

    public Uri a() {
        return this.a;
    }

    public String k() {
        Map<String, String> map = this.b;
        if (map == null || map.size() == 0) {
            return "";
        }
        String str = "?";
        for (String next : this.b.keySet()) {
            str = str + next + "=" + this.b.get(next) + "&";
        }
        return str.substring(0, str.length() - 1);
    }
}
