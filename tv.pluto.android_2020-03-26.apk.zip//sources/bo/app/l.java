package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;

public class l {
    private static final String a = AppboyLogger.getAppboyLogTag(l.class);
    private final SharedPreferences b;

    public l(Context context) {
        this.b = context.getSharedPreferences("com.appboy.offline.storagemap", 0);
    }

    public String a() {
        String string = this.b.getString("last_user", "");
        if (StringUtils.getByteSize(string) <= 997) {
            return string;
        }
        String str = a;
        AppboyLogger.w(str, "Stored user ID is longer than 997 bytes. Truncating. Original user ID: " + string);
        String truncateToByteLength = StringUtils.truncateToByteLength(string, 997);
        a(truncateToByteLength);
        return truncateToByteLength;
    }

    public void a(String str) {
        if (StringUtils.getByteSize(str) > 997) {
            String str2 = a;
            AppboyLogger.w(str2, "Offline user storage provider was given user ID longer than 997 . Rejecting. User ID: " + str);
            return;
        }
        StringUtils.checkNotNullOrEmpty(str);
        SharedPreferences.Editor edit = this.b.edit();
        edit.putString("last_user", str);
        edit.apply();
    }
}
