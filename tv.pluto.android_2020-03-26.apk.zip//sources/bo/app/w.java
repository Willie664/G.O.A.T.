package bo.app;

public enum w {
    ENTER,
    EXIT
}
