package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.List;
import org.json.JSONArray;

public abstract class fk implements ez {
    private static final String b = AppboyLogger.getAppboyLogTag(fk.class);
    protected List<ez> a;

    protected fk(List<ez> list) {
        this.a = list;
    }

    /* renamed from: a */
    public JSONArray forJsonPut() {
        JSONArray jSONArray = new JSONArray();
        try {
            for (ez forJsonPut : this.a) {
                jSONArray.put(forJsonPut.forJsonPut());
            }
        } catch (Exception e) {
            AppboyLogger.e(b, "Caught exception creating Json.", e);
        }
        return jSONArray;
    }
}
