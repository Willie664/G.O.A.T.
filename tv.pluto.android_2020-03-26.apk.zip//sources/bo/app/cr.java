package bo.app;

public class cr implements cu {
    private final String a;

    public cr(String str) {
        this.a = str;
    }

    public String a() {
        return this.a;
    }
}
