package bo.app;

public final class ae {
    private final df a;

    public ae(df dfVar) {
        if (dfVar != null) {
            this.a = dfVar;
            return;
        }
        throw new NullPointerException();
    }

    public df a() {
        return this.a;
    }
}
