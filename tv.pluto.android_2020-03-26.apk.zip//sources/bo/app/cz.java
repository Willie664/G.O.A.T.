package bo.app;

import android.net.Uri;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class cz extends cx {
    private static final String b = AppboyLogger.getAppboyLogTag(cz.class);
    private final long c;
    private final long d;
    private final String e;

    public boolean i() {
        return false;
    }

    public cz(String str, long j, long j2, String str2) {
        super(Uri.parse(str + "content_cards/sync"), (Map<String, String>) null);
        this.c = j;
        this.d = j2;
        this.e = str2;
    }

    public x j() {
        return x.POST;
    }

    public void a(ac acVar, cs csVar) {
        AppboyLogger.d(b, "ContentCardsSyncRequest executed successfully.");
    }

    public void a(Map<String, String> map) {
        super.a(map);
        map.put("X-Braze-DataRequest", "true");
        map.put("X-Braze-ContentCardsRequest", "true");
    }

    public JSONObject h() {
        JSONObject h = super.h();
        if (h == null) {
            return null;
        }
        try {
            h.put("last_full_sync_at", this.d);
            h.put("last_card_updated_at", this.c);
            if (!StringUtils.isNullOrBlank(this.e)) {
                h.put("user_id", this.e);
            }
            return h;
        } catch (JSONException e2) {
            AppboyLogger.w(b, "Experienced JSONException while creating Content Cards request. Returning null.", e2);
            return null;
        }
    }
}
