package bo.app;

import android.content.Context;
import com.appboy.Appboy;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import com.google.firebase.iid.FirebaseInstanceId;

public class br {
    private static final String a = AppboyLogger.getAppboyLogTag(br.class);
    private static final String[] b = {"com.google.firebase.iid.FirebaseInstanceId"};
    private final Context c;

    public br(Context context) {
        this.c = context;
    }

    public void a(String str) {
        String b2 = b(str);
        if (!StringUtils.isNullOrEmpty(b2)) {
            Appboy.getInstance(this.c).registerAppboyPushMessages(b2);
        } else {
            AppboyLogger.w(a, "Obtained an empty or null Firebase Cloud Messaging registration token. Not registering token.");
        }
    }

    public static boolean a(Context context, AppboyConfigurationProvider appboyConfigurationProvider) {
        if (StringUtils.isNullOrEmpty(appboyConfigurationProvider.getFirebaseCloudMessagingSenderIdKey())) {
            AppboyLogger.w(a, "Firebase Cloud Messaging requires a non-null and non-empty sender ID.");
            return false;
        } else if (!ej.b(context)) {
            AppboyLogger.w(a, "Firebase Cloud Messaging requires the Google Play Store to be installed.");
            return false;
        } else {
            try {
                ClassLoader classLoader = br.class.getClassLoader();
                for (String str : b) {
                    if (Class.forName(str, false, classLoader) == null) {
                        AppboyLogger.w(a, "Automatic registration for Firebase Cloud Messaging requires the following class to be present: " + str);
                        return false;
                    }
                }
                return true;
            } catch (Exception e) {
                AppboyLogger.e(a, "Caught error while checking for required classes for Firebase Cloud Messaging.", e);
                return false;
            }
        }
    }

    private static String b(String str) {
        String str2 = a;
        AppboyLogger.v(str2, "Registering for Firebase Cloud Messaging token using sender id: " + str);
        try {
            String token = FirebaseInstanceId.getInstance().getToken(str, "FCM");
            String str3 = a;
            AppboyLogger.v(str3, "Obtained Firebase Cloud Messaging token: " + token);
            return token;
        } catch (Exception e) {
            String str4 = a;
            AppboyLogger.e(str4, "Failed to register for Firebase Cloud Messaging using sender ID: " + str, e);
            return null;
        }
    }
}
