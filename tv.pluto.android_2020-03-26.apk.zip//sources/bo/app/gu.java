package bo.app;

import org.json.JSONArray;
import org.json.JSONObject;

public class gu extends gt {
    gq a;

    public gu(gq gqVar) {
        this.a = gqVar;
    }

    public void c(String str, JSONObject jSONObject, JSONObject jSONObject2, gr grVar) {
        b(str, jSONObject, jSONObject2, grVar);
        if (!this.a.a()) {
            a(str, jSONObject, jSONObject2, grVar);
        }
    }

    public void a(String str, Object obj, Object obj2, gr grVar) {
        if (!(obj instanceof Number) || !(obj2 instanceof Number)) {
            if (!obj.getClass().isAssignableFrom(obj2.getClass())) {
                grVar.a(str, obj, obj2);
            } else if (obj instanceof JSONArray) {
                e(str, (JSONArray) obj, (JSONArray) obj2, grVar);
            } else if (obj instanceof JSONObject) {
                c(str, (JSONObject) obj, (JSONObject) obj2, grVar);
            } else if (!obj.equals(obj2)) {
                grVar.a(str, obj, obj2);
            }
        } else if (((Number) obj).doubleValue() != ((Number) obj2).doubleValue()) {
            grVar.a(str, obj, obj2);
        }
    }

    public void e(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar) {
        if (jSONArray.length() != jSONArray2.length()) {
            grVar.a(str + "[]: Expected " + jSONArray.length() + " values but got " + jSONArray2.length());
        } else if (jSONArray.length() != 0) {
            if (this.a.b()) {
                c(str, jSONArray, jSONArray2, grVar);
            } else if (gw.c(jSONArray)) {
                b(str, jSONArray, jSONArray2, grVar);
            } else if (gw.d(jSONArray)) {
                a(str, jSONArray, jSONArray2, grVar);
            } else {
                d(str, jSONArray, jSONArray2, grVar);
            }
        }
    }
}
