package bo.app;

import android.content.Context;
import com.appboy.models.InAppMessageBase;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ev extends ew implements et {
    private static final String a = AppboyLogger.getAppboyLogTag(ev.class);
    private bt b;
    private String c;
    private String d;
    private String e;
    private String f;
    private long g = -1;

    public ev(JSONObject jSONObject, bt btVar) {
        super(jSONObject);
        String str = a;
        AppboyLogger.d(str, "Parsing templated triggered action with JSON: " + JsonUtils.getPrettyPrintedString(jSONObject));
        JSONObject jSONObject2 = jSONObject.getJSONObject("data");
        this.c = jSONObject2.getString("trigger_id");
        JSONArray optJSONArray = jSONObject2.optJSONArray("prefetch_image_urls");
        if (optJSONArray != null) {
            this.d = optJSONArray.getString(0);
        }
        JSONArray optJSONArray2 = jSONObject2.optJSONArray("prefetch_zip_urls");
        if (optJSONArray2 != null) {
            this.e = optJSONArray2.getString(0);
        }
        this.b = btVar;
    }

    public gj d() {
        if (!StringUtils.isNullOrBlank(this.d)) {
            return new gj(fr.IMAGE, this.d);
        }
        if (!StringUtils.isNullOrBlank(this.e)) {
            return new gj(fr.ZIP, this.e);
        }
        return null;
    }

    public void a(String str) {
        this.f = str;
    }

    public void a(Context context, ac acVar, ft ftVar, long j) {
        if (this.b != null) {
            this.g = j;
            String str = a;
            AppboyLogger.d(str, "Posting templating request after delay of " + c().d() + " seconds.");
            this.b.a(this, ftVar);
        }
    }

    public long g() {
        return this.g;
    }

    public String h() {
        return this.c;
    }

    public String i() {
        return this.f;
    }

    /* renamed from: f */
    public JSONObject forJsonPut() {
        try {
            JSONObject f2 = super.forJsonPut();
            f2.put(InAppMessageBase.TYPE, "templated_iam");
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("trigger_id", this.c);
            JSONArray jSONArray = new JSONArray();
            if (!StringUtils.isNullOrBlank(this.d)) {
                jSONArray.put(this.d);
                jSONObject.put("prefetch_image_urls", jSONArray);
            }
            JSONArray jSONArray2 = new JSONArray();
            if (!StringUtils.isNullOrBlank(this.e)) {
                jSONArray2.put(this.e);
                jSONObject.put("prefetch_zip_urls", jSONArray2);
            }
            f2.put("data", jSONObject);
            return f2;
        } catch (JSONException unused) {
            return null;
        }
    }
}
