package bo.app;

import android.content.Context;
import com.appboy.models.IPutIntoJson;
import org.json.JSONObject;

public interface et extends IPutIntoJson<JSONObject> {
    void a(Context context, ac acVar, ft ftVar, long j);

    void a(gk gkVar);

    void a(String str);

    boolean a();

    boolean a(ft ftVar);

    String b();

    fn c();

    gj d();

    gk e();
}
