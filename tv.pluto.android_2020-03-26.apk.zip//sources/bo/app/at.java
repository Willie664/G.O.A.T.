package bo.app;

public class at {
    private final ft a;
    private final et b;

    public at(ft ftVar, et etVar) {
        this.a = ftVar;
        this.b = etVar;
    }

    public ft a() {
        return this.a;
    }

    public et b() {
        return this.b;
    }
}
