package bo.app;

import com.appboy.enums.inappmessage.InAppMessageFailureType;
import com.appboy.enums.inappmessage.MessageType;
import com.appboy.models.IInAppMessage;
import com.appboy.models.InAppMessageBase;
import com.appboy.models.InAppMessageControl;
import com.appboy.models.InAppMessageFull;
import com.appboy.models.InAppMessageHtmlFull;
import com.appboy.models.InAppMessageModal;
import com.appboy.models.InAppMessageSlideup;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class em {
    private static final String a = AppboyLogger.getAppboyLogTag(em.class);

    public static IInAppMessage a(String str, bt btVar) {
        try {
            if (!StringUtils.isNullOrBlank(str)) {
                return a(new JSONObject(str), btVar);
            }
            AppboyLogger.i(a, "In-app message string was null or blank. Not de-serializing message.");
            return null;
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Encountered JSONException processing in-app message string: " + str, e);
            return null;
        } catch (Exception e2) {
            String str3 = a;
            AppboyLogger.e(str3, "Failed to deserialize the in-app message string." + str, e2);
            return null;
        }
    }

    public static IInAppMessage a(JSONObject jSONObject, bt btVar) {
        if (jSONObject == null) {
            try {
                AppboyLogger.d(a, "In-app message Json was null. Not deserializing message.");
                return null;
            } catch (JSONException e) {
                String str = a;
                AppboyLogger.w(str, "Encountered JSONException processing in-app message: " + JsonUtils.getPrettyPrintedString(jSONObject), e);
                return null;
            } catch (Exception e2) {
                String str2 = a;
                AppboyLogger.e(str2, "Failed to deserialize the in-app message: " + JsonUtils.getPrettyPrintedString(jSONObject), e2);
                return null;
            }
        } else if (a(jSONObject)) {
            AppboyLogger.d(a, "Deserializing control in-app message.");
            return new InAppMessageControl(jSONObject, btVar);
        } else {
            MessageType messageType = (MessageType) JsonUtils.optEnum(jSONObject, InAppMessageBase.TYPE, MessageType.class, null);
            if (messageType == null) {
                String str3 = a;
                AppboyLogger.i(str3, "In-app message type was null. Not deserializing message: " + JsonUtils.getPrettyPrintedString(jSONObject));
                b(jSONObject, btVar);
                return null;
            }
            int i = AnonymousClass1.a[messageType.ordinal()];
            if (i == 1) {
                return new InAppMessageFull(jSONObject, btVar);
            }
            if (i == 2) {
                return new InAppMessageModal(jSONObject, btVar);
            }
            if (i == 3) {
                return new InAppMessageSlideup(jSONObject, btVar);
            }
            if (i == 4) {
                return new InAppMessageHtmlFull(jSONObject, btVar);
            }
            String str4 = a;
            AppboyLogger.e(str4, "Unknown in-app message type. Not deserializing message: " + JsonUtils.getPrettyPrintedString(jSONObject));
            b(jSONObject, btVar);
            return null;
        }
    }

    /* renamed from: bo.app.em$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a = new int[MessageType.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(10:0|1|2|3|4|5|6|7|8|10) */
        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0014 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x002a */
        static {
            /*
                com.appboy.enums.inappmessage.MessageType[] r0 = com.appboy.enums.inappmessage.MessageType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0014 }
                com.appboy.enums.inappmessage.MessageType r1 = com.appboy.enums.inappmessage.MessageType.FULL     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001f }
                com.appboy.enums.inappmessage.MessageType r1 = com.appboy.enums.inappmessage.MessageType.MODAL     // Catch:{ NoSuchFieldError -> 0x001f }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x002a }
                com.appboy.enums.inappmessage.MessageType r1 = com.appboy.enums.inappmessage.MessageType.SLIDEUP     // Catch:{ NoSuchFieldError -> 0x002a }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x002a }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0035 }
                com.appboy.enums.inappmessage.MessageType r1 = com.appboy.enums.inappmessage.MessageType.HTML_FULL     // Catch:{ NoSuchFieldError -> 0x0035 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0035 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0035 }
            L_0x0035:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: bo.app.em.AnonymousClass1.<clinit>():void");
        }
    }

    private static void b(JSONObject jSONObject, bt btVar) {
        String optString = jSONObject.optString("card_id");
        String optString2 = jSONObject.optString("trigger_id");
        if (!StringUtils.isNullOrEmpty(optString) || !StringUtils.isNullOrEmpty(optString2)) {
            btVar.a((cc) cn.a(optString, optString2, InAppMessageFailureType.UNKNOWN_MESSAGE_TYPE));
        }
    }

    static boolean a(JSONObject jSONObject) {
        return jSONObject.optBoolean(InAppMessageBase.IS_CONTROL, false);
    }
}
