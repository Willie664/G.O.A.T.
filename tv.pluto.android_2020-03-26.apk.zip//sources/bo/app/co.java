package bo.app;

import com.appboy.Constants;
import org.json.JSONObject;

public class co extends cn {
    private final String a;

    private co(v vVar, JSONObject jSONObject, String str) {
        super(vVar, jSONObject);
        this.a = str;
    }

    public boolean n() {
        return this.a.equals(Constants.APPBOY_PUSH_ACTION_TYPE_NONE);
    }

    public static co b(String str, String str2, String str3) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("cid", str);
        jSONObject.put(Constants.APPBOY_PUSH_CONTENT_KEY, str2);
        return new co(v.PUSH_NOTIFICATION_ACTION_TRACKING, jSONObject, str3);
    }
}
