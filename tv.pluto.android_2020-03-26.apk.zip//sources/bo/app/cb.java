package bo.app;

import com.appboy.enums.CardKey;
import com.appboy.enums.CardType;
import com.appboy.models.cards.BannerImageCard;
import com.appboy.models.cards.CaptionedImageCard;
import com.appboy.models.cards.Card;
import com.appboy.models.cards.ControlCard;
import com.appboy.models.cards.ShortNewsCard;
import com.appboy.models.cards.TextAnnouncementCard;
import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class cb {
    private static final String a = AppboyLogger.getAppboyLogTag(cb.class);

    public static List<Card> a(JSONArray jSONArray, CardKey.Provider provider, bn bnVar, dw dwVar, c cVar) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                Card a2 = a(jSONArray.optString(i), provider, bnVar, dwVar, cVar);
                if (a2 != null) {
                    arrayList.add(a2);
                }
            } catch (Exception e) {
                String str = a;
                AppboyLogger.e(str, "Unable to create Card JSON in array. Ignoring. Was on element index: " + i + " of json array: " + jSONArray.toString(), e);
            }
        }
        return arrayList;
    }

    public static Card a(JSONObject jSONObject, CardKey.Provider provider, bn bnVar, dw dwVar, c cVar) {
        CardType cardTypeFromJson = provider.getCardTypeFromJson(jSONObject);
        int i = AnonymousClass1.a[cardTypeFromJson.ordinal()];
        if (i == 1) {
            return new BannerImageCard(jSONObject, provider, bnVar, dwVar, cVar);
        }
        if (i == 2) {
            return new CaptionedImageCard(jSONObject, provider, bnVar, dwVar, cVar);
        }
        if (i == 3) {
            return new ShortNewsCard(jSONObject, provider, bnVar, dwVar, cVar);
        }
        if (i == 4) {
            return new TextAnnouncementCard(jSONObject, provider, bnVar, dwVar, cVar);
        }
        if (i == 5) {
            return new ControlCard(jSONObject, provider, bnVar, dwVar, cVar);
        }
        throw new JSONException("Failed to construct java object from JSON [" + jSONObject.toString() + "] with cardType: " + cardTypeFromJson);
    }

    /* renamed from: bo.app.cb$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a = new int[CardType.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0014 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x002a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0035 */
        static {
            /*
                com.appboy.enums.CardType[] r0 = com.appboy.enums.CardType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0014 }
                com.appboy.enums.CardType r1 = com.appboy.enums.CardType.BANNER     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001f }
                com.appboy.enums.CardType r1 = com.appboy.enums.CardType.CAPTIONED_IMAGE     // Catch:{ NoSuchFieldError -> 0x001f }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x002a }
                com.appboy.enums.CardType r1 = com.appboy.enums.CardType.SHORT_NEWS     // Catch:{ NoSuchFieldError -> 0x002a }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x002a }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0035 }
                com.appboy.enums.CardType r1 = com.appboy.enums.CardType.TEXT_ANNOUNCEMENT     // Catch:{ NoSuchFieldError -> 0x0035 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0035 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0035 }
            L_0x0035:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0040 }
                com.appboy.enums.CardType r1 = com.appboy.enums.CardType.CONTROL     // Catch:{ NoSuchFieldError -> 0x0040 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0040 }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0040 }
            L_0x0040:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: bo.app.cb.AnonymousClass1.<clinit>():void");
        }
    }

    private static Card a(String str, CardKey.Provider provider, bn bnVar, dw dwVar, c cVar) {
        return a(new JSONObject(str), provider, bnVar, dwVar, cVar);
    }
}
