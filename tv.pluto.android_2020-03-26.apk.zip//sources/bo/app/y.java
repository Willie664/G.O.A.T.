package bo.app;

import com.comscore.android.id.IdHelperAndroid;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public enum y {
    UNKNOWN("unknown"),
    NONE(IdHelperAndroid.NO_ID_AVAILABLE),
    TWO_G("2g"),
    THREE_G("3g"),
    FOUR_G("4g"),
    WIFI("wifi");
    
    private static final Map<String, y> g = null;
    private final String h;

    static {
        g = new HashMap();
        Iterator it = EnumSet.allOf(y.class).iterator();
        while (it.hasNext()) {
            y yVar = (y) it.next();
            g.put(yVar.a(), yVar);
        }
    }

    private y(String str) {
        this.h = str;
    }

    public String a() {
        return this.h;
    }
}
