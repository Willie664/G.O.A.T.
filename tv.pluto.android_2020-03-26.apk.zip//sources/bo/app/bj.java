package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Executor;

public class bj {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(bj.class);
    /* access modifiers changed from: private */
    public final dv b;
    /* access modifiers changed from: private */
    public final dv c;
    private boolean d = false;

    public bj(dv dvVar, dv dvVar2) {
        this.c = dvVar;
        this.b = dvVar2;
    }

    public void a(cc ccVar) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage manager is closed. Not adding event: " + ccVar);
            return;
        }
        this.c.a(ccVar);
    }

    public void a(List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage manager is closed. Not deleting events: " + list);
            return;
        }
        this.c.b(list);
    }

    public void a(Executor executor, final t tVar) {
        if (this.d) {
            AppboyLogger.w(a, "Storage manager is closed. Not starting offline recovery.");
        } else {
            executor.execute(new Runnable() {
                public void run() {
                    AppboyLogger.d(bj.a, "Started offline AppboyEvent recovery task.");
                    bj.a(tVar, bj.this.c, bj.this.b);
                }
            });
        }
    }

    public void a() {
        this.d = true;
        this.c.b();
    }

    static void a(t tVar, dv dvVar, dv dvVar2) {
        HashSet hashSet = new HashSet();
        for (cc next : dvVar.a()) {
            String str = a;
            AppboyLogger.v(str, "Adding event to dispatch from active storage: " + next);
            hashSet.add(next.d());
            tVar.a(next);
        }
        if (dvVar2 != null) {
            Collection<cc> a2 = dvVar2.a();
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (cc next2 : a2) {
                arrayList.add(next2);
                if (next2.h()) {
                    String str2 = a;
                    AppboyLogger.d(str2, "Event present in migrated storage is non persistable. Not re-adding to current storage: " + next2);
                } else if (hashSet.contains(next2.d())) {
                    String str3 = a;
                    AppboyLogger.d(str3, "Event present in both storage providers. Not re-adding to current storage: " + next2);
                } else {
                    String str4 = a;
                    AppboyLogger.d(str4, "Found event in storage from migrated storage provider: " + next2);
                    arrayList2.add(next2);
                }
            }
            dvVar2.b(arrayList);
            dvVar.a((List<cc>) arrayList2);
        }
    }
}
