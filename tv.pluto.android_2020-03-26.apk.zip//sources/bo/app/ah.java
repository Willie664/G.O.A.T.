package bo.app;

import com.appboy.models.AppboyGeofence;
import java.util.List;

public final class ah {
    private final List<AppboyGeofence> a;

    public ah(List<AppboyGeofence> list) {
        this.a = list;
    }

    public List<AppboyGeofence> a() {
        return this.a;
    }
}
