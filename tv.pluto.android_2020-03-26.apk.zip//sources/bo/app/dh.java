package bo.app;

public interface dh {
    void a(dg dgVar);

    void b(dg dgVar);
}
