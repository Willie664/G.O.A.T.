package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadPoolExecutor;

public class dp implements dv {
    private static final String a = AppboyLogger.getAppboyLogTag(dp.class);
    /* access modifiers changed from: private */
    public final dv b;
    private final ThreadPoolExecutor c;
    private boolean d = false;

    public dp(dv dvVar, ThreadPoolExecutor threadPoolExecutor) {
        this.b = dvVar;
        this.c = threadPoolExecutor;
    }

    @Deprecated
    public void a(final cc ccVar) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding event: " + ccVar);
            return;
        }
        this.c.execute(new Runnable() {
            public void run() {
                dp.this.b.a(ccVar);
            }
        });
    }

    public void a(final List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding events: " + list);
            return;
        }
        this.c.execute(new Runnable() {
            public void run() {
                dp.this.b.a((List<cc>) list);
            }
        });
    }

    public void b(final List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not deleting events: " + list);
            return;
        }
        this.c.execute(new Runnable() {
            public void run() {
                dp.this.b.b(list);
            }
        });
    }

    public synchronized Collection<cc> a() {
        if (this.d) {
            AppboyLogger.w(a, "Storage provider is closed. Not getting all events.");
            return null;
        }
        try {
            return (Collection) this.c.submit(new Callable<Collection<cc>>() {
                /* renamed from: a */
                public Collection<cc> call() {
                    return dp.this.b.a();
                }
            }).get();
        } catch (Exception e) {
            throw new RuntimeException("Error while trying to asynchronously get all events.", e);
        }
    }

    public synchronized void b() {
        AppboyLogger.w(a, "Setting this provider and internal storage provider to closed. Cancelling all queued storage provider work.");
        this.d = true;
        this.b.b();
        this.c.shutdownNow();
    }
}
