package bo.app;

public enum x {
    GET,
    POST
}
