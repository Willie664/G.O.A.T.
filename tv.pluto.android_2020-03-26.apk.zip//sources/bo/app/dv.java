package bo.app;

import java.util.Collection;
import java.util.List;

public interface dv {
    Collection<cc> a();

    void a(cc ccVar);

    void a(List<cc> list);

    void b();

    void b(List<cc> list);
}
