package bo.app;

import com.appboy.Appboy;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public final class r implements t {
    private static final String a = AppboyLogger.getAppboyLogTag(r.class);
    private final bu b;
    private final ed c;
    private final LinkedBlockingQueue<df> d = new LinkedBlockingQueue<>(1000);
    private final AppboyConfigurationProvider e;
    private final ConcurrentHashMap<String, cc> f;
    private final ConcurrentHashMap<String, cc> g;

    public r(ed edVar, bu buVar, AppboyConfigurationProvider appboyConfigurationProvider) {
        this.c = edVar;
        this.b = buVar;
        this.e = appboyConfigurationProvider;
        this.f = new ConcurrentHashMap<>();
        this.g = new ConcurrentHashMap<>();
    }

    public synchronized void b(cc ccVar) {
        if (ccVar == null) {
            AppboyLogger.w(a, "Tried to add null AppboyEvent to pending dispatch.");
        } else {
            this.g.putIfAbsent(ccVar.d(), ccVar);
        }
    }

    public synchronized void a(cg cgVar) {
        if (!this.g.isEmpty()) {
            AppboyLogger.d(a, "Flushing pending events to dispatcher map");
            for (cc a2 : this.g.values()) {
                a2.a(cgVar);
            }
            this.f.putAll(this.g);
            this.g.clear();
        }
    }

    public void a(cc ccVar) {
        if (ccVar == null) {
            AppboyLogger.w(a, "Tried to add null AppboyEvent to dispatch.");
        } else {
            this.f.putIfAbsent(ccVar.d(), ccVar);
        }
    }

    public void a(ac acVar, df dfVar) {
        if (dfVar == null) {
            throw new NullPointerException();
        } else if (e()) {
            AppboyLogger.i(a, "Network requests are offline, not adding request to queue.");
        } else {
            String str = a;
            AppboyLogger.i(str, "Adding request to dispatcher with parameters: \n" + JsonUtils.getPrettyPrintedString(dfVar.h()), false);
            dfVar.a(acVar);
            this.d.add(dfVar);
        }
    }

    public boolean a() {
        return !this.d.isEmpty();
    }

    public df b() {
        return a(this.d.take());
    }

    public df c() {
        df poll = this.d.poll();
        if (poll != null) {
            a(poll);
        }
        return poll;
    }

    private void c(df dfVar) {
        if (this.b.c() != null) {
            dfVar.a(this.b.c());
        }
        if (this.e.getAppboyApiKey() != null) {
            dfVar.b(this.e.getAppboyApiKey().toString());
        }
        dfVar.c("3.6.0");
        dfVar.a(ee.a());
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0024, code lost:
        return r2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized bo.app.df a(bo.app.df r2) {
        /*
            r1 = this;
            monitor-enter(r1)
            if (r2 != 0) goto L_0x0006
            r2 = 0
            monitor-exit(r1)
            return r2
        L_0x0006:
            r1.c(r2)     // Catch:{ all -> 0x0025 }
            boolean r0 = r2 instanceof bo.app.dk     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x000f
            monitor-exit(r1)
            return r2
        L_0x000f:
            boolean r0 = r2 instanceof bo.app.dd     // Catch:{ all -> 0x0025 }
            if (r0 != 0) goto L_0x0023
            boolean r0 = r2 instanceof bo.app.de     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x0018
            goto L_0x0023
        L_0x0018:
            boolean r0 = r2 instanceof bo.app.cz     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x001e
            monitor-exit(r1)
            return r2
        L_0x001e:
            r1.b((bo.app.df) r2)     // Catch:{ all -> 0x0025 }
            monitor-exit(r1)
            return r2
        L_0x0023:
            monitor-exit(r1)
            return r2
        L_0x0025:
            r2 = move-exception
            monitor-exit(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.r.a(bo.app.df):bo.app.df");
    }

    /* access modifiers changed from: package-private */
    public void b(df dfVar) {
        dfVar.d(this.b.d());
        dfVar.a(this.e.getSdkFlavor());
        dfVar.e(this.b.e());
        cj b2 = this.b.b();
        dfVar.a(b2);
        if (b2 != null && b2.c()) {
            this.c.d();
        }
        dfVar.a((cm) this.c.b());
        dfVar.a(d());
    }

    /* access modifiers changed from: package-private */
    public synchronized ca d() {
        ArrayList arrayList;
        Collection<cc> values = this.f.values();
        arrayList = new ArrayList();
        Iterator<cc> it = values.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            cc next = it.next();
            arrayList.add(next);
            values.remove(next);
            String str = a;
            AppboyLogger.d(str, "Event dispatched: " + next.forJsonPut() + " with uid: " + next.d());
            if (arrayList.size() >= 32) {
                AppboyLogger.i(a, "Max number of events per dispatch reached: 32 . No more events will be included in this dispatch");
                break;
            }
        }
        return new ca(new HashSet(arrayList));
    }

    /* access modifiers changed from: package-private */
    public boolean e() {
        return Appboy.getOutboundNetworkRequestsOffline();
    }
}
