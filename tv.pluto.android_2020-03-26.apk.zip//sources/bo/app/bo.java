package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.appboy.support.AppboyLogger;

public class bo {
    private static final String d = AppboyLogger.getAppboyLogTag(bo.class);
    final SharedPreferences a;
    final ac b;
    boolean c = false;
    private final ea e;

    public bo(Context context, ac acVar, ea eaVar) {
        this.b = acVar;
        this.e = eaVar;
        this.a = context.getSharedPreferences("com.appboy.storage.sessions.messaging_session", 0);
    }

    /* access modifiers changed from: package-private */
    public void a() {
        if (c()) {
            AppboyLogger.d(d, "Publishing new messaging session event.");
            this.b.a(aj.a, aj.class);
            this.c = true;
            return;
        }
        AppboyLogger.d(d, "Messaging session not started.");
    }

    /* access modifiers changed from: package-private */
    public void b() {
        long a2 = ee.a();
        String str = d;
        AppboyLogger.d(str, "Messaging session stopped. Adding new messaging session timestamp: " + a2);
        this.a.edit().putLong("messaging_session_timestamp", a2).apply();
        this.c = false;
    }

    /* access modifiers changed from: package-private */
    public boolean c() {
        long f = this.e.f();
        if (f == -1 || this.c) {
            return false;
        }
        long j = this.a.getLong("messaging_session_timestamp", -1);
        long a2 = ee.a();
        String str = d;
        AppboyLogger.d(str, "Messaging session timeout: " + f + ", current diff: " + (a2 - j));
        if (j + f < a2) {
            return true;
        }
        return false;
    }
}
