package bo.app;

import com.appboy.models.outgoing.AppboyProperties;

public class fs extends gb {
    private String a;

    public String b() {
        return "custom_event";
    }

    public fs(String str, AppboyProperties appboyProperties, cc ccVar) {
        super(appboyProperties, ccVar);
        this.a = str;
    }

    public String a() {
        return this.a;
    }
}
