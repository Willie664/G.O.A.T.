package bo.app;

import org.json.JSONObject;

public class cp extends cn {
    private cp(v vVar, JSONObject jSONObject) {
        super(vVar, jSONObject);
    }

    public static cp k(String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("cid", str);
        return new cp(v.PUSH_NOTIFICATION_TRACKING, jSONObject);
    }
}
