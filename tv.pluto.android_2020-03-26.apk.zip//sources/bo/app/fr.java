package bo.app;

public enum fr {
    ZIP,
    IMAGE
}
