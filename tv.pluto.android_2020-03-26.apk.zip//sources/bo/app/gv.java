package bo.app;

import org.json.JSONArray;
import org.json.JSONObject;

public interface gv {
    gr a(JSONArray jSONArray, JSONArray jSONArray2);

    gr a(JSONObject jSONObject, JSONObject jSONObject2);

    void a(String str, Object obj, Object obj2, gr grVar);

    void c(String str, JSONObject jSONObject, JSONObject jSONObject2, gr grVar);

    void e(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar);
}
