package bo.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import com.appboy.Constants;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.receivers.AppboyActionReceiver;
import com.appboy.support.AppboyLogger;
import com.appboy.support.PermissionUtils;
import java.util.concurrent.TimeUnit;

public class bm implements bw {
    private static final String a = AppboyLogger.getAppboyLogTag(bm.class);
    private static final long b = TimeUnit.MINUTES.toMillis(10);
    private final Context c;
    private final LocationManager d;
    private final bt e;
    private final boolean f;

    public bm(Context context, bt btVar, AppboyConfigurationProvider appboyConfigurationProvider) {
        this.c = context;
        this.e = btVar;
        this.d = (LocationManager) context.getSystemService("location");
        this.f = a(appboyConfigurationProvider);
    }

    public boolean a(cd cdVar) {
        try {
            this.e.a((cc) cn.a(cdVar));
            return true;
        } catch (Exception e2) {
            AppboyLogger.w(a, "Failed to log location recorded event.", e2);
            return false;
        }
    }

    public boolean a() {
        Location a2;
        if (!this.f) {
            AppboyLogger.i(a, "Did not request single location update. Location collection is disabled.");
            return false;
        }
        boolean hasPermission = PermissionUtils.hasPermission(this.c, "android.permission.ACCESS_FINE_LOCATION");
        boolean hasPermission2 = PermissionUtils.hasPermission(this.c, "android.permission.ACCESS_COARSE_LOCATION");
        if (!hasPermission2 && !hasPermission) {
            AppboyLogger.i(a, "Did not request single location update. Neither fine nor coarse location permissions found.");
            return false;
        } else if (!hasPermission || (a2 = a(this.d)) == null) {
            String a3 = a(this.d, hasPermission, hasPermission2);
            if (a3 == null) {
                AppboyLogger.d(a, "Could not request single location update. Could not find suitable location provider.");
                return false;
            }
            try {
                String str = a;
                AppboyLogger.d(str, "Requesting single location update with provider: " + a3);
                this.d.requestSingleUpdate(a3, PendingIntent.getBroadcast(this.c, 0, new Intent(Constants.APPBOY_ACTION_RECEIVER_SINGLE_LOCATION_UPDATE_INTENT_ACTION).setClass(this.c, AppboyActionReceiver.class), 134217728));
                return true;
            } catch (SecurityException e2) {
                AppboyLogger.w(a, "Failed to request single location update due to security exception from insufficient permissions.", e2);
                return false;
            } catch (Exception e3) {
                AppboyLogger.w(a, "Failed to request single location update due to exception.", e3);
                return false;
            }
        } else {
            String str2 = a;
            AppboyLogger.d(str2, "Setting user location to last known GPS location: " + a2);
            a((cd) new ci(a2));
            return true;
        }
    }

    public static boolean a(AppboyConfigurationProvider appboyConfigurationProvider) {
        if (appboyConfigurationProvider.isLocationCollectionEnabled()) {
            AppboyLogger.i(a, "Location collection enabled via sdk configuration.");
            return true;
        }
        AppboyLogger.i(a, "Location collection disabled via sdk configuration.");
        return false;
    }

    static String a(LocationManager locationManager, boolean z, boolean z2) {
        if ((z2 || z) && locationManager.isProviderEnabled("network")) {
            return "network";
        }
        if (!z || !locationManager.isProviderEnabled("passive")) {
            return null;
        }
        return "passive";
    }

    static Location a(LocationManager locationManager) {
        Location lastKnownLocation;
        if (!locationManager.isProviderEnabled("gps") || (lastKnownLocation = locationManager.getLastKnownLocation("gps")) == null) {
            return null;
        }
        long c2 = ee.c() - lastKnownLocation.getTime();
        if (c2 > b) {
            String str = a;
            AppboyLogger.v(str, "Last known GPS location is too old and will not be used. Age ms: " + c2);
            return null;
        }
        String str2 = a;
        AppboyLogger.d(str2, "Using last known GPS location: " + lastKnownLocation);
        return lastKnownLocation;
    }
}
