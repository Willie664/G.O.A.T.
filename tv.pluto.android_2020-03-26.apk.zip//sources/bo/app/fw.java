package bo.app;

public class fw extends ga implements ft {
    public String b() {
        return "open";
    }
}
