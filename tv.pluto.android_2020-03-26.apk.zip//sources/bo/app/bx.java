package bo.app;

public interface bx {
    String a();

    void a(String str);
}
