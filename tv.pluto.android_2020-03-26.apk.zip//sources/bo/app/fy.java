package bo.app;

public class fy extends ga implements ft {
    private String a;

    public String b() {
        return "push_click";
    }

    public fy(String str, cc ccVar) {
        super(ccVar);
        this.a = a(str);
    }

    public String a() {
        return this.a;
    }
}
