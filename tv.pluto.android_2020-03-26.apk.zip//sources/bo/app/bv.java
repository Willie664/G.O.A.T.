package bo.app;

public interface bv {
    String a();
}
