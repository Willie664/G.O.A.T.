package bo.app;

import com.appboy.enums.SdkFlavor;
import java.util.Map;
import org.json.JSONObject;

public interface df extends dg {
    void a(long j);

    void a(ca caVar);

    void a(cj cjVar);

    void a(cm cmVar);

    void a(SdkFlavor sdkFlavor);

    void a(String str);

    void a(Map<String, String> map);

    void b(String str);

    cj c();

    void c(String str);

    void d(String str);

    cm e();

    void e(String str);

    cl f();

    ca g();

    JSONObject h();

    boolean i();
}
