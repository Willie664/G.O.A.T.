package bo.app;

import com.appboy.models.InAppMessageBase;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public final class ey extends fi {
    private static final String b = AppboyLogger.getAppboyLogTag(ey.class);
    private String c;

    public ey(JSONObject jSONObject) {
        super(jSONObject);
        this.c = jSONObject.getJSONObject("data").getString("event_name");
    }

    public boolean a(ft ftVar) {
        if (!(ftVar instanceof fs)) {
            return false;
        }
        fs fsVar = (fs) ftVar;
        if (StringUtils.isNullOrBlank(fsVar.a()) || !fsVar.a().equals(this.c)) {
            return false;
        }
        return super.a(ftVar);
    }

    /* renamed from: a */
    public JSONObject forJsonPut() {
        JSONObject a = super.forJsonPut();
        try {
            a.put(InAppMessageBase.TYPE, "custom_event_property");
            JSONObject jSONObject = a.getJSONObject("data");
            jSONObject.put("event_name", this.c);
            a.put("data", jSONObject);
        } catch (JSONException e) {
            AppboyLogger.e(b, "Caught exception creating CustomEventWithPropertiesTriggerCondition Json.", e);
        }
        return a;
    }
}
