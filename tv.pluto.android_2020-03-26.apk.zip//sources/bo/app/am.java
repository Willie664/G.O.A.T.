package bo.app;

public class am {
    private final cf a;

    public am(cf cfVar) {
        this.a = cfVar;
    }

    public cf a() {
        return this.a;
    }
}
