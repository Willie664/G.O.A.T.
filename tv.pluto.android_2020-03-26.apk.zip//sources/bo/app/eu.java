package bo.app;

import android.content.Context;
import com.appboy.models.IInAppMessage;
import com.appboy.models.IInAppMessageHtml;
import com.appboy.models.InAppMessageBase;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class eu extends ew implements et {
    private static final String a = AppboyLogger.getAppboyLogTag(eu.class);
    private IInAppMessage b;
    private bt c;
    private String d;

    public eu(JSONObject jSONObject, bt btVar) {
        super(jSONObject);
        String str = a;
        AppboyLogger.d(str, "Parsing in-app message triggered action with JSON: " + JsonUtils.getPrettyPrintedString(jSONObject));
        JSONObject jSONObject2 = jSONObject.getJSONObject("data");
        if (jSONObject2 != null) {
            this.c = btVar;
            this.b = em.a(jSONObject2, this.c);
            return;
        }
        AppboyLogger.w(a, "InAppMessageTriggeredAction Json did not contain in-app message.");
    }

    public gj d() {
        if (StringUtils.isNullOrBlank(this.b.getRemoteAssetPathForPrefetch())) {
            return null;
        }
        if (this.b instanceof IInAppMessageHtml) {
            return new gj(fr.ZIP, this.b.getRemoteAssetPathForPrefetch());
        }
        return new gj(fr.IMAGE, this.b.getRemoteAssetPathForPrefetch());
    }

    public void a(String str) {
        this.d = str;
    }

    public void a(Context context, ac acVar, ft ftVar, long j) {
        try {
            String str = a;
            AppboyLogger.d(str, "Attempting to publish in-app message after delay of " + c().d() + " seconds.");
            if (!StringUtils.isNullOrBlank(this.d)) {
                this.b.setLocalAssetPathForPrefetch(this.d);
            }
            this.b.setExpirationTimestamp(j);
            acVar.a(new ai(this, this.b, this.c.e()), ai.class);
        } catch (Exception e) {
            AppboyLogger.w(a, "Caught exception while performing triggered action.", e);
        }
    }

    /* renamed from: f */
    public JSONObject forJsonPut() {
        try {
            JSONObject f = super.forJsonPut();
            f.put("data", this.b.forJsonPut());
            f.put(InAppMessageBase.TYPE, "inapp");
            return f;
        } catch (JSONException unused) {
            return null;
        }
    }
}
