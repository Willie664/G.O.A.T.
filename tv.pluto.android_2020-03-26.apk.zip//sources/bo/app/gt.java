package bo.app;

import java.util.HashSet;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public abstract class gt implements gv {
    public final gr a(JSONObject jSONObject, JSONObject jSONObject2) {
        gr grVar = new gr();
        c("", jSONObject, jSONObject2, grVar);
        return grVar;
    }

    public final gr a(JSONArray jSONArray, JSONArray jSONArray2) {
        gr grVar = new gr();
        e("", jSONArray, jSONArray2, grVar);
        return grVar;
    }

    /* access modifiers changed from: protected */
    public void a(String str, JSONObject jSONObject, JSONObject jSONObject2, gr grVar) {
        for (String next : gw.a(jSONObject2)) {
            if (!jSONObject.has(next)) {
                grVar.b(str, next);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void b(String str, JSONObject jSONObject, JSONObject jSONObject2, gr grVar) {
        for (String next : gw.a(jSONObject)) {
            Object obj = jSONObject.get(next);
            if (jSONObject2.has(next)) {
                a(gw.a(str, next), obj, jSONObject2.get(next), grVar);
            } else {
                grVar.a(str, next);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void a(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar) {
        String a = gw.a(jSONArray);
        if (a == null || !gw.a(a, jSONArray2)) {
            d(str, jSONArray, jSONArray2, grVar);
            return;
        }
        Map<Object, JSONObject> a2 = gw.a(jSONArray, a);
        Map<Object, JSONObject> a3 = gw.a(jSONArray2, a);
        for (Object next : a2.keySet()) {
            if (!a3.containsKey(next)) {
                grVar.a(gw.a(str, a, next), a2.get(next));
            } else {
                a(gw.a(str, a, next), a2.get(next), a3.get(next), grVar);
            }
        }
        for (Object next2 : a3.keySet()) {
            if (!a2.containsKey(next2)) {
                grVar.b(gw.a(str, a, next2), a3.get(next2));
            }
        }
    }

    /* access modifiers changed from: protected */
    public void b(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar) {
        Map<T, Integer> a = gw.a(gw.b(jSONArray));
        Map<T, Integer> a2 = gw.a(gw.b(jSONArray2));
        for (T next : a.keySet()) {
            if (!a2.containsKey(next)) {
                grVar.a(str + "[]", next);
            } else if (!a2.get(next).equals(a.get(next))) {
                grVar.a(str + "[]: Expected " + a.get(next) + " occurrence(s) of " + next + " but got " + a2.get(next) + " occurrence(s)");
            }
        }
        for (T next2 : a2.keySet()) {
            if (!a.containsKey(next2)) {
                grVar.b(str + "[]", next2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void c(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar) {
        for (int i = 0; i < jSONArray.length(); i++) {
            Object obj = jSONArray.get(i);
            Object obj2 = jSONArray2.get(i);
            a(str + "[" + i + "]", obj, obj2, grVar);
        }
    }

    /* access modifiers changed from: protected */
    public void d(String str, JSONArray jSONArray, JSONArray jSONArray2, gr grVar) {
        boolean z;
        HashSet hashSet = new HashSet();
        for (int i = 0; i < jSONArray.length(); i++) {
            Object obj = jSONArray.get(i);
            int i2 = 0;
            while (true) {
                z = true;
                if (i2 >= jSONArray2.length()) {
                    z = false;
                    break;
                }
                Object obj2 = jSONArray2.get(i2);
                if (!hashSet.contains(Integer.valueOf(i2)) && obj2.getClass().equals(obj.getClass())) {
                    if (obj instanceof JSONObject) {
                        if (a((JSONObject) obj, (JSONObject) obj2).a()) {
                            hashSet.add(Integer.valueOf(i2));
                            break;
                        }
                    } else if (obj instanceof JSONArray) {
                        if (a((JSONArray) obj, (JSONArray) obj2).a()) {
                            hashSet.add(Integer.valueOf(i2));
                            break;
                        }
                    } else if (obj.equals(obj2)) {
                        hashSet.add(Integer.valueOf(i2));
                        break;
                    }
                }
                i2++;
            }
            if (!z) {
                grVar.a(str + "[" + i + "] Could not find match for element " + obj);
                return;
            }
        }
    }
}
