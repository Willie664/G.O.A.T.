package bo.app;

import android.net.Uri;

public interface dg {
    Uri a();

    void a(ac acVar);

    void a(ac acVar, ac acVar2, cu cuVar);

    void a(ac acVar, cs csVar);

    void b(ac acVar);

    x j();
}
