package bo.app;

public interface t {
    void a(ac acVar, df dfVar);

    void a(cc ccVar);

    void a(cg cgVar);

    void b(cc ccVar);
}
