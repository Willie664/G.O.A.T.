package bo.app;

import android.app.Activity;
import android.os.Handler;
import bo.app.cl;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.models.outgoing.Feedback;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import com.appboy.support.ValidationUtils;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONException;
import org.json.JSONObject;

public class bn implements bt {
    private static final String a = AppboyLogger.getAppboyLogTag(bn.class);
    private AtomicInteger b = new AtomicInteger(0);
    private AtomicInteger c = new AtomicInteger(0);
    private volatile String d = "";
    private final Object e = new Object();
    private final Object f = new Object();
    private final bp g;
    private final bo h;
    private final t i;
    private final ac j;
    private final bu k;
    private final AppboyConfigurationProvider l;
    private final ea m;
    private final bj n;
    private final String o;
    private final dz p;
    private final Handler q;
    private boolean r = false;
    private Class<? extends Activity> s = null;

    public bn(bp bpVar, t tVar, ac acVar, bu buVar, AppboyConfigurationProvider appboyConfigurationProvider, ea eaVar, bj bjVar, String str, boolean z, bo boVar, dz dzVar) {
        this.g = bpVar;
        this.i = tVar;
        this.j = acVar;
        this.k = buVar;
        this.l = appboyConfigurationProvider;
        this.r = z;
        this.o = str;
        this.m = eaVar;
        this.n = bjVar;
        this.h = boVar;
        this.p = dzVar;
        this.q = ek.a();
    }

    public cf a() {
        if (this.p.a()) {
            AppboyLogger.w(a, "SDK is disabled. Returning null session.");
            return null;
        }
        cf a2 = this.g.a();
        String str = a;
        AppboyLogger.i(str, "Completed the openSession call. Starting or continuing session " + a2.a());
        return a2;
    }

    public cf a(Activity activity) {
        if (this.p.a()) {
            AppboyLogger.w(a, "SDK is disabled. Returning null session.");
            return null;
        }
        cf a2 = a();
        this.s = activity.getClass();
        this.h.a();
        String str = a;
        AppboyLogger.v(str, "Opened session with activity: " + activity.getLocalClassName());
        return a2;
    }

    public cf b(Activity activity) {
        if (this.p.a()) {
            AppboyLogger.w(a, "SDK is disabled. Returning null session.");
            return null;
        } else if (this.s != null && !activity.getClass().equals(this.s)) {
            return null;
        } else {
            this.h.b();
            String str = a;
            AppboyLogger.v(str, "Closed session with activity: " + activity.getLocalClassName());
            return this.g.b();
        }
    }

    public cg b() {
        return this.g.c();
    }

    public void c() {
        if (this.p.a()) {
            AppboyLogger.w(a, "SDK is disabled. Not force closing session.");
            return;
        }
        this.s = null;
        this.g.e();
    }

    public boolean a(cc ccVar) {
        boolean z = false;
        if (this.p.a()) {
            String str = a;
            AppboyLogger.w(str, "SDK is disabled. Not logging event: " + ccVar);
            return false;
        }
        synchronized (this.e) {
            if (ccVar != null) {
                if (this.g.d() || this.g.c() == null) {
                    String str2 = a;
                    AppboyLogger.d(str2, "Not adding session id to event: " + JsonUtils.getPrettyPrintedString((JSONObject) ccVar.forJsonPut()));
                    if (ccVar.b().equals(v.SESSION_START)) {
                        AppboyLogger.w(a, "Session start event logged without a Session ID.");
                    }
                    z = true;
                } else {
                    ccVar.a(this.g.c());
                }
                if (!StringUtils.isNullOrEmpty(e())) {
                    ccVar.a(e());
                } else {
                    String str3 = a;
                    AppboyLogger.d(str3, "Not adding user id to event: " + JsonUtils.getPrettyPrintedString((JSONObject) ccVar.forJsonPut()));
                }
                String str4 = a;
                AppboyLogger.v(str4, "Attempting to log event: " + JsonUtils.getPrettyPrintedString((JSONObject) ccVar.forJsonPut()));
                if (ccVar instanceof cp) {
                    AppboyLogger.d(a, "Publishing an internal push body clicked event for any awaiting triggers.");
                    a((cp) ccVar);
                }
                if (!ccVar.h()) {
                    this.n.a(ccVar);
                }
                if (a(z, ccVar)) {
                    AppboyLogger.d(a, "Adding push click to dispatcher pending list");
                    this.i.b(ccVar);
                } else {
                    this.i.a(ccVar);
                }
                if (ccVar.b().equals(v.SESSION_START)) {
                    this.i.a(ccVar.g());
                }
            } else {
                AppboyLogger.e(a, "Appboy manager received null event.");
                throw new NullPointerException();
            }
        }
        if (z) {
            this.q.removeCallbacksAndMessages((Object) null);
            this.q.postDelayed(new Runnable() {
                public void run() {
                    bn.this.d();
                }
            }, 1000);
        }
        return true;
    }

    public void a(Throwable th) {
        a(th, true);
    }

    public void b(Throwable th) {
        a(th, false);
    }

    public void a(String str, String str2, boolean z) {
        if (str == null || !ValidationUtils.isValidEmailAddress(str)) {
            throw new IllegalArgumentException("Reply to email address is invalid");
        } else if (!StringUtils.isNullOrBlank(str2)) {
            a((df) new dc(this.l.getBaseUrlForRequests(), new Feedback(str2, str, z, this.k.a(), e())));
        } else {
            throw new IllegalArgumentException("Feedback message cannot be null or blank");
        }
    }

    public void d() {
        a(new cl.a());
    }

    public void a(cl.a aVar) {
        if (aVar == null) {
            AppboyLogger.d(a, "Cannot request data sync with null respond with object");
            return;
        }
        ea eaVar = this.m;
        if (eaVar != null && eaVar.l()) {
            aVar.a(new ck(this.m.g()));
        }
        aVar.a(e());
        cl c2 = aVar.c();
        if (c2.c() && (c2.d() || c2.e())) {
            this.m.a(false);
        }
        a((df) new da(this.l.getBaseUrlForRequests(), c2));
    }

    public void a(cd cdVar) {
        AppboyLogger.d(a, "Posting geofence request for location.");
        a((df) new dd(this.l.getBaseUrlForRequests(), cdVar));
    }

    public void a(df dfVar) {
        if (this.p.a()) {
            AppboyLogger.w(a, "SDK is disabled. Not adding request to dispatch.");
        } else {
            this.i.a(this.j, dfVar);
        }
    }

    public void b(cc ccVar) {
        AppboyLogger.d(a, "Posting geofence report for geofence event.");
        a((df) new de(this.l.getBaseUrlForRequests(), ccVar));
    }

    public void a(ev evVar, ft ftVar) {
        a((df) new dk(this.l.getBaseUrlForRequests(), evVar, ftVar, this, e()));
    }

    public void a(ft ftVar) {
        this.j.a(new as(ftVar), as.class);
    }

    public void a(List<String> list, long j2) {
        a((df) new dl(this.l.getBaseUrlForRequests(), list, j2, this.o));
    }

    public void a(boolean z) {
        this.r = z;
    }

    public void a(long j2, long j3) {
        a((df) new cz(this.l.getBaseUrlForRequests(), j2, j3, this.o));
    }

    public String e() {
        return this.o;
    }

    private boolean c(Throwable th) {
        synchronized (this.f) {
            this.b.getAndIncrement();
            if (this.d.equals(th.getMessage()) && this.c.get() > 3 && this.b.get() < 100) {
                return true;
            }
            if (this.d.equals(th.getMessage())) {
                this.c.getAndIncrement();
            } else {
                this.c.set(0);
            }
            if (this.b.get() >= 100) {
                this.b.set(0);
            }
            this.d = th.getMessage();
            return false;
        }
    }

    private void a(Throwable th, boolean z) {
        try {
            if (c(th)) {
                String str = a;
                AppboyLogger.w(str, "Not logging duplicate error: " + th);
                return;
            }
            a((cc) cn.a(th, b(), z));
        } catch (JSONException e2) {
            String str2 = a;
            AppboyLogger.e(str2, "Failed to create error event from " + th, e2);
        } catch (Exception e3) {
            AppboyLogger.e(a, "Failed to log error.", e3);
        }
    }

    private static boolean a(boolean z, cc ccVar) {
        if (!z) {
            return false;
        }
        if (ccVar instanceof co) {
            return !((co) ccVar).n();
        }
        if ((ccVar instanceof cp) || (ccVar instanceof cq)) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void a(cp cpVar) {
        JSONObject c2 = cpVar.c();
        if (c2 != null) {
            this.j.a(new ar(c2.optString("cid", (String) null), cpVar), ar.class);
            return;
        }
        AppboyLogger.w(a, "Event json was null. Not publishing push clicked trigger event.");
    }
}
