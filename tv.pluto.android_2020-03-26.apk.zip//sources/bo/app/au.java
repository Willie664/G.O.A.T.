package bo.app;

import java.util.List;

public final class au {
    private final List<et> a;

    public au(List<et> list) {
        this.a = list;
    }

    public List<et> a() {
        return this.a;
    }
}
