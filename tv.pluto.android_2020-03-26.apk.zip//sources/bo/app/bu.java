package bo.app;

public interface bu {
    cj a();

    void a(String str);

    void a(boolean z);

    cj b();

    String c();

    String d();

    String e();
}
