package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class ew implements et {
    private static final String a = AppboyLogger.getAppboyLogTag(ew.class);
    private final String b;
    private final fn c;
    private final List<fa> d = new ArrayList();
    private boolean e;
    private gk f;

    protected ew(JSONObject jSONObject) {
        this.b = jSONObject.getString("id");
        this.c = new fp(jSONObject);
        JSONArray jSONArray = jSONObject.getJSONArray("trigger_condition");
        if (jSONArray != null && jSONArray.length() > 0) {
            this.d.addAll(gl.a(jSONArray));
        }
        this.e = jSONObject.optBoolean("prefetch", true);
    }

    public boolean a(ft ftVar) {
        if (!j()) {
            String str = a;
            AppboyLogger.d(str, "Triggered action " + this.b + "not eligible to be triggered by " + ftVar.b() + " event. Current device time outside triggered action time window.");
            return false;
        }
        for (fa a2 : this.d) {
            if (a2.a(ftVar)) {
                return true;
            }
        }
        return false;
    }

    public boolean a() {
        return this.e;
    }

    public fn c() {
        return this.c;
    }

    public String b() {
        return this.b;
    }

    public void a(gk gkVar) {
        this.f = gkVar;
    }

    public gk e() {
        return this.f;
    }

    /* renamed from: f */
    public JSONObject forJsonPut() {
        try {
            JSONObject jSONObject = (JSONObject) this.c.forJsonPut();
            jSONObject.put("id", this.b);
            if (this.d != null) {
                JSONArray jSONArray = new JSONArray();
                for (fa forJsonPut : this.d) {
                    jSONArray.put(forJsonPut.forJsonPut());
                }
                jSONObject.put("trigger_condition", jSONArray);
                jSONObject.put("prefetch", this.e);
            }
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean j() {
        return k() && l();
    }

    /* access modifiers changed from: package-private */
    public boolean k() {
        return this.c.a() == -1 || ee.a() > this.c.a();
    }

    /* access modifiers changed from: package-private */
    public boolean l() {
        return this.c.b() == -1 || ee.a() < this.c.b();
    }
}
