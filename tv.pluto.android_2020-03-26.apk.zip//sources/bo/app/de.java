package bo.app;

import android.net.Uri;
import com.appboy.support.AppboyLogger;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class de extends cx {
    private static final String b = AppboyLogger.getAppboyLogTag(de.class);
    private final cc c;

    public boolean i() {
        return false;
    }

    public de(String str, cc ccVar) {
        super(Uri.parse(str + "geofence/report"), (Map<String, String>) null);
        this.c = ccVar;
    }

    public x j() {
        return x.POST;
    }

    public void a(ac acVar, cs csVar) {
        AppboyLogger.d(b, "GeofenceReportRequest executed successfully.");
    }

    public JSONObject h() {
        JSONObject h = super.h();
        if (h == null) {
            return null;
        }
        try {
            if (this.c != null) {
                h.put("geofence_event", this.c.forJsonPut());
            }
            return h;
        } catch (JSONException e) {
            AppboyLogger.w(b, "Experienced JSONException while creating geofence report request. Returning null.", e);
            return null;
        }
    }
}
