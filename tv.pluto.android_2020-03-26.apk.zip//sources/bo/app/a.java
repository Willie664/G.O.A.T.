package bo.app;

import com.appboy.support.AppboyLogger;
import org.json.JSONException;

public class a implements c {
    private static final String a = AppboyLogger.getAppboyLogTag(a.class);

    public cc a(String str) {
        try {
            return cn.d(str);
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Failed to create Content Cards impression event for card: " + str, e);
            return null;
        }
    }

    /* renamed from: b */
    public cn e(String str) {
        try {
            return cn.f(str);
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Failed to create Content Cards click event for card: " + str, e);
            return null;
        }
    }

    public cc c(String str) {
        try {
            return cn.g(str);
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Failed to create Content Cards dismissed event for card: " + str, e);
            return null;
        }
    }

    public cc d(String str) {
        try {
            return cn.e(str);
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Failed to create Content Cards control impression event for card: " + str, e);
            return null;
        }
    }
}
