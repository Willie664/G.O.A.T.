package bo.app;

import com.appboy.models.IInAppMessage;
import com.appboy.models.InAppMessageBase;
import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class gl {
    private static final String a = AppboyLogger.getAppboyLogTag(gl.class);

    public static IInAppMessage a(JSONObject jSONObject, bt btVar) {
        if (jSONObject == null) {
            try {
                AppboyLogger.d(a, "Templated message Json was null. Not de-serializing templated message.");
                return null;
            } catch (JSONException e) {
                String str = a;
                AppboyLogger.w(str, "Encountered JSONException processing templated message: " + jSONObject, e);
                return null;
            } catch (Exception e2) {
                String str2 = a;
                AppboyLogger.w(str2, "Encountered general exception processing templated message: " + jSONObject, e2);
                return null;
            }
        } else {
            String string = jSONObject.getString(InAppMessageBase.TYPE);
            if (string.equals("inapp")) {
                return em.a(jSONObject.getJSONObject("data"), btVar);
            }
            String str3 = a;
            AppboyLogger.w(str3, "Received templated message Json with unknown type: " + string + ". Not parsing.");
            return null;
        }
    }

    public static List<et> a(JSONArray jSONArray, bt btVar) {
        if (jSONArray == null) {
            try {
                AppboyLogger.d(a, "Triggered actions Json array was null. Not de-serializing triggered actions.");
                return null;
            } catch (JSONException e) {
                String str = a;
                AppboyLogger.w(str, "Encountered JSONException processing triggered actions Json array: " + jSONArray, e);
                return null;
            } catch (Exception e2) {
                String str2 = a;
                AppboyLogger.w(str2, "Failed to deserialize triggered actions Json array: " + jSONArray, e2);
                return null;
            }
        } else {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                et b = b(jSONArray.getJSONObject(i), btVar);
                if (b != null) {
                    arrayList.add(b);
                }
            }
            return arrayList;
        }
    }

    public static et b(JSONObject jSONObject, bt btVar) {
        et evVar;
        try {
            String string = jSONObject.getString(InAppMessageBase.TYPE);
            if (string.equals("inapp")) {
                evVar = new eu(jSONObject, btVar);
            } else if (string.equals("templated_iam")) {
                evVar = new ev(jSONObject, btVar);
            } else {
                String str = a;
                AppboyLogger.i(str, "Received unknown trigger type: " + string);
                return null;
            }
            return evVar;
        } catch (JSONException e) {
            String str2 = a;
            AppboyLogger.w(str2, "Encountered JSONException processing triggered action Json: " + jSONObject, e);
            return null;
        } catch (Exception e2) {
            String str3 = a;
            AppboyLogger.w(str3, "Failed to deserialize triggered action Json: " + jSONObject, e2);
            return null;
        }
    }

    public static List<fa> a(JSONArray jSONArray) {
        if (jSONArray == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            if (optJSONObject == null) {
                AppboyLogger.w(a, "Received null or blank trigger condition Json. Not parsing.");
            } else {
                String string = optJSONObject.getString(InAppMessageBase.TYPE);
                if (string.equals("purchase")) {
                    arrayList.add(new fe(optJSONObject));
                } else if (string.equals("custom_event")) {
                    arrayList.add(new ex(optJSONObject));
                } else if (string.equals("push_click")) {
                    arrayList.add(new fg(optJSONObject));
                } else if (string.equals("open")) {
                    arrayList.add(new fc());
                } else if (string.equals("iam_click")) {
                    arrayList.add(new fb(optJSONObject));
                } else if (string.equals("test")) {
                    arrayList.add(new fh());
                } else if (string.equals("custom_event_property")) {
                    arrayList.add(new ey(optJSONObject));
                } else if (string.equals("purchase_property")) {
                    arrayList.add(new ff(optJSONObject));
                } else {
                    String str = a;
                    AppboyLogger.w(str, "Received triggered condition Json with unknown type: " + string + ". Not parsing.");
                }
            }
        }
        return arrayList;
    }
}
