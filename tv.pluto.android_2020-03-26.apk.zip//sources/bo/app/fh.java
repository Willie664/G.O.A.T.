package bo.app;

import com.appboy.models.InAppMessageBase;
import org.json.JSONException;
import org.json.JSONObject;

public final class fh implements fa {
    public boolean a(ft ftVar) {
        return ftVar instanceof fz;
    }

    /* renamed from: a */
    public JSONObject forJsonPut() {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(InAppMessageBase.TYPE, "test");
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }
}
