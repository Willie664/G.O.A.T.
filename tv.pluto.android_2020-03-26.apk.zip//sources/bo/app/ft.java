package bo.app;

public interface ft {
    String b();

    long c();

    long d();

    cc e();
}
