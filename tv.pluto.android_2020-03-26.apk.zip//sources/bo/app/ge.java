package bo.app;

import java.util.List;

public interface ge {
    void a(List<et> list);
}
