package bo.app;

import android.net.Uri;
import bo.app.cl;
import com.appboy.support.AppboyLogger;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class da extends cx {
    private static final String b = AppboyLogger.getAppboyLogTag(da.class);
    private final cl c;

    public void a(ac acVar, cs csVar) {
    }

    public da(String str) {
        this(str, new cl.a().c());
    }

    public da(String str, cl clVar) {
        super(Uri.parse(str + "data"), (Map<String, String>) null);
        this.c = clVar;
        a(clVar);
    }

    public x j() {
        return x.POST;
    }

    public boolean i() {
        return this.c.b() && super.i();
    }

    public void a(Map<String, String> map) {
        super.a(map);
        if (!this.c.b()) {
            boolean z = false;
            if (this.c.e()) {
                map.put("X-Braze-FeedRequest", "true");
                z = true;
            }
            if (this.c.d()) {
                map.put("X-Braze-TriggersRequest", "true");
                z = true;
            }
            if (z) {
                map.put("X-Braze-DataRequest", "true");
            }
        }
    }

    public JSONObject h() {
        JSONObject h = super.h();
        if (h == null) {
            return null;
        }
        try {
            if (!this.c.b()) {
                h.put("respond_with", this.c.forJsonPut());
            }
            return h;
        } catch (JSONException e) {
            AppboyLogger.w(b, "Experienced JSONException while retrieving parameters. Returning null.", e);
            return null;
        }
    }
}
