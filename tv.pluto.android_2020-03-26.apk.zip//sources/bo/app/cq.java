package bo.app;

import com.appboy.Constants;
import org.json.JSONObject;

public class cq extends cn {
    private cq(v vVar, JSONObject jSONObject) {
        super(vVar, jSONObject);
    }

    public static cq j(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("cid", str);
        jSONObject.put(Constants.APPBOY_PUSH_CONTENT_KEY, str2);
        return new cq(v.PUSH_STORY_PAGE_CLICK, jSONObject);
    }
}
