package bo.app;

public final class an {
    public static final an a = new an();
}
