package bo.app;

import java.util.List;

public final class fl extends fk implements ez {
    public fl(List<ez> list) {
        super(list);
    }

    public boolean a(ft ftVar) {
        for (ez a : this.a) {
            if (a.a(ftVar)) {
                return true;
            }
        }
        return false;
    }
}
