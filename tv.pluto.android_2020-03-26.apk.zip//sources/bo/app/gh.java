package bo.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.enums.inappmessage.InAppMessageFailureType;
import com.appboy.events.IEventSubscriber;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONException;
import org.json.JSONObject;

public class gh implements gd {
    private static final String a = AppboyLogger.getAppboyLogTag(gh.class);
    /* access modifiers changed from: private */
    public final Context b;
    private final bt c;
    /* access modifiers changed from: private */
    public final ab d;
    private final long e;
    private final SharedPreferences f;
    private final gc g;
    private final gf h;
    /* access modifiers changed from: private */
    public final AtomicInteger i;
    private final Queue<ft> j;
    private Map<String, et> k;
    private volatile long l = 0;
    private final Object m = new Object();

    public gh(Context context, bt btVar, ab abVar, AppboyConfigurationProvider appboyConfigurationProvider, String str, String str2) {
        this.b = context.getApplicationContext();
        this.c = btVar;
        this.d = abVar;
        this.e = appboyConfigurationProvider.getTriggerActionMinimumTimeIntervalInSeconds();
        this.f = context.getSharedPreferences("com.appboy.storage.triggers.actions" + StringUtils.getCacheFileSuffix(context, str, str2), 0);
        this.g = new gg(context, str2);
        this.h = new gi(context, str, str2);
        this.k = c();
        this.i = new AtomicInteger(0);
        this.j = new ArrayDeque();
        d();
    }

    public void a(List<et> list) {
        if (list == null) {
            AppboyLogger.w(a, "Received a null list of triggers in registerTriggeredActions(). Doing nothing.");
            return;
        }
        fz fzVar = new fz();
        boolean z = false;
        synchronized (this.m) {
            this.k.clear();
            SharedPreferences.Editor edit = this.f.edit();
            edit.clear();
            String str = a;
            AppboyLogger.d(str, "Registering " + list.size() + " new triggered actions.");
            for (et next : list) {
                String str2 = a;
                AppboyLogger.d(str2, "Registering triggered action id " + next.b());
                this.k.put(next.b(), next);
                edit.putString(next.b(), ((JSONObject) next.forJsonPut()).toString());
                if (next.a((ft) fzVar)) {
                    z = true;
                }
            }
            edit.apply();
        }
        this.h.a(list);
        this.g.a(list);
        if (z) {
            AppboyLogger.i(a, "Test triggered actions found, triggering test event.");
            a((ft) fzVar);
            return;
        }
        AppboyLogger.d(a, "No test triggered actions found.");
    }

    public void a(ft ftVar) {
        this.j.add(ftVar);
        if (this.i.get() == 0) {
            b();
        }
    }

    public gf a() {
        return this.h;
    }

    public void a(long j2) {
        this.l = j2;
    }

    public void a(ft ftVar, et etVar) {
        long j2;
        String str = a;
        AppboyLogger.d(str, "Trigger manager received failed triggered action with id: <" + etVar.b() + ">. Will attempt to perform fallback triggered actions, if present.");
        gk e2 = etVar.e();
        if (e2 == null) {
            AppboyLogger.d(a, "Triggered action has no trigger metadata and cannot fallback. Doing nothing");
            return;
        }
        final et a2 = e2.a();
        if (a2 == null) {
            AppboyLogger.d(a, "Triggered action has no fallback action to perform. Doing nothing");
            return;
        }
        a2.a(e2);
        a2.a(this.g.a(a2));
        long d2 = ftVar.d();
        fn c2 = a2.c();
        long e3 = (long) c2.e();
        long millis = TimeUnit.SECONDS.toMillis((long) c2.d());
        if (e3 != -1) {
            j2 = e3 + d2;
        } else {
            j2 = d2 + millis + TimeUnit.SECONDS.toMillis(30);
        }
        long j3 = j2;
        if (j3 < ee.c()) {
            String str2 = a;
            AppboyLogger.d(str2, "Fallback trigger has expired. Trigger id: " + a2.b());
            a(this.c, a2.b(), InAppMessageFailureType.INTERNAL_TIMEOUT_EXCEEDED);
            a(ftVar, a2);
            return;
        }
        long max = Math.max(0, (millis + d2) - ee.c());
        String str3 = a;
        AppboyLogger.d(str3, "Performing fallback triggered action with id: <" + a2.b() + "> with a ms delay: " + max);
        final ft ftVar2 = ftVar;
        final long j4 = j3;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                a2.a(gh.this.b, gh.this.d, ftVar2, j4);
            }
        }, max);
    }

    private void d() {
        AppboyLogger.v(a, "Subscribing to trigger dispatch events.");
        this.d.b(new IEventSubscriber<aq>() {
            /* renamed from: a */
            public void trigger(aq aqVar) {
                gh.this.i.incrementAndGet();
            }
        }, aq.class);
        this.d.b(new IEventSubscriber<ap>() {
            /* renamed from: a */
            public void trigger(ap apVar) {
                gh.this.i.decrementAndGet();
                gh.this.b();
            }
        }, ap.class);
    }

    private void c(ft ftVar) {
        String str = a;
        AppboyLogger.d(str, "New incoming <" + ftVar.b() + ">. Searching for matching triggers.");
        et b2 = b(ftVar);
        if (b2 != null) {
            b(ftVar, b2);
        }
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (this.i.get() <= 0) {
            AppboyLogger.d(a, "In flight trigger requests is empty. Executing any pending trigger events.");
            while (!this.j.isEmpty()) {
                c(this.j.poll());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public et b(ft ftVar) {
        synchronized (this.m) {
            ArrayList arrayList = new ArrayList();
            et etVar = null;
            int i2 = Integer.MIN_VALUE;
            for (et next : this.k.values()) {
                if (next.a(ftVar) && this.h.a(next)) {
                    if (a(ftVar, next, this.l, this.e)) {
                        AppboyLogger.d(a, "Found potential triggered action for incoming trigger event. Action id " + next.b() + ".");
                        int c2 = next.c().c();
                        if (c2 > i2) {
                            etVar = next;
                            i2 = c2;
                        }
                        arrayList.add(next);
                    }
                }
            }
            if (etVar == null) {
                AppboyLogger.d(a, "Failed to match triggered action for incoming <" + ftVar.b() + ">.");
                return null;
            }
            arrayList.remove(etVar);
            etVar.a(new gk(arrayList));
            String str = a;
            StringBuilder sb = new StringBuilder();
            sb.append("Found best triggered action for incoming trigger event ");
            sb.append(ftVar.e() != null ? JsonUtils.getPrettyPrintedString((JSONObject) ftVar.e().forJsonPut()) : "");
            sb.append(".\nMatched Action id: ");
            sb.append(etVar.b());
            sb.append(".");
            AppboyLogger.d(str, sb.toString());
            return etVar;
        }
    }

    /* access modifiers changed from: package-private */
    public Map<String, et> c() {
        Set<String> keySet;
        HashMap hashMap = new HashMap();
        Map<String, ?> all = this.f.getAll();
        if (!(all == null || all.size() == 0 || (keySet = all.keySet()) == null || keySet.size() == 0)) {
            try {
                for (String next : keySet) {
                    String string = this.f.getString(next, (String) null);
                    if (StringUtils.isNullOrBlank(string)) {
                        String str = a;
                        AppboyLogger.w(str, "Received null or blank serialized triggered action string for action id " + next + " from shared preferences. Not parsing.");
                    } else {
                        et b2 = gl.b(new JSONObject(string), this.c);
                        if (b2 != null) {
                            hashMap.put(b2.b(), b2);
                            String str2 = a;
                            AppboyLogger.d(str2, "Retrieving templated triggered action id " + b2.b() + " from local storage.");
                        }
                    }
                }
            } catch (JSONException e2) {
                AppboyLogger.e(a, "Encountered Json exception while parsing stored triggered actions.", e2);
            } catch (Exception e3) {
                AppboyLogger.e(a, "Encountered unexpected exception while parsing stored triggered actions.", e3);
            }
        }
        return hashMap;
    }

    /* access modifiers changed from: package-private */
    public void b(ft ftVar, et etVar) {
        etVar.a(this.g.a(etVar));
        fn c2 = etVar.c();
        final long d2 = c2.e() != -1 ? ftVar.d() + ((long) c2.e()) : -1;
        Handler handler = new Handler(Looper.getMainLooper());
        int d3 = c2.d();
        String str = a;
        AppboyLogger.d(str, "Performing triggered action after a delay of " + d3 + " seconds.");
        final et etVar2 = etVar;
        final ft ftVar2 = ftVar;
        handler.postDelayed(new Runnable() {
            public void run() {
                etVar2.a(gh.this.b, gh.this.d, ftVar2, d2);
            }
        }, (long) (d3 * 1000));
    }

    static boolean a(ft ftVar, et etVar, long j2, long j3) {
        long j4;
        if (ftVar instanceof fz) {
            AppboyLogger.d(a, "Ignoring minimum time interval between triggered actions because the trigger event is a test.");
            return true;
        }
        long a2 = ee.a() + ((long) etVar.c().d());
        int g2 = etVar.c().g();
        if (g2 != -1) {
            String str = a;
            AppboyLogger.d(str, "Using override minimum display interval: " + g2);
            j4 = j2 + ((long) g2);
        } else {
            j4 = j2 + j3;
        }
        if (a2 >= j4) {
            String str2 = a;
            AppboyLogger.i(str2, "Minimum time interval requirement met for matched trigger. Action display time: " + a2 + " . Next viable display time: " + j4);
            return true;
        }
        String str3 = a;
        AppboyLogger.i(str3, "Minimum time interval requirement and triggered action override time interval requirement of " + j3 + " not met for matched trigger. Returning null. Next viable display time: " + j4 + ". Action display time: " + a2);
        return false;
    }

    static void a(bt btVar, String str, InAppMessageFailureType inAppMessageFailureType) {
        String str2 = a;
        AppboyLogger.i(str2, "Trigger internal timeout exceeded. Attempting to log trigger failure: " + inAppMessageFailureType);
        if (StringUtils.isNullOrBlank(str)) {
            String str3 = a;
            AppboyLogger.d(str3, "Trigger ID is null or blank. Not logging trigger failure: " + inAppMessageFailureType);
        } else if (btVar == null) {
            String str4 = a;
            AppboyLogger.e(str4, "Cannot log an trigger failure because the IAppboyManager is null. Trigger failure: " + inAppMessageFailureType);
        } else {
            try {
                btVar.a((cc) cn.a((String) null, str, inAppMessageFailureType));
            } catch (JSONException e2) {
                AppboyLogger.i(a, "Failed to log trigger failure event from trigger manager.", (Throwable) e2);
                btVar.a((Throwable) e2);
            }
        }
    }
}
