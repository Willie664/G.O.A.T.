package bo.app;

import com.appboy.events.ContentCardsUpdatedEvent;
import com.appboy.events.FeedUpdatedEvent;
import com.appboy.models.IInAppMessage;
import com.appboy.support.AppboyLogger;
import java.net.URI;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class cy implements Runnable {
    private static final String a = AppboyLogger.getAppboyLogTag(cy.class);
    private final df b;
    private final ac c;
    private final ac d;
    private final Map<String, String> e;
    private final g f;
    private final du g;
    private final ea h;
    private final dq i;
    private final bt j;

    public cy(df dfVar, d dVar, g gVar, ac acVar, ac acVar2, du duVar, bt btVar, ea eaVar, dq dqVar) {
        this.b = dfVar;
        this.c = acVar;
        this.d = acVar2;
        this.e = dVar.a();
        this.b.a(this.e);
        this.f = gVar;
        this.g = duVar;
        this.j = btVar;
        this.h = eaVar;
        this.i = dqVar;
    }

    public void run() {
        try {
            cs a2 = a();
            if (a2 != null) {
                a(a2);
                this.c.a(new ag(this.b), ag.class);
                this.c.a(new ae(this.b), ae.class);
                this.b.b(this.c);
                return;
            }
            AppboyLogger.w(a, "Api response was null, failing task.");
            this.b.b(this.c);
            this.b.a(this.c, this.d, new cv("An error occurred during request processing, resulting in no valid response being received. Check the error log for more details."));
            this.c.a(new ad(this.b), ad.class);
        } catch (Exception e2) {
            if (e2 instanceof av) {
                String str = a;
                AppboyLogger.d(str, "Experienced network communication exception processing API response. Sending network error event. " + e2.getMessage(), (Throwable) e2);
                this.c.a(new af(this.b), af.class);
            }
            AppboyLogger.w(a, "Experienced exception processing API response. Failing task.", e2);
        } catch (Throwable th) {
            this.b.b(this.c);
            throw th;
        }
    }

    /* renamed from: bo.app.cy$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a = new int[x.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0014 */
        static {
            /*
                bo.app.x[] r0 = bo.app.x.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                a = r0
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x0014 }
                bo.app.x r1 = bo.app.x.GET     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                int[] r0 = a     // Catch:{ NoSuchFieldError -> 0x001f }
                bo.app.x r1 = bo.app.x.POST     // Catch:{ NoSuchFieldError -> 0x001f }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: bo.app.cy.AnonymousClass1.<clinit>():void");
        }
    }

    /* access modifiers changed from: package-private */
    public cs a() {
        URI a2 = el.a(this.b.a());
        int i2 = AnonymousClass1.a[this.b.j().ordinal()];
        if (i2 == 1) {
            return new cs(this.f.a(a2, this.e), this.b, this.j);
        }
        if (i2 != 2) {
            String str = a;
            AppboyLogger.w(str, "Received a request with an unknown Http verb: [" + this.b.j() + "]");
            return null;
        }
        JSONObject h2 = this.b.h();
        if (h2 != null) {
            return new cs(this.f.a(a2, this.e, h2), this.b, this.j);
        }
        AppboyLogger.e(a, "Could not parse request parameters for put request to [%s], cancelling request.");
        return null;
    }

    /* access modifiers changed from: package-private */
    public void a(cs csVar) {
        if (!csVar.e()) {
            this.b.a(this.d, csVar);
        } else {
            a(csVar.n());
            this.b.a(this.c, this.d, csVar.n());
        }
        b(csVar);
    }

    /* access modifiers changed from: package-private */
    public void b(cs csVar) {
        String e2 = this.j.e();
        if (csVar.a()) {
            try {
                FeedUpdatedEvent a2 = this.g.a(csVar.h(), e2);
                if (a2 != null) {
                    this.d.a(a2, FeedUpdatedEvent.class);
                }
            } catch (JSONException unused) {
                AppboyLogger.w(a, "Unable to update/publish feed.");
            }
        }
        if (csVar.g()) {
            try {
                ContentCardsUpdatedEvent a3 = this.i.a(csVar.m(), e2);
                if (a3 != null) {
                    this.d.a(a3, ContentCardsUpdatedEvent.class);
                }
            } catch (JSONException e3) {
                AppboyLogger.e(a, "Encountered JSON exception while parsing Content Cards update. Unable to publish Content Cards update event.", e3);
            }
        }
        if (csVar.c()) {
            this.h.a(csVar.j());
            this.c.a(new ak(csVar.j()), ak.class);
        }
        if (csVar.d()) {
            this.c.a(new au(csVar.k()), au.class);
        }
        if (csVar.b()) {
            df dfVar = this.b;
            if (dfVar instanceof dk) {
                dk dkVar = (dk) dfVar;
                IInAppMessage i2 = csVar.i();
                i2.setExpirationTimestamp(dkVar.l());
                this.c.a(new ai(dkVar.m(), i2, e2), ai.class);
            }
        }
        if (csVar.f()) {
            this.c.a(new ah(csVar.l()), ah.class);
        }
    }

    private void a(cu cuVar) {
        String str = a;
        AppboyLogger.e(str, "Received server error from request: " + cuVar.a());
    }
}
