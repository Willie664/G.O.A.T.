package bo.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import com.appboy.Appboy;
import com.appboy.support.AppboyLogger;
import java.util.concurrent.TimeUnit;

public class bp {
    static final long a = TimeUnit.SECONDS.toMillis(10);
    /* access modifiers changed from: private */
    public static final String b = AppboyLogger.getAppboyLogTag(bp.class);
    private static final long c = TimeUnit.SECONDS.toMillis(10);
    /* access modifiers changed from: private */
    public final Object d = new Object();
    private final dx e;
    /* access modifiers changed from: private */
    public final ac f;
    private final Context g;
    private final AlarmManager h;
    private final int i;
    private final String j;
    private final ea k;
    private volatile cf l;
    private final Handler m;
    private final Runnable n;
    private final boolean o;

    public bp(final Context context, dx dxVar, ac acVar, AlarmManager alarmManager, ea eaVar, int i2, boolean z) {
        this.e = dxVar;
        this.f = acVar;
        this.g = context;
        this.h = alarmManager;
        this.i = i2;
        this.k = eaVar;
        this.m = ek.a();
        this.n = new Runnable() {
            public void run() {
                AppboyLogger.d(bp.b, "Requesting data flush on internal session close flush timer.");
                Appboy.getInstance(context).requestImmediateDataFlush();
            }
        };
        this.o = z;
        AnonymousClass2 r3 = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                new Thread(new a(goAsync())).start();
            }
        };
        this.j = context.getPackageName() + ".intent.APPBOY_SESSION_SHOULD_SEAL";
        context.registerReceiver(r3, new IntentFilter(this.j));
    }

    public cf a() {
        cf cfVar;
        synchronized (this.d) {
            if (i()) {
                this.e.a(this.l);
            }
            g();
            l();
            this.f.a(an.a, an.class);
            cfVar = this.l;
        }
        return cfVar;
    }

    public cf b() {
        cf cfVar;
        synchronized (this.d) {
            i();
            this.l.a(Double.valueOf(ee.b()));
            this.e.a(this.l);
            f();
            a(b(this.l, this.i, this.o));
            this.f.a(ao.a, ao.class);
            cfVar = this.l;
        }
        return cfVar;
    }

    public cg c() {
        synchronized (this.d) {
            k();
            if (this.l == null) {
                return null;
            }
            cg a2 = this.l.a();
            return a2;
        }
    }

    public boolean d() {
        boolean z;
        synchronized (this.d) {
            z = this.l != null && this.l.d();
        }
        return z;
    }

    public void e() {
        synchronized (this.d) {
            if (this.l != null) {
                this.l.e();
                this.e.a(this.l);
                this.f.a(new am(this.l), am.class);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0054, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean i() {
        /*
            r6 = this;
            java.lang.Object r0 = r6.d
            monitor-enter(r0)
            r6.k()     // Catch:{ all -> 0x0055 }
            bo.app.cf r1 = r6.l     // Catch:{ all -> 0x0055 }
            r2 = 1
            if (r1 == 0) goto L_0x0027
            bo.app.cf r1 = r6.l     // Catch:{ all -> 0x0055 }
            boolean r1 = r1.d()     // Catch:{ all -> 0x0055 }
            if (r1 == 0) goto L_0x0014
            goto L_0x0027
        L_0x0014:
            bo.app.cf r1 = r6.l     // Catch:{ all -> 0x0055 }
            java.lang.Double r1 = r1.c()     // Catch:{ all -> 0x0055 }
            if (r1 == 0) goto L_0x0024
            bo.app.cf r1 = r6.l     // Catch:{ all -> 0x0055 }
            r3 = 0
            r1.a(r3)     // Catch:{ all -> 0x0055 }
            monitor-exit(r0)     // Catch:{ all -> 0x0055 }
            return r2
        L_0x0024:
            r1 = 0
            monitor-exit(r0)     // Catch:{ all -> 0x0055 }
            return r1
        L_0x0027:
            bo.app.cf r1 = r6.l     // Catch:{ all -> 0x0055 }
            r6.j()     // Catch:{ all -> 0x0055 }
            if (r1 == 0) goto L_0x0053
            boolean r3 = r1.d()     // Catch:{ all -> 0x0055 }
            if (r3 == 0) goto L_0x0053
            java.lang.String r3 = b     // Catch:{ all -> 0x0055 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0055 }
            r4.<init>()     // Catch:{ all -> 0x0055 }
            java.lang.String r5 = "Clearing completely dispatched sealed session "
            r4.append(r5)     // Catch:{ all -> 0x0055 }
            bo.app.cg r5 = r1.a()     // Catch:{ all -> 0x0055 }
            r4.append(r5)     // Catch:{ all -> 0x0055 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0055 }
            com.appboy.support.AppboyLogger.d(r3, r4)     // Catch:{ all -> 0x0055 }
            bo.app.dx r3 = r6.e     // Catch:{ all -> 0x0055 }
            r3.b(r1)     // Catch:{ all -> 0x0055 }
        L_0x0053:
            monitor-exit(r0)     // Catch:{ all -> 0x0055 }
            return r2
        L_0x0055:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0055 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.bp.i():boolean");
    }

    private void j() {
        this.l = new cf(cg.a(), ee.b());
        String str = b;
        AppboyLogger.i(str, "New session created with ID: " + this.l.a());
        this.k.a(true);
        this.f.a(new al(this.l), al.class);
    }

    /* access modifiers changed from: private */
    public void k() {
        synchronized (this.d) {
            if (this.l == null) {
                this.l = this.e.a();
                if (this.l != null) {
                    String str = b;
                    AppboyLogger.d(str, "Restored session from offline storage: " + this.l.a().toString());
                }
            }
            if (this.l != null && this.l.c() != null && !this.l.d() && a(this.l, this.i, this.o)) {
                String str2 = b;
                AppboyLogger.i(str2, "Session [" + this.l.a() + "] being sealed because its end time is over the grace period.");
                e();
                this.e.b(this.l);
                this.l = null;
            }
        }
    }

    private void a(long j2) {
        String str = b;
        AppboyLogger.d(str, "Creating a session seal alarm with a delay of " + j2 + " ms");
        Intent intent = new Intent(this.j);
        intent.putExtra("session_id", this.l.toString());
        this.h.set(1, ee.c() + j2, PendingIntent.getBroadcast(this.g, 0, intent, 1073741824));
    }

    private void l() {
        Intent intent = new Intent(this.j);
        intent.putExtra("session_id", this.l.toString());
        this.h.cancel(PendingIntent.getBroadcast(this.g, 0, intent, 1073741824));
    }

    static boolean a(cf cfVar, int i2, boolean z) {
        long c2 = ee.c();
        long millis = TimeUnit.SECONDS.toMillis((long) i2);
        long millis2 = TimeUnit.SECONDS.toMillis(cfVar.c().longValue());
        long millis3 = TimeUnit.SECONDS.toMillis((long) cfVar.b());
        if (z) {
            if (millis3 + millis + a <= c2) {
                return true;
            }
            return false;
        } else if (millis2 + millis <= c2) {
            return true;
        } else {
            return false;
        }
    }

    static long b(cf cfVar, int i2, boolean z) {
        long millis = TimeUnit.SECONDS.toMillis((long) i2);
        if (!z) {
            return millis;
        }
        long millis2 = TimeUnit.SECONDS.toMillis((long) cfVar.b());
        return Math.max(a, (millis2 + millis) - ee.c());
    }

    /* access modifiers changed from: protected */
    public void f() {
        g();
        this.m.postDelayed(this.n, c);
    }

    /* access modifiers changed from: protected */
    public void g() {
        this.m.removeCallbacks(this.n);
    }

    class a implements Runnable {
        private final BroadcastReceiver.PendingResult b;

        a(BroadcastReceiver.PendingResult pendingResult) {
            this.b = pendingResult;
        }

        public void run() {
            try {
                a();
            } catch (Exception e) {
                AppboyLogger.e(bp.b, "Caught exception while sealing the session.", e);
            }
            this.b.finish();
        }

        private void a() {
            synchronized (bp.this.d) {
                try {
                    bp.this.k();
                } catch (Exception e) {
                    try {
                        bp.this.f.a(e, Throwable.class);
                    } catch (Exception e2) {
                        AppboyLogger.e(bp.b, "Failed to log throwable.", e2);
                    }
                }
            }
        }
    }
}
