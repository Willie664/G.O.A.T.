package bo.app;

public class gn {
    private final String a;
    private final Object b;
    private final Object c;

    public gn(String str, Object obj, Object obj2) {
        this.a = str;
        this.b = obj;
        this.c = obj2;
    }
}
