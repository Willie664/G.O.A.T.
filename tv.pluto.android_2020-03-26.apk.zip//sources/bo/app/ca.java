package bo.app;

import java.util.Set;

public class ca implements ce {
    private final Set<cc> a;

    public ca(Set<cc> set) {
        this.a = set;
    }

    public Set<cc> a() {
        return this.a;
    }

    public boolean b() {
        Set<cc> set = this.a;
        return set != null && set.isEmpty();
    }
}
