package bo.app;

public interface bw {
    boolean a();

    boolean a(cd cdVar);
}
