package bo.app;

import com.appboy.models.IInAppMessage;
import com.appboy.support.JsonUtils;
import org.json.JSONObject;

public final class ai {
    private final IInAppMessage a;
    private final String b;
    private final et c;

    public ai(et etVar, IInAppMessage iInAppMessage, String str) {
        this.b = str;
        if (iInAppMessage != null) {
            this.a = iInAppMessage;
            this.c = etVar;
            return;
        }
        throw new NullPointerException();
    }

    public et a() {
        return this.c;
    }

    public IInAppMessage b() {
        return this.a;
    }

    public String c() {
        return this.b;
    }

    public String toString() {
        return JsonUtils.getPrettyPrintedString((JSONObject) this.a.forJsonPut()) + "\nTriggered Action Id: " + this.c.b() + "\nUser Id: " + this.b;
    }
}
