package bo.app;

public final class al {
    public al(cf cfVar) {
        if (cfVar == null) {
            throw new IllegalArgumentException("Session created events cannot be created without a session available.");
        } else if (cfVar.d()) {
            throw new IllegalArgumentException("Session created events cannot be created with already sealed sessions.");
        }
    }
}
