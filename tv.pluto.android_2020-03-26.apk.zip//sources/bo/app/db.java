package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.List;

public class db implements dh {
    private static final String a = AppboyLogger.getAppboyLogTag(db.class);
    private static final List<df> b = new ArrayList();
    private static boolean c = false;
    private final ac d;

    public db(ac acVar) {
        this.d = acVar;
    }

    public void a(dg dgVar) {
        c(dgVar);
    }

    public void b(dg dgVar) {
        c(dgVar);
    }

    private void c(dg dgVar) {
        AppboyLogger.i(a, "Short circuiting execution of network request and immediately marking it as succeeded.", false);
        dgVar.a(this.d, (cs) null);
        dgVar.b(this.d);
        if (dgVar instanceof df) {
            this.d.a(new ae((df) dgVar), ae.class);
        }
    }
}
