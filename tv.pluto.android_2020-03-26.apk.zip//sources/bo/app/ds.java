package bo.app;

import com.appboy.support.AppboyLogger;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ds implements dv {
    private static final String a = AppboyLogger.getAppboyLogTag(ds.class);
    private final dv b;
    private final ac c;
    private boolean d = false;

    public ds(dv dvVar, ac acVar) {
        this.b = dvVar;
        this.c = acVar;
    }

    public void a(cc ccVar) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding event: " + ccVar);
            return;
        }
        try {
            this.b.a(ccVar);
        } catch (Exception e) {
            String str2 = a;
            AppboyLogger.e(str2, "Failed to insert event into storage. " + ccVar, e);
            a(this.c, e);
        }
    }

    public void a(List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not adding events: " + list);
            return;
        }
        try {
            this.b.a(list);
        } catch (Exception e) {
            String str2 = a;
            AppboyLogger.e(str2, "Failed to insert events into storage. " + list, e);
            a(this.c, e);
        }
    }

    public void b(List<cc> list) {
        if (this.d) {
            String str = a;
            AppboyLogger.w(str, "Storage provider is closed. Not deleting event: " + list);
            return;
        }
        try {
            this.b.b(list);
        } catch (Exception e) {
            String str2 = a;
            AppboyLogger.e(str2, "Failed to delete events from storage. " + list, e);
            a(this.c, e);
        }
    }

    public Collection<cc> a() {
        if (this.d) {
            AppboyLogger.w(a, "Storage provider is closed. Not getting all events.");
            return Collections.emptyList();
        }
        try {
            return this.b.a();
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to get all events from storage.", e);
            a(this.c, e);
            return Collections.emptyList();
        }
    }

    public void b() {
        AppboyLogger.w(a, "Setting this provider and internal storage provider to closed.");
        this.d = true;
        this.b.b();
    }

    private void a(ac acVar, Throwable th) {
        try {
            acVar.a(new aw("A storage exception has occurred. Please view the stack trace for more details.", th), aw.class);
        } catch (Exception e) {
            AppboyLogger.e(a, "Failed to log throwable.", e);
        }
    }
}
