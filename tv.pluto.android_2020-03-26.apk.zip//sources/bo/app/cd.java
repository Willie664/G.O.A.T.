package bo.app;

import com.appboy.models.IPutIntoJson;
import org.json.JSONObject;

public interface cd extends IPutIntoJson<JSONObject> {
    double a();

    double b();
}
