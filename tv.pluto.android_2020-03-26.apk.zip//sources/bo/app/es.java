package bo.app;

import android.app.AlarmManager;
import android.content.Context;
import androidx.core.app.NotificationCompat;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;
import java.util.concurrent.ThreadPoolExecutor;

public final class es {
    /* access modifiers changed from: private */
    public static final String a = AppboyLogger.getAppboyLogTag(es.class);
    /* access modifiers changed from: private */
    public final ed b;
    /* access modifiers changed from: private */
    public final dr c;
    /* access modifiers changed from: private */
    public final ab d;
    /* access modifiers changed from: private */
    public final n e;
    private final bn f;
    private final du g;
    private final aa h;
    private final ba i;
    private final d j;
    /* access modifiers changed from: private */
    public final q k;
    private final bp l;
    private final bw m;
    private final gh n;
    private final ea o;
    private final bk p;
    private final bj q;
    private final dq r;
    private final bu s;

    public es(Context context, l lVar, AppboyConfigurationProvider appboyConfigurationProvider, ac acVar, bi biVar, bx bxVar, boolean z, boolean z2, bz bzVar) {
        Cdo doVar;
        Context context2 = context;
        AppboyConfigurationProvider appboyConfigurationProvider2 = appboyConfigurationProvider;
        String a2 = lVar.a();
        String chVar = appboyConfigurationProvider.getAppboyApiKey().toString();
        dz dzVar = new dz(context2);
        ax axVar = new ax();
        this.i = new ba("user_dependency_manager_parallel_executor_identifier", axVar);
        this.d = new ab(this.i, dzVar);
        this.o = new ea(context2, chVar);
        if (a2.equals("")) {
            this.b = new ed(context2, bxVar, this.o, dzVar);
            this.c = new dr(context2);
            doVar = Cdo.a(context2, (String) null, chVar);
        } else {
            this.b = new ed(context, a2, chVar, bxVar, this.o, dzVar);
            this.c = new dr(context2, a2, chVar);
            doVar = Cdo.a(context2, a2, chVar);
        }
        this.s = new bq(context2, appboyConfigurationProvider2, biVar, this.c);
        this.j = new d();
        r rVar = new r(this.b, this.s, appboyConfigurationProvider2);
        dt dtVar = new dt(new ec(context2, a2, chVar), this.d);
        bb bbVar = new bb("user_dependency_manager_database_serial_identifier", axVar);
        axVar.a(new az(this.d));
        this.q = new bj(a(context2, a2, chVar), a(doVar, bbVar));
        AlarmManager alarmManager = (AlarmManager) context2.getSystemService(NotificationCompat.CATEGORY_ALARM);
        dz dzVar2 = dzVar;
        bp bpVar = r1;
        bb bbVar2 = bbVar;
        bp bpVar2 = new bp(context, dtVar, this.d, alarmManager, this.o, appboyConfigurationProvider.getSessionTimeoutSeconds(), appboyConfigurationProvider.getIsSessionStartBasedTimeoutEnabled());
        this.l = bpVar;
        this.g = new du(context2, a2);
        this.r = new dq(context2, a2, chVar);
        dj djVar = new dj(this.j, e.a(), this.d, acVar, this.i, this.g, this.o, this.r);
        this.k = new q(context, this.d, new o(), alarmManager, new p(context2), a2);
        this.k.a(this.d);
        this.k.a(z2);
        ax axVar2 = axVar;
        n nVar = r1;
        n nVar2 = new n(appboyConfigurationProvider, this.d, djVar, rVar, axVar2, z);
        this.e = nVar;
        bo boVar = new bo(context2, this.d, this.o);
        bp bpVar3 = this.l;
        n nVar3 = this.e;
        ab abVar = this.d;
        bu buVar = this.s;
        String str = chVar;
        String str2 = a2;
        bu buVar2 = buVar;
        AppboyConfigurationProvider appboyConfigurationProvider3 = appboyConfigurationProvider2;
        this.f = new bn(bpVar3, nVar3, abVar, buVar2, appboyConfigurationProvider, this.o, this.q, str2, z2, boVar, dzVar2);
        Context context3 = context;
        AppboyConfigurationProvider appboyConfigurationProvider4 = appboyConfigurationProvider3;
        AppboyConfigurationProvider appboyConfigurationProvider5 = appboyConfigurationProvider;
        this.n = new gh(context3, this.f, this.d, appboyConfigurationProvider5, str2, str);
        this.p = new bk(context3, str, this.f, appboyConfigurationProvider5, this.o);
        if (!z && (djVar instanceof dj)) {
            djVar.a((bt) this.f);
        }
        this.g.a(this.f);
        this.r.a(this.f);
        this.i.a((bt) this.f);
        bbVar2.a((bt) this.f);
        this.m = new bm(context2, this.f, appboyConfigurationProvider4);
        bw bwVar = this.m;
        n nVar4 = this.e;
        bn bnVar = this.f;
        ed edVar = this.b;
        dr drVar = this.c;
        ea eaVar = this.o;
        gh ghVar = this.n;
        this.h = new aa(context, bwVar, nVar4, bnVar, edVar, drVar, eaVar, ghVar, ghVar.a(), this.q, this.p, bzVar, acVar);
    }

    public ea a() {
        return this.o;
    }

    public q b() {
        return this.k;
    }

    public aa c() {
        return this.h;
    }

    public bn d() {
        return this.f;
    }

    public n e() {
        return this.e;
    }

    public ab f() {
        return this.d;
    }

    public ed g() {
        return this.b;
    }

    public ThreadPoolExecutor h() {
        return this.i;
    }

    public du i() {
        return this.g;
    }

    public bw j() {
        return this.m;
    }

    public bj k() {
        return this.q;
    }

    public gh l() {
        return this.n;
    }

    public bk m() {
        return this.p;
    }

    public dq n() {
        return this.r;
    }

    public bu o() {
        return this.s;
    }

    public void p() {
        this.i.execute(new Runnable() {
            /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
                java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
                	at java.util.ArrayList.rangeCheck(ArrayList.java:657)
                	at java.util.ArrayList.get(ArrayList.java:433)
                	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
                	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
                	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
                	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
                	at jadx.core.dex.visitors.regions.RegionMaker.processExcHandler(RegionMaker.java:1043)
                	at jadx.core.dex.visitors.regions.RegionMaker.processTryCatchBlocks(RegionMaker.java:975)
                	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:52)
                */
            public void run() {
                /*
                    r3 = this;
                    bo.app.es r0 = bo.app.es.this     // Catch:{ Exception -> 0x0074 }
                    bo.app.ed r0 = r0.b     // Catch:{ Exception -> 0x0074 }
                    monitor-enter(r0)     // Catch:{ Exception -> 0x0074 }
                    bo.app.es r1 = bo.app.es.this     // Catch:{ all -> 0x0071 }
                    bo.app.ed r1 = r1.b     // Catch:{ all -> 0x0071 }
                    boolean r1 = r1.c()     // Catch:{ all -> 0x0071 }
                    if (r1 == 0) goto L_0x002e
                    java.lang.String r1 = bo.app.es.a     // Catch:{ all -> 0x0071 }
                    java.lang.String r2 = "User cache was locked, waiting."
                    com.appboy.support.AppboyLogger.i(r1, r2)     // Catch:{ all -> 0x0071 }
                    bo.app.es r1 = bo.app.es.this     // Catch:{ InterruptedException -> 0x002e }
                    bo.app.ed r1 = r1.b     // Catch:{ InterruptedException -> 0x002e }
                    r1.wait()     // Catch:{ InterruptedException -> 0x002e }
                    java.lang.String r1 = bo.app.es.a     // Catch:{ InterruptedException -> 0x002e }
                    java.lang.String r2 = "User cache notified. Continuing UserDependencyManager shutdown"
                    com.appboy.support.AppboyLogger.d(r1, r2)     // Catch:{ InterruptedException -> 0x002e }
                L_0x002e:
                    monitor-exit(r0)     // Catch:{ all -> 0x0071 }
                    bo.app.es r0 = bo.app.es.this     // Catch:{ Exception -> 0x0074 }
                    bo.app.dr r0 = r0.c     // Catch:{ Exception -> 0x0074 }
                    monitor-enter(r0)     // Catch:{ Exception -> 0x0074 }
                    bo.app.es r1 = bo.app.es.this     // Catch:{ all -> 0x006e }
                    bo.app.dr r1 = r1.c     // Catch:{ all -> 0x006e }
                    boolean r1 = r1.c()     // Catch:{ all -> 0x006e }
                    if (r1 == 0) goto L_0x005d
                    java.lang.String r1 = bo.app.es.a     // Catch:{ all -> 0x006e }
                    java.lang.String r2 = "Device cache was locked, waiting."
                    com.appboy.support.AppboyLogger.i(r1, r2)     // Catch:{ all -> 0x006e }
                    bo.app.es r1 = bo.app.es.this     // Catch:{ InterruptedException -> 0x005d }
                    bo.app.dr r1 = r1.c     // Catch:{ InterruptedException -> 0x005d }
                    r1.wait()     // Catch:{ InterruptedException -> 0x005d }
                    java.lang.String r1 = bo.app.es.a     // Catch:{ InterruptedException -> 0x005d }
                    java.lang.String r2 = "Device cache notified. Continuing UserDependencyManager shutdown"
                    com.appboy.support.AppboyLogger.d(r1, r2)     // Catch:{ InterruptedException -> 0x005d }
                L_0x005d:
                    monitor-exit(r0)     // Catch:{ all -> 0x006e }
                    bo.app.es r0 = bo.app.es.this     // Catch:{ Exception -> 0x0074 }
                    bo.app.n r0 = r0.e     // Catch:{ Exception -> 0x0074 }
                    bo.app.es r1 = bo.app.es.this     // Catch:{ Exception -> 0x0074 }
                    bo.app.ab r1 = r1.d     // Catch:{ Exception -> 0x0074 }
                    r0.a((bo.app.ab) r1)     // Catch:{ Exception -> 0x0074 }
                    goto L_0x007e
                L_0x006e:
                    r1 = move-exception
                    monitor-exit(r0)     // Catch:{ all -> 0x006e }
                    throw r1     // Catch:{ Exception -> 0x0074 }
                L_0x0071:
                    r1 = move-exception
                    monitor-exit(r0)     // Catch:{ all -> 0x0071 }
                    throw r1     // Catch:{ Exception -> 0x0074 }
                L_0x0074:
                    r0 = move-exception
                    java.lang.String r1 = bo.app.es.a
                    java.lang.String r2 = "Exception while shutting down dispatch manager. Continuing."
                    com.appboy.support.AppboyLogger.w(r1, r2, r0)
                L_0x007e:
                    bo.app.es r0 = bo.app.es.this     // Catch:{ Exception -> 0x0088 }
                    bo.app.q r0 = r0.k     // Catch:{ Exception -> 0x0088 }
                    r0.b()     // Catch:{ Exception -> 0x0088 }
                    goto L_0x0092
                L_0x0088:
                    r0 = move-exception
                    java.lang.String r1 = bo.app.es.a
                    java.lang.String r2 = "Exception while un-registering data refresh broadcast receivers. Continuing."
                    com.appboy.support.AppboyLogger.w(r1, r2, r0)
                L_0x0092:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: bo.app.es.AnonymousClass1.run():void");
            }
        });
    }

    private dv a(Cdo doVar, bb bbVar) {
        return new ds(new dp(new dy(doVar), bbVar), this.d);
    }

    private dv a(Context context, String str, String str2) {
        return new ds(new dp(new eb(context, str, str2), this.i), this.d);
    }
}
