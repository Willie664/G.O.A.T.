package bo.app;

import android.net.Uri;
import com.appboy.events.SubmitFeedbackFailed;
import com.appboy.events.SubmitFeedbackSucceeded;
import com.appboy.models.outgoing.Feedback;
import com.appboy.support.AppboyLogger;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Deprecated
public final class dc extends cx {
    private static final String b = AppboyLogger.getAppboyLogTag(dc.class);
    private final Feedback c;

    public boolean i() {
        return false;
    }

    public dc(String str, Feedback feedback) {
        super(Uri.parse(str + "data"), (Map<String, String>) null);
        this.c = feedback;
    }

    public x j() {
        return x.POST;
    }

    public void a(ac acVar, cs csVar) {
        acVar.a(new SubmitFeedbackSucceeded(this.c), SubmitFeedbackSucceeded.class);
    }

    public void a(ac acVar, ac acVar2, cu cuVar) {
        super.a(acVar, acVar2, cuVar);
        acVar2.a(new SubmitFeedbackFailed(this.c, cuVar), SubmitFeedbackFailed.class);
    }

    public JSONObject h() {
        JSONObject h = super.h();
        if (h == null) {
            return null;
        }
        try {
            JSONArray jSONArray = new JSONArray();
            jSONArray.put(this.c.forJsonPut());
            h.put("feedback", jSONArray);
            return h;
        } catch (JSONException e) {
            AppboyLogger.w(b, "Experienced JSONException while retrieving parameters. Returning null.", e);
            return null;
        }
    }
}
