package bo.app;

import android.net.Uri;
import com.appboy.Appboy;
import com.appboy.enums.SdkFlavor;
import com.appboy.support.AppboyLogger;
import com.appboy.support.JsonUtils;
import com.appboy.support.StringUtils;
import java.util.ArrayList;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class cx extends di implements ce, df {
    private static final String b = AppboyLogger.getAppboyLogTag(cx.class);
    private Long c;
    private String d;
    private String e;
    private String f;
    private cj g;
    private String h;
    private String i;
    private SdkFlavor j;
    private cm k;
    private cl l;
    private ca m;

    protected cx(Uri uri, Map<String, String> map) {
        super(uri, map);
    }

    public Uri a() {
        return Appboy.getAppboyApiEndpoint(this.a);
    }

    public void a(String str) {
        this.d = str;
    }

    public cj c() {
        return this.g;
    }

    public void a(cj cjVar) {
        this.g = cjVar;
    }

    public void a(long j2) {
        this.c = Long.valueOf(j2);
    }

    public void b(String str) {
        this.e = str;
    }

    public String d() {
        return this.e;
    }

    public void c(String str) {
        this.f = str;
    }

    public void a(SdkFlavor sdkFlavor) {
        this.j = sdkFlavor;
    }

    public void d(String str) {
        this.h = str;
    }

    public cm e() {
        return this.k;
    }

    public void a(cm cmVar) {
        this.k = cmVar;
    }

    public void a(cl clVar) {
        this.l = clVar;
    }

    public cl f() {
        return this.l;
    }

    public void a(ca caVar) {
        this.m = caVar;
    }

    public ca g() {
        return this.m;
    }

    public void e(String str) {
        this.i = str;
    }

    public void a(ac acVar, ac acVar2, cu cuVar) {
        String a = cuVar.a();
        String str = b;
        AppboyLogger.e(str, "Error occurred while executing Braze request: " + a);
        if (a != null && a.equals("invalid_api_key")) {
            AppboyLogger.e(b, "******************************************************************");
            AppboyLogger.e(b, "**                        !! WARNING !!                         **");
            AppboyLogger.e(b, "**  The current API key/endpoint combination is invalid. This   **");
            AppboyLogger.e(b, "** is potentially an integration error. Please ensure that your **");
            AppboyLogger.e(b, "**     API key AND custom endpoint information are correct.     **");
            String str2 = b;
            AppboyLogger.e(str2, ">> API key    : " + d());
            String str3 = b;
            AppboyLogger.e(str3, ">> Request Uri: " + a());
            AppboyLogger.e(b, "******************************************************************");
        }
    }

    public JSONObject h() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.d != null) {
                jSONObject.put("device_id", this.d);
            }
            if (this.c != null) {
                jSONObject.put("time", this.c);
            }
            if (this.e != null) {
                jSONObject.put("api_key", this.e);
            }
            if (this.f != null) {
                jSONObject.put("sdk_version", this.f);
            }
            if (this.h != null) {
                jSONObject.put("app_version", this.h);
            }
            if (!StringUtils.isNullOrBlank(this.i)) {
                jSONObject.put("app_version_code", this.i);
            }
            if (this.g != null && !this.g.b()) {
                jSONObject.put("device", this.g.forJsonPut());
            }
            if (this.k != null && !this.k.b()) {
                jSONObject.put("attributes", this.k.forJsonPut());
            }
            if (this.m != null && !this.m.b()) {
                jSONObject.put("events", JsonUtils.constructJsonArray(this.m.a()));
            }
            if (this.j != null) {
                jSONObject.put("sdk_flavor", this.j.forJsonPut());
            }
            return jSONObject;
        } catch (JSONException e2) {
            AppboyLogger.w(b, "Experienced JSONException while retrieving parameters. Returning null.", e2);
            return null;
        }
    }

    public boolean i() {
        return b();
    }

    public boolean b() {
        ArrayList<ce> arrayList = new ArrayList<>();
        arrayList.add(this.g);
        arrayList.add(this.k);
        arrayList.add(this.m);
        for (ce ceVar : arrayList) {
            if (ceVar != null && !ceVar.b()) {
                return false;
            }
        }
        return true;
    }

    public void a(ac acVar) {
        AppboyLogger.v(b, "Request started");
        cl clVar = this.l;
        if (clVar != null && clVar.d()) {
            acVar.a(new aq(this), aq.class);
        }
    }

    public void b(ac acVar) {
        cl clVar = this.l;
        if (clVar != null && clVar.d()) {
            AppboyLogger.d(b, "Trigger dispatch completed. Alerting subscribers.");
            acVar.a(new ap(this), ap.class);
        }
    }

    public void a(Map<String, String> map) {
        map.put("X-Braze-Api-Key", this.e);
    }
}
