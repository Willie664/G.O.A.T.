package bo.app;

import com.appboy.models.IPutIntoJson;
import org.json.JSONObject;

public interface fn extends IPutIntoJson<JSONObject> {
    long a();

    long b();

    int c();

    int d();

    int e();

    fm f();

    int g();
}
