package bo.app;

import android.os.Handler;
import android.os.Looper;

public class ek {
    public static Handler a() {
        return new Handler(Looper.getMainLooper());
    }
}
