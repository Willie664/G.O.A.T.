package bo.app;

import org.json.JSONObject;

public class go {
    public static void a(JSONObject jSONObject, JSONObject jSONObject2, gq gqVar) {
        gr a = gp.a(jSONObject, jSONObject2, gqVar);
        if (a.b()) {
            throw new AssertionError(a.c());
        }
    }
}
