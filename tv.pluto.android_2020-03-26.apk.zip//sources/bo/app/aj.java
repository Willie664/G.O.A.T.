package bo.app;

public final class aj {
    public static final aj a = new aj();
}
