package bo.app;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import bo.app.cj;
import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.support.AppboyLogger;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.TimeZone;

public class bq implements bu {
    private static final String b = AppboyLogger.getAppboyLogTag(bq.class);
    final SharedPreferences a;
    private final Context c;
    private final bv d;
    private final dr e;
    private final AppboyConfigurationProvider f;
    private String g;
    private String h;

    public bq(Context context, AppboyConfigurationProvider appboyConfigurationProvider, bv bvVar, dr drVar) {
        if (context != null) {
            this.c = context;
            this.f = appboyConfigurationProvider;
            this.d = bvVar;
            this.e = drVar;
            this.a = context.getSharedPreferences("com.appboy.managers.device_data_provider", 0);
            return;
        }
        throw new NullPointerException();
    }

    public cj a() {
        return new cj.a(this.f).a(i()).b(k()).c(l()).d(a(m())).e(n().getID()).f(a(o(), p())).a(Boolean.valueOf(h())).b(Boolean.valueOf(q())).g(f()).c(g()).a();
    }

    public cj b() {
        this.e.a(a());
        return (cj) this.e.b();
    }

    public String c() {
        String a2 = this.d.a();
        if (a2 == null) {
            AppboyLogger.e(b, "Error reading deviceId, received a null value.");
        }
        return a2;
    }

    public void a(String str) {
        this.a.edit().putString("google_ad_id", str).apply();
    }

    public void a(boolean z) {
        this.a.edit().putBoolean("ad_tracking_enabled", !z).apply();
    }

    public String d() {
        String str = this.g;
        if (str != null) {
            return str;
        }
        PackageInfo j = j();
        if (j != null) {
            this.g = j.versionName;
            return this.g;
        }
        AppboyLogger.d(b, "App version could not be read. Returning null");
        return null;
    }

    public String e() {
        long j;
        String str = this.h;
        if (str != null) {
            return str;
        }
        PackageInfo j2 = j();
        if (j2 != null) {
            if (Build.VERSION.SDK_INT >= 28) {
                j = j2.getLongVersionCode();
            } else {
                j = (long) j2.versionCode;
            }
            this.h = j + ".0.0.0";
            return this.h;
        }
        AppboyLogger.d(b, "App version code could not be read. Returning null");
        return null;
    }

    private String i() {
        return String.valueOf(Build.VERSION.SDK_INT);
    }

    private PackageInfo j() {
        String packageName = this.c.getPackageName();
        try {
            return this.c.getPackageManager().getPackageInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e2) {
            String str = b;
            AppboyLogger.e(str, "Unable to inspect package [" + packageName + "]", e2);
            return this.c.getPackageManager().getPackageArchiveInfo(this.c.getApplicationInfo().sourceDir, 0);
        }
    }

    private String k() {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) this.c.getSystemService("phone");
            int phoneType = telephonyManager.getPhoneType();
            if (phoneType == 0) {
                return null;
            }
            if (phoneType == 1 || phoneType == 2) {
                return telephonyManager.getNetworkOperatorName();
            }
            AppboyLogger.w(b, "Unknown phone type");
            return null;
        } catch (Resources.NotFoundException e2) {
            AppboyLogger.e(b, "Caught resources not found exception while reading the phone carrier name.", e2);
            return null;
        } catch (SecurityException e3) {
            AppboyLogger.e(b, "Caught security exception while reading the phone carrier name.", e3);
            return null;
        }
    }

    private String l() {
        return Build.MODEL;
    }

    private Locale m() {
        return Locale.getDefault();
    }

    private TimeZone n() {
        return TimeZone.getDefault();
    }

    private DisplayMetrics o() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) this.c.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics;
    }

    private boolean p() {
        int rotation = ((WindowManager) this.c.getSystemService("window")).getDefaultDisplay().getRotation();
        return rotation == 1 || rotation == 3;
    }

    private boolean q() {
        if (Build.VERSION.SDK_INT < 28) {
            return false;
        }
        try {
            return ((ActivityManager) this.c.getSystemService("activity")).isBackgroundRestricted();
        } catch (Exception e2) {
            AppboyLogger.e(b, "Failed to collect background restriction information from Activity Manager", e2);
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public String f() {
        return this.a.getString("google_ad_id", (String) null);
    }

    /* access modifiers changed from: package-private */
    public Boolean g() {
        if (!this.a.contains("ad_tracking_enabled")) {
            return null;
        }
        return Boolean.valueOf(this.a.getBoolean("ad_tracking_enabled", true));
    }

    /* access modifiers changed from: package-private */
    public boolean h() {
        Object a2;
        Method a3;
        if (Build.VERSION.SDK_INT >= 24) {
            NotificationManager notificationManager = (NotificationManager) this.c.getSystemService("notification");
            if (notificationManager != null) {
                return notificationManager.areNotificationsEnabled();
            }
            return true;
        }
        if (Build.VERSION.SDK_INT >= 19) {
            try {
                Method a4 = ep.a("androidx.core.app.NotificationManagerCompat", "from", (Class<?>[]) new Class[]{Context.class});
                if ((a4 == null && (a4 = ep.a("androidx.core.app.NotificationManagerCompat", "from", (Class<?>[]) new Class[]{Context.class})) == null) || (a2 = ep.a((Object) null, a4, this.c)) == null || (a3 = ep.a(a2.getClass(), "areNotificationsEnabled", (Class<?>[]) new Class[0])) == null) {
                    return true;
                }
                Object a5 = ep.a(a2, a3, new Object[0]);
                if (a5 instanceof Boolean) {
                    return ((Boolean) a5).booleanValue();
                }
                return true;
            } catch (Exception e2) {
                AppboyLogger.e(b, "Failed to read notifications enabled state from NotificationManagerCompat.", e2);
            }
        }
        return true;
    }

    static String a(Locale locale) {
        return locale.toString();
    }

    static String a(DisplayMetrics displayMetrics, boolean z) {
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        if (z) {
            return i2 + "x" + i;
        }
        return i + "x" + i2;
    }
}
