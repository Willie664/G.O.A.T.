package bo.app;

public interface gf extends ge {
    void a(et etVar, long j);

    boolean a(et etVar);
}
