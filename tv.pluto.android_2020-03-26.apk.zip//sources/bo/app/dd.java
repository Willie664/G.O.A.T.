package bo.app;

import android.net.Uri;
import com.appboy.support.AppboyLogger;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class dd extends cx {
    private static final String b = AppboyLogger.getAppboyLogTag(dd.class);
    private final cc c;

    public boolean i() {
        return false;
    }

    public dd(String str, cd cdVar) {
        super(Uri.parse(str + "geofence/request"), (Map<String, String>) null);
        this.c = cn.a(cdVar);
    }

    public x j() {
        return x.POST;
    }

    public void a(ac acVar, cs csVar) {
        AppboyLogger.d(b, "GeofenceRefreshRequest executed successfully.");
    }

    public JSONObject h() {
        JSONObject h = super.h();
        if (h == null) {
            return null;
        }
        try {
            if (this.c != null) {
                h.put("location_event", this.c.forJsonPut());
            }
            return h;
        } catch (JSONException e) {
            AppboyLogger.w(b, "Experienced JSONException while creating geofence refresh request. Returning null.", e);
            return null;
        }
    }
}
