package bo.app;

public class av extends Exception {
    public av(String str, Throwable th) {
        super(str, th);
    }

    public av(String str) {
        super(str);
    }
}
