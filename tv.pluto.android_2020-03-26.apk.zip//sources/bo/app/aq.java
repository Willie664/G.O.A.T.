package bo.app;

public final class aq {
    private final df a;

    public aq(df dfVar) {
        this.a = dfVar;
    }
}
