package bo.app;

import android.content.Context;
import bo.app.cl;
import com.appboy.Appboy;
import com.appboy.AppboyInternal;
import com.appboy.events.IEventSubscriber;
import com.appboy.events.InAppMessageEvent;
import com.appboy.support.AppboyLogger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;

public class aa {
    /* access modifiers changed from: private */
    public static final String c = AppboyLogger.getAppboyLogTag(aa.class);
    AtomicBoolean a = new AtomicBoolean(false);
    long b = 0;
    /* access modifiers changed from: private */
    public final bw d;
    /* access modifiers changed from: private */
    public final t e;
    /* access modifiers changed from: private */
    public final bt f;
    /* access modifiers changed from: private */
    public final Context g;
    /* access modifiers changed from: private */
    public final ed h;
    /* access modifiers changed from: private */
    public final dr i;
    /* access modifiers changed from: private */
    public final ea j;
    /* access modifiers changed from: private */
    public final gd k;
    /* access modifiers changed from: private */
    public final bj l;
    /* access modifiers changed from: private */
    public final bk m;
    /* access modifiers changed from: private */
    public final bz n;
    /* access modifiers changed from: private */
    public final ac o;
    /* access modifiers changed from: private */
    public final gf p;
    /* access modifiers changed from: private */
    public AtomicBoolean q = new AtomicBoolean(false);
    /* access modifiers changed from: private */
    public ar r;

    public aa(Context context, bw bwVar, t tVar, bn bnVar, ed edVar, dr drVar, ea eaVar, gd gdVar, gf gfVar, bj bjVar, bk bkVar, bz bzVar, ac acVar) {
        this.d = bwVar;
        this.e = tVar;
        this.f = bnVar;
        this.g = context;
        this.h = edVar;
        this.i = drVar;
        this.j = eaVar;
        this.k = gdVar;
        this.p = gfVar;
        this.l = bjVar;
        this.m = bkVar;
        this.n = bzVar;
        this.o = acVar;
    }

    public void a(ab abVar) {
        abVar.b(b(), ad.class);
        abVar.b(e(), al.class);
        abVar.b(g(), am.class);
        abVar.b(j(), ar.class);
        abVar.b(h(), ak.class);
        abVar.b(a((Semaphore) null), Throwable.class);
        abVar.b(p(), aw.class);
        abVar.b(k(), au.class);
        abVar.b(f(), aj.class);
        abVar.b(a(), ae.class);
        abVar.b(i(), ah.class);
        abVar.b(l(), as.class);
        abVar.b(m(), ai.class);
        abVar.b(n(), at.class);
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ae> a() {
        return new IEventSubscriber<ae>() {
            /* renamed from: a */
            public void trigger(ae aeVar) {
                df a2 = aeVar.a();
                cl f = a2.f();
                if (f != null && f.c()) {
                    aa.this.j.a(false);
                }
                cj c = a2.c();
                if (c != null) {
                    aa.this.i.b(c, true);
                }
                cm e = a2.e();
                if (e != null) {
                    aa.this.h.b(e, true);
                }
                ca g = a2.g();
                if (g != null) {
                    aa.this.l.a((List<cc>) new ArrayList(g.a()));
                }
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ad> b() {
        return new IEventSubscriber<ad>() {
            /* renamed from: a */
            public void trigger(ad adVar) {
                df a2 = adVar.a();
                cl f = a2.f();
                if (f != null) {
                    if (f.d()) {
                        aa.this.c();
                        aa.this.d();
                    }
                    if (f.c()) {
                        aa.this.j.a(true);
                    }
                }
                cj c = a2.c();
                if (c != null) {
                    aa.this.i.b(c, false);
                }
                cm e = a2.e();
                if (e != null) {
                    aa.this.h.b(e, false);
                }
                ca g = a2.g();
                if (g != null) {
                    for (cc a3 : g.a()) {
                        aa.this.e.a(a3);
                    }
                }
            }
        };
    }

    /* access modifiers changed from: protected */
    public void c() {
        if (this.a.compareAndSet(true, false)) {
            this.k.a((ft) new fw());
        }
    }

    /* access modifiers changed from: protected */
    public void d() {
        if (this.q.compareAndSet(true, false) && this.r.a() != null) {
            this.k.a((ft) new fy(this.r.a(), this.r.b()));
            this.r = null;
        }
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<al> e() {
        return new IEventSubscriber<al>() {
            /* renamed from: a */
            public void trigger(al alVar) {
                AppboyLogger.d(aa.c, "Session start event for new session received.");
                aa.this.f.a((cc) cn.l());
                aa.this.d.a();
                aa.this.o();
                AppboyInternal.requestGeofenceRefresh(aa.this.g, false);
                aa.this.h.d();
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<aj> f() {
        return new IEventSubscriber<aj>() {
            /* renamed from: a */
            public void trigger(aj ajVar) {
                aa.this.o();
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<am> g() {
        return new IEventSubscriber<am>() {
            /* renamed from: a */
            public void trigger(am amVar) {
                aa.this.a(amVar);
                Appboy.getInstance(aa.this.g).requestImmediateDataFlush();
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ak> h() {
        return new IEventSubscriber<ak>() {
            /* renamed from: a */
            public void trigger(ak akVar) {
                aa.this.m.a(akVar.a());
                aa.this.n.a(akVar.a());
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ah> i() {
        return new IEventSubscriber<ah>() {
            /* renamed from: a */
            public void trigger(ah ahVar) {
                aa.this.m.a(ahVar.a());
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ar> j() {
        return new IEventSubscriber<ar>() {
            /* renamed from: a */
            public void trigger(ar arVar) {
                aa.this.q.set(true);
                ar unused = aa.this.r = arVar;
                AppboyLogger.i(aa.c, "Requesting trigger update due to trigger-eligible push click event");
                aa.this.f.a(new cl.a().b());
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<au> k() {
        return new IEventSubscriber<au>() {
            /* renamed from: a */
            public void trigger(au auVar) {
                aa.this.k.a(auVar.a());
                aa.this.c();
                aa.this.d();
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<as> l() {
        return new IEventSubscriber<as>() {
            /* renamed from: a */
            public void trigger(as asVar) {
                aa.this.k.a(asVar.a());
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<Throwable> a(final Semaphore semaphore) {
        return new IEventSubscriber<Throwable>() {
            /* renamed from: a */
            public void trigger(Throwable th) {
                Semaphore semaphore;
                try {
                    aa.this.f.a(th);
                    semaphore = semaphore;
                    if (semaphore == null) {
                        return;
                    }
                } catch (Exception e) {
                    AppboyLogger.e(aa.c, "Failed to log error.", e);
                    semaphore = semaphore;
                    if (semaphore == null) {
                        return;
                    }
                } catch (Throwable th2) {
                    Semaphore semaphore2 = semaphore;
                    if (semaphore2 != null) {
                        semaphore2.release();
                    }
                    throw th2;
                }
                semaphore.release();
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<ai> m() {
        return new IEventSubscriber<ai>() {
            /* renamed from: a */
            public void trigger(ai aiVar) {
                et a2 = aiVar.a();
                synchronized (aa.this.p) {
                    if (aa.this.p.a(a2)) {
                        aa.this.o.a(new InAppMessageEvent(aiVar.b(), aiVar.c()), InAppMessageEvent.class);
                        aa.this.p.a(a2, ee.a());
                        aa.this.k.a(ee.a());
                    } else {
                        String q = aa.c;
                        AppboyLogger.d(q, "Could not publish in-app message with trigger action id: " + a2.b());
                    }
                }
            }
        };
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<at> n() {
        return new IEventSubscriber<at>() {
            /* renamed from: a */
            public void trigger(at atVar) {
                aa.this.k.a(atVar.a(), atVar.b());
            }
        };
    }

    /* access modifiers changed from: package-private */
    public void o() {
        if (this.b + 5 < ee.a()) {
            this.a.set(true);
            AppboyLogger.d(c, "Requesting trigger refresh.");
            this.f.a(new cl.a().b());
            this.b = ee.a();
        }
    }

    /* access modifiers changed from: protected */
    public IEventSubscriber<aw> p() {
        return new IEventSubscriber<aw>() {
            /* renamed from: a */
            public void trigger(aw awVar) {
                try {
                    aa.this.f.b((Throwable) awVar);
                } catch (Exception e) {
                    AppboyLogger.e(aa.c, "Failed to log the storage exception.", e);
                }
            }
        };
    }

    /* access modifiers changed from: private */
    public void a(am amVar) {
        try {
            cf a2 = amVar.a();
            cn a3 = cn.a(a2.f());
            a3.a(a2.a());
            this.f.a((cc) a3);
        } catch (JSONException unused) {
            AppboyLogger.w(c, "Could not create session end event.");
        }
    }
}
