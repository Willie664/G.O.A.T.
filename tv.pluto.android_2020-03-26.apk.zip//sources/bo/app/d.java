package bo.app;

import io.fabric.sdk.android.services.common.AbstractSpiCall;
import java.util.HashMap;
import java.util.Map;

public class d {
    public Map<String, String> a() {
        HashMap hashMap = new HashMap();
        hashMap.put("Accept-Encoding", "gzip, deflate");
        hashMap.put("Content-Type", AbstractSpiCall.ACCEPT_JSON_VALUE);
        return hashMap;
    }
}
