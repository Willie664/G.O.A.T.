package bo.app;

import java.util.List;

public final class fj extends fk implements ez {
    public fj(List<ez> list) {
        super(list);
    }

    public boolean a(ft ftVar) {
        boolean z = false;
        for (ez a : this.a) {
            if (!a.a(ftVar)) {
                return false;
            }
            z = true;
        }
        return z;
    }
}
