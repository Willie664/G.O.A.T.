package bo.app;

public interface c {
    cc a(String str);

    cc c(String str);

    cc d(String str);

    cc e(String str);
}
