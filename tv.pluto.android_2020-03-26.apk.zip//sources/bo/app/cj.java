package bo.app;

import com.appboy.configuration.AppboyConfigurationProvider;
import com.appboy.enums.DeviceKey;
import com.appboy.models.IPutIntoJson;
import com.appboy.support.AppboyLogger;
import com.appboy.support.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class cj implements ce, IPutIntoJson<JSONObject> {
    private static final String a = AppboyLogger.getAppboyLogTag(cj.class);
    private final String b;
    private final String c;
    private final String d;
    private final String e;
    private final String f;
    private String g;
    private final Boolean h;
    private final Boolean i;
    private final String j;
    private final Boolean k;
    private final AppboyConfigurationProvider l;

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x008a, code lost:
        r17 = r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static bo.app.cj a(com.appboy.configuration.AppboyConfigurationProvider r19, org.json.JSONObject r20) {
        /*
            r0 = r20
            com.appboy.enums.DeviceKey[] r1 = com.appboy.enums.DeviceKey.values()
            int r2 = r1.length
            r4 = 0
            r5 = r4
            r6 = r5
            r7 = r6
            r8 = r7
            r9 = r8
            r10 = r9
            r11 = r10
            r12 = r11
            r13 = r12
            r14 = r13
            r4 = 0
        L_0x0013:
            if (r4 >= r2) goto L_0x00e2
            r15 = r1[r4]
            java.lang.String r3 = r15.getKey()
            int[] r17 = bo.app.cj.AnonymousClass1.a
            int r18 = r15.ordinal()
            r17 = r17[r18]
            switch(r17) {
                case 1: goto L_0x00ce;
                case 2: goto L_0x00c1;
                case 3: goto L_0x00b4;
                case 4: goto L_0x00a7;
                case 5: goto L_0x009a;
                case 6: goto L_0x008d;
                case 7: goto L_0x0076;
                case 8: goto L_0x0062;
                case 9: goto L_0x0053;
                case 10: goto L_0x0040;
                default: goto L_0x0026;
            }
        L_0x0026:
            java.lang.String r3 = a
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r17 = r1
            java.lang.String r1 = "Unknown key encountered in Device createFromJson "
            r0.append(r1)
            r0.append(r15)
            java.lang.String r0 = r0.toString()
            com.appboy.support.AppboyLogger.e(r3, r0)
            goto L_0x00da
        L_0x0040:
            boolean r15 = r0.has(r3)
            if (r15 == 0) goto L_0x008a
            boolean r3 = r0.optBoolean(r3)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            r17 = r1
            r14 = r3
            goto L_0x00da
        L_0x0053:
            boolean r15 = r0.has(r3)
            if (r15 == 0) goto L_0x008a
            java.lang.String r3 = r0.optString(r3)
            r17 = r1
            r13 = r3
            goto L_0x00da
        L_0x0062:
            boolean r15 = r0.has(r3)
            if (r15 == 0) goto L_0x008a
            r15 = 0
            boolean r3 = r0.optBoolean(r3, r15)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            r17 = r1
            r12 = r3
            goto L_0x00da
        L_0x0076:
            r15 = 0
            boolean r16 = r0.has(r3)
            if (r16 == 0) goto L_0x008a
            r11 = 1
            boolean r3 = r0.optBoolean(r3, r11)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            r17 = r1
            r11 = r3
            goto L_0x00da
        L_0x008a:
            r17 = r1
            goto L_0x00da
        L_0x008d:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r7 = r3
            goto L_0x00da
        L_0x009a:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r8 = r3
            goto L_0x00da
        L_0x00a7:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r10 = r3
            goto L_0x00da
        L_0x00b4:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r5 = r3
            goto L_0x00da
        L_0x00c1:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r6 = r3
            goto L_0x00da
        L_0x00ce:
            r15 = 0
            java.lang.String r3 = r0.optString(r3)
            java.lang.String r3 = com.appboy.support.StringUtils.emptyToNull(r3)
            r17 = r1
            r9 = r3
        L_0x00da:
            int r4 = r4 + 1
            r0 = r20
            r1 = r17
            goto L_0x0013
        L_0x00e2:
            bo.app.cj$a r0 = new bo.app.cj$a
            r1 = r19
            r0.<init>(r1)
            bo.app.cj$a r0 = r0.a((java.lang.String) r5)
            bo.app.cj$a r0 = r0.b((java.lang.String) r6)
            bo.app.cj$a r0 = r0.c((java.lang.String) r7)
            bo.app.cj$a r0 = r0.d(r8)
            bo.app.cj$a r0 = r0.e(r9)
            bo.app.cj$a r0 = r0.f(r10)
            bo.app.cj$a r0 = r0.a((java.lang.Boolean) r11)
            bo.app.cj$a r0 = r0.b((java.lang.Boolean) r12)
            bo.app.cj$a r0 = r0.g(r13)
            bo.app.cj$a r0 = r0.c((java.lang.Boolean) r14)
            bo.app.cj r0 = r0.a()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: bo.app.cj.a(com.appboy.configuration.AppboyConfigurationProvider, org.json.JSONObject):bo.app.cj");
    }

    public cj(AppboyConfigurationProvider appboyConfigurationProvider, String str, String str2, String str3, String str4, String str5, String str6, Boolean bool, Boolean bool2, String str7, Boolean bool3) {
        this.l = appboyConfigurationProvider;
        this.b = str;
        this.c = str2;
        this.d = str3;
        this.e = str4;
        this.g = str5;
        this.f = str6;
        this.h = bool;
        this.i = bool2;
        this.j = str7;
        this.k = bool3;
    }

    /* renamed from: a */
    public JSONObject forJsonPut() {
        JSONObject jSONObject = new JSONObject();
        try {
            a(this.l, jSONObject, DeviceKey.ANDROID_VERSION, this.b);
            a(this.l, jSONObject, DeviceKey.CARRIER, this.c);
            a(this.l, jSONObject, DeviceKey.MODEL, this.d);
            a(this.l, jSONObject, DeviceKey.RESOLUTION, this.f);
            a(this.l, jSONObject, DeviceKey.LOCALE, this.e);
            a(this.l, jSONObject, DeviceKey.NOTIFICATIONS_ENABLED, this.h);
            a(this.l, jSONObject, DeviceKey.IS_BACKGROUND_RESTRICTED, this.i);
            if (!StringUtils.isNullOrBlank(this.j)) {
                a(this.l, jSONObject, DeviceKey.GOOGLE_ADVERTISING_ID, this.j);
            }
            if (this.k != null) {
                a(this.l, jSONObject, DeviceKey.AD_TRACKING_ENABLED, this.k);
            }
            if (!StringUtils.isNullOrBlank(this.g)) {
                a(this.l, jSONObject, DeviceKey.TIMEZONE, this.g);
            }
        } catch (JSONException e2) {
            AppboyLogger.e(a, "Caught exception creating device Json.", e2);
        }
        return jSONObject;
    }

    public boolean b() {
        return forJsonPut().length() == 0;
    }

    public boolean c() {
        return forJsonPut().has(DeviceKey.NOTIFICATIONS_ENABLED.getKey());
    }

    static void a(AppboyConfigurationProvider appboyConfigurationProvider, JSONObject jSONObject, DeviceKey deviceKey, Object obj) {
        if (!appboyConfigurationProvider.getIsDeviceObjectWhitelistEnabled() || appboyConfigurationProvider.getDeviceObjectWhitelist().contains(deviceKey)) {
            jSONObject.putOpt(deviceKey.getKey(), obj);
            return;
        }
        String str = a;
        AppboyLogger.v(str, "Not adding device key <" + deviceKey + "> to export due to whitelist restrictions.");
    }

    public static class a {
        private AppboyConfigurationProvider a;
        private String b;
        private String c;
        private String d;
        private String e;
        private String f;
        private String g;
        private Boolean h;
        private Boolean i;
        private String j;
        private Boolean k;

        public a(AppboyConfigurationProvider appboyConfigurationProvider) {
            this.a = appboyConfigurationProvider;
        }

        public a a(String str) {
            this.b = str;
            return this;
        }

        public a b(String str) {
            this.c = str;
            return this;
        }

        public a c(String str) {
            this.d = str;
            return this;
        }

        public a d(String str) {
            this.e = str;
            return this;
        }

        public a e(String str) {
            this.f = str;
            return this;
        }

        public a f(String str) {
            this.g = str;
            return this;
        }

        public a a(Boolean bool) {
            this.h = bool;
            return this;
        }

        public a b(Boolean bool) {
            this.i = bool;
            return this;
        }

        public a g(String str) {
            this.j = str;
            return this;
        }

        public a c(Boolean bool) {
            this.k = bool;
            return this;
        }

        public cj a() {
            return new cj(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k);
        }
    }
}
