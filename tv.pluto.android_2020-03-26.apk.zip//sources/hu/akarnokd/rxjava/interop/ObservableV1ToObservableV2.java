package hu.akarnokd.rxjava.interop;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.plugins.RxJavaPlugins;
import rx.Subscriber;

final class ObservableV1ToObservableV2<T> extends Observable<T> {
    final rx.Observable<T> source;

    ObservableV1ToObservableV2(rx.Observable<T> observable) {
        this.source = observable;
    }

    /* access modifiers changed from: protected */
    public void subscribeActual(Observer<? super T> observer) {
        ObservableSubscriber observableSubscriber = new ObservableSubscriber(observer);
        observer.onSubscribe(observableSubscriber);
        this.source.unsafeSubscribe(observableSubscriber);
    }

    static final class ObservableSubscriber<T> extends Subscriber<T> implements Disposable {
        final Observer<? super T> actual;
        boolean done;

        ObservableSubscriber(Observer<? super T> observer) {
            this.actual = observer;
        }

        public void onNext(T t) {
            if (!this.done) {
                if (t == null) {
                    unsubscribe();
                    onError(new NullPointerException("The upstream 1.x Observable signalled a null value which is not supported in 2.x"));
                    return;
                }
                this.actual.onNext(t);
            }
        }

        public void onError(Throwable th) {
            if (this.done) {
                RxJavaPlugins.onError(th);
                return;
            }
            this.done = true;
            this.actual.onError(th);
            unsubscribe();
        }

        public void onCompleted() {
            if (!this.done) {
                this.done = true;
                this.actual.onComplete();
                unsubscribe();
            }
        }

        public void dispose() {
            unsubscribe();
        }

        public boolean isDisposed() {
            return isUnsubscribed();
        }
    }
}
