package hu.akarnokd.rxjava.interop;

import io.reactivex.SingleObserver;
import io.reactivex.SingleSource;
import io.reactivex.disposables.Disposable;
import io.reactivex.internal.disposables.DisposableHelper;
import java.util.concurrent.atomic.AtomicReference;
import rx.Single;
import rx.SingleSubscriber;
import rx.Subscription;

final class SingleV2ToSingleV1<T> implements Single.OnSubscribe<T> {
    final SingleSource<T> source;

    SingleV2ToSingleV1(SingleSource<T> singleSource) {
        this.source = singleSource;
    }

    public void call(SingleSubscriber<? super T> singleSubscriber) {
        SourceSingleObserver sourceSingleObserver = new SourceSingleObserver(singleSubscriber);
        singleSubscriber.add(sourceSingleObserver);
        this.source.subscribe(sourceSingleObserver);
    }

    static final class SourceSingleObserver<T> extends AtomicReference<Disposable> implements SingleObserver<T>, Subscription {
        private static final long serialVersionUID = 4758098209431016997L;
        final SingleSubscriber<? super T> actual;

        SourceSingleObserver(SingleSubscriber<? super T> singleSubscriber) {
            this.actual = singleSubscriber;
        }

        public void unsubscribe() {
            DisposableHelper.dispose(this);
        }

        public boolean isUnsubscribed() {
            return DisposableHelper.isDisposed((Disposable) get());
        }

        public void onSubscribe(Disposable disposable) {
            DisposableHelper.setOnce(this, disposable);
        }

        public void onSuccess(T t) {
            this.actual.onSuccess(t);
        }

        public void onError(Throwable th) {
            this.actual.onError(th);
        }
    }
}
