package hu.akarnokd.rxjava.interop;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.Single;
import io.reactivex.SingleSource;
import io.reactivex.internal.functions.ObjectHelper;
import org.reactivestreams.Publisher;
import rx.Observable;

public final class RxJavaInterop {
    public static <T> Observable<T> toV2Observable(rx.Observable<T> observable) {
        ObjectHelper.requireNonNull(observable, "source is null");
        return new ObservableV1ToObservableV2(observable);
    }

    public static <T> Single<T> toV2Single(rx.Single<T> single) {
        ObjectHelper.requireNonNull(single, "source is null");
        return new SingleV1ToSingleV2(single);
    }

    public static <T, R> ObservableTransformer<T, R> toV2Transformer(final Observable.Transformer<T, R> transformer, final BackpressureStrategy backpressureStrategy) {
        ObjectHelper.requireNonNull(transformer, "transformer is null");
        return new ObservableTransformer<T, R>() {
            public ObservableSource<R> apply(io.reactivex.Observable<T> observable) {
                return RxJavaInterop.toV2Observable((rx.Observable) transformer.call(RxJavaInterop.toV1Observable(observable, backpressureStrategy)));
            }
        };
    }

    public static <T> rx.Observable<T> toV1Observable(Publisher<T> publisher) {
        ObjectHelper.requireNonNull(publisher, "source is null");
        return rx.Observable.unsafeCreate(new FlowableV2ToObservableV1(publisher));
    }

    public static <T> rx.Observable<T> toV1Observable(ObservableSource<T> observableSource, BackpressureStrategy backpressureStrategy) {
        ObjectHelper.requireNonNull(observableSource, "source is null");
        ObjectHelper.requireNonNull(backpressureStrategy, "strategy is null");
        return toV1Observable(io.reactivex.Observable.wrap(observableSource).toFlowable(backpressureStrategy));
    }

    public static <T> rx.Single<T> toV1Single(SingleSource<T> singleSource) {
        ObjectHelper.requireNonNull(singleSource, "source is null");
        return rx.Single.create(new SingleV2ToSingleV1(singleSource));
    }
}
