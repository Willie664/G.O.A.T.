package hu.akarnokd.rxjava.interop;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import rx.SingleSubscriber;

final class SingleV1ToSingleV2<T> extends Single<T> {
    final rx.Single<T> source;

    SingleV1ToSingleV2(rx.Single<T> single) {
        this.source = single;
    }

    /* access modifiers changed from: protected */
    public void subscribeActual(SingleObserver<? super T> singleObserver) {
        SourceSingleSubscriber sourceSingleSubscriber = new SourceSingleSubscriber(singleObserver);
        singleObserver.onSubscribe(sourceSingleSubscriber);
        this.source.subscribe(sourceSingleSubscriber);
    }

    static final class SourceSingleSubscriber<T> extends SingleSubscriber<T> implements Disposable {
        final SingleObserver<? super T> observer;

        SourceSingleSubscriber(SingleObserver<? super T> singleObserver) {
            this.observer = singleObserver;
        }

        public void onSuccess(T t) {
            if (t == null) {
                this.observer.onError(new NullPointerException("The upstream 1.x Single signalled a null value which is not supported in 2.x"));
            } else {
                this.observer.onSuccess(t);
            }
        }

        public void onError(Throwable th) {
            this.observer.onError(th);
        }

        public void dispose() {
            unsubscribe();
        }

        public boolean isDisposed() {
            return isUnsubscribed();
        }
    }
}
