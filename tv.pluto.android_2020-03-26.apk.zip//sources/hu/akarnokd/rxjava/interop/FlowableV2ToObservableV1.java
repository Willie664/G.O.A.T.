package hu.akarnokd.rxjava.interop;

import io.reactivex.FlowableSubscriber;
import io.reactivex.internal.subscriptions.SubscriptionHelper;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import org.reactivestreams.Publisher;
import org.reactivestreams.Subscription;
import rx.Observable;
import rx.Producer;
import rx.Subscriber;

final class FlowableV2ToObservableV1<T> implements Observable.OnSubscribe<T> {
    final Publisher<T> source;

    FlowableV2ToObservableV1(Publisher<T> publisher) {
        this.source = publisher;
    }

    public void call(Subscriber<? super T> subscriber) {
        SourceSubscriber sourceSubscriber = new SourceSubscriber(subscriber);
        subscriber.add(sourceSubscriber);
        subscriber.setProducer(sourceSubscriber);
        this.source.subscribe(sourceSubscriber);
    }

    static final class SourceSubscriber<T> extends AtomicReference<Subscription> implements FlowableSubscriber<T>, Producer, rx.Subscription {
        private static final long serialVersionUID = -6567012932544037069L;
        final Subscriber<? super T> actual;
        final AtomicLong requested = new AtomicLong();

        SourceSubscriber(Subscriber<? super T> subscriber) {
            this.actual = subscriber;
        }

        public void request(long j) {
            if (j != 0) {
                SubscriptionHelper.deferredRequest(this, this.requested, j);
            }
        }

        public void unsubscribe() {
            SubscriptionHelper.cancel(this);
        }

        public boolean isUnsubscribed() {
            return SubscriptionHelper.CANCELLED == get();
        }

        public void onSubscribe(Subscription subscription) {
            SubscriptionHelper.deferredSetOnce(this, this.requested, subscription);
        }

        public void onNext(T t) {
            this.actual.onNext(t);
        }

        public void onError(Throwable th) {
            this.actual.onError(th);
        }

        public void onComplete() {
            this.actual.onCompleted();
        }
    }
}
