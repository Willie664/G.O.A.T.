package com.google.android.gms.internal.cast;

public enum zzfm implements zzlg {
    BROADCAST_ERROR_UNKNOWN(0),
    BROADCAST_ERROR_ENCRYPTION_FAILED(1),
    BROADCAST_ERROR_SOCKET_ERROR(2),
    BROADCAST_ERROR_DROPPED(3),
    BROADCAST_ERROR_KEY_EXCHANGE_INVALID_INPUT(4),
    BROADCAST_ERROR_KEY_EXCHANGE_INVALID_RESPONSE(5),
    BROADCAST_ERROR_KEY_EXCHANGE_EMPTY_RESPONSE(6),
    BROADCAST_ERROR_KEY_EXCHANGE_FAILED_TO_FIND_DEVICE(7),
    BROADCAST_ERROR_KEY_EXCHANGE_FAILED_TO_CONNECT(8),
    BROADCAST_ERROR_KEY_EXCHANGE_REQUEST_TIMED_OUT(9);
    
    public static final zzlf<zzfm> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzfp();
    }

    /* access modifiers changed from: public */
    zzfm(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzfo.zzago;
    }

    public final String toString() {
        return "<" + zzfm.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
