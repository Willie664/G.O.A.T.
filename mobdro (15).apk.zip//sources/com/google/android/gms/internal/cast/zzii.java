package com.google.android.gms.internal.cast;

public enum zzii implements zzlg {
    REMOTE_CONTROL_NOTIFICATION_FAILURE_UNKNOWN(0),
    REMOTE_CONTROL_NOTIFICATION_FAILED_TO_CONNECT(1),
    REMOTE_CONTROL_NOTIFICATION_FAILED_TO_JOIN_APPLICATION(2),
    REMOTE_CONTROL_NOTIFICATION_RECEIVED_INVALID_DEVICE_STATUS(3),
    REMOTE_CONTROL_NOTIFICATION_RECEIVED_INVALID_MEDIA_STATUS(4),
    REMOTE_CONTROL_NOTIFICATION_FAILED_TO_SET_MEDIA_NAMESPACE_CALLBACK(5),
    REMOTE_CONTROL_NOTIFICATION_FAILED_TO_REQUEST_RECEIVER_STATUS(6);
    
    public static final zzlf<zzii> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzil();
    }

    /* access modifiers changed from: public */
    zzii(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzik.zzago;
    }

    public final String toString() {
        return "<" + zzii.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
