package com.google.android.gms.internal.cast;

import android.content.Context;
import android.view.View;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.o;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaTrack;
import java.util.Iterator;
import java.util.List;

public final class zzbe extends a {
    public final View view;
    public final String zzrg;
    public final String zzvl;

    public zzbe(View view2, Context context) {
        this.view = view2;
        this.zzrg = context.getString(o.cast_closed_captions);
        this.zzvl = context.getString(o.cast_closed_captions_unavailable);
        this.view.setEnabled(false);
    }

    private final void zzed() {
        View view2;
        String str;
        boolean z;
        List<MediaTrack> list;
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient != null && remoteMediaClient.l()) {
            MediaInfo g2 = remoteMediaClient.g();
            if (g2 != null && (list = g2.f6053f) != null && !list.isEmpty()) {
                Iterator<MediaTrack> it = list.iterator();
                int i = 0;
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    int i2 = it.next().f6102b;
                    if (i2 == 2) {
                        i++;
                        if (i > 1) {
                            break;
                        }
                    } else if (i2 == 1) {
                        break;
                    }
                }
                z = true;
                if (z && !remoteMediaClient.r()) {
                    this.view.setEnabled(true);
                    view2 = this.view;
                    str = this.zzrg;
                    view2.setContentDescription(str);
                }
            }
            z = false;
            this.view.setEnabled(true);
            view2 = this.view;
            str = this.zzrg;
            view2.setContentDescription(str);
        }
        this.view.setEnabled(false);
        view2 = this.view;
        str = this.zzvl;
        view2.setContentDescription(str);
    }

    public final void onMediaStatusUpdated() {
        zzed();
    }

    public final void onSendingRemoteMediaRequest() {
        this.view.setEnabled(false);
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        this.view.setEnabled(true);
        zzed();
    }

    public final void onSessionEnded() {
        this.view.setEnabled(false);
        super.onSessionEnded();
    }
}
