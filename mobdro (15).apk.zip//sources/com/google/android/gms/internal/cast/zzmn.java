package com.google.android.gms.internal.cast;

public interface zzmn {
    boolean isInitialized();

    zzml zzje();
}
