package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzml;

public class zzju<MessageType extends zzml> implements zzmv<MessageType> {
    public static final zzkq zzbiw = zzkq.zzin();
}
