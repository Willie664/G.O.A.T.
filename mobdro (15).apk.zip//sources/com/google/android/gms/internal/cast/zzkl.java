package com.google.android.gms.internal.cast;

public final class zzkl {
    public zzkl() {
    }

    public /* synthetic */ zzkl(zzkb zzkb) {
        this();
    }
}
