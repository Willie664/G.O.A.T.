package com.google.android.gms.internal.cast;

import android.content.Context;
import b.c.a.b.c.a;
import b.c.a.b.c.j1;
import b.c.a.b.c.k1;

public interface zzab {
    j1 zza(Context context, a.c cVar, k1 k1Var);
}
