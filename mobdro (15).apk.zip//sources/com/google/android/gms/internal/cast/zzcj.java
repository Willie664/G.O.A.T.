package com.google.android.gms.internal.cast;

import b.c.a.b.c.a;
import com.google.android.gms.cast.CastDevice;

public final class zzcj implements a.e {
    public final /* synthetic */ zzcg zzaal;

    public zzcj(zzcg zzcg) {
        this.zzaal = zzcg;
    }

    public final void onMessageReceived(CastDevice castDevice, String str, String str2) {
        this.zzaal.zzzt.zzz(str2);
    }
}
