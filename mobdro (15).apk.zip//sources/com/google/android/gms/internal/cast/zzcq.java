package com.google.android.gms.internal.cast;

import b.c.a.b.c.h.a;
import com.google.android.gms.common.api.Status;

public final class zzcq implements a.C0047a {
    public final a zzaap;
    public final Status zzji;

    public zzcq(Status status, a aVar) {
        this.zzji = status;
        this.zzaap = aVar;
    }

    public final a getGameManagerClient() {
        return null;
    }

    public final Status getStatus() {
        return this.zzji;
    }
}
