package com.google.android.gms.internal.cast;

import java.util.Iterator;
import java.util.Map;

public final class zzni extends zzno {
    public final /* synthetic */ zznd zzbqq;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public zzni(zznd zznd) {
        super(zznd, (zzng) null);
        this.zzbqq = zznd;
    }

    public /* synthetic */ zzni(zznd zznd, zzng zzng) {
        this(zznd);
    }

    public final Iterator<Map.Entry<K, V>> iterator() {
        return new zznf(this.zzbqq, (zzng) null);
    }
}
