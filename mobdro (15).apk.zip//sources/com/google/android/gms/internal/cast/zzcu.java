package com.google.android.gms.internal.cast;

import b.c.a.b.c.h.b;
import b.c.a.b.c.h.c;
import b.c.a.b.c.i.a;
import b.c.a.b.d.r.e;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public final class zzcu implements b {
    public final String zzaas;
    public final int zzaat;
    public final int zzaaw;
    public final int zzaax;
    public final String zzaay;
    public final JSONObject zzaaz;
    public final Map<String, c> zzaba;

    public zzcu(int i, int i2, String str, JSONObject jSONObject, Collection<c> collection, String str2, int i3) {
        this.zzaaw = i;
        this.zzaax = i2;
        this.zzaay = str;
        this.zzaaz = jSONObject;
        this.zzaas = str2;
        this.zzaat = i3;
        this.zzaba = new HashMap(collection.size());
        for (c next : collection) {
            this.zzaba.put(next.getPlayerId(), next);
        }
    }

    public final boolean equals(Object obj) {
        if (obj != null && (obj instanceof b)) {
            b bVar = (b) obj;
            if (getPlayers().size() != bVar.getPlayers().size()) {
                return false;
            }
            for (c next : getPlayers()) {
                boolean z = false;
                for (c next2 : bVar.getPlayers()) {
                    if (a.a(next.getPlayerId(), next2.getPlayerId())) {
                        if (!a.a(next, next2)) {
                            return false;
                        }
                        z = true;
                    }
                }
                if (!z) {
                    return false;
                }
            }
            return this.zzaaw == bVar.getLobbyState() && this.zzaax == bVar.getGameplayState() && this.zzaat == bVar.getMaxPlayers() && a.a(this.zzaas, bVar.getApplicationName()) && a.a(this.zzaay, bVar.getGameStatusText()) && e.a(this.zzaaz, bVar.getGameData());
        }
    }

    public final CharSequence getApplicationName() {
        return this.zzaas;
    }

    public final List<c> getConnectedControllablePlayers() {
        ArrayList arrayList = new ArrayList();
        for (c next : getPlayers()) {
            if (next.isConnected() && next.isControllable()) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public final List<c> getConnectedPlayers() {
        ArrayList arrayList = new ArrayList();
        for (c next : getPlayers()) {
            if (next.isConnected()) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public final List<c> getControllablePlayers() {
        ArrayList arrayList = new ArrayList();
        for (c next : getPlayers()) {
            if (next.isControllable()) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public final JSONObject getGameData() {
        return this.zzaaz;
    }

    public final CharSequence getGameStatusText() {
        return this.zzaay;
    }

    public final int getGameplayState() {
        return this.zzaax;
    }

    public final Collection<String> getListOfChangedPlayers(b bVar) {
        HashSet hashSet = new HashSet();
        for (c next : getPlayers()) {
            c player = bVar.getPlayer(next.getPlayerId());
            if (player == null || !next.equals(player)) {
                hashSet.add(next.getPlayerId());
            }
        }
        for (c next2 : bVar.getPlayers()) {
            if (getPlayer(next2.getPlayerId()) == null) {
                hashSet.add(next2.getPlayerId());
            }
        }
        return hashSet;
    }

    public final int getLobbyState() {
        return this.zzaaw;
    }

    public final int getMaxPlayers() {
        return this.zzaat;
    }

    public final c getPlayer(String str) {
        if (str == null) {
            return null;
        }
        return this.zzaba.get(str);
    }

    public final Collection<c> getPlayers() {
        return Collections.unmodifiableCollection(this.zzaba.values());
    }

    public final List<c> getPlayersInState(int i) {
        ArrayList arrayList = new ArrayList();
        for (c next : getPlayers()) {
            if (next.getPlayerState() == i) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public final boolean hasGameDataChanged(b bVar) {
        return !e.a(this.zzaaz, bVar.getGameData());
    }

    public final boolean hasGameStatusTextChanged(b bVar) {
        return !a.a(this.zzaay, bVar.getGameStatusText());
    }

    public final boolean hasGameplayStateChanged(b bVar) {
        return this.zzaax != bVar.getGameplayState();
    }

    public final boolean hasLobbyStateChanged(b bVar) {
        return this.zzaaw != bVar.getLobbyState();
    }

    public final boolean hasPlayerChanged(String str, b bVar) {
        return !a.a(getPlayer(str), bVar.getPlayer(str));
    }

    public final boolean hasPlayerDataChanged(String str, b bVar) {
        c player = getPlayer(str);
        c player2 = bVar.getPlayer(str);
        if (player == null && player2 == null) {
            return false;
        }
        return player == null || player2 == null || !e.a(player.getPlayerData(), player2.getPlayerData());
    }

    public final boolean hasPlayerStateChanged(String str, b bVar) {
        c player = getPlayer(str);
        c player2 = bVar.getPlayer(str);
        if (player == null && player2 == null) {
            return false;
        }
        return player == null || player2 == null || player.getPlayerState() != player2.getPlayerState();
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.zzaaw), Integer.valueOf(this.zzaax), this.zzaba, this.zzaay, this.zzaaz, this.zzaas, Integer.valueOf(this.zzaat)});
    }
}
