package com.google.android.gms.internal.cast;

public enum zzgd implements zzlg {
    ERROR_UNKNOWN(0),
    ERROR_PEER_DISCONNECTED(1),
    ERROR_IO(2),
    ERROR_SSL(3),
    ERROR_TIMEOUT(4),
    ERROR_RELAY(5),
    ERROR_DEVICE_AUTH(6),
    ERROR_DEVICE_AUTH_ERROR_RECEIVED(7),
    ERROR_DEVICE_AUTH_CLIENT_AUTH_CERT_MALFORMED(8),
    ERROR_DEVICE_AUTH_CLIENT_AUTH_CERT_NOT_X509(9),
    ERROR_DEVICE_AUTH_CLIENT_AUTH_CERT_NOT_TRUSTED(10),
    ERROR_DEVICE_AUTH_SSL_CERT_NOT_TRUSTED(11),
    ERROR_DEVICE_AUTH_RESPONSE_MALFORMED(12),
    ERROR_CANCELED(13),
    ERROR_CAST_NEARBY_INVALID_REQUEST(14),
    ERROR_CANCELLED(15),
    ERROR_CRL_INVALID(16),
    ERROR_CRL_REVOCATION_CHECK_FAILED(17),
    ERROR_DEVICE_AUTH_TIMEOUT(18),
    ERROR_DEVICE_AUTH_PARSE_FAILURE(19),
    ERROR_DEVICE_AUTH_CHALLENGE_RECEIVED(20),
    ERROR_OTHER(99);
    
    public static final zzlf<zzgd> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzgc();
    }

    /* access modifiers changed from: public */
    zzgd(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzgf.zzago;
    }

    public final String toString() {
        return "<" + zzgd.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
