package com.google.android.gms.internal.cast;

public enum zzih implements zzlg {
    REMOTE_CONTROL_NOTIFICATION_CLICK_THROUGH_RESULT_NO_OP(0),
    REMOTE_CONTROL_NOTIFICATION_CLICK_THROUGH_RESULT_OPEN_PARTNER_APP(1),
    REMOTE_CONTROL_NOTIFICATION_CLICK_THROUGH_RESULT_OPEN_HOME_APP(2),
    REMOTE_CONTROL_NOTIFICATION_CLICK_THROUGH_RESULT_OPEN_PARTNER_APP_PLAY_STORE(3),
    REMOTE_CONTROL_NOTIFICATION_CLICK_THROUGH_RESULT_OPEN_HOME_APP_PLAY_STORE(4);
    
    public static final zzlf<zzih> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzig();
    }

    /* access modifiers changed from: public */
    zzih(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzij.zzago;
    }

    public final String toString() {
        return "<" + zzih.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
