package com.google.android.gms.internal.cast;

public final class zzjb implements zzli {
    public static final zzli zzago = new zzjb();
}
