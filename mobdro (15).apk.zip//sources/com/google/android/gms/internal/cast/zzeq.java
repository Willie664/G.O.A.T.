package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzei;

public final class zzeq implements zzlf<zzei.zza.zzc> {
}
