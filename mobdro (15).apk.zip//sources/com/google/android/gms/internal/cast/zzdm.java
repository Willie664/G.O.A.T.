package com.google.android.gms.internal.cast;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public final class zzdm extends zzb implements zzdn {
    public zzdm(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.cast.remote_display.ICastRemoteDisplayService");
    }

    public final void disconnect() throws RemoteException {
        zzc(3, zza());
    }

    public final void zza(zzdl zzdl) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) zzdl);
        zzc(6, zza);
    }

    public final void zza(zzdl zzdl, int i) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) zzdl);
        zza.writeInt(i);
        zzc(5, zza);
    }

    public final void zza(zzdl zzdl, PendingIntent pendingIntent, String str, String str2, Bundle bundle) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) zzdl);
        zzd.zza(zza, (Parcelable) pendingIntent);
        zza.writeString(str);
        zza.writeString(str2);
        zzd.zza(zza, (Parcelable) bundle);
        zzc(8, zza);
    }

    public final void zza(zzdl zzdl, zzdp zzdp, String str, String str2, Bundle bundle) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) zzdl);
        zzd.zza(zza, (IInterface) zzdp);
        zza.writeString(str);
        zza.writeString(str2);
        zzd.zza(zza, (Parcelable) bundle);
        zzc(7, zza);
    }
}
