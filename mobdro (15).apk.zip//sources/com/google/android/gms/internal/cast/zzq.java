package com.google.android.gms.internal.cast;

import android.content.Context;
import b.c.a.b.c.a;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.framework.CastOptions;

public interface zzq {
    zzo zza(Context context, CastDevice castDevice, CastOptions castOptions, a.d dVar, zzr zzr);
}
