package com.google.android.gms.internal.cast;

public final class zzjc implements zzli {
    public static final zzli zzago = new zzjc();
}
