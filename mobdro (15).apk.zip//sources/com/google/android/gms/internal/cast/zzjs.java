package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzjs;
import com.google.android.gms.internal.cast.zzjt;

public abstract class zzjs<MessageType extends zzjt<MessageType, BuilderType>, BuilderType extends zzjs<MessageType, BuilderType>> implements zzmo {
    public abstract BuilderType zza(MessageType messagetype);

    public final /* synthetic */ zzmo zza(zzml zzml) {
        if (zzje().getClass().isInstance(zzml)) {
            return zza((zzjt) zzml);
        }
        throw new IllegalArgumentException("mergeFrom(MessageLite) can only merge messages of the same type.");
    }

    /* renamed from: zzhu */
    public abstract BuilderType clone();
}
