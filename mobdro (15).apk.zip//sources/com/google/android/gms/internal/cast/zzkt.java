package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzkw;
import java.io.IOException;
import java.util.Map;

public abstract class zzkt<T extends zzkw<T>> {
    public abstract int zza(Map.Entry<?, ?> entry);

    public abstract void zza(zzon zzon, Map.Entry<?, ?> entry) throws IOException;

    public abstract zzku<T> zzc(Object obj);

    public abstract zzku<T> zzd(Object obj);

    public abstract void zze(Object obj);

    public abstract boolean zze(zzml zzml);
}
