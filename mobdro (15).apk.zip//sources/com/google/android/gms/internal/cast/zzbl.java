package com.google.android.gms.internal.cast;

import android.widget.TextView;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaMetadata;
import java.util.ArrayList;
import java.util.List;

public final class zzbl extends a {
    public final TextView zzvs;
    public final List<String> zzvt;

    public zzbl(TextView textView, List<String> list) {
        ArrayList arrayList = new ArrayList();
        this.zzvt = arrayList;
        this.zzvs = textView;
        arrayList.addAll(list);
    }

    public final void onMediaStatusUpdated() {
        MediaInfo mediaInfo;
        MediaMetadata mediaMetadata;
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient != null && remoteMediaClient.l() && (mediaInfo = remoteMediaClient.h().f6094a) != null && (mediaMetadata = mediaInfo.f6051d) != null) {
            for (String next : this.zzvt) {
                if (mediaMetadata.b(next)) {
                    this.zzvs.setText(mediaMetadata.c(next));
                    return;
                }
            }
            this.zzvs.setText("");
        }
    }
}
