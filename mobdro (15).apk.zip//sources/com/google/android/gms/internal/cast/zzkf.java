package com.google.android.gms.internal.cast;

import b.a.a.a.a;

public final class zzkf extends zzki {
    public final int zzbjg;
    public final int zzbjh;

    public zzkf(byte[] bArr, int i, int i2) {
        super(bArr);
        zzjy.zzd(i, i + i2, bArr.length);
        this.zzbjg = i;
        this.zzbjh = i2;
    }

    public final int size() {
        return this.zzbjh;
    }

    public final byte zzai(int i) {
        int size = size();
        if (((size - (i + 1)) | i) >= 0) {
            return this.zzbjj[this.zzbjg + i];
        }
        if (i < 0) {
            throw new ArrayIndexOutOfBoundsException(a.a(22, "Index < 0: ", i));
        }
        throw new ArrayIndexOutOfBoundsException(a.a(40, "Index > length: ", i, ", ", size));
    }

    public final byte zzaj(int i) {
        return this.zzbjj[this.zzbjg + i];
    }

    public final int zzig() {
        return this.zzbjg;
    }
}
