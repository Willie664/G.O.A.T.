package com.google.android.gms.internal.cast;

import android.animation.ObjectAnimator;
import android.view.View;

public final class zzat implements View.OnClickListener {
    public final /* synthetic */ zzaq zznk;

    public zzat(zzaq zzaq) {
        this.zznk = zzaq;
    }

    public final void onClick(View view) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, "alpha", new float[]{0.0f});
        ofFloat.setDuration(400).addListener(new zzas(this));
        ofFloat.start();
    }
}
