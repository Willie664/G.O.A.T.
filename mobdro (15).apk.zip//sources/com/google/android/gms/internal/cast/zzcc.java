package com.google.android.gms.internal.cast;

import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.VisibleForTesting;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.h;
import b.c.a.b.c.g.l;
import b.c.a.b.c.g.p;
import b.c.a.b.c.g.q;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;

public final class zzcc extends a implements d.e {
    public final b.c.a.b.c.g.w.g.d zzvf;
    public final TextView zzzn;
    public final ImageView zzzo;

    public zzcc(View view, b.c.a.b.c.g.w.g.d dVar) {
        this.zzzn = (TextView) view.findViewById(l.live_indicator_text);
        ImageView imageView = (ImageView) view.findViewById(l.live_indicator_dot);
        this.zzzo = imageView;
        this.zzvf = dVar;
        TypedArray obtainStyledAttributes = imageView.getContext().obtainStyledAttributes((AttributeSet) null, q.CastExpandedController, h.castExpandedControllerStyle, p.CastExpandedController);
        int resourceId = obtainStyledAttributes.getResourceId(q.CastExpandedController_castLiveIndicatorColor, 0);
        obtainStyledAttributes.recycle();
        this.zzzo.getDrawable().setColorFilter(this.zzzo.getContext().getResources().getColor(resourceId), PorterDuff.Mode.SRC_IN);
        zzea();
    }

    @VisibleForTesting
    private final void zzea() {
        d remoteMediaClient = getRemoteMediaClient();
        int i = 8;
        if (remoteMediaClient == null || !remoteMediaClient.l() || !remoteMediaClient.n()) {
            this.zzzn.setVisibility(8);
            this.zzzo.setVisibility(8);
            return;
        }
        boolean q = !remoteMediaClient.x() ? remoteMediaClient.q() : this.zzvf.d();
        this.zzzn.setVisibility(0);
        ImageView imageView = this.zzzo;
        if (q) {
            i = 0;
        }
        imageView.setVisibility(i);
        zzm.zza(zzjg.CAF_EXPANDED_CONTROLLER_WITH_LIVE_CONTENT);
    }

    public final void onMediaStatusUpdated() {
        zzea();
    }

    public final void onProgressUpdated(long j, long j2) {
        zzea();
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        if (getRemoteMediaClient() != null) {
            getRemoteMediaClient().a((d.e) this, 1000);
        }
        zzea();
    }

    public final void onSessionEnded() {
        if (getRemoteMediaClient() != null) {
            getRemoteMediaClient().a((d.e) this);
        }
        super.onSessionEnded();
        zzea();
    }
}
