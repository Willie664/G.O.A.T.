package com.google.android.gms.internal.cast;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import b.a.b.w.e;
import b.c.a.b.c.g.b;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.cast.framework.media.ImageHints;
import com.google.android.gms.common.images.WebImage;

public final class zzbg extends a {
    public final b.c.a.b.c.g.w.a zzpm;
    public final b.c.a.b.c.g.w.f.a zzpx;
    public final ImageHints zzpy;
    public final ImageView zzvn;
    public final Bitmap zzvo;

    public zzbg(ImageView imageView, Context context, @NonNull ImageHints imageHints, int i) {
        CastMediaOptions castMediaOptions;
        this.zzvn = imageView;
        this.zzpy = imageHints;
        this.zzvo = BitmapFactory.decodeResource(context.getResources(), i);
        b b2 = b.b(context);
        b.c.a.b.c.g.w.a aVar = null;
        if (!(b2 == null || (castMediaOptions = b2.a().f6126f) == null)) {
            aVar = castMediaOptions.p();
        }
        this.zzpm = aVar;
        this.zzpx = new b.c.a.b.c.g.w.f.a(context.getApplicationContext());
    }

    private final void zzed() {
        MediaInfo mediaInfo;
        b.c.a.b.c.g.w.a aVar;
        WebImage a2;
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null || !remoteMediaClient.l()) {
            this.zzvn.setImageBitmap(this.zzvo);
            return;
        }
        MediaQueueItem j = remoteMediaClient.j();
        Uri uri = null;
        if (!(j == null || (mediaInfo = j.f6087a) == null || ((aVar = this.zzpm) != null && (a2 = aVar.a(mediaInfo.f6051d, this.zzpy)) != null && (uri = a2.f6274b) != null))) {
            uri = e.a(mediaInfo, 0);
        }
        if (uri == null) {
            this.zzvn.setImageBitmap(this.zzvo);
        } else {
            this.zzpx.a(uri);
        }
    }

    public final void onMediaStatusUpdated() {
        zzed();
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        this.zzpx.f1565g = new zzbf(this);
        this.zzvn.setImageBitmap(this.zzvo);
        zzed();
    }

    public final void onSessionEnded() {
        this.zzpx.a();
        this.zzvn.setImageBitmap(this.zzvo);
        super.onSessionEnded();
    }
}
