package com.google.android.gms.internal.cast;

import android.view.View;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;

public final class zzbj extends a {
    public final View view;

    public zzbj(View view2) {
        this.view = view2;
    }

    private final void zzed() {
        View view2;
        int i;
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null || !remoteMediaClient.l() || remoteMediaClient.m()) {
            view2 = this.view;
            i = 0;
        } else {
            view2 = this.view;
            i = 8;
        }
        view2.setVisibility(i);
    }

    public final void onMediaStatusUpdated() {
        zzed();
    }

    public final void onSendingRemoteMediaRequest() {
        this.view.setVisibility(0);
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        zzed();
    }

    public final void onSessionEnded() {
        this.view.setVisibility(8);
        super.onSessionEnded();
    }
}
