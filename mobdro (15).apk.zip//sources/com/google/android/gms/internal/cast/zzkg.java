package com.google.android.gms.internal.cast;

public final class zzkg {
    public final byte[] buffer;
    public final zzkp zzbji;

    public zzkg(int i) {
        byte[] bArr = new byte[i];
        this.buffer = bArr;
        this.zzbji = zzkp.zza(bArr);
    }

    public /* synthetic */ zzkg(int i, zzkb zzkb) {
        this(i);
    }

    public final zzjy zzih() {
        this.zzbji.zzil();
        return new zzki(this.buffer);
    }

    public final zzkp zzii() {
        return this.zzbji;
    }
}
