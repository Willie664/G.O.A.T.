package com.google.android.gms.internal.cast;

import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public abstract class zzjx<E> extends AbstractList<E> implements zzlm<E> {
    public boolean zzbix = true;

    public void add(int i, E e2) {
        zzic();
        super.add(i, e2);
    }

    public boolean add(E e2) {
        zzic();
        return super.add(e2);
    }

    public boolean addAll(int i, Collection<? extends E> collection) {
        zzic();
        return super.addAll(i, collection);
    }

    public boolean addAll(Collection<? extends E> collection) {
        zzic();
        return super.addAll(collection);
    }

    public void clear() {
        zzic();
        super.clear();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        if (!(obj instanceof RandomAccess)) {
            return super.equals(obj);
        }
        List list = (List) obj;
        int size = size();
        if (size != list.size()) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (!get(i).equals(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int size = size();
        int i = 1;
        for (int i2 = 0; i2 < size; i2++) {
            i = (i * 31) + get(i2).hashCode();
        }
        return i;
    }

    public E remove(int i) {
        zzic();
        return super.remove(i);
    }

    public boolean remove(Object obj) {
        zzic();
        return super.remove(obj);
    }

    public boolean removeAll(Collection<?> collection) {
        zzic();
        return super.removeAll(collection);
    }

    public boolean retainAll(Collection<?> collection) {
        zzic();
        return super.retainAll(collection);
    }

    public E set(int i, E e2) {
        zzic();
        return super.set(i, e2);
    }

    public boolean zzia() {
        return this.zzbix;
    }

    public final void zzib() {
        this.zzbix = false;
    }

    public final void zzic() {
        if (!this.zzbix) {
            throw new UnsupportedOperationException();
        }
    }
}
