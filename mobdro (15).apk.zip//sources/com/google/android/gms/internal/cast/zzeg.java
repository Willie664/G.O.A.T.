package com.google.android.gms.internal.cast;

import java.io.Serializable;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class zzeg<T> implements Serializable {
    public static <T> zzeg<T> zzb(@NullableDecl T t) {
        return t == null ? zzeh.zzafl : new zzej(t);
    }

    @NullableDecl
    public abstract T zzfu();
}
