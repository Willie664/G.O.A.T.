package com.google.android.gms.internal.cast;

public final class zzfk implements zzlf<zzfl> {
}
