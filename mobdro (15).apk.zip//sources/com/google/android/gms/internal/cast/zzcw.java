package com.google.android.gms.internal.cast;

import b.c.a.b.c.i.a;
import b.c.a.b.d.r.e;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzcw {
    public final String zzaau;
    public final JSONObject zzabo;
    public final int zzhi;

    public zzcw(String str, int i, JSONObject jSONObject) {
        this.zzaau = str;
        this.zzhi = i;
        this.zzabo = jSONObject;
    }

    public zzcw(JSONObject jSONObject) throws JSONException {
        this(jSONObject.optString("playerId"), jSONObject.optInt("playerState"), jSONObject.optJSONObject("playerData"));
    }

    public final boolean equals(Object obj) {
        if (obj != null && (obj instanceof zzcw)) {
            zzcw zzcw = (zzcw) obj;
            return this.zzhi == zzcw.zzhi && a.a(this.zzaau, zzcw.zzaau) && e.a(this.zzabo, zzcw.zzabo);
        }
    }

    public final JSONObject getPlayerData() {
        return this.zzabo;
    }

    public final String getPlayerId() {
        return this.zzaau;
    }

    public final int getPlayerState() {
        return this.zzhi;
    }
}
