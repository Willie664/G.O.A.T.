package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzei;

public final class zzey implements zzlf<zzei.zzb.zza> {
}
