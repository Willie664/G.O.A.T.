package com.google.android.gms.internal.cast;

import b.c.a.b.c.g.c;
import b.c.a.b.c.g.r;
import b.c.a.b.c.g.u;
import b.c.a.b.c.g.w.f.i;
import com.google.android.gms.cast.framework.CastOptions;

public final class zzah extends u {
    public final CastOptions zzjz;
    public final zzax zzna;
    public final zzq zznb;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public zzah(android.content.Context r5, com.google.android.gms.cast.framework.CastOptions r6, com.google.android.gms.internal.cast.zzax r7) {
        /*
            r4 = this;
            java.util.List r0 = r6.p()
            boolean r0 = r0.isEmpty()
            java.lang.String r1 = "com.google.android.gms.cast.CATEGORY_CAST"
            java.lang.String r2 = "applicationId cannot be null"
            if (r0 == 0) goto L_0x001e
            java.lang.String r0 = r6.f6121a
            if (r0 == 0) goto L_0x0018
            r2 = 0
            java.lang.String r0 = b.a.b.w.e.a((java.lang.String) r1, (java.lang.String) r0, (java.util.Collection) r2)
            goto L_0x002c
        L_0x0018:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            r5.<init>(r2)
            throw r5
        L_0x001e:
            java.lang.String r0 = r6.f6121a
            java.util.List r3 = r6.p()
            if (r0 == 0) goto L_0x0043
            if (r3 == 0) goto L_0x003b
            java.lang.String r0 = b.a.b.w.e.a((java.lang.String) r1, (java.lang.String) r0, (java.util.Collection) r3)
        L_0x002c:
            r4.<init>(r5, r0)
            r4.zzjz = r6
            r4.zzna = r7
            com.google.android.gms.internal.cast.zzac r5 = new com.google.android.gms.internal.cast.zzac
            r5.<init>()
            r4.zznb = r5
            return
        L_0x003b:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r6 = "namespaces cannot be null"
            r5.<init>(r6)
            throw r5
        L_0x0043:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            r5.<init>(r2)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.cast.zzah.<init>(android.content.Context, com.google.android.gms.cast.framework.CastOptions, com.google.android.gms.internal.cast.zzax):void");
    }

    public final r createSession(String str) {
        return new c(getContext(), getCategory(), str, this.zzjz, this.zznb, new i(getContext(), this.zzjz, this.zzna));
    }

    public final boolean isSessionRecoverable() {
        return this.zzjz.f6125e;
    }
}
