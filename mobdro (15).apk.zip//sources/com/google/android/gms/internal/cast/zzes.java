package com.google.android.gms.internal.cast;

public final class zzes implements zzli {
    public static final zzli zzago = new zzes();
}
