package com.google.android.gms.internal.cast;

/* 'enum' modifier removed */
public final class zzom extends zzoi {
    public zzom(String str, int i, zzol zzol, int i2) {
        super(str, 11, zzol, 2, (zzof) null);
    }
}
