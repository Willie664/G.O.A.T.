package com.google.android.gms.internal.cast;

import java.util.NoSuchElementException;

public final class zzkb extends zzkd {
    public final int limit = this.zzbjf.size();
    public int position = 0;
    public final /* synthetic */ zzjy zzbjf;

    public zzkb(zzjy zzjy) {
        this.zzbjf = zzjy;
    }

    public final boolean hasNext() {
        return this.position < this.limit;
    }

    public final byte nextByte() {
        int i = this.position;
        if (i < this.limit) {
            this.position = i + 1;
            return this.zzbjf.zzaj(i);
        }
        throw new NoSuchElementException();
    }
}
