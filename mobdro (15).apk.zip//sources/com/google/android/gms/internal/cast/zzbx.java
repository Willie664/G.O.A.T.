package com.google.android.gms.internal.cast;

import android.text.format.DateUtils;
import android.widget.TextView;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.w.d;

public final class zzbx extends zzca implements d.e {
    public boolean zzut = true;
    public final long zzvk;
    public final TextView zzwm;
    public final String zzwn;

    public zzbx(TextView textView, long j, String str) {
        this.zzwm = textView;
        this.zzvk = j;
        this.zzwn = str;
    }

    public final boolean isAttached() {
        return this.zzut;
    }

    public final void onProgressUpdated(long j, long j2) {
        if (isAttached()) {
            TextView textView = this.zzwm;
            if (j == -1000) {
                j = j2;
            }
            textView.setText(DateUtils.formatElapsedTime(j / 1000));
        }
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient != null) {
            remoteMediaClient.a((d.e) this, this.zzvk);
            if (remoteMediaClient.l()) {
                this.zzwm.setText(DateUtils.formatElapsedTime(remoteMediaClient.d() / 1000));
            } else {
                this.zzwm.setText(this.zzwn);
            }
        }
    }

    public final void onSessionEnded() {
        this.zzwm.setText(this.zzwn);
        if (getRemoteMediaClient() != null) {
            getRemoteMediaClient().a((d.e) this);
        }
        super.onSessionEnded();
    }

    public final void zzg(long j) {
        this.zzwm.setText(DateUtils.formatElapsedTime(j / 1000));
    }

    public final void zzk(boolean z) {
        this.zzut = z;
    }
}
