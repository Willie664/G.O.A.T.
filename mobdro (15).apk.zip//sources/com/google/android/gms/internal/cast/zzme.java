package com.google.android.gms.internal.cast;

public final class zzme implements zzmm {
    public zzmm[] zzboz;

    public zzme(zzmm... zzmmArr) {
        this.zzboz = zzmmArr;
    }

    public final boolean zza(Class<?> cls) {
        for (zzmm zza : this.zzboz) {
            if (zza.zza(cls)) {
                return true;
            }
        }
        return false;
    }

    public final zzmj zzb(Class<?> cls) {
        for (zzmm zzmm : this.zzboz) {
            if (zzmm.zza(cls)) {
                return zzmm.zzb(cls);
            }
        }
        String name = cls.getName();
        throw new UnsupportedOperationException(name.length() != 0 ? "No factory is available for message type: ".concat(name) : new String("No factory is available for message type: "));
    }
}
