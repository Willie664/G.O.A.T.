package com.google.android.gms.internal.cast;

import b.c.a.b.d.k.h;
import com.google.android.gms.common.api.Status;

public final /* synthetic */ class zzz implements zzba {
    public static final zzba zzmu = new zzz();

    public final h zza(Object obj) {
        return zzt.zza((Status) obj);
    }
}
