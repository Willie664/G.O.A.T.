package com.google.android.gms.internal.cast;

public enum zzhw implements zzlg {
    PRECACHE_MESSAGE_RESULT_UNKNOWN(0),
    PRECACHE_MESSAGE_RESULT_SENT(1),
    PRECACHE_MESSAGE_RESULT_FAILED(2);
    
    public static final zzlf<zzhw> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzhz();
    }

    /* access modifiers changed from: public */
    zzhw(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzhy.zzago;
    }

    public final String toString() {
        return "<" + zzhw.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
