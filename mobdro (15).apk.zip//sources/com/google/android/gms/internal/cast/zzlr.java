package com.google.android.gms.internal.cast;

import java.util.Iterator;
import java.util.Map;

public final class zzlr<K> implements Iterator<Map.Entry<K, Object>> {
    public Iterator<Map.Entry<K, Object>> zzbok;

    public zzlr(Iterator<Map.Entry<K, Object>> it) {
        this.zzbok = it;
    }

    public final boolean hasNext() {
        return this.zzbok.hasNext();
    }

    public final /* synthetic */ Object next() {
        Map.Entry next = this.zzbok.next();
        return next.getValue() instanceof zzlq ? new zzls(next) : next;
    }

    public final void remove() {
        this.zzbok.remove();
    }
}
