package com.google.android.gms.internal.cast;

public final class zzhg implements zzli {
    public static final zzli zzago = new zzhg();
}
