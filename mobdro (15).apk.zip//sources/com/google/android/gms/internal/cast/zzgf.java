package com.google.android.gms.internal.cast;

public final class zzgf implements zzli {
    public static final zzli zzago = new zzgf();
}
