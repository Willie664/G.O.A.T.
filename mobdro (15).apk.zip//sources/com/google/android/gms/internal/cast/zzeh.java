package com.google.android.gms.internal.cast;

import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class zzeh<T> extends zzeg<T> {
    public static final zzeh<Object> zzafl = new zzeh<>();

    public final boolean equals(@NullableDecl Object obj) {
        return obj == this;
    }

    public final int hashCode() {
        return 2040732332;
    }

    public final String toString() {
        return "Optional.absent()";
    }

    @NullableDecl
    public final T zzfu() {
        return null;
    }
}
