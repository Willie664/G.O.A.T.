package com.google.android.gms.internal.cast;

public final class zzgx implements zzli {
    public static final zzli zzago = new zzgx();
}
