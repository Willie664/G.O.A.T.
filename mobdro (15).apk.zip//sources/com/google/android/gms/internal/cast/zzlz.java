package com.google.android.gms.internal.cast;

import b.a.a.a.a;
import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

public final class zzlz extends zzjx<Long> implements zzlm<Long>, zzmy, RandomAccess {
    public static final zzlz zzbov;
    public int size;
    public long[] zzbow;

    static {
        zzlz zzlz = new zzlz(new long[0], 0);
        zzbov = zzlz;
        zzlz.zzib();
    }

    public zzlz() {
        this(new long[10], 0);
    }

    public zzlz(long[] jArr, int i) {
        this.zzbow = jArr;
        this.size = i;
    }

    private final void zzbd(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzbe(i));
        }
    }

    private final String zzbe(int i) {
        return a.a(35, "Index:", i, ", Size:", this.size);
    }

    public static zzlz zzjv() {
        return zzbov;
    }

    public final /* synthetic */ void add(int i, Object obj) {
        int i2;
        long longValue = ((Long) obj).longValue();
        zzic();
        if (i < 0 || i > (i2 = this.size)) {
            throw new IndexOutOfBoundsException(zzbe(i));
        }
        long[] jArr = this.zzbow;
        if (i2 < jArr.length) {
            System.arraycopy(jArr, i, jArr, i + 1, i2 - i);
        } else {
            long[] jArr2 = new long[(((i2 * 3) / 2) + 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i);
            System.arraycopy(this.zzbow, i, jArr2, i + 1, this.size - i);
            this.zzbow = jArr2;
        }
        this.zzbow[i] = longValue;
        this.size++;
        this.modCount++;
    }

    public final /* synthetic */ boolean add(Object obj) {
        long longValue = ((Long) obj).longValue();
        zzic();
        int i = this.size;
        long[] jArr = this.zzbow;
        if (i == jArr.length) {
            long[] jArr2 = new long[(((i * 3) / 2) + 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i);
            this.zzbow = jArr2;
        }
        long[] jArr3 = this.zzbow;
        int i2 = this.size;
        this.size = i2 + 1;
        jArr3[i2] = longValue;
        return true;
    }

    public final boolean addAll(Collection<? extends Long> collection) {
        zzic();
        zzld.checkNotNull(collection);
        if (!(collection instanceof zzlz)) {
            return super.addAll(collection);
        }
        zzlz zzlz = (zzlz) collection;
        int i = zzlz.size;
        if (i == 0) {
            return false;
        }
        int i2 = this.size;
        if (Integer.MAX_VALUE - i2 >= i) {
            int i3 = i2 + i;
            long[] jArr = this.zzbow;
            if (i3 > jArr.length) {
                this.zzbow = Arrays.copyOf(jArr, i3);
            }
            System.arraycopy(zzlz.zzbow, 0, this.zzbow, this.size, zzlz.size);
            this.size = i3;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzlz)) {
            return super.equals(obj);
        }
        zzlz zzlz = (zzlz) obj;
        if (this.size != zzlz.size) {
            return false;
        }
        long[] jArr = zzlz.zzbow;
        for (int i = 0; i < this.size; i++) {
            if (this.zzbow[i] != jArr[i]) {
                return false;
            }
        }
        return true;
    }

    public final /* synthetic */ Object get(int i) {
        return Long.valueOf(getLong(i));
    }

    public final long getLong(int i) {
        zzbd(i);
        return this.zzbow[i];
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + zzld.zzu(this.zzbow[i2]);
        }
        return i;
    }

    public final /* synthetic */ Object remove(int i) {
        zzic();
        zzbd(i);
        long[] jArr = this.zzbow;
        long j = jArr[i];
        int i2 = this.size;
        if (i < i2 - 1) {
            System.arraycopy(jArr, i + 1, jArr, i, (i2 - i) - 1);
        }
        this.size--;
        this.modCount++;
        return Long.valueOf(j);
    }

    public final boolean remove(Object obj) {
        zzic();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Long.valueOf(this.zzbow[i]))) {
                long[] jArr = this.zzbow;
                System.arraycopy(jArr, i + 1, jArr, i, (this.size - i) - 1);
                this.size--;
                this.modCount++;
                return true;
            }
        }
        return false;
    }

    public final void removeRange(int i, int i2) {
        zzic();
        if (i2 >= i) {
            long[] jArr = this.zzbow;
            System.arraycopy(jArr, i2, jArr, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        long longValue = ((Long) obj).longValue();
        zzic();
        zzbd(i);
        long[] jArr = this.zzbow;
        long j = jArr[i];
        jArr[i] = longValue;
        return Long.valueOf(j);
    }

    public final int size() {
        return this.size;
    }

    public final /* synthetic */ zzlm zzbf(int i) {
        if (i >= this.size) {
            return new zzlz(Arrays.copyOf(this.zzbow, i), this.size);
        }
        throw new IllegalArgumentException();
    }
}
