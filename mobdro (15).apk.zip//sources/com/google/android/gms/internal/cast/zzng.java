package com.google.android.gms.internal.cast;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class zzng extends zznd<FieldDescriptorType, Object> {
    public zzng(int i) {
        super(i, (zzng) null);
    }

    public final void zzib() {
        if (!isImmutable()) {
            for (int i = 0; i < zzkm(); i++) {
                Map.Entry zzbm = zzbm(i);
                if (((zzkw) zzbm.getKey()).zziw()) {
                    zzbm.setValue(Collections.unmodifiableList((List) zzbm.getValue()));
                }
            }
            for (Map.Entry entry : zzkn()) {
                if (((zzkw) entry.getKey()).zziw()) {
                    entry.setValue(Collections.unmodifiableList((List) entry.getValue()));
                }
            }
        }
        super.zzib();
    }
}
