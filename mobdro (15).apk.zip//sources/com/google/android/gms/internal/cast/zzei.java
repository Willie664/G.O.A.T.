package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzlc;

public final class zzei {

    public static final class zza extends zzlc<zza, zzd> implements zzmn {
        public static final zza zzaga;
        public static volatile zzmv<zza> zzagb;
        public int zzafn;
        public int zzafo;
        public int zzafp;
        public int zzafq;
        public int zzafr;
        public int zzafs;
        public int zzaft;
        public int zzafu;
        public int zzafv;
        public int zzafw;
        public int zzafx;
        public int zzafy;
        public boolean zzafz;

        /* renamed from: com.google.android.gms.internal.cast.zzei$zza$zza  reason: collision with other inner class name */
        public enum C0127zza implements zzlg {
            AUDIO_FORMAT_UNKNOWN(0),
            AUDIO_FORMAT_AV_AUDIO_PCM_FLOAT_32(1),
            AUDIO_FORMAT_AV_AUDIO_PCM_FLOAT_64(2),
            AUDIO_FORMAT_AV_AUDIO_PCM_INT_16(3),
            AUDIO_FORMAT_AV_AUDIO_PCM_INT_32(4);
            
            public static final zzlf<C0127zza> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzel();
            }

            /* access modifiers changed from: public */
            C0127zza(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzem.zzago;
            }

            public final String toString() {
                return "<" + C0127zza.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        public enum zzb implements zzlg {
            BITRATE_MODE_UNKNOWN(0),
            BITRATE_MODE_FIXED(1),
            BITRATE_MODE_ADAPTIVE(2);
            
            public static final zzlf<zzb> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzeo();
            }

            /* access modifiers changed from: public */
            zzb(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzen.zzago;
            }

            public final String toString() {
                return "<" + zzb.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        public enum zzc implements zzlg {
            RENDER_BACKEND_UNKNOWN(0),
            RENDER_BACKEND_OPENGL_ES_2(1),
            RENDER_BACKEND_OPENGL_ES_3(2),
            RENDER_BACKEND_METAL(3);
            
            public static final zzlf<zzc> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzeq();
            }

            /* access modifiers changed from: public */
            zzc(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzep.zzago;
            }

            public final String toString() {
                return "<" + zzc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        public static final class zzd extends zzlc.zza<zza, zzd> implements zzmn {
            public zzd() {
                super(zza.zzaga);
            }

            public /* synthetic */ zzd(zzek zzek) {
                this();
            }
        }

        public enum zze implements zzlg {
            RENDER_TARGET_UNKNOWN(0),
            RENDER_TARGET_CAMERA(1),
            RENDER_TARGET_RENDER_TEXTURE_SET_ON_CAMERA(2),
            RENDER_TARGET_RENDER_TEXTURE(3);
            
            public static final zzlf<zze> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzer();
            }

            /* access modifiers changed from: public */
            zze(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzes.zzago;
            }

            public final String toString() {
                return "<" + zze.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        public enum zzf implements zzlg {
            TARGET_DELAY_UNKNOWN(0),
            TARGET_DELAY_MINIMUM(1),
            TARGET_DELAY_LOW(2),
            TARGET_DELAY_NORMAL(3),
            TARGET_DELAY_HIGH(4);
            
            public static final zzlf<zzf> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzeu();
            }

            /* access modifiers changed from: public */
            zzf(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzet.zzago;
            }

            public final String toString() {
                return "<" + zzf.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        public enum zzg implements zzlg {
            TARGET_FPS_UNKNOWN(0),
            TARGET_FPS_15(1),
            TARGET_FPS_24(2),
            TARGET_FPS_25(3),
            TARGET_FPS_30(4),
            TARGET_FPS_60(5);
            
            public static final zzlf<zzg> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzev();
            }

            /* access modifiers changed from: public */
            zzg(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzew.zzago;
            }

            public final String toString() {
                return "<" + zzg.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        static {
            zza zza = new zza();
            zzaga = zza;
            zzlc.zza(zza.class, zza);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzek.zzagc[i - 1]) {
                case 1:
                    return new zza();
                case 2:
                    return new zzd((zzek) null);
                case 3:
                    return zzlc.zza((zzml) zzaga, "\u0001\f\u0000\u0001\u0001\f\f\u0000\u0000\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\f\u0002\u0004\f\u0003\u0005\f\u0004\u0006\f\u0005\u0007\f\u0006\b\f\u0007\t\u0004\b\n\u0004\t\u000b\u0004\n\f\u0007\u000b", new Object[]{"zzafn", "zzafo", "zzafp", "zzafq", zzc.zzfx(), "zzafr", zze.zzfx(), "zzafs", zzb.zzfx(), "zzaft", zzf.zzfx(), "zzafu", zzg.zzfx(), "zzafv", C0127zza.zzfx(), "zzafw", "zzafx", "zzafy", "zzafz"});
                case 4:
                    return zzaga;
                case 5:
                    zzmv<zza> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zza.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzaga);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzb extends zzlc<zzb, C0128zzb> implements zzmn {
        public static volatile zzmv<zzb> zzagb;
        public static final zzb zzahs;
        public int zzafn;
        public int zzahm;
        public int zzahn;
        public int zzaho;
        public int zzahp;
        public zza zzahq;
        public int zzahr;

        public enum zza implements zzlg {
            ERROR_UNKNOWN(0),
            ERROR_SETUP_DEVICE_NOT_SUPPORTED(1),
            ERROR_SETUP_GOOGLE_PLAY_SERVICES_UPDATE_REQUIRED(2),
            ERROR_SETUP_CONFIGURATION_REJECTED_BY_RECEIVER(3),
            ERROR_OPENGL_UNKNOWN_ERROR(4),
            ERROR_OPENGL_INITIALIZATION_ERROR(5),
            ERROR_OPENGL_CONTEXT_CREATION_ERROR(6),
            ERROR_OPENGL_SHADER_COMPILATION_ERROR(7),
            ERROR_OPENGL_SHADER_LINKING_ERROR(8),
            ERROR_OPENGL_RENDERING_ERROR(9),
            ERROR_OPENGL_TEXTURE_BINDING_ERROR(10),
            ERROR_OPENGL_SHUTDOWN_ERROR(11),
            ERROR_OPENGL_UNSUPPORTED_OPENGL_API_ERROR(12),
            ERROR_OPENGL_TEXTURE_CACHE_CREATION_ERROR(13),
            ERROR_OPENGL_LUMA_PASS_PIPELINE_CREATION_ERROR(14),
            ERROR_OPENGL_CHROMA_PASS_PIPELINE_CREATION_ERROR(15),
            ERROR_OPENGL_SHADER_DECOMPRESSION_ERROR(16),
            ERROR_OPENGL_PIXELBUFFER_CREATION_ERROR(17),
            ERROR_OPENGL_LUMA_TEXTURE_CACHE_CREATION_ERROR(18),
            ERROR_OPENGL_CHROMA_TEXTURE_CACHE_CREATION_ERROR(19),
            ERROR_OPENGL_MAKE_CURRENT_ERROR(20),
            ERROR_OPENGL_EGL_CONTEXT_ERROR(21),
            ERROR_OPENGL_EGL_BAD_NATIVE_SURFACE_ERROR(22),
            ERROR_METAL_UNKNOWN_ERROR(23),
            ERROR_METAL_TEXTURE_CACHE_CREATION_ERROR(24),
            ERROR_METAL_SHADER_DECOMPRESSION_ERROR(25),
            ERROR_METAL_SHADER_LOADING_ERROR(26),
            ERROR_METAL_BUFFER_ALLOCATION_ERROR(27),
            ERROR_METAL_LUMA_PASS_PIPELINE_CREATION_ERROR(28),
            ERROR_METAL_CHROMA_PASS_BUFFER_CREATION_ERROR(29),
            ERROR_METAL_CHROMA_PASS_TEXTURE_CREATION_ERROR(30),
            ERROR_METAL_CHROMA_PASS_PIPELINE_CREATION_ERROR(31),
            ERROR_METAL_PIXELBUFFER_CREATION_ERROR(32),
            ERROR_METAL_TEXTURE_CREATION_ERROR(33),
            ERROR_METAL_LUMA_RENDER_COMMAND_ENCODER_CREATION_ERROR(34),
            ERROR_METAL_CHROMA_RENDER_COMMAND_ENCODER_CREATION_ERROR(35),
            ERROR_METAL_COMMAND_BUFFER_EXECUTION_ERROR(36),
            ERROR_AUDIO_CONVERTER_CREATION_ERROR(37),
            ERROR_AUDIO_CONVERTER_PRIMEMETHOD_ERROR(38),
            ERROR_AUDIO_CONVERTER_CONVERSION_ERROR(39),
            ERROR_SETUP_FEATURE_NOT_SUPPORTED(40),
            ERROR_DUPLICATE_REQUEST(41),
            ERROR_PROTOCOL_ERROR(42);
            
            public static final zzlf<zza> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzey();
            }

            /* access modifiers changed from: public */
            zza(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzex.zzago;
            }

            public final String toString() {
                return "<" + zza.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        /* renamed from: com.google.android.gms.internal.cast.zzei$zzb$zzb  reason: collision with other inner class name */
        public static final class C0128zzb extends zzlc.zza<zzb, C0128zzb> implements zzmn {
            public C0128zzb() {
                super(zzb.zzahs);
            }

            public /* synthetic */ C0128zzb(zzek zzek) {
                this();
            }
        }

        public enum zzc implements zzlg {
            PLUGIN_TYPE_UNKNOWN(0),
            PLUGIN_TYPE_UNITY_3D(1);
            
            public static final zzlf<zzc> zzagi = null;
            public final int value;

            /* access modifiers changed from: public */
            static {
                zzagi = new zzez();
            }

            /* access modifiers changed from: public */
            zzc(int i) {
                this.value = i;
            }

            public static zzli zzfx() {
                return zzfb.zzago;
            }

            public final String toString() {
                return "<" + zzc.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
            }

            public final int zzfw() {
                return this.value;
            }
        }

        static {
            zzb zzb = new zzb();
            zzahs = zzb;
            zzlc.zza(zzb.class, zzb);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzek.zzagc[i - 1]) {
                case 1:
                    return new zzb();
                case 2:
                    return new C0128zzb((zzek) null);
                case 3:
                    return zzlc.zza((zzml) zzahs, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0004\u0000\u0002\f\u0001\u0003\u0004\u0002\u0004\u0004\u0003\u0005\t\u0004\u0006\f\u0005", new Object[]{"zzafn", "zzahm", "zzahn", zzc.zzfx(), "zzaho", "zzahp", "zzahq", "zzahr", zza.zzfx()});
                case 4:
                    return zzahs;
                case 5:
                    zzmv<zzb> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzb.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzahs);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }
}
