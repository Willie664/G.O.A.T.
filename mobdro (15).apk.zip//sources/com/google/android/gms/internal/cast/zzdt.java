package com.google.android.gms.internal.cast;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import androidx.collection.SimpleArrayMap;

public class zzdt extends AnimatorListenerAdapter {
    public SimpleArrayMap<Animator, Boolean> zzafb = new SimpleArrayMap<>();

    public void onAnimationCancel(Animator animator) {
        this.zzafb.put(animator, true);
    }

    public void onAnimationStart(Animator animator) {
        this.zzafb.put(animator, false);
    }

    public final boolean zzb(Animator animator) {
        return this.zzafb.containsKey(animator) && this.zzafb.get(animator).booleanValue();
    }
}
