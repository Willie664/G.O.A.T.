package com.google.android.gms.internal.cast;

import android.view.View;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.a;

public final class zzbz extends a {
    public final View view;
    public final int zzwk;

    public zzbz(View view2, int i) {
        this.view = view2;
        this.zzwk = i;
    }

    private final void zzed() {
        int i;
        View view2;
        d remoteMediaClient = getRemoteMediaClient();
        if (remoteMediaClient == null || !remoteMediaClient.l() || remoteMediaClient.h().m == 0) {
            view2 = this.view;
            i = this.zzwk;
        } else {
            view2 = this.view;
            i = 0;
        }
        view2.setVisibility(i);
    }

    public final void onMediaStatusUpdated() {
        zzed();
    }

    public final void onSessionConnected(c cVar) {
        super.onSessionConnected(cVar);
        zzed();
    }

    public final void onSessionEnded() {
        this.view.setVisibility(this.zzwk);
        super.onSessionEnded();
    }
}
