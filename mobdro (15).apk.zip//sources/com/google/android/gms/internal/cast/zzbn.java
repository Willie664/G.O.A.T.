package com.google.android.gms.internal.cast;

import b.c.a.b.c.a;

public final class zzbn extends a.d {
    public final /* synthetic */ zzbo zzvu;

    public zzbn(zzbo zzbo) {
        this.zzvu = zzbo;
    }

    public final void onVolumeChanged() {
        this.zzvu.zzed();
    }
}
