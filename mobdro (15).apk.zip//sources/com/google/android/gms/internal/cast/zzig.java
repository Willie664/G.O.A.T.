package com.google.android.gms.internal.cast;

public final class zzig implements zzlf<zzih> {
}
