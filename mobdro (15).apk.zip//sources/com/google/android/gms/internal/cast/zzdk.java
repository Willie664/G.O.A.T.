package com.google.android.gms.internal.cast;

import android.os.Parcel;
import android.os.RemoteException;
import android.view.Surface;

public abstract class zzdk extends zza implements zzdl {
    public zzdk() {
        super("com.google.android.gms.cast.remote_display.ICastRemoteDisplayCallbacks");
    }

    public final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        if (i == 1) {
            zza(parcel.readInt(), parcel.readInt(), (Surface) zzd.zza(parcel, Surface.CREATOR));
        } else if (i == 2) {
            onError(parcel.readInt());
        } else if (i == 3) {
            onDisconnected();
        } else if (i != 4) {
            return false;
        } else {
            zzh();
        }
        parcel2.writeNoException();
        return true;
    }
}
