package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzlc;
import java.io.IOException;
import java.util.Map;

public final class zzks extends zzkt<zzlc.zze> {
    public final int zza(Map.Entry<?, ?> entry) {
        zzlc.zze zze = (zzlc.zze) entry.getKey();
        throw new NoSuchMethodError();
    }

    public final void zza(zzon zzon, Map.Entry<?, ?> entry) throws IOException {
        zzlc.zze zze = (zzlc.zze) entry.getKey();
        throw new NoSuchMethodError();
    }

    public final zzku<zzlc.zze> zzc(Object obj) {
        return ((zzlc.zzb) obj).zzbnb;
    }

    public final zzku<zzlc.zze> zzd(Object obj) {
        zzlc.zzb zzb = (zzlc.zzb) obj;
        if (zzb.zzbnb.isImmutable()) {
            zzb.zzbnb = (zzku) zzb.zzbnb.clone();
        }
        return zzb.zzbnb;
    }

    public final void zze(Object obj) {
        zzc(obj).zzib();
    }

    public final boolean zze(zzml zzml) {
        return zzml instanceof zzlc.zzb;
    }
}
