package com.google.android.gms.internal.cast;

import b.a.a.a.a;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class zzej<T> extends zzeg<T> {
    public final T zzafm;

    public zzej(T t) {
        this.zzafm = t;
    }

    public final boolean equals(@NullableDecl Object obj) {
        if (obj instanceof zzej) {
            return this.zzafm.equals(((zzej) obj).zzafm);
        }
        return false;
    }

    public final int hashCode() {
        return this.zzafm.hashCode() + 1502476572;
    }

    public final String toString() {
        String valueOf = String.valueOf(this.zzafm);
        return a.a(valueOf.length() + 13, "Optional.of(", valueOf, ")");
    }

    public final T zzfu() {
        return this.zzafm;
    }
}
