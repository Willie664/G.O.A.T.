package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzlc;

public final class zzmz implements zzmj {
    public final int flags;
    public final String info;
    public final Object[] zzbpi;
    public final zzml zzbpl;

    public zzmz(zzml zzml, String str, Object[] objArr) {
        this.zzbpl = zzml;
        this.info = str;
        this.zzbpi = objArr;
        char charAt = str.charAt(0);
        if (charAt < 55296) {
            this.flags = charAt;
            return;
        }
        char c2 = charAt & 8191;
        int i = 13;
        int i2 = 1;
        while (true) {
            int i3 = i2 + 1;
            char charAt2 = str.charAt(i2);
            if (charAt2 >= 55296) {
                c2 |= (charAt2 & 8191) << i;
                i += 13;
                i2 = i3;
            } else {
                this.flags = c2 | (charAt2 << i);
                return;
            }
        }
    }

    public final int zzjz() {
        return (this.flags & 1) == 1 ? zzlc.zzd.zzbnk : zzlc.zzd.zzbnl;
    }

    public final boolean zzka() {
        return (this.flags & 2) == 2;
    }

    public final zzml zzkb() {
        return this.zzbpl;
    }

    public final String zzkj() {
        return this.info;
    }

    public final Object[] zzkk() {
        return this.zzbpi;
    }
}
