package com.google.android.gms.internal.cast;

import com.google.android.gms.internal.cast.zzlc;

public final class zzmc implements zznb {
    public static final zzmm zzboy = new zzmb();
    public final zzmm zzbox;

    public zzmc() {
        this(new zzme(zzla.zziy(), zzjw()));
    }

    public zzmc(zzmm zzmm) {
        this.zzbox = (zzmm) zzld.zza(zzmm, "messageInfoFactory");
    }

    public static boolean zza(zzmj zzmj) {
        return zzmj.zzjz() == zzlc.zzd.zzbnk;
    }

    public static zzmm zzjw() {
        try {
            return (zzmm) Class.forName("com.google.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", new Class[0]).invoke((Object) null, new Object[0]);
        } catch (Exception unused) {
            return zzboy;
        }
    }

    public final <T> zznc<T> zzd(Class<T> cls) {
        Class<zzlc> cls2 = zzlc.class;
        zzne.zzf((Class<?>) cls);
        zzmj zzb = this.zzbox.zzb(cls);
        if (zzb.zzka()) {
            return cls2.isAssignableFrom(cls) ? zzms.zza(zzne.zzkt(), zzkv.zzis(), zzb.zzkb()) : zzms.zza(zzne.zzkr(), zzkv.zzit(), zzb.zzkb());
        }
        if (cls2.isAssignableFrom(cls)) {
            boolean zza = zza(zzb);
            zzmu zzkg = zzmw.zzkg();
            zzlv zzju = zzlv.zzju();
            zznu<?, ?> zzkt = zzne.zzkt();
            if (zza) {
                return zzmp.zza(cls, zzb, zzkg, zzju, zzkt, zzkv.zzis(), zzmk.zzkd());
            }
            return zzmp.zza(cls, zzb, zzkg, zzju, zzkt, (zzkt<?>) null, zzmk.zzkd());
        }
        boolean zza2 = zza(zzb);
        zzmu zzkf = zzmw.zzkf();
        zzlv zzjt = zzlv.zzjt();
        if (zza2) {
            return zzmp.zza(cls, zzb, zzkf, zzjt, zzne.zzkr(), zzkv.zzit(), zzmk.zzkc());
        }
        return zzmp.zza(cls, zzb, zzkf, zzjt, zzne.zzks(), (zzkt<?>) null, zzmk.zzkc());
    }
}
