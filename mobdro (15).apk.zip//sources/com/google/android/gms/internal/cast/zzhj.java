package com.google.android.gms.internal.cast;

public enum zzhj implements zzlg {
    LAUNCH_UNKNOWN(0),
    JOIN(1),
    LAUNCH(2);
    
    public static final zzlf<zzhj> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzhi();
    }

    /* access modifiers changed from: public */
    zzhj(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzhl.zzago;
    }

    public final String toString() {
        return "<" + zzhj.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
