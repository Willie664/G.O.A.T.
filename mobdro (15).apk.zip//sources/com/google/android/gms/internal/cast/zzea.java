package com.google.android.gms.internal.cast;

import android.annotation.TargetApi;
import android.view.Choreographer;

@TargetApi(16)
public final class zzea extends zzdu {
    public Choreographer zzafh = Choreographer.getInstance();

    public final void zza(zzdw zzdw) {
        this.zzafh.postFrameCallback(zzdw.zzfm());
    }
}
