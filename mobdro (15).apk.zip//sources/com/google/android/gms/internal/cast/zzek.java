package com.google.android.gms.internal.cast;

public final /* synthetic */ class zzek {
    public static final /* synthetic */ int[] zzagc;

    /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
    /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x002f */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0037 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000f */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0017 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x001f */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0027 */
    static {
        /*
            int[] r0 = com.google.android.gms.internal.cast.zzlc.zzd.zzjl()
            int r0 = r0.length
            int[] r0 = new int[r0]
            zzagc = r0
            r1 = 1
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbnf     // Catch:{ NoSuchFieldError -> 0x000f }
            int r2 = r2 - r1
            r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x000f }
        L_0x000f:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x0017 }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbng     // Catch:{ NoSuchFieldError -> 0x0017 }
            int r2 = r2 - r1
            r3 = 2
            r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0017 }
        L_0x0017:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x001f }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbne     // Catch:{ NoSuchFieldError -> 0x001f }
            int r2 = r2 - r1
            r3 = 3
            r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x001f }
        L_0x001f:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x0027 }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbnh     // Catch:{ NoSuchFieldError -> 0x0027 }
            int r2 = r2 - r1
            r3 = 4
            r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0027 }
        L_0x0027:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x002f }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbni     // Catch:{ NoSuchFieldError -> 0x002f }
            int r2 = r2 - r1
            r3 = 5
            r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x002f }
        L_0x002f:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x0037 }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbnc     // Catch:{ NoSuchFieldError -> 0x0037 }
            int r2 = r2 - r1
            r3 = 6
            r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0037 }
        L_0x0037:
            int[] r0 = zzagc     // Catch:{ NoSuchFieldError -> 0x003f }
            int r2 = com.google.android.gms.internal.cast.zzlc.zzd.zzbnd     // Catch:{ NoSuchFieldError -> 0x003f }
            int r2 = r2 - r1
            r1 = 7
            r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x003f }
        L_0x003f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.cast.zzek.<clinit>():void");
    }
}
