package com.google.android.gms.internal.cast;

import java.util.Map;

public interface zzmi {
    int zzb(int i, Object obj, Object obj2);

    Object zzc(Object obj, Object obj2);

    zzmg<?, ?> zzi(Object obj);

    Map<?, ?> zzj(Object obj);

    Object zzk(Object obj);
}
