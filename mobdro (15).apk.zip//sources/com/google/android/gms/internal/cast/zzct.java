package com.google.android.gms.internal.cast;

import b.c.a.b.c.h.a;
import com.google.android.gms.common.api.Status;
import org.json.JSONObject;

public final class zzct implements a.b {
    public final String zzaau;
    public final JSONObject zzaav;
    public final long zzfd;
    public final Status zzji;

    public zzct(Status status, String str, long j, JSONObject jSONObject) {
        this.zzji = status;
        this.zzaau = str;
        this.zzfd = j;
        this.zzaav = jSONObject;
    }

    public final JSONObject getExtraMessageData() {
        return this.zzaav;
    }

    public final String getPlayerId() {
        return this.zzaau;
    }

    public final long getRequestId() {
        return this.zzfd;
    }

    public final Status getStatus() {
        return this.zzji;
    }
}
