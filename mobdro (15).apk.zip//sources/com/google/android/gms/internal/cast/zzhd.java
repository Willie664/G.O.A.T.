package com.google.android.gms.internal.cast;

public enum zzhd implements zzlg {
    SUCCESS(0),
    LOW_API_LEVEL(1),
    DEVICE_AUTH_FAILURE(2),
    DEVICE_UNAUTHENTICATED(3),
    PASSWORD_ENCRYPTION_FAILURE(4),
    NO_WIFI_MANAGER(5),
    WEP_RESTRICTION_PRE_O(6),
    NO_MATCHING_NETWORK(7),
    EMPTY_PASSWORD(8);
    
    public static final zzlf<zzhd> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzhc();
    }

    /* access modifiers changed from: public */
    zzhd(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzhf.zzago;
    }

    public final String toString() {
        return "<" + zzhd.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
