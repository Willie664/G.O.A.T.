package com.google.android.gms.internal.cast;

public final class zzhu implements zzlf<zzhv> {
}
