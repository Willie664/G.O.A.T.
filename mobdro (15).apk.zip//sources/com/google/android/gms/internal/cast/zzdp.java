package com.google.android.gms.internal.cast;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzdp extends IInterface {
    void zzad(int i) throws RemoteException;
}
