package com.google.android.gms.internal.cast;

public final class zzjj implements zzlf<zzjg> {
}
