package com.google.android.gms.internal.cast;

public enum zzfl implements zzlg {
    APPLICATION_CONNECTION_FAILED_REASON_UNKNOWN(0),
    APPLICATION_NOT_FOUND(1),
    APPLICATION_NOT_RUNNING(2),
    APPLICATION_NOT_ALLOWED(3),
    LAUNCH_CANCELLED(4),
    LAUNCH_TIMED_OUT(5),
    INVALID_REQUEST(6);
    
    public static final zzlf<zzfl> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzfk();
    }

    /* access modifiers changed from: public */
    zzfl(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzfn.zzago;
    }

    public final String toString() {
        return "<" + zzfl.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
