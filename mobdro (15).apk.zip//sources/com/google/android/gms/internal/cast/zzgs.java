package com.google.android.gms.internal.cast;

public final class zzgs implements zzli {
    public static final zzli zzago = new zzgs();
}
