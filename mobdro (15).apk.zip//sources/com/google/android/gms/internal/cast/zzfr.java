package com.google.android.gms.internal.cast;

public enum zzfr implements zzlg {
    RESULT_UNKNOWN(0),
    DECODE_SUCCESS(1),
    REQUEST_TIMED_OUT(2),
    USER_CANCELLED(3),
    USER_INTERRUPTED_AUDIO_PARING(4);
    
    public static final zzlf<zzfr> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzfq();
    }

    /* access modifiers changed from: public */
    zzfr(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzft.zzago;
    }

    public final String toString() {
        return "<" + zzfr.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
