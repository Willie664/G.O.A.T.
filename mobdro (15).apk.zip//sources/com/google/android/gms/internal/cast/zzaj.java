package com.google.android.gms.internal.cast;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import b.c.a.b.c.g.a1;
import b.c.a.b.c.g.h0;
import b.c.a.b.c.g.j0;
import b.c.a.b.c.g.m0;
import b.c.a.b.c.g.q0;
import b.c.a.b.c.g.t0;
import b.c.a.b.c.g.w.f.f;
import b.c.a.b.c.g.w.f.g;
import b.c.a.b.e.a;
import com.google.android.gms.cast.framework.CastOptions;
import java.util.Map;

public final class zzaj extends zzb implements zzag {
    public zzaj(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.cast.framework.internal.ICastDynamiteModule");
    }

    public final j0 zza(a aVar, CastOptions castOptions, zzai zzai, Map map) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) aVar);
        zzd.zza(zza, (Parcelable) castOptions);
        zzd.zza(zza, (IInterface) zzai);
        zza.writeMap(map);
        Parcel zza2 = zza(1, zza);
        j0 a2 = j0.a.a(zza2.readStrongBinder());
        zza2.recycle();
        return a2;
    }

    public final m0 zza(CastOptions castOptions, a aVar, h0 h0Var) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (Parcelable) castOptions);
        zzd.zza(zza, (IInterface) aVar);
        zzd.zza(zza, (IInterface) h0Var);
        Parcel zza2 = zza(3, zza);
        m0 a2 = m0.a.a(zza2.readStrongBinder());
        zza2.recycle();
        return a2;
    }

    public final q0 zza(a aVar, a aVar2, a aVar3) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) aVar);
        zzd.zza(zza, (IInterface) aVar2);
        zzd.zza(zza, (IInterface) aVar3);
        Parcel zza2 = zza(5, zza);
        q0 a2 = q0.a.a(zza2.readStrongBinder());
        zza2.recycle();
        return a2;
    }

    public final t0 zza(String str, String str2, a1 a1Var) throws RemoteException {
        Parcel zza = zza();
        zza.writeString(str);
        zza.writeString(str2);
        zzd.zza(zza, (IInterface) a1Var);
        Parcel zza2 = zza(2, zza);
        t0 a2 = t0.a.a(zza2.readStrongBinder());
        zza2.recycle();
        return a2;
    }

    public final f zza(a aVar, g gVar, int i, int i2, boolean z, long j, int i3, int i4, int i5) throws RemoteException {
        Parcel zza = zza();
        zzd.zza(zza, (IInterface) aVar);
        zzd.zza(zza, (IInterface) gVar);
        zza.writeInt(i);
        zza.writeInt(i2);
        zzd.writeBoolean(zza, z);
        zza.writeLong(j);
        zza.writeInt(i3);
        zza.writeInt(i4);
        zza.writeInt(i5);
        Parcel zza2 = zza(6, zza);
        f a2 = f.a.a(zza2.readStrongBinder());
        zza2.recycle();
        return a2;
    }
}
