package com.google.android.gms.internal.cast;

public final class zzga implements zzli {
    public static final zzli zzago = new zzga();
}
