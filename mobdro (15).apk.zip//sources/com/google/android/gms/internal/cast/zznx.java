package com.google.android.gms.internal.cast;

import java.util.Iterator;

public final class zznx implements Iterator<String> {
    public Iterator<String> zzbra = this.zzbrb.zzbqz.iterator();
    public final /* synthetic */ zznv zzbrb;

    public zznx(zznv zznv) {
        this.zzbrb = zznv;
    }

    public final boolean hasNext() {
        return this.zzbra.hasNext();
    }

    public final /* synthetic */ Object next() {
        return this.zzbra.next();
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
