package com.google.android.gms.internal.cast;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class zzmx {
    public static final zzmx zzbqa = new zzmx();
    public final zznb zzbqb = new zzmc();
    public final ConcurrentMap<Class<?>, zznc<?>> zzbqc = new ConcurrentHashMap();

    public static zzmx zzki() {
        return zzbqa;
    }

    public final <T> zznc<T> zze(Class<T> cls) {
        zzld.zza(cls, "messageType");
        zznc<T> zznc = (zznc) this.zzbqc.get(cls);
        if (zznc != null) {
            return zznc;
        }
        zznc<T> zzd = this.zzbqb.zzd(cls);
        zzld.zza(cls, "messageType");
        zzld.zza(zzd, "schema");
        zznc<T> putIfAbsent = this.zzbqc.putIfAbsent(cls, zzd);
        return putIfAbsent != null ? putIfAbsent : zzd;
    }

    public final <T> zznc<T> zzn(T t) {
        return zze(t.getClass());
    }
}
