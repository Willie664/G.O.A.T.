package com.google.android.gms.internal.cast;

import android.annotation.TargetApi;
import android.hardware.display.VirtualDisplay;
import b.c.a.b.c.b;
import b.c.a.b.c.i.b;
import b.c.a.b.d.k.a;
import b.c.a.b.d.k.d;
import b.c.a.b.d.k.e;

@Deprecated
public final class zzcz {
    public static final b zzy = new b("CastRemoteDisplayApiImpl");
    public final zzdp zzaeo = new zzcy(this);
    public VirtualDisplay zzbm;
    public a<?> zzdn;

    public zzcz(a aVar) {
        this.zzdn = aVar;
    }

    /* access modifiers changed from: private */
    @TargetApi(19)
    public final void zzg() {
        VirtualDisplay virtualDisplay = this.zzbm;
        if (virtualDisplay != null) {
            if (virtualDisplay.getDisplay() != null) {
                zzy.a(b.a.a.a.a.a(38, "releasing virtual display: ", this.zzbm.getDisplay().getDisplayId()), new Object[0]);
            }
            this.zzbm.release();
            this.zzbm = null;
        }
    }

    public final e<b.c> startRemoteDisplay(d dVar, String str) {
        b.c.a.b.c.i.b bVar = zzy;
        Object[] objArr = new Object[0];
        if (bVar.a()) {
            bVar.b("startRemoteDisplay", objArr);
        }
        return dVar.a(new zzdb(this, dVar, str));
    }

    public final e<b.c> stopRemoteDisplay(d dVar) {
        b.c.a.b.c.i.b bVar = zzy;
        Object[] objArr = new Object[0];
        if (bVar.a()) {
            bVar.b("stopRemoteDisplay", objArr);
        }
        return dVar.a(new zzda(this, dVar));
    }
}
