package com.google.android.gms.internal.cast;

import b.c.a.b.c.h.a;
import b.c.a.b.d.k.h;
import com.google.android.gms.common.api.Status;

public abstract class zzco extends zzcp<a.C0047a> {
    public a zzaap;
    public final /* synthetic */ zzch zzzt;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public zzco(zzch zzch, a aVar) {
        super(zzch);
        this.zzzt = zzch;
        this.zzaap = aVar;
        this.zzaaq = new zzcr(this, zzch);
    }

    public static /* synthetic */ a zza(zzco zzco) {
        return null;
    }

    public static a.C0047a zzf(Status status) {
        return new zzcq(status, (a) null);
    }

    public /* synthetic */ h createFailedResult(Status status) {
        return zzf(status);
    }
}
