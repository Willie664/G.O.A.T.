package com.google.android.gms.internal.cast;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public final class zzdr extends Handler {
    public static zzdq zzaew;

    public zzdr() {
    }

    public zzdr(Looper looper) {
        super(looper);
    }

    public final void dispatchMessage(Message message) {
        super.dispatchMessage(message);
    }
}
