package com.google.android.gms.internal.cast;

import b.c.a.b.d.k.e;
import b.c.a.b.d.k.h;
import b.c.a.b.l.d;
import b.c.a.b.l.d0;
import b.c.a.b.l.j;
import com.google.android.gms.common.api.Status;

public final class zzaw {
    public static <R extends h, T> e<R> zza(b.c.a.b.l.h<T> hVar, zzba<R, T> zzba, zzba<R, Status> zzba2) {
        zzbb zzbb = new zzbb(zzba2);
        zzaz zzaz = new zzaz(zzbb, zzba);
        d0 d0Var = (d0) hVar;
        if (d0Var != null) {
            d0Var.a(j.f2722a, zzaz);
            d0Var.a(j.f2722a, (d) new zzay(zzbb, zzba2));
            return zzbb;
        }
        throw null;
    }
}
