package com.google.android.gms.internal.cast;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import androidx.constraintlayout.motion.widget.Key;
import b.a.b.w.e;
import b.c.a.b.c.g.v.a.d;
import b.c.a.b.c.g.v.a.f;
import b.c.a.b.c.g.v.a.g;
import com.google.android.gms.cast.framework.internal.featurehighlight.OuterHighlightDrawable;
import com.google.android.gms.cast.framework.internal.featurehighlight.zzb;

public final class zzap implements f {
    public final /* synthetic */ zzam zzng;

    public zzap(zzam zzam) {
        this.zzng = zzam;
    }

    public final void dismiss() {
        if (this.zzng.zzne) {
            e.f((Context) this.zzng.zzlb);
            zzb zze = this.zzng.zznd;
            zzar zzar = new zzar(this);
            ObjectAnimator duration = ObjectAnimator.ofFloat(zze.f6149f.asView(), "alpha", new float[]{0.0f}).setDuration(200);
            duration.setInterpolator(zzed.zzfs());
            float exactCenterX = zze.f6145b.exactCenterX() - zze.f6147d.i;
            float exactCenterY = zze.f6145b.exactCenterY();
            OuterHighlightDrawable outerHighlightDrawable = zze.f6147d;
            float f2 = exactCenterY - outerHighlightDrawable.j;
            PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{0.0f});
            PropertyValuesHolder ofInt = PropertyValuesHolder.ofInt("alpha", new int[]{0});
            ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(outerHighlightDrawable, new PropertyValuesHolder[]{ofFloat, PropertyValuesHolder.ofFloat(Key.TRANSLATION_X, new float[]{0.0f, exactCenterX}), PropertyValuesHolder.ofFloat(Key.TRANSLATION_Y, new float[]{0.0f, f2}), ofInt});
            ofPropertyValuesHolder.setInterpolator(zzed.zzfs());
            Animator duration2 = ofPropertyValuesHolder.setDuration(200);
            Animator a2 = zze.f6148e.a();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(new Animator[]{duration, duration2, a2});
            animatorSet.addListener(new g(zze, zzar));
            Animator animator = zze.h;
            if (animator != null) {
                animator.cancel();
            }
            zze.h = animatorSet;
            animatorSet.start();
        }
    }

    public final void zzbi() {
        if (this.zzng.zzne) {
            e.f((Context) this.zzng.zzlb);
            zzb zze = this.zzng.zznd;
            zzao zzao = new zzao(this);
            ObjectAnimator duration = ObjectAnimator.ofFloat(zze.f6149f.asView(), "alpha", new float[]{0.0f}).setDuration(200);
            duration.setInterpolator(zzed.zzfs());
            ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(zze.f6147d, new PropertyValuesHolder[]{PropertyValuesHolder.ofFloat("scale", new float[]{1.125f}), PropertyValuesHolder.ofInt("alpha", new int[]{0})});
            ofPropertyValuesHolder.setInterpolator(zzed.zzfs());
            Animator duration2 = ofPropertyValuesHolder.setDuration(200);
            Animator a2 = zze.f6148e.a();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(new Animator[]{duration, duration2, a2});
            animatorSet.addListener(new d(zze, zzao));
            Animator animator = zze.h;
            if (animator != null) {
                animator.cancel();
            }
            zze.h = animatorSet;
            animatorSet.start();
        }
    }
}
