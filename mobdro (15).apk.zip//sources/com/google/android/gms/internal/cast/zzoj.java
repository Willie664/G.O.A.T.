package com.google.android.gms.internal.cast;

/* 'enum' modifier removed */
public final class zzoj extends zzoi {
    public zzoj(String str, int i, zzol zzol, int i2) {
        super(str, 10, zzol, 2, (zzof) null);
    }
}
