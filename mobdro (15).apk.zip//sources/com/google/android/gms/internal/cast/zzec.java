package com.google.android.gms.internal.cast;

import android.view.animation.Interpolator;
import androidx.core.view.animation.PathInterpolatorCompat;

public final class zzec {
    public static final Interpolator zzafi = PathInterpolatorCompat.create(0.0f, 0.0f, 0.2f, 1.0f);
    public static final Interpolator zzafj = PathInterpolatorCompat.create(0.4f, 0.0f, 1.0f, 1.0f);
    public static final Interpolator zzafk = PathInterpolatorCompat.create(0.4f, 0.0f, 0.2f, 1.0f);
}
