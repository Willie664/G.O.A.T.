package com.google.android.gms.internal.cast;

import b.a.a.a.a;
import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

public final class zzle extends zzjx<Integer> implements zzlh, zzmy, RandomAccess {
    public static final zzle zzbnt;
    public int size;
    public int[] zzbnu;

    static {
        zzle zzle = new zzle(new int[0], 0);
        zzbnt = zzle;
        zzle.zzib();
    }

    public zzle() {
        this(new int[10], 0);
    }

    public zzle(int[] iArr, int i) {
        this.zzbnu = iArr;
        this.size = i;
    }

    private final void zzbd(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzbe(i));
        }
    }

    private final String zzbe(int i) {
        return a.a(35, "Index:", i, ", Size:", this.size);
    }

    public static zzle zzjm() {
        return zzbnt;
    }

    public final /* synthetic */ void add(int i, Object obj) {
        int i2;
        int intValue = ((Integer) obj).intValue();
        zzic();
        if (i < 0 || i > (i2 = this.size)) {
            throw new IndexOutOfBoundsException(zzbe(i));
        }
        int[] iArr = this.zzbnu;
        if (i2 < iArr.length) {
            System.arraycopy(iArr, i, iArr, i + 1, i2 - i);
        } else {
            int[] iArr2 = new int[(((i2 * 3) / 2) + 1)];
            System.arraycopy(iArr, 0, iArr2, 0, i);
            System.arraycopy(this.zzbnu, i, iArr2, i + 1, this.size - i);
            this.zzbnu = iArr2;
        }
        this.zzbnu[i] = intValue;
        this.size++;
        this.modCount++;
    }

    public final /* synthetic */ boolean add(Object obj) {
        zzbc(((Integer) obj).intValue());
        return true;
    }

    public final boolean addAll(Collection<? extends Integer> collection) {
        zzic();
        zzld.checkNotNull(collection);
        if (!(collection instanceof zzle)) {
            return super.addAll(collection);
        }
        zzle zzle = (zzle) collection;
        int i = zzle.size;
        if (i == 0) {
            return false;
        }
        int i2 = this.size;
        if (Integer.MAX_VALUE - i2 >= i) {
            int i3 = i2 + i;
            int[] iArr = this.zzbnu;
            if (i3 > iArr.length) {
                this.zzbnu = Arrays.copyOf(iArr, i3);
            }
            System.arraycopy(zzle.zzbnu, 0, this.zzbnu, this.size, zzle.size);
            this.size = i3;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzle)) {
            return super.equals(obj);
        }
        zzle zzle = (zzle) obj;
        if (this.size != zzle.size) {
            return false;
        }
        int[] iArr = zzle.zzbnu;
        for (int i = 0; i < this.size; i++) {
            if (this.zzbnu[i] != iArr[i]) {
                return false;
            }
        }
        return true;
    }

    public final /* synthetic */ Object get(int i) {
        return Integer.valueOf(getInt(i));
    }

    public final int getInt(int i) {
        zzbd(i);
        return this.zzbnu[i];
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + this.zzbnu[i2];
        }
        return i;
    }

    public final /* synthetic */ Object remove(int i) {
        zzic();
        zzbd(i);
        int[] iArr = this.zzbnu;
        int i2 = iArr[i];
        int i3 = this.size;
        if (i < i3 - 1) {
            System.arraycopy(iArr, i + 1, iArr, i, (i3 - i) - 1);
        }
        this.size--;
        this.modCount++;
        return Integer.valueOf(i2);
    }

    public final boolean remove(Object obj) {
        zzic();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Integer.valueOf(this.zzbnu[i]))) {
                int[] iArr = this.zzbnu;
                System.arraycopy(iArr, i + 1, iArr, i, (this.size - i) - 1);
                this.size--;
                this.modCount++;
                return true;
            }
        }
        return false;
    }

    public final void removeRange(int i, int i2) {
        zzic();
        if (i2 >= i) {
            int[] iArr = this.zzbnu;
            System.arraycopy(iArr, i2, iArr, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        int intValue = ((Integer) obj).intValue();
        zzic();
        zzbd(i);
        int[] iArr = this.zzbnu;
        int i2 = iArr[i];
        iArr[i] = intValue;
        return Integer.valueOf(i2);
    }

    public final int size() {
        return this.size;
    }

    /* renamed from: zzbb */
    public final zzlh zzbf(int i) {
        if (i >= this.size) {
            return new zzle(Arrays.copyOf(this.zzbnu, i), this.size);
        }
        throw new IllegalArgumentException();
    }

    public final void zzbc(int i) {
        zzic();
        int i2 = this.size;
        int[] iArr = this.zzbnu;
        if (i2 == iArr.length) {
            int[] iArr2 = new int[(((i2 * 3) / 2) + 1)];
            System.arraycopy(iArr, 0, iArr2, 0, i2);
            this.zzbnu = iArr2;
        }
        int[] iArr3 = this.zzbnu;
        int i3 = this.size;
        this.size = i3 + 1;
        iArr3[i3] = i;
    }
}
