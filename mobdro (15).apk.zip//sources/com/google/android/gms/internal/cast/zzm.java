package com.google.android.gms.internal.cast;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import b.c.a.b.c.i.b;
import b.c.a.b.d.n.p;
import com.google.android.gms.internal.cast.zzjm;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@MainThread
public final class zzm {
    public static final String zzmn = p.f1965c.a("play-services-cast");
    public static zzm zzmo;
    public static final b zzy = new b("FeatureUsageAnalytics");
    public final Handler handler;
    public final String packageName;
    public final zzf zzma;
    public final SharedPreferences zzmc;
    public final Runnable zzmp;
    public long zzmq;
    public Set<zzjg> zzmr = new HashSet();
    public Set<zzjg> zzms = new HashSet();

    public zzm(@NonNull SharedPreferences sharedPreferences, @NonNull zzf zzf, @NonNull String str) {
        zzjg zzr;
        this.zzmc = sharedPreferences;
        this.zzma = zzf;
        this.packageName = str;
        this.handler = new zzdr(Looper.getMainLooper());
        this.zzmp = new zzp(this);
        String string = this.zzmc.getString("feature_usage_sdk_version", (String) null);
        String string2 = this.zzmc.getString("feature_usage_package_name", (String) null);
        this.zzmr = new HashSet();
        this.zzms = new HashSet();
        this.zzmq = 0;
        if (!zzmn.equals(string) || !this.packageName.equals(string2)) {
            HashSet hashSet = new HashSet();
            for (String next : this.zzmc.getAll().keySet()) {
                if (next.startsWith("feature_usage_timestamp_")) {
                    hashSet.add(next);
                }
            }
            hashSet.add("feature_usage_last_report_time");
            zza((Set<String>) hashSet);
            this.zzmc.edit().putString("feature_usage_sdk_version", zzmn).putString("feature_usage_package_name", this.packageName).apply();
            return;
        }
        this.zzmq = this.zzmc.getLong("feature_usage_last_report_time", 0);
        long currentTime = getCurrentTime();
        HashSet hashSet2 = new HashSet();
        for (String next2 : this.zzmc.getAll().keySet()) {
            if (next2.startsWith("feature_usage_timestamp_")) {
                long j = this.zzmc.getLong(next2, 0);
                if (j == 0 || currentTime - j <= 1209600000) {
                    if (next2.startsWith("feature_usage_timestamp_reported_feature_")) {
                        zzr = zzr(next2.substring(41));
                        this.zzms.add(zzr);
                    } else if (next2.startsWith("feature_usage_timestamp_detected_feature_")) {
                        zzr = zzr(next2.substring(41));
                    }
                    this.zzmr.add(zzr);
                } else {
                    hashSet2.add(next2);
                }
            }
        }
        zza((Set<String>) hashSet2);
        zzbc();
    }

    public static long getCurrentTime() {
        return System.currentTimeMillis();
    }

    public static synchronized zzm zza(@NonNull SharedPreferences sharedPreferences, @NonNull zzf zzf, @NonNull String str) {
        zzm zzm;
        synchronized (zzm.class) {
            if (zzmo == null) {
                zzmo = new zzm(sharedPreferences, zzf, str);
            }
            zzm = zzmo;
        }
        return zzm;
    }

    public static void zza(zzjg zzjg) {
        zzm zzm;
        if (zzf.zzlw && (zzm = zzmo) != null) {
            zzm.zzmc.edit().putLong(zzm.zzq(Integer.toString(zzjg.zzfw())), getCurrentTime()).apply();
            zzm.zzmr.add(zzjg);
            zzm.zzbc();
        }
    }

    private final void zza(Set<String> set) {
        if (!set.isEmpty()) {
            SharedPreferences.Editor edit = this.zzmc.edit();
            for (String remove : set) {
                edit.remove(remove);
            }
            edit.apply();
        }
    }

    private final void zzbc() {
        this.handler.post(this.zzmp);
    }

    public static String zze(String str, String str2) {
        return String.format("%s%s", new Object[]{str, str2});
    }

    private final String zzq(String str) {
        String zze = zze("feature_usage_timestamp_reported_feature_", str);
        return this.zzmc.contains(zze) ? zze : zze("feature_usage_timestamp_detected_feature_", str);
    }

    public static zzjg zzr(String str) {
        try {
            return zzjg.zzae(Integer.parseInt(str));
        } catch (NumberFormatException unused) {
            return zzjg.DEVELOPER_FEATURE_FLAG_UNKNOWN;
        }
    }

    public final /* synthetic */ void zzbd() {
        if (!this.zzmr.isEmpty()) {
            long j = this.zzms.equals(this.zzmr) ? 172800000 : 86400000;
            long currentTime = getCurrentTime();
            long j2 = this.zzmq;
            if (j2 == 0 || currentTime - j2 >= j) {
                b bVar = zzy;
                Object[] objArr = new Object[0];
                if (bVar.a()) {
                    bVar.b("Upload the feature usage report.", objArr);
                }
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(this.zzmr);
                zzjm.zzb.zza zzb = zzjm.zzb.zzga().zzb((Iterable<? extends zzjg>) arrayList);
                this.zzma.zza((zzjm.zzj) ((zzlc) zzjm.zzj.zzgn().zzb((zzjm.zzb) ((zzlc) zzb.zzb((zzjm.zze) ((zzlc) zzjm.zze.zzge().zzal(zzmn).zzak(this.packageName).zzjd())).zzjd())).zzjd()), zzhb.API_USAGE_REPORT);
                SharedPreferences.Editor edit = this.zzmc.edit();
                if (!this.zzms.equals(this.zzmr)) {
                    HashSet<zzjg> hashSet = new HashSet<>(this.zzmr);
                    this.zzms = hashSet;
                    for (zzjg zzfw : hashSet) {
                        String num = Integer.toString(zzfw.zzfw());
                        String zzq = zzq(num);
                        String zze = zze("feature_usage_timestamp_reported_feature_", num);
                        if (!TextUtils.equals(zzq, zze)) {
                            long j3 = this.zzmc.getLong(zzq, 0);
                            edit.remove(zzq);
                            if (j3 != 0) {
                                edit.putLong(zze, j3);
                            }
                        }
                    }
                }
                this.zzmq = currentTime;
                edit.putLong("feature_usage_last_report_time", currentTime).apply();
            }
        }
    }
}
