package com.google.android.gms.internal.cast;

import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import com.google.android.gms.internal.cast.zzei;
import com.google.android.gms.internal.cast.zzlc;

public final class zzjm {

    public static final class zza extends zzlc<zza, C0129zza> implements zzmn {
        public static volatile zzmv<zza> zzagb;
        public static final zzlk<Integer, zzjg> zzbav = new zzjp();
        public static final zza zzbaw;
        public int zzafn;
        public String zzbas = "";
        public String zzbat = "";
        public zzlh zzbau = zzlc.zzjh();

        /* renamed from: com.google.android.gms.internal.cast.zzjm$zza$zza  reason: collision with other inner class name */
        public static final class C0129zza extends zzlc.zza<zza, C0129zza> implements zzmn {
            public C0129zza() {
                super(zza.zzbaw);
            }

            public /* synthetic */ C0129zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zza zza = new zza();
            zzbaw = zza;
            zzlc.zza(zza.class, zza);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zza();
                case 2:
                    return new C0129zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbaw, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001\b\u0000\u0002\b\u0001\u0003\u001e", new Object[]{"zzafn", "zzbas", "zzbat", "zzbau", zzjg.zzfx()});
                case 4:
                    return zzbaw;
                case 5:
                    zzmv<zza> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zza.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbaw);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzaa extends zzlc<zzaa, zza> implements zzmn {
        public static volatile zzmv<zzaa> zzagb;
        public static final zzaa zzbhd;
        public int zzafn;
        public long zzbha;
        public zzlj zzbhb = zzlc.zzji();
        public zzlj zzbhc = zzlc.zzji();

        public static final class zza extends zzlc.zza<zzaa, zza> implements zzmn {
            public zza() {
                super(zzaa.zzbhd);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzaa zzaa = new zzaa();
            zzbhd = zzaa;
            zzlc.zza(zzaa.class, zzaa);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzaa();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhd, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0002\u0000\u0001\u0005\u0000\u0002\u0017\u0003\u0017", new Object[]{"zzafn", "zzbha", "zzbhb", "zzbhc"});
                case 4:
                    return zzbhd;
                case 5:
                    zzmv<zzaa> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzaa.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhd);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzab extends zzlc<zzab, zza> implements zzmn {
        public static volatile zzmv<zzab> zzagb;
        public static final zzab zzbhh;
        public int zzafn;
        public int zzbhe;
        public int zzbhf;
        public int zzbhg;

        public static final class zza extends zzlc.zza<zzab, zza> implements zzmn {
            public zza() {
                super(zzab.zzbhh);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzab zzab = new zzab();
            zzbhh = zzab;
            zzlc.zza(zzab.class, zzab);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzab();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhh, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\u0004\u0002", new Object[]{"zzafn", "zzbhe", "zzbhf", "zzbhg"});
                case 4:
                    return zzbhh;
                case 5:
                    zzmv<zzab> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzab.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhh);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzac extends zzlc<zzac, zza> implements zzmn {
        public static volatile zzmv<zzac> zzagb;
        public static final zzac zzbhj;
        public int zzafn;
        public int zzbgc;
        public String zzbhi = "";

        public static final class zza extends zzlc.zza<zzac, zza> implements zzmn {
            public zza() {
                super(zzac.zzbhj);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzac zzac = new zzac();
            zzbhj = zzac;
            zzlc.zza(zzac.class, zzac);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzac();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhj, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0004\u0000\u0002\b\u0001", new Object[]{"zzafn", "zzbgc", "zzbhi"});
                case 4:
                    return zzbhj;
                case 5:
                    zzmv<zzac> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzac.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhj);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzad extends zzlc<zzad, zza> implements zzmn {
        public static volatile zzmv<zzad> zzagb;
        public static final zzad zzbhq;
        public int zzafn;
        public String zzbbp = "";
        public boolean zzbhk;
        public boolean zzbhl;
        public int zzbhm;
        public String zzbhn = "";
        public int zzbho;
        public int zzbhp;

        public static final class zza extends zzlc.zza<zzad, zza> implements zzmn {
            public zza() {
                super(zzad.zzbhq);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzad zzad = new zzad();
            zzbhq = zzad;
            zzlc.zza(zzad.class, zzad);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzad();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhq, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0000\u0001\u0007\u0000\u0002\u0007\u0001\u0003\u0004\u0002\u0004\b\u0003\u0005\u0004\u0004\u0006\u0004\u0005\u0007\b\u0006", new Object[]{"zzafn", "zzbhk", "zzbhl", "zzbhm", "zzbhn", "zzbho", "zzbhp", "zzbbp"});
                case 4:
                    return zzbhq;
                case 5:
                    zzmv<zzad> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzad.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhq);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzae extends zzlc<zzae, zza> implements zzmn {
        public static volatile zzmv<zzae> zzagb;
        public static final zzae zzbhu;
        public int zzafn;
        public int zzbhr;
        public int zzbhs;
        public int zzbht;

        public static final class zza extends zzlc.zza<zzae, zza> implements zzmn {
            public zza() {
                super(zzae.zzbhu);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzae zzae = new zzae();
            zzbhu = zzae;
            zzlc.zza(zzae.class, zzae);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzae();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhu, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0004\u0000\u0002\f\u0001\u0003\u0004\u0002", new Object[]{"zzafn", "zzbhr", "zzbhs", zzhk.zzfx(), "zzbht"});
                case 4:
                    return zzbhu;
                case 5:
                    zzmv<zzae> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzae.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhu);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzaf extends zzlc<zzaf, zza> implements zzmn {
        public static volatile zzmv<zzaf> zzagb;
        public static final zzaf zzbhy;
        public int zzafn;
        public zzlm<zzaj> zzbhv = zzlc.zzjj();
        public zzlm<zzl> zzbhw = zzlc.zzjj();
        public zzai zzbhx;

        public static final class zza extends zzlc.zza<zzaf, zza> implements zzmn {
            public zza() {
                super(zzaf.zzbhy);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzaf zzaf = new zzaf();
            zzbhy = zzaf;
            zzlc.zza(zzaf.class, zzaf);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzaf();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbhy, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0002\u0000\u0001\u001b\u0002\u001b\u0003\t\u0000", new Object[]{"zzafn", "zzbhv", zzaj.class, "zzbhw", zzl.class, "zzbhx"});
                case 4:
                    return zzbhy;
                case 5:
                    zzmv<zzaf> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzaf.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbhy);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzag extends zzlc<zzag, zza> implements zzmn {
        public static volatile zzmv<zzag> zzagb;
        public static final zzag zzbid;
        public int zzafn;
        public zzm zzbbu;
        public int zzbcf;
        public long zzbgt;
        public int zzbhz;
        public int zzbia;
        public int zzbib;
        public zzlm<zzm> zzbic = zzlc.zzjj();

        public static final class zza extends zzlc.zza<zzag, zza> implements zzmn {
            public zza() {
                super(zzag.zzbid);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzag zzag = new zzag();
            zzbid = zzag;
            zzlc.zza(zzag.class, zzag);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzag();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbid, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0001\u0000\u0001\t\u0000\u0002\f\u0001\u0003\f\u0002\u0004\f\u0003\u0005\f\u0004\u0006\u0002\u0005\u0007\u001b", new Object[]{"zzafn", "zzbbu", "zzbhz", zzib.zzfx(), "zzbcf", zzhw.zzfx(), "zzbia", zzgd.zzfx(), "zzbib", zzfm.zzfx(), "zzbgt", "zzbic", zzm.class});
                case 4:
                    return zzbid;
                case 5:
                    zzmv<zzag> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzag.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbid);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzah extends zzlc<zzah, zza> implements zzmn {
        public static volatile zzmv<zzah> zzagb;
        public static final zzah zzbih;
        public int zzafn;
        public String zzbdd = "";
        public zzlm<zzs> zzbie = zzlc.zzjj();
        public zzlm<zzm> zzbif = zzlc.zzjj();
        public boolean zzbig;

        public static final class zza extends zzlc.zza<zzah, zza> implements zzmn {
            public zza() {
                super(zzah.zzbih);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzah zzah = new zzah();
            zzbih = zzah;
            zzlc.zza(zzah.class, zzah);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzah();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbih, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001\b\u0000\u0002\u001b\u0003\u001b\u0004\u0007\u0001", new Object[]{"zzafn", "zzbdd", "zzbie", zzs.class, "zzbif", zzm.class, "zzbig"});
                case 4:
                    return zzbih;
                case 5:
                    zzmv<zzah> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzah.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbih);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzai extends zzlc<zzai, zza> implements zzmn {
        public static volatile zzmv<zzai> zzagb;
        public static final zzai zzbii;
        public int zzafn;
        public zzc zzbeu;

        public static final class zza extends zzlc.zza<zzai, zza> implements zzmn {
            public zza() {
                super(zzai.zzbii);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzai zzai = new zzai();
            zzbii = zzai;
            zzlc.zza(zzai.class, zzai);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzai();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbii, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t\u0000", new Object[]{"zzafn", "zzbeu"});
                case 4:
                    return zzbii;
                case 5:
                    zzmv<zzai> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzai.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbii);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzaj extends zzlc<zzaj, zza> implements zzmn {
        public static volatile zzmv<zzaj> zzagb;
        public static final zzaj zzbij;
        public int zzafn;
        public int zzbes;
        public int zzbet;
        public zzc zzbeu;

        public static final class zza extends zzlc.zza<zzaj, zza> implements zzmn {
            public zza() {
                super(zzaj.zzbij);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzaj zzaj = new zzaj();
            zzbij = zzaj;
            zzlc.zza(zzaj.class, zzaj);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzaj();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbij, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0000\u0002\u000b\u0001\u0003\t\u0002", new Object[]{"zzafn", "zzbes", zzin.zzfx(), "zzbet", "zzbeu"});
                case 4:
                    return zzbij;
                case 5:
                    zzmv<zzaj> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzaj.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbij);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzak extends zzlc<zzak, zza> implements zzmn {
        public static volatile zzmv<zzak> zzagb;
        public static final zzak zzbil;
        public int zzafn;
        public zzlm<zzac> zzbbn = zzlc.zzjj();
        public int zzbhp;
        public int zzbhz;
        public zzlm<zzac> zzbik = zzlc.zzjj();

        public static final class zza extends zzlc.zza<zzak, zza> implements zzmn {
            public zza() {
                super(zzak.zzbil);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzak zzak = new zzak();
            zzbil = zzak;
            zzlc.zza(zzak.class, zzak);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            Class<zzac> cls = zzac.class;
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzak();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbil, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001\f\u0000\u0002\u001b\u0003\u001b\u0004\u0004\u0001", new Object[]{"zzafn", "zzbhz", zzit.zzfx(), "zzbbn", cls, "zzbik", cls, "zzbhp"});
                case 4:
                    return zzbil;
                case 5:
                    zzmv<zzak> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzak.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbil);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzal extends zzlc<zzal, zza> implements zzmn {
        public static volatile zzmv<zzal> zzagb;
        public static final zzal zzbir;
        public int zzafn;
        public int zzbim;
        public int zzbin;
        public zzlm<zzm> zzbio = zzlc.zzjj();
        public zzlm<zzm> zzbip = zzlc.zzjj();
        public int zzbiq;

        public static final class zza extends zzlc.zza<zzal, zza> implements zzmn {
            public zza() {
                super(zzal.zzbir);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzal zzal = new zzal();
            zzbir = zzal;
            zzlc.zza(zzal.class, zzal);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            Class<zzm> cls = zzm.class;
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzal();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbir, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0002\u0000\u0001\f\u0000\u0002\f\u0001\u0003\u001b\u0004\u001b\u0005\f\u0002", new Object[]{"zzafn", "zzbim", zziu.zzfx(), "zzbin", zziz.zzfx(), "zzbio", cls, "zzbip", cls, "zzbiq", zzgd.zzfx()});
                case 4:
                    return zzbir;
                case 5:
                    zzmv<zzal> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzal.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbir);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzam extends zzlc<zzam, zza> implements zzmn {
        public static volatile zzmv<zzam> zzagb;
        public static final zzlk<Integer, zzja> zzbit = new zzjr();
        public static final zzam zzbiu;
        public int zzafn;
        public int zzbes;
        public int zzbiq;
        public zzlh zzbis = zzlc.zzjh();

        public static final class zza extends zzlc.zza<zzam, zza> implements zzmn {
            public zza() {
                super(zzam.zzbiu);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzam zzam = new zzam();
            zzbiu = zzam;
            zzlc.zza(zzam.class, zzam);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzam();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbiu, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0001\u0000\u0001\f\u0000\u0002\f\u0001\u0003\u001e", new Object[]{"zzafn", "zzbes", zzjf.zzfx(), "zzbiq", zzgd.zzfx(), "zzbis", zzja.zzfx()});
                case 4:
                    return zzbiu;
                case 5:
                    zzmv<zzam> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzam.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbiu);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzb extends zzlc<zzb, zza> implements zzmn {
        public static volatile zzmv<zzb> zzagb;
        public static final zzlk<Integer, zzjg> zzbbb = new zzjq();
        public static final zzb zzbbc;
        public int zzafn;
        public zze zzbax;
        public zzx zzbay;
        public zzlm<zzv> zzbaz = zzlc.zzjj();
        public zzlh zzbba = zzlc.zzjh();

        public static final class zza extends zzlc.zza<zzb, zza> implements zzmn {
            public zza() {
                super(zzb.zzbbc);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }

            public final zza zzb(zze zze) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzb) this.zzbmw).zza(zze);
                return this;
            }

            public final zza zzb(Iterable<? extends zzjg> iterable) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzb) this.zzbmw).zza(iterable);
                return this;
            }
        }

        static {
            zzb zzb = new zzb();
            zzbbc = zzb;
            zzlc.zza(zzb.class, zzb);
        }

        /* access modifiers changed from: private */
        public final void zza(zze zze) {
            zze.getClass();
            this.zzbax = zze;
            this.zzafn |= 1;
        }

        /* access modifiers changed from: private */
        public final void zza(Iterable<? extends zzjg> iterable) {
            if (!this.zzbba.zzia()) {
                zzlh zzlh = this.zzbba;
                int size = zzlh.size();
                this.zzbba = zzlh.zzbb(size == 0 ? 10 : size << 1);
            }
            for (zzjg zzfw : iterable) {
                this.zzbba.zzbc(zzfw.zzfw());
            }
        }

        public static zza zzga() {
            return (zza) zzbbc.zzjf();
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzb();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbbc, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0002\u0000\u0001\t\u0000\u0002\t\u0001\u0003\u001b\u0004\u001e", new Object[]{"zzafn", "zzbax", "zzbay", "zzbaz", zzv.class, "zzbba", zzjg.zzfx()});
                case 4:
                    return zzbbc;
                case 5:
                    zzmv<zzb> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzb.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbbc);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzc extends zzlc<zzc, zza> implements zzmn {
        public static volatile zzmv<zzc> zzagb;
        public static final zzc zzbbi;
        public int zzafn;
        public int zzbbd;
        public double zzbbe;
        public double zzbbf;
        public double zzbbg;
        public double zzbbh;

        public static final class zza extends zzlc.zza<zzc, zza> implements zzmn {
            public zza() {
                super(zzc.zzbbi);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzc zzc = new zzc();
            zzbbi = zzc;
            zzlc.zza(zzc.class, zzc);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzc();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbbi, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001\u000b\u0000\u0002\u0000\u0001\u0003\u0000\u0002\u0004\u0000\u0003\u0005\u0000\u0004", new Object[]{"zzafn", "zzbbd", "zzbbe", "zzbbf", "zzbbg", "zzbbh"});
                case 4:
                    return zzbbi;
                case 5:
                    zzmv<zzc> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzc.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbbi);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzd extends zzlc<zzd, zza> implements zzmn {
        public static volatile zzmv<zzd> zzagb;
        public static final zzd zzbbq;
        public int zzafn;
        public int zzbbj;
        public boolean zzbbk;
        public int zzbbl;
        public boolean zzbbm;
        public zzlm<zzac> zzbbn = zzlc.zzjj();
        public zzlm<zzac> zzbbo = zzlc.zzjj();
        public String zzbbp = "";

        public static final class zza extends zzlc.zza<zzd, zza> implements zzmn {
            public zza() {
                super(zzd.zzbbq);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzd zzd = new zzd();
            zzbbq = zzd;
            zzlc.zza(zzd.class, zzd);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            Class<zzac> cls = zzac.class;
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzd();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbbq, "\u0001\u0007\u0000\u0001\u0001\t\u0007\u0000\u0002\u0000\u0001\f\u0000\u0002\u0007\u0001\u0003\f\u0002\u0004\u0007\u0003\u0007\u001b\b\u001b\t\b\u0004", new Object[]{"zzafn", "zzbbj", zzfa.zzfx(), "zzbbk", "zzbbl", zzgd.zzfx(), "zzbbm", "zzbbn", cls, "zzbbo", cls, "zzbbp"});
                case 4:
                    return zzbbq;
                case 5:
                    zzmv<zzd> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzd.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbbq);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zze extends zzlc<zze, zza> implements zzmn {
        public static volatile zzmv<zze> zzagb;
        public static final zze zzbbt;
        public int zzafn;
        public String zzbbr = "";
        public String zzbbs = "";

        public static final class zza extends zzlc.zza<zze, zza> implements zzmn {
            public zza() {
                super(zze.zzbbt);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }

            public final zza zzak(String str) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zze) this.zzbmw).zzai(str);
                return this;
            }

            public final zza zzal(String str) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zze) this.zzbmw).zzaj(str);
                return this;
            }
        }

        static {
            zze zze = new zze();
            zzbbt = zze;
            zzlc.zza(zze.class, zze);
        }

        /* access modifiers changed from: private */
        public final void zzai(String str) {
            str.getClass();
            this.zzafn |= 1;
            this.zzbbr = str;
        }

        /* access modifiers changed from: private */
        public final void zzaj(String str) {
            str.getClass();
            this.zzafn |= 2;
            this.zzbbs = str;
        }

        public static zza zzge() {
            return (zza) zzbbt.zzjf();
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zze();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbbt, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\b\u0000\u0002\b\u0001", new Object[]{"zzafn", "zzbbr", "zzbbs"});
                case 4:
                    return zzbbt;
                case 5:
                    zzmv<zze> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zze.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbbt);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzf extends zzlc<zzf, zza> implements zzmn {
        public static volatile zzmv<zzf> zzagb;
        public static final zzf zzbca;
        public int zzafn;
        public zzm zzbbu;
        public boolean zzbbv;
        public long zzbbw;
        public int zzbbx;
        public int zzbby;
        public int zzbbz;

        public static final class zza extends zzlc.zza<zzf, zza> implements zzmn {
            public zza() {
                super(zzf.zzbca);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }

            public final zza zzb(zzff zzff) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzf) this.zzbmw).zza(zzff);
                return this;
            }

            public final zza zzb(zzfg zzfg) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzf) this.zzbmw).zza(zzfg);
                return this;
            }

            public final zza zzb(zzm zzm) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzf) this.zzbmw).zza(zzm);
                return this;
            }

            public final zza zzi(long j) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzf) this.zzbmw).zzh(j);
                return this;
            }

            public final zza zzn(boolean z) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzf) this.zzbmw).zzm(z);
                return this;
            }
        }

        static {
            zzf zzf = new zzf();
            zzbca = zzf;
            zzlc.zza(zzf.class, zzf);
        }

        public static zza zza(zzf zzf) {
            return (zza) zzbca.zzb(zzf);
        }

        /* access modifiers changed from: private */
        public final void zza(zzff zzff) {
            this.zzbbz = zzff.zzfw();
            this.zzafn |= 32;
        }

        /* access modifiers changed from: private */
        public final void zza(zzfg zzfg) {
            this.zzbby = zzfg.zzfw();
            this.zzafn |= 16;
        }

        /* access modifiers changed from: private */
        public final void zza(zzm zzm) {
            zzm.getClass();
            this.zzbbu = zzm;
            this.zzafn |= 1;
        }

        public static zza zzgg() {
            return (zza) zzbca.zzjf();
        }

        public static zzf zzgh() {
            return zzbca;
        }

        /* access modifiers changed from: private */
        public final void zzh(long j) {
            this.zzafn |= 4;
            this.zzbbw = j;
        }

        /* access modifiers changed from: private */
        public final void zzm(boolean z) {
            this.zzafn |= 2;
            this.zzbbv = z;
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzf();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbca, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\t\u0000\u0002\u0007\u0001\u0003\u0005\u0002\u0004\u0006\u0003\u0005\f\u0004\u0006\f\u0005", new Object[]{"zzafn", "zzbbu", "zzbbv", "zzbbw", "zzbbx", "zzbby", zzfg.zzfx(), "zzbbz", zzff.zzfx()});
                case 4:
                    return zzbca;
                case 5:
                    zzmv<zzf> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzf.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbca);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzg extends zzlc<zzg, zza> implements zzmn {
        public static volatile zzmv<zzg> zzagb;
        public static final zzg zzbce;
        public int zzafn;
        public int zzbbd;
        public int zzbcb;
        public int zzbcc;
        public int zzbcd;

        public static final class zza extends zzlc.zza<zzg, zza> implements zzmn {
            public zza() {
                super(zzg.zzbce);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzg zzg = new zzg();
            zzbce = zzg;
            zzlc.zza(zzg.class, zzg);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzg();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbce, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u000b\u0000\u0002\u000b\u0001\u0003\f\u0002\u0004\u0004\u0003", new Object[]{"zzafn", "zzbcb", "zzbbd", "zzbcc", zzgw.zzfx(), "zzbcd"});
                case 4:
                    return zzbce;
                case 5:
                    zzmv<zzg> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzg.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbce);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzh extends zzlc<zzh, zza> implements zzmn {
        public static volatile zzmv<zzh> zzagb;
        public static final zzh zzbcg;
        public int zzafn;
        public int zzbcf;

        public static final class zza extends zzlc.zza<zzh, zza> implements zzmn {
            public zza() {
                super(zzh.zzbcg);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzh zzh = new zzh();
            zzbcg = zzh;
            zzlc.zza(zzh.class, zzh);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzh();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbcg, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\f\u0000", new Object[]{"zzafn", "zzbcf", zzfr.zzfx()});
                case 4:
                    return zzbcg;
                case 5:
                    zzmv<zzh> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzh.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbcg);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzi extends zzlc<zzi, zza> implements zzmn {
        public static volatile zzmv<zzi> zzagb;
        public static final zzi zzbcm;
        public int zzafn;
        public int zzbch;
        public int zzbci;
        public int zzbcj;
        public boolean zzbck;
        public int zzbcl;

        public static final class zza extends zzlc.zza<zzi, zza> implements zzmn {
            public zza() {
                super(zzi.zzbcm);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzi zzi = new zzi();
            zzbcm = zzi;
            zzlc.zza(zzi.class, zzi);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzi();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbcm, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001\f\u0000\u0002\f\u0001\u0003\f\u0002\u0004\u0007\u0003\u0005\u0004\u0004", new Object[]{"zzafn", "zzbch", zzhv.zzfx(), "zzbci", zzhp.zzfx(), "zzbcj", zzhq.zzfx(), "zzbck", "zzbcl"});
                case 4:
                    return zzbcm;
                case 5:
                    zzmv<zzi> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzi.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbcm);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzj extends zzlc<zzj, zza> implements zzmn {
        public static volatile zzmv<zzj> zzagb;
        public static final zzj zzben;
        public int zzafn;
        public String zzbbp = "";
        public int zzbcn;
        public long zzbco;
        public long zzbcp;
        public int zzbcq;
        public zzr zzbcr;
        public zzae zzbcs;
        public zzq zzbct;
        public zzo zzbcu;
        public zzh zzbcv;
        public zzad zzbcw;
        public zzd zzbcx;
        public zzak zzbcy;
        public zzn zzbcz;
        public zzei.zzb zzbda;
        public String zzbdb = "";
        public zzaa zzbdc;
        public String zzbdd = "";
        public zzlh zzbde = zzlc.zzjh();
        public zzlm<zzs> zzbdf = zzlc.zzjj();
        public zzlm<zzu> zzbdg = zzlc.zzjj();
        public zzlm<zzk> zzbdh = zzlc.zzjj();
        public zzlm<zzah> zzbdi = zzlc.zzjj();
        public int zzbdj;
        public int zzbdk;
        public zzm zzbdl;
        public int zzbdm;
        public zzi zzbdn;
        public zzlm<zzm> zzbdo = zzlc.zzjj();
        public zzm zzbdp;
        public int zzbdq;
        public int zzbdr;
        public int zzbds;
        public int zzbdt;
        public int zzbdu;
        public int zzbdv;
        public zzal zzbdw;
        public zzf zzbdx;
        public zza zzbdy;
        public zzw zzbdz;
        public zzag zzbea;
        public zzy zzbeb;
        public zzlm<zze> zzbec = zzlc.zzjj();
        public int zzbed;
        public zzab zzbee;
        public zzlm<zzg> zzbef = zzlc.zzjj();
        public boolean zzbeg;
        public boolean zzbeh;
        public int zzbei;
        public zzb zzbej;
        public zzaf zzbek;
        public zzt zzbel;
        public byte zzbem = 2;

        public static final class zza extends zzlc.zza<zzj, zza> implements zzmn {
            public zza() {
                super(zzj.zzben);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }

            public final zza zza(zzf.zza zza) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zzb((zzf) ((zzlc) zza.zzjd()));
                return this;
            }

            public final zza zzag(int i) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zzaf(i);
                return this;
            }

            public final zza zzao(String str) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zzam(str);
                return this;
            }

            public final zza zzap(String str) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zzan(str);
                return this;
            }

            public final zza zzb(zzb zzb) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zza(zzb);
                return this;
            }

            public final zzf zzgm() {
                return ((zzj) this.zzbmw).zzgm();
            }

            public final zza zzk(long j) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzj) this.zzbmw).zzj(j);
                return this;
            }
        }

        static {
            zzj zzj = new zzj();
            zzben = zzj;
            zzlc.zza(zzj.class, zzj);
        }

        public static zza zza(zzj zzj) {
            return (zza) zzben.zzb(zzj);
        }

        /* access modifiers changed from: private */
        public final void zza(zzb zzb) {
            zzb.getClass();
            this.zzbej = zzb;
            this.zzbcn |= 256;
        }

        /* access modifiers changed from: private */
        public final void zzaf(int i) {
            this.zzafn |= 268435456;
            this.zzbdv = i;
        }

        /* access modifiers changed from: private */
        public final void zzam(String str) {
            str.getClass();
            this.zzafn |= 16384;
            this.zzbdb = str;
        }

        /* access modifiers changed from: private */
        public final void zzan(String str) {
            str.getClass();
            this.zzafn |= 65536;
            this.zzbdd = str;
        }

        /* access modifiers changed from: private */
        public final void zzb(zzf zzf) {
            zzf.getClass();
            this.zzbdx = zzf;
            this.zzafn |= BasicMeasure.EXACTLY;
        }

        public static zza zzgn() {
            return (zza) zzben.zzjf();
        }

        /* access modifiers changed from: private */
        public final void zzj(long j) {
            this.zzafn |= 2;
            this.zzbcp = j;
        }

        public final Object zza(int i, Object obj, Object obj2) {
            int i2 = 1;
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzj();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzben, "\u00013\u0000\u0002\u000133\u0000\b\u0001\u0001\u0002\u0000\u0002\u0002\u0001\u0003\f\u0002\u0004\t\u0003\u0005\t\u0004\u0006\t\u0005\u0007\t\u0006\b\t\u0007\t\b\u000e\n\t\b\u000b\t\t\f\t\n\r\b\u000b\u000e\t\f\u000f\t\r\u0010\t\u000f\u0011\b\u0010\u0012\u0016\u0013\u001b\u0014\u001b\u0015\u001b\u0016\u001b\u0017\f\u0011\u0018\t\u0015\u0019\u001b\u001a\t\u0016\u001b\f\u0018\u001c\u0004\u0019\u001d\u0004\u001a\u001e\u0004\u001b\u001f\u0006\u001c \t\u001d!\t\u001e\"\t\u001f#\f\u0012$\t\u0013%Љ &\t!'\t\"(\u001b)\f#*\t$+\u001b,\f\u0017-\u0007%.\u0007&/\f'0\t(1\u0004\u00142\t)3\t*", new Object[]{"zzafn", "zzbcn", "zzbco", "zzbcp", "zzbcq", zzio.zzfx(), "zzbcr", "zzbcs", "zzbct", "zzbcu", "zzbcv", "zzbdb", "zzbcw", "zzbcx", "zzbcy", "zzbbp", "zzbcz", "zzbda", "zzbdc", "zzbdd", "zzbde", "zzbdf", zzs.class, "zzbdg", zzu.class, "zzbdh", zzk.class, "zzbdi", zzah.class, "zzbdj", zzii.zzfx(), "zzbdn", "zzbdo", zzm.class, "zzbdp", "zzbdr", zzgv.zzfx(), "zzbds", "zzbdt", "zzbdu", "zzbdv", "zzbdw", "zzbdx", "zzbdy", "zzbdk", zzic.zzfx(), "zzbdl", "zzbdz", "zzbea", "zzbeb", "zzbec", zze.class, "zzbed", zzih.zzfx(), "zzbee", "zzbef", zzg.class, "zzbdq", zzgq.zzfx(), "zzbeg", "zzbeh", "zzbei", zzgk.zzfx(), "zzbej", "zzbdm", "zzbek", "zzbel"});
                case 4:
                    return zzben;
                case 5:
                    zzmv<zzj> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzj.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzben);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return Byte.valueOf(this.zzbem);
                case 7:
                    if (obj == null) {
                        i2 = 0;
                    }
                    this.zzbem = (byte) i2;
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public final zzf zzgm() {
            zzf zzf = this.zzbdx;
            return zzf == null ? zzf.zzgh() : zzf;
        }
    }

    public static final class zzk extends zzlc<zzk, zza> implements zzmn {
        public static volatile zzmv<zzk> zzagb;
        public static final zzk zzber;
        public int zzafn;
        public int zzbeo = 0;
        public Object zzbep;
        public long zzbeq;

        public static final class zza extends zzlc.zza<zzk, zza> implements zzmn {
            public zza() {
                super(zzk.zzber);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzk zzk = new zzk();
            zzber = zzk;
            zzlc.zza(zzk.class, zzk);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzk();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzber, "\u0001\u0004\u0001\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0005\u0000\u0002:\u0000\u00035\u0000\u00048\u0000", new Object[]{"zzbep", "zzbeo", "zzafn", "zzbeq"});
                case 4:
                    return zzber;
                case 5:
                    zzmv<zzk> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzk.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzber);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzl extends zzlc<zzl, zza> implements zzmn {
        public static volatile zzmv<zzl> zzagb;
        public static final zzl zzbev;
        public int zzafn;
        public int zzbes;
        public int zzbet;
        public zzc zzbeu;

        public static final class zza extends zzlc.zza<zzl, zza> implements zzmn {
            public zza() {
                super(zzl.zzbev);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzl zzl = new zzl();
            zzbev = zzl;
            zzlc.zza(zzl.class, zzl);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzl();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbev, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0000\u0002\u000b\u0001\u0003\t\u0002", new Object[]{"zzafn", "zzbes", zzfx.zzfx(), "zzbet", "zzbeu"});
                case 4:
                    return zzbev;
                case 5:
                    zzmv<zzl> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzl.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbev);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzm extends zzlc<zzm, zza> implements zzmn {
        public static volatile zzmv<zzm> zzagb;
        public static final zzm zzbey;
        public int zzafn;
        public String zzbew = "";
        public String zzbex = "";

        public static final class zza extends zzlc.zza<zzm, zza> implements zzmn {
            public zza() {
                super(zzm.zzbey);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }

            public final zza zzar(String str) {
                if (this.zzbmx) {
                    zziz();
                    this.zzbmx = false;
                }
                ((zzm) this.zzbmw).zzaq(str);
                return this;
            }
        }

        static {
            zzm zzm = new zzm();
            zzbey = zzm;
            zzlc.zza(zzm.class, zzm);
        }

        /* access modifiers changed from: private */
        public final void zzaq(String str) {
            str.getClass();
            this.zzafn |= 1;
            this.zzbew = str;
        }

        public static zza zzgr() {
            return (zza) zzbey.zzjf();
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzm();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbey, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\b\u0000\u0002\b\u0001", new Object[]{"zzafn", "zzbew", "zzbex"});
                case 4:
                    return zzbey;
                case 5:
                    zzmv<zzm> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzm.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbey);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzn extends zzlc<zzn, zzb> implements zzmn {
        public static volatile zzmv<zzn> zzagb;
        public static final zzn zzbfd;
        public int zzafn;
        public int zzbez;
        public int zzbfa;
        public int zzbfb;
        public zzlm<zza> zzbfc = zzlc.zzjj();

        public static final class zza extends zzlc<zza, C0130zza> implements zzmn {
            public static volatile zzmv<zza> zzagb;
            public static final zza zzbfi;
            public int zzafn;
            public int zzbfe;
            public int zzbff;
            public int zzbfg;
            public int zzbfh;

            /* renamed from: com.google.android.gms.internal.cast.zzjm$zzn$zza$zza  reason: collision with other inner class name */
            public static final class C0130zza extends zzlc.zza<zza, C0130zza> implements zzmn {
                public C0130zza() {
                    super(zza.zzbfi);
                }

                public /* synthetic */ C0130zza(zzjo zzjo) {
                    this();
                }
            }

            static {
                zza zza = new zza();
                zzbfi = zza;
                zzlc.zza(zza.class, zza);
            }

            public final Object zza(int i, Object obj, Object obj2) {
                switch (zzjo.zzagc[i - 1]) {
                    case 1:
                        return new zza();
                    case 2:
                        return new C0130zza((zzjo) null);
                    case 3:
                        return zzlc.zza((zzml) zzbfi, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\u0004\u0002\u0004\u0004\u0003", new Object[]{"zzafn", "zzbfe", "zzbff", "zzbfg", "zzbfh"});
                    case 4:
                        return zzbfi;
                    case 5:
                        zzmv<zza> zzmv = zzagb;
                        if (zzmv == null) {
                            synchronized (zza.class) {
                                zzmv = zzagb;
                                if (zzmv == null) {
                                    zzmv = new zzlc.zzc<>(zzbfi);
                                    zzagb = zzmv;
                                }
                            }
                        }
                        return zzmv;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }
        }

        public static final class zzb extends zzlc.zza<zzn, zzb> implements zzmn {
            public zzb() {
                super(zzn.zzbfd);
            }

            public /* synthetic */ zzb(zzjo zzjo) {
                this();
            }
        }

        static {
            zzn zzn = new zzn();
            zzbfd = zzn;
            zzlc.zza(zzn.class, zzn);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzn();
                case 2:
                    return new zzb((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbfd, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0001\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\u0004\u0002\u0004\u001b", new Object[]{"zzafn", "zzbez", "zzbfa", "zzbfb", "zzbfc", zza.class});
                case 4:
                    return zzbfd;
                case 5:
                    zzmv<zzn> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzn.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbfd);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzo extends zzlc<zzo, zza> implements zzmn {
        public static volatile zzmv<zzo> zzagb;
        public static final zzo zzbfp;
        public int zzafn;
        public boolean zzbfj;
        public int zzbfk;
        public int zzbfl;
        public int zzbfm;
        public zzz zzbfn;
        public int zzbfo;

        public static final class zza extends zzlc.zza<zzo, zza> implements zzmn {
            public zza() {
                super(zzo.zzbfp);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzo zzo = new zzo();
            zzbfp = zzo;
            zzlc.zza(zzo.class, zzo);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzo();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbfp, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0007\u0000\u0002\f\u0001\u0003\f\u0002\u0004\f\u0003\u0005\t\u0004\u0006\f\u0005", new Object[]{"zzafn", "zzbfj", "zzbfk", zzgd.zzfx(), "zzbfl", zzgj.zzfx(), "zzbfm", zzfl.zzfx(), "zzbfn", "zzbfo", zzge.zzfx()});
                case 4:
                    return zzbfp;
                case 5:
                    zzmv<zzo> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzo.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbfp);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzp extends zzlc<zzp, zza> implements zzmn {
        public static volatile zzmv<zzp> zzagb;
        public static final zzp zzbfs;
        public int zzafn;
        public String zzbdd = "";
        public boolean zzbfq;
        public zzam zzbfr;

        public static final class zza extends zzlc.zza<zzp, zza> implements zzmn {
            public zza() {
                super(zzp.zzbfs);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzp zzp = new zzp();
            zzbfs = zzp;
            zzlc.zza(zzp.class, zzp);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzp();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbfs, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\b\u0000\u0002\u0007\u0001\u0003\t\u0002", new Object[]{"zzafn", "zzbdd", "zzbfq", "zzbfr"});
                case 4:
                    return zzbfs;
                case 5:
                    zzmv<zzp> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzp.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbfs);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzq extends zzlc<zzq, zza> implements zzmn {
        public static volatile zzmv<zzq> zzagb;
        public static final zzq zzbfz;
        public int zzafn;
        public int zzbbl;
        public int zzbft;
        public int zzbfu;
        public zzlh zzbfv = zzlc.zzjh();
        public zzlh zzbfw = zzlc.zzjh();
        public zzlm<String> zzbfx = zzlc.zzjj();
        public zzlm<String> zzbfy = zzlc.zzjj();

        public static final class zza extends zzlc.zza<zzq, zza> implements zzmn {
            public zza() {
                super(zzq.zzbfz);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzq zzq = new zzq();
            zzbfz = zzq;
            zzlc.zza(zzq.class, zzq);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzq();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbfz, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0004\u0000\u0001\u0004\u0000\u0002\f\u0001\u0003\u0016\u0004\u0016\u0005\u001a\u0006\u001a\u0007\f\u0002", new Object[]{"zzafn", "zzbft", "zzbfu", zzgp.zzfx(), "zzbfv", "zzbfw", "zzbfx", "zzbfy", "zzbbl", zzgd.zzfx()});
                case 4:
                    return zzbfz;
                case 5:
                    zzmv<zzq> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzq.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbfz);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzr extends zzlc<zzr, zza> implements zzmn {
        public static volatile zzmv<zzr> zzagb;
        public static final zzr zzbga;
        public int zzafn;
        public int zzbfu;

        public static final class zza extends zzlc.zza<zzr, zza> implements zzmn {
            public zza() {
                super(zzr.zzbga);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzr zzr = new zzr();
            zzbga = zzr;
            zzlc.zza(zzr.class, zzr);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzr();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbga, "\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\f\u0000", new Object[]{"zzafn", "zzbfu", zzgp.zzfx()});
                case 4:
                    return zzbga;
                case 5:
                    zzmv<zzr> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzr.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbga);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzs extends zzlc<zzs, zza> implements zzmn {
        public static volatile zzmv<zzs> zzagb;
        public static final zzs zzbge;
        public int zzafn;
        public int zzbgb;
        public int zzbgc;
        public int zzbgd;

        public static final class zza extends zzlc.zza<zzs, zza> implements zzmn {
            public zza() {
                super(zzs.zzbge);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzs zzs = new zzs();
            zzbge = zzs;
            zzlc.zza(zzs.class, zzs);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzs();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbge, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0000\u0002\u0004\u0001\u0003\u0004\u0002", new Object[]{"zzafn", "zzbgb", zzgp.zzfx(), "zzbgc", "zzbgd"});
                case 4:
                    return zzbge;
                case 5:
                    zzmv<zzs> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzs.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbge);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzt extends zzlc<zzt, zza> implements zzmn {
        public static volatile zzmv<zzt> zzagb;
        public static final zzt zzbgg;
        public zzlm<zzp> zzbgf = zzlc.zzjj();

        public static final class zza extends zzlc.zza<zzt, zza> implements zzmn {
            public zza() {
                super(zzt.zzbgg);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzt zzt = new zzt();
            zzbgg = zzt;
            zzlc.zza(zzt.class, zzt);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzt();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgg, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{"zzbgf", zzp.class});
                case 4:
                    return zzbgg;
                case 5:
                    zzmv<zzt> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzt.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgg);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzu extends zzlc<zzu, zza> implements zzmn {
        public static volatile zzmv<zzu> zzagb;
        public static final zzu zzbgk;
        public int zzafn;
        public int zzbgh;
        public int zzbgi;
        public zzs zzbgj;

        public static final class zza extends zzlc.zza<zzu, zza> implements zzmn {
            public zza() {
                super(zzu.zzbgk);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzu zzu = new zzu();
            zzbgk = zzu;
            zzlc.zza(zzu.class, zzu);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzu();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgk, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\t\u0002", new Object[]{"zzafn", "zzbgh", "zzbgi", "zzbgj"});
                case 4:
                    return zzbgk;
                case 5:
                    zzmv<zzu> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzu.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgk);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzv extends zzlc<zzv, zza> implements zzmn {
        public static volatile zzmv<zzv> zzagb;
        public static final zzv zzbgn;
        public int zzafn;
        public int zzbgl;
        public int zzbgm;

        public static final class zza extends zzlc.zza<zzv, zza> implements zzmn {
            public zza() {
                super(zzv.zzbgn);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzv zzv = new zzv();
            zzbgn = zzv;
            zzlc.zza(zzv.class, zzv);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzv();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgn, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\f\u0000\u0002\u0004\u0001", new Object[]{"zzafn", "zzbgl", zzfy.zzfx(), "zzbgm"});
                case 4:
                    return zzbgn;
                case 5:
                    zzmv<zzv> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzv.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgn);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzw extends zzlc<zzw, zza> implements zzmn {
        public static volatile zzmv<zzw> zzagb;
        public static final zzw zzbgr;
        public int zzafn;
        public byte zzbem = 2;
        public int zzbgo;
        public int zzbgp;
        public int zzbgq;

        public static final class zza extends zzlc.zza<zzw, zza> implements zzmn {
            public zza() {
                super(zzw.zzbgr);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzw zzw = new zzw();
            zzbgr = zzw;
            zzlc.zza(zzw.class, zzw);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            int i2 = 1;
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzw();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgr, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0001\u0001Ԍ\u0000\u0002\u0004\u0001\u0003\f\u0002", new Object[]{"zzafn", "zzbgo", zzhd.zzfx(), "zzbgp", "zzbgq", zzjl.zzfx()});
                case 4:
                    return zzbgr;
                case 5:
                    zzmv<zzw> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzw.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgr);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return Byte.valueOf(this.zzbem);
                case 7:
                    if (obj == null) {
                        i2 = 0;
                    }
                    this.zzbem = (byte) i2;
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzx extends zzlc<zzx, zza> implements zzmn {
        public static volatile zzmv<zzx> zzagb;
        public static final zzx zzbgs;
        public int zzafn;
        public String zzbas = "";
        public String zzbat = "";

        public static final class zza extends zzlc.zza<zzx, zza> implements zzmn {
            public zza() {
                super(zzx.zzbgs);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzx zzx = new zzx();
            zzbgs = zzx;
            zzlc.zza(zzx.class, zzx);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzx();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgs, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\b\u0000\u0002\b\u0001", new Object[]{"zzafn", "zzbas", "zzbat"});
                case 4:
                    return zzbgs;
                case 5:
                    zzmv<zzx> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzx.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgs);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzy extends zzlc<zzy, zza> implements zzmn {
        public static volatile zzmv<zzy> zzagb;
        public static final zzy zzbgv;
        public int zzafn;
        public int zzbcf;
        public long zzbgt;
        public int zzbgu;

        public static final class zza extends zzlc.zza<zzy, zza> implements zzmn {
            public zza() {
                super(zzy.zzbgv);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzy zzy = new zzy();
            zzbgv = zzy;
            zzlc.zza(zzy.class, zzy);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzy();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgv, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0000\u0002\u0002\u0001\u0003\f\u0002", new Object[]{"zzafn", "zzbcf", zzhe.zzfx(), "zzbgt", "zzbgu", zzfm.zzfx()});
                case 4:
                    return zzbgv;
                case 5:
                    zzmv<zzy> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzy.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgv);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }

    public static final class zzz extends zzlc<zzz, zza> implements zzmn {
        public static volatile zzmv<zzz> zzagb;
        public static final zzz zzbgz;
        public int zzafn;
        public int zzbbx;
        public int zzbfo;
        public int zzbgc;
        public int zzbgw;
        public boolean zzbgx;
        public boolean zzbgy;

        public static final class zza extends zzlc.zza<zzz, zza> implements zzmn {
            public zza() {
                super(zzz.zzbgz);
            }

            public /* synthetic */ zza(zzjo zzjo) {
                this();
            }
        }

        static {
            zzz zzz = new zzz();
            zzbgz = zzz;
            zzlc.zza(zzz.class, zzz);
        }

        public final Object zza(int i, Object obj, Object obj2) {
            switch (zzjo.zzagc[i - 1]) {
                case 1:
                    return new zzz();
                case 2:
                    return new zza((zzjo) null);
                case 3:
                    return zzlc.zza((zzml) zzbgz, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0004\u0000\u0002\f\u0001\u0003\u0007\u0002\u0004\u0007\u0003\u0005\f\u0004\u0006\u0006\u0005", new Object[]{"zzafn", "zzbgc", "zzbgw", zzhj.zzfx(), "zzbgx", "zzbgy", "zzbfo", zzfs.zzfx(), "zzbbx"});
                case 4:
                    return zzbgz;
                case 5:
                    zzmv<zzz> zzmv = zzagb;
                    if (zzmv == null) {
                        synchronized (zzz.class) {
                            zzmv = zzagb;
                            if (zzmv == null) {
                                zzmv = new zzlc.zzc<>(zzbgz);
                                zzagb = zzmv;
                            }
                        }
                    }
                    return zzmv;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }
    }
}
