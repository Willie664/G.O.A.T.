package com.google.android.gms.internal.cast;

public final class zzmg<K, V> {
    public final zzoi zzbpb;
    public final zzoi zzbpc;
}
