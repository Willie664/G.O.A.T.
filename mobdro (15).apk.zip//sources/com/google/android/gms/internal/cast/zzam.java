package com.google.android.gms.internal.cast;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.RelativeLayout;
import androidx.core.view.GestureDetectorCompat;
import b.c.a.b.c.g.e;
import b.c.a.b.c.g.f;
import b.c.a.b.c.g.n;
import b.c.a.b.c.g.v.a.b;
import b.c.a.b.c.g.v.a.c;
import b.c.a.b.c.g.v.a.h;
import com.google.android.gms.cast.framework.internal.featurehighlight.zzb;

public final class zzam extends RelativeLayout {
    public int color;
    public Activity zzlb;
    public View zzlc;
    public String zzle;
    public f zzlf;
    public final boolean zznc;
    public zzb zznd;
    public boolean zzne;

    @TargetApi(15)
    public zzam(e eVar) {
        throw null;
    }

    /* access modifiers changed from: private */
    public final void reset() {
        removeAllViews();
        this.zzlb = null;
        this.zzlf = null;
        this.zzlc = null;
        this.zznd = null;
        this.zzle = null;
        this.color = 0;
        this.zzne = false;
    }

    public static boolean zzh(Context context) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) context.getSystemService("accessibility");
        return accessibilityManager != null && accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled();
    }

    public final void remove() {
        if (this.zzne) {
            ((ViewGroup) this.zzlb.getWindow().getDecorView()).removeView(this);
            reset();
        }
    }

    public final void show() {
        Activity activity = this.zzlb;
        if (activity != null && this.zzlc != null && !this.zzne && !zzh(activity)) {
            if (!this.zznc || !PreferenceManager.getDefaultSharedPreferences(this.zzlb).getBoolean("googlecast-introOverlayShown", false)) {
                zzb zzb = new zzb(this.zzlb);
                this.zznd = zzb;
                int i = this.color;
                if (i != 0) {
                    zzb.f6147d.a(i);
                }
                addView(this.zznd);
                h hVar = (h) this.zzlb.getLayoutInflater().inflate(n.cast_help_text, this.zznd, false);
                hVar.setText(this.zzle, (CharSequence) null);
                zzb zzb2 = this.zznd;
                if (zzb2 != null) {
                    zzb2.f6149f = (h) zzee.checkNotNull(hVar);
                    zzb2.addView(hVar.asView(), 0);
                    zzb zzb3 = this.zznd;
                    View view = this.zzlc;
                    zzap zzap = new zzap(this);
                    if (zzb3 != null) {
                        zzb3.f6150g = (View) zzee.checkNotNull(view);
                        zzb3.l = (b.c.a.b.c.g.v.a.f) zzee.checkNotNull(zzap);
                        GestureDetectorCompat gestureDetectorCompat = new GestureDetectorCompat(zzb3.getContext(), new c(view, zzap));
                        zzb3.k = gestureDetectorCompat;
                        gestureDetectorCompat.setIsLongpressEnabled(false);
                        zzb3.setVisibility(4);
                        this.zzne = true;
                        ((ViewGroup) this.zzlb.getWindow().getDecorView()).addView(this);
                        zzb zzb4 = this.zznd;
                        if (zzb4 != null) {
                            zzb4.addOnLayoutChangeListener(new b(zzb4));
                            return;
                        }
                        throw null;
                    }
                    throw null;
                }
                throw null;
            }
            reset();
        }
    }
}
