package com.google.android.gms.internal.cast;

import java.util.Iterator;

public interface zzkh extends Iterator<Byte> {
    byte nextByte();
}
