package com.google.android.gms.internal.cast;

import java.lang.Comparable;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class zznd<K extends Comparable<K>, V> extends AbstractMap<K, V> {
    public boolean zzbjz;
    public final int zzbqf;
    public List<zznm> zzbqg;
    public Map<K, V> zzbqh;
    public volatile zzno zzbqi;
    public Map<K, V> zzbqj;
    public volatile zzni zzbqk;

    public zznd(int i) {
        this.zzbqf = i;
        this.zzbqg = Collections.emptyList();
        this.zzbqh = Collections.emptyMap();
        this.zzbqj = Collections.emptyMap();
    }

    public /* synthetic */ zznd(int i, zzng zzng) {
        this(i);
    }

    private final int zza(K k) {
        int size = this.zzbqg.size() - 1;
        if (size >= 0) {
            int compareTo = k.compareTo((Comparable) this.zzbqg.get(size).getKey());
            if (compareTo > 0) {
                return -(size + 2);
            }
            if (compareTo == 0) {
                return size;
            }
        }
        int i = 0;
        while (i <= size) {
            int i2 = (i + size) / 2;
            int compareTo2 = k.compareTo((Comparable) this.zzbqg.get(i2).getKey());
            if (compareTo2 < 0) {
                size = i2 - 1;
            } else if (compareTo2 <= 0) {
                return i2;
            } else {
                i = i2 + 1;
            }
        }
        return -(i + 1);
    }

    public static <FieldDescriptorType extends zzkw<FieldDescriptorType>> zznd<FieldDescriptorType, Object> zzbl(int i) {
        return new zzng(i);
    }

    /* access modifiers changed from: private */
    public final V zzbn(int i) {
        zzkp();
        V value = this.zzbqg.remove(i).getValue();
        if (!this.zzbqh.isEmpty()) {
            Iterator it = zzkq().entrySet().iterator();
            this.zzbqg.add(new zznm(this, (Map.Entry) it.next()));
            it.remove();
        }
        return value;
    }

    /* access modifiers changed from: private */
    public final void zzkp() {
        if (this.zzbjz) {
            throw new UnsupportedOperationException();
        }
    }

    private final SortedMap<K, V> zzkq() {
        zzkp();
        if (this.zzbqh.isEmpty() && !(this.zzbqh instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.zzbqh = treeMap;
            this.zzbqj = treeMap.descendingMap();
        }
        return (SortedMap) this.zzbqh;
    }

    public void clear() {
        zzkp();
        if (!this.zzbqg.isEmpty()) {
            this.zzbqg.clear();
        }
        if (!this.zzbqh.isEmpty()) {
            this.zzbqh.clear();
        }
    }

    public boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return zza(comparable) >= 0 || this.zzbqh.containsKey(comparable);
    }

    public Set<Map.Entry<K, V>> entrySet() {
        if (this.zzbqi == null) {
            this.zzbqi = new zzno(this, (zzng) null);
        }
        return this.zzbqi;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zznd)) {
            return super.equals(obj);
        }
        zznd zznd = (zznd) obj;
        int size = size();
        if (size != zznd.size()) {
            return false;
        }
        int zzkm = zzkm();
        if (zzkm != zznd.zzkm()) {
            return entrySet().equals(zznd.entrySet());
        }
        for (int i = 0; i < zzkm; i++) {
            if (!zzbm(i).equals(zznd.zzbm(i))) {
                return false;
            }
        }
        if (zzkm != size) {
            return this.zzbqh.equals(zznd.zzbqh);
        }
        return true;
    }

    public V get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int zza = zza(comparable);
        return zza >= 0 ? this.zzbqg.get(zza).getValue() : this.zzbqh.get(comparable);
    }

    public int hashCode() {
        int zzkm = zzkm();
        int i = 0;
        for (int i2 = 0; i2 < zzkm; i2++) {
            i += this.zzbqg.get(i2).hashCode();
        }
        return this.zzbqh.size() > 0 ? i + this.zzbqh.hashCode() : i;
    }

    public final boolean isImmutable() {
        return this.zzbjz;
    }

    public V remove(Object obj) {
        zzkp();
        Comparable comparable = (Comparable) obj;
        int zza = zza(comparable);
        if (zza >= 0) {
            return zzbn(zza);
        }
        if (this.zzbqh.isEmpty()) {
            return null;
        }
        return this.zzbqh.remove(comparable);
    }

    public int size() {
        return this.zzbqh.size() + this.zzbqg.size();
    }

    /* renamed from: zza */
    public final V put(K k, V v) {
        zzkp();
        int zza = zza(k);
        if (zza >= 0) {
            return this.zzbqg.get(zza).setValue(v);
        }
        zzkp();
        if (this.zzbqg.isEmpty() && !(this.zzbqg instanceof ArrayList)) {
            this.zzbqg = new ArrayList(this.zzbqf);
        }
        int i = -(zza + 1);
        if (i >= this.zzbqf) {
            return zzkq().put(k, v);
        }
        int size = this.zzbqg.size();
        int i2 = this.zzbqf;
        if (size == i2) {
            zznm remove = this.zzbqg.remove(i2 - 1);
            zzkq().put((Comparable) remove.getKey(), remove.getValue());
        }
        this.zzbqg.add(i, new zznm(this, k, v));
        return null;
    }

    public final Map.Entry<K, V> zzbm(int i) {
        return this.zzbqg.get(i);
    }

    public void zzib() {
        if (!this.zzbjz) {
            this.zzbqh = this.zzbqh.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.zzbqh);
            this.zzbqj = this.zzbqj.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.zzbqj);
            this.zzbjz = true;
        }
    }

    public final int zzkm() {
        return this.zzbqg.size();
    }

    public final Iterable<Map.Entry<K, V>> zzkn() {
        return this.zzbqh.isEmpty() ? zznh.zzkx() : this.zzbqh.entrySet();
    }

    public final Set<Map.Entry<K, V>> zzko() {
        if (this.zzbqk == null) {
            this.zzbqk = new zzni(this, (zzng) null);
        }
        return this.zzbqk;
    }
}
