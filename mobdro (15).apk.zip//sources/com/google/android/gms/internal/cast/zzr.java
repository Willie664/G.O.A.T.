package com.google.android.gms.internal.cast;

import android.os.Bundle;

public interface zzr {
    void onConnected(Bundle bundle);

    void onConnectionSuspended(int i);

    void zzr(int i);
}
