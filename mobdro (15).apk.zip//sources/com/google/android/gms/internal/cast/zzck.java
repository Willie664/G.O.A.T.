package com.google.android.gms.internal.cast;

import b.c.a.b.d.k.h;
import b.c.a.b.d.k.i;
import com.google.android.gms.common.api.Status;

public final class zzck implements i<Status> {
    public final /* synthetic */ long zzaam;
    public final /* synthetic */ zzch zzzt;

    public zzck(zzch zzch, long j) {
        this.zzzt = zzch;
        this.zzaam = j;
    }

    public final /* synthetic */ void onResult(h hVar) {
        Status status = (Status) hVar;
        if (!status.p()) {
            this.zzzt.zzb(this.zzaam, status.f6256b);
        }
    }
}
