package com.google.android.gms.internal.cast;

import android.app.PendingIntent;
import b.c.a.b.c.h.a;
import b.c.a.b.c.i.q;
import com.google.android.gms.common.api.Status;
import java.util.Locale;

public final class zzcr implements q {
    public final /* synthetic */ zzch zzaan;
    public final /* synthetic */ zzco zzaar;

    public zzcr(zzco zzco, zzch zzch) {
        this.zzaar = zzco;
        this.zzaan = zzch;
    }

    public final void zza(long j, int i, Object obj) {
        if (obj == null) {
            try {
                zzco zzco = this.zzaar;
                Status status = new Status(1, i, (String) null, (PendingIntent) null);
                zzco.zza(this.zzaar);
                zzco.setResult(new zzcq(status, (a) null));
            } catch (ClassCastException unused) {
                this.zzaar.setResult(zzco.zzf(new Status(13)));
            }
        } else {
            zzcv zzcv = (zzcv) obj;
            zzcs zzcs = zzcv.zzabn;
            if (zzcs == null || b.c.a.b.c.i.a.a("1.0.0", zzcs.getVersion())) {
                zzco zzco2 = this.zzaar;
                Status status2 = new Status(1, i, zzcv.zzabd, (PendingIntent) null);
                zzco.zza(this.zzaar);
                zzco2.setResult(new zzcq(status2, (a) null));
                return;
            }
            zzcs unused2 = this.zzaar.zzzt.zzzy = null;
            this.zzaar.setResult(zzco.zzf(new Status(2150, String.format(Locale.ROOT, "Incorrect Game Manager SDK version. Receiver: %s Sender: %s", new Object[]{zzcs.getVersion(), "1.0.0"}))));
        }
    }

    public final void zzb(long j) {
        this.zzaar.setResult(zzco.zzf(new Status(2103)));
    }
}
