package com.google.android.gms.internal.cast;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import b.c.a.b.d.g;
import b.c.a.b.d.k.d;
import b.c.a.b.d.n.c;
import b.c.a.b.d.n.f;

public final class zzdg extends f<zzdn> {
    public zzdg(Context context, Looper looper, c cVar, d.a aVar, d.b bVar) {
        super(context, looper, 83, cVar, aVar, bVar);
    }

    public final /* synthetic */ IInterface createServiceInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.remote_display.ICastRemoteDisplayService");
        return queryLocalInterface instanceof zzdn ? (zzdn) queryLocalInterface : new zzdm(iBinder);
    }

    public final int getMinApkVersion() {
        return g.GOOGLE_PLAY_SERVICES_VERSION_CODE;
    }

    public final String getServiceDescriptor() {
        return "com.google.android.gms.cast.remote_display.ICastRemoteDisplayService";
    }

    public final String getStartServiceAction() {
        return "com.google.android.gms.cast.remote_display.service.START";
    }
}
