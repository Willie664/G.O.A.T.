package com.google.android.gms.internal.cast;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import b.c.a.b.c.i.b;
import com.google.android.gms.internal.cast.zzjm;
import java.math.BigInteger;

@MainThread
public final class zzn {
    public static final b zzy = new b("ApplicationAnalyticsUtils");

    public static zzjm.zzj zza(@NonNull zzk zzk) {
        return (zzjm.zzj) ((zzlc) zzc(zzk).zzjd());
    }

    public static zzjm.zzj zza(@NonNull zzk zzk, int i) {
        zzjm.zzj.zza zzc = zzc(zzk);
        zzjm.zzf.zza zza = zzjm.zzf.zza(zzc.zzgm());
        zza.zzb(i != 1 ? i != 2 ? zzfg.APP_SESSION_REASON_UNKNOWN : zzfg.APP_SESSION_NETWORK_NOT_REACHABLE : zzfg.APP_SESSION_GMSCORE_SERVICE_DISCONNECTED);
        zzc.zza(zza);
        return (zzjm.zzj) ((zzlc) zzc.zzjd());
    }

    public static zzjm.zzj zza(@NonNull zzk zzk, boolean z) {
        zzjm.zzj.zza zzc = zzc(zzk);
        zza(zzc, z);
        return (zzjm.zzj) ((zzlc) zzc.zzjd());
    }

    public static void zza(@NonNull zzjm.zzj.zza zza, boolean z) {
        zzjm.zzf.zza zza2 = zzjm.zzf.zza(zza.zzgm());
        zza2.zzn(z);
        zza.zza(zza2);
    }

    public static zzjm.zzj zzb(@NonNull zzk zzk) {
        zzjm.zzj.zza zzc = zzc(zzk);
        zza(zzc, true);
        zzjm.zzf.zza zza = zzjm.zzf.zza(zzc.zzgm());
        zza.zzb(zzfg.APP_SESSION_RESUMED_FROM_SAVED_SESSION);
        zzc.zza(zza);
        return (zzjm.zzj) ((zzlc) zzc.zzjd());
    }

    public static zzjm.zzj zzb(@NonNull zzk zzk, int i) {
        zzjm.zzj.zza zzc = zzc(zzk);
        zzjm.zzf.zza zza = zzjm.zzf.zza(zzc.zzgm());
        zza.zzb(i == 0 ? zzfg.APP_SESSION_CASTING_STOPPED : zzfg.APP_SESSION_REASON_ERROR);
        zza.zzb(i != 0 ? i != 7 ? i != 15 ? i != 2000 ? i != 2002 ? i != 2004 ? i != 2005 ? zzff.APP_SESSION_ERROR_CONN_OTHER : zzff.APP_SESSION_ERROR_RECEIVER_SESSION_NOT_RUNNING : zzff.APP_SESSION_ERROR_RECEIVER_APPLICATION_NOT_FOUND : zzff.APP_SESSION_ERROR_CONN_CANCELLED : zzff.APP_SESSION_ERROR_CONN_DEVICE_AUTH : zzff.APP_SESSION_ERROR_CONN_TIMEOUT : zzff.APP_SESSION_ERROR_CONN_IO : zzff.APP_SESSION_ERROR_UNKNOWN);
        zzc.zza(zza);
        return (zzjm.zzj) ((zzlc) zzc.zzjd());
    }

    public static zzjm.zzj.zza zzc(@NonNull zzk zzk) {
        zzjm.zzj.zza zzk2 = zzjm.zzj.zzgn().zzk(zzk.zzmj);
        int i = zzk.zzmk;
        zzk.zzmk = i + 1;
        zzjm.zzj.zza zzag = zzk2.zzag(i);
        String str = zzk.zzbe;
        if (str != null) {
            zzag.zzap(str);
        }
        zzjm.zzf.zza zzgg = zzjm.zzf.zzgg();
        if (zzk.zzz != null) {
            zzgg.zzb((zzjm.zzm) ((zzlc) zzjm.zzm.zzgr().zzar(zzk.zzz).zzjd()));
        }
        zzgg.zzn(false);
        String str2 = zzk.zzml;
        if (str2 != null) {
            zzgg.zzi(zzs(str2));
        }
        zzag.zza(zzgg);
        return zzag;
    }

    public static long zzs(String str) {
        try {
            String replace = str.replace("-", "");
            return new BigInteger(replace.substring(0, Math.min(16, replace.length())), 16).longValue();
        } catch (NumberFormatException e2) {
            zzy.b("receiverSessionId %s is not valid for hash: %s", str, e2.getMessage());
            return 0;
        }
    }
}
