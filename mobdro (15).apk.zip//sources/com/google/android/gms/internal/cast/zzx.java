package com.google.android.gms.internal.cast;

import b.c.a.b.d.k.h;
import com.google.android.gms.common.api.Status;

public final /* synthetic */ class zzx implements zzba {
    public static final zzba zzmu = new zzx();

    public final h zza(Object obj) {
        return zzt.zzb((Status) obj);
    }
}
