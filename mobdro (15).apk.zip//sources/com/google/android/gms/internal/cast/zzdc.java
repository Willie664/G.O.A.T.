package com.google.android.gms.internal.cast;

import android.os.RemoteException;
import b.c.a.b.c.b;
import b.c.a.b.d.k.a;
import b.c.a.b.d.k.h;
import b.c.a.b.d.k.n.d;
import com.google.android.gms.common.api.Status;

public class zzdc extends d<b.c, zzdj> {
    public final /* synthetic */ zzcz zzaen;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public zzdc(zzcz zzcz, b.c.a.b.d.k.d dVar) {
        super((a<?>) zzcz.zzdn, dVar);
        this.zzaen = zzcz;
    }

    public /* synthetic */ h createFailedResult(Status status) {
        return new zzdh(status);
    }

    /* renamed from: zza */
    public void doExecute(zzdj zzdj) throws RemoteException {
    }
}
