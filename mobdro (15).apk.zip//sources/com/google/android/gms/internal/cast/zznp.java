package com.google.android.gms.internal.cast;

public final class zznp implements zzns {
    public final /* synthetic */ zzjy zzbqv;

    public zznp(zzjy zzjy) {
        this.zzbqv = zzjy;
    }

    public final int size() {
        return this.zzbqv.size();
    }

    public final byte zzai(int i) {
        return this.zzbqv.zzai(i);
    }
}
