package com.google.android.gms.internal.cast;

import android.annotation.TargetApi;
import android.view.Choreographer;

public abstract class zzdw {
    public Runnable zzafe;
    public Choreographer.FrameCallback zzaff;

    public abstract void doFrame(long j);

    @TargetApi(16)
    public final Choreographer.FrameCallback zzfm() {
        if (this.zzaff == null) {
            this.zzaff = new zzdz(this);
        }
        return this.zzaff;
    }

    public final Runnable zzfn() {
        if (this.zzafe == null) {
            this.zzafe = new zzdy(this);
        }
        return this.zzafe;
    }
}
