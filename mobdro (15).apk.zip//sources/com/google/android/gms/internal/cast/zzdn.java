package com.google.android.gms.internal.cast;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

public interface zzdn extends IInterface {
    void disconnect() throws RemoteException;

    void zza(zzdl zzdl) throws RemoteException;

    void zza(zzdl zzdl, int i) throws RemoteException;

    void zza(zzdl zzdl, PendingIntent pendingIntent, String str, String str2, Bundle bundle) throws RemoteException;

    void zza(zzdl zzdl, zzdp zzdp, String str, String str2, Bundle bundle) throws RemoteException;
}
