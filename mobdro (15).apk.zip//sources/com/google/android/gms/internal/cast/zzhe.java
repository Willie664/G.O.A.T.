package com.google.android.gms.internal.cast;

public enum zzhe implements zzlg {
    KEY_EXCHANGE_UNKNOWN(0),
    KEY_EXCHANGE_SUCCEEDED(1),
    KEY_EXCHANGE_FAILED(2);
    
    public static final zzlf<zzhe> zzagi = null;
    public final int value;

    /* access modifiers changed from: public */
    static {
        zzagi = new zzhh();
    }

    /* access modifiers changed from: public */
    zzhe(int i) {
        this.value = i;
    }

    public static zzli zzfx() {
        return zzhg.zzago;
    }

    public final String toString() {
        return "<" + zzhe.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + this.value + " name=" + name() + '>';
    }

    public final int zzfw() {
        return this.value;
    }
}
