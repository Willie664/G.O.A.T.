package com.google.android.gms.stats;

import androidx.legacy.content.WakefulBroadcastReceiver;

public abstract class GCoreWakefulBroadcastReceiver extends WakefulBroadcastReceiver {
}
