package com.google.android.gms.auth.api.signin.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.a.a.a.a.c;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class GoogleSignInOptionsExtensionParcelable extends AbstractSafeParcelable {
    public static final Parcelable.Creator<GoogleSignInOptionsExtensionParcelable> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    public final int f5999a;

    /* renamed from: b  reason: collision with root package name */
    public int f6000b;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f6001c;

    public GoogleSignInOptionsExtensionParcelable(int i, int i2, Bundle bundle) {
        this.f5999a = i;
        this.f6000b = i2;
        this.f6001c = bundle;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f5999a);
        d.a(parcel, 2, this.f6000b);
        d.a(parcel, 3, this.f6001c, false);
        d.b(parcel, a2);
    }
}
