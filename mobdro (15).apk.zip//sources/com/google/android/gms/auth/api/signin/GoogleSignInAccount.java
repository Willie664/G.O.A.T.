package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import b.a.b.w.e;
import b.c.a.b.a.a.a.b;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.a;
import b.c.a.b.d.r.c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleSignInAccount extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new b();
    public static a n = c.f1997a;

    /* renamed from: a  reason: collision with root package name */
    public final int f5985a;

    /* renamed from: b  reason: collision with root package name */
    public String f5986b;

    /* renamed from: c  reason: collision with root package name */
    public String f5987c;

    /* renamed from: d  reason: collision with root package name */
    public String f5988d;

    /* renamed from: e  reason: collision with root package name */
    public String f5989e;

    /* renamed from: f  reason: collision with root package name */
    public Uri f5990f;

    /* renamed from: g  reason: collision with root package name */
    public String f5991g;
    public long h;
    public String i;
    public List<Scope> j;
    public String k;
    public String l;
    public Set<Scope> m = new HashSet();

    public GoogleSignInAccount(int i2, String str, String str2, String str3, String str4, Uri uri, String str5, long j2, String str6, List<Scope> list, String str7, String str8) {
        this.f5985a = i2;
        this.f5986b = str;
        this.f5987c = str2;
        this.f5988d = str3;
        this.f5989e = str4;
        this.f5990f = uri;
        this.f5991g = str5;
        this.h = j2;
        this.i = str6;
        this.j = list;
        this.k = str7;
        this.l = str8;
    }

    @Nullable
    public static GoogleSignInAccount b(@Nullable String str) throws JSONException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String optString = jSONObject.optString("photoUrl", (String) null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i2 = 0; i2 < length; i2++) {
            hashSet.add(new Scope(jSONArray.getString(i2)));
        }
        String optString2 = jSONObject.optString("id");
        String optString3 = jSONObject.optString("tokenId", (String) null);
        String optString4 = jSONObject.optString(NotificationCompat.CATEGORY_EMAIL, (String) null);
        String optString5 = jSONObject.optString("displayName", (String) null);
        String optString6 = jSONObject.optString("givenName", (String) null);
        String optString7 = jSONObject.optString("familyName", (String) null);
        Long valueOf = Long.valueOf(parseLong);
        String string = jSONObject.getString("obfuscatedIdentifier");
        if (valueOf == null) {
            if (((c) n) != null) {
                valueOf = Long.valueOf(System.currentTimeMillis() / 1000);
            } else {
                throw null;
            }
        }
        long longValue = valueOf.longValue();
        e.d(string);
        e.b(hashSet);
        GoogleSignInAccount googleSignInAccount = r3;
        GoogleSignInAccount googleSignInAccount2 = new GoogleSignInAccount(3, optString2, optString3, optString4, optString5, parse, (String) null, longValue, string, new ArrayList(hashSet), optString6, optString7);
        GoogleSignInAccount googleSignInAccount3 = googleSignInAccount;
        googleSignInAccount3.f5991g = jSONObject.optString("serverAuthCode", (String) null);
        return googleSignInAccount3;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        if (googleSignInAccount.i.equals(this.i)) {
            if (((AbstractSet) googleSignInAccount.p()).equals(p())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((AbstractSet) p()).hashCode() + ((this.i.hashCode() + 527) * 31);
    }

    @NonNull
    public Set<Scope> p() {
        HashSet hashSet = new HashSet(this.j);
        hashSet.addAll(this.m);
        return hashSet;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f5985a);
        d.a(parcel, 2, this.f5986b, false);
        d.a(parcel, 3, this.f5987c, false);
        d.a(parcel, 4, this.f5988d, false);
        d.a(parcel, 5, this.f5989e, false);
        d.a(parcel, 6, (Parcelable) this.f5990f, i2, false);
        d.a(parcel, 7, this.f5991g, false);
        d.a(parcel, 8, this.h);
        d.a(parcel, 9, this.i, false);
        d.b(parcel, 10, this.j, false);
        d.a(parcel, 11, this.k, false);
        d.a(parcel, 12, this.l, false);
        d.b(parcel, a2);
    }
}
