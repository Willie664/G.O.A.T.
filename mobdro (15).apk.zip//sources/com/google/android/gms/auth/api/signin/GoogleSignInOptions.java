package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.core.app.NotificationCompat;
import b.c.a.b.a.a.a.c;
import b.c.a.b.d.k.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class GoogleSignInOptions extends AbstractSafeParcelable implements a.d.f, ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInOptions> CREATOR = new c();
    public static final Scope k = new Scope("profile");
    public static final Scope l = new Scope("openid");
    public static final Scope m = new Scope("https://www.googleapis.com/auth/games_lite");
    public static final Scope n = new Scope("https://www.googleapis.com/auth/games");

    /* renamed from: a  reason: collision with root package name */
    public final int f5992a;

    /* renamed from: b  reason: collision with root package name */
    public final ArrayList<Scope> f5993b;

    /* renamed from: c  reason: collision with root package name */
    public Account f5994c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f5995d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f5996e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f5997f;

    /* renamed from: g  reason: collision with root package name */
    public String f5998g;
    public String h;
    public ArrayList<GoogleSignInOptionsExtensionParcelable> i;
    public String j;

    static {
        new Scope(NotificationCompat.CATEGORY_EMAIL);
        HashSet hashSet = new HashSet();
        HashMap hashMap = new HashMap();
        hashSet.add(l);
        hashSet.add(k);
        if (hashSet.contains(n) && hashSet.contains(m)) {
            hashSet.remove(m);
        }
        new GoogleSignInOptions(3, new ArrayList(hashSet), (Account) null, false, false, false, (String) null, (String) null, hashMap, (String) null);
        HashSet hashSet2 = new HashSet();
        HashMap hashMap2 = new HashMap();
        hashSet2.add(m);
        hashSet2.addAll(Arrays.asList(new Scope[0]));
        if (hashSet2.contains(n) && hashSet2.contains(m)) {
            hashSet2.remove(m);
        }
        new GoogleSignInOptions(3, new ArrayList(hashSet2), (Account) null, false, false, false, (String) null, (String) null, hashMap2, (String) null);
    }

    public GoogleSignInOptions(int i2, ArrayList<Scope> arrayList, Account account, boolean z, boolean z2, boolean z3, String str, String str2, Map<Integer, GoogleSignInOptionsExtensionParcelable> map, String str3) {
        this.f5992a = i2;
        this.f5993b = arrayList;
        this.f5994c = account;
        this.f5995d = z;
        this.f5996e = z2;
        this.f5997f = z3;
        this.f5998g = str;
        this.h = str2;
        this.i = new ArrayList<>(map.values());
        this.j = str3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0045, code lost:
        if (r3.f5994c.equals(r4.f5994c) != false) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0060, code lost:
        if (r3.f5998g.equals(r4.f5998g) != false) goto L_0x0062;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r4) {
        /*
            r3 = this;
            r0 = 0
            if (r4 != 0) goto L_0x0004
            return r0
        L_0x0004:
            com.google.android.gms.auth.api.signin.GoogleSignInOptions r4 = (com.google.android.gms.auth.api.signin.GoogleSignInOptions) r4     // Catch:{ ClassCastException -> 0x0080 }
            java.util.ArrayList<com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable> r1 = r3.i     // Catch:{ ClassCastException -> 0x0080 }
            int r1 = r1.size()     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 > 0) goto L_0x0080
            java.util.ArrayList<com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable> r1 = r4.i     // Catch:{ ClassCastException -> 0x0080 }
            int r1 = r1.size()     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 <= 0) goto L_0x0017
            goto L_0x0080
        L_0x0017:
            java.util.ArrayList<com.google.android.gms.common.api.Scope> r1 = r3.f5993b     // Catch:{ ClassCastException -> 0x0080 }
            int r1 = r1.size()     // Catch:{ ClassCastException -> 0x0080 }
            java.util.ArrayList r2 = r4.p()     // Catch:{ ClassCastException -> 0x0080 }
            int r2 = r2.size()     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != r2) goto L_0x0080
            java.util.ArrayList<com.google.android.gms.common.api.Scope> r1 = r3.f5993b     // Catch:{ ClassCastException -> 0x0080 }
            java.util.ArrayList r2 = r4.p()     // Catch:{ ClassCastException -> 0x0080 }
            boolean r1 = r1.containsAll(r2)     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != 0) goto L_0x0034
            goto L_0x0080
        L_0x0034:
            android.accounts.Account r1 = r3.f5994c     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != 0) goto L_0x003d
            android.accounts.Account r1 = r4.f5994c     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != 0) goto L_0x0080
            goto L_0x0047
        L_0x003d:
            android.accounts.Account r1 = r3.f5994c     // Catch:{ ClassCastException -> 0x0080 }
            android.accounts.Account r2 = r4.f5994c     // Catch:{ ClassCastException -> 0x0080 }
            boolean r1 = r1.equals(r2)     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 == 0) goto L_0x0080
        L_0x0047:
            java.lang.String r1 = r3.f5998g     // Catch:{ ClassCastException -> 0x0080 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 == 0) goto L_0x0058
            java.lang.String r1 = r4.f5998g     // Catch:{ ClassCastException -> 0x0080 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 == 0) goto L_0x0080
            goto L_0x0062
        L_0x0058:
            java.lang.String r1 = r3.f5998g     // Catch:{ ClassCastException -> 0x0080 }
            java.lang.String r2 = r4.f5998g     // Catch:{ ClassCastException -> 0x0080 }
            boolean r1 = r1.equals(r2)     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 == 0) goto L_0x0080
        L_0x0062:
            boolean r1 = r3.f5997f     // Catch:{ ClassCastException -> 0x0080 }
            boolean r2 = r4.f5997f     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != r2) goto L_0x0080
            boolean r1 = r3.f5995d     // Catch:{ ClassCastException -> 0x0080 }
            boolean r2 = r4.f5995d     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != r2) goto L_0x0080
            boolean r1 = r3.f5996e     // Catch:{ ClassCastException -> 0x0080 }
            boolean r2 = r4.f5996e     // Catch:{ ClassCastException -> 0x0080 }
            if (r1 != r2) goto L_0x0080
            java.lang.String r1 = r3.j     // Catch:{ ClassCastException -> 0x0080 }
            java.lang.String r4 = r4.j     // Catch:{ ClassCastException -> 0x0080 }
            boolean r4 = android.text.TextUtils.equals(r1, r4)     // Catch:{ ClassCastException -> 0x0080 }
            if (r4 == 0) goto L_0x0080
            r4 = 1
            return r4
        L_0x0080:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.auth.api.signin.GoogleSignInOptions.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        ArrayList arrayList = new ArrayList();
        ArrayList<Scope> arrayList2 = this.f5993b;
        int size = arrayList2.size();
        int i2 = 0;
        while (i2 < size) {
            Scope scope = arrayList2.get(i2);
            i2++;
            arrayList.add(scope.f6251b);
        }
        Collections.sort(arrayList);
        b.c.a.b.a.a.a.a.a aVar = new b.c.a.b.a.a.a.a.a();
        aVar.a((Object) arrayList);
        aVar.a((Object) this.f5994c);
        aVar.a((Object) this.f5998g);
        aVar.a(this.f5997f);
        aVar.a(this.f5995d);
        aVar.a(this.f5996e);
        aVar.a((Object) this.j);
        return aVar.f1432a;
    }

    public ArrayList<Scope> p() {
        return new ArrayList<>(this.f5993b);
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f5992a);
        d.b(parcel, 2, p(), false);
        d.a(parcel, 3, (Parcelable) this.f5994c, i2, false);
        d.a(parcel, 4, this.f5995d);
        d.a(parcel, 5, this.f5996e);
        d.a(parcel, 6, this.f5997f);
        d.a(parcel, 7, this.f5998g, false);
        d.a(parcel, 8, this.h, false);
        d.b(parcel, 9, this.i, false);
        d.a(parcel, 10, this.j, false);
        d.b(parcel, a2);
    }
}
