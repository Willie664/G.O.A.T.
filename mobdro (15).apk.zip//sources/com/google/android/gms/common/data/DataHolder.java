package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b.a.b.w.e;
import b.c.a.b.d.l.b;
import b.c.a.b.d.l.c;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;

@KeepName
public final class DataHolder extends AbstractSafeParcelable implements Closeable {
    public static final Parcelable.Creator<DataHolder> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    public final int f6264a;

    /* renamed from: b  reason: collision with root package name */
    public final String[] f6265b;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f6266c;

    /* renamed from: d  reason: collision with root package name */
    public final CursorWindow[] f6267d;

    /* renamed from: e  reason: collision with root package name */
    public final int f6268e;

    /* renamed from: f  reason: collision with root package name */
    public final Bundle f6269f;

    /* renamed from: g  reason: collision with root package name */
    public int[] f6270g;
    public boolean h = false;
    public boolean i = true;

    public static class a {
        public /* synthetic */ a(String[] strArr) {
            e.b(strArr);
            new ArrayList();
            new HashMap();
        }
    }

    static {
        new b(new String[0]);
    }

    public DataHolder(int i2, String[] strArr, CursorWindow[] cursorWindowArr, int i3, Bundle bundle) {
        this.f6264a = i2;
        this.f6265b = strArr;
        this.f6267d = cursorWindowArr;
        this.f6268e = i3;
        this.f6269f = bundle;
    }

    public final void close() {
        synchronized (this) {
            if (!this.h) {
                this.h = true;
                for (CursorWindow close : this.f6267d) {
                    close.close();
                }
            }
        }
    }

    public final void finalize() throws Throwable {
        try {
            if (this.i && this.f6267d.length > 0 && !p()) {
                close();
                String.valueOf(toString()).length();
            }
        } finally {
            super.finalize();
        }
    }

    public final boolean p() {
        boolean z;
        synchronized (this) {
            z = this.h;
        }
        return z;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        String[] strArr = this.f6265b;
        if (strArr != null) {
            int a3 = d.a(parcel, 1);
            parcel.writeStringArray(strArr);
            d.b(parcel, a3);
        }
        d.a(parcel, 2, (T[]) this.f6267d, i2, false);
        d.a(parcel, 3, this.f6268e);
        d.a(parcel, 4, this.f6269f, false);
        d.a(parcel, 1000, this.f6264a);
        d.b(parcel, a2);
        if ((i2 & 1) != 0) {
            close();
        }
    }
}
