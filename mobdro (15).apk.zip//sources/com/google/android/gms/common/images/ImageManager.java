package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import com.google.android.gms.common.annotation.KeepName;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;

public final class ImageManager {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f6271a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static HashSet<Uri> f6272b = new HashSet<>();

    @KeepName
    public final class ImageReceiver extends ResultReceiver {
        public final void onReceiveResult(int i, Bundle bundle) {
            ParcelFileDescriptor parcelFileDescriptor = (ParcelFileDescriptor) bundle.getParcelable("com.google.android.gms.extra.fileDescriptor");
            ImageManager.a();
            throw null;
        }
    }

    public static /* synthetic */ ExecutorService a() {
        throw null;
    }
}
