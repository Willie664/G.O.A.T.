package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import b.a.b.w.e;
import b.c.a.b.d.m.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Locale;

public final class WebImage extends AbstractSafeParcelable {
    public static final Parcelable.Creator<WebImage> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final int f6273a;

    /* renamed from: b  reason: collision with root package name */
    public final Uri f6274b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6275c;

    /* renamed from: d  reason: collision with root package name */
    public final int f6276d;

    public WebImage(int i, Uri uri, int i2, int i3) {
        this.f6273a = i;
        this.f6274b = uri;
        this.f6275c = i2;
        this.f6276d = i3;
    }

    public WebImage(Uri uri, int i, int i2) throws IllegalArgumentException {
        this.f6273a = 1;
        this.f6274b = uri;
        this.f6275c = i;
        this.f6276d = i2;
        if (uri == null) {
            throw new IllegalArgumentException("url cannot be null");
        } else if (i < 0 || i2 < 0) {
            throw new IllegalArgumentException("width and height must not be negative");
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof WebImage)) {
            WebImage webImage = (WebImage) obj;
            return e.c((Object) this.f6274b, (Object) webImage.f6274b) && this.f6275c == webImage.f6275c && this.f6276d == webImage.f6276d;
        }
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6274b, Integer.valueOf(this.f6275c), Integer.valueOf(this.f6276d)});
    }

    public final String toString() {
        return String.format(Locale.US, "Image %dx%d %s", new Object[]{Integer.valueOf(this.f6275c), Integer.valueOf(this.f6276d), this.f6274b.toString()});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6273a);
        d.a(parcel, 2, (Parcelable) this.f6274b, i, false);
        d.a(parcel, 3, this.f6275c);
        d.a(parcel, 4, this.f6276d);
        d.b(parcel, a2);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public WebImage(org.json.JSONObject r5) throws java.lang.IllegalArgumentException {
        /*
            r4 = this;
            java.lang.String r0 = "url"
            boolean r1 = r5.has(r0)
            if (r1 == 0) goto L_0x0011
            java.lang.String r0 = r5.getString(r0)     // Catch:{ JSONException -> 0x0011 }
            android.net.Uri r0 = android.net.Uri.parse(r0)     // Catch:{ JSONException -> 0x0011 }
            goto L_0x0012
        L_0x0011:
            r0 = 0
        L_0x0012:
            r1 = 0
            java.lang.String r2 = "width"
            int r2 = r5.optInt(r2, r1)
            java.lang.String r3 = "height"
            int r5 = r5.optInt(r3, r1)
            r4.<init>(r0, r2, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.images.WebImage.<init>(org.json.JSONObject):void");
    }
}
