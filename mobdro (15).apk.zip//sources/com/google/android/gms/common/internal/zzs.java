package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.t0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

@Deprecated
public final class zzs extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzs> CREATOR = new t0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6309a;

    public zzs(int i) {
        this.f6309a = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6309a);
        d.b(parcel, a2);
    }
}
