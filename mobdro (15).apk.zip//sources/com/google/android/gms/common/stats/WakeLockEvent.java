package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.q.d;
import java.util.List;

public final class WakeLockEvent extends StatsEvent {
    public static final Parcelable.Creator<WakeLockEvent> CREATOR = new d();

    /* renamed from: a  reason: collision with root package name */
    public final int f6344a;

    /* renamed from: b  reason: collision with root package name */
    public final long f6345b;

    /* renamed from: c  reason: collision with root package name */
    public int f6346c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6347d;

    /* renamed from: e  reason: collision with root package name */
    public final String f6348e;

    /* renamed from: f  reason: collision with root package name */
    public final String f6349f;

    /* renamed from: g  reason: collision with root package name */
    public final int f6350g;
    public final List<String> h;
    public final String i;
    public final long j;
    public int k;
    public final String l;
    public final float m;
    public final long n;
    public final boolean o;
    public long p = -1;

    public WakeLockEvent(int i2, long j2, int i3, String str, int i4, List<String> list, String str2, long j3, int i5, String str3, String str4, float f2, long j4, String str5, boolean z) {
        this.f6344a = i2;
        this.f6345b = j2;
        this.f6346c = i3;
        this.f6347d = str;
        this.f6348e = str3;
        this.f6349f = str5;
        this.f6350g = i4;
        this.h = list;
        this.i = str2;
        this.j = j3;
        this.k = i5;
        this.l = str4;
        this.m = f2;
        this.n = j4;
        this.o = z;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int a2 = b.c.a.b.d.n.u.d.a(parcel);
        b.c.a.b.d.n.u.d.a(parcel, 1, this.f6344a);
        b.c.a.b.d.n.u.d.a(parcel, 2, this.f6345b);
        b.c.a.b.d.n.u.d.a(parcel, 4, this.f6347d, false);
        b.c.a.b.d.n.u.d.a(parcel, 5, this.f6350g);
        b.c.a.b.d.n.u.d.a(parcel, 6, this.h, false);
        b.c.a.b.d.n.u.d.a(parcel, 8, this.j);
        b.c.a.b.d.n.u.d.a(parcel, 10, this.f6348e, false);
        b.c.a.b.d.n.u.d.a(parcel, 11, this.f6346c);
        b.c.a.b.d.n.u.d.a(parcel, 12, this.i, false);
        b.c.a.b.d.n.u.d.a(parcel, 13, this.l, false);
        b.c.a.b.d.n.u.d.a(parcel, 14, this.k);
        b.c.a.b.d.n.u.d.a(parcel, 15, this.m);
        b.c.a.b.d.n.u.d.a(parcel, 16, this.n);
        b.c.a.b.d.n.u.d.a(parcel, 17, this.f6349f, false);
        b.c.a.b.d.n.u.d.a(parcel, 18, this.o);
        b.c.a.b.d.n.u.d.b(parcel, a2);
    }
}
