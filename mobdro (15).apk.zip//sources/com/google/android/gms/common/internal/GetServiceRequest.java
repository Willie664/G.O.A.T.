package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.d;
import b.c.a.b.d.n.a;
import b.c.a.b.d.n.h0;
import b.c.a.b.d.n.j;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class GetServiceRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<GetServiceRequest> CREATOR = new h0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6286a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6287b;

    /* renamed from: c  reason: collision with root package name */
    public int f6288c;

    /* renamed from: d  reason: collision with root package name */
    public String f6289d;

    /* renamed from: e  reason: collision with root package name */
    public IBinder f6290e;

    /* renamed from: f  reason: collision with root package name */
    public Scope[] f6291f;

    /* renamed from: g  reason: collision with root package name */
    public Bundle f6292g;
    public Account h;
    public Feature[] i;
    public Feature[] j;
    public boolean k;
    public int l;

    public GetServiceRequest(int i2) {
        this.f6286a = 4;
        this.f6288c = d.f1771a;
        this.f6287b = i2;
        this.k = true;
    }

    public GetServiceRequest(int i2, int i3, int i4, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, Feature[] featureArr, Feature[] featureArr2, boolean z, int i5) {
        this.f6286a = i2;
        this.f6287b = i3;
        this.f6288c = i4;
        if ("com.google.android.gms".equals(str)) {
            this.f6289d = "com.google.android.gms";
        } else {
            this.f6289d = str;
        }
        if (i2 < 2) {
            this.h = iBinder != null ? a.a(j.a.a(iBinder)) : null;
        } else {
            this.f6290e = iBinder;
            this.h = account;
        }
        this.f6291f = scopeArr;
        this.f6292g = bundle;
        this.i = featureArr;
        this.j = featureArr2;
        this.k = z;
        this.l = i5;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = b.c.a.b.d.n.u.d.a(parcel);
        b.c.a.b.d.n.u.d.a(parcel, 1, this.f6286a);
        b.c.a.b.d.n.u.d.a(parcel, 2, this.f6287b);
        b.c.a.b.d.n.u.d.a(parcel, 3, this.f6288c);
        b.c.a.b.d.n.u.d.a(parcel, 4, this.f6289d, false);
        b.c.a.b.d.n.u.d.a(parcel, 5, this.f6290e, false);
        b.c.a.b.d.n.u.d.a(parcel, 6, (T[]) this.f6291f, i2, false);
        b.c.a.b.d.n.u.d.a(parcel, 7, this.f6292g, false);
        b.c.a.b.d.n.u.d.a(parcel, 8, (Parcelable) this.h, i2, false);
        b.c.a.b.d.n.u.d.a(parcel, 10, (T[]) this.i, i2, false);
        b.c.a.b.d.n.u.d.a(parcel, 11, (T[]) this.j, i2, false);
        b.c.a.b.d.n.u.d.a(parcel, 12, this.k);
        b.c.a.b.d.n.u.d.a(parcel, 13, this.l);
        b.c.a.b.d.n.u.d.b(parcel, a2);
    }
}
