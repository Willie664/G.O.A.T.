package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.g0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class zza extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zza> CREATOR = new g0();

    /* renamed from: a  reason: collision with root package name */
    public Bundle f6306a;

    /* renamed from: b  reason: collision with root package name */
    public Feature[] f6307b;

    /* renamed from: c  reason: collision with root package name */
    public int f6308c;

    public zza() {
    }

    public zza(Bundle bundle, Feature[] featureArr, int i) {
        this.f6306a = bundle;
        this.f6307b = featureArr;
        this.f6308c = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6306a, false);
        d.a(parcel, 2, (T[]) this.f6307b, i, false);
        d.a(parcel, 3, this.f6308c);
        d.b(parcel, a2);
    }
}
