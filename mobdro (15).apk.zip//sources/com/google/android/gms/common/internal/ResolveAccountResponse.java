package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.d0;
import b.c.a.b.d.n.j;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountResponse extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ResolveAccountResponse> CREATOR = new d0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6297a;

    /* renamed from: b  reason: collision with root package name */
    public IBinder f6298b;

    /* renamed from: c  reason: collision with root package name */
    public ConnectionResult f6299c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f6300d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f6301e;

    public ResolveAccountResponse(int i, IBinder iBinder, ConnectionResult connectionResult, boolean z, boolean z2) {
        this.f6297a = i;
        this.f6298b = iBinder;
        this.f6299c = connectionResult;
        this.f6300d = z;
        this.f6301e = z2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ResolveAccountResponse)) {
            return false;
        }
        ResolveAccountResponse resolveAccountResponse = (ResolveAccountResponse) obj;
        return this.f6299c.equals(resolveAccountResponse.f6299c) && p().equals(resolveAccountResponse.p());
    }

    public j p() {
        return j.a.a(this.f6298b);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6297a);
        d.a(parcel, 2, this.f6298b, false);
        d.a(parcel, 3, (Parcelable) this.f6299c, i, false);
        d.a(parcel, 4, this.f6300d);
        d.a(parcel, 5, this.f6301e);
        d.b(parcel, a2);
    }
}
