package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.p.a.b;
import b.c.a.b.d.p.a.c;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;
import java.util.ArrayList;
import java.util.HashMap;

public final class StringToIntConverter extends AbstractSafeParcelable implements FastJsonResponse.a<String, Integer> {
    public static final Parcelable.Creator<StringToIntConverter> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    public final int f6313a;

    /* renamed from: b  reason: collision with root package name */
    public final HashMap<String, Integer> f6314b;

    /* renamed from: c  reason: collision with root package name */
    public final SparseArray<String> f6315c;

    public static final class zaa extends AbstractSafeParcelable {
        public static final Parcelable.Creator<zaa> CREATOR = new b();

        /* renamed from: a  reason: collision with root package name */
        public final int f6316a;

        /* renamed from: b  reason: collision with root package name */
        public final String f6317b;

        /* renamed from: c  reason: collision with root package name */
        public final int f6318c;

        public zaa(int i, String str, int i2) {
            this.f6316a = i;
            this.f6317b = str;
            this.f6318c = i2;
        }

        public zaa(String str, int i) {
            this.f6316a = 1;
            this.f6317b = str;
            this.f6318c = i;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            int a2 = d.a(parcel);
            d.a(parcel, 1, this.f6316a);
            d.a(parcel, 2, this.f6317b, false);
            d.a(parcel, 3, this.f6318c);
            d.b(parcel, a2);
        }
    }

    public StringToIntConverter() {
        this.f6313a = 1;
        this.f6314b = new HashMap<>();
        this.f6315c = new SparseArray<>();
    }

    public StringToIntConverter(int i, ArrayList<zaa> arrayList) {
        this.f6313a = i;
        this.f6314b = new HashMap<>();
        this.f6315c = new SparseArray<>();
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            zaa zaa2 = arrayList.get(i2);
            i2++;
            zaa zaa3 = zaa2;
            String str = zaa3.f6317b;
            int i3 = zaa3.f6318c;
            this.f6314b.put(str, Integer.valueOf(i3));
            this.f6315c.put(i3, str);
        }
    }

    public final /* synthetic */ Object a(Object obj) {
        String str = this.f6315c.get(((Integer) obj).intValue());
        return (str != null || !this.f6314b.containsKey("gms_unknown")) ? str : "gms_unknown";
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6313a);
        ArrayList arrayList = new ArrayList();
        for (String next : this.f6314b.keySet()) {
            arrayList.add(new zaa(next, this.f6314b.get(next).intValue()));
        }
        d.b(parcel, 2, arrayList, false);
        d.b(parcel, a2);
    }
}
