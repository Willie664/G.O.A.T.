package com.google.android.gms.common.api.internal;

import androidx.annotation.Keep;
import b.c.a.b.d.k.n.i;
import b.c.a.b.d.k.n.j;

public class LifecycleCallback {
    @Keep
    public static j getChimeraLifecycleFragmentImpl(i iVar) {
        throw new IllegalStateException("Method not available in SDK.");
    }
}
