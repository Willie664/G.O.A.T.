package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import b.a.a.a.a;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.p.b.e;
import com.google.android.gms.common.server.response.FastJsonResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SafeParcelResponse extends FastSafeParcelableJsonResponse {
    public static final Parcelable.Creator<SafeParcelResponse> CREATOR = new e();

    /* renamed from: a  reason: collision with root package name */
    public final int f6328a;

    /* renamed from: b  reason: collision with root package name */
    public final Parcel f6329b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6330c = 2;

    /* renamed from: d  reason: collision with root package name */
    public final zaj f6331d;

    /* renamed from: e  reason: collision with root package name */
    public final String f6332e;

    /* renamed from: f  reason: collision with root package name */
    public int f6333f;

    /* renamed from: g  reason: collision with root package name */
    public int f6334g;

    public SafeParcelResponse(int i, Parcel parcel, zaj zaj) {
        this.f6328a = i;
        b.a.b.w.e.b(parcel);
        this.f6329b = parcel;
        this.f6331d = zaj;
        this.f6332e = zaj == null ? null : zaj.f6337c;
        this.f6333f = 2;
    }

    public static void a(StringBuilder sb, int i, Object obj) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                sb.append(obj);
                return;
            case 7:
                sb.append("\"");
                sb.append(b.c.a.b.d.r.e.a(obj.toString()));
                sb.append("\"");
                return;
            case 8:
                sb.append("\"");
                sb.append(d.a((byte[]) obj));
                sb.append("\"");
                return;
            case 9:
                sb.append("\"");
                sb.append(d.b((byte[]) obj));
                sb.append("\"");
                return;
            case 10:
                d.a(sb, (HashMap<String, String>) (HashMap) obj);
                return;
            case 11:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException(a.a(26, "Unknown type = ", i));
        }
    }

    public Map<String, FastJsonResponse.Field<?, ?>> a() {
        zaj zaj = this.f6331d;
        if (zaj == null) {
            return null;
        }
        return zaj.b(this.f6332e);
    }

    public final void a(StringBuilder sb, FastJsonResponse.Field<?, ?> field, Object obj) {
        if (field.f6323c) {
            ArrayList arrayList = (ArrayList) obj;
            sb.append("[");
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (i != 0) {
                    sb.append(",");
                }
                a(sb, field.f6322b, arrayList.get(i));
            }
            sb.append("]");
            return;
        }
        a(sb, field.f6322b, obj);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v4, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v6, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v21, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v8, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: long} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v10, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v15, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: android.os.Parcel} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v5, resolved type: android.os.Parcel} */
    /* JADX WARNING: type inference failed for: r6v3 */
    /* JADX WARNING: type inference failed for: r6v16 */
    /* JADX WARNING: type inference failed for: r6v18 */
    /* JADX WARNING: type inference failed for: r6v19 */
    /* JADX WARNING: type inference failed for: r6v20 */
    /* JADX WARNING: type inference failed for: r6v21 */
    /* JADX WARNING: type inference failed for: r6v22 */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:146:0x036e, code lost:
        r13.append(r1);
        r13.append("\"");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:153:0x039e, code lost:
        r13.append(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00d0, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00dd, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00e6, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00f3, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x0100, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x010d, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0116, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0123, code lost:
        if (r2 != null) goto L_0x0125;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x0125, code lost:
        r1 = r2.a(r1);
     */
    /* JADX WARNING: Incorrect type for immutable var: ssa=boolean[], code=?, for r6v12, types: [boolean[]] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(java.lang.StringBuilder r13, java.util.Map<java.lang.String, com.google.android.gms.common.server.response.FastJsonResponse.Field<?, ?>> r14, android.os.Parcel r15) {
        /*
            r12 = this;
            android.util.SparseArray r0 = new android.util.SparseArray
            r0.<init>()
            java.util.Set r14 = r14.entrySet()
            java.util.Iterator r14 = r14.iterator()
        L_0x000d:
            boolean r1 = r14.hasNext()
            if (r1 == 0) goto L_0x0025
            java.lang.Object r1 = r14.next()
            java.util.Map$Entry r1 = (java.util.Map.Entry) r1
            java.lang.Object r2 = r1.getValue()
            com.google.android.gms.common.server.response.FastJsonResponse$Field r2 = (com.google.android.gms.common.server.response.FastJsonResponse.Field) r2
            int r2 = r2.f6327g
            r0.put(r2, r1)
            goto L_0x000d
        L_0x0025:
            r14 = 123(0x7b, float:1.72E-43)
            r13.append(r14)
            int r14 = b.a.b.w.e.a((android.os.Parcel) r15)
            r1 = 0
        L_0x002f:
            int r2 = r15.dataPosition()
            if (r2 >= r14) goto L_0x03ac
            int r2 = r15.readInt()
            r3 = 65535(0xffff, float:9.1834E-41)
            r3 = r3 & r2
            java.lang.Object r3 = r0.get(r3)
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3
            if (r3 == 0) goto L_0x002f
            java.lang.String r4 = ","
            if (r1 == 0) goto L_0x004c
            r13.append(r4)
        L_0x004c:
            java.lang.Object r1 = r3.getKey()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object r3 = r3.getValue()
            com.google.android.gms.common.server.response.FastJsonResponse$Field r3 = (com.google.android.gms.common.server.response.FastJsonResponse.Field) r3
            java.lang.String r5 = "\""
            r13.append(r5)
            r13.append(r1)
            java.lang.String r1 = "\":"
            r13.append(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r1 = r3.k
            if (r1 == 0) goto L_0x006b
            r1 = 1
            goto L_0x006c
        L_0x006b:
            r1 = 0
        L_0x006c:
            if (r1 == 0) goto L_0x012e
            int r1 = r3.f6324d
            switch(r1) {
                case 0: goto L_0x0119;
                case 1: goto L_0x0110;
                case 2: goto L_0x0103;
                case 3: goto L_0x00f6;
                case 4: goto L_0x00e9;
                case 5: goto L_0x00e0;
                case 6: goto L_0x00d3;
                case 7: goto L_0x00ca;
                case 8: goto L_0x00bd;
                case 9: goto L_0x00bd;
                case 10: goto L_0x008b;
                case 11: goto L_0x0083;
                default: goto L_0x0073;
            }
        L_0x0073:
            java.lang.IllegalArgumentException r13 = new java.lang.IllegalArgumentException
            int r14 = r3.f6324d
            r15 = 36
            java.lang.String r0 = "Unknown field out type = "
            java.lang.String r14 = b.a.a.a.a.a((int) r15, (java.lang.String) r0, (int) r14)
            r13.<init>(r14)
            throw r13
        L_0x0083:
            java.lang.IllegalArgumentException r13 = new java.lang.IllegalArgumentException
            java.lang.String r14 = "Method does not accept concrete type."
            r13.<init>(r14)
            throw r13
        L_0x008b:
            android.os.Bundle r1 = b.a.b.w.e.c((android.os.Parcel) r15, (int) r2)
            java.util.HashMap r2 = new java.util.HashMap
            r2.<init>()
            java.util.Set r4 = r1.keySet()
            java.util.Iterator r4 = r4.iterator()
        L_0x009c:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x00b0
            java.lang.Object r5 = r4.next()
            java.lang.String r5 = (java.lang.String) r5
            java.lang.String r6 = r1.getString(r5)
            r2.put(r5, r6)
            goto L_0x009c
        L_0x00b0:
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r1 = r3.k
            if (r1 == 0) goto L_0x00b8
            java.lang.Object r2 = r1.a(r2)
        L_0x00b8:
            r12.a((java.lang.StringBuilder) r13, (com.google.android.gms.common.server.response.FastJsonResponse.Field<?, ?>) r3, (java.lang.Object) r2)
            goto L_0x03a9
        L_0x00bd:
            byte[] r1 = b.a.b.w.e.d((android.os.Parcel) r15, (int) r2)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            java.lang.Object r1 = r2.a(r1)
            goto L_0x0129
        L_0x00ca:
            java.lang.String r1 = b.a.b.w.e.h((android.os.Parcel) r15, (int) r2)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x00d3:
            boolean r1 = b.a.b.w.e.l(r15, r2)
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x00e0:
            java.math.BigDecimal r1 = b.a.b.w.e.a((android.os.Parcel) r15, (int) r2)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x00e9:
            double r1 = b.a.b.w.e.n(r15, r2)
            java.lang.Double r1 = java.lang.Double.valueOf(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x00f6:
            float r1 = b.a.b.w.e.o(r15, r2)
            java.lang.Float r1 = java.lang.Float.valueOf(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x0103:
            long r1 = b.a.b.w.e.s(r15, r2)
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x0110:
            java.math.BigInteger r1 = b.a.b.w.e.b((android.os.Parcel) r15, (int) r2)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
            goto L_0x0125
        L_0x0119:
            int r1 = b.a.b.w.e.q(r15, r2)
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            com.google.android.gms.common.server.response.FastJsonResponse$a<I, O> r2 = r3.k
            if (r2 == 0) goto L_0x0129
        L_0x0125:
            java.lang.Object r1 = r2.a(r1)
        L_0x0129:
            r12.a((java.lang.StringBuilder) r13, (com.google.android.gms.common.server.response.FastJsonResponse.Field<?, ?>) r3, (java.lang.Object) r1)
            goto L_0x03a9
        L_0x012e:
            boolean r1 = r3.f6325e
            if (r1 == 0) goto L_0x02d2
            java.lang.String r1 = "["
            r13.append(r1)
            int r1 = r3.f6324d
            r6 = 0
            switch(r1) {
                case 0: goto L_0x02b6;
                case 1: goto L_0x028c;
                case 2: goto L_0x0273;
                case 3: goto L_0x024b;
                case 4: goto L_0x0223;
                case 5: goto L_0x01ef;
                case 6: goto L_0x01c7;
                case 7: goto L_0x01ac;
                case 8: goto L_0x01a4;
                case 9: goto L_0x01a4;
                case 10: goto L_0x01a4;
                case 11: goto L_0x0145;
                default: goto L_0x013d;
            }
        L_0x013d:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r14 = "Unknown field type out."
            r13.<init>(r14)
            throw r13
        L_0x0145:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x0150
            goto L_0x017b
        L_0x0150:
            int r5 = r15.readInt()
            android.os.Parcel[] r7 = new android.os.Parcel[r5]
            r8 = 0
        L_0x0157:
            if (r8 >= r5) goto L_0x0176
            int r9 = r15.readInt()
            if (r9 == 0) goto L_0x0171
            int r10 = r15.dataPosition()
            android.os.Parcel r11 = android.os.Parcel.obtain()
            r11.appendFrom(r15, r10, r9)
            r7[r8] = r11
            int r10 = r10 + r9
            r15.setDataPosition(r10)
            goto L_0x0173
        L_0x0171:
            r7[r8] = r6
        L_0x0173:
            int r8 = r8 + 1
            goto L_0x0157
        L_0x0176:
            int r2 = r2 + r1
            r15.setDataPosition(r2)
            r6 = r7
        L_0x017b:
            int r1 = r6.length
            r2 = 0
        L_0x017d:
            if (r2 >= r1) goto L_0x02cf
            if (r2 <= 0) goto L_0x0184
            r13.append(r4)
        L_0x0184:
            r5 = r6[r2]
            r7 = 0
            r5.setDataPosition(r7)
            java.lang.String r5 = r3.i
            b.a.b.w.e.b(r5)
            com.google.android.gms.common.server.response.zaj r5 = r3.j
            b.a.b.w.e.b(r5)
            com.google.android.gms.common.server.response.zaj r5 = r3.j
            java.lang.String r7 = r3.i
            java.util.Map r5 = r5.b(r7)
            r7 = r6[r2]
            r12.a((java.lang.StringBuilder) r13, (java.util.Map<java.lang.String, com.google.android.gms.common.server.response.FastJsonResponse.Field<?, ?>>) r5, (android.os.Parcel) r7)
            int r2 = r2 + 1
            goto L_0x017d
        L_0x01a4:
            java.lang.UnsupportedOperationException r13 = new java.lang.UnsupportedOperationException
            java.lang.String r14 = "List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported"
            r13.<init>(r14)
            throw r13
        L_0x01ac:
            java.lang.String[] r1 = b.a.b.w.e.i(r15, r2)
            int r2 = r1.length
            r3 = 0
        L_0x01b2:
            if (r3 >= r2) goto L_0x02cf
            if (r3 == 0) goto L_0x01b9
            r13.append(r4)
        L_0x01b9:
            r13.append(r5)
            r6 = r1[r3]
            r13.append(r6)
            r13.append(r5)
            int r3 = r3 + 1
            goto L_0x01b2
        L_0x01c7:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x01d2
            goto L_0x01da
        L_0x01d2:
            boolean[] r6 = r15.createBooleanArray()
            int r2 = r2 + r1
            r15.setDataPosition(r2)
        L_0x01da:
            int r1 = r6.length
            r2 = 0
        L_0x01dc:
            if (r2 >= r1) goto L_0x02cf
            if (r2 == 0) goto L_0x01e3
            r13.append(r4)
        L_0x01e3:
            boolean r3 = r6[r2]
            java.lang.String r3 = java.lang.Boolean.toString(r3)
            r13.append(r3)
            int r2 = r2 + 1
            goto L_0x01dc
        L_0x01ef:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x01fa
            goto L_0x021e
        L_0x01fa:
            int r3 = r15.readInt()
            java.math.BigDecimal[] r6 = new java.math.BigDecimal[r3]
            r4 = 0
        L_0x0201:
            if (r4 >= r3) goto L_0x021a
            byte[] r5 = r15.createByteArray()
            int r7 = r15.readInt()
            java.math.BigDecimal r8 = new java.math.BigDecimal
            java.math.BigInteger r9 = new java.math.BigInteger
            r9.<init>(r5)
            r8.<init>(r9, r7)
            r6[r4] = r8
            int r4 = r4 + 1
            goto L_0x0201
        L_0x021a:
            int r2 = r2 + r1
            r15.setDataPosition(r2)
        L_0x021e:
            b.c.a.b.d.n.u.d.a((java.lang.StringBuilder) r13, (T[]) r6)
            goto L_0x02cf
        L_0x0223:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x022e
            goto L_0x0236
        L_0x022e:
            double[] r6 = r15.createDoubleArray()
            int r2 = r2 + r1
            r15.setDataPosition(r2)
        L_0x0236:
            int r1 = r6.length
            r2 = 0
        L_0x0238:
            if (r2 >= r1) goto L_0x02cf
            if (r2 == 0) goto L_0x023f
            r13.append(r4)
        L_0x023f:
            r7 = r6[r2]
            java.lang.String r3 = java.lang.Double.toString(r7)
            r13.append(r3)
            int r2 = r2 + 1
            goto L_0x0238
        L_0x024b:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x0256
            goto L_0x025e
        L_0x0256:
            float[] r6 = r15.createFloatArray()
            int r2 = r2 + r1
            r15.setDataPosition(r2)
        L_0x025e:
            int r1 = r6.length
            r2 = 0
        L_0x0260:
            if (r2 >= r1) goto L_0x02cf
            if (r2 == 0) goto L_0x0267
            r13.append(r4)
        L_0x0267:
            r3 = r6[r2]
            java.lang.String r3 = java.lang.Float.toString(r3)
            r13.append(r3)
            int r2 = r2 + 1
            goto L_0x0260
        L_0x0273:
            long[] r1 = b.a.b.w.e.f((android.os.Parcel) r15, (int) r2)
            int r2 = r1.length
            r3 = 0
        L_0x0279:
            if (r3 >= r2) goto L_0x02cf
            if (r3 == 0) goto L_0x0280
            r13.append(r4)
        L_0x0280:
            r5 = r1[r3]
            java.lang.String r5 = java.lang.Long.toString(r5)
            r13.append(r5)
            int r3 = r3 + 1
            goto L_0x0279
        L_0x028c:
            int r1 = b.a.b.w.e.t(r15, r2)
            int r2 = r15.dataPosition()
            if (r1 != 0) goto L_0x0297
            goto L_0x02b2
        L_0x0297:
            int r3 = r15.readInt()
            java.math.BigInteger[] r6 = new java.math.BigInteger[r3]
            r4 = 0
        L_0x029e:
            if (r4 >= r3) goto L_0x02ae
            java.math.BigInteger r5 = new java.math.BigInteger
            byte[] r7 = r15.createByteArray()
            r5.<init>(r7)
            r6[r4] = r5
            int r4 = r4 + 1
            goto L_0x029e
        L_0x02ae:
            int r2 = r2 + r1
            r15.setDataPosition(r2)
        L_0x02b2:
            b.c.a.b.d.n.u.d.a((java.lang.StringBuilder) r13, (T[]) r6)
            goto L_0x02cf
        L_0x02b6:
            int[] r1 = b.a.b.w.e.e((android.os.Parcel) r15, (int) r2)
            int r2 = r1.length
            r3 = 0
        L_0x02bc:
            if (r3 >= r2) goto L_0x02cf
            if (r3 == 0) goto L_0x02c3
            r13.append(r4)
        L_0x02c3:
            r5 = r1[r3]
            java.lang.String r5 = java.lang.Integer.toString(r5)
            r13.append(r5)
            int r3 = r3 + 1
            goto L_0x02bc
        L_0x02cf:
            java.lang.String r1 = "]"
            goto L_0x0347
        L_0x02d2:
            int r1 = r3.f6324d
            switch(r1) {
                case 0: goto L_0x03a2;
                case 1: goto L_0x039a;
                case 2: goto L_0x0392;
                case 3: goto L_0x038a;
                case 4: goto L_0x0382;
                case 5: goto L_0x037d;
                case 6: goto L_0x0375;
                case 7: goto L_0x0363;
                case 8: goto L_0x0357;
                case 9: goto L_0x034b;
                case 10: goto L_0x02fe;
                case 11: goto L_0x02df;
                default: goto L_0x02d7;
            }
        L_0x02d7:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r14 = "Unknown field type out"
            r13.<init>(r14)
            throw r13
        L_0x02df:
            android.os.Parcel r1 = b.a.b.w.e.g((android.os.Parcel) r15, (int) r2)
            r2 = 0
            r1.setDataPosition(r2)
            java.lang.String r2 = r3.i
            b.a.b.w.e.b(r2)
            com.google.android.gms.common.server.response.zaj r2 = r3.j
            b.a.b.w.e.b(r2)
            com.google.android.gms.common.server.response.zaj r2 = r3.j
            java.lang.String r3 = r3.i
            java.util.Map r2 = r2.b(r3)
            r12.a((java.lang.StringBuilder) r13, (java.util.Map<java.lang.String, com.google.android.gms.common.server.response.FastJsonResponse.Field<?, ?>>) r2, (android.os.Parcel) r1)
            goto L_0x03a9
        L_0x02fe:
            android.os.Bundle r1 = b.a.b.w.e.c((android.os.Parcel) r15, (int) r2)
            java.util.Set r2 = r1.keySet()
            r2.size()
            java.lang.String r3 = "{"
            r13.append(r3)
            java.util.Iterator r2 = r2.iterator()
            r3 = 1
        L_0x0313:
            boolean r6 = r2.hasNext()
            if (r6 == 0) goto L_0x0345
            java.lang.Object r6 = r2.next()
            java.lang.String r6 = (java.lang.String) r6
            if (r3 != 0) goto L_0x0324
            r13.append(r4)
        L_0x0324:
            r13.append(r5)
            r13.append(r6)
            r13.append(r5)
            java.lang.String r3 = ":"
            r13.append(r3)
            r13.append(r5)
            java.lang.String r3 = r1.getString(r6)
            java.lang.String r3 = b.c.a.b.d.r.e.a(r3)
            r13.append(r3)
            r13.append(r5)
            r3 = 0
            goto L_0x0313
        L_0x0345:
            java.lang.String r1 = "}"
        L_0x0347:
            r13.append(r1)
            goto L_0x03a9
        L_0x034b:
            byte[] r1 = b.a.b.w.e.d((android.os.Parcel) r15, (int) r2)
            r13.append(r5)
            java.lang.String r1 = b.c.a.b.d.n.u.d.b((byte[]) r1)
            goto L_0x036e
        L_0x0357:
            byte[] r1 = b.a.b.w.e.d((android.os.Parcel) r15, (int) r2)
            r13.append(r5)
            java.lang.String r1 = b.c.a.b.d.n.u.d.a((byte[]) r1)
            goto L_0x036e
        L_0x0363:
            java.lang.String r1 = b.a.b.w.e.h((android.os.Parcel) r15, (int) r2)
            r13.append(r5)
            java.lang.String r1 = b.c.a.b.d.r.e.a(r1)
        L_0x036e:
            r13.append(r1)
            r13.append(r5)
            goto L_0x03a9
        L_0x0375:
            boolean r1 = b.a.b.w.e.l(r15, r2)
            r13.append(r1)
            goto L_0x03a9
        L_0x037d:
            java.math.BigDecimal r1 = b.a.b.w.e.a((android.os.Parcel) r15, (int) r2)
            goto L_0x039e
        L_0x0382:
            double r1 = b.a.b.w.e.n(r15, r2)
            r13.append(r1)
            goto L_0x03a9
        L_0x038a:
            float r1 = b.a.b.w.e.o(r15, r2)
            r13.append(r1)
            goto L_0x03a9
        L_0x0392:
            long r1 = b.a.b.w.e.s(r15, r2)
            r13.append(r1)
            goto L_0x03a9
        L_0x039a:
            java.math.BigInteger r1 = b.a.b.w.e.b((android.os.Parcel) r15, (int) r2)
        L_0x039e:
            r13.append(r1)
            goto L_0x03a9
        L_0x03a2:
            int r1 = b.a.b.w.e.q(r15, r2)
            r13.append(r1)
        L_0x03a9:
            r1 = 1
            goto L_0x002f
        L_0x03ac:
            int r0 = r15.dataPosition()
            if (r0 != r14) goto L_0x03b8
            r14 = 125(0x7d, float:1.75E-43)
            r13.append(r14)
            return
        L_0x03b8:
            b.c.a.b.d.n.u.c r13 = new b.c.a.b.d.n.u.c
            r0 = 37
            java.lang.String r1 = "Overread allowed size end="
            java.lang.String r14 = b.a.a.a.a.a((int) r0, (java.lang.String) r1, (int) r14)
            r13.<init>(r14, r15)
            goto L_0x03c7
        L_0x03c6:
            throw r13
        L_0x03c7:
            goto L_0x03c6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.server.response.SafeParcelResponse.a(java.lang.StringBuilder, java.util.Map, android.os.Parcel):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0005, code lost:
        if (r0 != 1) goto L_0x001a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.os.Parcel b() {
        /*
            r2 = this;
            int r0 = r2.f6333f
            if (r0 == 0) goto L_0x0008
            r1 = 1
            if (r0 == r1) goto L_0x0010
            goto L_0x001a
        L_0x0008:
            android.os.Parcel r0 = r2.f6329b
            int r0 = b.c.a.b.d.n.u.d.a((android.os.Parcel) r0)
            r2.f6334g = r0
        L_0x0010:
            android.os.Parcel r0 = r2.f6329b
            int r1 = r2.f6334g
            b.c.a.b.d.n.u.d.b((android.os.Parcel) r0, (int) r1)
            r0 = 2
            r2.f6333f = r0
        L_0x001a:
            android.os.Parcel r0 = r2.f6329b
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.server.response.SafeParcelResponse.b():android.os.Parcel");
    }

    public String toString() {
        b.a.b.w.e.b(this.f6331d, (Object) "Cannot convert to JSON on client side.");
        Parcel b2 = b();
        b2.setDataPosition(0);
        StringBuilder sb = new StringBuilder(100);
        a(sb, this.f6331d.b(this.f6332e), b2);
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zaj zaj;
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6328a);
        Parcel b2 = b();
        if (b2 != null) {
            int a3 = d.a(parcel, 2);
            parcel.appendFrom(b2, 0, b2.dataSize());
            d.b(parcel, a3);
        }
        int i2 = this.f6330c;
        if (i2 == 0) {
            zaj = null;
        } else if (i2 == 1 || i2 == 2) {
            zaj = this.f6331d;
        } else {
            throw new IllegalStateException(a.a(34, "Invalid creation type: ", this.f6330c));
        }
        d.a(parcel, 3, (Parcelable) zaj, i, false);
        d.b(parcel, a2);
    }
}
