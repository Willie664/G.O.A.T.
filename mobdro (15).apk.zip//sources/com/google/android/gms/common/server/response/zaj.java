package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import b.a.b.w.e;
import b.c.a.b.d.p.b.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class zaj extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zaj> CREATOR = new d();

    /* renamed from: a  reason: collision with root package name */
    public final int f6335a;

    /* renamed from: b  reason: collision with root package name */
    public final HashMap<String, Map<String, FastJsonResponse.Field<?, ?>>> f6336b;

    /* renamed from: c  reason: collision with root package name */
    public final String f6337c;

    public zaj(int i, ArrayList<zam> arrayList, String str) {
        this.f6335a = i;
        HashMap<String, Map<String, FastJsonResponse.Field<?, ?>>> hashMap = new HashMap<>();
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            zam zam = arrayList.get(i2);
            String str2 = zam.f6342b;
            HashMap hashMap2 = new HashMap();
            int size2 = zam.f6343c.size();
            for (int i3 = 0; i3 < size2; i3++) {
                zal zal = zam.f6343c.get(i3);
                hashMap2.put(zal.f6339b, zal.f6340c);
            }
            hashMap.put(str2, hashMap2);
        }
        this.f6336b = hashMap;
        e.b(str);
        this.f6337c = str;
        for (String str3 : this.f6336b.keySet()) {
            Map map = this.f6336b.get(str3);
            for (String str4 : map.keySet()) {
                ((FastJsonResponse.Field) map.get(str4)).j = this;
            }
        }
    }

    public final Map<String, FastJsonResponse.Field<?, ?>> b(String str) {
        return this.f6336b.get(str);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        for (String next : this.f6336b.keySet()) {
            sb.append(next);
            sb.append(":\n");
            Map map = this.f6336b.get(next);
            for (String str : map.keySet()) {
                sb.append("  ");
                sb.append(str);
                sb.append(": ");
                sb.append(map.get(str));
            }
        }
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.c.a.b.d.n.u.d.a(parcel);
        b.c.a.b.d.n.u.d.a(parcel, 1, this.f6335a);
        ArrayList arrayList = new ArrayList();
        for (String next : this.f6336b.keySet()) {
            arrayList.add(new zam(next, this.f6336b.get(next)));
        }
        b.c.a.b.d.n.u.d.b(parcel, 2, arrayList, false);
        b.c.a.b.d.n.u.d.a(parcel, 3, this.f6337c, false);
        b.c.a.b.d.n.u.d.b(parcel, a2);
    }
}
