package com.google.android.gms.common.data;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import b.c.a.b.d.l.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.nio.ByteBuffer;

public class BitmapTeleporter extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<BitmapTeleporter> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final int f6260a;

    /* renamed from: b  reason: collision with root package name */
    public ParcelFileDescriptor f6261b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6262c;

    /* renamed from: d  reason: collision with root package name */
    public Bitmap f6263d = null;

    public BitmapTeleporter(int i, ParcelFileDescriptor parcelFileDescriptor, int i2) {
        this.f6260a = i;
        this.f6261b = parcelFileDescriptor;
        this.f6262c = i2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (this.f6261b != null) {
            int a2 = d.a(parcel);
            d.a(parcel, 1, this.f6260a);
            d.a(parcel, 2, (Parcelable) this.f6261b, i | 1, false);
            d.a(parcel, 3, this.f6262c);
            d.b(parcel, a2);
            this.f6261b = null;
            return;
        }
        Bitmap bitmap = this.f6263d;
        ByteBuffer allocate = ByteBuffer.allocate(bitmap.getHeight() * bitmap.getRowBytes());
        bitmap.copyPixelsToBuffer(allocate);
        allocate.array();
        throw new IllegalStateException("setTempDir() must be called before writing this object to a parcel");
    }
}
