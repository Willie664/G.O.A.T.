package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.e0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInButtonConfig extends AbstractSafeParcelable {
    public static final Parcelable.Creator<SignInButtonConfig> CREATOR = new e0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6302a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6303b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6304c;
    @Deprecated

    /* renamed from: d  reason: collision with root package name */
    public final Scope[] f6305d;

    public SignInButtonConfig(int i, int i2) {
        this.f6302a = 1;
        this.f6303b = i;
        this.f6304c = i2;
        this.f6305d = null;
    }

    public SignInButtonConfig(int i, int i2, int i3, Scope[] scopeArr) {
        this.f6302a = i;
        this.f6303b = i2;
        this.f6304c = i3;
        this.f6305d = scopeArr;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6302a);
        d.a(parcel, 2, this.f6303b);
        d.a(parcel, 3, this.f6304c);
        d.a(parcel, 4, (T[]) this.f6305d, i, false);
        d.b(parcel, a2);
    }
}
