package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import b.a.b.w.e;
import b.c.a.b.d.n.q;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.converter.StringToIntConverter;
import com.google.android.gms.common.server.converter.zab;
import java.util.Iterator;
import java.util.Map;

public abstract class FastJsonResponse {

    public static class Field<I, O> extends AbstractSafeParcelable {
        public static final b.c.a.b.d.p.b.a CREATOR = new b.c.a.b.d.p.b.a();

        /* renamed from: a  reason: collision with root package name */
        public final int f6321a;

        /* renamed from: b  reason: collision with root package name */
        public final int f6322b;

        /* renamed from: c  reason: collision with root package name */
        public final boolean f6323c;

        /* renamed from: d  reason: collision with root package name */
        public final int f6324d;

        /* renamed from: e  reason: collision with root package name */
        public final boolean f6325e;

        /* renamed from: f  reason: collision with root package name */
        public final String f6326f;

        /* renamed from: g  reason: collision with root package name */
        public final int f6327g;
        public final Class<? extends FastJsonResponse> h;
        public final String i;
        public zaj j;
        public a<I, O> k;

        public Field(int i2, int i3, boolean z, int i4, boolean z2, String str, int i5, String str2, zab zab) {
            this.f6321a = i2;
            this.f6322b = i3;
            this.f6323c = z;
            this.f6324d = i4;
            this.f6325e = z2;
            this.f6326f = str;
            this.f6327g = i5;
            if (str2 == null) {
                this.h = null;
                this.i = null;
            } else {
                this.h = SafeParcelResponse.class;
                this.i = str2;
            }
            if (zab == null) {
                this.k = null;
                return;
            }
            StringToIntConverter stringToIntConverter = zab.f6320b;
            if (stringToIntConverter != null) {
                this.k = stringToIntConverter;
                return;
            }
            throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
        }

        public String toString() {
            q c2 = e.c((Object) this);
            c2.a("versionCode", Integer.valueOf(this.f6321a));
            c2.a("typeIn", Integer.valueOf(this.f6322b));
            c2.a("typeInArray", Boolean.valueOf(this.f6323c));
            c2.a("typeOut", Integer.valueOf(this.f6324d));
            c2.a("typeOutArray", Boolean.valueOf(this.f6325e));
            c2.a("outputFieldName", this.f6326f);
            c2.a("safeParcelFieldId", Integer.valueOf(this.f6327g));
            String str = this.i;
            if (str == null) {
                str = null;
            }
            c2.a("concreteTypeName", str);
            Class<? extends FastJsonResponse> cls = this.h;
            if (cls != null) {
                c2.a("concreteType.class", cls.getCanonicalName());
            }
            a<I, O> aVar = this.k;
            if (aVar != null) {
                c2.a("converterName", aVar.getClass().getCanonicalName());
            }
            return c2.toString();
        }

        public void writeToParcel(Parcel parcel, int i2) {
            int a2 = d.a(parcel);
            d.a(parcel, 1, this.f6321a);
            d.a(parcel, 2, this.f6322b);
            d.a(parcel, 3, this.f6323c);
            d.a(parcel, 4, this.f6324d);
            d.a(parcel, 5, this.f6325e);
            d.a(parcel, 6, this.f6326f, false);
            d.a(parcel, 7, this.f6327g);
            String str = this.i;
            zab zab = null;
            if (str == null) {
                str = null;
            }
            d.a(parcel, 8, str, false);
            a<I, O> aVar = this.k;
            if (aVar != null) {
                zab = zab.a(aVar);
            }
            d.a(parcel, 9, (Parcelable) zab, i2, false);
            d.b(parcel, a2);
        }
    }

    public interface a<I, O> {
        I a(O o);
    }

    public abstract Map<String, Field<?, ?>> a();

    public boolean a(Field field) {
        if (field.f6324d != 11) {
            throw new UnsupportedOperationException("Converting to JSON does not require this method.");
        } else if (field.f6325e) {
            throw new UnsupportedOperationException("Concrete type arrays not supported");
        } else {
            throw new UnsupportedOperationException("Concrete types not supported");
        }
    }

    public String toString() {
        Map<String, Field<?, ?>> a2 = a();
        StringBuilder sb = new StringBuilder(100);
        Iterator<String> it = a2.keySet().iterator();
        if (!it.hasNext()) {
            sb.append(sb.length() > 0 ? "}" : "{}");
            return sb.toString();
        }
        a(a2.get(it.next()));
        throw null;
    }
}
