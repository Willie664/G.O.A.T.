package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import b.a.b.w.e;
import b.c.a.b.d.k.o;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Scope extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<Scope> CREATOR = new o();

    /* renamed from: a  reason: collision with root package name */
    public final int f6250a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6251b;

    public Scope(int i, String str) {
        e.a(str, (Object) "scopeUri must not be null or empty");
        this.f6250a = i;
        this.f6251b = str;
    }

    public Scope(String str) {
        e.a(str, (Object) "scopeUri must not be null or empty");
        this.f6250a = 1;
        this.f6251b = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Scope)) {
            return false;
        }
        return this.f6251b.equals(((Scope) obj).f6251b);
    }

    public final int hashCode() {
        return this.f6251b.hashCode();
    }

    public final String toString() {
        return this.f6251b;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6250a);
        d.a(parcel, 2, this.f6251b, false);
        d.b(parcel, a2);
    }
}
