package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.a.a.a.a;
import b.a.b.w.e;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.n.w;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ClientIdentity extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ClientIdentity> CREATOR = new w();

    /* renamed from: a  reason: collision with root package name */
    public final int f6284a;
    @Nullable

    /* renamed from: b  reason: collision with root package name */
    public final String f6285b;

    public ClientIdentity(int i, @Nullable String str) {
        this.f6284a = i;
        this.f6285b = str;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj != null && (obj instanceof ClientIdentity)) {
            ClientIdentity clientIdentity = (ClientIdentity) obj;
            return clientIdentity.f6284a == this.f6284a && e.c((Object) clientIdentity.f6285b, (Object) this.f6285b);
        }
    }

    public int hashCode() {
        return this.f6284a;
    }

    public String toString() {
        int i = this.f6284a;
        String str = this.f6285b;
        StringBuilder sb = new StringBuilder(a.a(str, 12));
        sb.append(i);
        sb.append(":");
        sb.append(str);
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6284a);
        d.a(parcel, 2, this.f6285b, false);
        d.b(parcel, a2);
    }
}
