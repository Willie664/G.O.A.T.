package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.n.v;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<AuthAccountRequest> CREATOR = new v();

    /* renamed from: a  reason: collision with root package name */
    public final int f6277a;
    @Deprecated

    /* renamed from: b  reason: collision with root package name */
    public final IBinder f6278b;

    /* renamed from: c  reason: collision with root package name */
    public final Scope[] f6279c;

    /* renamed from: d  reason: collision with root package name */
    public Integer f6280d;

    /* renamed from: e  reason: collision with root package name */
    public Integer f6281e;

    /* renamed from: f  reason: collision with root package name */
    public Account f6282f;

    public AuthAccountRequest(int i, IBinder iBinder, Scope[] scopeArr, Integer num, Integer num2, Account account) {
        this.f6277a = i;
        this.f6278b = iBinder;
        this.f6279c = scopeArr;
        this.f6280d = num;
        this.f6281e = num2;
        this.f6282f = account;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6277a);
        d.a(parcel, 2, this.f6278b, false);
        d.a(parcel, 3, (T[]) this.f6279c, i, false);
        d.a(parcel, 4, this.f6280d, false);
        d.a(parcel, 5, this.f6281e, false);
        d.a(parcel, 6, (Parcelable) this.f6282f, i, false);
        d.b(parcel, a2);
    }
}
