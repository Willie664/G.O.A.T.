package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.a.b.w.e;
import b.c.a.b.d.k.h;
import b.c.a.b.d.k.p;
import b.c.a.b.d.n.q;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class Status extends AbstractSafeParcelable implements h, ReflectedParcelable {
    public static final Parcelable.Creator<Status> CREATOR = new p();

    /* renamed from: e  reason: collision with root package name */
    public static final Status f6252e = new Status(0);

    /* renamed from: f  reason: collision with root package name */
    public static final Status f6253f = new Status(14);

    /* renamed from: g  reason: collision with root package name */
    public static final Status f6254g = new Status(8);
    public static final Status h = new Status(15);
    public static final Status i = new Status(16);

    /* renamed from: a  reason: collision with root package name */
    public final int f6255a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6256b;
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public final String f6257c;
    @Nullable

    /* renamed from: d  reason: collision with root package name */
    public final PendingIntent f6258d;

    static {
        new Status(17);
        new Status(18);
    }

    public Status(int i2) {
        this(1, i2, (String) null, (PendingIntent) null);
    }

    public Status(int i2, int i3, @Nullable String str, @Nullable PendingIntent pendingIntent) {
        this.f6255a = i2;
        this.f6256b = i3;
        this.f6257c = str;
        this.f6258d = pendingIntent;
    }

    public Status(int i2, @Nullable String str) {
        this(1, i2, str, (PendingIntent) null);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f6255a == status.f6255a && this.f6256b == status.f6256b && e.c((Object) this.f6257c, (Object) status.f6257c) && e.c((Object) this.f6258d, (Object) status.f6258d);
    }

    public final Status getStatus() {
        return this;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6255a), Integer.valueOf(this.f6256b), this.f6257c, this.f6258d});
    }

    public final boolean p() {
        return this.f6256b <= 0;
    }

    public final String toString() {
        q c2 = e.c((Object) this);
        String str = this.f6257c;
        if (str == null) {
            str = e.b(this.f6256b);
        }
        c2.a("statusCode", str);
        c2.a("resolution", this.f6258d);
        return c2.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6256b);
        d.a(parcel, 2, this.f6257c, false);
        d.a(parcel, 3, (Parcelable) this.f6258d, i2, false);
        d.a(parcel, 1000, this.f6255a);
        d.b(parcel, a2);
    }
}
