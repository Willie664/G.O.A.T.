package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.c0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ResolveAccountRequest> CREATOR = new c0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6293a;

    /* renamed from: b  reason: collision with root package name */
    public final Account f6294b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6295c;

    /* renamed from: d  reason: collision with root package name */
    public final GoogleSignInAccount f6296d;

    public ResolveAccountRequest(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f6293a = i;
        this.f6294b = account;
        this.f6295c = i2;
        this.f6296d = googleSignInAccount;
    }

    public ResolveAccountRequest(Account account, int i, GoogleSignInAccount googleSignInAccount) {
        this.f6293a = 2;
        this.f6294b = account;
        this.f6295c = i;
        this.f6296d = googleSignInAccount;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6293a);
        d.a(parcel, 2, (Parcelable) this.f6294b, i, false);
        d.a(parcel, 3, this.f6295c);
        d.a(parcel, 4, (Parcelable) this.f6296d, i, false);
        d.b(parcel, a2);
    }
}
