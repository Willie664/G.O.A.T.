package com.google.android.gms.common.server;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.p.c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class FavaDiagnosticsEntity extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<FavaDiagnosticsEntity> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    public final int f6310a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6311b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6312c;

    public FavaDiagnosticsEntity(int i, String str, int i2) {
        this.f6310a = i;
        this.f6311b = str;
        this.f6312c = i2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6310a);
        d.a(parcel, 2, this.f6311b, false);
        d.a(parcel, 3, this.f6312c);
        d.b(parcel, a2);
    }
}
