package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.p.b.b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;

public final class zal extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zal> CREATOR = new b();

    /* renamed from: a  reason: collision with root package name */
    public final int f6338a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6339b;

    /* renamed from: c  reason: collision with root package name */
    public final FastJsonResponse.Field<?, ?> f6340c;

    public zal(int i, String str, FastJsonResponse.Field<?, ?> field) {
        this.f6338a = i;
        this.f6339b = str;
        this.f6340c = field;
    }

    public zal(String str, FastJsonResponse.Field<?, ?> field) {
        this.f6338a = 1;
        this.f6339b = str;
        this.f6340c = field;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6338a);
        d.a(parcel, 2, this.f6339b, false);
        d.a(parcel, 3, (Parcelable) this.f6340c, i, false);
        d.b(parcel, a2);
    }
}
