package com.google.android.gms.common;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import b.c.a.b.d.e0;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.w;
import b.c.a.b.d.z;
import b.c.a.b.e.a;
import b.c.a.b.e.b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import javax.annotation.Nullable;

public final class zzj extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzj> CREATOR = new e0();

    /* renamed from: a  reason: collision with root package name */
    public final String f6351a;
    @Nullable

    /* renamed from: b  reason: collision with root package name */
    public final w f6352b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f6353c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f6354d;

    public zzj(String str, @Nullable IBinder iBinder, boolean z, boolean z2) {
        this.f6351a = str;
        z zVar = null;
        if (iBinder != null) {
            try {
                a zzb = w.a(iBinder).zzb();
                byte[] bArr = zzb == null ? null : (byte[]) b.a(zzb);
                if (bArr != null) {
                    zVar = new z(bArr);
                }
            } catch (RemoteException unused) {
            }
        }
        this.f6352b = zVar;
        this.f6353c = z;
        this.f6354d = z2;
    }

    public zzj(String str, @Nullable w wVar, boolean z, boolean z2) {
        this.f6351a = str;
        this.f6352b = wVar;
        this.f6353c = z;
        this.f6354d = z2;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6351a, false);
        w wVar = this.f6352b;
        d.a(parcel, 2, wVar == null ? null : wVar.asBinder(), false);
        d.a(parcel, 3, this.f6353c);
        d.a(parcel, 4, this.f6354d);
        d.b(parcel, a2);
    }
}
