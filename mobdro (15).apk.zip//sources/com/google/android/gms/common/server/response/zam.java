package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.p.b.c;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;
import java.util.ArrayList;
import java.util.Map;

public final class zam extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zam> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    public final int f6341a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6342b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList<zal> f6343c;

    public zam(int i, String str, ArrayList<zal> arrayList) {
        this.f6341a = i;
        this.f6342b = str;
        this.f6343c = arrayList;
    }

    public zam(String str, Map<String, FastJsonResponse.Field<?, ?>> map) {
        ArrayList<zal> arrayList;
        this.f6341a = 1;
        this.f6342b = str;
        if (map == null) {
            arrayList = null;
        } else {
            arrayList = new ArrayList<>();
            for (String next : map.keySet()) {
                arrayList.add(new zal(next, map.get(next)));
            }
        }
        this.f6343c = arrayList;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6341a);
        d.a(parcel, 2, this.f6342b, false);
        d.b(parcel, 3, this.f6343c, false);
        d.b(parcel, a2);
    }
}
