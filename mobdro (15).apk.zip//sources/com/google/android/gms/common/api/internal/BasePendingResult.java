package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.NonNull;
import b.c.a.b.d.k.d;
import b.c.a.b.d.k.e;
import b.c.a.b.d.k.f;
import b.c.a.b.d.k.h;
import b.c.a.b.d.k.i;
import b.c.a.b.d.k.l;
import b.c.a.b.d.k.n.c1;
import b.c.a.b.d.k.n.r0;
import b.c.a.b.d.k.n.u0;
import b.c.a.b.d.n.k;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.base.zar;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@KeepName
public abstract class BasePendingResult<R extends h> extends e<R> {
    public static final ThreadLocal<Boolean> zado = new c1();
    @KeepName
    public b mResultGuardian;
    public Status mStatus;
    public R zacl;
    public final Object zadp;
    public final a<R> zadq;
    public final WeakReference<d> zadr;
    public final CountDownLatch zads;
    public final ArrayList<e.a> zadt;
    public i<? super R> zadu;
    public final AtomicReference<u0> zadv;
    public volatile boolean zadw;
    public boolean zadx;
    public boolean zady;
    public k zadz;
    public volatile r0<R> zaea;
    public boolean zaeb;

    public static class a<R extends h> extends zar {
        public a() {
            super(Looper.getMainLooper());
        }

        public a(Looper looper) {
            super(looper);
        }

        public final void a(i<? super R> iVar, R r) {
            sendMessage(obtainMessage(1, new Pair(BasePendingResult.zaa(iVar), r)));
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i == 1) {
                Pair pair = (Pair) message.obj;
                i iVar = (i) pair.first;
                h hVar = (h) pair.second;
                try {
                    iVar.onResult(hVar);
                } catch (RuntimeException e2) {
                    BasePendingResult.zab(hVar);
                    throw e2;
                }
            } else if (i != 2) {
                Log.wtf("BasePendingResult", b.a.a.a.a.a(45, "Don't know how to handle message: ", i), new Exception());
            } else {
                ((BasePendingResult) message.obj).zab(Status.h);
            }
        }
    }

    public final class b {
        public /* synthetic */ b(c1 c1Var) {
        }

        public final void finalize() throws Throwable {
            BasePendingResult.zab(BasePendingResult.this.zacl);
            super.finalize();
        }
    }

    @Deprecated
    public BasePendingResult() {
        this.zadp = new Object();
        this.zads = new CountDownLatch(1);
        this.zadt = new ArrayList<>();
        this.zadv = new AtomicReference<>();
        this.zaeb = false;
        this.zadq = new a<>(Looper.getMainLooper());
        this.zadr = new WeakReference<>((Object) null);
    }

    @Deprecated
    public BasePendingResult(Looper looper) {
        this.zadp = new Object();
        this.zads = new CountDownLatch(1);
        this.zadt = new ArrayList<>();
        this.zadv = new AtomicReference<>();
        this.zaeb = false;
        this.zadq = new a<>(looper);
        this.zadr = new WeakReference<>((Object) null);
    }

    public BasePendingResult(d dVar) {
        this.zadp = new Object();
        this.zads = new CountDownLatch(1);
        this.zadt = new ArrayList<>();
        this.zadv = new AtomicReference<>();
        this.zaeb = false;
        this.zadq = new a<>(dVar != null ? dVar.a() : Looper.getMainLooper());
        this.zadr = new WeakReference<>(dVar);
    }

    public BasePendingResult(@NonNull a<R> aVar) {
        this.zadp = new Object();
        this.zads = new CountDownLatch(1);
        this.zadt = new ArrayList<>();
        this.zadv = new AtomicReference<>();
        this.zaeb = false;
        b.a.b.w.e.b(aVar, (Object) "CallbackHandler must not be null");
        this.zadq = aVar;
        this.zadr = new WeakReference<>((Object) null);
    }

    private final R get() {
        R r;
        synchronized (this.zadp) {
            b.a.b.w.e.b(!this.zadw, (Object) "Result has already been consumed.");
            b.a.b.w.e.b(isReady(), (Object) "Result is not ready.");
            r = this.zacl;
            this.zacl = null;
            this.zadu = null;
            this.zadw = true;
        }
        u0 andSet = this.zadv.getAndSet((Object) null);
        if (andSet != null) {
            andSet.a(this);
        }
        return r;
    }

    public static <R extends h> i<R> zaa(i<R> iVar) {
        return iVar;
    }

    private final void zaa(R r) {
        this.zacl = r;
        this.zadz = null;
        this.zads.countDown();
        this.mStatus = this.zacl.getStatus();
        if (this.zadx) {
            this.zadu = null;
        } else if (this.zadu != null) {
            this.zadq.removeMessages(2);
            this.zadq.a(this.zadu, get());
        } else if (this.zacl instanceof f) {
            this.mResultGuardian = new b((c1) null);
        }
        ArrayList<e.a> arrayList = this.zadt;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            e.a aVar = arrayList.get(i);
            i++;
            aVar.a(this.mStatus);
        }
        this.zadt.clear();
    }

    public static void zab(h hVar) {
        if (hVar instanceof f) {
            try {
                ((f) hVar).release();
            } catch (RuntimeException unused) {
                String.valueOf(hVar).length();
            }
        }
    }

    public final void addStatusListener(e.a aVar) {
        b.a.b.w.e.a(aVar != null, (Object) "Callback cannot be null.");
        synchronized (this.zadp) {
            if (isReady()) {
                aVar.a(this.mStatus);
            } else {
                this.zadt.add(aVar);
            }
        }
    }

    public final R await() {
        b.a.b.w.e.e("await must not be called on the UI thread");
        boolean z = true;
        b.a.b.w.e.b(!this.zadw, (Object) "Result has already been consumed");
        if (this.zaea != null) {
            z = false;
        }
        b.a.b.w.e.b(z, (Object) "Cannot await if then() has been called.");
        try {
            this.zads.await();
        } catch (InterruptedException unused) {
            zab(Status.f6253f);
        }
        b.a.b.w.e.b(isReady(), (Object) "Result is not ready.");
        return get();
    }

    public final R await(long j, TimeUnit timeUnit) {
        if (j > 0) {
            b.a.b.w.e.e("await must not be called on the UI thread when time is greater than zero.");
        }
        boolean z = true;
        b.a.b.w.e.b(!this.zadw, (Object) "Result has already been consumed.");
        if (this.zaea != null) {
            z = false;
        }
        b.a.b.w.e.b(z, (Object) "Cannot await if then() has been called.");
        try {
            if (!this.zads.await(j, timeUnit)) {
                zab(Status.h);
            }
        } catch (InterruptedException unused) {
            zab(Status.f6253f);
        }
        b.a.b.w.e.b(isReady(), (Object) "Result is not ready.");
        return get();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:8|(2:10|11)|12|13|14|15) */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0029, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x0015 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void cancel() {
        /*
            r2 = this;
            java.lang.Object r0 = r2.zadp
            monitor-enter(r0)
            boolean r1 = r2.zadx     // Catch:{ all -> 0x002a }
            if (r1 != 0) goto L_0x0028
            boolean r1 = r2.zadw     // Catch:{ all -> 0x002a }
            if (r1 == 0) goto L_0x000c
            goto L_0x0028
        L_0x000c:
            b.c.a.b.d.n.k r1 = r2.zadz     // Catch:{ all -> 0x002a }
            if (r1 == 0) goto L_0x0015
            b.c.a.b.d.n.k r1 = r2.zadz     // Catch:{ RemoteException -> 0x0015 }
            r1.cancel()     // Catch:{ RemoteException -> 0x0015 }
        L_0x0015:
            R r1 = r2.zacl     // Catch:{ all -> 0x002a }
            zab((b.c.a.b.d.k.h) r1)     // Catch:{ all -> 0x002a }
            r1 = 1
            r2.zadx = r1     // Catch:{ all -> 0x002a }
            com.google.android.gms.common.api.Status r1 = com.google.android.gms.common.api.Status.i     // Catch:{ all -> 0x002a }
            b.c.a.b.d.k.h r1 = r2.createFailedResult(r1)     // Catch:{ all -> 0x002a }
            r2.zaa(r1)     // Catch:{ all -> 0x002a }
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            return
        L_0x0028:
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            return
        L_0x002a:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x002a }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.BasePendingResult.cancel():void");
    }

    @NonNull
    public abstract R createFailedResult(Status status);

    public boolean isCanceled() {
        boolean z;
        synchronized (this.zadp) {
            z = this.zadx;
        }
        return z;
    }

    public final boolean isReady() {
        return this.zads.getCount() == 0;
    }

    public final void setCancelToken(k kVar) {
        synchronized (this.zadp) {
            this.zadz = kVar;
        }
    }

    public final void setResult(R r) {
        synchronized (this.zadp) {
            if (this.zady || this.zadx) {
                zab((h) r);
                return;
            }
            isReady();
            boolean z = true;
            b.a.b.w.e.b(!isReady(), (Object) "Results have already been set");
            if (this.zadw) {
                z = false;
            }
            b.a.b.w.e.b(z, (Object) "Result has already been consumed");
            zaa(r);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x003e, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setResultCallback(b.c.a.b.d.k.i<? super R> r6) {
        /*
            r5 = this;
            java.lang.Object r0 = r5.zadp
            monitor-enter(r0)
            if (r6 != 0) goto L_0x000a
            r6 = 0
            r5.zadu = r6     // Catch:{ all -> 0x003f }
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x000a:
            boolean r1 = r5.zadw     // Catch:{ all -> 0x003f }
            r2 = 1
            r3 = 0
            if (r1 != 0) goto L_0x0012
            r1 = 1
            goto L_0x0013
        L_0x0012:
            r1 = 0
        L_0x0013:
            java.lang.String r4 = "Result has already been consumed."
            b.a.b.w.e.b((boolean) r1, (java.lang.Object) r4)     // Catch:{ all -> 0x003f }
            b.c.a.b.d.k.n.r0<R> r1 = r5.zaea     // Catch:{ all -> 0x003f }
            if (r1 != 0) goto L_0x001d
            goto L_0x001e
        L_0x001d:
            r2 = 0
        L_0x001e:
            java.lang.String r1 = "Cannot set callbacks if then() has been called."
            b.a.b.w.e.b((boolean) r2, (java.lang.Object) r1)     // Catch:{ all -> 0x003f }
            boolean r1 = r5.isCanceled()     // Catch:{ all -> 0x003f }
            if (r1 == 0) goto L_0x002b
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x002b:
            boolean r1 = r5.isReady()     // Catch:{ all -> 0x003f }
            if (r1 == 0) goto L_0x003b
            com.google.android.gms.common.api.internal.BasePendingResult$a<R> r1 = r5.zadq     // Catch:{ all -> 0x003f }
            b.c.a.b.d.k.h r2 = r5.get()     // Catch:{ all -> 0x003f }
            r1.a(r6, r2)     // Catch:{ all -> 0x003f }
            goto L_0x003d
        L_0x003b:
            r5.zadu = r6     // Catch:{ all -> 0x003f }
        L_0x003d:
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            return
        L_0x003f:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x003f }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.BasePendingResult.setResultCallback(b.c.a.b.d.k.i):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x004c, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setResultCallback(b.c.a.b.d.k.i<? super R> r6, long r7, java.util.concurrent.TimeUnit r9) {
        /*
            r5 = this;
            java.lang.Object r0 = r5.zadp
            monitor-enter(r0)
            if (r6 != 0) goto L_0x000a
            r6 = 0
            r5.zadu = r6     // Catch:{ all -> 0x004d }
            monitor-exit(r0)     // Catch:{ all -> 0x004d }
            return
        L_0x000a:
            boolean r1 = r5.zadw     // Catch:{ all -> 0x004d }
            r2 = 1
            r3 = 0
            if (r1 != 0) goto L_0x0012
            r1 = 1
            goto L_0x0013
        L_0x0012:
            r1 = 0
        L_0x0013:
            java.lang.String r4 = "Result has already been consumed."
            b.a.b.w.e.b((boolean) r1, (java.lang.Object) r4)     // Catch:{ all -> 0x004d }
            b.c.a.b.d.k.n.r0<R> r1 = r5.zaea     // Catch:{ all -> 0x004d }
            if (r1 != 0) goto L_0x001d
            goto L_0x001e
        L_0x001d:
            r2 = 0
        L_0x001e:
            java.lang.String r1 = "Cannot set callbacks if then() has been called."
            b.a.b.w.e.b((boolean) r2, (java.lang.Object) r1)     // Catch:{ all -> 0x004d }
            boolean r1 = r5.isCanceled()     // Catch:{ all -> 0x004d }
            if (r1 == 0) goto L_0x002b
            monitor-exit(r0)     // Catch:{ all -> 0x004d }
            return
        L_0x002b:
            boolean r1 = r5.isReady()     // Catch:{ all -> 0x004d }
            if (r1 == 0) goto L_0x003b
            com.google.android.gms.common.api.internal.BasePendingResult$a<R> r7 = r5.zadq     // Catch:{ all -> 0x004d }
            b.c.a.b.d.k.h r8 = r5.get()     // Catch:{ all -> 0x004d }
            r7.a(r6, r8)     // Catch:{ all -> 0x004d }
            goto L_0x004b
        L_0x003b:
            r5.zadu = r6     // Catch:{ all -> 0x004d }
            com.google.android.gms.common.api.internal.BasePendingResult$a<R> r6 = r5.zadq     // Catch:{ all -> 0x004d }
            long r7 = r9.toMillis(r7)     // Catch:{ all -> 0x004d }
            r9 = 2
            android.os.Message r9 = r6.obtainMessage(r9, r5)     // Catch:{ all -> 0x004d }
            r6.sendMessageDelayed(r9, r7)     // Catch:{ all -> 0x004d }
        L_0x004b:
            monitor-exit(r0)     // Catch:{ all -> 0x004d }
            return
        L_0x004d:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x004d }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.api.internal.BasePendingResult.setResultCallback(b.c.a.b.d.k.i, long, java.util.concurrent.TimeUnit):void");
    }

    public <S extends h> l<S> then(b.c.a.b.d.k.k<? super R, ? extends S> kVar) {
        l<S> a2;
        b.a.b.w.e.b(!this.zadw, (Object) "Result has already been consumed.");
        synchronized (this.zadp) {
            boolean z = false;
            b.a.b.w.e.b(this.zaea == null, (Object) "Cannot call then() twice.");
            b.a.b.w.e.b(this.zadu == null, (Object) "Cannot call then() if callbacks are set.");
            if (!this.zadx) {
                z = true;
            }
            b.a.b.w.e.b(z, (Object) "Cannot call then() if result was canceled.");
            this.zaeb = true;
            this.zaea = new r0<>(this.zadr);
            a2 = this.zaea.a(kVar);
            if (isReady()) {
                this.zadq.a(this.zaea, get());
            } else {
                this.zadu = this.zaea;
            }
        }
        return a2;
    }

    public final void zaa(u0 u0Var) {
        this.zadv.set(u0Var);
    }

    public final void zab(Status status) {
        synchronized (this.zadp) {
            if (!isReady()) {
                setResult(createFailedResult(status));
                this.zady = true;
            }
        }
    }

    public final Integer zal() {
        return null;
    }

    public final boolean zaq() {
        boolean isCanceled;
        synchronized (this.zadp) {
            if (((d) this.zadr.get()) == null || !this.zaeb) {
                cancel();
            }
            isCanceled = isCanceled();
        }
        return isCanceled;
    }

    public final void zar() {
        this.zaeb = this.zaeb || zado.get().booleanValue();
    }
}
