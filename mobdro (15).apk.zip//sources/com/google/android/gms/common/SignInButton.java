package com.google.android.gms.common;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import b.c.a.b.b.d;
import com.google.android.gms.common.api.Scope;

public final class SignInButton extends FrameLayout implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public int f6245a;

    /* renamed from: b  reason: collision with root package name */
    public int f6246b;

    /* renamed from: c  reason: collision with root package name */
    public View f6247c;

    /* renamed from: d  reason: collision with root package name */
    public View.OnClickListener f6248d;

    public SignInButton(Context context) {
        this(context, (AttributeSet) null);
    }

    public SignInButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: finally extract failed */
    public SignInButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f6248d = null;
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, d.SignInButton, 0, 0);
        try {
            this.f6245a = obtainStyledAttributes.getInt(d.SignInButton_buttonSize, 0);
            this.f6246b = obtainStyledAttributes.getInt(d.SignInButton_colorScheme, 2);
            obtainStyledAttributes.recycle();
            setStyle(this.f6245a, this.f6246b);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void onClick(View view) {
        View.OnClickListener onClickListener = this.f6248d;
        if (onClickListener != null && view == this.f6247c) {
            onClickListener.onClick(this);
        }
    }

    public final void setColorScheme(int i) {
        setStyle(this.f6245a, i);
    }

    public final void setEnabled(boolean z) {
        super.setEnabled(z);
        this.f6247c.setEnabled(z);
    }

    public final void setOnClickListener(View.OnClickListener onClickListener) {
        this.f6248d = onClickListener;
        View view = this.f6247c;
        if (view != null) {
            view.setOnClickListener(this);
        }
    }

    @Deprecated
    public final void setScopes(Scope[] scopeArr) {
        setStyle(this.f6245a, this.f6246b);
    }

    public final void setSize(int i) {
        setStyle(i, this.f6246b);
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x00c8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setStyle(int r9, int r10) {
        /*
            r8 = this;
            r8.f6245a = r9
            r8.f6246b = r10
            android.content.Context r9 = r8.getContext()
            android.view.View r10 = r8.f6247c
            if (r10 == 0) goto L_0x000f
            r8.removeView(r10)
        L_0x000f:
            int r10 = r8.f6245a     // Catch:{ a -> 0x001b }
            int r0 = r8.f6246b     // Catch:{ a -> 0x001b }
            android.view.View r10 = b.c.a.b.d.n.r.a(r9, r10, r0)     // Catch:{ a -> 0x001b }
            r8.f6247c = r10     // Catch:{ a -> 0x001b }
            goto L_0x00cf
        L_0x001b:
            int r10 = r8.f6245a
            int r0 = r8.f6246b
            com.google.android.gms.common.internal.SignInButtonImpl r1 = new com.google.android.gms.common.internal.SignInButtonImpl
            r1.<init>(r9)
            android.content.res.Resources r9 = r9.getResources()
            android.graphics.Typeface r2 = android.graphics.Typeface.DEFAULT_BOLD
            r1.setTypeface(r2)
            r2 = 1096810496(0x41600000, float:14.0)
            r1.setTextSize(r2)
            android.util.DisplayMetrics r2 = r9.getDisplayMetrics()
            float r2 = r2.density
            r3 = 1111490560(0x42400000, float:48.0)
            float r2 = r2 * r3
            r3 = 1056964608(0x3f000000, float:0.5)
            float r2 = r2 + r3
            int r2 = (int) r2
            r1.setMinHeight(r2)
            r1.setMinWidth(r2)
            int r2 = b.c.a.b.b.b.common_google_signin_btn_icon_dark
            int r3 = b.c.a.b.b.b.common_google_signin_btn_icon_light
            int r2 = com.google.android.gms.common.internal.SignInButtonImpl.a(r0, r2, r3, r3)
            int r3 = b.c.a.b.b.b.common_google_signin_btn_text_dark
            int r4 = b.c.a.b.b.b.common_google_signin_btn_text_light
            int r3 = com.google.android.gms.common.internal.SignInButtonImpl.a(r0, r3, r4, r4)
            java.lang.String r4 = "Unknown button size: "
            r5 = 32
            r6 = 2
            r7 = 1
            if (r10 == 0) goto L_0x006e
            if (r10 == r7) goto L_0x006e
            if (r10 != r6) goto L_0x0064
            goto L_0x006f
        L_0x0064:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = b.a.a.a.a.a((int) r5, (java.lang.String) r4, (int) r10)
            r9.<init>(r10)
            throw r9
        L_0x006e:
            r2 = r3
        L_0x006f:
            android.graphics.drawable.Drawable r2 = r9.getDrawable(r2)
            android.graphics.drawable.Drawable r2 = androidx.core.graphics.drawable.DrawableCompat.wrap(r2)
            int r3 = b.c.a.b.b.a.common_google_signin_btn_tint
            android.content.res.ColorStateList r3 = r9.getColorStateList(r3)
            androidx.core.graphics.drawable.DrawableCompat.setTintList(r2, r3)
            android.graphics.PorterDuff$Mode r3 = android.graphics.PorterDuff.Mode.SRC_ATOP
            androidx.core.graphics.drawable.DrawableCompat.setTintMode(r2, r3)
            r1.setBackgroundDrawable(r2)
            int r2 = b.c.a.b.b.a.common_google_signin_btn_text_dark
            int r3 = b.c.a.b.b.a.common_google_signin_btn_text_light
            int r0 = com.google.android.gms.common.internal.SignInButtonImpl.a(r0, r2, r3, r3)
            android.content.res.ColorStateList r0 = r9.getColorStateList(r0)
            b.a.b.w.e.b(r0)
            r1.setTextColor(r0)
            r0 = 0
            if (r10 == 0) goto L_0x00b2
            if (r10 == r7) goto L_0x00af
            if (r10 != r6) goto L_0x00a5
            r1.setText(r0)
            goto L_0x00bb
        L_0x00a5:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = b.a.a.a.a.a((int) r5, (java.lang.String) r4, (int) r10)
            r9.<init>(r10)
            throw r9
        L_0x00af:
            int r10 = b.c.a.b.b.c.common_signin_button_text_long
            goto L_0x00b4
        L_0x00b2:
            int r10 = b.c.a.b.b.c.common_signin_button_text
        L_0x00b4:
            java.lang.String r9 = r9.getString(r10)
            r1.setText(r9)
        L_0x00bb:
            r1.setTransformationMethod(r0)
            android.content.Context r9 = r1.getContext()
            boolean r9 = b.c.a.b.d.n.u.d.c((android.content.Context) r9)
            if (r9 == 0) goto L_0x00cd
            r9 = 19
            r1.setGravity(r9)
        L_0x00cd:
            r8.f6247c = r1
        L_0x00cf:
            android.view.View r9 = r8.f6247c
            r8.addView(r9)
            android.view.View r9 = r8.f6247c
            boolean r10 = r8.isEnabled()
            r9.setEnabled(r10)
            android.view.View r9 = r8.f6247c
            r9.setOnClickListener(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.SignInButton.setStyle(int, int):void");
    }

    @Deprecated
    public final void setStyle(int i, int i2, Scope[] scopeArr) {
        setStyle(i, i2);
    }
}
