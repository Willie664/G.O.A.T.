package com.google.android.gms.common.stats;

import android.text.TextUtils;
import b.a.a.a.a;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public abstract class StatsEvent extends AbstractSafeParcelable implements ReflectedParcelable {
    public String toString() {
        WakeLockEvent wakeLockEvent = (WakeLockEvent) this;
        long j = wakeLockEvent.f6345b;
        int i = wakeLockEvent.f6346c;
        long j2 = wakeLockEvent.p;
        String str = wakeLockEvent.f6347d;
        int i2 = wakeLockEvent.f6350g;
        List<String> list = wakeLockEvent.h;
        String str2 = "";
        String join = list == null ? str2 : TextUtils.join(",", list);
        int i3 = wakeLockEvent.k;
        String str3 = wakeLockEvent.f6348e;
        if (str3 == null) {
            str3 = str2;
        }
        String str4 = wakeLockEvent.l;
        if (str4 == null) {
            str4 = str2;
        }
        float f2 = wakeLockEvent.m;
        String str5 = wakeLockEvent.f6349f;
        if (str5 != null) {
            str2 = str5;
        }
        boolean z = wakeLockEvent.o;
        StringBuilder sb = new StringBuilder(str2.length() + str4.length() + str3.length() + a.a(join, a.a(str, 51)));
        sb.append("\t");
        sb.append(str);
        sb.append("\t");
        sb.append(i2);
        sb.append("\t");
        sb.append(join);
        sb.append("\t");
        sb.append(i3);
        sb.append("\t");
        sb.append(str3);
        sb.append("\t");
        sb.append(str4);
        sb.append("\t");
        sb.append(f2);
        sb.append("\t");
        sb.append(str2);
        sb.append("\t");
        sb.append(z);
        String sb2 = sb.toString();
        StringBuilder sb3 = new StringBuilder(a.a(sb2, 53));
        sb3.append(j);
        sb3.append("\t");
        sb3.append(i);
        sb3.append("\t");
        sb3.append(j2);
        sb3.append(sb2);
        return sb3.toString();
    }
}
