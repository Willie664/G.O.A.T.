package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.a.b.w.e;
import b.c.a.b.d.n.q;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.t;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class ConnectionResult extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ConnectionResult> CREATOR = new t();

    /* renamed from: e  reason: collision with root package name */
    public static final ConnectionResult f6237e = new ConnectionResult(0);

    /* renamed from: a  reason: collision with root package name */
    public final int f6238a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6239b;

    /* renamed from: c  reason: collision with root package name */
    public final PendingIntent f6240c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6241d;

    public ConnectionResult(int i) {
        this.f6238a = 1;
        this.f6239b = i;
        this.f6240c = null;
        this.f6241d = null;
    }

    public ConnectionResult(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f6238a = i;
        this.f6239b = i2;
        this.f6240c = pendingIntent;
        this.f6241d = str;
    }

    public static String zza(int i) {
        if (i == 99) {
            return "UNFINISHED";
        }
        if (i == 1500) {
            return "DRIVE_EXTERNAL_STORAGE_REQUIRED";
        }
        switch (i) {
            case -1:
                return "UNKNOWN";
            case 0:
                return "SUCCESS";
            case 1:
                return "SERVICE_MISSING";
            case 2:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case 3:
                return "SERVICE_DISABLED";
            case 4:
                return "SIGN_IN_REQUIRED";
            case 5:
                return "INVALID_ACCOUNT";
            case 6:
                return "RESOLUTION_REQUIRED";
            case 7:
                return "NETWORK_ERROR";
            case 8:
                return "INTERNAL_ERROR";
            case 9:
                return "SERVICE_INVALID";
            case 10:
                return "DEVELOPER_ERROR";
            case 11:
                return "LICENSE_CHECK_FAILED";
            default:
                switch (i) {
                    case 13:
                        return "CANCELED";
                    case 14:
                        return "TIMEOUT";
                    case 15:
                        return "INTERRUPTED";
                    case 16:
                        return "API_UNAVAILABLE";
                    case 17:
                        return "SIGN_IN_FAILED";
                    case 18:
                        return "SERVICE_UPDATING";
                    case 19:
                        return "SERVICE_MISSING_PERMISSION";
                    case 20:
                        return "RESTRICTED_PROFILE";
                    case 21:
                        return "API_VERSION_UPDATE_REQUIRED";
                    default:
                        StringBuilder sb = new StringBuilder(31);
                        sb.append("UNKNOWN_ERROR_CODE(");
                        sb.append(i);
                        sb.append(")");
                        return sb.toString();
                }
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ConnectionResult)) {
            return false;
        }
        ConnectionResult connectionResult = (ConnectionResult) obj;
        return this.f6239b == connectionResult.f6239b && e.c((Object) this.f6240c, (Object) connectionResult.f6240c) && e.c((Object) this.f6241d, (Object) connectionResult.f6241d);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6239b), this.f6240c, this.f6241d});
    }

    public final boolean p() {
        return this.f6239b == 0;
    }

    public final String toString() {
        q c2 = e.c((Object) this);
        c2.a("statusCode", zza(this.f6239b));
        c2.a("resolution", this.f6240c);
        c2.a("message", this.f6241d);
        return c2.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6238a);
        d.a(parcel, 2, this.f6239b);
        d.a(parcel, 3, (Parcelable) this.f6240c, i, false);
        d.a(parcel, 4, this.f6241d, false);
        d.b(parcel, a2);
    }

    public ConnectionResult(int i, @Nullable PendingIntent pendingIntent) {
        this.f6238a = 1;
        this.f6239b = i;
        this.f6240c = pendingIntent;
        this.f6241d = null;
    }
}
