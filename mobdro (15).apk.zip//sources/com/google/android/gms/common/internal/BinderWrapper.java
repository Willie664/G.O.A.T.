package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.f0;
import com.google.android.gms.common.annotation.KeepName;

@KeepName
public final class BinderWrapper implements Parcelable {
    public static final Parcelable.Creator<BinderWrapper> CREATOR = new f0();

    /* renamed from: a  reason: collision with root package name */
    public IBinder f6283a = null;

    public BinderWrapper() {
    }

    public BinderWrapper(IBinder iBinder) {
        this.f6283a = iBinder;
    }

    public /* synthetic */ BinderWrapper(Parcel parcel, f0 f0Var) {
        this.f6283a = parcel.readStrongBinder();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.f6283a);
    }
}
