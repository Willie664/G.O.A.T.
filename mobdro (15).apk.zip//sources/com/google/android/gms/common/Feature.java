package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.a.b.w.e;
import b.c.a.b.d.n.q;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.u;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import io.lum.sdk.perr;
import java.util.Arrays;

public class Feature extends AbstractSafeParcelable {
    public static final Parcelable.Creator<Feature> CREATOR = new u();

    /* renamed from: a  reason: collision with root package name */
    public final String f6242a;
    @Deprecated

    /* renamed from: b  reason: collision with root package name */
    public final int f6243b;

    /* renamed from: c  reason: collision with root package name */
    public final long f6244c;

    public Feature(String str, int i, long j) {
        this.f6242a = str;
        this.f6243b = i;
        this.f6244c = j;
    }

    public Feature(String str, long j) {
        this.f6242a = str;
        this.f6244c = j;
        this.f6243b = -1;
    }

    public boolean equals(@Nullable Object obj) {
        if (obj instanceof Feature) {
            Feature feature = (Feature) obj;
            String str = this.f6242a;
            if (((str == null || !str.equals(feature.f6242a)) && (this.f6242a != null || feature.f6242a != null)) || getVersion() != feature.getVersion()) {
                return false;
            }
            return true;
        }
        return false;
    }

    public long getVersion() {
        long j = this.f6244c;
        return j == -1 ? (long) this.f6243b : j;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6242a, Long.valueOf(getVersion())});
    }

    public String toString() {
        q c2 = e.c((Object) this);
        c2.a("name", this.f6242a);
        c2.a(perr.columns.VER, Long.valueOf(getVersion()));
        return c2.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6242a, false);
        d.a(parcel, 2, this.f6243b);
        d.a(parcel, 3, getVersion());
        d.b(parcel, a2);
    }
}
