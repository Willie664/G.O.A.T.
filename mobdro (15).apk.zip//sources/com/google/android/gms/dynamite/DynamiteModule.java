package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import b.c.a.b.f.e;
import b.c.a.b.f.h;
import b.c.a.b.f.i;
import b.c.a.b.f.j;
import com.google.android.gms.common.util.DynamiteApi;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import javax.annotation.concurrent.GuardedBy;

public final class DynamiteModule {
    @GuardedBy("DynamiteModule.class")

    /* renamed from: b  reason: collision with root package name */
    public static Boolean f6355b = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: c  reason: collision with root package name */
    public static h f6356c = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: d  reason: collision with root package name */
    public static j f6357d = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: e  reason: collision with root package name */
    public static String f6358e = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: f  reason: collision with root package name */
    public static int f6359f = -1;

    /* renamed from: g  reason: collision with root package name */
    public static final ThreadLocal<c> f6360g = new ThreadLocal<>();
    public static final b.C0126b h = new b.c.a.b.f.a();
    public static final b i = new b.c.a.b.f.c();
    public static final b j = new b.c.a.b.f.b();
    public static final b k = new b.c.a.b.f.d();
    public static final b l = new e();

    /* renamed from: a  reason: collision with root package name */
    public final Context f6361a;

    @DynamiteApi
    public static class DynamiteLoaderClassLoader {
        @GuardedBy("DynamiteLoaderClassLoader.class")
        public static ClassLoader sClassLoader;
    }

    public static class a extends Exception {
        public /* synthetic */ a(String str, b.c.a.b.f.a aVar) {
            super(str);
        }

        public /* synthetic */ a(String str, Throwable th, b.c.a.b.f.a aVar) {
            super(str, th);
        }
    }

    public interface b {

        public static class a {

            /* renamed from: a  reason: collision with root package name */
            public int f6362a = 0;

            /* renamed from: b  reason: collision with root package name */
            public int f6363b = 0;

            /* renamed from: c  reason: collision with root package name */
            public int f6364c = 0;
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b  reason: collision with other inner class name */
        public interface C0126b {
            int a(Context context, String str);

            int a(Context context, String str, boolean z) throws a;
        }

        a a(Context context, String str, C0126b bVar) throws a;
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public Cursor f6365a;

        public c() {
        }

        public /* synthetic */ c(b.c.a.b.f.a aVar) {
        }
    }

    public static class d implements b.C0126b {

        /* renamed from: a  reason: collision with root package name */
        public final int f6366a;

        public d(int i) {
            this.f6366a = i;
        }

        public final int a(Context context, String str) {
            return this.f6366a;
        }

        public final int a(Context context, String str, boolean z) {
            return 0;
        }
    }

    public DynamiteModule(Context context) {
        b.a.b.w.e.b(context);
        this.f6361a = context;
    }

    public static int a(Context context, String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (declaredField.get((Object) null).equals(str)) {
                return declaredField2.getInt((Object) null);
            }
            String.valueOf(declaredField.get((Object) null)).length();
            String.valueOf(str).length();
            return 0;
        } catch (ClassNotFoundException unused) {
            String.valueOf(str).length();
            return 0;
        } catch (Exception e2) {
            String valueOf = String.valueOf(e2.getMessage());
            if (valueOf.length() != 0) {
                "Failed to load module descriptor class: ".concat(valueOf);
            } else {
                new String("Failed to load module descriptor class: ");
            }
            return 0;
        }
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:657)
        	at java.util.ArrayList.get(ArrayList.java:433)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:23:0x0050=Splitter:B:23:0x0050, B:18:0x0035=Splitter:B:18:0x0035, B:39:0x008b=Splitter:B:39:0x008b} */
    public static int a(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)     // Catch:{ all -> 0x00dc }
            java.lang.Boolean r1 = f6355b     // Catch:{ all -> 0x00d9 }
            if (r1 != 0) goto L_0x00ac
            android.content.Context r1 = r8.getApplicationContext()     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule$DynamiteLoaderClassLoader> r2 = com.google.android.gms.dynamite.DynamiteModule.DynamiteLoaderClassLoader.class
            java.lang.String r2 = r2.getName()     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            java.lang.String r2 = "sClassLoader"
            java.lang.reflect.Field r2 = r1.getDeclaredField(r2)     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            monitor-enter(r1)     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
            r3 = 0
            java.lang.Object r4 = r2.get(r3)     // Catch:{ all -> 0x0099 }
            java.lang.ClassLoader r4 = (java.lang.ClassLoader) r4     // Catch:{ all -> 0x0099 }
            if (r4 == 0) goto L_0x0038
            java.lang.ClassLoader r2 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0099 }
            if (r4 != r2) goto L_0x0032
        L_0x002f:
            java.lang.Boolean r2 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x0099 }
            goto L_0x0096
        L_0x0032:
            a((java.lang.ClassLoader) r4)     // Catch:{ a -> 0x0035 }
        L_0x0035:
            java.lang.Boolean r2 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x0099 }
            goto L_0x0096
        L_0x0038:
            java.lang.String r4 = "com.google.android.gms"
            android.content.Context r5 = r8.getApplicationContext()     // Catch:{ all -> 0x0099 }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ all -> 0x0099 }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x0099 }
            if (r4 == 0) goto L_0x0050
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0099 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0099 }
            goto L_0x002f
        L_0x0050:
            int r4 = c(r8, r9, r10)     // Catch:{ a -> 0x008e }
            java.lang.String r5 = f6358e     // Catch:{ a -> 0x008e }
            if (r5 == 0) goto L_0x008b
            java.lang.String r5 = f6358e     // Catch:{ a -> 0x008e }
            boolean r5 = r5.isEmpty()     // Catch:{ a -> 0x008e }
            if (r5 == 0) goto L_0x0061
            goto L_0x008b
        L_0x0061:
            int r5 = android.os.Build.VERSION.SDK_INT     // Catch:{ a -> 0x008e }
            r6 = 29
            if (r5 < r6) goto L_0x0073
            dalvik.system.DelegateLastClassLoader r5 = new dalvik.system.DelegateLastClassLoader     // Catch:{ a -> 0x008e }
            java.lang.String r6 = f6358e     // Catch:{ a -> 0x008e }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x008e }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x008e }
            goto L_0x007e
        L_0x0073:
            b.c.a.b.f.f r5 = new b.c.a.b.f.f     // Catch:{ a -> 0x008e }
            java.lang.String r6 = f6358e     // Catch:{ a -> 0x008e }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x008e }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x008e }
        L_0x007e:
            a((java.lang.ClassLoader) r5)     // Catch:{ a -> 0x008e }
            r2.set(r3, r5)     // Catch:{ a -> 0x008e }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ a -> 0x008e }
            f6355b = r5     // Catch:{ a -> 0x008e }
            monitor-exit(r1)     // Catch:{ all -> 0x0099 }
            monitor-exit(r0)     // Catch:{ all -> 0x00d9 }
            return r4
        L_0x008b:
            monitor-exit(r1)     // Catch:{ all -> 0x0099 }
            monitor-exit(r0)     // Catch:{ all -> 0x00d9 }
            return r4
        L_0x008e:
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0099 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0099 }
            goto L_0x002f
        L_0x0096:
            monitor-exit(r1)     // Catch:{ all -> 0x0099 }
            r1 = r2
            goto L_0x00aa
        L_0x0099:
            r2 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0099 }
            throw r2     // Catch:{ ClassNotFoundException -> 0x00a0, IllegalAccessException -> 0x009e, NoSuchFieldException -> 0x009c }
        L_0x009c:
            r1 = move-exception
            goto L_0x00a1
        L_0x009e:
            r1 = move-exception
            goto L_0x00a1
        L_0x00a0:
            r1 = move-exception
        L_0x00a1:
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00d9 }
            r1.length()     // Catch:{ all -> 0x00d9 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00d9 }
        L_0x00aa:
            f6355b = r1     // Catch:{ all -> 0x00d9 }
        L_0x00ac:
            monitor-exit(r0)     // Catch:{ all -> 0x00d9 }
            boolean r0 = r1.booleanValue()     // Catch:{ all -> 0x00dc }
            if (r0 == 0) goto L_0x00d4
            int r8 = c(r8, r9, r10)     // Catch:{ a -> 0x00b8 }
            return r8
        L_0x00b8:
            r9 = move-exception
            java.lang.String r10 = "Failed to retrieve remote module version: "
            java.lang.String r9 = r9.getMessage()     // Catch:{ all -> 0x00dc }
            java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ all -> 0x00dc }
            int r0 = r9.length()     // Catch:{ all -> 0x00dc }
            if (r0 == 0) goto L_0x00cd
            r10.concat(r9)     // Catch:{ all -> 0x00dc }
            goto L_0x00d2
        L_0x00cd:
            java.lang.String r9 = new java.lang.String     // Catch:{ all -> 0x00dc }
            r9.<init>(r10)     // Catch:{ all -> 0x00dc }
        L_0x00d2:
            r8 = 0
            return r8
        L_0x00d4:
            int r8 = b((android.content.Context) r8, (java.lang.String) r9, (boolean) r10)     // Catch:{ all -> 0x00dc }
            return r8
        L_0x00d9:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00d9 }
            throw r9     // Catch:{ all -> 0x00dc }
        L_0x00dc:
            r9 = move-exception
            b.c.a.b.d.r.b.a(r8, r9)
            goto L_0x00e2
        L_0x00e1:
            throw r9
        L_0x00e2:
            goto L_0x00e1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.a(android.content.Context, java.lang.String, boolean):int");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005a, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static b.c.a.b.f.h a(android.content.Context r4) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)
            b.c.a.b.f.h r1 = f6356c     // Catch:{ all -> 0x005b }
            if (r1 == 0) goto L_0x000b
            b.c.a.b.f.h r4 = f6356c     // Catch:{ all -> 0x005b }
            monitor-exit(r0)     // Catch:{ all -> 0x005b }
            return r4
        L_0x000b:
            r1 = 0
            java.lang.String r2 = "com.google.android.gms"
            r3 = 3
            android.content.Context r4 = r4.createPackageContext(r2, r3)     // Catch:{ Exception -> 0x003f }
            java.lang.ClassLoader r4 = r4.getClassLoader()     // Catch:{ Exception -> 0x003f }
            java.lang.String r2 = "com.google.android.gms.chimera.container.DynamiteLoaderImpl"
            java.lang.Class r4 = r4.loadClass(r2)     // Catch:{ Exception -> 0x003f }
            java.lang.Object r4 = r4.newInstance()     // Catch:{ Exception -> 0x003f }
            android.os.IBinder r4 = (android.os.IBinder) r4     // Catch:{ Exception -> 0x003f }
            if (r4 != 0) goto L_0x0027
            r2 = r1
            goto L_0x0039
        L_0x0027:
            java.lang.String r2 = "com.google.android.gms.dynamite.IDynamiteLoader"
            android.os.IInterface r2 = r4.queryLocalInterface(r2)     // Catch:{ Exception -> 0x003f }
            boolean r3 = r2 instanceof b.c.a.b.f.h     // Catch:{ Exception -> 0x003f }
            if (r3 == 0) goto L_0x0034
            b.c.a.b.f.h r2 = (b.c.a.b.f.h) r2     // Catch:{ Exception -> 0x003f }
            goto L_0x0039
        L_0x0034:
            b.c.a.b.f.g r2 = new b.c.a.b.f.g     // Catch:{ Exception -> 0x003f }
            r2.<init>(r4)     // Catch:{ Exception -> 0x003f }
        L_0x0039:
            if (r2 == 0) goto L_0x0059
            f6356c = r2     // Catch:{ Exception -> 0x003f }
            monitor-exit(r0)     // Catch:{ all -> 0x005b }
            return r2
        L_0x003f:
            r4 = move-exception
            java.lang.String r2 = "Failed to load IDynamiteLoader from GmsCore: "
            java.lang.String r4 = r4.getMessage()     // Catch:{ all -> 0x005b }
            java.lang.String r4 = java.lang.String.valueOf(r4)     // Catch:{ all -> 0x005b }
            int r3 = r4.length()     // Catch:{ all -> 0x005b }
            if (r3 == 0) goto L_0x0054
            r2.concat(r4)     // Catch:{ all -> 0x005b }
            goto L_0x0059
        L_0x0054:
            java.lang.String r4 = new java.lang.String     // Catch:{ all -> 0x005b }
            r4.<init>(r2)     // Catch:{ all -> 0x005b }
        L_0x0059:
            monitor-exit(r0)     // Catch:{ all -> 0x005b }
            return r1
        L_0x005b:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x005b }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.a(android.content.Context):b.c.a.b.f.h");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0049, code lost:
        if (r10 != null) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0060, code lost:
        if (r10 != null) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0096, code lost:
        if (r10 != null) goto L_0x004b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.dynamite.DynamiteModule a(android.content.Context r9, com.google.android.gms.dynamite.DynamiteModule.b r10, java.lang.String r11) throws com.google.android.gms.dynamite.DynamiteModule.a {
        /*
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r0 = f6360g
            java.lang.Object r0 = r0.get()
            com.google.android.gms.dynamite.DynamiteModule$c r0 = (com.google.android.gms.dynamite.DynamiteModule.c) r0
            com.google.android.gms.dynamite.DynamiteModule$c r1 = new com.google.android.gms.dynamite.DynamiteModule$c
            r2 = 0
            r1.<init>(r2)
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r3 = f6360g
            r3.set(r1)
            com.google.android.gms.dynamite.DynamiteModule$b$b r3 = h     // Catch:{ all -> 0x00e6 }
            com.google.android.gms.dynamite.DynamiteModule$b$a r3 = r10.a(r9, r11, r3)     // Catch:{ all -> 0x00e6 }
            int r4 = r3.f6362a     // Catch:{ all -> 0x00e6 }
            java.lang.String r4 = java.lang.String.valueOf(r11)     // Catch:{ all -> 0x00e6 }
            r4.length()     // Catch:{ all -> 0x00e6 }
            java.lang.String r4 = java.lang.String.valueOf(r11)     // Catch:{ all -> 0x00e6 }
            r4.length()     // Catch:{ all -> 0x00e6 }
            int r4 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            if (r4 == 0) goto L_0x00bc
            int r4 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            r5 = -1
            if (r4 != r5) goto L_0x0036
            int r4 = r3.f6362a     // Catch:{ all -> 0x00e6 }
            if (r4 == 0) goto L_0x00bc
        L_0x0036:
            int r4 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            r6 = 1
            if (r4 != r6) goto L_0x003f
            int r4 = r3.f6363b     // Catch:{ all -> 0x00e6 }
            if (r4 == 0) goto L_0x00bc
        L_0x003f:
            int r4 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            if (r4 != r5) goto L_0x0054
            com.google.android.gms.dynamite.DynamiteModule r9 = b(r9, r11)     // Catch:{ all -> 0x00e6 }
            android.database.Cursor r10 = r1.f6365a
            if (r10 == 0) goto L_0x004e
        L_0x004b:
            r10.close()
        L_0x004e:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = f6360g
            r10.set(r0)
            return r9
        L_0x0054:
            int r4 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            if (r4 != r6) goto L_0x00a1
            int r4 = r3.f6363b     // Catch:{ a -> 0x0063 }
            com.google.android.gms.dynamite.DynamiteModule r9 = a((android.content.Context) r9, (java.lang.String) r11, (int) r4)     // Catch:{ a -> 0x0063 }
            android.database.Cursor r10 = r1.f6365a
            if (r10 == 0) goto L_0x004e
            goto L_0x004b
        L_0x0063:
            r4 = move-exception
            java.lang.String r6 = "Failed to load remote module: "
            java.lang.String r7 = r4.getMessage()     // Catch:{ all -> 0x00e6 }
            java.lang.String r7 = java.lang.String.valueOf(r7)     // Catch:{ all -> 0x00e6 }
            int r8 = r7.length()     // Catch:{ all -> 0x00e6 }
            if (r8 == 0) goto L_0x0078
            r6.concat(r7)     // Catch:{ all -> 0x00e6 }
            goto L_0x007d
        L_0x0078:
            java.lang.String r7 = new java.lang.String     // Catch:{ all -> 0x00e6 }
            r7.<init>(r6)     // Catch:{ all -> 0x00e6 }
        L_0x007d:
            int r6 = r3.f6362a     // Catch:{ all -> 0x00e6 }
            if (r6 == 0) goto L_0x0099
            com.google.android.gms.dynamite.DynamiteModule$d r6 = new com.google.android.gms.dynamite.DynamiteModule$d     // Catch:{ all -> 0x00e6 }
            int r3 = r3.f6362a     // Catch:{ all -> 0x00e6 }
            r6.<init>(r3)     // Catch:{ all -> 0x00e6 }
            com.google.android.gms.dynamite.DynamiteModule$b$a r10 = r10.a(r9, r11, r6)     // Catch:{ all -> 0x00e6 }
            int r10 = r10.f6364c     // Catch:{ all -> 0x00e6 }
            if (r10 != r5) goto L_0x0099
            com.google.android.gms.dynamite.DynamiteModule r9 = b(r9, r11)     // Catch:{ all -> 0x00e6 }
            android.database.Cursor r10 = r1.f6365a
            if (r10 == 0) goto L_0x004e
            goto L_0x004b
        L_0x0099:
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00e6 }
            java.lang.String r10 = "Remote load failed. No local fallback found."
            r9.<init>(r10, r4, r2)     // Catch:{ all -> 0x00e6 }
            throw r9     // Catch:{ all -> 0x00e6 }
        L_0x00a1:
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00e6 }
            int r10 = r3.f6364c     // Catch:{ all -> 0x00e6 }
            r11 = 47
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x00e6 }
            r3.<init>(r11)     // Catch:{ all -> 0x00e6 }
            java.lang.String r11 = "VersionPolicy returned invalid code:"
            r3.append(r11)     // Catch:{ all -> 0x00e6 }
            r3.append(r10)     // Catch:{ all -> 0x00e6 }
            java.lang.String r10 = r3.toString()     // Catch:{ all -> 0x00e6 }
            r9.<init>(r10, r2)     // Catch:{ all -> 0x00e6 }
            throw r9     // Catch:{ all -> 0x00e6 }
        L_0x00bc:
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00e6 }
            int r10 = r3.f6362a     // Catch:{ all -> 0x00e6 }
            int r11 = r3.f6363b     // Catch:{ all -> 0x00e6 }
            r3 = 91
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00e6 }
            r4.<init>(r3)     // Catch:{ all -> 0x00e6 }
            java.lang.String r3 = "No acceptable module found. Local version is "
            r4.append(r3)     // Catch:{ all -> 0x00e6 }
            r4.append(r10)     // Catch:{ all -> 0x00e6 }
            java.lang.String r10 = " and remote version is "
            r4.append(r10)     // Catch:{ all -> 0x00e6 }
            r4.append(r11)     // Catch:{ all -> 0x00e6 }
            java.lang.String r10 = "."
            r4.append(r10)     // Catch:{ all -> 0x00e6 }
            java.lang.String r10 = r4.toString()     // Catch:{ all -> 0x00e6 }
            r9.<init>(r10, r2)     // Catch:{ all -> 0x00e6 }
            throw r9     // Catch:{ all -> 0x00e6 }
        L_0x00e6:
            r9 = move-exception
            android.database.Cursor r10 = r1.f6365a
            if (r10 == 0) goto L_0x00ee
            r10.close()
        L_0x00ee:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = f6360g
            r10.set(r0)
            goto L_0x00f5
        L_0x00f4:
            throw r9
        L_0x00f5:
            goto L_0x00f4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.a(android.content.Context, com.google.android.gms.dynamite.DynamiteModule$b, java.lang.String):com.google.android.gms.dynamite.DynamiteModule");
    }

    public static DynamiteModule a(Context context, String str, int i2) throws a {
        Boolean bool;
        b.c.a.b.e.a aVar;
        try {
            synchronized (DynamiteModule.class) {
                bool = f6355b;
            }
            if (bool == null) {
                throw new a("Failed to determine which loading route to use.", (b.c.a.b.f.a) null);
            } else if (bool.booleanValue()) {
                return b(context, str, i2);
            } else {
                String.valueOf(str).length();
                h a2 = a(context);
                if (a2 != null) {
                    if (a2.c() >= 2) {
                        aVar = a2.a((b.c.a.b.e.a) new b.c.a.b.e.b(context), str, i2);
                    } else {
                        aVar = a2.b((b.c.a.b.e.a) new b.c.a.b.e.b(context), str, i2);
                    }
                    if (b.c.a.b.e.b.a(aVar) != null) {
                        return new DynamiteModule((Context) b.c.a.b.e.b.a(aVar));
                    }
                    throw new a("Failed to load remote module.", (b.c.a.b.f.a) null);
                }
                throw new a("Failed to create IDynamiteLoader.", (b.c.a.b.f.a) null);
            }
        } catch (RemoteException e2) {
            throw new a("Failed to load remote module.", e2, (b.c.a.b.f.a) null);
        } catch (a e3) {
            throw e3;
        } catch (Throwable th) {
            b.c.a.b.d.r.b.a(context, th);
            throw new a("Failed to load remote module.", th, (b.c.a.b.f.a) null);
        }
    }

    public static Boolean a() {
        Boolean valueOf;
        synchronized (DynamiteModule.class) {
            valueOf = Boolean.valueOf(f6359f >= 2);
        }
        return valueOf;
    }

    @GuardedBy("DynamiteModule.class")
    public static void a(ClassLoader classLoader) throws a {
        j jVar;
        try {
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]);
            if (iBinder == null) {
                jVar = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                jVar = queryLocalInterface instanceof j ? (j) queryLocalInterface : new i(iBinder);
            }
            f6357d = jVar;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
            throw new a("Failed to instantiate dynamite loader", e2, (b.c.a.b.f.a) null);
        }
    }

    public static int b(Context context, String str, boolean z) {
        h a2 = a(context);
        if (a2 == null) {
            return 0;
        }
        try {
            if (a2.c() >= 2) {
                return a2.a((b.c.a.b.e.a) new b.c.a.b.e.b(context), str, z);
            }
            return a2.b((b.c.a.b.e.a) new b.c.a.b.e.b(context), str, z);
        } catch (RemoteException e2) {
            String valueOf = String.valueOf(e2.getMessage());
            if (valueOf.length() != 0) {
                "Failed to retrieve remote module version: ".concat(valueOf);
            } else {
                new String("Failed to retrieve remote module version: ");
            }
            return 0;
        }
    }

    public static DynamiteModule b(Context context, String str) {
        String valueOf = String.valueOf(str);
        if (valueOf.length() != 0) {
            "Selected local version of ".concat(valueOf);
        } else {
            new String("Selected local version of ");
        }
        return new DynamiteModule(context.getApplicationContext());
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00a9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int c(android.content.Context r8, java.lang.String r9, boolean r10) throws com.google.android.gms.dynamite.DynamiteModule.a {
        /*
            r0 = 0
            android.content.ContentResolver r1 = r8.getContentResolver()     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            if (r10 == 0) goto L_0x000a
            java.lang.String r8 = "api_force_staging"
            goto L_0x000c
        L_0x000a:
            java.lang.String r8 = "api"
        L_0x000c:
            int r10 = r8.length()     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            int r10 = r10 + 42
            java.lang.String r2 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            int r2 = r2.length()     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            int r10 = r10 + r2
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            r2.<init>(r10)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            java.lang.String r10 = "content://com.google.android.gms.chimera/"
            r2.append(r10)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            r2.append(r8)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            java.lang.String r8 = "/"
            r2.append(r8)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            r2.append(r9)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            java.lang.String r8 = r2.toString()     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            android.net.Uri r2 = android.net.Uri.parse(r8)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r8 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x0096, all -> 0x0094 }
            if (r8 == 0) goto L_0x008c
            boolean r9 = r8.moveToFirst()     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            if (r9 == 0) goto L_0x008c
            r9 = 0
            int r9 = r8.getInt(r9)     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            if (r9 <= 0) goto L_0x007c
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r10 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r10)     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            r1 = 2
            java.lang.String r1 = r8.getString(r1)     // Catch:{ all -> 0x0079 }
            f6358e = r1     // Catch:{ all -> 0x0079 }
            java.lang.String r1 = "loaderVersion"
            int r1 = r8.getColumnIndex(r1)     // Catch:{ all -> 0x0079 }
            if (r1 < 0) goto L_0x0067
            int r1 = r8.getInt(r1)     // Catch:{ all -> 0x0079 }
            f6359f = r1     // Catch:{ all -> 0x0079 }
        L_0x0067:
            monitor-exit(r10)     // Catch:{ all -> 0x0079 }
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = f6360g     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            java.lang.Object r10 = r10.get()     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            com.google.android.gms.dynamite.DynamiteModule$c r10 = (com.google.android.gms.dynamite.DynamiteModule.c) r10     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            if (r10 == 0) goto L_0x007c
            android.database.Cursor r1 = r10.f6365a     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            if (r1 != 0) goto L_0x007c
            r10.f6365a = r8     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            goto L_0x007d
        L_0x0079:
            r9 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0079 }
            throw r9     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
        L_0x007c:
            r0 = r8
        L_0x007d:
            if (r0 == 0) goto L_0x0082
            r0.close()
        L_0x0082:
            return r9
        L_0x0083:
            r9 = move-exception
            r0 = r8
            r8 = r9
            goto L_0x00a7
        L_0x0087:
            r9 = move-exception
            r7 = r9
            r9 = r8
            r8 = r7
            goto L_0x0098
        L_0x008c:
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            java.lang.String r10 = "Failed to connect to dynamite module ContentResolver."
            r9.<init>(r10, r0)     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
            throw r9     // Catch:{ Exception -> 0x0087, all -> 0x0083 }
        L_0x0094:
            r8 = move-exception
            goto L_0x00a7
        L_0x0096:
            r8 = move-exception
            r9 = r0
        L_0x0098:
            boolean r10 = r8 instanceof com.google.android.gms.dynamite.DynamiteModule.a     // Catch:{ all -> 0x00a5 }
            if (r10 == 0) goto L_0x009d
            throw r8     // Catch:{ all -> 0x00a5 }
        L_0x009d:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00a5 }
            java.lang.String r1 = "V2 version check failed"
            r10.<init>(r1, r8, r0)     // Catch:{ all -> 0x00a5 }
            throw r10     // Catch:{ all -> 0x00a5 }
        L_0x00a5:
            r8 = move-exception
            r0 = r9
        L_0x00a7:
            if (r0 == 0) goto L_0x00ac
            r0.close()
        L_0x00ac:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.c(android.content.Context, java.lang.String, boolean):int");
    }

    public final IBinder a(String str) throws a {
        try {
            return (IBinder) this.f6361a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e2) {
            String valueOf = String.valueOf(str);
            throw new a(valueOf.length() != 0 ? "Failed to instantiate module class: ".concat(valueOf) : new String("Failed to instantiate module class: "), e2, (b.c.a.b.f.a) null);
        }
    }

    public static DynamiteModule b(Context context, String str, int i2) throws a, RemoteException {
        j jVar;
        b.c.a.b.e.a aVar;
        String.valueOf(str).length();
        synchronized (DynamiteModule.class) {
            jVar = f6357d;
        }
        if (jVar != null) {
            c cVar = f6360g.get();
            if (cVar == null || cVar.f6365a == null) {
                throw new a("No result cursor", (b.c.a.b.f.a) null);
            }
            Context applicationContext = context.getApplicationContext();
            Cursor cursor = cVar.f6365a;
            new b.c.a.b.e.b(null);
            if (a().booleanValue()) {
                aVar = jVar.b(new b.c.a.b.e.b(applicationContext), str, i2, new b.c.a.b.e.b(cursor));
            } else {
                aVar = jVar.a(new b.c.a.b.e.b(applicationContext), str, i2, new b.c.a.b.e.b(cursor));
            }
            Context context2 = (Context) b.c.a.b.e.b.a(aVar);
            if (context2 != null) {
                return new DynamiteModule(context2);
            }
            throw new a("Failed to get module context", (b.c.a.b.f.a) null);
        }
        throw new a("DynamiteLoaderV2 was not cached.", (b.c.a.b.f.a) null);
    }
}
