package com.google.android.gms.signin.internal;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.j.b.i;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class zak extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zak> CREATOR = new i();

    /* renamed from: a  reason: collision with root package name */
    public final int f6415a;

    /* renamed from: b  reason: collision with root package name */
    public final ConnectionResult f6416b;
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public final ResolveAccountResponse f6417c;

    public zak() {
        ConnectionResult connectionResult = new ConnectionResult(8, (PendingIntent) null);
        this.f6415a = 1;
        this.f6416b = connectionResult;
        this.f6417c = null;
    }

    public zak(int i, ConnectionResult connectionResult, @Nullable ResolveAccountResponse resolveAccountResponse) {
        this.f6415a = i;
        this.f6416b = connectionResult;
        this.f6417c = resolveAccountResponse;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6415a);
        d.a(parcel, 2, (Parcelable) this.f6416b, i, false);
        d.a(parcel, 3, (Parcelable) this.f6417c, i, false);
        d.b(parcel, a2);
    }
}
