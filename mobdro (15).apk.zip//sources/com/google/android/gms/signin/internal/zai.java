package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.d.n.u.d;
import b.c.a.b.j.b.h;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class zai extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zai> CREATOR = new h();

    /* renamed from: a  reason: collision with root package name */
    public final int f6413a;

    /* renamed from: b  reason: collision with root package name */
    public final ResolveAccountRequest f6414b;

    public zai(int i, ResolveAccountRequest resolveAccountRequest) {
        this.f6413a = i;
        this.f6414b = resolveAccountRequest;
    }

    public zai(ResolveAccountRequest resolveAccountRequest) {
        this.f6413a = 1;
        this.f6414b = resolveAccountRequest;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6413a);
        d.a(parcel, 2, (Parcelable) this.f6414b, i, false);
        d.b(parcel, a2);
    }
}
