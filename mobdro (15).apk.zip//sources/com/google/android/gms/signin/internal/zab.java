package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import b.c.a.b.d.k.h;
import b.c.a.b.d.n.u.d;
import b.c.a.b.j.b.b;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class zab extends AbstractSafeParcelable implements h {
    public static final Parcelable.Creator<zab> CREATOR = new b();

    /* renamed from: a  reason: collision with root package name */
    public final int f6410a;

    /* renamed from: b  reason: collision with root package name */
    public int f6411b;
    @Nullable

    /* renamed from: c  reason: collision with root package name */
    public Intent f6412c;

    public zab() {
        this.f6410a = 2;
        this.f6411b = 0;
        this.f6412c = null;
    }

    public zab(int i, int i2, @Nullable Intent intent) {
        this.f6410a = i;
        this.f6411b = i2;
        this.f6412c = intent;
    }

    public final Status getStatus() {
        return this.f6411b == 0 ? Status.f6252e : Status.i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 1, this.f6410a);
        d.a(parcel, 2, this.f6411b);
        d.a(parcel, 3, (Parcelable) this.f6412c, i, false);
        d.b(parcel, a2);
    }
}
