package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import b.c.a.b.g.a.a;
import b.c.a.b.g.a.b;
import b.c.a.b.g.a.d;
import b.c.a.b.g.a.e;
import b.c.a.b.g.c;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.internal.flags.zze;

@DynamiteApi
public class FlagProviderImpl extends c {

    /* renamed from: a  reason: collision with root package name */
    public boolean f6367a = false;

    /* renamed from: b  reason: collision with root package name */
    public SharedPreferences f6368b;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        if (!this.f6367a) {
            return z;
        }
        SharedPreferences sharedPreferences = this.f6368b;
        Boolean valueOf = Boolean.valueOf(z);
        try {
            valueOf = (Boolean) zze.zza(new a(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            if (valueOf2.length() != 0) {
                "Flag value not available, returning default: ".concat(valueOf2);
            } else {
                new String("Flag value not available, returning default: ");
            }
        }
        return valueOf.booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        if (!this.f6367a) {
            return i;
        }
        SharedPreferences sharedPreferences = this.f6368b;
        Integer valueOf = Integer.valueOf(i);
        try {
            valueOf = (Integer) zze.zza(new b(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            if (valueOf2.length() != 0) {
                "Flag value not available, returning default: ".concat(valueOf2);
            } else {
                new String("Flag value not available, returning default: ");
            }
        }
        return valueOf.intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        if (!this.f6367a) {
            return j;
        }
        SharedPreferences sharedPreferences = this.f6368b;
        Long valueOf = Long.valueOf(j);
        try {
            valueOf = (Long) zze.zza(new b.c.a.b.g.a.c(sharedPreferences, str, valueOf));
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            if (valueOf2.length() != 0) {
                "Flag value not available, returning default: ".concat(valueOf2);
            } else {
                new String("Flag value not available, returning default: ");
            }
        }
        return valueOf.longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        if (!this.f6367a) {
            return str2;
        }
        try {
            return (String) zze.zza(new d(this.f6368b, str, str2));
        } catch (Exception e2) {
            String valueOf = String.valueOf(e2.getMessage());
            if (valueOf.length() != 0) {
                "Flag value not available, returning default: ".concat(valueOf);
                return str2;
            }
            new String("Flag value not available, returning default: ");
            return str2;
        }
    }

    public void init(b.c.a.b.e.a aVar) {
        Context context = (Context) b.c.a.b.e.b.a(aVar);
        if (!this.f6367a) {
            try {
                this.f6368b = e.a(context.createPackageContext("com.google.android.gms", 0));
                this.f6367a = true;
            } catch (PackageManager.NameNotFoundException unused) {
            } catch (Exception e2) {
                String valueOf = String.valueOf(e2.getMessage());
                if (valueOf.length() != 0) {
                    "Could not retrieve sdk flags, continuing with defaults: ".concat(valueOf);
                } else {
                    new String("Could not retrieve sdk flags, continuing with defaults: ");
                }
            }
        }
    }
}
