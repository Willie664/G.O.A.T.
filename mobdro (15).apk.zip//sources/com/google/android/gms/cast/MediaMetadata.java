package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.app.NotificationCompatJellybean;
import b.c.a.b.c.s0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaMetadata extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaMetadata> CREATOR = new s0();

    /* renamed from: d  reason: collision with root package name */
    public static final String[] f6067d = {null, "String", "int", "double", "ISO-8601 date String", "Time in milliseconds as long"};

    /* renamed from: e  reason: collision with root package name */
    public static final a f6068e;

    /* renamed from: a  reason: collision with root package name */
    public final List<WebImage> f6069a;

    /* renamed from: b  reason: collision with root package name */
    public final Bundle f6070b;

    /* renamed from: c  reason: collision with root package name */
    public int f6071c;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final Map<String, String> f6072a = new HashMap();

        /* renamed from: b  reason: collision with root package name */
        public final Map<String, String> f6073b = new HashMap();

        /* renamed from: c  reason: collision with root package name */
        public final Map<String, Integer> f6074c = new HashMap();

        public final a a(String str, String str2, int i) {
            this.f6072a.put(str, str2);
            this.f6073b.put(str2, str);
            this.f6074c.put(str, Integer.valueOf(i));
            return this;
        }

        public final String a(String str) {
            return this.f6072a.get(str);
        }

        public final int b(String str) {
            Integer num = this.f6074c.get(str);
            if (num != null) {
                return num.intValue();
            }
            return 0;
        }
    }

    static {
        a aVar = new a();
        aVar.a("com.google.android.gms.cast.metadata.CREATION_DATE", "creationDateTime", 4);
        aVar.a("com.google.android.gms.cast.metadata.RELEASE_DATE", "releaseDate", 4);
        aVar.a("com.google.android.gms.cast.metadata.BROADCAST_DATE", "originalAirdate", 4);
        aVar.a("com.google.android.gms.cast.metadata.TITLE", NotificationCompatJellybean.KEY_TITLE, 1);
        aVar.a("com.google.android.gms.cast.metadata.SUBTITLE", "subtitle", 1);
        aVar.a("com.google.android.gms.cast.metadata.ARTIST", "artist", 1);
        aVar.a("com.google.android.gms.cast.metadata.ALBUM_ARTIST", "albumArtist", 1);
        aVar.a("com.google.android.gms.cast.metadata.ALBUM_TITLE", "albumName", 1);
        aVar.a("com.google.android.gms.cast.metadata.COMPOSER", "composer", 1);
        aVar.a("com.google.android.gms.cast.metadata.DISC_NUMBER", "discNumber", 2);
        aVar.a("com.google.android.gms.cast.metadata.TRACK_NUMBER", "trackNumber", 2);
        aVar.a("com.google.android.gms.cast.metadata.SEASON_NUMBER", "season", 2);
        aVar.a("com.google.android.gms.cast.metadata.EPISODE_NUMBER", "episode", 2);
        aVar.a("com.google.android.gms.cast.metadata.SERIES_TITLE", "seriesTitle", 1);
        aVar.a("com.google.android.gms.cast.metadata.STUDIO", "studio", 1);
        aVar.a("com.google.android.gms.cast.metadata.WIDTH", "width", 2);
        aVar.a("com.google.android.gms.cast.metadata.HEIGHT", "height", 2);
        aVar.a("com.google.android.gms.cast.metadata.LOCATION_NAME", "location", 1);
        aVar.a("com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "latitude", 3);
        aVar.a("com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "longitude", 3);
        aVar.a("com.google.android.gms.cast.metadata.SECTION_DURATION", "sectionDuration", 5);
        aVar.a("com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_MEDIA", "sectionStartTimeInMedia", 5);
        aVar.a("com.google.android.gms.cast.metadata.SECTION_START_ABSOLUTE_TIME", "sectionStartAbsoluteTime", 5);
        aVar.a("com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_CONTAINER", "sectionStartTimeInContainer", 5);
        aVar.a("com.google.android.gms.cast.metadata.QUEUE_ITEM_ID", "queueItemId", 2);
        aVar.a("com.google.android.gms.cast.metadata.BOOK_TITLE", "bookTitle", 1);
        aVar.a("com.google.android.gms.cast.metadata.CHAPTER_NUMBER", "chapterNumber", 2);
        aVar.a("com.google.android.gms.cast.metadata.CHAPTER_TITLE", "chapterTitle", 1);
        f6068e = aVar;
    }

    public MediaMetadata() {
        this(0);
    }

    public MediaMetadata(int i) {
        ArrayList arrayList = new ArrayList();
        Bundle bundle = new Bundle();
        this.f6069a = arrayList;
        this.f6070b = bundle;
        this.f6071c = i;
    }

    public MediaMetadata(List<WebImage> list, Bundle bundle, int i) {
        this.f6069a = list;
        this.f6070b = bundle;
        this.f6071c = i;
    }

    public static void a(String str, int i) throws IllegalArgumentException {
        if (!TextUtils.isEmpty(str)) {
            int b2 = f6068e.b(str);
            if (b2 != i && b2 != 0) {
                String str2 = f6067d[i];
                StringBuilder sb = new StringBuilder(b.a.a.a.a.a(str2, b.a.a.a.a.a(str, 21)));
                sb.append("Value for ");
                sb.append(str);
                sb.append(" must be a ");
                sb.append(str2);
                throw new IllegalArgumentException(sb.toString());
            }
            return;
        }
        throw new IllegalArgumentException("null and empty keys are not allowed");
    }

    public final void a(JSONObject jSONObject) {
        Bundle bundle;
        JSONObject jSONObject2 = jSONObject;
        this.f6070b.clear();
        this.f6069a.clear();
        this.f6071c = 0;
        try {
            this.f6071c = jSONObject2.getInt("metadataType");
        } catch (JSONException unused) {
        }
        JSONArray optJSONArray = jSONObject2.optJSONArray("images");
        if (optJSONArray != null) {
            b.c.a.b.c.i.c.a.a(this.f6069a, optJSONArray);
        }
        ArrayList arrayList = new ArrayList();
        int i = this.f6071c;
        if (i == 0) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 1) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 2) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE"});
        } else if (i == 3) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 4) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE"});
        } else if (i == 5) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.CHAPTER_TITLE", "com.google.android.gms.cast.metadata.CHAPTER_NUMBER", "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.BOOK_TITLE", "com.google.android.gms.cast.metadata.SUBTITLE"});
        }
        Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.SECTION_DURATION", "com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_MEDIA", "com.google.android.gms.cast.metadata.SECTION_START_ABSOLUTE_TIME", "com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_CONTAINER", "com.google.android.gms.cast.metadata.QUEUE_ITEM_ID"});
        HashSet hashSet = new HashSet(arrayList);
        try {
            Iterator<String> keys = jSONObject.keys();
            while (keys.hasNext()) {
                String next = keys.next();
                if (!"metadataType".equals(next)) {
                    String str = f6068e.f6073b.get(next);
                    if (str == null) {
                        Object obj = jSONObject2.get(next);
                        if (obj instanceof String) {
                            this.f6070b.putString(next, (String) obj);
                        } else if (obj instanceof Integer) {
                            this.f6070b.putInt(next, ((Integer) obj).intValue());
                        } else if (obj instanceof Double) {
                            this.f6070b.putDouble(next, ((Double) obj).doubleValue());
                        }
                    } else if (hashSet.contains(str)) {
                        try {
                            Object obj2 = jSONObject2.get(next);
                            if (obj2 != null) {
                                int b2 = f6068e.b(str);
                                if (b2 != 1) {
                                    if (b2 != 2) {
                                        if (b2 == 3) {
                                            double optDouble = jSONObject2.optDouble(next);
                                            if (!Double.isNaN(optDouble)) {
                                                this.f6070b.putDouble(str, optDouble);
                                            }
                                        } else if (b2 != 4) {
                                            if (b2 == 5) {
                                                this.f6070b.putLong(str, b.c.a.b.c.i.a.a((double) jSONObject2.optLong(next)));
                                            }
                                        } else if ((obj2 instanceof String) && b.c.a.b.c.i.c.a.a((String) obj2) != null) {
                                            bundle = this.f6070b;
                                        }
                                    } else if (obj2 instanceof Integer) {
                                        this.f6070b.putInt(str, ((Integer) obj2).intValue());
                                    }
                                } else if (obj2 instanceof String) {
                                    bundle = this.f6070b;
                                }
                                bundle.putString(str, (String) obj2);
                            }
                        } catch (JSONException unused2) {
                        }
                    }
                }
            }
        } catch (JSONException unused3) {
        }
    }

    public final boolean a(Bundle bundle, Bundle bundle2) {
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            Object obj2 = bundle2.get(str);
            if ((obj instanceof Bundle) && (obj2 instanceof Bundle) && !a((Bundle) obj, (Bundle) obj2)) {
                return false;
            }
            if (obj == null) {
                if (obj2 != null || !bundle2.containsKey(str)) {
                    return false;
                }
            } else if (!obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    public boolean b(String str) {
        return this.f6070b.containsKey(str);
    }

    public String c(String str) {
        a(str, 1);
        return this.f6070b.getString(str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaMetadata)) {
            return false;
        }
        MediaMetadata mediaMetadata = (MediaMetadata) obj;
        return a(this.f6070b, mediaMetadata.f6070b) && this.f6069a.equals(mediaMetadata.f6069a);
    }

    public int hashCode() {
        int i = 17;
        for (String str : this.f6070b.keySet()) {
            i = (i * 31) + this.f6070b.get(str).hashCode();
        }
        return this.f6069a.hashCode() + (i * 31);
    }

    public boolean p() {
        List<WebImage> list = this.f6069a;
        return list != null && !list.isEmpty();
    }

    public final JSONObject q() {
        String a2;
        double d2;
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("metadataType", this.f6071c);
        } catch (JSONException unused) {
        }
        JSONArray a3 = b.c.a.b.c.i.c.a.a(this.f6069a);
        if (!(a3 == null || a3.length() == 0)) {
            try {
                jSONObject.put("images", a3);
            } catch (JSONException unused2) {
            }
        }
        ArrayList arrayList = new ArrayList();
        int i = this.f6071c;
        if (i == 0) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 1) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 2) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE"});
        } else if (i == 3) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE"});
        } else if (i == 4) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE"});
        } else if (i == 5) {
            Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.CHAPTER_TITLE", "com.google.android.gms.cast.metadata.CHAPTER_NUMBER", "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.BOOK_TITLE", "com.google.android.gms.cast.metadata.SUBTITLE"});
        }
        Collections.addAll(arrayList, new String[]{"com.google.android.gms.cast.metadata.SECTION_DURATION", "com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_MEDIA", "com.google.android.gms.cast.metadata.SECTION_START_ABSOLUTE_TIME", "com.google.android.gms.cast.metadata.SECTION_START_TIME_IN_CONTAINER", "com.google.android.gms.cast.metadata.QUEUE_ITEM_ID"});
        try {
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                String str = (String) obj;
                if (this.f6070b.containsKey(str)) {
                    int b2 = f6068e.b(str);
                    if (b2 != 1) {
                        if (b2 != 2) {
                            if (b2 == 3) {
                                a2 = f6068e.a(str);
                                d2 = this.f6070b.getDouble(str);
                            } else if (b2 != 4) {
                                if (b2 == 5) {
                                    a2 = f6068e.a(str);
                                    d2 = b.c.a.b.c.i.a.a(this.f6070b.getLong(str));
                                }
                            }
                            jSONObject.put(a2, d2);
                        } else {
                            jSONObject.put(f6068e.a(str), this.f6070b.getInt(str));
                        }
                    }
                    jSONObject.put(f6068e.a(str), this.f6070b.getString(str));
                }
            }
            for (String str2 : this.f6070b.keySet()) {
                if (!str2.startsWith("com.google.")) {
                    Object obj2 = this.f6070b.get(str2);
                    if (!(obj2 instanceof String)) {
                        if (!(obj2 instanceof Integer)) {
                            if (!(obj2 instanceof Double)) {
                            }
                        }
                    }
                    jSONObject.put(str2, obj2);
                }
            }
        } catch (JSONException unused3) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.b(parcel, 2, this.f6069a, false);
        d.a(parcel, 3, this.f6070b, false);
        d.a(parcel, 4, this.f6071c);
        d.b(parcel, a2);
    }
}
