package com.google.android.gms.cast.framework.media.internal;

import androidx.annotation.Keep;
import b.c.a.b.c.g.j;
import b.c.a.b.c.g.k;
import b.c.a.b.c.g.o;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class ResourceProvider {

    /* renamed from: a  reason: collision with root package name */
    public static final Map<String, Integer> f6194a;

    static {
        HashMap hashMap = new HashMap();
        hashMap.put("smallIconDrawableResId", Integer.valueOf(k.cast_ic_notification_small_icon));
        hashMap.put("stopLiveStreamDrawableResId", Integer.valueOf(k.cast_ic_notification_stop_live_stream));
        hashMap.put("pauseDrawableResId", Integer.valueOf(k.cast_ic_notification_pause));
        hashMap.put("playDrawableResId", Integer.valueOf(k.cast_ic_notification_play));
        hashMap.put("skipNextDrawableResId", Integer.valueOf(k.cast_ic_notification_skip_next));
        hashMap.put("skipPrevDrawableResId", Integer.valueOf(k.cast_ic_notification_skip_prev));
        hashMap.put("forwardDrawableResId", Integer.valueOf(k.cast_ic_notification_forward));
        hashMap.put("forward10DrawableResId", Integer.valueOf(k.cast_ic_notification_forward10));
        hashMap.put("forward30DrawableResId", Integer.valueOf(k.cast_ic_notification_forward30));
        hashMap.put("rewindDrawableResId", Integer.valueOf(k.cast_ic_notification_rewind));
        hashMap.put("rewind10DrawableResId", Integer.valueOf(k.cast_ic_notification_rewind10));
        hashMap.put("rewind30DrawableResId", Integer.valueOf(k.cast_ic_notification_rewind30));
        hashMap.put("disconnectDrawableResId", Integer.valueOf(k.cast_ic_notification_disconnect));
        hashMap.put("notificationImageSizeDimenResId", Integer.valueOf(j.cast_notification_image_size));
        hashMap.put("castingToDeviceStringResId", Integer.valueOf(o.cast_casting_to_device));
        hashMap.put("stopLiveStreamStringResId", Integer.valueOf(o.cast_stop_live_stream));
        hashMap.put("pauseStringResId", Integer.valueOf(o.cast_pause));
        hashMap.put("playStringResId", Integer.valueOf(o.cast_play));
        hashMap.put("skipNextStringResId", Integer.valueOf(o.cast_skip_next));
        hashMap.put("skipPrevStringResId", Integer.valueOf(o.cast_skip_prev));
        hashMap.put("forwardStringResId", Integer.valueOf(o.cast_forward));
        hashMap.put("forward10StringResId", Integer.valueOf(o.cast_forward_10));
        hashMap.put("forward30StringResId", Integer.valueOf(o.cast_forward_30));
        hashMap.put("rewindStringResId", Integer.valueOf(o.cast_rewind));
        hashMap.put("rewind10StringResId", Integer.valueOf(o.cast_rewind_10));
        hashMap.put("rewind30StringResId", Integer.valueOf(o.cast_rewind_30));
        hashMap.put("disconnectStringResId", Integer.valueOf(o.cast_disconnect));
        f6194a = Collections.unmodifiableMap(hashMap);
    }

    @Keep
    public static Integer findResourceByName(String str) {
        if (str == null) {
            return null;
        }
        return f6194a.get(str);
    }
}
