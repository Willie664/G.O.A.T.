package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.d1;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public class ApplicationMetadata extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ApplicationMetadata> CREATOR = new d1();

    /* renamed from: a  reason: collision with root package name */
    public String f6021a;

    /* renamed from: b  reason: collision with root package name */
    public String f6022b;

    /* renamed from: c  reason: collision with root package name */
    public List<String> f6023c;

    /* renamed from: d  reason: collision with root package name */
    public String f6024d;

    /* renamed from: e  reason: collision with root package name */
    public Uri f6025e;
    @Nullable

    /* renamed from: f  reason: collision with root package name */
    public String f6026f;

    /* renamed from: g  reason: collision with root package name */
    public String f6027g;

    public ApplicationMetadata() {
        this.f6023c = new ArrayList();
    }

    public ApplicationMetadata(String str, String str2, List list, String str3, Uri uri, @Nullable String str4, @Nullable String str5) {
        this.f6021a = str;
        this.f6022b = str2;
        this.f6023c = list;
        this.f6024d = str3;
        this.f6025e = uri;
        this.f6026f = str4;
        this.f6027g = str5;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationMetadata)) {
            return false;
        }
        ApplicationMetadata applicationMetadata = (ApplicationMetadata) obj;
        return a.a(this.f6021a, applicationMetadata.f6021a) && a.a(this.f6022b, applicationMetadata.f6022b) && a.a(this.f6023c, applicationMetadata.f6023c) && a.a(this.f6024d, applicationMetadata.f6024d) && a.a(this.f6025e, applicationMetadata.f6025e) && a.a(this.f6026f, applicationMetadata.f6026f) && a.a(this.f6027g, applicationMetadata.f6027g);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6021a, this.f6022b, this.f6023c, this.f6024d, this.f6025e, this.f6026f});
    }

    public String toString() {
        String str = this.f6021a;
        String str2 = this.f6022b;
        List<String> list = this.f6023c;
        int size = list == null ? 0 : list.size();
        String str3 = this.f6024d;
        String valueOf = String.valueOf(this.f6025e);
        String str4 = this.f6026f;
        String str5 = this.f6027g;
        StringBuilder sb = new StringBuilder(b.a.a.a.a.a(str5, b.a.a.a.a.a(str4, valueOf.length() + b.a.a.a.a.a(str3, b.a.a.a.a.a(str2, b.a.a.a.a.a(str, 118))))));
        sb.append("applicationId: ");
        sb.append(str);
        sb.append(", name: ");
        sb.append(str2);
        sb.append(", namespaces.count: ");
        sb.append(size);
        sb.append(", senderAppIdentifier: ");
        sb.append(str3);
        sb.append(", senderAppLaunchUrl: ");
        sb.append(valueOf);
        sb.append(", iconUrl: ");
        sb.append(str4);
        return b.a.a.a.a.a(sb, ", type: ", str5);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6021a, false);
        d.a(parcel, 3, this.f6022b, false);
        d.b(parcel, 4, (List) null, false);
        d.a(parcel, 5, (List<String>) Collections.unmodifiableList(this.f6023c), false);
        d.a(parcel, 6, this.f6024d, false);
        d.a(parcel, 7, (Parcelable) this.f6025e, i, false);
        d.a(parcel, 8, this.f6026f, false);
        d.a(parcel, 9, this.f6027g, false);
        d.b(parcel, a2);
    }
}
