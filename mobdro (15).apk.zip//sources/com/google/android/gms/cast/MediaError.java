package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.n0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import org.json.JSONObject;

public class MediaError extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<MediaError> CREATOR = new n0();

    /* renamed from: a  reason: collision with root package name */
    public final long f6045a;

    /* renamed from: b  reason: collision with root package name */
    public final Integer f6046b;

    /* renamed from: c  reason: collision with root package name */
    public final String f6047c;

    public MediaError(long j, Integer num, String str) {
        this.f6045a = j;
        this.f6046b = num;
        this.f6047c = str;
    }

    public static MediaError a(JSONObject jSONObject) {
        long optLong = jSONObject.optLong("requestId");
        String str = null;
        Integer valueOf = jSONObject.has("detailedErrorCode") ? Integer.valueOf(jSONObject.optInt("detailedErrorCode")) : null;
        if (jSONObject.has("reason")) {
            str = jSONObject.optString("reason");
        }
        return new MediaError(optLong, valueOf, str);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6045a);
        d.a(parcel, 3, this.f6046b, false);
        d.a(parcel, 4, this.f6047c, false);
        d.b(parcel, a2);
    }
}
