package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.cardview.widget.RoundRectDrawableWithShadow;
import b.c.a.b.c.i.a;
import b.c.a.b.c.o0;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaInfo extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<MediaInfo> CREATOR = new o0();

    /* renamed from: a  reason: collision with root package name */
    public String f6048a;

    /* renamed from: b  reason: collision with root package name */
    public int f6049b;

    /* renamed from: c  reason: collision with root package name */
    public String f6050c;

    /* renamed from: d  reason: collision with root package name */
    public MediaMetadata f6051d;

    /* renamed from: e  reason: collision with root package name */
    public long f6052e;

    /* renamed from: f  reason: collision with root package name */
    public List<MediaTrack> f6053f;

    /* renamed from: g  reason: collision with root package name */
    public TextTrackStyle f6054g;
    public String h;
    public List<AdBreakInfo> i;
    public List<AdBreakClipInfo> j;
    public String k;
    public VastAdsRequest l;
    public long m;
    public String n;
    public String o;
    public JSONObject p;

    public MediaInfo(@NonNull String str, int i2, String str2, MediaMetadata mediaMetadata, long j2, List<MediaTrack> list, TextTrackStyle textTrackStyle, String str3, List<AdBreakInfo> list2, List<AdBreakClipInfo> list3, String str4, VastAdsRequest vastAdsRequest, long j3, String str5, String str6) {
        String str7 = str3;
        this.f6048a = str;
        this.f6049b = i2;
        this.f6050c = str2;
        this.f6051d = mediaMetadata;
        this.f6052e = j2;
        this.f6053f = list;
        this.f6054g = textTrackStyle;
        this.h = str7;
        if (str7 != null) {
            try {
                this.p = new JSONObject(this.h);
            } catch (JSONException unused) {
                this.p = null;
                this.h = null;
            }
        } else {
            this.p = null;
        }
        this.i = list2;
        this.j = list3;
        this.k = str4;
        this.l = vastAdsRequest;
        this.m = j3;
        this.n = str5;
        this.o = str6;
    }

    public MediaInfo(JSONObject jSONObject) throws JSONException {
        this(jSONObject.optString("contentId"), -1, (String) null, (MediaMetadata) null, -1, (List<MediaTrack>) null, (TextTrackStyle) null, (String) null, (List<AdBreakInfo>) null, (List<AdBreakClipInfo>) null, (String) null, (VastAdsRequest) null, -1, (String) null, (String) null);
        MediaInfo mediaInfo;
        int i2;
        int i3;
        JSONObject jSONObject2 = jSONObject;
        String optString = jSONObject2.optString("streamType", "NONE");
        if ("NONE".equals(optString)) {
            mediaInfo = this;
            mediaInfo.f6049b = 0;
        } else {
            mediaInfo = this;
            if ("BUFFERED".equals(optString)) {
                mediaInfo.f6049b = 1;
            } else if ("LIVE".equals(optString)) {
                mediaInfo.f6049b = 2;
            } else {
                mediaInfo.f6049b = -1;
            }
        }
        mediaInfo.f6050c = jSONObject2.optString("contentType", (String) null);
        if (jSONObject2.has("metadata")) {
            JSONObject jSONObject3 = jSONObject2.getJSONObject("metadata");
            MediaMetadata mediaMetadata = new MediaMetadata(jSONObject3.getInt("metadataType"));
            mediaInfo.f6051d = mediaMetadata;
            mediaMetadata.a(jSONObject3);
        }
        mediaInfo.f6052e = -1;
        if (jSONObject2.has("duration") && !jSONObject2.isNull("duration")) {
            double optDouble = jSONObject2.optDouble("duration", RoundRectDrawableWithShadow.COS_45);
            if (!Double.isNaN(optDouble) && !Double.isInfinite(optDouble)) {
                mediaInfo.f6052e = a.a(optDouble);
            }
        }
        if (jSONObject2.has("tracks")) {
            mediaInfo.f6053f = new ArrayList();
            JSONArray jSONArray = jSONObject2.getJSONArray("tracks");
            for (int i4 = 0; i4 < jSONArray.length(); i4++) {
                JSONObject jSONObject4 = jSONArray.getJSONObject(i4);
                MediaTrack mediaTrack = new MediaTrack(0, 0, (String) null, (String) null, (String) null, (String) null, -1, (String) null);
                mediaTrack.f6101a = jSONObject4.getLong("trackId");
                String string = jSONObject4.getString("type");
                if ("TEXT".equals(string)) {
                    mediaTrack.f6102b = 1;
                } else if ("AUDIO".equals(string)) {
                    mediaTrack.f6102b = 2;
                } else if ("VIDEO".equals(string)) {
                    mediaTrack.f6102b = 3;
                } else {
                    String valueOf = String.valueOf(string);
                    throw new JSONException(valueOf.length() != 0 ? "invalid type: ".concat(valueOf) : new String("invalid type: "));
                }
                mediaTrack.f6103c = jSONObject4.optString("trackContentId", (String) null);
                mediaTrack.f6104d = jSONObject4.optString("trackContentType", (String) null);
                mediaTrack.f6105e = jSONObject4.optString("name", (String) null);
                mediaTrack.f6106f = jSONObject4.optString("language", (String) null);
                if (jSONObject4.has("subtype")) {
                    String string2 = jSONObject4.getString("subtype");
                    if ("SUBTITLES".equals(string2)) {
                        mediaTrack.f6107g = 1;
                    } else if ("CAPTIONS".equals(string2)) {
                        mediaTrack.f6107g = 2;
                    } else if ("DESCRIPTIONS".equals(string2)) {
                        mediaTrack.f6107g = 3;
                    } else {
                        i3 = "CHAPTERS".equals(string2) ? 4 : "METADATA".equals(string2) ? 5 : -1;
                    }
                    mediaTrack.i = jSONObject4.optJSONObject("customData");
                    mediaInfo.f6053f.add(mediaTrack);
                } else {
                    i3 = 0;
                }
                mediaTrack.f6107g = i3;
                mediaTrack.i = jSONObject4.optJSONObject("customData");
                mediaInfo.f6053f.add(mediaTrack);
            }
        } else {
            mediaInfo.f6053f = null;
        }
        if (jSONObject2.has("textTrackStyle")) {
            JSONObject jSONObject5 = jSONObject2.getJSONObject("textTrackStyle");
            TextTrackStyle textTrackStyle = new TextTrackStyle(1.0f, 0, 0, -1, 0, -1, 0, 0, (String) null, -1, -1, (String) null);
            textTrackStyle.f6108a = (float) jSONObject5.optDouble("fontScale", 1.0d);
            textTrackStyle.f6109b = TextTrackStyle.b(jSONObject5.optString("foregroundColor"));
            textTrackStyle.f6110c = TextTrackStyle.b(jSONObject5.optString("backgroundColor"));
            if (jSONObject5.has("edgeType")) {
                String string3 = jSONObject5.getString("edgeType");
                if ("NONE".equals(string3)) {
                    textTrackStyle.f6111d = 0;
                } else if ("OUTLINE".equals(string3)) {
                    textTrackStyle.f6111d = 1;
                } else if ("DROP_SHADOW".equals(string3)) {
                    textTrackStyle.f6111d = 2;
                } else if ("RAISED".equals(string3)) {
                    textTrackStyle.f6111d = 3;
                } else if ("DEPRESSED".equals(string3)) {
                    textTrackStyle.f6111d = 4;
                }
            }
            textTrackStyle.f6112e = TextTrackStyle.b(jSONObject5.optString("edgeColor"));
            if (jSONObject5.has("windowType")) {
                String string4 = jSONObject5.getString("windowType");
                if ("NONE".equals(string4)) {
                    textTrackStyle.f6113f = 0;
                } else if ("NORMAL".equals(string4)) {
                    textTrackStyle.f6113f = 1;
                } else if ("ROUNDED_CORNERS".equals(string4)) {
                    textTrackStyle.f6113f = 2;
                }
            }
            textTrackStyle.f6114g = TextTrackStyle.b(jSONObject5.optString("windowColor"));
            if (textTrackStyle.f6113f == 2) {
                textTrackStyle.h = jSONObject5.optInt("windowRoundedCornerRadius", 0);
            }
            textTrackStyle.i = jSONObject5.optString("fontFamily", (String) null);
            if (jSONObject5.has("fontGenericFamily")) {
                String string5 = jSONObject5.getString("fontGenericFamily");
                if ("SANS_SERIF".equals(string5)) {
                    textTrackStyle.j = 0;
                } else if ("MONOSPACED_SANS_SERIF".equals(string5)) {
                    textTrackStyle.j = 1;
                } else if ("SERIF".equals(string5)) {
                    textTrackStyle.j = 2;
                } else if ("MONOSPACED_SERIF".equals(string5)) {
                    textTrackStyle.j = 3;
                } else if ("CASUAL".equals(string5)) {
                    textTrackStyle.j = 4;
                } else {
                    if ("CURSIVE".equals(string5)) {
                        i2 = 5;
                    } else {
                        i2 = "SMALL_CAPITALS".equals(string5) ? 6 : i2;
                    }
                    textTrackStyle.j = i2;
                }
            }
            if (jSONObject5.has("fontStyle")) {
                String string6 = jSONObject5.getString("fontStyle");
                if ("NORMAL".equals(string6)) {
                    textTrackStyle.k = 0;
                } else if ("BOLD".equals(string6)) {
                    textTrackStyle.k = 1;
                } else if ("ITALIC".equals(string6)) {
                    textTrackStyle.k = 2;
                } else if ("BOLD_ITALIC".equals(string6)) {
                    textTrackStyle.k = 3;
                }
            }
            textTrackStyle.m = jSONObject5.optJSONObject("customData");
            mediaInfo.f6054g = textTrackStyle;
        } else {
            mediaInfo.f6054g = null;
        }
        a(jSONObject);
        mediaInfo.p = jSONObject2.optJSONObject("customData");
        mediaInfo.k = jSONObject2.optString("entity", (String) null);
        mediaInfo.n = jSONObject2.optString("atvEntity", (String) null);
        mediaInfo.l = VastAdsRequest.a(jSONObject2.optJSONObject("vmapAdsRequest"));
        if (jSONObject2.has("startAbsoluteTime") && !jSONObject2.isNull("startAbsoluteTime")) {
            double optDouble2 = jSONObject2.optDouble("startAbsoluteTime");
            if (!Double.isNaN(optDouble2) && !Double.isInfinite(optDouble2) && optDouble2 >= RoundRectDrawableWithShadow.COS_45) {
                mediaInfo.m = a.a(optDouble2);
            }
        }
        if (jSONObject2.has("contentUrl")) {
            mediaInfo.o = jSONObject2.optString("contentUrl");
        }
    }

    public final void a(JSONObject jSONObject) throws JSONException {
        int i2 = 0;
        if (jSONObject.has("breaks")) {
            JSONArray jSONArray = jSONObject.getJSONArray("breaks");
            this.i = new ArrayList(jSONArray.length());
            int i3 = 0;
            while (true) {
                if (i3 < jSONArray.length()) {
                    AdBreakInfo a2 = AdBreakInfo.a(jSONArray.getJSONObject(i3));
                    if (a2 == null) {
                        this.i.clear();
                        break;
                    } else {
                        this.i.add(a2);
                        i3++;
                    }
                } else {
                    break;
                }
            }
        }
        if (jSONObject.has("breakClips")) {
            JSONArray jSONArray2 = jSONObject.getJSONArray("breakClips");
            this.j = new ArrayList(jSONArray2.length());
            while (i2 < jSONArray2.length()) {
                AdBreakClipInfo a3 = AdBreakClipInfo.a(jSONArray2.getJSONObject(i2));
                if (a3 != null) {
                    this.j.add(a3);
                    i2++;
                } else {
                    this.j.clear();
                    return;
                }
            }
        }
    }

    public boolean equals(Object obj) {
        JSONObject jSONObject;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaInfo)) {
            return false;
        }
        MediaInfo mediaInfo = (MediaInfo) obj;
        if ((this.p == null) != (mediaInfo.p == null)) {
            return false;
        }
        JSONObject jSONObject2 = this.p;
        return (jSONObject2 == null || (jSONObject = mediaInfo.p) == null || e.a(jSONObject2, jSONObject)) && a.a(this.f6048a, mediaInfo.f6048a) && this.f6049b == mediaInfo.f6049b && a.a(this.f6050c, mediaInfo.f6050c) && a.a(this.f6051d, mediaInfo.f6051d) && this.f6052e == mediaInfo.f6052e && a.a(this.f6053f, mediaInfo.f6053f) && a.a(this.f6054g, mediaInfo.f6054g) && a.a(this.i, mediaInfo.i) && a.a(this.j, mediaInfo.j) && a.a(this.k, mediaInfo.k) && a.a(this.l, mediaInfo.l) && this.m == mediaInfo.m && a.a(this.n, mediaInfo.n) && a.a(this.o, mediaInfo.o);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6048a, Integer.valueOf(this.f6049b), this.f6050c, this.f6051d, Long.valueOf(this.f6052e), String.valueOf(this.p), this.f6053f, this.f6054g, this.i, this.j, this.k, this.l, Long.valueOf(this.m), this.n});
    }

    public final JSONObject p() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("contentId", this.f6048a);
            jSONObject.putOpt("contentUrl", this.o);
            int i2 = this.f6049b;
            jSONObject.put("streamType", i2 != 1 ? i2 != 2 ? "NONE" : "LIVE" : "BUFFERED");
            if (this.f6050c != null) {
                jSONObject.put("contentType", this.f6050c);
            }
            if (this.f6051d != null) {
                jSONObject.put("metadata", this.f6051d.q());
            }
            if (this.f6052e <= -1) {
                jSONObject.put("duration", JSONObject.NULL);
            } else {
                jSONObject.put("duration", a.a(this.f6052e));
            }
            if (this.f6053f != null) {
                JSONArray jSONArray = new JSONArray();
                for (MediaTrack p2 : this.f6053f) {
                    jSONArray.put(p2.p());
                }
                jSONObject.put("tracks", jSONArray);
            }
            if (this.f6054g != null) {
                jSONObject.put("textTrackStyle", this.f6054g.p());
            }
            if (this.p != null) {
                jSONObject.put("customData", this.p);
            }
            if (this.k != null) {
                jSONObject.put("entity", this.k);
            }
            if (this.i != null) {
                JSONArray jSONArray2 = new JSONArray();
                for (AdBreakInfo p3 : this.i) {
                    jSONArray2.put(p3.p());
                }
                jSONObject.put("breaks", jSONArray2);
            }
            if (this.j != null) {
                JSONArray jSONArray3 = new JSONArray();
                for (AdBreakClipInfo p4 : this.j) {
                    jSONArray3.put(p4.p());
                }
                jSONObject.put("breakClips", jSONArray3);
            }
            if (this.l != null) {
                jSONObject.put("vmapAdsRequest", this.l.p());
            }
            if (this.m != -1) {
                jSONObject.put("startAbsoluteTime", a.a(this.m));
            }
            jSONObject.putOpt("atvEntity", this.n);
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.p;
        List<T> list = null;
        this.h = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6048a, false);
        d.a(parcel, 3, this.f6049b);
        d.a(parcel, 4, this.f6050c, false);
        d.a(parcel, 5, (Parcelable) this.f6051d, i2, false);
        d.a(parcel, 6, this.f6052e);
        d.b(parcel, 7, this.f6053f, false);
        d.a(parcel, 8, (Parcelable) this.f6054g, i2, false);
        d.a(parcel, 9, this.h, false);
        List<AdBreakInfo> list2 = this.i;
        d.b(parcel, 10, list2 == null ? null : Collections.unmodifiableList(list2), false);
        List<AdBreakClipInfo> list3 = this.j;
        if (list3 != null) {
            list = Collections.unmodifiableList(list3);
        }
        d.b(parcel, 11, list, false);
        d.a(parcel, 12, this.k, false);
        d.a(parcel, 13, (Parcelable) this.l, i2, false);
        d.a(parcel, 14, this.m);
        d.a(parcel, 15, this.n, false);
        d.a(parcel, 16, this.o, false);
        d.b(parcel, a2);
    }
}
