package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import b.c.a.b.c.g.w.a;
import b.c.a.b.c.g.w.d0;
import b.c.a.b.c.g.w.i;
import b.c.a.b.c.g.w.x;
import b.c.a.b.c.i.b;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class CastMediaOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<CastMediaOptions> CREATOR = new i();

    /* renamed from: g  reason: collision with root package name */
    public static final b f6151g = new b("CastMediaOptions");

    /* renamed from: a  reason: collision with root package name */
    public final String f6152a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6153b;

    /* renamed from: c  reason: collision with root package name */
    public final x f6154c;

    /* renamed from: d  reason: collision with root package name */
    public final NotificationOptions f6155d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f6156e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f6157f;

    public CastMediaOptions(String str, String str2, IBinder iBinder, NotificationOptions notificationOptions, boolean z, boolean z2) {
        x xVar;
        this.f6152a = str;
        this.f6153b = str2;
        if (iBinder == null) {
            xVar = null;
        } else {
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.media.IImagePicker");
            xVar = queryLocalInterface instanceof x ? (x) queryLocalInterface : new d0(iBinder);
        }
        this.f6154c = xVar;
        this.f6155d = notificationOptions;
        this.f6156e = z;
        this.f6157f = z2;
    }

    public a p() {
        x xVar = this.f6154c;
        if (xVar == null) {
            return null;
        }
        try {
            return (a) b.c.a.b.e.b.a(xVar.zzbr());
        } catch (RemoteException unused) {
            b bVar = f6151g;
            Object[] objArr = {"getWrappedClientObject", x.class.getSimpleName()};
            if (!bVar.a()) {
                return null;
            }
            bVar.b("Unable to call %s on %s.", objArr);
            return null;
        }
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6152a, false);
        d.a(parcel, 3, this.f6153b, false);
        x xVar = this.f6154c;
        d.a(parcel, 4, xVar == null ? null : xVar.asBinder(), false);
        d.a(parcel, 5, (Parcelable) this.f6155d, i, false);
        d.a(parcel, 6, this.f6156e);
        d.a(parcel, 7, this.f6157f);
        d.b(parcel, a2);
    }
}
