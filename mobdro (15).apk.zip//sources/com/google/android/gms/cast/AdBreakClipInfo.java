package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.app.NotificationCompatJellybean;
import b.c.a.b.c.i.a;
import b.c.a.b.c.j;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class AdBreakClipInfo extends AbstractSafeParcelable {
    public static final Parcelable.Creator<AdBreakClipInfo> CREATOR = new j();

    /* renamed from: a  reason: collision with root package name */
    public final String f6002a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6003b;

    /* renamed from: c  reason: collision with root package name */
    public final long f6004c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6005d;

    /* renamed from: e  reason: collision with root package name */
    public final String f6006e;

    /* renamed from: f  reason: collision with root package name */
    public final String f6007f;

    /* renamed from: g  reason: collision with root package name */
    public String f6008g;
    public String h;
    public String i;
    public final long j;
    public final String k;
    public final VastAdsRequest l;
    public JSONObject m;

    public AdBreakClipInfo(String str, String str2, long j2, String str3, String str4, String str5, String str6, String str7, String str8, long j3, String str9, VastAdsRequest vastAdsRequest) {
        JSONObject jSONObject;
        this.f6002a = str;
        this.f6003b = str2;
        this.f6004c = j2;
        this.f6005d = str3;
        this.f6006e = str4;
        this.f6007f = str5;
        this.f6008g = str6;
        this.h = str7;
        this.i = str8;
        this.j = j3;
        this.k = str9;
        this.l = vastAdsRequest;
        if (!TextUtils.isEmpty(str6)) {
            try {
                this.m = new JSONObject(str6);
            } catch (JSONException e2) {
                String.format(Locale.ROOT, "Error creating AdBreakClipInfo: %s", new Object[]{e2.getMessage()});
                this.f6008g = null;
                jSONObject = new JSONObject();
            }
        } else {
            jSONObject = new JSONObject();
            this.m = jSONObject;
        }
    }

    public static AdBreakClipInfo a(JSONObject jSONObject) {
        String str;
        JSONObject jSONObject2 = jSONObject;
        if (jSONObject2 == null || !jSONObject2.has("id")) {
            return null;
        }
        try {
            String string = jSONObject2.getString("id");
            long a2 = a.a((double) jSONObject2.optLong("duration"));
            String optString = jSONObject2.optString("clickThroughUrl", (String) null);
            String optString2 = jSONObject2.optString("contentUrl", (String) null);
            String optString3 = jSONObject2.optString("mimeType", (String) null);
            if (optString3 == null) {
                optString3 = jSONObject2.optString("contentType", (String) null);
            }
            String str2 = optString3;
            String optString4 = jSONObject2.optString(NotificationCompatJellybean.KEY_TITLE, (String) null);
            JSONObject optJSONObject = jSONObject2.optJSONObject("customData");
            String optString5 = jSONObject2.optString("contentId", (String) null);
            String optString6 = jSONObject2.optString("posterUrl", (String) null);
            long j2 = -1;
            if (jSONObject2.has("whenSkippable")) {
                j2 = a.a((double) ((Integer) jSONObject2.get("whenSkippable")).intValue());
            }
            long j3 = j2;
            String optString7 = jSONObject2.optString("hlsSegmentFormat", (String) null);
            VastAdsRequest a3 = VastAdsRequest.a(jSONObject2.optJSONObject("vastAdsRequest"));
            if (optJSONObject != null) {
                if (optJSONObject.length() != 0) {
                    str = optJSONObject.toString();
                    return new AdBreakClipInfo(string, optString4, a2, optString2, str2, optString, str, optString5, optString6, j3, optString7, a3);
                }
            }
            str = null;
            return new AdBreakClipInfo(string, optString4, a2, optString2, str2, optString, str, optString5, optString6, j3, optString7, a3);
        } catch (JSONException e2) {
            String.format(Locale.ROOT, "Error while creating an AdBreakClipInfo from JSON: %s", new Object[]{e2.getMessage()});
            return null;
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AdBreakClipInfo)) {
            return false;
        }
        AdBreakClipInfo adBreakClipInfo = (AdBreakClipInfo) obj;
        return a.a(this.f6002a, adBreakClipInfo.f6002a) && a.a(this.f6003b, adBreakClipInfo.f6003b) && this.f6004c == adBreakClipInfo.f6004c && a.a(this.f6005d, adBreakClipInfo.f6005d) && a.a(this.f6006e, adBreakClipInfo.f6006e) && a.a(this.f6007f, adBreakClipInfo.f6007f) && a.a(this.f6008g, adBreakClipInfo.f6008g) && a.a(this.h, adBreakClipInfo.h) && a.a(this.i, adBreakClipInfo.i) && this.j == adBreakClipInfo.j && a.a(this.k, adBreakClipInfo.k) && a.a(this.l, adBreakClipInfo.l);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6002a, this.f6003b, Long.valueOf(this.f6004c), this.f6005d, this.f6006e, this.f6007f, this.f6008g, this.h, this.i, Long.valueOf(this.j), this.k, this.l});
    }

    public final JSONObject p() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("id", this.f6002a);
            jSONObject.put("duration", a.a(this.f6004c));
            if (this.j != -1) {
                jSONObject.put("whenSkippable", a.a(this.j));
            }
            if (this.h != null) {
                jSONObject.put("contentId", this.h);
            }
            if (this.f6006e != null) {
                jSONObject.put("contentType", this.f6006e);
            }
            if (this.f6003b != null) {
                jSONObject.put(NotificationCompatJellybean.KEY_TITLE, this.f6003b);
            }
            if (this.f6005d != null) {
                jSONObject.put("contentUrl", this.f6005d);
            }
            if (this.f6007f != null) {
                jSONObject.put("clickThroughUrl", this.f6007f);
            }
            if (this.m != null) {
                jSONObject.put("customData", this.m);
            }
            if (this.i != null) {
                jSONObject.put("posterUrl", this.i);
            }
            if (this.k != null) {
                jSONObject.put("hlsSegmentFormat", this.k);
            }
            if (this.l != null) {
                jSONObject.put("vastAdsRequest", this.l.p());
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6002a, false);
        d.a(parcel, 3, this.f6003b, false);
        d.a(parcel, 4, this.f6004c);
        d.a(parcel, 5, this.f6005d, false);
        d.a(parcel, 6, this.f6006e, false);
        d.a(parcel, 7, this.f6007f, false);
        d.a(parcel, 8, this.f6008g, false);
        d.a(parcel, 9, this.h, false);
        d.a(parcel, 10, this.i, false);
        d.a(parcel, 11, this.j);
        d.a(parcel, 12, this.k, false);
        d.a(parcel, 13, (Parcelable) this.l, i2, false);
        d.b(parcel, a2);
    }
}
