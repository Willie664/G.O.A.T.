package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.l0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzbg extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzbg> CREATOR = new l0();

    /* renamed from: a  reason: collision with root package name */
    public int f6232a;

    public zzbg() {
        this.f6232a = 0;
    }

    public zzbg(int i) {
        this.f6232a = i;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof zzbg) && this.f6232a == ((zzbg) obj).f6232a;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6232a)});
    }

    public final String toString() {
        int i = this.f6232a;
        return String.format("joinOptions(connectionType=%s)", new Object[]{i != 0 ? i != 2 ? "UNKNOWN" : "INVISIBLE" : "STRONG"});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6232a);
        d.b(parcel, a2);
    }
}
