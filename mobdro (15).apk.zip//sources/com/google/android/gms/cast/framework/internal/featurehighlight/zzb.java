package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.animation.Animator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.core.view.GestureDetectorCompat;
import b.c.a.b.c.g.l;
import b.c.a.b.c.g.v.a.a;
import b.c.a.b.c.g.v.a.f;
import b.c.a.b.c.g.v.a.h;
import b.c.a.b.c.g.v.a.i;

public final class zzb extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public final int[] f6144a = new int[2];

    /* renamed from: b  reason: collision with root package name */
    public final Rect f6145b = new Rect();

    /* renamed from: c  reason: collision with root package name */
    public final Rect f6146c = new Rect();

    /* renamed from: d  reason: collision with root package name */
    public final OuterHighlightDrawable f6147d;

    /* renamed from: e  reason: collision with root package name */
    public final InnerZoneDrawable f6148e;

    /* renamed from: f  reason: collision with root package name */
    public h f6149f;

    /* renamed from: g  reason: collision with root package name */
    public View f6150g;
    @Nullable
    public Animator h;
    public final i i;
    public final GestureDetectorCompat j;
    @Nullable
    public GestureDetectorCompat k;
    public f l;
    public boolean m;

    public zzb(Context context) {
        super(context);
        setId(l.cast_featurehighlight_view);
        setWillNotDraw(false);
        InnerZoneDrawable innerZoneDrawable = new InnerZoneDrawable(context);
        this.f6148e = innerZoneDrawable;
        innerZoneDrawable.setCallback(this);
        OuterHighlightDrawable outerHighlightDrawable = new OuterHighlightDrawable(context);
        this.f6147d = outerHighlightDrawable;
        outerHighlightDrawable.setCallback(this);
        this.i = new i(this);
        GestureDetectorCompat gestureDetectorCompat = new GestureDetectorCompat(context, new a(this));
        this.j = gestureDetectorCompat;
        gestureDetectorCompat.setIsLongpressEnabled(false);
        setVisibility(8);
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams;
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-2, -2);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ViewGroup.MarginLayoutParams(layoutParams);
    }

    public final void onDraw(Canvas canvas) {
        canvas.save();
        this.f6147d.draw(canvas);
        this.f6148e.draw(canvas);
        View view = this.f6150g;
        if (view != null) {
            if (view.getParent() != null) {
                Bitmap createBitmap = Bitmap.createBitmap(this.f6150g.getWidth(), this.f6150g.getHeight(), Bitmap.Config.ARGB_8888);
                this.f6150g.draw(new Canvas(createBitmap));
                int color = this.f6147d.f6142f.getColor();
                int red = Color.red(color);
                int green = Color.green(color);
                int blue = Color.blue(color);
                for (int i2 = 0; i2 < createBitmap.getHeight(); i2++) {
                    for (int i3 = 0; i3 < createBitmap.getWidth(); i3++) {
                        int pixel = createBitmap.getPixel(i3, i2);
                        if (Color.alpha(pixel) != 0) {
                            createBitmap.setPixel(i3, i2, Color.argb(Color.alpha(pixel), red, green, blue));
                        }
                    }
                }
                Rect rect = this.f6145b;
                canvas.drawBitmap(createBitmap, (float) rect.left, (float) rect.top, (Paint) null);
            }
            canvas.restore();
            return;
        }
        throw new IllegalStateException("Neither target view nor drawable was set");
    }

    public final void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        View view = this.f6150g;
        if (view != null) {
            boolean z2 = true;
            if (view.getParent() != null) {
                int[] iArr = this.f6144a;
                View view2 = this.f6150g;
                getLocationInWindow(iArr);
                int i6 = iArr[0];
                int i7 = iArr[1];
                view2.getLocationInWindow(iArr);
                iArr[0] = iArr[0] - i6;
                iArr[1] = iArr[1] - i7;
            }
            Rect rect = this.f6145b;
            int[] iArr2 = this.f6144a;
            rect.set(iArr2[0], iArr2[1], this.f6150g.getWidth() + iArr2[0], this.f6150g.getHeight() + this.f6144a[1]);
            this.f6146c.set(i2, i3, i4, i5);
            this.f6147d.setBounds(this.f6146c);
            this.f6148e.setBounds(this.f6146c);
            i iVar = this.i;
            Rect rect2 = this.f6145b;
            Rect rect3 = this.f6146c;
            View asView = iVar.f1518f.f6149f.asView();
            if (rect2.isEmpty() || rect3.isEmpty()) {
                asView.layout(0, 0, 0, 0);
            } else {
                int centerY = rect2.centerY();
                int centerX = rect2.centerX();
                boolean z3 = centerY < rect3.centerY();
                int max = Math.max(iVar.f1514b * 2, rect2.height()) / 2;
                int i8 = iVar.f1515c;
                int i9 = centerY + max + i8;
                if (z3) {
                    iVar.a(asView, rect3.width(), rect3.bottom - i9);
                    int a2 = iVar.a(asView, rect3.left, rect3.right, asView.getMeasuredWidth(), centerX);
                    asView.layout(a2, i9, asView.getMeasuredWidth() + a2, asView.getMeasuredHeight() + i9);
                } else {
                    int i10 = (centerY - max) - i8;
                    iVar.a(asView, rect3.width(), i10 - rect3.top);
                    int a3 = iVar.a(asView, rect3.left, rect3.right, asView.getMeasuredWidth(), centerX);
                    asView.layout(a3, i10 - asView.getMeasuredHeight(), asView.getMeasuredWidth() + a3, i10);
                }
            }
            iVar.f1513a.set(asView.getLeft(), asView.getTop(), asView.getRight(), asView.getBottom());
            OuterHighlightDrawable outerHighlightDrawable = iVar.f1518f.f6147d;
            Rect rect4 = iVar.f1513a;
            outerHighlightDrawable.f6140d.set(rect2);
            outerHighlightDrawable.f6141e.set(rect4);
            float exactCenterX = rect2.exactCenterX();
            float exactCenterY = rect2.exactCenterY();
            Rect bounds = outerHighlightDrawable.getBounds();
            if (Math.min(exactCenterY - ((float) bounds.top), ((float) bounds.bottom) - exactCenterY) < ((float) outerHighlightDrawable.f6137a)) {
                outerHighlightDrawable.i = exactCenterX;
                outerHighlightDrawable.j = exactCenterY;
            } else {
                if (exactCenterX > bounds.exactCenterX()) {
                    z2 = false;
                }
                float exactCenterX2 = rect4.exactCenterX();
                float f2 = (float) outerHighlightDrawable.f6138b;
                outerHighlightDrawable.i = z2 ? exactCenterX2 + f2 : exactCenterX2 - f2;
                outerHighlightDrawable.j = rect4.exactCenterY();
            }
            outerHighlightDrawable.f6143g = Math.max(OuterHighlightDrawable.a(outerHighlightDrawable.i, outerHighlightDrawable.j, rect2), OuterHighlightDrawable.a(outerHighlightDrawable.i, outerHighlightDrawable.j, rect4)) + ((float) outerHighlightDrawable.f6139c);
            outerHighlightDrawable.invalidateSelf();
            InnerZoneDrawable innerZoneDrawable = iVar.f1518f.f6148e;
            innerZoneDrawable.f6132c.set(rect2);
            innerZoneDrawable.h = innerZoneDrawable.f6132c.exactCenterX();
            innerZoneDrawable.i = innerZoneDrawable.f6132c.exactCenterY();
            innerZoneDrawable.f6135f = Math.max((float) innerZoneDrawable.f6133d, Math.max(((float) innerZoneDrawable.f6132c.width()) / 2.0f, ((float) innerZoneDrawable.f6132c.height()) / 2.0f));
            innerZoneDrawable.invalidateSelf();
            return;
        }
        throw new IllegalStateException("Target view must be set before layout");
    }

    public final void onMeasure(int i2, int i3) {
        setMeasuredDimension(ViewGroup.resolveSize(View.MeasureSpec.getSize(i2), i2), ViewGroup.resolveSize(View.MeasureSpec.getSize(i3), i3));
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.m = this.f6145b.contains((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        if (this.m) {
            GestureDetectorCompat gestureDetectorCompat = this.k;
            if (gestureDetectorCompat != null) {
                gestureDetectorCompat.onTouchEvent(motionEvent);
                if (actionMasked == 1) {
                    motionEvent = MotionEvent.obtain(motionEvent);
                    motionEvent.setAction(3);
                }
            }
            if (this.f6150g.getParent() != null) {
                this.f6150g.onTouchEvent(motionEvent);
            }
        } else {
            this.j.onTouchEvent(motionEvent);
        }
        return true;
    }

    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f6147d || drawable == this.f6148e || drawable == null;
    }
}
