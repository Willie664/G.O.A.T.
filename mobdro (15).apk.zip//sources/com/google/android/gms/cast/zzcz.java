package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.VisibleForTesting;
import b.c.a.b.c.c1;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzcz extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzcz> CREATOR = new c1();

    /* renamed from: a  reason: collision with root package name */
    public final String f6233a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6234b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6235c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6236d;

    public zzcz(String str, int i, int i2, String str2) {
        this.f6233a = str;
        this.f6234b = i;
        this.f6235c = i2;
        this.f6236d = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzcz)) {
            return false;
        }
        zzcz zzcz = (zzcz) obj;
        return a.a(this.f6233a, zzcz.f6233a) && a.a(Integer.valueOf(this.f6234b), Integer.valueOf(zzcz.f6234b)) && a.a(Integer.valueOf(this.f6235c), Integer.valueOf(zzcz.f6235c)) && a.a(zzcz.f6236d, this.f6236d);
    }

    @VisibleForTesting
    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6233a, Integer.valueOf(this.f6234b), Integer.valueOf(this.f6235c), this.f6236d});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6233a, false);
        d.a(parcel, 3, this.f6234b);
        d.a(parcel, 4, this.f6235c);
        d.a(parcel, 5, this.f6236d, false);
        d.b(parcel, a2);
    }
}
