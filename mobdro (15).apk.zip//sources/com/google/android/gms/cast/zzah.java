package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.a;
import b.c.a.b.c.m;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzah extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzah> CREATOR = new m();

    /* renamed from: a  reason: collision with root package name */
    public final zzaf f6230a;

    /* renamed from: b  reason: collision with root package name */
    public final zzaf f6231b;

    public zzah(zzaf zzaf, zzaf zzaf2) {
        this.f6230a = zzaf;
        this.f6231b = zzaf2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzah)) {
            return false;
        }
        zzah zzah = (zzah) obj;
        return a.a(this.f6230a, zzah.f6230a) && a.a(this.f6231b, zzah.f6231b);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6230a, this.f6231b});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, (Parcelable) this.f6230a, i, false);
        d.a(parcel, 3, (Parcelable) this.f6231b, i, false);
        d.b(parcel, a2);
    }
}
