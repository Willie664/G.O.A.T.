package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.g.w.f0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ImageHints extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ImageHints> CREATOR = new f0();

    /* renamed from: a  reason: collision with root package name */
    public final int f6158a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6159b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6160c;

    public ImageHints(int i, int i2, int i3) {
        this.f6158a = i;
        this.f6159b = i2;
        this.f6160c = i3;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6158a);
        d.a(parcel, 3, this.f6159b);
        d.a(parcel, 4, this.f6160c);
        d.b(parcel, a2);
    }
}
