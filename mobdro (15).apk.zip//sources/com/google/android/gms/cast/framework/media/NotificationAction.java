package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.g.w.n0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class NotificationAction extends AbstractSafeParcelable {
    public static final Parcelable.Creator<NotificationAction> CREATOR = new n0();

    /* renamed from: a  reason: collision with root package name */
    public final String f6177a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6178b;

    /* renamed from: c  reason: collision with root package name */
    public final String f6179c;

    public NotificationAction(String str, int i, String str2) {
        this.f6177a = str;
        this.f6178b = i;
        this.f6179c = str2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6177a, false);
        d.a(parcel, 3, this.f6178b);
        d.a(parcel, 4, this.f6179c, false);
        d.b(parcel, a2);
    }
}
