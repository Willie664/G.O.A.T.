package com.google.android.gms.cast;

import android.graphics.Color;
import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.e1;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public final class TextTrackStyle extends AbstractSafeParcelable {
    public static final Parcelable.Creator<TextTrackStyle> CREATOR = new e1();

    /* renamed from: a  reason: collision with root package name */
    public float f6108a;

    /* renamed from: b  reason: collision with root package name */
    public int f6109b;

    /* renamed from: c  reason: collision with root package name */
    public int f6110c;

    /* renamed from: d  reason: collision with root package name */
    public int f6111d;

    /* renamed from: e  reason: collision with root package name */
    public int f6112e;

    /* renamed from: f  reason: collision with root package name */
    public int f6113f;

    /* renamed from: g  reason: collision with root package name */
    public int f6114g;
    public int h;
    public String i;
    public int j;
    public int k;
    public String l;
    public JSONObject m;

    public TextTrackStyle() {
        this(1.0f, 0, 0, -1, 0, -1, 0, 0, (String) null, -1, -1, (String) null);
    }

    public TextTrackStyle(float f2, int i2, int i3, int i4, int i5, int i6, int i7, int i8, String str, int i9, int i10, String str2) {
        this.f6108a = f2;
        this.f6109b = i2;
        this.f6110c = i3;
        this.f6111d = i4;
        this.f6112e = i5;
        this.f6113f = i6;
        this.f6114g = i7;
        this.h = i8;
        this.i = str;
        this.j = i9;
        this.k = i10;
        this.l = str2;
        if (str2 != null) {
            try {
                this.m = new JSONObject(this.l);
            } catch (JSONException unused) {
                this.m = null;
                this.l = null;
            }
        } else {
            this.m = null;
        }
    }

    public static String a(int i2) {
        return String.format("#%02X%02X%02X%02X", new Object[]{Integer.valueOf(Color.red(i2)), Integer.valueOf(Color.green(i2)), Integer.valueOf(Color.blue(i2)), Integer.valueOf(Color.alpha(i2))});
    }

    public static int b(String str) {
        if (str != null && str.length() == 9 && str.charAt(0) == '#') {
            try {
                return Color.argb(Integer.parseInt(str.substring(7, 9), 16), Integer.parseInt(str.substring(1, 3), 16), Integer.parseInt(str.substring(3, 5), 16), Integer.parseInt(str.substring(5, 7), 16));
            } catch (NumberFormatException unused) {
            }
        }
        return 0;
    }

    public final boolean equals(Object obj) {
        JSONObject jSONObject;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextTrackStyle)) {
            return false;
        }
        TextTrackStyle textTrackStyle = (TextTrackStyle) obj;
        if ((this.m == null) != (textTrackStyle.m == null)) {
            return false;
        }
        JSONObject jSONObject2 = this.m;
        return (jSONObject2 == null || (jSONObject = textTrackStyle.m) == null || e.a(jSONObject2, jSONObject)) && this.f6108a == textTrackStyle.f6108a && this.f6109b == textTrackStyle.f6109b && this.f6110c == textTrackStyle.f6110c && this.f6111d == textTrackStyle.f6111d && this.f6112e == textTrackStyle.f6112e && this.f6113f == textTrackStyle.f6113f && this.h == textTrackStyle.h && a.a(this.i, textTrackStyle.i) && this.j == textTrackStyle.j && this.k == textTrackStyle.k;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f6108a), Integer.valueOf(this.f6109b), Integer.valueOf(this.f6110c), Integer.valueOf(this.f6111d), Integer.valueOf(this.f6112e), Integer.valueOf(this.f6113f), Integer.valueOf(this.f6114g), Integer.valueOf(this.h), this.i, Integer.valueOf(this.j), Integer.valueOf(this.k), String.valueOf(this.m)});
    }

    /* JADX WARNING: Code restructure failed: missing block: B:50:?, code lost:
        r0.put("fontGenericFamily", r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.json.JSONObject p() {
        /*
            r8 = this;
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            java.lang.String r1 = "fontScale"
            float r2 = r8.f6108a     // Catch:{ JSONException -> 0x00e7 }
            double r2 = (double) r2     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
            int r1 = r8.f6109b     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x001c
            java.lang.String r1 = "foregroundColor"
            int r2 = r8.f6109b     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = a(r2)     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x001c:
            int r1 = r8.f6110c     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x002b
            java.lang.String r1 = "backgroundColor"
            int r2 = r8.f6110c     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = a(r2)     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x002b:
            int r1 = r8.f6111d     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = "NONE"
            r3 = 3
            r4 = 1
            r5 = 2
            java.lang.String r6 = "edgeType"
            if (r1 == 0) goto L_0x004f
            if (r1 == r4) goto L_0x004c
            if (r1 == r5) goto L_0x0049
            if (r1 == r3) goto L_0x0046
            r7 = 4
            if (r1 == r7) goto L_0x0040
            goto L_0x0052
        L_0x0040:
            java.lang.String r1 = "DEPRESSED"
        L_0x0042:
            r0.put(r6, r1)     // Catch:{ JSONException -> 0x00e7 }
            goto L_0x0052
        L_0x0046:
            java.lang.String r1 = "RAISED"
            goto L_0x0042
        L_0x0049:
            java.lang.String r1 = "DROP_SHADOW"
            goto L_0x0042
        L_0x004c:
            java.lang.String r1 = "OUTLINE"
            goto L_0x0042
        L_0x004f:
            r0.put(r6, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x0052:
            int r1 = r8.f6112e     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x0061
            java.lang.String r1 = "edgeColor"
            int r6 = r8.f6112e     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r6 = a(r6)     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r6)     // Catch:{ JSONException -> 0x00e7 }
        L_0x0061:
            int r1 = r8.f6113f     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r6 = "NORMAL"
            java.lang.String r7 = "windowType"
            if (r1 == 0) goto L_0x0078
            if (r1 == r4) goto L_0x0074
            if (r1 == r5) goto L_0x006e
            goto L_0x007b
        L_0x006e:
            java.lang.String r1 = "ROUNDED_CORNERS"
            r0.put(r7, r1)     // Catch:{ JSONException -> 0x00e7 }
            goto L_0x007b
        L_0x0074:
            r0.put(r7, r6)     // Catch:{ JSONException -> 0x00e7 }
            goto L_0x007b
        L_0x0078:
            r0.put(r7, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x007b:
            int r1 = r8.f6114g     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x008a
            java.lang.String r1 = "windowColor"
            int r2 = r8.f6114g     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = a(r2)     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x008a:
            int r1 = r8.f6113f     // Catch:{ JSONException -> 0x00e7 }
            if (r1 != r5) goto L_0x0095
            java.lang.String r1 = "windowRoundedCornerRadius"
            int r2 = r8.h     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x0095:
            java.lang.String r1 = r8.i     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x00a0
            java.lang.String r1 = "fontFamily"
            java.lang.String r2 = r8.i     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x00a0:
            int r1 = r8.j     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = "fontGenericFamily"
            switch(r1) {
                case 0: goto L_0x00bd;
                case 1: goto L_0x00ba;
                case 2: goto L_0x00b7;
                case 3: goto L_0x00b4;
                case 4: goto L_0x00b1;
                case 5: goto L_0x00ae;
                case 6: goto L_0x00a8;
                default: goto L_0x00a7;
            }
        L_0x00a7:
            goto L_0x00c0
        L_0x00a8:
            java.lang.String r1 = "SMALL_CAPITALS"
        L_0x00aa:
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x00e7 }
            goto L_0x00c0
        L_0x00ae:
            java.lang.String r1 = "CURSIVE"
            goto L_0x00aa
        L_0x00b1:
            java.lang.String r1 = "CASUAL"
            goto L_0x00aa
        L_0x00b4:
            java.lang.String r1 = "MONOSPACED_SERIF"
            goto L_0x00aa
        L_0x00b7:
            java.lang.String r1 = "SERIF"
            goto L_0x00aa
        L_0x00ba:
            java.lang.String r1 = "MONOSPACED_SANS_SERIF"
            goto L_0x00aa
        L_0x00bd:
            java.lang.String r1 = "SANS_SERIF"
            goto L_0x00aa
        L_0x00c0:
            int r1 = r8.k     // Catch:{ JSONException -> 0x00e7 }
            java.lang.String r2 = "fontStyle"
            if (r1 == 0) goto L_0x00d9
            if (r1 == r4) goto L_0x00d6
            if (r1 == r5) goto L_0x00d3
            if (r1 == r3) goto L_0x00cd
            goto L_0x00dc
        L_0x00cd:
            java.lang.String r1 = "BOLD_ITALIC"
        L_0x00cf:
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x00e7 }
            goto L_0x00dc
        L_0x00d3:
            java.lang.String r1 = "ITALIC"
            goto L_0x00cf
        L_0x00d6:
            java.lang.String r1 = "BOLD"
            goto L_0x00cf
        L_0x00d9:
            r0.put(r2, r6)     // Catch:{ JSONException -> 0x00e7 }
        L_0x00dc:
            org.json.JSONObject r1 = r8.m     // Catch:{ JSONException -> 0x00e7 }
            if (r1 == 0) goto L_0x00e7
            java.lang.String r1 = "customData"
            org.json.JSONObject r2 = r8.m     // Catch:{ JSONException -> 0x00e7 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00e7 }
        L_0x00e7:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.TextTrackStyle.p():org.json.JSONObject");
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.m;
        this.l = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6108a);
        d.a(parcel, 3, this.f6109b);
        d.a(parcel, 4, this.f6110c);
        d.a(parcel, 5, this.f6111d);
        d.a(parcel, 6, this.f6112e);
        d.a(parcel, 7, this.f6113f);
        d.a(parcel, 8, this.f6114g);
        d.a(parcel, 9, this.h);
        d.a(parcel, 10, this.i, false);
        d.a(parcel, 11, this.j);
        d.a(parcel, 12, this.k);
        d.a(parcel, 13, this.l, false);
        d.b(parcel, a2);
    }
}
