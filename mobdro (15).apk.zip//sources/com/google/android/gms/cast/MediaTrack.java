package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.a1;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaTrack extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<MediaTrack> CREATOR = new a1();

    /* renamed from: a  reason: collision with root package name */
    public long f6101a;

    /* renamed from: b  reason: collision with root package name */
    public int f6102b;

    /* renamed from: c  reason: collision with root package name */
    public String f6103c;

    /* renamed from: d  reason: collision with root package name */
    public String f6104d;

    /* renamed from: e  reason: collision with root package name */
    public String f6105e;

    /* renamed from: f  reason: collision with root package name */
    public String f6106f;

    /* renamed from: g  reason: collision with root package name */
    public int f6107g;
    public String h;
    public JSONObject i;

    public MediaTrack(long j, int i2, String str, String str2, String str3, String str4, int i3, String str5) {
        this.f6101a = j;
        this.f6102b = i2;
        this.f6103c = str;
        this.f6104d = str2;
        this.f6105e = str3;
        this.f6106f = str4;
        this.f6107g = i3;
        this.h = str5;
        if (str5 != null) {
            try {
                this.i = new JSONObject(this.h);
            } catch (JSONException unused) {
                this.i = null;
                this.h = null;
            }
        } else {
            this.i = null;
        }
    }

    public final boolean equals(Object obj) {
        JSONObject jSONObject;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaTrack)) {
            return false;
        }
        MediaTrack mediaTrack = (MediaTrack) obj;
        if ((this.i == null) != (mediaTrack.i == null)) {
            return false;
        }
        JSONObject jSONObject2 = this.i;
        return (jSONObject2 == null || (jSONObject = mediaTrack.i) == null || e.a(jSONObject2, jSONObject)) && this.f6101a == mediaTrack.f6101a && this.f6102b == mediaTrack.f6102b && a.a(this.f6103c, mediaTrack.f6103c) && a.a(this.f6104d, mediaTrack.f6104d) && a.a(this.f6105e, mediaTrack.f6105e) && a.a(this.f6106f, mediaTrack.f6106f) && this.f6107g == mediaTrack.f6107g;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f6101a), Integer.valueOf(this.f6102b), this.f6103c, this.f6104d, this.f6105e, this.f6106f, Integer.valueOf(this.f6107g), String.valueOf(this.i)});
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x002a A[Catch:{ JSONException -> 0x0084 }] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0035 A[Catch:{ JSONException -> 0x0084 }] */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0040 A[Catch:{ JSONException -> 0x0084 }] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x004f A[Catch:{ JSONException -> 0x0084 }] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0076 A[Catch:{ JSONException -> 0x0084 }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x007d A[Catch:{ JSONException -> 0x0084 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.json.JSONObject p() {
        /*
            r6 = this;
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            java.lang.String r1 = "trackId"
            long r2 = r6.f6101a     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x0084 }
            int r1 = r6.f6102b     // Catch:{ JSONException -> 0x0084 }
            r2 = 3
            r3 = 2
            r4 = 1
            java.lang.String r5 = "type"
            if (r1 == r4) goto L_0x0023
            if (r1 == r3) goto L_0x0020
            if (r1 == r2) goto L_0x001a
            goto L_0x0026
        L_0x001a:
            java.lang.String r1 = "VIDEO"
        L_0x001c:
            r0.put(r5, r1)     // Catch:{ JSONException -> 0x0084 }
            goto L_0x0026
        L_0x0020:
            java.lang.String r1 = "AUDIO"
            goto L_0x001c
        L_0x0023:
            java.lang.String r1 = "TEXT"
            goto L_0x001c
        L_0x0026:
            java.lang.String r1 = r6.f6103c     // Catch:{ JSONException -> 0x0084 }
            if (r1 == 0) goto L_0x0031
            java.lang.String r1 = "trackContentId"
            java.lang.String r5 = r6.f6103c     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r5)     // Catch:{ JSONException -> 0x0084 }
        L_0x0031:
            java.lang.String r1 = r6.f6104d     // Catch:{ JSONException -> 0x0084 }
            if (r1 == 0) goto L_0x003c
            java.lang.String r1 = "trackContentType"
            java.lang.String r5 = r6.f6104d     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r5)     // Catch:{ JSONException -> 0x0084 }
        L_0x003c:
            java.lang.String r1 = r6.f6105e     // Catch:{ JSONException -> 0x0084 }
            if (r1 == 0) goto L_0x0047
            java.lang.String r1 = "name"
            java.lang.String r5 = r6.f6105e     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r5)     // Catch:{ JSONException -> 0x0084 }
        L_0x0047:
            java.lang.String r1 = r6.f6106f     // Catch:{ JSONException -> 0x0084 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x0084 }
            if (r1 != 0) goto L_0x0056
            java.lang.String r1 = "language"
            java.lang.String r5 = r6.f6106f     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r5)     // Catch:{ JSONException -> 0x0084 }
        L_0x0056:
            int r1 = r6.f6107g     // Catch:{ JSONException -> 0x0084 }
            java.lang.String r5 = "subtype"
            if (r1 == r4) goto L_0x0076
            if (r1 == r3) goto L_0x0073
            if (r1 == r2) goto L_0x0070
            r2 = 4
            if (r1 == r2) goto L_0x006d
            r2 = 5
            if (r1 == r2) goto L_0x0067
            goto L_0x0079
        L_0x0067:
            java.lang.String r1 = "METADATA"
        L_0x0069:
            r0.put(r5, r1)     // Catch:{ JSONException -> 0x0084 }
            goto L_0x0079
        L_0x006d:
            java.lang.String r1 = "CHAPTERS"
            goto L_0x0069
        L_0x0070:
            java.lang.String r1 = "DESCRIPTIONS"
            goto L_0x0069
        L_0x0073:
            java.lang.String r1 = "CAPTIONS"
            goto L_0x0069
        L_0x0076:
            java.lang.String r1 = "SUBTITLES"
            goto L_0x0069
        L_0x0079:
            org.json.JSONObject r1 = r6.i     // Catch:{ JSONException -> 0x0084 }
            if (r1 == 0) goto L_0x0084
            java.lang.String r1 = "customData"
            org.json.JSONObject r2 = r6.i     // Catch:{ JSONException -> 0x0084 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x0084 }
        L_0x0084:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaTrack.p():org.json.JSONObject");
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.i;
        this.h = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6101a);
        d.a(parcel, 3, this.f6102b);
        d.a(parcel, 4, this.f6103c, false);
        d.a(parcel, 5, this.f6104d, false);
        d.a(parcel, 6, this.f6105e, false);
        d.a(parcel, 7, this.f6106f, false);
        d.a(parcel, 8, this.f6107g);
        d.a(parcel, 9, this.h, false);
        d.b(parcel, a2);
    }
}
