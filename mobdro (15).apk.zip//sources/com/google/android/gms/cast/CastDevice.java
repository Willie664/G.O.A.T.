package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import b.c.a.b.c.i.a;
import b.c.a.b.c.l1;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CastDevice extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<CastDevice> CREATOR = new l1();

    /* renamed from: a  reason: collision with root package name */
    public String f6028a;

    /* renamed from: b  reason: collision with root package name */
    public String f6029b;

    /* renamed from: c  reason: collision with root package name */
    public InetAddress f6030c;

    /* renamed from: d  reason: collision with root package name */
    public String f6031d;

    /* renamed from: e  reason: collision with root package name */
    public String f6032e;

    /* renamed from: f  reason: collision with root package name */
    public String f6033f;

    /* renamed from: g  reason: collision with root package name */
    public int f6034g;
    public List<WebImage> h;
    public int i;
    public int j;
    public String k;
    public String l;
    public int m;
    public String n;
    public byte[] o;
    public String p;

    public CastDevice(String str, String str2, String str3, String str4, String str5, int i2, List<WebImage> list, int i3, int i4, String str6, String str7, int i5, String str8, byte[] bArr, String str9) {
        String str10 = "";
        this.f6028a = str == null ? str10 : str;
        String str11 = str2 == null ? str10 : str2;
        this.f6029b = str11;
        if (!TextUtils.isEmpty(str11)) {
            try {
                this.f6030c = InetAddress.getByName(this.f6029b);
            } catch (UnknownHostException e2) {
                String str12 = this.f6029b;
                String message = e2.getMessage();
                String.valueOf(str12).length();
                String.valueOf(message).length();
            }
        }
        this.f6031d = str3 == null ? str10 : str3;
        this.f6032e = str4 == null ? str10 : str4;
        this.f6033f = str5 == null ? str10 : str5;
        this.f6034g = i2;
        this.h = list != null ? list : new ArrayList<>();
        this.i = i3;
        this.j = i4;
        this.k = str6 != null ? str6 : str10;
        this.l = str7;
        this.m = i5;
        this.n = str8;
        this.o = bArr;
        this.p = str9;
    }

    public static CastDevice a(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(CastDevice.class.getClassLoader());
        return (CastDevice) bundle.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
    }

    public boolean a(int i2) {
        return (this.i & i2) == i2;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CastDevice)) {
            return false;
        }
        CastDevice castDevice = (CastDevice) obj;
        String str = this.f6028a;
        return str == null ? castDevice.f6028a == null : a.a(str, castDevice.f6028a) && a.a(this.f6030c, castDevice.f6030c) && a.a(this.f6032e, castDevice.f6032e) && a.a(this.f6031d, castDevice.f6031d) && a.a(this.f6033f, castDevice.f6033f) && this.f6034g == castDevice.f6034g && a.a(this.h, castDevice.h) && this.i == castDevice.i && this.j == castDevice.j && a.a(this.k, castDevice.k) && a.a(Integer.valueOf(this.m), Integer.valueOf(castDevice.m)) && a.a(this.n, castDevice.n) && a.a(this.l, castDevice.l) && a.a(this.f6033f, castDevice.f6033f) && this.f6034g == castDevice.f6034g && ((this.o == null && castDevice.o == null) || Arrays.equals(this.o, castDevice.o)) && a.a(this.p, castDevice.p);
    }

    public int hashCode() {
        String str = this.f6028a;
        if (str == null) {
            return 0;
        }
        return str.hashCode();
    }

    public String p() {
        return this.f6028a.startsWith("__cast_nearby__") ? this.f6028a.substring(16) : this.f6028a;
    }

    public String toString() {
        return String.format("\"%s\" (%s)", new Object[]{this.f6031d, this.f6028a});
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6028a, false);
        d.a(parcel, 3, this.f6029b, false);
        d.a(parcel, 4, this.f6031d, false);
        d.a(parcel, 5, this.f6032e, false);
        d.a(parcel, 6, this.f6033f, false);
        d.a(parcel, 7, this.f6034g);
        d.b(parcel, 8, Collections.unmodifiableList(this.h), false);
        d.a(parcel, 9, this.i);
        d.a(parcel, 10, this.j);
        d.a(parcel, 11, this.k, false);
        d.a(parcel, 12, this.l, false);
        d.a(parcel, 13, this.m);
        d.a(parcel, 14, this.n, false);
        byte[] bArr = this.o;
        if (bArr != null) {
            int a3 = d.a(parcel, 15);
            parcel.writeByteArray(bArr);
            d.b(parcel, a3);
        }
        d.a(parcel, 16, this.p, false);
        d.b(parcel, a2);
    }
}
