package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.g1;
import b.c.a.b.c.i.b;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public final class VideoInfo extends AbstractSafeParcelable {
    public static final Parcelable.Creator<VideoInfo> CREATOR = new g1();

    /* renamed from: d  reason: collision with root package name */
    public static final b f6117d = new b("VideoInfo");

    /* renamed from: a  reason: collision with root package name */
    public int f6118a;

    /* renamed from: b  reason: collision with root package name */
    public int f6119b;

    /* renamed from: c  reason: collision with root package name */
    public int f6120c;

    public VideoInfo(int i, int i2, int i3) {
        this.f6118a = i;
        this.f6119b = i2;
        this.f6120c = i3;
    }

    public static VideoInfo a(JSONObject jSONObject) {
        if (jSONObject == null) {
            return null;
        }
        try {
            String string = jSONObject.getString("hdrType");
            char c2 = 65535;
            int hashCode = string.hashCode();
            int i = 3;
            if (hashCode != 3218) {
                if (hashCode != 103158) {
                    if (hashCode != 113729) {
                        if (hashCode == 99136405) {
                            if (string.equals("hdr10")) {
                                c2 = 1;
                            }
                        }
                    } else if (string.equals("sdr")) {
                        c2 = 3;
                    }
                } else if (string.equals("hdr")) {
                    c2 = 2;
                }
            } else if (string.equals("dv")) {
                c2 = 0;
            }
            if (c2 != 0) {
                if (c2 == 1) {
                    i = 2;
                } else if (c2 == 2) {
                    i = 4;
                } else if (c2 != 3) {
                    b bVar = f6117d;
                    Object[] objArr = {string};
                    if (bVar.a()) {
                        bVar.b("Unknown HDR type: %s", objArr);
                    }
                    i = 0;
                } else {
                    i = 1;
                }
            }
            return new VideoInfo(jSONObject.getInt("width"), jSONObject.getInt("height"), i);
        } catch (JSONException e2) {
            b bVar2 = f6117d;
            Object[] objArr2 = {e2.getMessage()};
            if (bVar2.a()) {
                bVar2.b("Error while creating a VideoInfo instance from JSON: %s", objArr2);
            }
            return null;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof VideoInfo)) {
            return false;
        }
        VideoInfo videoInfo = (VideoInfo) obj;
        return this.f6119b == videoInfo.f6119b && this.f6118a == videoInfo.f6118a && this.f6120c == videoInfo.f6120c;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6119b), Integer.valueOf(this.f6118a), Integer.valueOf(this.f6120c)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6118a);
        d.a(parcel, 3, this.f6119b);
        d.a(parcel, 4, this.f6120c);
        d.b(parcel, a2);
    }
}
