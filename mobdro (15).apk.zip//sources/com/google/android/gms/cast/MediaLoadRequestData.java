package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.b;
import b.c.a.b.c.r0;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONObject;

public class MediaLoadRequestData extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaLoadRequestData> CREATOR = new r0();
    public static final b n = new b("MediaLoadRequestData");

    /* renamed from: a  reason: collision with root package name */
    public final MediaInfo f6060a;

    /* renamed from: b  reason: collision with root package name */
    public final MediaQueueData f6061b;

    /* renamed from: c  reason: collision with root package name */
    public final Boolean f6062c;

    /* renamed from: d  reason: collision with root package name */
    public final long f6063d;

    /* renamed from: e  reason: collision with root package name */
    public final double f6064e;

    /* renamed from: f  reason: collision with root package name */
    public final long[] f6065f;

    /* renamed from: g  reason: collision with root package name */
    public String f6066g;
    public final JSONObject h;
    public final String i;
    public final String j;
    public final String k;
    public final String l;
    public long m;

    public MediaLoadRequestData(MediaInfo mediaInfo, MediaQueueData mediaQueueData, Boolean bool, long j2, double d2, long[] jArr, JSONObject jSONObject, String str, String str2, String str3, String str4, long j3) {
        this.f6060a = mediaInfo;
        this.f6061b = mediaQueueData;
        this.f6062c = bool;
        this.f6063d = j2;
        this.f6064e = d2;
        this.f6065f = jArr;
        this.h = jSONObject;
        this.i = str;
        this.j = str2;
        this.k = str3;
        this.l = str4;
        this.m = j3;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaLoadRequestData)) {
            return false;
        }
        MediaLoadRequestData mediaLoadRequestData = (MediaLoadRequestData) obj;
        return e.a(this.h, mediaLoadRequestData.h) && b.a.b.w.e.c((Object) this.f6060a, (Object) mediaLoadRequestData.f6060a) && b.a.b.w.e.c((Object) this.f6061b, (Object) mediaLoadRequestData.f6061b) && b.a.b.w.e.c((Object) this.f6062c, (Object) mediaLoadRequestData.f6062c) && this.f6063d == mediaLoadRequestData.f6063d && this.f6064e == mediaLoadRequestData.f6064e && Arrays.equals(this.f6065f, mediaLoadRequestData.f6065f) && b.a.b.w.e.c((Object) this.i, (Object) mediaLoadRequestData.i) && b.a.b.w.e.c((Object) this.j, (Object) mediaLoadRequestData.j) && b.a.b.w.e.c((Object) this.k, (Object) mediaLoadRequestData.k) && b.a.b.w.e.c((Object) this.l, (Object) mediaLoadRequestData.l) && this.m == mediaLoadRequestData.m;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6060a, this.f6061b, this.f6062c, Long.valueOf(this.f6063d), Double.valueOf(this.f6064e), this.f6065f, String.valueOf(this.h), this.i, this.j, this.k, this.l, Long.valueOf(this.m)});
    }

    public void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.h;
        this.f6066g = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, (Parcelable) this.f6060a, i2, false);
        d.a(parcel, 3, (Parcelable) this.f6061b, i2, false);
        d.a(parcel, 4, this.f6062c, false);
        d.a(parcel, 5, this.f6063d);
        d.a(parcel, 6, this.f6064e);
        d.a(parcel, 7, this.f6065f, false);
        d.a(parcel, 8, this.f6066g, false);
        d.a(parcel, 9, this.i, false);
        d.a(parcel, 10, this.j, false);
        d.a(parcel, 11, this.k, false);
        d.a(parcel, 12, this.l, false);
        d.a(parcel, 13, this.m);
        d.b(parcel, a2);
    }
}
