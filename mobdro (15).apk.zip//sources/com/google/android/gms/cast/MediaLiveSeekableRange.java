package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.a;
import b.c.a.b.c.i.b;
import b.c.a.b.c.p0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaLiveSeekableRange extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaLiveSeekableRange> CREATOR = new p0();

    /* renamed from: e  reason: collision with root package name */
    public static final b f6055e = new b("MediaLiveSeekableRange");

    /* renamed from: a  reason: collision with root package name */
    public final long f6056a;

    /* renamed from: b  reason: collision with root package name */
    public final long f6057b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f6058c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f6059d;

    public MediaLiveSeekableRange(long j, long j2, boolean z, boolean z2) {
        this.f6056a = Math.max(j, 0);
        this.f6057b = Math.max(j2, 0);
        this.f6058c = z;
        this.f6059d = z2;
    }

    public static MediaLiveSeekableRange a(JSONObject jSONObject) {
        if (jSONObject != null && jSONObject.has("start") && jSONObject.has("end")) {
            try {
                return new MediaLiveSeekableRange(a.a(jSONObject.getDouble("start")), a.a(jSONObject.getDouble("end")), jSONObject.optBoolean("isMovingWindow"), jSONObject.optBoolean("isLiveDone"));
            } catch (JSONException unused) {
                b bVar = f6055e;
                String valueOf = String.valueOf(jSONObject);
                StringBuilder sb = new StringBuilder(valueOf.length() + 43);
                sb.append("Ignoring Malformed MediaLiveSeekableRange: ");
                sb.append(valueOf);
                bVar.b(sb.toString(), new Object[0]);
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaLiveSeekableRange)) {
            return false;
        }
        MediaLiveSeekableRange mediaLiveSeekableRange = (MediaLiveSeekableRange) obj;
        return this.f6056a == mediaLiveSeekableRange.f6056a && this.f6057b == mediaLiveSeekableRange.f6057b && this.f6058c == mediaLiveSeekableRange.f6058c && this.f6059d == mediaLiveSeekableRange.f6059d;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f6056a), Long.valueOf(this.f6057b), Boolean.valueOf(this.f6058c), Boolean.valueOf(this.f6059d)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6056a);
        d.a(parcel, 3, this.f6057b);
        d.a(parcel, 4, this.f6058c);
        d.a(parcel, 5, this.f6059d);
        d.b(parcel, a2);
    }
}
