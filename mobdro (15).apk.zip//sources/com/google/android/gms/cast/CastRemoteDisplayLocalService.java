package com.google.android.gms.cast;

import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.view.Display;
import androidx.annotation.VisibleForTesting;
import androidx.mediarouter.media.MediaRouter;
import b.a.b.w.e;
import b.c.a.b.c.c;
import b.c.a.b.c.f;
import b.c.a.b.c.k;
import b.c.a.b.c.p1;
import b.c.a.b.c.q1;
import b.c.a.b.c.r1;
import b.c.a.b.d.n.u.d;
import b.c.a.b.l.d0;
import b.c.a.b.l.h;
import b.c.a.b.l.j;
import b.c.a.b.l.s;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.cast.zzdr;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(19)
public abstract class CastRemoteDisplayLocalService extends Service {
    public static final b.c.a.b.c.i.b i = new b.c.a.b.c.i.b("CastRemoteDisplayLocalService");
    public static final Object j = new Object();
    public static AtomicBoolean k = new AtomicBoolean(false);
    public static CastRemoteDisplayLocalService l;

    /* renamed from: a  reason: collision with root package name */
    public WeakReference<a> f6035a;

    /* renamed from: b  reason: collision with root package name */
    public CastDevice f6036b;

    /* renamed from: c  reason: collision with root package name */
    public Display f6037c;

    /* renamed from: d  reason: collision with root package name */
    public Handler f6038d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f6039e = false;

    /* renamed from: f  reason: collision with root package name */
    public c f6040f;

    /* renamed from: g  reason: collision with root package name */
    public final MediaRouter.Callback f6041g = new r1(this);
    public final IBinder h = new b(this);

    public interface a {
        void a(Status status);
    }

    @VisibleForTesting
    public class b extends Binder {
        public b(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
        }
    }

    public static /* synthetic */ void a(CastRemoteDisplayLocalService castRemoteDisplayLocalService, boolean z) {
        castRemoteDisplayLocalService.a(z);
        throw null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0030, code lost:
        if (r1.f6038d == null) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x003a, code lost:
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x003c, code lost:
        r1.f6038d.post(new b.c.a.b.c.s1(r1, r4));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0046, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0047, code lost:
        r1.a(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x004a, code lost:
        throw null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004b, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void b(boolean r4) {
        /*
            b.c.a.b.c.i.b r0 = i
            r1 = 0
            java.lang.Object[] r2 = new java.lang.Object[r1]
            boolean r3 = r0.a()
            if (r3 != 0) goto L_0x000c
            goto L_0x0011
        L_0x000c:
            java.lang.String r3 = "Stopping Service"
            r0.b(r3, r2)
        L_0x0011:
            java.util.concurrent.atomic.AtomicBoolean r0 = k
            r0.set(r1)
            java.lang.Object r0 = j
            monitor-enter(r0)
            com.google.android.gms.cast.CastRemoteDisplayLocalService r2 = l     // Catch:{ all -> 0x004c }
            if (r2 != 0) goto L_0x0028
            b.c.a.b.c.i.b r4 = i     // Catch:{ all -> 0x004c }
            java.lang.String r2 = "Service is already being stopped"
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ all -> 0x004c }
            r4.b(r2, r1)     // Catch:{ all -> 0x004c }
            monitor-exit(r0)     // Catch:{ all -> 0x004c }
            return
        L_0x0028:
            com.google.android.gms.cast.CastRemoteDisplayLocalService r1 = l     // Catch:{ all -> 0x004c }
            r2 = 0
            l = r2     // Catch:{ all -> 0x004c }
            monitor-exit(r0)     // Catch:{ all -> 0x004c }
            android.os.Handler r0 = r1.f6038d
            if (r0 == 0) goto L_0x004b
            android.os.Looper r0 = android.os.Looper.myLooper()
            android.os.Looper r3 = android.os.Looper.getMainLooper()
            if (r0 == r3) goto L_0x0047
            android.os.Handler r0 = r1.f6038d
            b.c.a.b.c.s1 r2 = new b.c.a.b.c.s1
            r2.<init>(r1, r4)
            r0.post(r2)
            return
        L_0x0047:
            r1.a((boolean) r4)
            throw r2
        L_0x004b:
            return
        L_0x004c:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x004c }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.CastRemoteDisplayLocalService.b(boolean):void");
    }

    public final void a(boolean z) {
        a("Stopping Service");
        e.c("stopServiceInstanceInternal must be called on the main thread");
        a("stopRemoteDisplaySession");
        a("stopRemoteDisplay");
        c cVar = this.f6040f;
        if (cVar != null) {
            h a2 = cVar.a(1, new p1(cVar));
            k kVar = new k(this);
            d0 d0Var = (d0) a2;
            if (d0Var != null) {
                d0Var.f2714b.a(new s(j.f2722a, kVar));
                d0Var.f();
                throw null;
            }
            throw null;
        }
        throw null;
    }

    public IBinder onBind(Intent intent) {
        a("onBind");
        return this.h;
    }

    public void onCreate() {
        a("onCreate");
        super.onCreate();
        zzdr zzdr = new zzdr(getMainLooper());
        this.f6038d = zzdr;
        zzdr.postDelayed(new q1(this), 100);
        if (this.f6040f == null) {
            this.f6040f = b.c.a.b.c.b.a(this);
        }
        if (d.h()) {
            NotificationChannel notificationChannel = new NotificationChannel("cast_remote_display_local_service", getString(f.cast_notification_default_channel_name), 2);
            notificationChannel.setShowBadge(false);
            ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(notificationChannel);
        }
    }

    public int onStartCommand(Intent intent, int i2, int i3) {
        a("onStartCommand");
        this.f6039e = true;
        return 2;
    }

    public final void a(String str) {
        b.c.a.b.c.i.b bVar = i;
        Object[] objArr = {this, str};
        if (bVar.a()) {
            bVar.b("[Instance: %s] %s", objArr);
        }
    }
}
