package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.a;
import b.c.a.b.c.i.k0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.zzah;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzu extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzu> CREATOR = new k0();

    /* renamed from: a  reason: collision with root package name */
    public double f6220a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f6221b;

    /* renamed from: c  reason: collision with root package name */
    public int f6222c;

    /* renamed from: d  reason: collision with root package name */
    public ApplicationMetadata f6223d;

    /* renamed from: e  reason: collision with root package name */
    public int f6224e;

    /* renamed from: f  reason: collision with root package name */
    public zzah f6225f;

    /* renamed from: g  reason: collision with root package name */
    public double f6226g;

    public zzu() {
        this.f6220a = Double.NaN;
        this.f6221b = false;
        this.f6222c = -1;
        this.f6223d = null;
        this.f6224e = -1;
        this.f6225f = null;
        this.f6226g = Double.NaN;
    }

    public zzu(double d2, boolean z, int i, ApplicationMetadata applicationMetadata, int i2, zzah zzah, double d3) {
        this.f6220a = d2;
        this.f6221b = z;
        this.f6222c = i;
        this.f6223d = applicationMetadata;
        this.f6224e = i2;
        this.f6225f = zzah;
        this.f6226g = d3;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzu)) {
            return false;
        }
        zzu zzu = (zzu) obj;
        if (this.f6220a == zzu.f6220a && this.f6221b == zzu.f6221b && this.f6222c == zzu.f6222c && a.a(this.f6223d, zzu.f6223d) && this.f6224e == zzu.f6224e) {
            zzah zzah = this.f6225f;
            return a.a(zzah, zzah) && this.f6226g == zzu.f6226g;
        }
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Double.valueOf(this.f6220a), Boolean.valueOf(this.f6221b), Integer.valueOf(this.f6222c), this.f6223d, Integer.valueOf(this.f6224e), this.f6225f, Double.valueOf(this.f6226g)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6220a);
        d.a(parcel, 3, this.f6221b);
        d.a(parcel, 4, this.f6222c);
        d.a(parcel, 5, (Parcelable) this.f6223d, i, false);
        d.a(parcel, 6, this.f6224e);
        d.a(parcel, 7, (Parcelable) this.f6225f, i, false);
        d.a(parcel, 8, this.f6226g);
        d.b(parcel, a2);
    }
}
