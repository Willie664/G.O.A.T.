package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import b.c.a.b.c.g.w.c0;
import b.c.a.b.c.g.w.o0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

public class NotificationOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<NotificationOptions> CREATOR = new o0();
    public static final List<String> G = Arrays.asList(new String[]{MediaIntentReceiver.ACTION_TOGGLE_PLAYBACK, MediaIntentReceiver.ACTION_STOP_CASTING});
    public static final int[] H = {0, 1};
    public final int A;
    public final int B;
    public final int C;
    public final int D;
    public final int E;
    public final c0 F;

    /* renamed from: a  reason: collision with root package name */
    public final List<String> f6180a;

    /* renamed from: b  reason: collision with root package name */
    public final int[] f6181b;

    /* renamed from: c  reason: collision with root package name */
    public final long f6182c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6183d;

    /* renamed from: e  reason: collision with root package name */
    public final int f6184e;

    /* renamed from: f  reason: collision with root package name */
    public final int f6185f;

    /* renamed from: g  reason: collision with root package name */
    public final int f6186g;
    public final int h;
    public final int i;
    public final int j;
    public final int k;
    public final int l;
    public final int m;
    public final int n;
    public final int o;
    public final int p;
    public final int q;
    public final int r;
    public final int s;
    public final int t;
    public final int u;
    public final int v;
    public final int w;
    public final int x;
    public final int y;
    public final int z;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public String f6187a;

        /* renamed from: b  reason: collision with root package name */
        public List<String> f6188b = NotificationOptions.G;

        /* renamed from: c  reason: collision with root package name */
        public int[] f6189c = NotificationOptions.H;

        /* renamed from: d  reason: collision with root package name */
        public int f6190d = a("smallIconDrawableResId");

        /* renamed from: e  reason: collision with root package name */
        public int f6191e = a("stopLiveStreamDrawableResId");

        /* renamed from: f  reason: collision with root package name */
        public int f6192f = a("pauseDrawableResId");

        /* renamed from: g  reason: collision with root package name */
        public int f6193g = a("playDrawableResId");
        public int h = a("skipNextDrawableResId");
        public int i = a("skipPrevDrawableResId");
        public int j = a("forwardDrawableResId");
        public int k = a("forward10DrawableResId");
        public int l = a("forward30DrawableResId");
        public int m = a("rewindDrawableResId");
        public int n = a("rewind10DrawableResId");
        public int o = a("rewind30DrawableResId");
        public int p = a("disconnectDrawableResId");
        public long q = FragmentStateAdapter.GRACE_WINDOW_TIME_MS;

        public static int a(String str) {
            try {
                Integer num = (Integer) Class.forName("com.google.android.gms.cast.framework.media.internal.ResourceProvider").getMethod("findResourceByName", new Class[]{String.class}).invoke((Object) null, new Object[]{str});
                if (num == null) {
                    return 0;
                }
                return num.intValue();
            } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                return 0;
            }
        }

        public final NotificationOptions a() {
            return new NotificationOptions(this.f6188b, this.f6189c, this.q, this.f6187a, this.f6190d, this.f6191e, this.f6192f, this.f6193g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p, a("notificationImageSizeDimenResId"), a("castingToDeviceStringResId"), a("stopLiveStreamStringResId"), a("pauseStringResId"), a("playStringResId"), a("skipNextStringResId"), a("skipPrevStringResId"), a("forwardStringResId"), a("forward10StringResId"), a("forward30StringResId"), a("rewindStringResId"), a("rewind10StringResId"), a("rewind30StringResId"), a("disconnectStringResId"), (IBinder) null);
        }
    }

    /* JADX WARNING: type inference failed for: r1v31, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NotificationOptions(java.util.List<java.lang.String> r7, int[] r8, long r9, java.lang.String r11, int r12, int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20, int r21, int r22, int r23, int r24, int r25, int r26, int r27, int r28, int r29, int r30, int r31, int r32, int r33, int r34, int r35, int r36, int r37, int r38, android.os.IBinder r39) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r8
            r3 = r39
            r6.<init>()
            r4 = 0
            if (r1 == 0) goto L_0x0013
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>(r7)
            r0.f6180a = r5
            goto L_0x0015
        L_0x0013:
            r0.f6180a = r4
        L_0x0015:
            if (r2 == 0) goto L_0x001f
            int r1 = r2.length
            int[] r1 = java.util.Arrays.copyOf(r8, r1)
            r0.f6181b = r1
            goto L_0x0021
        L_0x001f:
            r0.f6181b = r4
        L_0x0021:
            r1 = r9
            r0.f6182c = r1
            r1 = r11
            r0.f6183d = r1
            r1 = r12
            r0.f6184e = r1
            r1 = r13
            r0.f6185f = r1
            r1 = r14
            r0.f6186g = r1
            r1 = r15
            r0.h = r1
            r1 = r16
            r0.i = r1
            r1 = r17
            r0.j = r1
            r1 = r18
            r0.k = r1
            r1 = r19
            r0.l = r1
            r1 = r20
            r0.m = r1
            r1 = r21
            r0.n = r1
            r1 = r22
            r0.o = r1
            r1 = r23
            r0.p = r1
            r1 = r24
            r0.q = r1
            r1 = r25
            r0.r = r1
            r1 = r26
            r0.s = r1
            r1 = r27
            r0.t = r1
            r1 = r28
            r0.u = r1
            r1 = r29
            r0.v = r1
            r1 = r30
            r0.w = r1
            r1 = r31
            r0.x = r1
            r1 = r32
            r0.y = r1
            r1 = r33
            r0.z = r1
            r1 = r34
            r0.A = r1
            r1 = r35
            r0.B = r1
            r1 = r36
            r0.C = r1
            r1 = r37
            r0.D = r1
            r1 = r38
            r0.E = r1
            if (r3 != 0) goto L_0x0092
            goto L_0x00a5
        L_0x0092:
            java.lang.String r1 = "com.google.android.gms.cast.framework.media.INotificationActionsProvider"
            android.os.IInterface r1 = r3.queryLocalInterface(r1)
            boolean r2 = r1 instanceof b.c.a.b.c.g.w.c0
            if (r2 == 0) goto L_0x00a0
            r4 = r1
            b.c.a.b.c.g.w.c0 r4 = (b.c.a.b.c.g.w.c0) r4
            goto L_0x00a5
        L_0x00a0:
            b.c.a.b.c.g.w.e0 r4 = new b.c.a.b.c.g.w.e0
            r4.<init>(r3)
        L_0x00a5:
            r0.F = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.NotificationOptions.<init>(java.util.List, int[], long, java.lang.String, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, android.os.IBinder):void");
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6180a, false);
        int[] iArr = this.f6181b;
        int[] copyOf = Arrays.copyOf(iArr, iArr.length);
        if (copyOf != null) {
            int a3 = d.a(parcel, 3);
            parcel.writeIntArray(copyOf);
            d.b(parcel, a3);
        }
        d.a(parcel, 4, this.f6182c);
        d.a(parcel, 5, this.f6183d, false);
        d.a(parcel, 6, this.f6184e);
        d.a(parcel, 7, this.f6185f);
        d.a(parcel, 8, this.f6186g);
        d.a(parcel, 9, this.h);
        d.a(parcel, 10, this.i);
        d.a(parcel, 11, this.j);
        d.a(parcel, 12, this.k);
        d.a(parcel, 13, this.l);
        d.a(parcel, 14, this.m);
        d.a(parcel, 15, this.n);
        d.a(parcel, 16, this.o);
        d.a(parcel, 17, this.p);
        d.a(parcel, 18, this.q);
        d.a(parcel, 19, this.r);
        d.a(parcel, 20, this.s);
        d.a(parcel, 21, this.t);
        d.a(parcel, 22, this.u);
        d.a(parcel, 23, this.v);
        d.a(parcel, 24, this.w);
        d.a(parcel, 25, this.x);
        d.a(parcel, 26, this.y);
        d.a(parcel, 27, this.z);
        d.a(parcel, 28, this.A);
        d.a(parcel, 29, this.B);
        d.a(parcel, 30, this.C);
        d.a(parcel, 31, this.D);
        d.a(parcel, 32, this.E);
        c0 c0Var = this.F;
        d.a(parcel, 33, c0Var == null ? null : c0Var.asBinder(), false);
        d.b(parcel, a2);
    }
}
