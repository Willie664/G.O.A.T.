package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.cardview.widget.RoundRectDrawableWithShadow;
import b.a.b.w.e;
import b.c.a.b.c.t0;
import b.c.a.b.c.u0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MediaQueueContainerMetadata extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaQueueContainerMetadata> CREATOR = new u0();

    /* renamed from: a  reason: collision with root package name */
    public int f6075a;

    /* renamed from: b  reason: collision with root package name */
    public String f6076b;

    /* renamed from: c  reason: collision with root package name */
    public List<MediaMetadata> f6077c;

    /* renamed from: d  reason: collision with root package name */
    public List<WebImage> f6078d;

    /* renamed from: e  reason: collision with root package name */
    public double f6079e;

    public MediaQueueContainerMetadata() {
        this.f6075a = 0;
        this.f6076b = null;
        this.f6077c = null;
        this.f6078d = null;
        this.f6079e = RoundRectDrawableWithShadow.COS_45;
    }

    public MediaQueueContainerMetadata(int i, String str, List<MediaMetadata> list, List<WebImage> list2, double d2) {
        this.f6075a = i;
        this.f6076b = str;
        this.f6077c = list;
        this.f6078d = list2;
        this.f6079e = d2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaQueueContainerMetadata)) {
            return false;
        }
        MediaQueueContainerMetadata mediaQueueContainerMetadata = (MediaQueueContainerMetadata) obj;
        return this.f6075a == mediaQueueContainerMetadata.f6075a && TextUtils.equals(this.f6076b, mediaQueueContainerMetadata.f6076b) && e.c((Object) this.f6077c, (Object) mediaQueueContainerMetadata.f6077c) && e.c((Object) this.f6078d, (Object) mediaQueueContainerMetadata.f6078d) && this.f6079e == mediaQueueContainerMetadata.f6079e;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6075a), this.f6076b, this.f6077c, this.f6078d, Double.valueOf(this.f6079e)});
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0020 A[Catch:{ JSONException -> 0x0077 }] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0044 A[Catch:{ JSONException -> 0x0077 }, LOOP:0: B:19:0x003e->B:21:0x0044, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.json.JSONObject p() {
        /*
            r4 = this;
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            int r1 = r4.f6075a     // Catch:{ JSONException -> 0x0077 }
            java.lang.String r2 = "containerType"
            if (r1 == 0) goto L_0x0015
            r3 = 1
            if (r1 == r3) goto L_0x000f
            goto L_0x0018
        L_0x000f:
            java.lang.String r1 = "AUDIOBOOK_CONTAINER"
        L_0x0011:
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x0077 }
            goto L_0x0018
        L_0x0015:
            java.lang.String r1 = "GENERIC_CONTAINER"
            goto L_0x0011
        L_0x0018:
            java.lang.String r1 = r4.f6076b     // Catch:{ JSONException -> 0x0077 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x0077 }
            if (r1 != 0) goto L_0x0027
            java.lang.String r1 = "title"
            java.lang.String r2 = r4.f6076b     // Catch:{ JSONException -> 0x0077 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x0077 }
        L_0x0027:
            java.util.List<com.google.android.gms.cast.MediaMetadata> r1 = r4.f6077c     // Catch:{ JSONException -> 0x0077 }
            if (r1 == 0) goto L_0x0057
            java.util.List<com.google.android.gms.cast.MediaMetadata> r1 = r4.f6077c     // Catch:{ JSONException -> 0x0077 }
            boolean r1 = r1.isEmpty()     // Catch:{ JSONException -> 0x0077 }
            if (r1 != 0) goto L_0x0057
            org.json.JSONArray r1 = new org.json.JSONArray     // Catch:{ JSONException -> 0x0077 }
            r1.<init>()     // Catch:{ JSONException -> 0x0077 }
            java.util.List<com.google.android.gms.cast.MediaMetadata> r2 = r4.f6077c     // Catch:{ JSONException -> 0x0077 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ JSONException -> 0x0077 }
        L_0x003e:
            boolean r3 = r2.hasNext()     // Catch:{ JSONException -> 0x0077 }
            if (r3 == 0) goto L_0x0052
            java.lang.Object r3 = r2.next()     // Catch:{ JSONException -> 0x0077 }
            com.google.android.gms.cast.MediaMetadata r3 = (com.google.android.gms.cast.MediaMetadata) r3     // Catch:{ JSONException -> 0x0077 }
            org.json.JSONObject r3 = r3.q()     // Catch:{ JSONException -> 0x0077 }
            r1.put(r3)     // Catch:{ JSONException -> 0x0077 }
            goto L_0x003e
        L_0x0052:
            java.lang.String r2 = "sections"
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x0077 }
        L_0x0057:
            java.util.List<com.google.android.gms.common.images.WebImage> r1 = r4.f6078d     // Catch:{ JSONException -> 0x0077 }
            if (r1 == 0) goto L_0x0070
            java.util.List<com.google.android.gms.common.images.WebImage> r1 = r4.f6078d     // Catch:{ JSONException -> 0x0077 }
            boolean r1 = r1.isEmpty()     // Catch:{ JSONException -> 0x0077 }
            if (r1 != 0) goto L_0x0070
            java.util.List<com.google.android.gms.common.images.WebImage> r1 = r4.f6078d     // Catch:{ JSONException -> 0x0077 }
            org.json.JSONArray r1 = b.c.a.b.c.i.c.a.a((java.util.List<com.google.android.gms.common.images.WebImage>) r1)     // Catch:{ JSONException -> 0x0077 }
            if (r1 == 0) goto L_0x0070
            java.lang.String r2 = "containerImages"
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x0077 }
        L_0x0070:
            java.lang.String r1 = "containerDuration"
            double r2 = r4.f6079e     // Catch:{ JSONException -> 0x0077 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x0077 }
        L_0x0077:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaQueueContainerMetadata.p():org.json.JSONObject");
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6075a);
        d.a(parcel, 3, this.f6076b, false);
        List<MediaMetadata> list = this.f6077c;
        List<T> list2 = null;
        d.b(parcel, 4, list == null ? null : Collections.unmodifiableList(list), false);
        List<WebImage> list3 = this.f6078d;
        if (list3 != null) {
            list2 = Collections.unmodifiableList(list3);
        }
        d.b(parcel, 5, list2, false);
        d.a(parcel, 6, this.f6079e);
        d.b(parcel, a2);
    }

    public /* synthetic */ MediaQueueContainerMetadata(MediaQueueContainerMetadata mediaQueueContainerMetadata, t0 t0Var) {
        this.f6075a = mediaQueueContainerMetadata.f6075a;
        this.f6076b = mediaQueueContainerMetadata.f6076b;
        this.f6077c = mediaQueueContainerMetadata.f6077c;
        this.f6078d = mediaQueueContainerMetadata.f6078d;
        this.f6079e = mediaQueueContainerMetadata.f6079e;
    }

    public /* synthetic */ MediaQueueContainerMetadata(t0 t0Var) {
        this.f6075a = 0;
        this.f6076b = null;
        this.f6077c = null;
        this.f6078d = null;
        this.f6079e = RoundRectDrawableWithShadow.COS_45;
    }
}
