package com.google.android.gms.cast.framework;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import b.c.a.b.c.g.e0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<CastOptions> CREATOR = new e0();

    /* renamed from: a  reason: collision with root package name */
    public String f6121a;

    /* renamed from: b  reason: collision with root package name */
    public final List<String> f6122b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f6123c;

    /* renamed from: d  reason: collision with root package name */
    public final LaunchOptions f6124d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f6125e;

    /* renamed from: f  reason: collision with root package name */
    public final CastMediaOptions f6126f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f6127g;
    public final double h;
    public final boolean i;

    public CastOptions(String str, List<String> list, boolean z, LaunchOptions launchOptions, boolean z2, CastMediaOptions castMediaOptions, boolean z3, double d2, boolean z4) {
        this.f6121a = TextUtils.isEmpty(str) ? "" : str;
        int size = list == null ? 0 : list.size();
        ArrayList arrayList = new ArrayList(size);
        this.f6122b = arrayList;
        if (size > 0) {
            arrayList.addAll(list);
        }
        this.f6123c = z;
        this.f6124d = launchOptions == null ? new LaunchOptions() : launchOptions;
        this.f6125e = z2;
        this.f6126f = castMediaOptions;
        this.f6127g = z3;
        this.h = d2;
        this.i = z4;
    }

    public List<String> p() {
        return Collections.unmodifiableList(this.f6122b);
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6121a, false);
        d.a(parcel, 3, p(), false);
        d.a(parcel, 4, this.f6123c);
        d.a(parcel, 5, (Parcelable) this.f6124d, i2, false);
        d.a(parcel, 6, this.f6125e);
        d.a(parcel, 7, (Parcelable) this.f6126f, i2, false);
        d.a(parcel, 8, this.f6127g);
        d.a(parcel, 9, this.h);
        d.a(parcel, 10, this.i);
        d.b(parcel, a2);
    }
}
