package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.a;
import b.c.a.b.c.m0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Locale;

public class LaunchOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<LaunchOptions> CREATOR = new m0();

    /* renamed from: a  reason: collision with root package name */
    public boolean f6042a;

    /* renamed from: b  reason: collision with root package name */
    public String f6043b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f6044c;

    public LaunchOptions() {
        String a2 = a.a(Locale.getDefault());
        this.f6042a = false;
        this.f6043b = a2;
        this.f6044c = false;
    }

    public LaunchOptions(boolean z, String str, boolean z2) {
        this.f6042a = z;
        this.f6043b = str;
        this.f6044c = z2;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LaunchOptions)) {
            return false;
        }
        LaunchOptions launchOptions = (LaunchOptions) obj;
        return this.f6042a == launchOptions.f6042a && a.a(this.f6043b, launchOptions.f6043b);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Boolean.valueOf(this.f6042a), this.f6043b});
    }

    public String toString() {
        return String.format("LaunchOptions(relaunchIfRunning=%b, language=%s, androidReceiverCompatible: %b)", new Object[]{Boolean.valueOf(this.f6042a), this.f6043b, Boolean.valueOf(this.f6044c)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6042a);
        d.a(parcel, 3, this.f6043b, false);
        d.a(parcel, 4, this.f6044c);
        d.b(parcel, a2);
    }
}
