package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import androidx.annotation.ColorInt;
import androidx.annotation.Keep;
import androidx.core.graphics.ColorUtils;
import b.c.a.b.c.g.i;
import b.c.a.b.c.g.j;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.internal.cast.zzef;

public class OuterHighlightDrawable extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final int f6137a;

    /* renamed from: b  reason: collision with root package name */
    public final int f6138b;

    /* renamed from: c  reason: collision with root package name */
    public final int f6139c;

    /* renamed from: d  reason: collision with root package name */
    public final Rect f6140d = new Rect();

    /* renamed from: e  reason: collision with root package name */
    public final Rect f6141e = new Rect();

    /* renamed from: f  reason: collision with root package name */
    public final Paint f6142f = new Paint();

    /* renamed from: g  reason: collision with root package name */
    public float f6143g;
    public float h = 1.0f;
    public float i;
    public float j;
    public float k = 0.0f;
    public float l = 0.0f;
    public int m = 244;

    public OuterHighlightDrawable(Context context) {
        int i2;
        if (d.g()) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(16843827, typedValue, true);
            i2 = ColorUtils.setAlphaComponent(typedValue.data, 244);
        } else {
            i2 = context.getResources().getColor(i.cast_libraries_material_featurehighlight_outer_highlight_default_color);
        }
        a(i2);
        this.f6142f.setAntiAlias(true);
        this.f6142f.setStyle(Paint.Style.FILL);
        Resources resources = context.getResources();
        this.f6137a = resources.getDimensionPixelSize(j.cast_libraries_material_featurehighlight_center_threshold);
        this.f6138b = resources.getDimensionPixelSize(j.cast_libraries_material_featurehighlight_center_horizontal_offset);
        this.f6139c = resources.getDimensionPixelSize(j.cast_libraries_material_featurehighlight_outer_padding);
    }

    public static float a(float f2, float f3, Rect rect) {
        float f4 = (float) rect.left;
        float f5 = (float) rect.top;
        float f6 = (float) rect.right;
        float f7 = (float) rect.bottom;
        float zza = zzef.zza(f2, f3, f4, f5);
        float zza2 = zzef.zza(f2, f3, f6, f5);
        float zza3 = zzef.zza(f2, f3, f6, f7);
        float zza4 = zzef.zza(f2, f3, f4, f7);
        if (zza <= zza2 || zza <= zza3 || zza <= zza4) {
            zza = (zza2 <= zza3 || zza2 <= zza4) ? zza3 > zza4 ? zza3 : zza4 : zza2;
        }
        return (float) Math.ceil((double) zza);
    }

    public final void a(@ColorInt int i2) {
        this.f6142f.setColor(i2);
        this.m = this.f6142f.getAlpha();
        invalidateSelf();
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(this.i + this.k, this.j + this.l, this.f6143g * this.h, this.f6142f);
    }

    public int getAlpha() {
        return this.f6142f.getAlpha();
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i2) {
        this.f6142f.setAlpha(i2);
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f6142f.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Keep
    public void setScale(float f2) {
        this.h = f2;
        invalidateSelf();
    }

    @Keep
    public void setTranslationX(float f2) {
        this.k = f2;
        invalidateSelf();
    }

    @Keep
    public void setTranslationY(float f2) {
        this.l = f2;
        invalidateSelf();
    }
}
