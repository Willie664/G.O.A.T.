package com.google.android.gms.cast.framework.media.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.SeekBar;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import b.a.b.w.e;
import b.c.a.b.c.g.h;
import b.c.a.b.c.g.j;
import b.c.a.b.c.g.p;
import b.c.a.b.c.g.q;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CastSeekBar extends View {
    @VisibleForTesting

    /* renamed from: a  reason: collision with root package name */
    public d f6195a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f6196b;

    /* renamed from: c  reason: collision with root package name */
    public Integer f6197c;
    @VisibleForTesting

    /* renamed from: d  reason: collision with root package name */
    public List<b> f6198d;
    @VisibleForTesting

    /* renamed from: e  reason: collision with root package name */
    public a f6199e;

    /* renamed from: f  reason: collision with root package name */
    public final float f6200f;

    /* renamed from: g  reason: collision with root package name */
    public final float f6201g;
    public final float h;
    public final float i;
    public final float j;
    public final Paint k;
    @ColorInt
    public final int l;
    @ColorInt
    public final int m;
    @ColorInt
    public final int n;
    @ColorInt
    public final int o;
    public int[] p;
    public Point q;
    public Runnable r;

    public static abstract class a {
        public void a(CastSeekBar castSeekBar) {
            throw null;
        }

        public void a(CastSeekBar castSeekBar, int i, boolean z) {
            throw null;
        }

        public void b(CastSeekBar castSeekBar) {
            throw null;
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public int f6202a;

        public b(int i) {
            this.f6202a = i;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof b) && this.f6202a == ((b) obj).f6202a;
        }

        public final int hashCode() {
            return Integer.valueOf(this.f6202a).hashCode();
        }
    }

    public class c extends View.AccessibilityDelegate {
        public /* synthetic */ c(b.c.a.b.c.g.w.h.a aVar) {
        }

        public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName(SeekBar.class.getName());
            accessibilityEvent.setItemCount(CastSeekBar.this.f6195a.f6205b);
            accessibilityEvent.setCurrentItemIndex(CastSeekBar.this.getProgress());
        }

        @TargetApi(16)
        public final void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName(SeekBar.class.getName());
            if (view.isEnabled()) {
                accessibilityNodeInfo.addAction(4096);
                accessibilityNodeInfo.addAction(8192);
            }
        }

        @TargetApi(16)
        public final boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            if (!view.isEnabled()) {
                return false;
            }
            if (super.performAccessibilityAction(view, i, bundle)) {
                return true;
            }
            if (i == 4096 || i == 8192) {
                CastSeekBar castSeekBar = CastSeekBar.this;
                castSeekBar.f6196b = true;
                a aVar = castSeekBar.f6199e;
                if (aVar != null) {
                    aVar.b(castSeekBar);
                }
                int i2 = CastSeekBar.this.f6195a.f6205b / 20;
                if (i == 8192) {
                    i2 = -i2;
                }
                CastSeekBar castSeekBar2 = CastSeekBar.this;
                castSeekBar2.a(castSeekBar2.getProgress() + i2);
                CastSeekBar castSeekBar3 = CastSeekBar.this;
                castSeekBar3.f6196b = false;
                a aVar2 = castSeekBar3.f6199e;
                if (aVar2 != null) {
                    aVar2.a(castSeekBar3);
                }
            }
            return false;
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public int f6204a;

        /* renamed from: b  reason: collision with root package name */
        public int f6205b;

        /* renamed from: c  reason: collision with root package name */
        public int f6206c;

        /* renamed from: d  reason: collision with root package name */
        public int f6207d;

        /* renamed from: e  reason: collision with root package name */
        public int f6208e;

        /* renamed from: f  reason: collision with root package name */
        public boolean f6209f;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof d)) {
                return false;
            }
            d dVar = (d) obj;
            return this.f6204a == dVar.f6204a && this.f6205b == dVar.f6205b && this.f6206c == dVar.f6206c && this.f6207d == dVar.f6207d && this.f6208e == dVar.f6208e && this.f6209f == dVar.f6209f;
        }

        public final int hashCode() {
            return Arrays.hashCode(new Object[]{Integer.valueOf(this.f6204a), Integer.valueOf(this.f6205b), Integer.valueOf(this.f6206c), Integer.valueOf(this.f6207d), Integer.valueOf(this.f6208e), Boolean.valueOf(this.f6209f)});
        }
    }

    public CastSeekBar(Context context) {
        this(context, (AttributeSet) null);
    }

    public CastSeekBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CastSeekBar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f6198d = new ArrayList();
        setAccessibilityDelegate(new c((b.c.a.b.c.g.w.h.a) null));
        Paint paint = new Paint(1);
        this.k = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f6200f = context.getResources().getDimension(j.cast_seek_bar_minimum_width);
        this.f6201g = context.getResources().getDimension(j.cast_seek_bar_minimum_height);
        this.h = context.getResources().getDimension(j.cast_seek_bar_progress_height) / 2.0f;
        this.i = context.getResources().getDimension(j.cast_seek_bar_thumb_size) / 2.0f;
        this.j = context.getResources().getDimension(j.cast_seek_bar_ad_break_radius);
        d dVar = new d();
        this.f6195a = dVar;
        dVar.f6205b = 1;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, q.CastExpandedController, h.castExpandedControllerStyle, p.CastExpandedController);
        int resourceId = obtainStyledAttributes.getResourceId(q.CastExpandedController_castSeekBarProgressAndThumbColor, 0);
        int resourceId2 = obtainStyledAttributes.getResourceId(q.CastExpandedController_castSeekBarSecondaryProgressColor, 0);
        int resourceId3 = obtainStyledAttributes.getResourceId(q.CastExpandedController_castSeekBarUnseekableProgressColor, 0);
        int resourceId4 = obtainStyledAttributes.getResourceId(q.CastExpandedController_castAdBreakMarkerColor, 0);
        this.l = context.getResources().getColor(resourceId);
        this.m = context.getResources().getColor(resourceId2);
        this.n = context.getResources().getColor(resourceId3);
        this.o = context.getResources().getColor(resourceId4);
        obtainStyledAttributes.recycle();
    }

    public final void a(int i2) {
        d dVar = this.f6195a;
        if (dVar.f6209f) {
            this.f6197c = Integer.valueOf(b.c.a.b.c.i.a.a(i2, dVar.f6207d, dVar.f6208e));
            a aVar = this.f6199e;
            if (aVar != null) {
                aVar.a(this, getProgress(), true);
            }
            Runnable runnable = this.r;
            if (runnable == null) {
                this.r = new b.c.a.b.c.g.w.h.b(this);
            } else {
                removeCallbacks(runnable);
            }
            postDelayed(this.r, 200);
            postInvalidate();
        }
    }

    public final void a(@NonNull Canvas canvas, int i2, int i3, int i4, int i5) {
        this.k.setColor(i5);
        int i6 = this.f6195a.f6205b;
        float f2 = (float) i4;
        float f3 = this.h;
        Canvas canvas2 = canvas;
        canvas2.drawRect(((((float) i2) * 1.0f) / ((float) i6)) * f2, -f3, ((((float) i3) * 1.0f) / ((float) i6)) * f2, f3, this.k);
    }

    public final int b(int i2) {
        int measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        double d2 = (double) i2;
        Double.isNaN(d2);
        double d3 = (double) measuredWidth;
        Double.isNaN(d3);
        double d4 = (d2 * 1.0d) / d3;
        double d5 = (double) this.f6195a.f6205b;
        Double.isNaN(d5);
        return (int) (d4 * d5);
    }

    public int getMaxProgress() {
        return this.f6195a.f6205b;
    }

    public int getProgress() {
        Integer num = this.f6197c;
        return num != null ? num.intValue() : this.f6195a.f6204a;
    }

    public void onDetachedFromWindow() {
        Runnable runnable = this.r;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        super.onDetachedFromWindow();
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x00e5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(@androidx.annotation.NonNull android.graphics.Canvas r12) {
        /*
            r11 = this;
            int r0 = r12.save()
            int r1 = r11.getPaddingLeft()
            float r1 = (float) r1
            int r2 = r11.getPaddingTop()
            float r2 = (float) r2
            r12.translate(r1, r2)
            int r1 = r11.getMeasuredWidth()
            int r2 = r11.getPaddingLeft()
            int r1 = r1 - r2
            int r2 = r11.getPaddingRight()
            int r1 = r1 - r2
            int r2 = r11.getMeasuredHeight()
            int r3 = r11.getPaddingTop()
            int r2 = r2 - r3
            int r3 = r11.getPaddingBottom()
            int r2 = r2 - r3
            int r9 = r11.getProgress()
            int r10 = r12.save()
            int r2 = r2 / 2
            float r2 = (float) r2
            r3 = 0
            r12.translate(r3, r2)
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r2 = r11.f6195a
            boolean r3 = r2.f6209f
            if (r3 == 0) goto L_0x007a
            int r6 = r2.f6207d
            if (r6 <= 0) goto L_0x004f
            r5 = 0
            int r8 = r11.n
            r3 = r11
            r4 = r12
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x004f:
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r2 = r11.f6195a
            int r5 = r2.f6207d
            if (r9 <= r5) goto L_0x005e
            int r8 = r11.l
            r3 = r11
            r4 = r12
            r6 = r9
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x005e:
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r2 = r11.f6195a
            int r6 = r2.f6208e
            if (r6 <= r9) goto L_0x006d
            int r8 = r11.m
            r3 = r11
            r4 = r12
            r5 = r9
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x006d:
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r2 = r11.f6195a
            int r6 = r2.f6205b
            int r5 = r2.f6208e
            if (r6 <= r5) goto L_0x00a8
            int r8 = r11.n
            r3 = r11
            r4 = r12
            goto L_0x00a4
        L_0x007a:
            int r2 = r2.f6206c
            r3 = 0
            int r2 = java.lang.Math.max(r2, r3)
            if (r2 <= 0) goto L_0x008d
            r5 = 0
            int r8 = r11.n
            r3 = r11
            r4 = r12
            r6 = r2
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x008d:
            if (r9 <= r2) goto L_0x0099
            int r8 = r11.l
            r3 = r11
            r4 = r12
            r5 = r2
            r6 = r9
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x0099:
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r2 = r11.f6195a
            int r6 = r2.f6205b
            if (r6 <= r9) goto L_0x00a8
            int r8 = r11.n
            r3 = r11
            r4 = r12
            r5 = r9
        L_0x00a4:
            r7 = r1
            r3.a(r4, r5, r6, r7, r8)
        L_0x00a8:
            r12.restoreToCount(r10)
            java.util.List<com.google.android.gms.cast.framework.media.widget.CastSeekBar$b> r1 = r11.f6198d
            if (r1 == 0) goto L_0x010e
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L_0x00b6
            goto L_0x010e
        L_0x00b6:
            android.graphics.Paint r1 = r11.k
            int r2 = r11.o
            r1.setColor(r2)
            int r1 = r11.getMeasuredWidth()
            int r2 = r11.getPaddingLeft()
            int r1 = r1 - r2
            int r2 = r11.getPaddingRight()
            int r1 = r1 - r2
            int r2 = r11.getMeasuredHeight()
            int r3 = r11.getPaddingTop()
            int r2 = r2 - r3
            int r3 = r11.getPaddingBottom()
            int r2 = r2 - r3
            java.util.List<com.google.android.gms.cast.framework.media.widget.CastSeekBar$b> r3 = r11.f6198d
            java.util.Iterator r3 = r3.iterator()
        L_0x00df:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x010e
            java.lang.Object r4 = r3.next()
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$b r4 = (com.google.android.gms.cast.framework.media.widget.CastSeekBar.b) r4
            if (r4 == 0) goto L_0x00df
            int r4 = r4.f6202a
            if (r4 < 0) goto L_0x00df
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r5 = r11.f6195a
            int r5 = r5.f6205b
            int r4 = java.lang.Math.min(r4, r5)
            float r4 = (float) r4
            float r5 = (float) r1
            float r4 = r4 * r5
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r5 = r11.f6195a
            int r5 = r5.f6205b
            float r5 = (float) r5
            float r4 = r4 / r5
            int r5 = r2 / 2
            float r5 = (float) r5
            float r6 = r11.j
            android.graphics.Paint r7 = r11.k
            r12.drawCircle(r4, r5, r6, r7)
            goto L_0x00df
        L_0x010e:
            boolean r1 = r11.isEnabled()
            if (r1 == 0) goto L_0x016d
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r1 = r11.f6195a
            boolean r1 = r1.f6209f
            if (r1 != 0) goto L_0x011b
            goto L_0x016d
        L_0x011b:
            android.graphics.Paint r1 = r11.k
            int r2 = r11.l
            r1.setColor(r2)
            int r1 = r11.getMeasuredWidth()
            int r2 = r11.getPaddingLeft()
            int r1 = r1 - r2
            int r2 = r11.getPaddingRight()
            int r1 = r1 - r2
            int r2 = r11.getMeasuredHeight()
            int r3 = r11.getPaddingTop()
            int r2 = r2 - r3
            int r3 = r11.getPaddingBottom()
            int r2 = r2 - r3
            r3 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r5 = r11.getProgress()
            double r5 = (double) r5
            java.lang.Double.isNaN(r5)
            double r5 = r5 * r3
            com.google.android.gms.cast.framework.media.widget.CastSeekBar$d r3 = r11.f6195a
            int r3 = r3.f6205b
            double r3 = (double) r3
            java.lang.Double.isNaN(r3)
            double r5 = r5 / r3
            double r3 = (double) r1
            java.lang.Double.isNaN(r3)
            double r5 = r5 * r3
            int r1 = (int) r5
            int r3 = r12.save()
            float r1 = (float) r1
            float r2 = (float) r2
            r4 = 1073741824(0x40000000, float:2.0)
            float r2 = r2 / r4
            float r4 = r11.i
            android.graphics.Paint r5 = r11.k
            r12.drawCircle(r1, r2, r4, r5)
            r12.restoreToCount(r3)
        L_0x016d:
            r12.restoreToCount(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.widget.CastSeekBar.onDraw(android.graphics.Canvas):void");
    }

    public synchronized void onMeasure(int i2, int i3) {
        setMeasuredDimension(View.resolveSizeAndState((int) (this.f6200f + ((float) getPaddingLeft()) + ((float) getPaddingRight())), i2, 0), View.resolveSizeAndState((int) (this.f6201g + ((float) getPaddingTop()) + ((float) getPaddingBottom())), i3, 0));
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled() || !this.f6195a.f6209f) {
            return false;
        }
        if (this.q == null) {
            this.q = new Point();
        }
        if (this.p == null) {
            this.p = new int[2];
        }
        getLocationOnScreen(this.p);
        this.q.set((((int) motionEvent.getRawX()) - this.p[0]) - getPaddingLeft(), ((int) motionEvent.getRawY()) - this.p[1]);
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f6196b = true;
            a aVar = this.f6199e;
            if (aVar != null) {
                aVar.b(this);
            }
        } else if (action == 1) {
            a(b(this.q.x));
            this.f6196b = false;
            a aVar2 = this.f6199e;
            if (aVar2 != null) {
                aVar2.a(this);
            }
            return true;
        } else if (action != 2) {
            if (action != 3) {
                return false;
            }
            this.f6196b = false;
            this.f6197c = null;
            a aVar3 = this.f6199e;
            if (aVar3 != null) {
                aVar3.a(this, getProgress(), true);
                this.f6199e.a(this);
            }
            postInvalidate();
            return true;
        }
        a(b(this.q.x));
        return true;
    }

    public final void setAdBreaks(List<b> list) {
        if (!e.c((Object) this.f6198d, (Object) list)) {
            this.f6198d = list == null ? null : new ArrayList(list);
            postInvalidate();
        }
    }
}
