package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.cardview.widget.RoundRectDrawableWithShadow;
import androidx.transition.Transition;
import b.c.a.b.c.i.a;
import b.c.a.b.c.x0;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaQueueItem extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaQueueItem> CREATOR = new x0();

    /* renamed from: a  reason: collision with root package name */
    public MediaInfo f6087a;

    /* renamed from: b  reason: collision with root package name */
    public int f6088b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f6089c;

    /* renamed from: d  reason: collision with root package name */
    public double f6090d;

    /* renamed from: e  reason: collision with root package name */
    public double f6091e;

    /* renamed from: f  reason: collision with root package name */
    public double f6092f;

    /* renamed from: g  reason: collision with root package name */
    public long[] f6093g;
    public String h;
    public JSONObject i;

    public MediaQueueItem(MediaInfo mediaInfo, int i2, boolean z, double d2, double d3, double d4, long[] jArr, String str) {
        this.f6090d = Double.NaN;
        this.f6087a = mediaInfo;
        this.f6088b = i2;
        this.f6089c = z;
        this.f6090d = d2;
        this.f6091e = d3;
        this.f6092f = d4;
        this.f6093g = jArr;
        this.h = str;
        if (str != null) {
            try {
                this.i = new JSONObject(this.h);
            } catch (JSONException unused) {
                this.i = null;
                this.h = null;
            }
        } else {
            this.i = null;
        }
    }

    public MediaQueueItem(JSONObject jSONObject) throws JSONException {
        this((MediaInfo) null, 0, true, Double.NaN, Double.POSITIVE_INFINITY, RoundRectDrawableWithShadow.COS_45, (long[]) null, (String) null);
        a(jSONObject);
    }

    public boolean a(JSONObject jSONObject) throws JSONException {
        boolean z;
        boolean z2;
        int i2;
        boolean z3 = false;
        if (jSONObject.has("media")) {
            this.f6087a = new MediaInfo(jSONObject.getJSONObject("media"));
            z = true;
        } else {
            z = false;
        }
        if (jSONObject.has(Transition.MATCH_ITEM_ID_STR) && this.f6088b != (i2 = jSONObject.getInt(Transition.MATCH_ITEM_ID_STR))) {
            this.f6088b = i2;
            z = true;
        }
        if (jSONObject.has("autoplay") && this.f6089c != (z2 = jSONObject.getBoolean("autoplay"))) {
            this.f6089c = z2;
            z = true;
        }
        double optDouble = jSONObject.optDouble("startTime");
        if (Double.isNaN(optDouble) != Double.isNaN(this.f6090d) || (!Double.isNaN(optDouble) && Math.abs(optDouble - this.f6090d) > 1.0E-7d)) {
            this.f6090d = optDouble;
            z = true;
        }
        if (jSONObject.has("playbackDuration")) {
            double d2 = jSONObject.getDouble("playbackDuration");
            if (Math.abs(d2 - this.f6091e) > 1.0E-7d) {
                this.f6091e = d2;
                z = true;
            }
        }
        if (jSONObject.has("preloadTime")) {
            double d3 = jSONObject.getDouble("preloadTime");
            if (Math.abs(d3 - this.f6092f) > 1.0E-7d) {
                this.f6092f = d3;
                z = true;
            }
        }
        long[] jArr = null;
        if (jSONObject.has("activeTrackIds")) {
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            long[] jArr2 = new long[length];
            for (int i3 = 0; i3 < length; i3++) {
                jArr2[i3] = jSONArray.getLong(i3);
            }
            long[] jArr3 = this.f6093g;
            if (jArr3 != null && jArr3.length == length) {
                int i4 = 0;
                while (true) {
                    if (i4 >= length) {
                        jArr = jArr2;
                        break;
                    } else if (this.f6093g[i4] != jArr2[i4]) {
                        break;
                    } else {
                        i4++;
                    }
                }
            }
            jArr = jArr2;
            z3 = true;
        }
        if (z3) {
            this.f6093g = jArr;
            z = true;
        }
        if (!jSONObject.has("customData")) {
            return z;
        }
        this.i = jSONObject.getJSONObject("customData");
        return true;
    }

    public boolean equals(Object obj) {
        JSONObject jSONObject;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaQueueItem)) {
            return false;
        }
        MediaQueueItem mediaQueueItem = (MediaQueueItem) obj;
        if ((this.i == null) != (mediaQueueItem.i == null)) {
            return false;
        }
        JSONObject jSONObject2 = this.i;
        return (jSONObject2 == null || (jSONObject = mediaQueueItem.i) == null || e.a(jSONObject2, jSONObject)) && a.a(this.f6087a, mediaQueueItem.f6087a) && this.f6088b == mediaQueueItem.f6088b && this.f6089c == mediaQueueItem.f6089c && ((Double.isNaN(this.f6090d) && Double.isNaN(mediaQueueItem.f6090d)) || this.f6090d == mediaQueueItem.f6090d) && this.f6091e == mediaQueueItem.f6091e && this.f6092f == mediaQueueItem.f6092f && Arrays.equals(this.f6093g, mediaQueueItem.f6093g);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6087a, Integer.valueOf(this.f6088b), Boolean.valueOf(this.f6089c), Double.valueOf(this.f6090d), Double.valueOf(this.f6091e), Double.valueOf(this.f6092f), Integer.valueOf(Arrays.hashCode(this.f6093g)), String.valueOf(this.i)});
    }

    public JSONObject p() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.f6087a != null) {
                jSONObject.put("media", this.f6087a.p());
            }
            if (this.f6088b != 0) {
                jSONObject.put(Transition.MATCH_ITEM_ID_STR, this.f6088b);
            }
            jSONObject.put("autoplay", this.f6089c);
            if (!Double.isNaN(this.f6090d)) {
                jSONObject.put("startTime", this.f6090d);
            }
            if (this.f6091e != Double.POSITIVE_INFINITY) {
                jSONObject.put("playbackDuration", this.f6091e);
            }
            jSONObject.put("preloadTime", this.f6092f);
            if (this.f6093g != null) {
                JSONArray jSONArray = new JSONArray();
                for (long put : this.f6093g) {
                    jSONArray.put(put);
                }
                jSONObject.put("activeTrackIds", jSONArray);
            }
            if (this.i != null) {
                jSONObject.put("customData", this.i);
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.i;
        this.h = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, (Parcelable) this.f6087a, i2, false);
        d.a(parcel, 3, this.f6088b);
        d.a(parcel, 4, this.f6089c);
        d.a(parcel, 5, this.f6090d);
        d.a(parcel, 6, this.f6091e);
        d.a(parcel, 7, this.f6092f);
        d.a(parcel, 8, this.f6093g, false);
        d.a(parcel, 9, this.h, false);
        d.b(parcel, a2);
    }
}
