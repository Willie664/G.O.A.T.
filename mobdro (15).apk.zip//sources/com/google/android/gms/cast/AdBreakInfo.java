package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.f0;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AdBreakInfo extends AbstractSafeParcelable {
    public static final Parcelable.Creator<AdBreakInfo> CREATOR = new f0();

    /* renamed from: a  reason: collision with root package name */
    public final long f6009a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6010b;

    /* renamed from: c  reason: collision with root package name */
    public final long f6011c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f6012d;

    /* renamed from: e  reason: collision with root package name */
    public String[] f6013e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f6014f;

    public AdBreakInfo(long j, String str, long j2, boolean z, String[] strArr, boolean z2) {
        this.f6009a = j;
        this.f6010b = str;
        this.f6011c = j2;
        this.f6012d = z;
        this.f6013e = strArr;
        this.f6014f = z2;
    }

    public static AdBreakInfo a(JSONObject jSONObject) {
        String[] strArr;
        if (jSONObject != null && jSONObject.has("id") && jSONObject.has("position")) {
            try {
                String string = jSONObject.getString("id");
                long a2 = a.a((double) jSONObject.getLong("position"));
                boolean optBoolean = jSONObject.optBoolean("isWatched");
                long a3 = a.a((double) jSONObject.optLong("duration"));
                JSONArray optJSONArray = jSONObject.optJSONArray("breakClipIds");
                if (optJSONArray != null) {
                    String[] strArr2 = new String[optJSONArray.length()];
                    for (int i = 0; i < optJSONArray.length(); i++) {
                        strArr2[i] = optJSONArray.getString(i);
                    }
                    strArr = strArr2;
                } else {
                    strArr = null;
                }
                return new AdBreakInfo(a2, string, a3, optBoolean, strArr, jSONObject.optBoolean("isEmbedded"));
            } catch (JSONException e2) {
                String.format(Locale.ROOT, "Error while creating an AdBreakInfo from JSON: %s", new Object[]{e2.getMessage()});
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AdBreakInfo)) {
            return false;
        }
        AdBreakInfo adBreakInfo = (AdBreakInfo) obj;
        return a.a(this.f6010b, adBreakInfo.f6010b) && this.f6009a == adBreakInfo.f6009a && this.f6011c == adBreakInfo.f6011c && this.f6012d == adBreakInfo.f6012d && Arrays.equals(this.f6013e, adBreakInfo.f6013e) && this.f6014f == adBreakInfo.f6014f;
    }

    public int hashCode() {
        return this.f6010b.hashCode();
    }

    public final JSONObject p() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("id", this.f6010b);
            jSONObject.put("position", a.a(this.f6009a));
            jSONObject.put("isWatched", this.f6012d);
            jSONObject.put("isEmbedded", this.f6014f);
            jSONObject.put("duration", a.a(this.f6011c));
            if (this.f6013e != null) {
                JSONArray jSONArray = new JSONArray();
                for (String put : this.f6013e) {
                    jSONArray.put(put);
                }
                jSONObject.put("breakClipIds", jSONArray);
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6009a);
        d.a(parcel, 3, this.f6010b, false);
        d.a(parcel, 4, this.f6011c);
        d.a(parcel, 5, this.f6012d);
        String[] strArr = this.f6013e;
        if (strArr != null) {
            int a3 = d.a(parcel, 6);
            parcel.writeStringArray(strArr);
            d.b(parcel, a3);
        }
        d.a(parcel, 7, this.f6014f);
        d.b(parcel, a2);
    }
}
