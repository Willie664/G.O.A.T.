package com.google.android.gms.cast.framework.media;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat;
import b.c.a.b.c.g.w.c0;
import b.c.a.b.c.g.w.h0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.images.WebImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MediaNotificationService extends Service {
    public static final b.c.a.b.c.i.b q = new b.c.a.b.c.i.b("MediaNotificationService");

    /* renamed from: a  reason: collision with root package name */
    public NotificationOptions f6161a;

    /* renamed from: b  reason: collision with root package name */
    public b.c.a.b.c.g.w.a f6162b;

    /* renamed from: c  reason: collision with root package name */
    public ComponentName f6163c;

    /* renamed from: d  reason: collision with root package name */
    public ComponentName f6164d;

    /* renamed from: e  reason: collision with root package name */
    public List<NotificationCompat.Action> f6165e = new ArrayList();

    /* renamed from: f  reason: collision with root package name */
    public int[] f6166f;

    /* renamed from: g  reason: collision with root package name */
    public long f6167g;
    public b.c.a.b.c.g.w.f.a h;
    public ImageHints i;
    public Resources j;
    public a k;
    public b l;
    public NotificationManager m;
    public Notification n;
    public b.c.a.b.c.g.b o;
    public final BroadcastReceiver p = new h0(this);

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final MediaSessionCompat.Token f6168a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f6169b;

        /* renamed from: c  reason: collision with root package name */
        public final int f6170c;

        /* renamed from: d  reason: collision with root package name */
        public final String f6171d;

        /* renamed from: e  reason: collision with root package name */
        public final String f6172e;

        /* renamed from: f  reason: collision with root package name */
        public final boolean f6173f;

        /* renamed from: g  reason: collision with root package name */
        public final boolean f6174g;

        public a(boolean z, int i, String str, String str2, MediaSessionCompat.Token token, boolean z2, boolean z3) {
            this.f6169b = z;
            this.f6170c = i;
            this.f6171d = str;
            this.f6172e = str2;
            this.f6168a = token;
            this.f6173f = z2;
            this.f6174g = z3;
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final Uri f6175a;

        /* renamed from: b  reason: collision with root package name */
        public Bitmap f6176b;

        public b(WebImage webImage) {
            this.f6175a = webImage == null ? null : webImage.f6274b;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0090 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean a(com.google.android.gms.cast.framework.CastOptions r7) {
        /*
            java.lang.Class<b.c.a.b.c.g.w.c> r0 = b.c.a.b.c.g.w.c.class
            com.google.android.gms.cast.framework.media.CastMediaOptions r7 = r7.f6126f
            com.google.android.gms.cast.framework.media.NotificationOptions r7 = r7.f6155d
            r1 = 0
            if (r7 != 0) goto L_0x000a
            return r1
        L_0x000a:
            b.c.a.b.c.g.w.c0 r7 = r7.F
            r2 = 1
            if (r7 != 0) goto L_0x0010
            return r2
        L_0x0010:
            java.util.List r3 = a((b.c.a.b.c.g.w.c0) r7)
            int[] r7 = b(r7)
            if (r3 == 0) goto L_0x003c
            boolean r4 = r3.isEmpty()
            if (r4 == 0) goto L_0x0021
            goto L_0x003c
        L_0x0021:
            int r4 = r3.size()
            r5 = 5
            if (r4 <= r5) goto L_0x003a
            b.c.a.b.c.i.b r4 = q
            java.lang.String r5 = r0.getSimpleName()
            java.lang.String r6 = " provides more than 5 actions."
            java.lang.String r5 = r5.concat(r6)
            java.lang.Object[] r6 = new java.lang.Object[r1]
            r4.b(r5, r6)
            goto L_0x004d
        L_0x003a:
            r4 = 1
            goto L_0x004e
        L_0x003c:
            b.c.a.b.c.i.b r4 = q
            java.lang.String r5 = r0.getSimpleName()
            java.lang.String r6 = " doesn't provide any action."
            java.lang.String r5 = r5.concat(r6)
            java.lang.Object[] r6 = new java.lang.Object[r1]
            r4.b(r5, r6)
        L_0x004d:
            r4 = 0
        L_0x004e:
            if (r4 == 0) goto L_0x0091
            int r3 = r3.size()
            if (r7 == 0) goto L_0x007c
            int r4 = r7.length
            if (r4 != 0) goto L_0x005a
            goto L_0x007c
        L_0x005a:
            int r4 = r7.length
            r5 = 0
        L_0x005c:
            if (r5 >= r4) goto L_0x007a
            r6 = r7[r5]
            if (r6 < 0) goto L_0x0068
            if (r6 < r3) goto L_0x0065
            goto L_0x0068
        L_0x0065:
            int r5 = r5 + 1
            goto L_0x005c
        L_0x0068:
            b.c.a.b.c.i.b r7 = q
            java.lang.String r0 = r0.getSimpleName()
            java.lang.String r3 = "provides a compact view action whose index is out of bounds."
            java.lang.String r0 = r0.concat(r3)
            java.lang.Object[] r3 = new java.lang.Object[r1]
            r7.b(r0, r3)
            goto L_0x008d
        L_0x007a:
            r7 = 1
            goto L_0x008e
        L_0x007c:
            b.c.a.b.c.i.b r7 = q
            java.lang.String r0 = r0.getSimpleName()
            java.lang.String r3 = " doesn't provide any actions for compact view."
            java.lang.String r0 = r0.concat(r3)
            java.lang.Object[] r3 = new java.lang.Object[r1]
            r7.b(r0, r3)
        L_0x008d:
            r7 = 0
        L_0x008e:
            if (r7 == 0) goto L_0x0091
            return r2
        L_0x0091:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.MediaNotificationService.a(com.google.android.gms.cast.framework.CastOptions):boolean");
    }

    public static int[] b(c0 c0Var) {
        try {
            return c0Var.d();
        } catch (RemoteException unused) {
            q.b("Unable to call %s on %s.", "getCompactViewActionIndices", c0.class.getSimpleName());
            return null;
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        this.m = (NotificationManager) getSystemService("notification");
        b.c.a.b.c.g.b a2 = b.c.a.b.c.g.b.a((Context) this);
        this.o = a2;
        CastMediaOptions castMediaOptions = a2.a().f6126f;
        this.f6161a = castMediaOptions.f6155d;
        this.f6162b = castMediaOptions.p();
        this.j = getResources();
        this.f6163c = new ComponentName(getApplicationContext(), castMediaOptions.f6152a);
        this.f6164d = !TextUtils.isEmpty(this.f6161a.f6183d) ? new ComponentName(getApplicationContext(), this.f6161a.f6183d) : null;
        NotificationOptions notificationOptions = this.f6161a;
        this.f6167g = notificationOptions.f6182c;
        int dimensionPixelSize = this.j.getDimensionPixelSize(notificationOptions.r);
        this.i = new ImageHints(1, dimensionPixelSize, dimensionPixelSize);
        this.h = new b.c.a.b.c.g.w.f.a(getApplicationContext(), this.i);
        if (this.f6164d != null) {
            registerReceiver(this.p, new IntentFilter(this.f6164d.flattenToString()));
        }
        if (d.h()) {
            NotificationChannel notificationChannel = new NotificationChannel("cast_media_notification", "Cast", 2);
            notificationChannel.setShowBadge(false);
            this.m.createNotificationChannel(notificationChannel);
        }
    }

    public void onDestroy() {
        b.c.a.b.c.g.w.f.a aVar = this.h;
        if (aVar != null) {
            aVar.a();
        }
        if (this.f6164d != null) {
            try {
                unregisterReceiver(this.p);
            } catch (IllegalArgumentException unused) {
                q.b("Unregistering trampoline BroadcastReceiver failed", new Object[0]);
            }
        }
        this.m.cancel(1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0088, code lost:
        if ((r1 != null && r7.f6169b == r1.f6169b && r7.f6170c == r1.f6170c && b.c.a.b.c.i.a.a(r7.f6171d, r1.f6171d) && b.c.a.b.c.i.a.a(r7.f6172e, r1.f6172e) && r7.f6173f == r1.f6173f && r7.f6174g == r1.f6174g) == false) goto L_0x008a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int onStartCommand(@androidx.annotation.NonNull android.content.Intent r17, int r18, int r19) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            java.lang.String r2 = "extra_media_info"
            android.os.Parcelable r2 = r1.getParcelableExtra(r2)
            com.google.android.gms.cast.MediaInfo r2 = (com.google.android.gms.cast.MediaInfo) r2
            com.google.android.gms.cast.MediaMetadata r3 = r2.f6051d
            r4 = 0
            java.lang.String r5 = "extra_remote_media_client_player_state"
            int r5 = r1.getIntExtra(r5, r4)
            java.lang.String r6 = "extra_cast_device"
            android.os.Parcelable r6 = r1.getParcelableExtra(r6)
            com.google.android.gms.cast.CastDevice r6 = (com.google.android.gms.cast.CastDevice) r6
            com.google.android.gms.cast.framework.media.MediaNotificationService$a r15 = new com.google.android.gms.cast.framework.media.MediaNotificationService$a
            r14 = 2
            r13 = 1
            if (r5 != r14) goto L_0x0025
            r8 = 1
            goto L_0x0026
        L_0x0025:
            r8 = 0
        L_0x0026:
            int r9 = r2.f6049b
            java.lang.String r2 = "com.google.android.gms.cast.metadata.TITLE"
            java.lang.String r10 = r3.c(r2)
            java.lang.String r11 = r6.f6031d
            java.lang.String r2 = "extra_media_session_token"
            android.os.Parcelable r2 = r1.getParcelableExtra(r2)
            r12 = r2
            android.support.v4.media.session.MediaSessionCompat$Token r12 = (android.support.v4.media.session.MediaSessionCompat.Token) r12
            java.lang.String r2 = "extra_can_skip_next"
            boolean r2 = r1.getBooleanExtra(r2, r4)
            java.lang.String r5 = "extra_can_skip_prev"
            boolean r5 = r1.getBooleanExtra(r5, r4)
            r7 = r15
            r6 = 1
            r13 = r2
            r2 = 2
            r14 = r5
            r7.<init>(r8, r9, r10, r11, r12, r13, r14)
            java.lang.String r5 = "extra_media_notification_force_update"
            boolean r1 = r1.getBooleanExtra(r5, r4)
            if (r1 != 0) goto L_0x008a
            com.google.android.gms.cast.framework.media.MediaNotificationService$a r1 = r0.k
            if (r1 == 0) goto L_0x0087
            boolean r5 = r15.f6169b
            boolean r7 = r1.f6169b
            if (r5 != r7) goto L_0x0087
            int r5 = r15.f6170c
            int r7 = r1.f6170c
            if (r5 != r7) goto L_0x0087
            java.lang.String r5 = r15.f6171d
            java.lang.String r7 = r1.f6171d
            boolean r5 = b.c.a.b.c.i.a.a(r5, r7)
            if (r5 == 0) goto L_0x0087
            java.lang.String r5 = r15.f6172e
            java.lang.String r7 = r1.f6172e
            boolean r5 = b.c.a.b.c.i.a.a(r5, r7)
            if (r5 == 0) goto L_0x0087
            boolean r5 = r15.f6173f
            boolean r7 = r1.f6173f
            if (r5 != r7) goto L_0x0087
            boolean r5 = r15.f6174g
            boolean r1 = r1.f6174g
            if (r5 != r1) goto L_0x0087
            r13 = 1
            goto L_0x0088
        L_0x0087:
            r13 = 0
        L_0x0088:
            if (r13 != 0) goto L_0x008f
        L_0x008a:
            r0.k = r15
            r16.a()
        L_0x008f:
            com.google.android.gms.cast.framework.media.MediaNotificationService$b r1 = new com.google.android.gms.cast.framework.media.MediaNotificationService$b
            b.c.a.b.c.g.w.a r5 = r0.f6162b
            if (r5 == 0) goto L_0x009c
            com.google.android.gms.cast.framework.media.ImageHints r7 = r0.i
            com.google.android.gms.common.images.WebImage r3 = r5.a(r3, r7)
            goto L_0x00ac
        L_0x009c:
            boolean r5 = r3.p()
            if (r5 == 0) goto L_0x00ab
            java.util.List<com.google.android.gms.common.images.WebImage> r3 = r3.f6069a
            java.lang.Object r3 = r3.get(r4)
            com.google.android.gms.common.images.WebImage r3 = (com.google.android.gms.common.images.WebImage) r3
            goto L_0x00ac
        L_0x00ab:
            r3 = 0
        L_0x00ac:
            r1.<init>(r3)
            com.google.android.gms.cast.framework.media.MediaNotificationService$b r3 = r0.l
            if (r3 == 0) goto L_0x00be
            android.net.Uri r5 = r1.f6175a
            android.net.Uri r3 = r3.f6175a
            boolean r3 = b.c.a.b.c.i.a.a(r5, r3)
            if (r3 == 0) goto L_0x00be
            r4 = 1
        L_0x00be:
            if (r4 != 0) goto L_0x00d0
            b.c.a.b.c.g.w.f.a r3 = r0.h
            b.c.a.b.c.g.w.i0 r4 = new b.c.a.b.c.g.w.i0
            r4.<init>(r0, r1)
            r3.f1565g = r4
            b.c.a.b.c.g.w.f.a r3 = r0.h
            android.net.Uri r1 = r1.f6175a
            r3.a(r1)
        L_0x00d0:
            android.app.Notification r1 = r0.n
            r0.startForeground(r6, r1)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.MediaNotificationService.onStartCommand(android.content.Intent, int, int):int");
    }

    public static List<NotificationAction> a(c0 c0Var) {
        try {
            return c0Var.e();
        } catch (RemoteException unused) {
            q.b("Unable to call %s on %s.", "getNotificationActions", c0.class.getSimpleName());
            return null;
        }
    }

    public final void a() {
        NotificationCompat.Action action;
        if (this.k != null) {
            b bVar = this.l;
            PendingIntent pendingIntent = null;
            NotificationCompat.Builder visibility = new NotificationCompat.Builder(this, "cast_media_notification").setLargeIcon(bVar == null ? null : bVar.f6176b).setSmallIcon(this.f6161a.f6184e).setContentTitle(this.k.f6171d).setContentText(this.j.getString(this.f6161a.s, new Object[]{this.k.f6172e})).setOngoing(true).setShowWhen(false).setVisibility(1);
            if (this.f6164d != null) {
                Intent intent = new Intent();
                intent.putExtra("targetActivity", this.f6164d);
                intent.setAction(this.f6164d.flattenToString());
                pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 134217728);
            }
            if (pendingIntent != null) {
                visibility.setContentIntent(pendingIntent);
            }
            c0 c0Var = this.f6161a.F;
            if (c0Var != null) {
                q.b("actionsProvider != null", new Object[0]);
                this.f6166f = (int[]) b(c0Var).clone();
                List<NotificationAction> a2 = a(c0Var);
                this.f6165e = new ArrayList();
                for (NotificationAction next : a2) {
                    String str = next.f6177a;
                    if (str.equals(MediaIntentReceiver.ACTION_TOGGLE_PLAYBACK) || str.equals(MediaIntentReceiver.ACTION_SKIP_NEXT) || str.equals(MediaIntentReceiver.ACTION_SKIP_PREV) || str.equals(MediaIntentReceiver.ACTION_FORWARD) || str.equals(MediaIntentReceiver.ACTION_REWIND) || str.equals(MediaIntentReceiver.ACTION_STOP_CASTING)) {
                        action = a(next.f6177a);
                    } else {
                        Intent intent2 = new Intent(next.f6177a);
                        intent2.setComponent(this.f6163c);
                        action = new NotificationCompat.Action.Builder(next.f6178b, (CharSequence) next.f6179c, PendingIntent.getBroadcast(this, 0, intent2, 0)).build();
                    }
                    this.f6165e.add(action);
                }
            } else {
                q.b("actionsProvider == null", new Object[0]);
                this.f6165e = new ArrayList();
                for (String a3 : this.f6161a.f6180a) {
                    this.f6165e.add(a(a3));
                }
                int[] iArr = this.f6161a.f6181b;
                this.f6166f = (int[]) Arrays.copyOf(iArr, iArr.length).clone();
            }
            for (NotificationCompat.Action addAction : this.f6165e) {
                visibility.addAction(addAction);
            }
            if (Build.VERSION.SDK_INT >= 21) {
                visibility.setStyle(new NotificationCompat.MediaStyle().setShowActionsInCompactView(this.f6166f).setMediaSession(this.k.f6168a));
            }
            this.n = visibility.build();
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.core.app.NotificationCompat.Action a(java.lang.String r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.hashCode()
            r5 = 0
            java.lang.String r6 = "com.google.android.gms.cast.framework.action.FORWARD"
            java.lang.String r7 = "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"
            java.lang.String r8 = "com.google.android.gms.cast.framework.action.STOP_CASTING"
            java.lang.String r9 = "com.google.android.gms.cast.framework.action.SKIP_PREV"
            java.lang.String r10 = "com.google.android.gms.cast.framework.action.SKIP_NEXT"
            java.lang.String r11 = "com.google.android.gms.cast.framework.action.REWIND"
            switch(r2) {
                case -1699820260: goto L_0x004b;
                case -945151566: goto L_0x0043;
                case -945080078: goto L_0x003b;
                case -668151673: goto L_0x0033;
                case -124479363: goto L_0x0029;
                case 235550565: goto L_0x0021;
                case 1362116196: goto L_0x0019;
                default: goto L_0x0018;
            }
        L_0x0018:
            goto L_0x0053
        L_0x0019:
            boolean r2 = r1.equals(r6)
            if (r2 == 0) goto L_0x0053
            r2 = 3
            goto L_0x0054
        L_0x0021:
            boolean r2 = r1.equals(r7)
            if (r2 == 0) goto L_0x0053
            r2 = 0
            goto L_0x0054
        L_0x0029:
            java.lang.String r2 = "com.google.android.gms.cast.framework.action.DISCONNECT"
            boolean r2 = r1.equals(r2)
            if (r2 == 0) goto L_0x0053
            r2 = 6
            goto L_0x0054
        L_0x0033:
            boolean r2 = r1.equals(r8)
            if (r2 == 0) goto L_0x0053
            r2 = 5
            goto L_0x0054
        L_0x003b:
            boolean r2 = r1.equals(r9)
            if (r2 == 0) goto L_0x0053
            r2 = 2
            goto L_0x0054
        L_0x0043:
            boolean r2 = r1.equals(r10)
            if (r2 == 0) goto L_0x0053
            r2 = 1
            goto L_0x0054
        L_0x004b:
            boolean r2 = r1.equals(r11)
            if (r2 == 0) goto L_0x0053
            r2 = 4
            goto L_0x0054
        L_0x0053:
            r2 = -1
        L_0x0054:
            r12 = 30000(0x7530, double:1.4822E-319)
            r14 = 10000(0x2710, double:4.9407E-320)
            r4 = 134217728(0x8000000, float:3.85186E-34)
            java.lang.String r3 = "googlecast-extra_skip_step_ms"
            r16 = 0
            switch(r2) {
                case 0: goto L_0x015a;
                case 1: goto L_0x012e;
                case 2: goto L_0x0102;
                case 3: goto L_0x00c8;
                case 4: goto L_0x008e;
                case 5: goto L_0x006a;
                case 6: goto L_0x006a;
                default: goto L_0x0061;
            }
        L_0x0061:
            b.c.a.b.c.i.b r2 = q
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r3[r5] = r1
            goto L_0x019c
        L_0x006a:
            android.content.Intent r1 = new android.content.Intent
            r1.<init>(r8)
            android.content.ComponentName r2 = r0.f6163c
            r1.setComponent(r2)
            android.app.PendingIntent r1 = android.app.PendingIntent.getBroadcast(r0, r5, r1, r5)
            androidx.core.app.NotificationCompat$Action$Builder r2 = new androidx.core.app.NotificationCompat$Action$Builder
            com.google.android.gms.cast.framework.media.NotificationOptions r3 = r0.f6161a
            int r4 = r3.q
            android.content.res.Resources r5 = r0.j
            int r3 = r3.E
            java.lang.String r3 = r5.getString(r3)
            r2.<init>((int) r4, (java.lang.CharSequence) r3, (android.app.PendingIntent) r1)
            androidx.core.app.NotificationCompat$Action r1 = r2.build()
            return r1
        L_0x008e:
            long r1 = r0.f6167g
            android.content.Intent r6 = new android.content.Intent
            r6.<init>(r11)
            android.content.ComponentName r7 = r0.f6163c
            r6.setComponent(r7)
            r6.putExtra(r3, r1)
            android.app.PendingIntent r3 = android.app.PendingIntent.getBroadcast(r0, r5, r6, r4)
            com.google.android.gms.cast.framework.media.NotificationOptions r4 = r0.f6161a
            int r5 = r4.n
            int r6 = r4.B
            int r7 = (r1 > r14 ? 1 : (r1 == r14 ? 0 : -1))
            if (r7 != 0) goto L_0x00b0
            int r5 = r4.o
            int r6 = r4.C
            goto L_0x00b8
        L_0x00b0:
            int r7 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r7 != 0) goto L_0x00b8
            int r5 = r4.p
            int r6 = r4.D
        L_0x00b8:
            androidx.core.app.NotificationCompat$Action$Builder r1 = new androidx.core.app.NotificationCompat$Action$Builder
            android.content.res.Resources r2 = r0.j
            java.lang.String r2 = r2.getString(r6)
            r1.<init>((int) r5, (java.lang.CharSequence) r2, (android.app.PendingIntent) r3)
            androidx.core.app.NotificationCompat$Action r1 = r1.build()
            return r1
        L_0x00c8:
            long r1 = r0.f6167g
            android.content.Intent r7 = new android.content.Intent
            r7.<init>(r6)
            android.content.ComponentName r6 = r0.f6163c
            r7.setComponent(r6)
            r7.putExtra(r3, r1)
            android.app.PendingIntent r3 = android.app.PendingIntent.getBroadcast(r0, r5, r7, r4)
            com.google.android.gms.cast.framework.media.NotificationOptions r4 = r0.f6161a
            int r5 = r4.k
            int r6 = r4.y
            int r7 = (r1 > r14 ? 1 : (r1 == r14 ? 0 : -1))
            if (r7 != 0) goto L_0x00ea
            int r5 = r4.l
            int r6 = r4.z
            goto L_0x00f2
        L_0x00ea:
            int r7 = (r1 > r12 ? 1 : (r1 == r12 ? 0 : -1))
            if (r7 != 0) goto L_0x00f2
            int r5 = r4.m
            int r6 = r4.A
        L_0x00f2:
            androidx.core.app.NotificationCompat$Action$Builder r1 = new androidx.core.app.NotificationCompat$Action$Builder
            android.content.res.Resources r2 = r0.j
            java.lang.String r2 = r2.getString(r6)
            r1.<init>((int) r5, (java.lang.CharSequence) r2, (android.app.PendingIntent) r3)
            androidx.core.app.NotificationCompat$Action r1 = r1.build()
            return r1
        L_0x0102:
            com.google.android.gms.cast.framework.media.MediaNotificationService$a r1 = r0.k
            boolean r1 = r1.f6174g
            if (r1 == 0) goto L_0x0116
            android.content.Intent r1 = new android.content.Intent
            r1.<init>(r9)
            android.content.ComponentName r2 = r0.f6163c
            r1.setComponent(r2)
            android.app.PendingIntent r16 = android.app.PendingIntent.getBroadcast(r0, r5, r1, r5)
        L_0x0116:
            r1 = r16
            androidx.core.app.NotificationCompat$Action$Builder r2 = new androidx.core.app.NotificationCompat$Action$Builder
            com.google.android.gms.cast.framework.media.NotificationOptions r3 = r0.f6161a
            int r4 = r3.j
            android.content.res.Resources r5 = r0.j
            int r3 = r3.x
            java.lang.String r3 = r5.getString(r3)
            r2.<init>((int) r4, (java.lang.CharSequence) r3, (android.app.PendingIntent) r1)
            androidx.core.app.NotificationCompat$Action r1 = r2.build()
            return r1
        L_0x012e:
            com.google.android.gms.cast.framework.media.MediaNotificationService$a r1 = r0.k
            boolean r1 = r1.f6173f
            if (r1 == 0) goto L_0x0142
            android.content.Intent r1 = new android.content.Intent
            r1.<init>(r10)
            android.content.ComponentName r2 = r0.f6163c
            r1.setComponent(r2)
            android.app.PendingIntent r16 = android.app.PendingIntent.getBroadcast(r0, r5, r1, r5)
        L_0x0142:
            r1 = r16
            androidx.core.app.NotificationCompat$Action$Builder r2 = new androidx.core.app.NotificationCompat$Action$Builder
            com.google.android.gms.cast.framework.media.NotificationOptions r3 = r0.f6161a
            int r4 = r3.i
            android.content.res.Resources r5 = r0.j
            int r3 = r3.w
            java.lang.String r3 = r5.getString(r3)
            r2.<init>((int) r4, (java.lang.CharSequence) r3, (android.app.PendingIntent) r1)
            androidx.core.app.NotificationCompat$Action r1 = r2.build()
            return r1
        L_0x015a:
            com.google.android.gms.cast.framework.media.MediaNotificationService$a r1 = r0.k
            int r2 = r1.f6170c
            boolean r1 = r1.f6169b
            r3 = 2
            if (r2 != r3) goto L_0x016a
            com.google.android.gms.cast.framework.media.NotificationOptions r2 = r0.f6161a
            int r3 = r2.f6185f
            int r2 = r2.t
            goto L_0x0170
        L_0x016a:
            com.google.android.gms.cast.framework.media.NotificationOptions r2 = r0.f6161a
            int r3 = r2.f6186g
            int r2 = r2.u
        L_0x0170:
            if (r1 == 0) goto L_0x0173
            goto L_0x0177
        L_0x0173:
            com.google.android.gms.cast.framework.media.NotificationOptions r3 = r0.f6161a
            int r3 = r3.h
        L_0x0177:
            if (r1 == 0) goto L_0x017a
            goto L_0x017e
        L_0x017a:
            com.google.android.gms.cast.framework.media.NotificationOptions r1 = r0.f6161a
            int r2 = r1.v
        L_0x017e:
            android.content.Intent r1 = new android.content.Intent
            r1.<init>(r7)
            android.content.ComponentName r4 = r0.f6163c
            r1.setComponent(r4)
            android.app.PendingIntent r1 = android.app.PendingIntent.getBroadcast(r0, r5, r1, r5)
            androidx.core.app.NotificationCompat$Action$Builder r4 = new androidx.core.app.NotificationCompat$Action$Builder
            android.content.res.Resources r5 = r0.j
            java.lang.String r2 = r5.getString(r2)
            r4.<init>((int) r3, (java.lang.CharSequence) r2, (android.app.PendingIntent) r1)
            androidx.core.app.NotificationCompat$Action r1 = r4.build()
            return r1
        L_0x019c:
            java.lang.String r1 = "Action: %s is not a pre-defined action."
            r2.b(r1, r3)
            return r16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.MediaNotificationService.a(java.lang.String):androidx.core.app.NotificationCompat$Action");
    }
}
