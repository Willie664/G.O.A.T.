package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import b.a.b.w.e;
import b.c.a.b.c.v0;
import b.c.a.b.c.w0;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MediaQueueData extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaQueueData> CREATOR = new w0();

    /* renamed from: a  reason: collision with root package name */
    public String f6080a;

    /* renamed from: b  reason: collision with root package name */
    public String f6081b;

    /* renamed from: c  reason: collision with root package name */
    public int f6082c;

    /* renamed from: d  reason: collision with root package name */
    public String f6083d;

    /* renamed from: e  reason: collision with root package name */
    public MediaQueueContainerMetadata f6084e;

    /* renamed from: f  reason: collision with root package name */
    public int f6085f;

    /* renamed from: g  reason: collision with root package name */
    public List<MediaQueueItem> f6086g;
    public int h;
    public long i;

    public MediaQueueData() {
        clear();
    }

    public /* synthetic */ MediaQueueData(MediaQueueData mediaQueueData, v0 v0Var) {
        this.f6080a = mediaQueueData.f6080a;
        this.f6081b = mediaQueueData.f6081b;
        this.f6082c = mediaQueueData.f6082c;
        this.f6083d = mediaQueueData.f6083d;
        this.f6084e = mediaQueueData.f6084e;
        this.f6085f = mediaQueueData.f6085f;
        this.f6086g = mediaQueueData.f6086g;
        this.h = mediaQueueData.h;
        this.i = mediaQueueData.i;
    }

    public MediaQueueData(String str, String str2, int i2, String str3, MediaQueueContainerMetadata mediaQueueContainerMetadata, int i3, List<MediaQueueItem> list, int i4, long j) {
        this.f6080a = str;
        this.f6081b = str2;
        this.f6082c = i2;
        this.f6083d = str3;
        this.f6084e = mediaQueueContainerMetadata;
        this.f6085f = i3;
        this.f6086g = list;
        this.h = i4;
        this.i = j;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(com.google.android.gms.cast.MediaQueueData r13, org.json.JSONObject r14) {
        /*
            r13.clear()
            if (r14 != 0) goto L_0x0007
            goto L_0x01ba
        L_0x0007:
            r0 = 0
            java.lang.String r1 = "id"
            java.lang.String r1 = r14.optString(r1, r0)
            r13.f6080a = r1
            java.lang.String r1 = "entity"
            java.lang.String r1 = r14.optString(r1, r0)
            r13.f6081b = r1
            java.lang.String r1 = "queueType"
            java.lang.String r1 = r14.optString(r1)
            int r2 = r1.hashCode()
            r3 = -1
            r4 = 2
            r5 = 3
            r6 = 4
            r7 = 5
            r8 = 6
            r9 = 7
            r10 = 8
            r11 = 0
            r12 = 1
            switch(r2) {
                case -1803151310: goto L_0x0082;
                case -1758903120: goto L_0x0078;
                case -1632865838: goto L_0x006e;
                case -1319760993: goto L_0x0064;
                case -1088524588: goto L_0x005a;
                case 62359119: goto L_0x0050;
                case 73549584: goto L_0x0045;
                case 393100598: goto L_0x003b;
                case 902303413: goto L_0x0031;
                default: goto L_0x0030;
            }
        L_0x0030:
            goto L_0x008c
        L_0x0031:
            java.lang.String r2 = "LIVE_TV"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 7
            goto L_0x008d
        L_0x003b:
            java.lang.String r2 = "VIDEO_PLAYLIST"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 6
            goto L_0x008d
        L_0x0045:
            java.lang.String r2 = "MOVIE"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 8
            goto L_0x008d
        L_0x0050:
            java.lang.String r2 = "ALBUM"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 0
            goto L_0x008d
        L_0x005a:
            java.lang.String r2 = "TV_SERIES"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 5
            goto L_0x008d
        L_0x0064:
            java.lang.String r2 = "AUDIOBOOK"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 2
            goto L_0x008d
        L_0x006e:
            java.lang.String r2 = "PLAYLIST"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 1
            goto L_0x008d
        L_0x0078:
            java.lang.String r2 = "RADIO_STATION"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 3
            goto L_0x008d
        L_0x0082:
            java.lang.String r2 = "PODCAST_SERIES"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x008c
            r1 = 4
            goto L_0x008d
        L_0x008c:
            r1 = -1
        L_0x008d:
            switch(r1) {
                case 0: goto L_0x00ab;
                case 1: goto L_0x00a8;
                case 2: goto L_0x00a5;
                case 3: goto L_0x00a2;
                case 4: goto L_0x009f;
                case 5: goto L_0x009c;
                case 6: goto L_0x0099;
                case 7: goto L_0x0096;
                case 8: goto L_0x0091;
                default: goto L_0x0090;
            }
        L_0x0090:
            goto L_0x00ad
        L_0x0091:
            r1 = 9
            r13.f6082c = r1
            goto L_0x00ad
        L_0x0096:
            r13.f6082c = r10
            goto L_0x00ad
        L_0x0099:
            r13.f6082c = r9
            goto L_0x00ad
        L_0x009c:
            r13.f6082c = r8
            goto L_0x00ad
        L_0x009f:
            r13.f6082c = r7
            goto L_0x00ad
        L_0x00a2:
            r13.f6082c = r6
            goto L_0x00ad
        L_0x00a5:
            r13.f6082c = r5
            goto L_0x00ad
        L_0x00a8:
            r13.f6082c = r4
            goto L_0x00ad
        L_0x00ab:
            r13.f6082c = r12
        L_0x00ad:
            java.lang.String r1 = "name"
            java.lang.String r1 = r14.optString(r1, r0)
            r13.f6083d = r1
            java.lang.String r1 = "containerMetadata"
            boolean r2 = r14.has(r1)
            if (r2 == 0) goto L_0x0161
            com.google.android.gms.cast.MediaQueueContainerMetadata r2 = new com.google.android.gms.cast.MediaQueueContainerMetadata
            r2.<init>(r0)
            org.json.JSONObject r1 = r14.optJSONObject(r1)
            r2.f6075a = r11
            r2.f6076b = r0
            r2.f6077c = r0
            r2.f6078d = r0
            r4 = 0
            r2.f6079e = r4
            if (r1 != 0) goto L_0x00d6
            goto L_0x015a
        L_0x00d6:
            java.lang.String r4 = "containerType"
            java.lang.String r5 = ""
            java.lang.String r4 = r1.optString(r4, r5)
            int r5 = r4.hashCode()
            r6 = 6924225(0x69a7c1, float:9.702906E-39)
            if (r5 == r6) goto L_0x00f7
            r6 = 828666841(0x316473d9, float:3.3244218E-9)
            if (r5 == r6) goto L_0x00ed
            goto L_0x0100
        L_0x00ed:
            java.lang.String r5 = "GENERIC_CONTAINER"
            boolean r4 = r4.equals(r5)
            if (r4 == 0) goto L_0x0100
            r3 = 0
            goto L_0x0100
        L_0x00f7:
            java.lang.String r5 = "AUDIOBOOK_CONTAINER"
            boolean r4 = r4.equals(r5)
            if (r4 == 0) goto L_0x0100
            r3 = 1
        L_0x0100:
            if (r3 == 0) goto L_0x0108
            if (r3 == r12) goto L_0x0105
            goto L_0x010a
        L_0x0105:
            r2.f6075a = r12
            goto L_0x010a
        L_0x0108:
            r2.f6075a = r11
        L_0x010a:
            java.lang.String r3 = "title"
            java.lang.String r3 = r1.optString(r3, r0)
            r2.f6076b = r3
            java.lang.String r3 = "sections"
            org.json.JSONArray r3 = r1.optJSONArray(r3)
            if (r3 == 0) goto L_0x013e
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r2.f6077c = r4
            r4 = 0
        L_0x0122:
            int r5 = r3.length()
            if (r4 >= r5) goto L_0x013e
            org.json.JSONObject r5 = r3.optJSONObject(r4)
            if (r5 == 0) goto L_0x013b
            com.google.android.gms.cast.MediaMetadata r6 = new com.google.android.gms.cast.MediaMetadata
            r6.<init>(r11)
            r6.a(r5)
            java.util.List<com.google.android.gms.cast.MediaMetadata> r5 = r2.f6077c
            r5.add(r6)
        L_0x013b:
            int r4 = r4 + 1
            goto L_0x0122
        L_0x013e:
            java.lang.String r3 = "containerImages"
            org.json.JSONArray r3 = r1.optJSONArray(r3)
            if (r3 == 0) goto L_0x0150
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r2.f6078d = r4
            b.c.a.b.c.i.c.a.a(r4, r3)
        L_0x0150:
            double r3 = r2.f6079e
            java.lang.String r5 = "containerDuration"
            double r3 = r1.optDouble(r5, r3)
            r2.f6079e = r3
        L_0x015a:
            com.google.android.gms.cast.MediaQueueContainerMetadata r1 = new com.google.android.gms.cast.MediaQueueContainerMetadata
            r1.<init>(r2, r0)
            r13.f6084e = r1
        L_0x0161:
            java.lang.String r0 = "repeatMode"
            java.lang.String r0 = r14.optString(r0)
            java.lang.Integer r0 = b.a.b.w.e.h(r0)
            if (r0 == 0) goto L_0x0173
            int r0 = r0.intValue()
            r13.f6085f = r0
        L_0x0173:
            java.lang.String r0 = "items"
            org.json.JSONArray r0 = r14.optJSONArray(r0)
            if (r0 == 0) goto L_0x019b
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r13.f6086g = r1
        L_0x0182:
            int r1 = r0.length()
            if (r11 >= r1) goto L_0x019b
            org.json.JSONObject r1 = r0.optJSONObject(r11)
            if (r1 == 0) goto L_0x0198
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r2 = r13.f6086g     // Catch:{ JSONException -> 0x0198 }
            com.google.android.gms.cast.MediaQueueItem r3 = new com.google.android.gms.cast.MediaQueueItem     // Catch:{ JSONException -> 0x0198 }
            r3.<init>(r1)     // Catch:{ JSONException -> 0x0198 }
            r2.add(r3)     // Catch:{ JSONException -> 0x0198 }
        L_0x0198:
            int r11 = r11 + 1
            goto L_0x0182
        L_0x019b:
            int r0 = r13.h
            java.lang.String r1 = "startIndex"
            int r0 = r14.optInt(r1, r0)
            r13.h = r0
            java.lang.String r0 = "startTime"
            boolean r1 = r14.has(r0)
            if (r1 == 0) goto L_0x01ba
            long r1 = r13.i
            double r1 = (double) r1
            double r0 = r14.optDouble(r0, r1)
            long r0 = b.c.a.b.c.i.a.a((double) r0)
            r13.i = r0
        L_0x01ba:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaQueueData.a(com.google.android.gms.cast.MediaQueueData, org.json.JSONObject):void");
    }

    public final void clear() {
        this.f6080a = null;
        this.f6081b = null;
        this.f6082c = 0;
        this.f6083d = null;
        this.f6085f = 0;
        this.f6086g = null;
        this.h = 0;
        this.i = -1;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaQueueData)) {
            return false;
        }
        MediaQueueData mediaQueueData = (MediaQueueData) obj;
        return TextUtils.equals(this.f6080a, mediaQueueData.f6080a) && TextUtils.equals(this.f6081b, mediaQueueData.f6081b) && this.f6082c == mediaQueueData.f6082c && TextUtils.equals(this.f6083d, mediaQueueData.f6083d) && e.c((Object) this.f6084e, (Object) mediaQueueData.f6084e) && this.f6085f == mediaQueueData.f6085f && e.c((Object) this.f6086g, (Object) mediaQueueData.f6086g) && this.h == mediaQueueData.h && this.i == mediaQueueData.i;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6080a, this.f6081b, Integer.valueOf(this.f6082c), this.f6083d, this.f6084e, Integer.valueOf(this.f6085f), this.f6086g, Integer.valueOf(this.h), Long.valueOf(this.i)});
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
        r0.put("queueType", r1);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.json.JSONObject p() {
        /*
            r6 = this;
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            java.lang.String r1 = r6.f6080a     // Catch:{ JSONException -> 0x00c2 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x00c2 }
            if (r1 != 0) goto L_0x0014
            java.lang.String r1 = "id"
            java.lang.String r2 = r6.f6080a     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
        L_0x0014:
            java.lang.String r1 = r6.f6081b     // Catch:{ JSONException -> 0x00c2 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x00c2 }
            if (r1 != 0) goto L_0x0023
            java.lang.String r1 = "entity"
            java.lang.String r2 = r6.f6081b     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
        L_0x0023:
            int r1 = r6.f6082c     // Catch:{ JSONException -> 0x00c2 }
            java.lang.String r2 = "queueType"
            switch(r1) {
                case 1: goto L_0x0046;
                case 2: goto L_0x0043;
                case 3: goto L_0x0040;
                case 4: goto L_0x003d;
                case 5: goto L_0x003a;
                case 6: goto L_0x0037;
                case 7: goto L_0x0034;
                case 8: goto L_0x0031;
                case 9: goto L_0x002b;
                default: goto L_0x002a;
            }
        L_0x002a:
            goto L_0x0049
        L_0x002b:
            java.lang.String r1 = "MOVIE"
        L_0x002d:
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x00c2 }
            goto L_0x0049
        L_0x0031:
            java.lang.String r1 = "LIVE_TV"
            goto L_0x002d
        L_0x0034:
            java.lang.String r1 = "VIDEO_PLAYLIST"
            goto L_0x002d
        L_0x0037:
            java.lang.String r1 = "TV_SERIES"
            goto L_0x002d
        L_0x003a:
            java.lang.String r1 = "PODCAST_SERIES"
            goto L_0x002d
        L_0x003d:
            java.lang.String r1 = "RADIO_STATION"
            goto L_0x002d
        L_0x0040:
            java.lang.String r1 = "AUDIOBOOK"
            goto L_0x002d
        L_0x0043:
            java.lang.String r1 = "PLAYLIST"
            goto L_0x002d
        L_0x0046:
            java.lang.String r1 = "ALBUM"
            goto L_0x002d
        L_0x0049:
            java.lang.String r1 = r6.f6083d     // Catch:{ JSONException -> 0x00c2 }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ JSONException -> 0x00c2 }
            if (r1 != 0) goto L_0x0058
            java.lang.String r1 = "name"
            java.lang.String r2 = r6.f6083d     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
        L_0x0058:
            com.google.android.gms.cast.MediaQueueContainerMetadata r1 = r6.f6084e     // Catch:{ JSONException -> 0x00c2 }
            if (r1 == 0) goto L_0x0067
            java.lang.String r1 = "containerMetadata"
            com.google.android.gms.cast.MediaQueueContainerMetadata r2 = r6.f6084e     // Catch:{ JSONException -> 0x00c2 }
            org.json.JSONObject r2 = r2.p()     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
        L_0x0067:
            int r1 = r6.f6085f     // Catch:{ JSONException -> 0x00c2 }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ JSONException -> 0x00c2 }
            java.lang.String r1 = b.a.b.w.e.a((java.lang.Integer) r1)     // Catch:{ JSONException -> 0x00c2 }
            if (r1 == 0) goto L_0x0078
            java.lang.String r2 = "repeatMode"
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x00c2 }
        L_0x0078:
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r1 = r6.f6086g     // Catch:{ JSONException -> 0x00c2 }
            if (r1 == 0) goto L_0x00a8
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r1 = r6.f6086g     // Catch:{ JSONException -> 0x00c2 }
            boolean r1 = r1.isEmpty()     // Catch:{ JSONException -> 0x00c2 }
            if (r1 != 0) goto L_0x00a8
            org.json.JSONArray r1 = new org.json.JSONArray     // Catch:{ JSONException -> 0x00c2 }
            r1.<init>()     // Catch:{ JSONException -> 0x00c2 }
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r2 = r6.f6086g     // Catch:{ JSONException -> 0x00c2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ JSONException -> 0x00c2 }
        L_0x008f:
            boolean r3 = r2.hasNext()     // Catch:{ JSONException -> 0x00c2 }
            if (r3 == 0) goto L_0x00a3
            java.lang.Object r3 = r2.next()     // Catch:{ JSONException -> 0x00c2 }
            com.google.android.gms.cast.MediaQueueItem r3 = (com.google.android.gms.cast.MediaQueueItem) r3     // Catch:{ JSONException -> 0x00c2 }
            org.json.JSONObject r3 = r3.p()     // Catch:{ JSONException -> 0x00c2 }
            r1.put(r3)     // Catch:{ JSONException -> 0x00c2 }
            goto L_0x008f
        L_0x00a3:
            java.lang.String r2 = "items"
            r0.put(r2, r1)     // Catch:{ JSONException -> 0x00c2 }
        L_0x00a8:
            java.lang.String r1 = "startIndex"
            int r2 = r6.h     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
            long r1 = r6.i     // Catch:{ JSONException -> 0x00c2 }
            r3 = -1
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 == 0) goto L_0x00c2
            java.lang.String r1 = "startTime"
            long r2 = r6.i     // Catch:{ JSONException -> 0x00c2 }
            double r2 = b.c.a.b.c.i.a.a((long) r2)     // Catch:{ JSONException -> 0x00c2 }
            r0.put(r1, r2)     // Catch:{ JSONException -> 0x00c2 }
        L_0x00c2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaQueueData.p():org.json.JSONObject");
    }

    public void writeToParcel(Parcel parcel, int i2) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6080a, false);
        d.a(parcel, 3, this.f6081b, false);
        d.a(parcel, 4, this.f6082c);
        d.a(parcel, 5, this.f6083d, false);
        d.a(parcel, 6, (Parcelable) this.f6084e, i2, false);
        d.a(parcel, 7, this.f6085f);
        List<MediaQueueItem> list = this.f6086g;
        d.b(parcel, 8, list == null ? null : Collections.unmodifiableList(list), false);
        d.a(parcel, 9, this.h);
        d.a(parcel, 10, this.i);
        d.b(parcel, a2);
    }

    public /* synthetic */ MediaQueueData(v0 v0Var) {
        clear();
    }
}
