package com.google.android.gms.cast.framework;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import b.a.b.w.e;
import b.c.a.b.c.g.i0;
import b.c.a.b.c.g.p0;
import b.c.a.b.c.g.q0;
import b.c.a.b.c.g.s;
import b.c.a.b.c.g.u0;
import b.c.a.b.c.i.b;
import b.c.a.b.e.a;
import com.google.android.gms.internal.cast.zzae;

public class ReconnectionService extends Service {

    /* renamed from: b  reason: collision with root package name */
    public static final b f6128b = new b("ReconnectionService");

    /* renamed from: a  reason: collision with root package name */
    public q0 f6129a;

    public IBinder onBind(Intent intent) {
        try {
            return this.f6129a.onBind(intent);
        } catch (RemoteException unused) {
            b bVar = f6128b;
            Object[] objArr = {"onBind", q0.class.getSimpleName()};
            if (!bVar.a()) {
                return null;
            }
            bVar.b("Unable to call %s on %s.", objArr);
            return null;
        }
    }

    public void onCreate() {
        a aVar;
        b.c.a.b.c.g.b a2 = b.c.a.b.c.g.b.a((Context) this);
        s b2 = a2.b();
        a aVar2 = null;
        if (b2 != null) {
            try {
                aVar = b2.f1499a.a();
            } catch (RemoteException unused) {
                b bVar = s.f1498c;
                Object[] objArr = {"getWrappedThis", u0.class.getSimpleName()};
                if (bVar.a()) {
                    bVar.b("Unable to call %s on %s.", objArr);
                }
                aVar = null;
            }
            e.c("Must be called from the main thread.");
            i0 i0Var = a2.f1475d;
            if (i0Var != null) {
                try {
                    aVar2 = i0Var.f1493a.a();
                } catch (RemoteException unused2) {
                    b bVar2 = i0.f1492b;
                    Object[] objArr2 = {"getWrappedThis", p0.class.getSimpleName()};
                    if (bVar2.a()) {
                        bVar2.b("Unable to call %s on %s.", objArr2);
                    }
                }
                q0 zza = zzae.zza(this, aVar, aVar2);
                this.f6129a = zza;
                try {
                    zza.onCreate();
                } catch (RemoteException unused3) {
                    b bVar3 = f6128b;
                    Object[] objArr3 = {"onCreate", q0.class.getSimpleName()};
                    if (bVar3.a()) {
                        bVar3.b("Unable to call %s on %s.", objArr3);
                    }
                }
                super.onCreate();
                return;
            }
            throw null;
        }
        throw null;
    }

    public void onDestroy() {
        try {
            this.f6129a.onDestroy();
        } catch (RemoteException unused) {
            b bVar = f6128b;
            Object[] objArr = {"onDestroy", q0.class.getSimpleName()};
            if (bVar.a()) {
                bVar.b("Unable to call %s on %s.", objArr);
            }
        }
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            return this.f6129a.a(intent, i, i2);
        } catch (RemoteException unused) {
            b bVar = f6128b;
            Object[] objArr = {"onStartCommand", q0.class.getSimpleName()};
            if (bVar.a()) {
                bVar.b("Unable to call %s on %s.", objArr);
            }
            return 1;
        }
    }
}
