package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.f1;
import b.c.a.b.c.i.a;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public class VastAdsRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<VastAdsRequest> CREATOR = new f1();

    /* renamed from: a  reason: collision with root package name */
    public final String f6115a;

    /* renamed from: b  reason: collision with root package name */
    public final String f6116b;

    public VastAdsRequest(String str, String str2) {
        this.f6115a = str;
        this.f6116b = str2;
    }

    public static VastAdsRequest a(JSONObject jSONObject) {
        if (jSONObject == null) {
            return null;
        }
        return new VastAdsRequest(jSONObject.optString("adTagUrl", (String) null), jSONObject.optString("adsResponse", (String) null));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof VastAdsRequest)) {
            return false;
        }
        VastAdsRequest vastAdsRequest = (VastAdsRequest) obj;
        return a.a(this.f6115a, vastAdsRequest.f6115a) && a.a(this.f6116b, vastAdsRequest.f6116b);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6115a, this.f6116b});
    }

    public final JSONObject p() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.f6115a != null) {
                jSONObject.put("adTagUrl", this.f6115a);
            }
            if (this.f6116b != null) {
                jSONObject.put("adsResponse", this.f6116b);
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6115a, false);
        d.a(parcel, 3, this.f6116b, false);
        d.b(parcel, a2);
    }
}
