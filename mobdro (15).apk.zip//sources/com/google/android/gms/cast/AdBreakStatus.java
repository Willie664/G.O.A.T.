package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.b1;
import b.c.a.b.c.i.a;
import b.c.a.b.c.i.b;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public class AdBreakStatus extends AbstractSafeParcelable {
    public static final Parcelable.Creator<AdBreakStatus> CREATOR = new b1();

    /* renamed from: f  reason: collision with root package name */
    public static final b f6015f = new b("AdBreakStatus");

    /* renamed from: a  reason: collision with root package name */
    public final long f6016a;

    /* renamed from: b  reason: collision with root package name */
    public final long f6017b;

    /* renamed from: c  reason: collision with root package name */
    public final String f6018c;

    /* renamed from: d  reason: collision with root package name */
    public final String f6019d;

    /* renamed from: e  reason: collision with root package name */
    public final long f6020e;

    public AdBreakStatus(long j, long j2, String str, String str2, long j3) {
        this.f6016a = j;
        this.f6017b = j2;
        this.f6018c = str;
        this.f6019d = str2;
        this.f6020e = j3;
    }

    public static AdBreakStatus a(JSONObject jSONObject) {
        if (jSONObject != null && jSONObject.has("currentBreakTime") && jSONObject.has("currentBreakClipTime")) {
            try {
                long a2 = a.a((double) jSONObject.getLong("currentBreakTime"));
                long a3 = a.a((double) jSONObject.getLong("currentBreakClipTime"));
                String optString = jSONObject.optString("breakId", (String) null);
                String optString2 = jSONObject.optString("breakClipId", (String) null);
                long optLong = jSONObject.optLong("whenSkippable", -1);
                return new AdBreakStatus(a2, a3, optString, optString2, optLong != -1 ? a.a((double) optLong) : optLong);
            } catch (JSONException unused) {
                f6015f.b("Error while creating an AdBreakClipInfo from JSON", new Object[0]);
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AdBreakStatus)) {
            return false;
        }
        AdBreakStatus adBreakStatus = (AdBreakStatus) obj;
        return this.f6016a == adBreakStatus.f6016a && this.f6017b == adBreakStatus.f6017b && a.a(this.f6018c, adBreakStatus.f6018c) && a.a(this.f6019d, adBreakStatus.f6019d) && this.f6020e == adBreakStatus.f6020e;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f6016a), Long.valueOf(this.f6017b), this.f6018c, this.f6019d, Long.valueOf(this.f6020e)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6016a);
        d.a(parcel, 3, this.f6017b);
        d.a(parcel, 4, this.f6018c, false);
        d.a(parcel, 5, this.f6019d, false);
        d.a(parcel, 6, this.f6020e);
        d.b(parcel, a2);
    }
}
