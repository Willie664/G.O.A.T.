package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseArray;
import b.c.a.b.c.i.a;
import b.c.a.b.c.i.b;
import b.c.a.b.c.z0;
import b.c.a.b.d.n.u.d;
import b.c.a.b.d.r.e;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaStatus extends AbstractSafeParcelable {
    public static final Parcelable.Creator<MediaStatus> CREATOR = new z0();

    /* renamed from: a  reason: collision with root package name */
    public MediaInfo f6094a;

    /* renamed from: b  reason: collision with root package name */
    public long f6095b;

    /* renamed from: c  reason: collision with root package name */
    public int f6096c;

    /* renamed from: d  reason: collision with root package name */
    public double f6097d;

    /* renamed from: e  reason: collision with root package name */
    public int f6098e;

    /* renamed from: f  reason: collision with root package name */
    public int f6099f;

    /* renamed from: g  reason: collision with root package name */
    public long f6100g;
    public long h;
    public double i;
    public boolean j;
    public long[] k;
    public int l;
    public int m;
    public String n;
    public JSONObject o;
    public int p;
    public final List<MediaQueueItem> q = new ArrayList();
    public boolean r;
    public AdBreakStatus s;
    public VideoInfo t;
    public MediaLiveSeekableRange u;
    public MediaQueueData v;
    public final SparseArray<Integer> w = new SparseArray<>();

    static {
        new b("MediaStatus");
    }

    public MediaStatus(MediaInfo mediaInfo, long j2, int i2, double d2, int i3, int i4, long j3, long j4, double d3, boolean z, long[] jArr, int i5, int i6, String str, int i7, List<MediaQueueItem> list, boolean z2, AdBreakStatus adBreakStatus, VideoInfo videoInfo, MediaLiveSeekableRange mediaLiveSeekableRange, MediaQueueData mediaQueueData) {
        String str2 = str;
        List<MediaQueueItem> list2 = list;
        this.f6094a = mediaInfo;
        this.f6095b = j2;
        this.f6096c = i2;
        this.f6097d = d2;
        this.f6098e = i3;
        this.f6099f = i4;
        this.f6100g = j3;
        this.h = j4;
        this.i = d3;
        this.j = z;
        this.k = jArr;
        this.l = i5;
        this.m = i6;
        this.n = str2;
        if (str2 != null) {
            try {
                this.o = new JSONObject(this.n);
            } catch (JSONException unused) {
                this.o = null;
                this.n = null;
            }
        } else {
            this.o = null;
        }
        this.p = i7;
        if (list2 != null && !list.isEmpty()) {
            a(list2);
        }
        this.r = z2;
        this.s = adBreakStatus;
        this.t = videoInfo;
        this.u = mediaLiveSeekableRange;
        this.v = mediaQueueData;
    }

    public static boolean a(int i2, int i3, int i4, int i5) {
        if (i2 != 1) {
            return false;
        }
        if (i3 != 1) {
            if (i3 == 2) {
                return i5 != 2;
            }
            if (i3 != 3) {
                return true;
            }
        }
        return i4 == 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:147:0x0259  */
    /* JADX WARNING: Removed duplicated region for block: B:189:0x034a  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x0192  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int a(org.json.JSONObject r28, int r29) throws org.json.JSONException {
        /*
            r27 = this;
            r0 = r27
            r1 = r28
            java.lang.String r2 = "extendedStatus"
            org.json.JSONObject r3 = r1.optJSONObject(r2)
            r4 = 0
            if (r3 != 0) goto L_0x000e
            goto L_0x0052
        L_0x000e:
            java.util.ArrayList r5 = new java.util.ArrayList     // Catch:{ JSONException -> 0x0051 }
            r5.<init>()     // Catch:{ JSONException -> 0x0051 }
            java.util.Iterator r6 = r28.keys()     // Catch:{ JSONException -> 0x0051 }
        L_0x0017:
            boolean r7 = r6.hasNext()     // Catch:{ JSONException -> 0x0051 }
            if (r7 == 0) goto L_0x0027
            java.lang.Object r7 = r6.next()     // Catch:{ JSONException -> 0x0051 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ JSONException -> 0x0051 }
            r5.add(r7)     // Catch:{ JSONException -> 0x0051 }
            goto L_0x0017
        L_0x0027:
            org.json.JSONObject r6 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0051 }
            java.lang.String[] r7 = new java.lang.String[r4]     // Catch:{ JSONException -> 0x0051 }
            java.lang.Object[] r5 = r5.toArray(r7)     // Catch:{ JSONException -> 0x0051 }
            java.lang.String[] r5 = (java.lang.String[]) r5     // Catch:{ JSONException -> 0x0051 }
            r6.<init>(r1, r5)     // Catch:{ JSONException -> 0x0051 }
            java.util.Iterator r5 = r3.keys()     // Catch:{ JSONException -> 0x0051 }
        L_0x0038:
            boolean r7 = r5.hasNext()     // Catch:{ JSONException -> 0x0051 }
            if (r7 == 0) goto L_0x004c
            java.lang.Object r7 = r5.next()     // Catch:{ JSONException -> 0x0051 }
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ JSONException -> 0x0051 }
            java.lang.Object r8 = r3.get(r7)     // Catch:{ JSONException -> 0x0051 }
            r6.put(r7, r8)     // Catch:{ JSONException -> 0x0051 }
            goto L_0x0038
        L_0x004c:
            r6.remove(r2)     // Catch:{ JSONException -> 0x0051 }
            r1 = r6
            goto L_0x0052
        L_0x0051:
        L_0x0052:
            java.lang.String r2 = "mediaSessionId"
            long r2 = r1.getLong(r2)
            long r5 = r0.f6095b
            r7 = 1
            int r8 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r8 == 0) goto L_0x0063
            r0.f6095b = r2
            r2 = 1
            goto L_0x0064
        L_0x0063:
            r2 = 0
        L_0x0064:
            java.lang.String r3 = "playerState"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x00eb
            java.lang.String r3 = r1.getString(r3)
            java.lang.String r5 = "IDLE"
            boolean r5 = r3.equals(r5)
            r8 = 3
            r9 = 4
            if (r5 == 0) goto L_0x007c
            r3 = 1
            goto L_0x00a5
        L_0x007c:
            java.lang.String r5 = "PLAYING"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x0086
            r3 = 2
            goto L_0x00a5
        L_0x0086:
            java.lang.String r5 = "PAUSED"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x0090
            r3 = 3
            goto L_0x00a5
        L_0x0090:
            java.lang.String r5 = "BUFFERING"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x009a
            r3 = 4
            goto L_0x00a5
        L_0x009a:
            java.lang.String r5 = "LOADING"
            boolean r3 = r3.equals(r5)
            if (r3 == 0) goto L_0x00a4
            r3 = 5
            goto L_0x00a5
        L_0x00a4:
            r3 = 0
        L_0x00a5:
            int r5 = r0.f6098e
            if (r3 == r5) goto L_0x00ad
            r0.f6098e = r3
            r2 = r2 | 2
        L_0x00ad:
            if (r3 != r7) goto L_0x00eb
            java.lang.String r3 = "idleReason"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x00eb
            java.lang.String r3 = r1.getString(r3)
            java.lang.String r5 = "CANCELLED"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x00c5
            r8 = 2
            goto L_0x00e3
        L_0x00c5:
            java.lang.String r5 = "INTERRUPTED"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x00ce
            goto L_0x00e3
        L_0x00ce:
            java.lang.String r5 = "FINISHED"
            boolean r5 = r3.equals(r5)
            if (r5 == 0) goto L_0x00d8
            r8 = 1
            goto L_0x00e3
        L_0x00d8:
            java.lang.String r5 = "ERROR"
            boolean r3 = r3.equals(r5)
            if (r3 == 0) goto L_0x00e2
            r8 = 4
            goto L_0x00e3
        L_0x00e2:
            r8 = 0
        L_0x00e3:
            int r3 = r0.f6099f
            if (r8 == r3) goto L_0x00eb
            r0.f6099f = r8
            r2 = r2 | 2
        L_0x00eb:
            java.lang.String r3 = "playbackRate"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x0101
            double r8 = r1.getDouble(r3)
            double r10 = r0.f6097d
            int r3 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
            if (r3 == 0) goto L_0x0101
            r0.f6097d = r8
            r2 = r2 | 2
        L_0x0101:
            java.lang.String r3 = "currentTime"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x011d
            double r8 = r1.getDouble(r3)
            long r8 = b.c.a.b.c.i.a.a((double) r8)
            long r10 = r0.f6100g
            int r3 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r3 == 0) goto L_0x011b
            r0.f6100g = r8
            r2 = r2 | 2
        L_0x011b:
            r2 = r2 | 128(0x80, float:1.794E-43)
        L_0x011d:
            java.lang.String r3 = "supportedMediaCommands"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x0133
            long r8 = r1.getLong(r3)
            long r10 = r0.h
            int r3 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r3 == 0) goto L_0x0133
            r0.h = r8
            r2 = r2 | 2
        L_0x0133:
            java.lang.String r3 = "volume"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x0161
            r5 = r29 & 1
            if (r5 != 0) goto L_0x0161
            org.json.JSONObject r3 = r1.getJSONObject(r3)
            java.lang.String r5 = "level"
            double r8 = r3.getDouble(r5)
            double r10 = r0.i
            int r5 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r5 == 0) goto L_0x0153
            r0.i = r8
            r2 = r2 | 2
        L_0x0153:
            java.lang.String r5 = "muted"
            boolean r3 = r3.getBoolean(r5)
            boolean r5 = r0.j
            if (r3 == r5) goto L_0x0161
            r0.j = r3
            r2 = r2 | 2
        L_0x0161:
            java.lang.String r3 = "activeTrackIds"
            boolean r5 = r1.has(r3)
            r8 = 0
            if (r5 == 0) goto L_0x0195
            org.json.JSONArray r3 = r1.getJSONArray(r3)
            long[] r3 = b.c.a.b.c.i.a.a((org.json.JSONArray) r3)
            long[] r5 = r0.k
            if (r5 != 0) goto L_0x0177
            goto L_0x018a
        L_0x0177:
            int r5 = r5.length
            int r9 = r3.length
            if (r5 == r9) goto L_0x017c
            goto L_0x018a
        L_0x017c:
            r5 = 0
        L_0x017d:
            int r9 = r3.length
            if (r5 >= r9) goto L_0x018f
            long[] r9 = r0.k
            r10 = r9[r5]
            r12 = r3[r5]
            int r9 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r9 == 0) goto L_0x018c
        L_0x018a:
            r5 = 1
            goto L_0x0190
        L_0x018c:
            int r5 = r5 + 1
            goto L_0x017d
        L_0x018f:
            r5 = 0
        L_0x0190:
            if (r5 == 0) goto L_0x019e
            r0.k = r3
            goto L_0x019e
        L_0x0195:
            long[] r3 = r0.k
            if (r3 == 0) goto L_0x019c
            r3 = r8
            r5 = 1
            goto L_0x019e
        L_0x019c:
            r3 = r8
            r5 = 0
        L_0x019e:
            if (r5 == 0) goto L_0x01a4
            r0.k = r3
            r2 = r2 | 2
        L_0x01a4:
            java.lang.String r3 = "customData"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x01b6
            org.json.JSONObject r3 = r1.getJSONObject(r3)
            r0.o = r3
            r0.n = r8
            r2 = r2 | 2
        L_0x01b6:
            java.lang.String r3 = "media"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x01df
            org.json.JSONObject r3 = r1.getJSONObject(r3)
            com.google.android.gms.cast.MediaInfo r5 = new com.google.android.gms.cast.MediaInfo
            r5.<init>(r3)
            com.google.android.gms.cast.MediaInfo r9 = r0.f6094a
            if (r9 == 0) goto L_0x01d1
            boolean r9 = r9.equals(r5)
            if (r9 != 0) goto L_0x01d5
        L_0x01d1:
            r0.f6094a = r5
            r2 = r2 | 2
        L_0x01d5:
            java.lang.String r5 = "metadata"
            boolean r3 = r3.has(r5)
            if (r3 == 0) goto L_0x01df
            r2 = r2 | 4
        L_0x01df:
            java.lang.String r3 = "currentItemId"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x01f3
            int r3 = r1.getInt(r3)
            int r5 = r0.f6096c
            if (r5 == r3) goto L_0x01f3
            r0.f6096c = r3
            r2 = r2 | 2
        L_0x01f3:
            java.lang.String r3 = "preloadedItemId"
            int r3 = r1.optInt(r3, r4)
            int r5 = r0.m
            if (r5 == r3) goto L_0x0201
            r0.m = r3
            r2 = r2 | 16
        L_0x0201:
            java.lang.String r3 = "loadingItemId"
            int r3 = r1.optInt(r3, r4)
            int r5 = r0.l
            if (r5 == r3) goto L_0x020f
            r0.l = r3
            r2 = r2 | 2
        L_0x020f:
            com.google.android.gms.cast.MediaInfo r3 = r0.f6094a
            if (r3 != 0) goto L_0x0215
            r3 = -1
            goto L_0x0217
        L_0x0215:
            int r3 = r3.f6049b
        L_0x0217:
            int r5 = r0.f6098e
            int r9 = r0.f6099f
            int r10 = r0.l
            boolean r3 = a(r5, r9, r10, r3)
            if (r3 != 0) goto L_0x034e
            java.lang.String r3 = "repeatMode"
            boolean r5 = r1.has(r3)
            if (r5 == 0) goto L_0x0250
            java.lang.String r3 = r1.getString(r3)
            java.lang.Integer r3 = b.a.b.w.e.h(r3)
            if (r3 != 0) goto L_0x0238
            int r3 = r0.p
            goto L_0x023c
        L_0x0238:
            int r3 = r3.intValue()
        L_0x023c:
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            int r5 = r0.p
            int r9 = r3.intValue()
            if (r5 == r9) goto L_0x0250
            int r3 = r3.intValue()
            r0.p = r3
            r3 = 1
            goto L_0x0251
        L_0x0250:
            r3 = 0
        L_0x0251:
            java.lang.String r5 = "items"
            boolean r9 = r1.has(r5)
            if (r9 == 0) goto L_0x0348
            org.json.JSONArray r5 = r1.getJSONArray(r5)
            int r9 = r5.length()
            android.util.SparseArray r10 = new android.util.SparseArray
            r10.<init>()
            r11 = 0
        L_0x0267:
            if (r11 >= r9) goto L_0x027d
            org.json.JSONObject r12 = r5.getJSONObject(r11)
            java.lang.String r13 = "itemId"
            int r12 = r12.getInt(r13)
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)
            r10.put(r11, r12)
            int r11 = r11 + 1
            goto L_0x0267
        L_0x027d:
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            r12 = 0
        L_0x0283:
            if (r12 >= r9) goto L_0x033c
            java.lang.Object r13 = r10.get(r12)
            java.lang.Integer r13 = (java.lang.Integer) r13
            org.json.JSONObject r14 = r5.getJSONObject(r12)
            int r15 = r13.intValue()
            com.google.android.gms.cast.MediaQueueItem r15 = r0.b(r15)
            if (r15 == 0) goto L_0x02b3
            boolean r14 = r15.a(r14)
            r3 = r3 | r14
            r11.add(r15)
            int r13 = r13.intValue()
            java.lang.Integer r13 = r0.a((int) r13)
            int r13 = r13.intValue()
            r29 = r5
            if (r12 == r13) goto L_0x0334
            goto L_0x0333
        L_0x02b3:
            int r3 = r13.intValue()
            int r13 = r0.f6096c
            if (r3 != r13) goto L_0x0329
            com.google.android.gms.cast.MediaInfo r3 = r0.f6094a
            if (r3 == 0) goto L_0x0329
            com.google.android.gms.cast.MediaQueueItem r13 = new com.google.android.gms.cast.MediaQueueItem
            r17 = 0
            r18 = 1
            r19 = 9221120237041090560(0x7ff8000000000000, double:NaN)
            r21 = 9218868437227405312(0x7ff0000000000000, double:Infinity)
            r23 = 0
            r25 = 0
            r26 = 0
            r15 = r13
            r16 = r3
            r15.<init>(r16, r17, r18, r19, r21, r23, r25, r26)
            com.google.android.gms.cast.MediaInfo r3 = r13.f6087a
            if (r3 == 0) goto L_0x0321
            double r6 = r13.f6090d
            boolean r3 = java.lang.Double.isNaN(r6)
            r6 = 0
            r29 = r5
            if (r3 != 0) goto L_0x02f4
            double r4 = r13.f6090d
            int r3 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r3 < 0) goto L_0x02ec
            goto L_0x02f4
        L_0x02ec:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "startTime cannot be negative or NaN."
            r1.<init>(r2)
            throw r1
        L_0x02f4:
            double r3 = r13.f6091e
            boolean r3 = java.lang.Double.isNaN(r3)
            if (r3 != 0) goto L_0x0319
            double r3 = r13.f6092f
            boolean r3 = java.lang.Double.isNaN(r3)
            if (r3 != 0) goto L_0x0311
            double r3 = r13.f6092f
            int r5 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
            if (r5 < 0) goto L_0x0311
            r13.a(r14)
            r11.add(r13)
            goto L_0x0333
        L_0x0311:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "preloadTime cannot be negative or Nan."
            r1.<init>(r2)
            throw r1
        L_0x0319:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "playbackDuration cannot be NaN."
            r1.<init>(r2)
            throw r1
        L_0x0321:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "media cannot be null."
            r1.<init>(r2)
            throw r1
        L_0x0329:
            r29 = r5
            com.google.android.gms.cast.MediaQueueItem r3 = new com.google.android.gms.cast.MediaQueueItem
            r3.<init>(r14)
            r11.add(r3)
        L_0x0333:
            r3 = 1
        L_0x0334:
            int r12 = r12 + 1
            r5 = r29
            r4 = 0
            r7 = 1
            goto L_0x0283
        L_0x033c:
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r4 = r0.q
            int r4 = r4.size()
            if (r4 == r9) goto L_0x0345
            r3 = 1
        L_0x0345:
            r0.a((java.util.List<com.google.android.gms.cast.MediaQueueItem>) r11)
        L_0x0348:
            if (r3 == 0) goto L_0x034c
            r2 = r2 | 8
        L_0x034c:
            r3 = 0
            goto L_0x036b
        L_0x034e:
            r3 = 0
            r0.f6096c = r3
            r0.l = r3
            r0.m = r3
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r4 = r0.q
            boolean r4 = r4.isEmpty()
            if (r4 != 0) goto L_0x036b
            r0.p = r3
            java.util.List<com.google.android.gms.cast.MediaQueueItem> r4 = r0.q
            r4.clear()
            android.util.SparseArray<java.lang.Integer> r4 = r0.w
            r4.clear()
            r2 = r2 | 8
        L_0x036b:
            java.lang.String r4 = "breakStatus"
            org.json.JSONObject r4 = r1.optJSONObject(r4)
            com.google.android.gms.cast.AdBreakStatus r4 = com.google.android.gms.cast.AdBreakStatus.a(r4)
            com.google.android.gms.cast.AdBreakStatus r5 = r0.s
            if (r5 != 0) goto L_0x037b
            if (r4 != 0) goto L_0x0385
        L_0x037b:
            com.google.android.gms.cast.AdBreakStatus r5 = r0.s
            if (r5 == 0) goto L_0x038e
            boolean r5 = r5.equals(r4)
            if (r5 != 0) goto L_0x038e
        L_0x0385:
            if (r4 == 0) goto L_0x0388
            r3 = 1
        L_0x0388:
            r0.r = r3
            r0.s = r4
            r2 = r2 | 32
        L_0x038e:
            java.lang.String r3 = "videoInfo"
            org.json.JSONObject r3 = r1.optJSONObject(r3)
            com.google.android.gms.cast.VideoInfo r3 = com.google.android.gms.cast.VideoInfo.a(r3)
            com.google.android.gms.cast.VideoInfo r4 = r0.t
            if (r4 != 0) goto L_0x039e
            if (r3 != 0) goto L_0x03a8
        L_0x039e:
            com.google.android.gms.cast.VideoInfo r4 = r0.t
            if (r4 == 0) goto L_0x03ac
            boolean r4 = r4.equals(r3)
            if (r4 != 0) goto L_0x03ac
        L_0x03a8:
            r0.t = r3
            r2 = r2 | 64
        L_0x03ac:
            java.lang.String r3 = "breakInfo"
            boolean r4 = r1.has(r3)
            if (r4 == 0) goto L_0x03c1
            com.google.android.gms.cast.MediaInfo r4 = r0.f6094a
            if (r4 == 0) goto L_0x03c1
            org.json.JSONObject r3 = r1.getJSONObject(r3)
            r4.a(r3)
            r2 = r2 | 2
        L_0x03c1:
            java.lang.String r3 = "queueData"
            boolean r4 = r1.has(r3)
            if (r4 == 0) goto L_0x03dc
            com.google.android.gms.cast.MediaQueueData r4 = new com.google.android.gms.cast.MediaQueueData
            r4.<init>(r8)
            org.json.JSONObject r3 = r1.getJSONObject(r3)
            com.google.android.gms.cast.MediaQueueData.a(r4, r3)
            com.google.android.gms.cast.MediaQueueData r3 = new com.google.android.gms.cast.MediaQueueData
            r3.<init>(r4, r8)
            r0.v = r3
        L_0x03dc:
            java.lang.String r3 = "liveSeekableRange"
            boolean r4 = r1.has(r3)
            if (r4 == 0) goto L_0x03f1
            org.json.JSONObject r1 = r1.optJSONObject(r3)
            com.google.android.gms.cast.MediaLiveSeekableRange r1 = com.google.android.gms.cast.MediaLiveSeekableRange.a(r1)
            r0.u = r1
            r1 = 2
            r1 = r1 | r2
            goto L_0x03fa
        L_0x03f1:
            com.google.android.gms.cast.MediaLiveSeekableRange r1 = r0.u
            if (r1 == 0) goto L_0x03f7
            r2 = r2 | 2
        L_0x03f7:
            r0.u = r8
            r1 = r2
        L_0x03fa:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaStatus.a(org.json.JSONObject, int):int");
    }

    public Integer a(int i2) {
        return this.w.get(i2);
    }

    public MediaQueueItem b(int i2) {
        Integer num = this.w.get(i2);
        if (num == null) {
            return null;
        }
        return this.q.get(num.intValue());
    }

    public boolean equals(Object obj) {
        JSONObject jSONObject;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaStatus)) {
            return false;
        }
        MediaStatus mediaStatus = (MediaStatus) obj;
        if ((this.o == null) == (mediaStatus.o == null) && this.f6095b == mediaStatus.f6095b && this.f6096c == mediaStatus.f6096c && this.f6097d == mediaStatus.f6097d && this.f6098e == mediaStatus.f6098e && this.f6099f == mediaStatus.f6099f && this.f6100g == mediaStatus.f6100g && this.i == mediaStatus.i && this.j == mediaStatus.j && this.l == mediaStatus.l && this.m == mediaStatus.m && this.p == mediaStatus.p && Arrays.equals(this.k, mediaStatus.k) && a.a(Long.valueOf(this.h), Long.valueOf(mediaStatus.h)) && a.a(this.q, mediaStatus.q) && a.a(this.f6094a, mediaStatus.f6094a)) {
            JSONObject jSONObject2 = this.o;
            return (jSONObject2 == null || (jSONObject = mediaStatus.o) == null || e.a(jSONObject2, jSONObject)) && this.r == mediaStatus.r && a.a(this.s, mediaStatus.s) && a.a(this.t, mediaStatus.t) && a.a(this.u, mediaStatus.u) && b.a.b.w.e.c((Object) this.v, (Object) mediaStatus.v);
        }
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6094a, Long.valueOf(this.f6095b), Integer.valueOf(this.f6096c), Double.valueOf(this.f6097d), Integer.valueOf(this.f6098e), Integer.valueOf(this.f6099f), Long.valueOf(this.f6100g), Long.valueOf(this.h), Double.valueOf(this.i), Boolean.valueOf(this.j), Integer.valueOf(Arrays.hashCode(this.k)), Integer.valueOf(this.l), Integer.valueOf(this.m), String.valueOf(this.o), Integer.valueOf(this.p), this.q, Boolean.valueOf(this.r), this.s, this.t, this.u, this.v});
    }

    public AdBreakClipInfo p() {
        AdBreakStatus adBreakStatus = this.s;
        if (!(adBreakStatus == null || this.f6094a == null)) {
            String str = adBreakStatus.f6019d;
            if (TextUtils.isEmpty(str)) {
                return null;
            }
            List<AdBreakClipInfo> list = this.f6094a.j;
            List<T> unmodifiableList = list == null ? null : Collections.unmodifiableList(list);
            if (unmodifiableList != null && !unmodifiableList.isEmpty()) {
                for (T t2 : unmodifiableList) {
                    if (str.equals(t2.f6002a)) {
                        return t2;
                    }
                }
            }
        }
        return null;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        JSONObject jSONObject = this.o;
        this.n = jSONObject == null ? null : jSONObject.toString();
        int a2 = d.a(parcel);
        d.a(parcel, 2, (Parcelable) this.f6094a, i2, false);
        d.a(parcel, 3, this.f6095b);
        d.a(parcel, 4, this.f6096c);
        d.a(parcel, 5, this.f6097d);
        d.a(parcel, 6, this.f6098e);
        d.a(parcel, 7, this.f6099f);
        d.a(parcel, 8, this.f6100g);
        d.a(parcel, 9, this.h);
        d.a(parcel, 10, this.i);
        d.a(parcel, 11, this.j);
        d.a(parcel, 12, this.k, false);
        d.a(parcel, 13, this.l);
        d.a(parcel, 14, this.m);
        d.a(parcel, 15, this.n, false);
        d.a(parcel, 16, this.p);
        d.b(parcel, 17, this.q, false);
        d.a(parcel, 18, this.r);
        d.a(parcel, 19, (Parcelable) this.s, i2, false);
        d.a(parcel, 20, (Parcelable) this.t, i2, false);
        d.a(parcel, 21, (Parcelable) this.u, i2, false);
        d.a(parcel, 22, (Parcelable) this.v, i2, false);
        d.b(parcel, a2);
    }

    public final void a(List<MediaQueueItem> list) {
        this.q.clear();
        this.w.clear();
        if (list != null) {
            for (int i2 = 0; i2 < list.size(); i2++) {
                MediaQueueItem mediaQueueItem = list.get(i2);
                this.q.add(mediaQueueItem);
                this.w.put(mediaQueueItem.f6088b, Integer.valueOf(i2));
            }
        }
    }
}
