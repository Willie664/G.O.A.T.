package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.i.a;
import b.c.a.b.c.i.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzb extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzb> CREATOR = new d();

    /* renamed from: a  reason: collision with root package name */
    public String f6219a;

    public zzb() {
        this.f6219a = null;
    }

    public zzb(String str) {
        this.f6219a = str;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzb)) {
            return false;
        }
        return a.a(this.f6219a, ((zzb) obj).f6219a);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f6219a});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.c.a.b.d.n.u.d.a(parcel);
        b.c.a.b.d.n.u.d.a(parcel, 2, this.f6219a, false);
        b.c.a.b.d.n.u.d.b(parcel, a2);
    }
}
