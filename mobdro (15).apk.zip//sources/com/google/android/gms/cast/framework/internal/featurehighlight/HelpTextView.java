package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Keep;
import androidx.annotation.Nullable;
import b.c.a.b.c.g.l;
import b.c.a.b.c.g.v.a.h;
import com.google.android.gms.internal.cast.zzee;

@Keep
public class HelpTextView extends LinearLayout implements h {
    public TextView zzom;
    public TextView zzon;

    @Keep
    public HelpTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public static void zza(TextView textView, @Nullable CharSequence charSequence) {
        textView.setText(charSequence);
        textView.setVisibility(TextUtils.isEmpty(charSequence) ? 8 : 0);
    }

    @Keep
    public View asView() {
        return this;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.zzom = (TextView) zzee.checkNotNull((TextView) findViewById(l.cast_featurehighlight_help_text_header_view));
        this.zzon = (TextView) zzee.checkNotNull((TextView) findViewById(l.cast_featurehighlight_help_text_body_view));
    }

    @Keep
    public void setText(@Nullable CharSequence charSequence, @Nullable CharSequence charSequence2) {
        zza(this.zzom, charSequence);
        zza(this.zzon, charSequence2);
    }
}
