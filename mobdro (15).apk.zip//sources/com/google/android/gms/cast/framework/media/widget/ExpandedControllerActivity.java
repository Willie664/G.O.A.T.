package com.google.android.gms.cast.framework.media.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.appcompat.R;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import b.a.b.w.e;
import b.c.a.b.c.g.c;
import b.c.a.b.c.g.l;
import b.c.a.b.c.g.n;
import b.c.a.b.c.g.o;
import b.c.a.b.c.g.p;
import b.c.a.b.c.g.q;
import b.c.a.b.c.g.r;
import b.c.a.b.c.g.s;
import b.c.a.b.c.g.t;
import b.c.a.b.c.g.w.d;
import b.c.a.b.c.g.w.g.f;
import b.c.a.b.c.g.w.g.h;
import b.c.a.b.c.g.w.g.i;
import b.c.a.b.c.g.w.g.j;
import b.c.a.b.c.g.w.g.k;
import b.c.a.b.c.g.w.g.m;
import b.c.a.b.c.g.w.h.d;
import b.c.a.b.c.g.w.h.g;
import com.google.android.gms.cast.AdBreakClipInfo;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.media.ImageHints;
import com.google.android.gms.internal.cast.zzbc;
import com.google.android.gms.internal.cast.zzbd;
import com.google.android.gms.internal.cast.zzbe;
import com.google.android.gms.internal.cast.zzbi;
import com.google.android.gms.internal.cast.zzbj;
import com.google.android.gms.internal.cast.zzbo;
import com.google.android.gms.internal.cast.zzbq;
import com.google.android.gms.internal.cast.zzbs;
import com.google.android.gms.internal.cast.zzbt;
import com.google.android.gms.internal.cast.zzbw;
import com.google.android.gms.internal.cast.zzcc;
import com.google.android.gms.internal.cast.zzcd;
import com.google.android.gms.internal.cast.zzce;
import com.google.android.gms.internal.cast.zzcf;
import com.google.android.gms.internal.cast.zzjg;
import com.google.android.gms.internal.cast.zzm;
import java.util.Timer;

public class ExpandedControllerActivity extends AppCompatActivity {
    public View A;
    public View B;
    public ImageView C;
    public TextView D;
    public TextView E;
    public TextView F;
    public TextView G;
    public b.c.a.b.c.g.w.f.a H;
    public b.c.a.b.c.g.w.g.b I;
    public s J;
    public boolean K;
    public boolean L;
    public Timer M;
    @Nullable
    public String N;

    /* renamed from: a  reason: collision with root package name */
    public final t<c> f6210a = new a((d) null);

    /* renamed from: b  reason: collision with root package name */
    public final d.b f6211b = new b((b.c.a.b.c.g.w.h.d) null);
    @DrawableRes

    /* renamed from: c  reason: collision with root package name */
    public int f6212c;
    @DrawableRes

    /* renamed from: d  reason: collision with root package name */
    public int f6213d;
    @DrawableRes

    /* renamed from: e  reason: collision with root package name */
    public int f6214e;
    @DrawableRes

    /* renamed from: f  reason: collision with root package name */
    public int f6215f;
    @DrawableRes

    /* renamed from: g  reason: collision with root package name */
    public int f6216g;
    @DrawableRes
    public int h;
    @DrawableRes
    public int i;
    @DrawableRes
    public int j;
    @DrawableRes
    public int k;
    @DrawableRes
    public int l;
    @ColorInt
    public int m;
    @ColorInt
    public int n;
    @ColorInt
    public int o;
    @ColorInt
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public TextView u;
    public CastSeekBar v;
    public ImageView w;
    public ImageView x;
    public int[] y;
    public ImageView[] z = new ImageView[4];

    public class a implements t<c> {
        public /* synthetic */ a(b.c.a.b.c.g.w.h.d dVar) {
        }

        public final /* synthetic */ void onSessionEnded(r rVar, int i) {
            c cVar = (c) rVar;
            ExpandedControllerActivity.this.finish();
        }

        public final /* bridge */ /* synthetic */ void onSessionEnding(r rVar) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionResumeFailed(r rVar, int i) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionResumed(r rVar, boolean z) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionResuming(r rVar, String str) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionStartFailed(r rVar, int i) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionStarted(r rVar, String str) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionStarting(r rVar) {
            c cVar = (c) rVar;
        }

        public final /* bridge */ /* synthetic */ void onSessionSuspended(r rVar, int i) {
            c cVar = (c) rVar;
        }
    }

    public class b implements d.b {
        public /* synthetic */ b(b.c.a.b.c.g.w.h.d dVar) {
        }

        public final void a() {
            ExpandedControllerActivity.this.h();
        }

        public final void b() {
        }

        public final void c() {
            b.c.a.b.c.g.w.d a2 = ExpandedControllerActivity.this.g();
            if (a2 == null || !a2.l()) {
                ExpandedControllerActivity expandedControllerActivity = ExpandedControllerActivity.this;
                if (!expandedControllerActivity.K) {
                    expandedControllerActivity.finish();
                    return;
                }
                return;
            }
            ExpandedControllerActivity expandedControllerActivity2 = ExpandedControllerActivity.this;
            expandedControllerActivity2.K = false;
            expandedControllerActivity2.i();
            ExpandedControllerActivity.this.j();
        }

        public final void d() {
            ExpandedControllerActivity expandedControllerActivity = ExpandedControllerActivity.this;
            expandedControllerActivity.u.setText(expandedControllerActivity.getResources().getString(o.cast_expanded_controller_loading));
        }

        public final void e() {
            ExpandedControllerActivity.this.j();
        }

        public final void f() {
        }
    }

    public final void a(View view, int i2, int i3, b.c.a.b.c.g.w.g.b bVar) {
        ImageView imageView = (ImageView) view.findViewById(i2);
        if (i3 == l.cast_button_type_empty) {
            imageView.setVisibility(4);
        } else if (i3 == l.cast_button_type_custom) {
        } else {
            if (i3 == l.cast_button_type_play_pause_toggle) {
                imageView.setBackgroundResource(this.f6212c);
                Drawable a2 = g.a(this, this.q, this.f6214e);
                Drawable a3 = g.a(this, this.q, this.f6213d);
                Drawable a4 = g.a(this, this.q, this.f6215f);
                imageView.setImageDrawable(a3);
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    zzm.zza(zzjg.PAUSE_CONTROLLER);
                    imageView.setOnClickListener(new f(bVar));
                    bVar.b(imageView, new zzbq(imageView, bVar.f1581a, a3, a2, a4, (View) null, false));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_skip_previous) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.f6216g));
                imageView.setContentDescription(getResources().getString(o.cast_skip_prev));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new j(bVar));
                    bVar.b(imageView, new zzbw(imageView, 0));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_skip_next) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.h));
                imageView.setContentDescription(getResources().getString(o.cast_skip_next));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new b.c.a.b.c.g.w.g.g(bVar));
                    bVar.b(imageView, new zzbt(imageView, 0));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_rewind_30_seconds) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.i));
                imageView.setContentDescription(getResources().getString(o.cast_rewind_30));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new b.c.a.b.c.g.w.g.l(bVar, 30000));
                    bVar.b(imageView, new zzbs(imageView, bVar.f1585e));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_forward_30_seconds) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.j));
                imageView.setContentDescription(getResources().getString(o.cast_forward_30));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new i(bVar, 30000));
                    bVar.b(imageView, new zzbd(imageView, bVar.f1585e));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_mute_toggle) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.k));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new h(bVar));
                    bVar.b(imageView, new zzbo(imageView, bVar.f1581a));
                    return;
                }
                throw null;
            } else if (i3 == l.cast_button_type_closed_caption) {
                imageView.setBackgroundResource(this.f6212c);
                imageView.setImageDrawable(g.a(this, this.q, this.l));
                if (bVar != null) {
                    e.c("Must be called from the main thread.");
                    imageView.setOnClickListener(new m(bVar));
                    bVar.b(imageView, new zzbe(imageView, bVar.f1581a));
                    return;
                }
                throw null;
            }
        }
    }

    public final b.c.a.b.c.g.w.d g() {
        c a2 = this.J.a();
        if (a2 == null || !a2.a()) {
            return null;
        }
        return a2.d();
    }

    public final void h() {
        MediaInfo g2;
        MediaMetadata mediaMetadata;
        ActionBar supportActionBar;
        b.c.a.b.c.g.w.d g3 = g();
        if (g3 != null && g3.l() && (g2 = g3.g()) != null && (mediaMetadata = g2.f6051d) != null && (supportActionBar = getSupportActionBar()) != null) {
            supportActionBar.setTitle((CharSequence) mediaMetadata.c("com.google.android.gms.cast.metadata.TITLE"));
            supportActionBar.setSubtitle((CharSequence) e.a(mediaMetadata));
        }
    }

    public final void i() {
        CastDevice c2;
        c a2 = this.J.a();
        if (!(a2 == null || (c2 = a2.c()) == null)) {
            String str = c2.f6031d;
            if (!TextUtils.isEmpty(str)) {
                this.u.setText(getResources().getString(o.cast_casting_to_device, new Object[]{str}));
                return;
            }
        }
        this.u.setText("");
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x0124  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x013f  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0143  */
    @android.annotation.TargetApi(23)
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void j() {
        /*
            r17 = this;
            r0 = r17
            b.c.a.b.c.g.w.d r1 = r17.g()
            if (r1 == 0) goto L_0x0168
            com.google.android.gms.cast.MediaStatus r2 = r1.h()
            if (r2 != 0) goto L_0x0010
            goto L_0x0168
        L_0x0010:
            com.google.android.gms.cast.MediaStatus r2 = r1.h()
            boolean r2 = r2.r
            r3 = 0
            r4 = 8
            if (r2 == 0) goto L_0x014f
            android.widget.ImageView r2 = r0.x
            int r2 = r2.getVisibility()
            r5 = 1
            r6 = 0
            if (r2 != r4) goto L_0x00d8
            android.widget.ImageView r2 = r0.w
            android.graphics.drawable.Drawable r2 = r2.getDrawable()
            if (r2 == 0) goto L_0x00d8
            boolean r7 = r2 instanceof android.graphics.drawable.BitmapDrawable
            if (r7 == 0) goto L_0x00d8
            android.graphics.drawable.BitmapDrawable r2 = (android.graphics.drawable.BitmapDrawable) r2
            android.graphics.Bitmap r2 = r2.getBitmap()
            if (r2 == 0) goto L_0x00d8
            b.c.a.b.c.i.b r7 = b.c.a.b.c.g.w.h.g.f1607a
            r8 = 3
            java.lang.Object[] r9 = new java.lang.Object[r8]
            r9[r6] = r2
            int r10 = r2.getWidth()
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r9[r5] = r10
            int r10 = r2.getHeight()
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r11 = 2
            r9[r11] = r10
            boolean r10 = r7.a()
            if (r10 != 0) goto L_0x005c
            goto L_0x0061
        L_0x005c:
            java.lang.String r10 = "Begin blurring bitmap %s, original width = %d, original height = %d."
            r7.b(r10, r9)
        L_0x0061:
            int r7 = r2.getWidth()
            float r7 = (float) r7
            r9 = 1048576000(0x3e800000, float:0.25)
            float r7 = r7 * r9
            int r7 = java.lang.Math.round(r7)
            int r10 = r2.getHeight()
            float r10 = (float) r10
            float r10 = r10 * r9
            int r9 = java.lang.Math.round(r10)
            android.graphics.Bitmap r2 = android.graphics.Bitmap.createScaledBitmap(r2, r7, r9, r6)
            android.graphics.Bitmap$Config r10 = r2.getConfig()
            android.graphics.Bitmap r10 = android.graphics.Bitmap.createBitmap(r7, r9, r10)
            android.renderscript.RenderScript r12 = android.renderscript.RenderScript.create(r17)
            android.renderscript.Allocation r13 = android.renderscript.Allocation.createFromBitmap(r12, r2)
            android.renderscript.Type r14 = r13.getType()
            android.renderscript.Allocation r14 = android.renderscript.Allocation.createTyped(r12, r14)
            android.renderscript.Element r15 = r13.getElement()
            android.renderscript.ScriptIntrinsicBlur r15 = android.renderscript.ScriptIntrinsicBlur.create(r12, r15)
            r15.setInput(r13)
            r13 = 1089470464(0x40f00000, float:7.5)
            r15.setRadius(r13)
            r15.forEach(r14)
            r14.copyTo(r10)
            r12.destroy()
            b.c.a.b.c.i.b r12 = b.c.a.b.c.g.w.h.g.f1607a
            java.lang.Object[] r8 = new java.lang.Object[r8]
            r8[r6] = r2
            java.lang.Integer r2 = java.lang.Integer.valueOf(r7)
            r8[r5] = r2
            java.lang.Integer r2 = java.lang.Integer.valueOf(r9)
            r8[r11] = r2
            boolean r2 = r12.a()
            if (r2 != 0) goto L_0x00c7
            goto L_0x00cc
        L_0x00c7:
            java.lang.String r2 = "End blurring bitmap %s, original width = %d, original height = %d."
            r12.b(r2, r8)
        L_0x00cc:
            if (r10 == 0) goto L_0x00d8
            android.widget.ImageView r2 = r0.x
            r2.setImageBitmap(r10)
            android.widget.ImageView r2 = r0.x
            r2.setVisibility(r6)
        L_0x00d8:
            com.google.android.gms.cast.MediaStatus r2 = r1.h()
            com.google.android.gms.cast.AdBreakClipInfo r2 = r2.p()
            if (r2 == 0) goto L_0x00ec
            java.lang.String r3 = r2.f6003b
            java.lang.String r2 = r2.i
            r16 = r3
            r3 = r2
            r2 = r16
            goto L_0x00ed
        L_0x00ec:
            r2 = r3
        L_0x00ed:
            boolean r7 = android.text.TextUtils.isEmpty(r3)
            if (r7 != 0) goto L_0x00f4
            goto L_0x00fe
        L_0x00f4:
            java.lang.String r3 = r0.N
            boolean r3 = android.text.TextUtils.isEmpty(r3)
            if (r3 != 0) goto L_0x010d
            java.lang.String r3 = r0.N
        L_0x00fe:
            android.net.Uri r3 = android.net.Uri.parse(r3)
            b.c.a.b.c.g.w.f.a r7 = r0.H
            r7.a(r3)
            android.view.View r3 = r0.B
            r3.setVisibility(r4)
            goto L_0x011c
        L_0x010d:
            android.widget.TextView r3 = r0.D
            r3.setVisibility(r6)
            android.view.View r3 = r0.B
            r3.setVisibility(r6)
            android.widget.ImageView r3 = r0.C
            r3.setVisibility(r4)
        L_0x011c:
            android.widget.TextView r3 = r0.E
            boolean r4 = android.text.TextUtils.isEmpty(r2)
            if (r4 == 0) goto L_0x012e
            android.content.res.Resources r2 = r17.getResources()
            int r4 = b.c.a.b.c.g.o.cast_ad_label
            java.lang.String r2 = r2.getString(r4)
        L_0x012e:
            r3.setText(r2)
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 23
            if (r2 < r3) goto L_0x0138
            goto L_0x0139
        L_0x0138:
            r5 = 0
        L_0x0139:
            android.widget.TextView r2 = r0.E
            int r3 = r0.r
            if (r5 == 0) goto L_0x0143
            r2.setTextAppearance(r3)
            goto L_0x0146
        L_0x0143:
            r2.setTextAppearance(r0, r3)
        L_0x0146:
            android.view.View r2 = r0.A
            r2.setVisibility(r6)
            r0.a((b.c.a.b.c.g.w.d) r1)
            return
        L_0x014f:
            android.widget.TextView r1 = r0.G
            r1.setVisibility(r4)
            android.widget.TextView r1 = r0.F
            r1.setVisibility(r4)
            android.view.View r1 = r0.A
            r1.setVisibility(r4)
            android.widget.ImageView r1 = r0.x
            r1.setVisibility(r4)
            android.widget.ImageView r1 = r0.x
            r1.setImageBitmap(r3)
        L_0x0168:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.widget.ExpandedControllerActivity.j():void");
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        s b2 = b.c.a.b.c.g.b.a((Context) this).b();
        this.J = b2;
        if (b2.a() == null) {
            finish();
        }
        b.c.a.b.c.g.w.g.b bVar = new b.c.a.b.c.g.w.g.b(this);
        this.I = bVar;
        d.b bVar2 = this.f6211b;
        e.c("Must be called from the main thread.");
        bVar.f1586f = bVar2;
        setContentView(n.cast_expanded_controller_activity);
        boolean z2 = true;
        TypedArray obtainStyledAttributes = obtainStyledAttributes(new int[]{R.attr.selectableItemBackgroundBorderless});
        this.f6212c = obtainStyledAttributes.getResourceId(0, 0);
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = obtainStyledAttributes((AttributeSet) null, q.CastExpandedController, b.c.a.b.c.g.h.castExpandedControllerStyle, p.CastExpandedController);
        this.q = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castButtonColor, 0);
        this.f6213d = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castPlayButtonDrawable, 0);
        this.f6214e = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castPauseButtonDrawable, 0);
        this.f6215f = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castStopButtonDrawable, 0);
        this.f6216g = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castSkipPreviousButtonDrawable, 0);
        this.h = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castSkipNextButtonDrawable, 0);
        this.i = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castRewind30ButtonDrawable, 0);
        this.j = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castForward30ButtonDrawable, 0);
        this.k = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castMuteToggleButtonDrawable, 0);
        this.l = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castClosedCaptionsButtonDrawable, 0);
        int resourceId = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castControlButtons, 0);
        if (resourceId != 0) {
            TypedArray obtainTypedArray = getResources().obtainTypedArray(resourceId);
            e.a(obtainTypedArray.length() == 4);
            this.y = new int[obtainTypedArray.length()];
            for (int i2 = 0; i2 < obtainTypedArray.length(); i2++) {
                this.y[i2] = obtainTypedArray.getResourceId(i2, 0);
            }
            obtainTypedArray.recycle();
        } else {
            int i3 = l.cast_button_type_empty;
            this.y = new int[]{i3, i3, i3, i3};
        }
        this.p = obtainStyledAttributes2.getColor(q.CastExpandedController_castExpandedControllerLoadingIndicatorColor, 0);
        this.m = getResources().getColor(obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdLabelColor, 0));
        this.n = getResources().getColor(obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdInProgressTextColor, 0));
        this.o = getResources().getColor(obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdLabelTextColor, 0));
        this.r = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdLabelTextAppearance, 0);
        this.s = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdInProgressLabelTextAppearance, 0);
        this.t = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castAdInProgressText, 0);
        int resourceId2 = obtainStyledAttributes2.getResourceId(q.CastExpandedController_castDefaultAdPosterUrl, 0);
        if (resourceId2 != 0) {
            this.N = getApplicationContext().getResources().getString(resourceId2);
        }
        obtainStyledAttributes2.recycle();
        View findViewById = findViewById(l.expanded_controller_layout);
        b.c.a.b.c.g.w.g.b bVar3 = this.I;
        this.w = (ImageView) findViewById.findViewById(l.background_image_view);
        this.x = (ImageView) findViewById.findViewById(l.blurred_background_image_view);
        View findViewById2 = findViewById.findViewById(l.background_place_holder_image_view);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        ImageView imageView = this.w;
        ImageHints imageHints = new ImageHints(4, displayMetrics.widthPixels, displayMetrics.heightPixels);
        if (bVar3 != null) {
            e.c("Must be called from the main thread.");
            bVar3.b(imageView, new zzbi(imageView, bVar3.f1581a, imageHints, 0, findViewById2));
            this.u = (TextView) findViewById.findViewById(l.status_text);
            ProgressBar progressBar = (ProgressBar) findViewById.findViewById(l.loading_indicator);
            Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
            int i4 = this.p;
            if (i4 != 0) {
                indeterminateDrawable.setColorFilter(i4, PorterDuff.Mode.SRC_IN);
            }
            e.c("Must be called from the main thread.");
            bVar3.b(progressBar, new zzbj(progressBar));
            TextView textView = (TextView) findViewById.findViewById(l.start_text);
            TextView textView2 = (TextView) findViewById.findViewById(l.end_text);
            SeekBar seekBar = (SeekBar) findViewById.findViewById(l.seek_bar);
            CastSeekBar castSeekBar = (CastSeekBar) findViewById.findViewById(l.cast_seek_bar);
            this.v = castSeekBar;
            e.c("Must be called from the main thread.");
            zzm.zza(zzjg.SEEK_CONTROLLER);
            castSeekBar.f6199e = new k(bVar3);
            bVar3.b(castSeekBar, new zzbc(castSeekBar, 1000, bVar3.f1585e));
            bVar3.a(textView, new zzcf(textView, bVar3.f1585e));
            bVar3.a(textView2, new zzcd(textView2, bVar3.f1585e));
            View findViewById3 = findViewById.findViewById(l.live_indicators);
            b.c.a.b.c.g.w.g.b bVar4 = this.I;
            bVar4.a(findViewById3, new zzcc(findViewById3, bVar4.f1585e));
            RelativeLayout relativeLayout = (RelativeLayout) findViewById.findViewById(l.tooltip_container);
            zzce zzce = new zzce(relativeLayout, this.v, this.I.f1585e);
            this.I.a(relativeLayout, zzce);
            this.I.f1584d.add(zzce);
            this.z[0] = (ImageView) findViewById.findViewById(l.button_0);
            this.z[1] = (ImageView) findViewById.findViewById(l.button_1);
            this.z[2] = (ImageView) findViewById.findViewById(l.button_2);
            this.z[3] = (ImageView) findViewById.findViewById(l.button_3);
            a(findViewById, l.button_0, this.y[0], bVar3);
            a(findViewById, l.button_1, this.y[1], bVar3);
            a(findViewById, l.button_play_pause_toggle, l.cast_button_type_play_pause_toggle, bVar3);
            a(findViewById, l.button_2, this.y[2], bVar3);
            a(findViewById, l.button_3, this.y[3], bVar3);
            View findViewById4 = findViewById(l.ad_container);
            this.A = findViewById4;
            this.C = (ImageView) findViewById4.findViewById(l.ad_image_view);
            this.B = this.A.findViewById(l.ad_background_image_view);
            TextView textView3 = (TextView) this.A.findViewById(l.ad_label);
            this.E = textView3;
            textView3.setTextColor(this.o);
            this.E.setBackgroundColor(this.m);
            this.D = (TextView) this.A.findViewById(l.ad_in_progress_label);
            this.G = (TextView) findViewById(l.ad_skip_text);
            TextView textView4 = (TextView) findViewById(l.ad_skip_button);
            this.F = textView4;
            textView4.setOnClickListener(new b.c.a.b.c.g.w.h.c(this));
            setSupportActionBar((Toolbar) findViewById(l.toolbar));
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeAsUpIndicator(b.c.a.b.c.g.k.quantum_ic_keyboard_arrow_down_white_36);
            }
            i();
            h();
            if (!(this.D == null || this.t == 0)) {
                if (Build.VERSION.SDK_INT < 23) {
                    z2 = false;
                }
                if (z2) {
                    this.D.setTextAppearance(this.s);
                } else {
                    this.D.setTextAppearance(getApplicationContext(), this.s);
                }
                this.D.setTextColor(this.n);
                this.D.setText(this.t);
            }
            b.c.a.b.c.g.w.f.a aVar = new b.c.a.b.c.g.w.f.a(getApplicationContext(), new ImageHints(-1, this.C.getWidth(), this.C.getHeight()));
            this.H = aVar;
            aVar.f1565g = new b.c.a.b.c.g.w.h.d(this);
            zzm.zza(zzjg.CAF_EXPANDED_CONTROLLER);
            return;
        }
        throw null;
    }

    public void onDestroy() {
        this.H.a();
        b.c.a.b.c.g.w.g.b bVar = this.I;
        if (bVar != null) {
            e.c("Must be called from the main thread.");
            bVar.f1586f = null;
            b.c.a.b.c.g.w.g.b bVar2 = this.I;
            if (bVar2 != null) {
                e.c("Must be called from the main thread.");
                bVar2.i();
                bVar2.f1583c.clear();
                s sVar = bVar2.f1582b;
                if (sVar != null) {
                    sVar.b(bVar2, c.class);
                }
                bVar2.f1586f = null;
            } else {
                throw null;
            }
        }
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return true;
        }
        finish();
        return true;
    }

    public void onPause() {
        b.c.a.b.c.g.b.a((Context) this).b().b(this.f6210a, c.class);
        super.onPause();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0050, code lost:
        if (r0 != false) goto L_0x0055;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onResume() {
        /*
            r5 = this;
            b.c.a.b.c.g.b r0 = b.c.a.b.c.g.b.a((android.content.Context) r5)
            b.c.a.b.c.g.s r0 = r0.b()
            b.c.a.b.c.g.t<b.c.a.b.c.g.c> r1 = r5.f6210a
            java.lang.Class<b.c.a.b.c.g.c> r2 = b.c.a.b.c.g.c.class
            r0.a(r1, r2)
            b.c.a.b.c.g.b r0 = b.c.a.b.c.g.b.a((android.content.Context) r5)
            b.c.a.b.c.g.s r0 = r0.b()
            b.c.a.b.c.g.c r0 = r0.a()
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x0052
            boolean r3 = r0.a()
            if (r3 != 0) goto L_0x0055
            java.lang.String r3 = "Must be called from the main thread."
            b.a.b.w.e.c((java.lang.String) r3)
            b.c.a.b.c.g.t0 r0 = r0.f1495a     // Catch:{ RemoteException -> 0x0031 }
            boolean r0 = r0.isConnecting()     // Catch:{ RemoteException -> 0x0031 }
            goto L_0x0050
        L_0x0031:
            b.c.a.b.c.i.b r0 = b.c.a.b.c.g.r.f1494c
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r4 = "isConnecting"
            r3[r2] = r4
            java.lang.Class<b.c.a.b.c.g.t0> r4 = b.c.a.b.c.g.t0.class
            java.lang.String r4 = r4.getSimpleName()
            r3[r1] = r4
            boolean r4 = r0.a()
            if (r4 != 0) goto L_0x004a
            goto L_0x004f
        L_0x004a:
            java.lang.String r4 = "Unable to call %s on %s."
            r0.b(r4, r3)
        L_0x004f:
            r0 = 0
        L_0x0050:
            if (r0 != 0) goto L_0x0055
        L_0x0052:
            r5.finish()
        L_0x0055:
            b.c.a.b.c.g.w.d r0 = r5.g()
            if (r0 == 0) goto L_0x0063
            boolean r0 = r0.l()
            if (r0 != 0) goto L_0x0062
            goto L_0x0063
        L_0x0062:
            r1 = 0
        L_0x0063:
            r5.K = r1
            r5.i()
            r5.j()
            super.onResume()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.framework.media.widget.ExpandedControllerActivity.onResume():void");
    }

    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (z2) {
            getWindow().getDecorView().setSystemUiVisibility(((getWindow().getDecorView().getSystemUiVisibility() ^ 2) ^ 4) ^ 4096);
            setImmersive(true);
        }
    }

    public final void a(b.c.a.b.c.g.w.d dVar) {
        if (!this.K && !dVar.m()) {
            this.F.setVisibility(8);
            this.G.setVisibility(8);
            AdBreakClipInfo p2 = dVar.h().p();
            if (p2 != null && p2.j != -1) {
                if (!this.L) {
                    b.c.a.b.c.g.w.h.f fVar = new b.c.a.b.c.g.w.h.f(this, dVar);
                    Timer timer = new Timer();
                    this.M = timer;
                    timer.scheduleAtFixedRate(fVar, 0, 500);
                    this.L = true;
                }
                float a2 = (float) (p2.j - dVar.a());
                if (a2 <= 0.0f) {
                    if (this.L) {
                        this.M.cancel();
                        this.L = false;
                    }
                    this.F.setVisibility(0);
                    this.F.setClickable(true);
                    return;
                }
                this.G.setVisibility(0);
                this.G.setText(getResources().getString(o.cast_expanded_controller_skip_ad_text, new Object[]{Integer.valueOf((int) Math.ceil((double) (a2 / 1000.0f)))}));
                this.F.setClickable(false);
            }
        }
    }
}
