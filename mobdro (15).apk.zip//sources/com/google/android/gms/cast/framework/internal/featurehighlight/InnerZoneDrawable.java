package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import androidx.annotation.Keep;
import b.c.a.b.c.g.j;
import b.c.a.b.c.g.m;
import com.google.android.gms.internal.cast.zzed;

public class InnerZoneDrawable extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final Paint f6130a = new Paint();

    /* renamed from: b  reason: collision with root package name */
    public final Paint f6131b = new Paint();

    /* renamed from: c  reason: collision with root package name */
    public final Rect f6132c = new Rect();

    /* renamed from: d  reason: collision with root package name */
    public final int f6133d;

    /* renamed from: e  reason: collision with root package name */
    public final int f6134e;

    /* renamed from: f  reason: collision with root package name */
    public float f6135f;

    /* renamed from: g  reason: collision with root package name */
    public float f6136g = 1.0f;
    public float h;
    public float i;
    public float j;
    public float k;

    public InnerZoneDrawable(Context context) {
        Resources resources = context.getResources();
        this.f6133d = resources.getDimensionPixelSize(j.cast_libraries_material_featurehighlight_inner_radius);
        this.f6134e = resources.getInteger(m.cast_libraries_material_featurehighlight_pulse_base_alpha);
        this.f6130a.setAntiAlias(true);
        this.f6130a.setStyle(Paint.Style.FILL);
        this.f6131b.setAntiAlias(true);
        this.f6131b.setStyle(Paint.Style.FILL);
        this.f6130a.setColor(-1);
        this.f6131b.setColor(-1);
        invalidateSelf();
    }

    public final Animator a() {
        ObjectAnimator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{PropertyValuesHolder.ofFloat("scale", new float[]{0.0f}), PropertyValuesHolder.ofInt("alpha", new int[]{0}), PropertyValuesHolder.ofFloat("pulseScale", new float[]{0.0f}), PropertyValuesHolder.ofFloat("pulseAlpha", new float[]{0.0f})});
        ofPropertyValuesHolder.setInterpolator(zzed.zzfs());
        return ofPropertyValuesHolder.setDuration(200);
    }

    public void draw(Canvas canvas) {
        float f2 = this.k;
        if (f2 > 0.0f) {
            float f3 = this.f6135f * this.j;
            this.f6131b.setAlpha((int) (((float) this.f6134e) * f2));
            canvas.drawCircle(this.h, this.i, f3, this.f6131b);
        }
        canvas.drawCircle(this.h, this.i, this.f6135f * this.f6136g, this.f6130a);
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i2) {
        this.f6130a.setAlpha(i2);
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f6130a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Keep
    public void setPulseAlpha(float f2) {
        this.k = f2;
        invalidateSelf();
    }

    @Keep
    public void setPulseScale(float f2) {
        this.j = f2;
        invalidateSelf();
    }

    @Keep
    public void setScale(float f2) {
        this.f6136g = f2;
        invalidateSelf();
    }
}
