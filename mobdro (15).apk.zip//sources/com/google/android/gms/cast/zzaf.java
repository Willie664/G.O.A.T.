package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import b.c.a.b.c.l;
import b.c.a.b.d.n.u.d;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class zzaf extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzaf> CREATOR = new l();

    /* renamed from: a  reason: collision with root package name */
    public final float f6227a;

    /* renamed from: b  reason: collision with root package name */
    public final float f6228b;

    /* renamed from: c  reason: collision with root package name */
    public final float f6229c;

    public zzaf(float f2, float f3, float f4) {
        this.f6227a = f2;
        this.f6228b = f3;
        this.f6229c = f4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzaf)) {
            return false;
        }
        zzaf zzaf = (zzaf) obj;
        return this.f6227a == zzaf.f6227a && this.f6228b == zzaf.f6228b && this.f6229c == zzaf.f6229c;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f6227a), Float.valueOf(this.f6228b), Float.valueOf(this.f6229c)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = d.a(parcel);
        d.a(parcel, 2, this.f6227a);
        d.a(parcel, 3, this.f6228b);
        d.a(parcel, 4, this.f6229c);
        d.b(parcel, a2);
    }
}
