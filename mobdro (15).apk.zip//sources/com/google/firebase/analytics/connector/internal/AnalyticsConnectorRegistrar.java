package com.google.firebase.analytics.connector.internal;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import b.c.b.c;
import b.c.b.e.a.a;
import b.c.b.f.d;
import b.c.b.f.g;
import b.c.b.f.h;
import b.c.b.f.p;
import java.util.Arrays;
import java.util.List;

@Keep
public class AnalyticsConnectorRegistrar implements h {
    @SuppressLint({"MissingPermission"})
    @Keep
    public List<d<?>> getComponents() {
        d.b<a> a2 = d.a(a.class);
        a2.a(p.a(c.class));
        a2.a(p.a(Context.class));
        a2.a(p.a(b.c.b.i.d.class));
        a2.a((g<a>) b.c.b.e.a.c.a.f3212a);
        a2.a(2);
        return Arrays.asList(new d[]{a2.a(), b.c.a.b.d.n.u.d.a("fire-analytics", "17.3.0")});
    }
}
