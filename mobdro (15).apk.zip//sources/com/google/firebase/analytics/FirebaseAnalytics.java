package com.google.firebase.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Keep;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresPermission;
import androidx.annotation.Size;
import b.a.b.w.e;
import b.c.a.b.d.r.c;
import b.c.a.b.h.b.ha;
import b.c.a.b.h.b.p7;
import b.c.a.b.h.b.q5;
import b.c.a.b.h.b.r6;
import b.c.b.e.b;
import com.google.android.gms.internal.measurement.zzv;
import com.google.android.gms.internal.measurement.zzx;
import com.google.firebase.iid.FirebaseInstanceId;

public final class FirebaseAnalytics {

    /* renamed from: d  reason: collision with root package name */
    public static volatile FirebaseAnalytics f6816d;

    /* renamed from: a  reason: collision with root package name */
    public final q5 f6817a;

    /* renamed from: b  reason: collision with root package name */
    public final zzx f6818b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f6819c;

    public FirebaseAnalytics(q5 q5Var) {
        e.b(q5Var);
        this.f6817a = q5Var;
        this.f6818b = null;
        this.f6819c = false;
    }

    public FirebaseAnalytics(zzx zzx) {
        e.b(zzx);
        this.f6817a = null;
        this.f6818b = zzx;
        this.f6819c = true;
    }

    @RequiresPermission(allOf = {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK"})
    @NonNull
    @Keep
    public static FirebaseAnalytics getInstance(@NonNull Context context) {
        if (f6816d == null) {
            synchronized (FirebaseAnalytics.class) {
                if (f6816d == null) {
                    f6816d = zzx.zzb(context) ? new FirebaseAnalytics(zzx.zza(context)) : new FirebaseAnalytics(q5.a(context, (zzv) null));
                }
            }
        }
        return f6816d;
    }

    @Keep
    public static p7 getScionFrontendApiImplementation(Context context, Bundle bundle) {
        zzx zza;
        if (zzx.zzb(context) && (zza = zzx.zza(context, (String) null, (String) null, (String) null, bundle)) != null) {
            return new b(zza);
        }
        return null;
    }

    public final void a(@Size(max = 40, min = 1) @NonNull String str, @Nullable Bundle bundle) {
        if (this.f6819c) {
            this.f6818b.zza(str, bundle);
            return;
        }
        r6 j = this.f6817a.j();
        if (((c) j.f2258a.n) != null) {
            j.a("app", str, bundle, false, true, System.currentTimeMillis());
            return;
        }
        throw null;
    }

    @Keep
    public final String getFirebaseInstanceId() {
        FirebaseInstanceId.f().d();
        return FirebaseInstanceId.h();
    }

    @MainThread
    @Keep
    public final void setCurrentScreen(@NonNull Activity activity, @Size(max = 36, min = 1) @Nullable String str, @Size(max = 36, min = 1) @Nullable String str2) {
        if (this.f6819c) {
            this.f6818b.zza(activity, str, str2);
        } else if (!ha.a()) {
            this.f6817a.zzr().i.a("setCurrentScreen must be called from the main thread");
        } else {
            this.f6817a.n().a(activity, str, str2);
        }
    }
}
