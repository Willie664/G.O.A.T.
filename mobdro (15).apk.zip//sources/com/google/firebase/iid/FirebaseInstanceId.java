package com.google.firebase.iid;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import b.c.a.b.l.h;
import b.c.b.c;
import b.c.b.i.b;
import b.c.b.i.d;
import b.c.b.k.g0;
import b.c.b.k.h0;
import b.c.b.k.k;
import b.c.b.k.l0;
import b.c.b.k.m0;
import b.c.b.k.p;
import b.c.b.k.t;
import b.c.b.k.u;
import b.c.b.k.w;
import b.c.b.k.y;
import b.c.b.n.f;
import com.mobdro.player.FFmpegPlayer;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.concurrent.GuardedBy;

public class FirebaseInstanceId {
    public static final long i = TimeUnit.HOURS.toSeconds(8);
    public static u j;
    @GuardedBy("FirebaseInstanceId.class")
    public static ScheduledExecutorService k;

    /* renamed from: a  reason: collision with root package name */
    public final Executor f6822a;

    /* renamed from: b  reason: collision with root package name */
    public final c f6823b;

    /* renamed from: c  reason: collision with root package name */
    public final k f6824c;

    /* renamed from: d  reason: collision with root package name */
    public final l0 f6825d;

    /* renamed from: e  reason: collision with root package name */
    public final p f6826e;

    /* renamed from: f  reason: collision with root package name */
    public final y f6827f;
    @GuardedBy("this")

    /* renamed from: g  reason: collision with root package name */
    public boolean f6828g = false;
    public final a h;

    public class a {

        /* renamed from: a  reason: collision with root package name */
        public boolean f6829a;

        /* renamed from: b  reason: collision with root package name */
        public final d f6830b;
        @GuardedBy("this")

        /* renamed from: c  reason: collision with root package name */
        public boolean f6831c;
        @GuardedBy("this")
        @Nullable

        /* renamed from: d  reason: collision with root package name */
        public b<b.c.b.a> f6832d;
        @GuardedBy("this")
        @Nullable

        /* renamed from: e  reason: collision with root package name */
        public Boolean f6833e;

        public a(d dVar) {
            this.f6830b = dVar;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
            return r1.f6829a && r1.f6834f.f6823b.c();
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized boolean a() {
            /*
                r1 = this;
                monitor-enter(r1)
                r1.b()     // Catch:{ all -> 0x0023 }
                java.lang.Boolean r0 = r1.f6833e     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0010
                java.lang.Boolean r0 = r1.f6833e     // Catch:{ all -> 0x0023 }
                boolean r0 = r0.booleanValue()     // Catch:{ all -> 0x0023 }
                monitor-exit(r1)
                return r0
            L_0x0010:
                boolean r0 = r1.f6829a     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0021
                com.google.firebase.iid.FirebaseInstanceId r0 = com.google.firebase.iid.FirebaseInstanceId.this     // Catch:{ all -> 0x0023 }
                b.c.b.c r0 = r0.f6823b     // Catch:{ all -> 0x0023 }
                boolean r0 = r0.c()     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0021
                r0 = 1
            L_0x001f:
                monitor-exit(r1)
                return r0
            L_0x0021:
                r0 = 0
                goto L_0x001f
            L_0x0023:
                r0 = move-exception
                monitor-exit(r1)
                goto L_0x0027
            L_0x0026:
                throw r0
            L_0x0027:
                goto L_0x0026
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.FirebaseInstanceId.a.a():boolean");
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(3:10|11|(1:15)) */
        /* JADX WARNING: Code restructure failed: missing block: B:11:?, code lost:
            r1 = r4.f6834f.f6823b;
            r1.a();
            r1 = r1.f3191a;
            r2 = new android.content.Intent("com.google.firebase.MESSAGING_EVENT");
            r2.setPackage(r1.getPackageName());
            r3 = false;
            r1 = r1.getPackageManager().resolveService(r2, 0);
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x000f */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized void b() {
            /*
                r4 = this;
                monitor-enter(r4)
                boolean r0 = r4.f6831c     // Catch:{ all -> 0x0056 }
                if (r0 == 0) goto L_0x0007
                monitor-exit(r4)
                return
            L_0x0007:
                r0 = 1
                java.lang.String r1 = "com.google.firebase.messaging.FirebaseMessaging"
                java.lang.Class.forName(r1)     // Catch:{ ClassNotFoundException -> 0x000f }
            L_0x000d:
                r3 = 1
                goto L_0x0036
            L_0x000f:
                com.google.firebase.iid.FirebaseInstanceId r1 = com.google.firebase.iid.FirebaseInstanceId.this     // Catch:{ all -> 0x0056 }
                b.c.b.c r1 = r1.f6823b     // Catch:{ all -> 0x0056 }
                r1.a()     // Catch:{ all -> 0x0056 }
                android.content.Context r1 = r1.f3191a     // Catch:{ all -> 0x0056 }
                android.content.Intent r2 = new android.content.Intent     // Catch:{ all -> 0x0056 }
                java.lang.String r3 = "com.google.firebase.MESSAGING_EVENT"
                r2.<init>(r3)     // Catch:{ all -> 0x0056 }
                java.lang.String r3 = r1.getPackageName()     // Catch:{ all -> 0x0056 }
                r2.setPackage(r3)     // Catch:{ all -> 0x0056 }
                android.content.pm.PackageManager r1 = r1.getPackageManager()     // Catch:{ all -> 0x0056 }
                r3 = 0
                android.content.pm.ResolveInfo r1 = r1.resolveService(r2, r3)     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0036
                android.content.pm.ServiceInfo r1 = r1.serviceInfo     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0036
                goto L_0x000d
            L_0x0036:
                r4.f6829a = r3     // Catch:{ all -> 0x0056 }
                java.lang.Boolean r1 = r4.c()     // Catch:{ all -> 0x0056 }
                r4.f6833e = r1     // Catch:{ all -> 0x0056 }
                if (r1 != 0) goto L_0x0052
                boolean r1 = r4.f6829a     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0052
                b.c.b.k.k0 r1 = new b.c.b.k.k0     // Catch:{ all -> 0x0056 }
                r1.<init>(r4)     // Catch:{ all -> 0x0056 }
                r4.f6832d = r1     // Catch:{ all -> 0x0056 }
                b.c.b.i.d r2 = r4.f6830b     // Catch:{ all -> 0x0056 }
                java.lang.Class<b.c.b.a> r3 = b.c.b.a.class
                r2.a(r3, r1)     // Catch:{ all -> 0x0056 }
            L_0x0052:
                r4.f6831c = r0     // Catch:{ all -> 0x0056 }
                monitor-exit(r4)
                return
            L_0x0056:
                r0 = move-exception
                monitor-exit(r4)
                goto L_0x005a
            L_0x0059:
                throw r0
            L_0x005a:
                goto L_0x0059
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.FirebaseInstanceId.a.b():void");
        }

        @Nullable
        public final Boolean c() {
            ApplicationInfo applicationInfo;
            c cVar = FirebaseInstanceId.this.f6823b;
            cVar.a();
            Context context = cVar.f3191a;
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("auto_init")) {
                return Boolean.valueOf(sharedPreferences.getBoolean("auto_init", false));
            }
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128)) == null || applicationInfo.metaData == null || !applicationInfo.metaData.containsKey("firebase_messaging_auto_init_enabled")) {
                    return null;
                }
                return Boolean.valueOf(applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled"));
            } catch (PackageManager.NameNotFoundException unused) {
                return null;
            }
        }
    }

    public FirebaseInstanceId(c cVar, k kVar, Executor executor, Executor executor2, d dVar, f fVar, b.c.b.j.c cVar2) {
        if (k.a(cVar) != null) {
            synchronized (FirebaseInstanceId.class) {
                if (j == null) {
                    cVar.a();
                    j = new u(cVar.f3191a);
                }
            }
            this.f6823b = cVar;
            this.f6824c = kVar;
            this.f6825d = new l0(cVar, kVar, executor, fVar, cVar2);
            this.f6822a = executor2;
            this.f6827f = new y(j);
            this.h = new a(dVar);
            this.f6826e = new p(executor);
            executor2.execute(new h0(this));
            return;
        }
        throw new IllegalStateException("FirebaseInstanceId failed to initialize, FirebaseApp is missing project ID");
    }

    public static void a(Runnable runnable, long j2) {
        synchronized (FirebaseInstanceId.class) {
            if (k == null) {
                k = new ScheduledThreadPoolExecutor(1, new b.c.a.b.d.r.i.a("FirebaseInstanceId"));
            }
            k.schedule(runnable, j2, TimeUnit.SECONDS);
        }
    }

    @NonNull
    public static FirebaseInstanceId f() {
        return getInstance(c.d());
    }

    public static boolean g() {
        if (!Log.isLoggable("FirebaseInstanceId", 3)) {
            return Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseInstanceId", 3);
        }
        return true;
    }

    @NonNull
    @Keep
    public static FirebaseInstanceId getInstance(@NonNull c cVar) {
        cVar.a();
        return (FirebaseInstanceId) cVar.f3194d.a(FirebaseInstanceId.class);
    }

    public static String h() {
        return j.b("").f3937a;
    }

    public final <T> T a(h<T> hVar) throws IOException {
        try {
            return b.c.a.b.d.n.u.d.a(hVar, 30000, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e2) {
            Throwable cause = e2.getCause();
            if (cause instanceof IOException) {
                if ("INSTANCE_ID_RESET".equals(cause.getMessage())) {
                    c();
                }
                throw ((IOException) cause);
            } else if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else {
                throw new IOException(e2);
            }
        } catch (InterruptedException | TimeoutException unused) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
    }

    public final synchronized void a(long j2) {
        a(new w(this, this.f6827f, Math.min(Math.max(30, j2 << 1), i)), j2);
        this.f6828g = true;
    }

    public final synchronized void a(boolean z) {
        this.f6828g = z;
    }

    public final boolean a(@Nullable t tVar) {
        if (tVar != null) {
            return (System.currentTimeMillis() > (tVar.f3943c + t.f3940d) ? 1 : (System.currentTimeMillis() == (tVar.f3943c + t.f3940d) ? 0 : -1)) > 0 || !this.f6824c.b().equals(tVar.f3942b);
        }
    }

    public final String b() throws IOException {
        String a2 = k.a(this.f6823b);
        if (Looper.getMainLooper() != Looper.myLooper()) {
            return ((b.c.b.k.a) a(b.c.a.b.d.n.u.d.a(null).b(this.f6822a, new g0(this, a2, "*")))).a();
        }
        throw new IOException("MAIN_THREAD");
    }

    public final synchronized void c() {
        j.b();
        if (this.h.a()) {
            e();
        }
    }

    public final void d() {
        if (a(a()) || this.f6827f.a()) {
            e();
        }
    }

    public final synchronized void e() {
        if (!this.f6828g) {
            a(0);
        }
    }

    @Nullable
    public final t a() {
        return j.a("", k.a(this.f6823b), "*");
    }

    public final void a(String str) throws IOException {
        t a2 = a();
        if (!a(a2)) {
            String h2 = h();
            String str2 = a2.f3941a;
            l0 l0Var = this.f6825d;
            if (l0Var != null) {
                Bundle bundle = new Bundle();
                String valueOf = String.valueOf(str);
                bundle.putString("gcm.topic", valueOf.length() != 0 ? "/topics/".concat(valueOf) : new String("/topics/"));
                String valueOf2 = String.valueOf(str);
                a(l0Var.a(l0Var.a(h2, str2, valueOf2.length() != 0 ? "/topics/".concat(valueOf2) : new String("/topics/"), bundle)).a(b.c.b.k.c.f3870a, new m0()));
                return;
            }
            throw null;
        }
        throw new IOException("token not available");
    }

    public final void b(String str) throws IOException {
        t a2 = a();
        if (!a(a2)) {
            String h2 = h();
            l0 l0Var = this.f6825d;
            String str2 = a2.f3941a;
            if (l0Var != null) {
                Bundle bundle = new Bundle();
                String valueOf = String.valueOf(str);
                bundle.putString("gcm.topic", valueOf.length() != 0 ? "/topics/".concat(valueOf) : new String("/topics/"));
                bundle.putString("delete", FFmpegPlayer.HW_ACCEL_STATE);
                String valueOf2 = String.valueOf(str);
                a(l0Var.a(l0Var.a(h2, str2, valueOf2.length() != 0 ? "/topics/".concat(valueOf2) : new String("/topics/"), bundle)).a(b.c.b.k.c.f3870a, new m0()));
                return;
            }
            throw null;
        }
        throw new IOException("token not available");
    }
}
