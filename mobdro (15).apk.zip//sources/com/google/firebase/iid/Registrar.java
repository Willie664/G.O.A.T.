package com.google.firebase.iid;

import androidx.annotation.Keep;
import b.c.b.c;
import b.c.b.f.d;
import b.c.b.f.g;
import b.c.b.f.h;
import b.c.b.f.p;
import b.c.b.k.m;
import b.c.b.k.n;
import b.c.b.n.f;
import java.util.Arrays;
import java.util.List;

@Keep
public final class Registrar implements h {

    public static class a implements b.c.b.k.b.a {

        /* renamed from: a  reason: collision with root package name */
        public final FirebaseInstanceId f6836a;

        public a(FirebaseInstanceId firebaseInstanceId) {
            this.f6836a = firebaseInstanceId;
        }

        public final String getId() {
            this.f6836a.d();
            return FirebaseInstanceId.h();
        }
    }

    @Keep
    public final List<d<?>> getComponents() {
        Class<FirebaseInstanceId> cls = FirebaseInstanceId.class;
        d.b<FirebaseInstanceId> a2 = d.a(cls);
        a2.a(p.a(c.class));
        a2.a(p.a(b.c.b.i.d.class));
        a2.a(p.a(f.class));
        a2.a(p.a(b.c.b.j.c.class));
        a2.a((g<FirebaseInstanceId>) m.f3914a);
        a2.a(1);
        d<FirebaseInstanceId> a3 = a2.a();
        d.b<b.c.b.k.b.a> a4 = d.a(b.c.b.k.b.a.class);
        a4.a(p.a(cls));
        a4.a((g<b.c.b.k.b.a>) n.f3915a);
        return Arrays.asList(new d[]{a3, a4.a(), b.c.a.b.d.n.u.d.a("fire-iid", "20.0.2")});
    }
}
