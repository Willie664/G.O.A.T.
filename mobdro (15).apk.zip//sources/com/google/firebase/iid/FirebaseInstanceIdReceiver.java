package com.google.firebase.iid;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.legacy.content.WakefulBroadcastReceiver;
import b.c.a.b.d.n.u.d;
import b.c.b.k.a0;
import b.c.b.k.r;
import b.c.b.k.x;
import javax.annotation.concurrent.GuardedBy;

public final class FirebaseInstanceIdReceiver extends WakefulBroadcastReceiver {
    @GuardedBy("FirebaseInstanceIdReceiver.class")

    /* renamed from: a  reason: collision with root package name */
    public static a0 f6835a;

    public static int a(BroadcastReceiver broadcastReceiver, Context context, Intent intent) {
        boolean isLoggable = Log.isLoggable("FirebaseInstanceId", 3);
        if (broadcastReceiver.isOrderedBroadcast()) {
            broadcastReceiver.setResultCode(-1);
        }
        a(context, "com.google.firebase.MESSAGING_EVENT").a(intent, broadcastReceiver.goAsync());
        return -1;
    }

    public static synchronized a0 a(Context context, String str) {
        a0 a0Var;
        synchronized (FirebaseInstanceIdReceiver.class) {
            if (f6835a == null) {
                f6835a = new a0(context, str);
            }
            a0Var = f6835a;
        }
        return a0Var;
    }

    public final void b(Context context, Intent intent) {
        intent.setComponent((ComponentName) null);
        intent.setPackage(context.getPackageName());
        int i = -1;
        if ("google.com/iid".equals(intent.getStringExtra("from"))) {
            String stringExtra = intent.getStringExtra("CMD");
            if (stringExtra != null) {
                if (Log.isLoggable("FirebaseInstanceId", 3)) {
                    String valueOf = String.valueOf(intent.getExtras());
                    stringExtra.length();
                    valueOf.length();
                }
                if ("RST".equals(stringExtra) || "RST_FULL".equals(stringExtra)) {
                    FirebaseInstanceId.f().c();
                } else if ("SYNC".equals(stringExtra)) {
                    FirebaseInstanceId f2 = FirebaseInstanceId.f();
                    if (f2 != null) {
                        FirebaseInstanceId.j.c("");
                        f2.e();
                    } else {
                        throw null;
                    }
                }
            }
        } else {
            String stringExtra2 = intent.getStringExtra("gcm.rawData64");
            boolean z = false;
            if (stringExtra2 != null) {
                intent.putExtra("rawData", Base64.decode(stringExtra2, 0));
                intent.removeExtra("gcm.rawData64");
            }
            boolean z2 = d.h() && context.getApplicationInfo().targetSdkVersion >= 26;
            if ((intent.getFlags() & 268435456) != 0) {
                z = true;
            }
            if (!z2 || z) {
                r a2 = r.a();
                a2.f3936d.offer(intent);
                Intent intent2 = new Intent("com.google.firebase.MESSAGING_EVENT");
                intent2.setPackage(context.getPackageName());
                String a3 = a2.a(context, intent2);
                if (a3 != null) {
                    if (Log.isLoggable("FirebaseInstanceId", 3)) {
                        if (a3.length() != 0) {
                            "Restricting intent to a specific service: ".concat(a3);
                        } else {
                            new String("Restricting intent to a specific service: ");
                        }
                    }
                    intent2.setClassName(context.getPackageName(), a3);
                }
                try {
                    if ((a2.a(context) ? x.a(context, intent2) : context.startService(intent2)) == null) {
                        i = 404;
                    }
                } catch (SecurityException unused) {
                    i = 401;
                } catch (IllegalStateException e2) {
                    String.valueOf(e2).length();
                    i = 402;
                }
                if (d.h() && i == 402) {
                    a(this, context, intent);
                    i = 403;
                }
            } else {
                a(this, context, intent);
            }
        }
        if (isOrderedBroadcast()) {
            setResultCode(i);
        }
    }

    public final void onReceive(@NonNull Context context, @NonNull Intent intent) {
        if (intent != null) {
            Parcelable parcelableExtra = intent.getParcelableExtra("wrapped_intent");
            Intent intent2 = parcelableExtra instanceof Intent ? (Intent) parcelableExtra : null;
            if (intent2 != null) {
                b(context, intent2);
            } else {
                b(context, intent);
            }
        }
    }
}
