package com.google.firebase.iid;

import android.os.Build;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import b.c.b.k.f0;
import b.c.b.k.q0;

public class zzf implements Parcelable {
    public static final Parcelable.Creator<zzf> CREATOR = new f0();

    /* renamed from: a  reason: collision with root package name */
    public Messenger f6837a;

    /* renamed from: b  reason: collision with root package name */
    public q0 f6838b;

    public static final class a extends ClassLoader {
        public final Class<?> loadClass(String str, boolean z) throws ClassNotFoundException {
            if (!"com.google.android.gms.iid.MessengerCompat".equals(str)) {
                return super.loadClass(str, z);
            }
            boolean g2 = FirebaseInstanceId.g();
            return zzf.class;
        }
    }

    public zzf(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.f6837a = new Messenger(iBinder);
        } else {
            this.f6838b = new q0(iBinder);
        }
    }

    public final IBinder a() {
        Messenger messenger = this.f6837a;
        return messenger != null ? messenger.getBinder() : this.f6838b.asBinder();
    }

    public final void a(Message message) throws RemoteException {
        Messenger messenger = this.f6837a;
        if (messenger != null) {
            messenger.send(message);
            return;
        }
        q0 q0Var = this.f6838b;
        if (q0Var != null) {
            Parcel obtain = Parcel.obtain();
            obtain.writeInterfaceToken("com.google.android.gms.iid.IMessengerCompat");
            obtain.writeInt(1);
            message.writeToParcel(obtain, 0);
            try {
                q0Var.f3931a.transact(1, obtain, (Parcel) null, 1);
            } finally {
                obtain.recycle();
            }
        } else {
            throw null;
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        try {
            return a().equals(((zzf) obj).a());
        } catch (ClassCastException unused) {
            return false;
        }
    }

    public int hashCode() {
        return a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        Messenger messenger = this.f6837a;
        parcel.writeStrongBinder(messenger != null ? messenger.getBinder() : this.f6838b.asBinder());
    }
}
