package com.google.firebase.crashlytics;

import b.c.b.c;
import b.c.b.f.d;
import b.c.b.f.g;
import b.c.b.f.h;
import b.c.b.f.p;
import b.c.b.k.b.a;
import java.util.Arrays;
import java.util.List;

public class CrashlyticsRegistrar implements h {
    public List<d<?>> getComponents() {
        d.b<FirebaseCrashlytics> a2 = d.a(FirebaseCrashlytics.class);
        a2.a(p.a(c.class));
        a2.a(new p(a.class, 1, 1));
        a2.a(new p(b.c.b.e.a.a.class, 0, 0));
        a2.a(new p(b.c.b.g.c.a.class, 0, 0));
        a2.a((g<FirebaseCrashlytics>) new b.c.b.g.a(this));
        a2.a(2);
        return Arrays.asList(new d[]{a2.a(), b.c.a.b.d.n.u.d.a("fire-cls", "17.0.0-beta03")});
    }
}
