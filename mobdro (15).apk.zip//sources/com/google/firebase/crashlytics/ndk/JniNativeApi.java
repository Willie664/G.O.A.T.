package com.google.firebase.crashlytics.ndk;

import b.c.b.g.c.b;
import b.c.b.g.d.d;

public class JniNativeApi implements d {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f6821a;

    static {
        boolean z;
        try {
            System.loadLibrary("crashlytics");
            z = true;
        } catch (UnsatisfiedLinkError e2) {
            b bVar = b.f3281c;
            e2.getLocalizedMessage();
            if (bVar != null) {
                z = false;
            } else {
                throw null;
            }
        }
        f6821a = z;
    }

    public final native boolean nativeInit(String str, Object obj);
}
