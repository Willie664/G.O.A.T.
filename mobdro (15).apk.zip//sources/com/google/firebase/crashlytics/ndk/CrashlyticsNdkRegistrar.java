package com.google.firebase.crashlytics.ndk;

import android.content.Context;
import b.c.b.f.d;
import b.c.b.f.g;
import b.c.b.f.h;
import b.c.b.f.p;
import b.c.b.g.c.a;
import b.c.b.g.d.b;
import java.util.Arrays;
import java.util.List;

public class CrashlyticsNdkRegistrar implements h {
    public List<d<?>> getComponents() {
        d.b<a> a2 = d.a(a.class);
        a2.a(p.a(Context.class));
        a2.a((g<a>) new b(this));
        a2.a(2);
        return Arrays.asList(new d[]{a2.a(), b.c.a.b.d.n.u.d.a("fire-cls-ndk", "17.0.0-beta03")});
    }
}
