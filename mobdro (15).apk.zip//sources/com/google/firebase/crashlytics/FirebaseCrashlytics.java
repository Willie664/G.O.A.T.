package com.google.firebase.crashlytics;

import androidx.annotation.NonNull;
import b.c.a.b.d.n.u.d;
import b.c.a.b.l.d0;
import b.c.a.b.l.h;
import b.c.b.c;
import b.c.b.g.c.b;
import b.c.b.g.c.j.e1;
import b.c.b.g.c.j.i0;
import b.c.b.g.c.j.l;
import b.c.b.g.c.j.m;
import b.c.b.g.c.j.n;
import b.c.b.g.c.j.v;
import java.util.Date;

public class FirebaseCrashlytics {

    /* renamed from: a  reason: collision with root package name */
    public final i0 f6820a;

    public FirebaseCrashlytics(@NonNull i0 i0Var) {
        this.f6820a = i0Var;
    }

    @NonNull
    public static FirebaseCrashlytics getInstance() {
        c d2 = c.d();
        d2.a();
        FirebaseCrashlytics firebaseCrashlytics = (FirebaseCrashlytics) d2.f3194d.a(FirebaseCrashlytics.class);
        if (firebaseCrashlytics != null) {
            return firebaseCrashlytics;
        }
        throw new NullPointerException("FirebaseCrashlytics component is not present.");
    }

    @NonNull
    public h<Boolean> checkForUnsentReports() {
        v vVar = this.f6820a.h;
        if (vVar.z.compareAndSet(false, true)) {
            return vVar.w.f2721a;
        }
        if (b.f3281c != null) {
            return d.a(false);
        }
        throw null;
    }

    public void deleteUnsentReports() {
        v vVar = this.f6820a.h;
        vVar.x.a(false);
        d0<TResult> d0Var = vVar.y.f2721a;
    }

    public boolean didCrashOnPreviousExecution() {
        return this.f6820a.f3374g;
    }

    public void log(@NonNull String str) {
        i0 i0Var = this.f6820a;
        if (i0Var != null) {
            long currentTimeMillis = System.currentTimeMillis() - i0Var.f3371d;
            v vVar = i0Var.h;
            vVar.f3455f.a(new l(vVar, currentTimeMillis, str));
            return;
        }
        throw null;
    }

    public void recordException(@NonNull Throwable th) {
        if (th != null) {
            v vVar = this.f6820a.h;
            Thread currentThread = Thread.currentThread();
            if (vVar != null) {
                vVar.f3455f.a((Runnable) new m(vVar, new Date(), th, currentThread));
                return;
            }
            throw null;
        } else if (b.f3281c == null) {
            throw null;
        }
    }

    public void sendUnsentReports() {
        v vVar = this.f6820a.h;
        vVar.x.a(true);
        d0<TResult> d0Var = vVar.y.f2721a;
    }

    public void setCrashlyticsCollectionEnabled(boolean z) {
        this.f6820a.f3370c.a(z);
    }

    public void setCustomKey(@NonNull String str, double d2) {
        this.f6820a.a(str, Double.toString(d2));
    }

    public void setCustomKey(@NonNull String str, float f2) {
        this.f6820a.a(str, Float.toString(f2));
    }

    public void setCustomKey(@NonNull String str, int i) {
        this.f6820a.a(str, Integer.toString(i));
    }

    public void setCustomKey(@NonNull String str, long j) {
        this.f6820a.a(str, Long.toString(j));
    }

    public void setCustomKey(@NonNull String str, @NonNull String str2) {
        this.f6820a.a(str, str2);
    }

    public void setCustomKey(@NonNull String str, boolean z) {
        this.f6820a.a(str, Boolean.toString(z));
    }

    public void setUserId(@NonNull String str) {
        v vVar = this.f6820a.h;
        e1 e1Var = vVar.f3454e;
        if (e1Var != null) {
            e1Var.f3333a = e1.a(str);
            vVar.f3455f.a(new n(vVar, vVar.f3454e));
            return;
        }
        throw null;
    }
}
