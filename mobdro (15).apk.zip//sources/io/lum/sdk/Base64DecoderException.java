package io.lum.sdk;

public class Base64DecoderException extends Exception {
    public static final long serialVersionUID = 1;

    public Base64DecoderException() {
    }

    public Base64DecoderException(String str) {
        super(str);
    }
}
