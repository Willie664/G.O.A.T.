package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import b.a.a.a.a;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class set {
    public static volatile HashMap<String, file> m_files = new HashMap<>();
    public final Context m_app_context;
    public boolean m_is_persistent = false;
    public boolean m_listener_active;
    public final List<listener> m_listeners = new LinkedList();
    public final String m_name;
    public final PropertyChangeListener m_pcl = new property_change_listener() {
        public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
            set.this.notify_change(propertyChangeEvent.getPropertyName());
        }
    };
    public SharedPreferences m_storage = null;
    public boolean m_use_file_persistent = false;

    public class file<K, V> {
        public PropertyChangeSupport m_listener_support = new PropertyChangeSupport(this);
        public HashMap<K, V> m_props = new HashMap<>();

        public file() {
        }

        public void clear() {
            this.m_props.clear();
        }

        public boolean containsKey(K k) {
            return this.m_props.containsKey(k);
        }

        public V get(K k) {
            return this.m_props.get(k);
        }

        public V put(K k, V v) {
            V v2 = this.m_props.containsKey(k) ? this.m_props.get(k) : null;
            V put = this.m_props.put(k, v);
            this.m_listener_support.firePropertyChange(k.toString(), v2, v);
            return put;
        }

        public void put_all(Map map) {
            this.m_props.putAll(map);
        }

        public void register_listener(PropertyChangeListener propertyChangeListener) {
            this.m_listener_support.addPropertyChangeListener(propertyChangeListener);
        }

        public V remove(K k) {
            Object obj = this.m_props.containsKey(k) ? this.m_props.get(k) : null;
            V remove = this.m_props.remove(k);
            this.m_listener_support.firePropertyChange(k.toString(), obj, (Object) null);
            return remove;
        }

        public void unregister_listener(PropertyChangeListener propertyChangeListener) {
            this.m_listener_support.removePropertyChangeListener(propertyChangeListener);
        }
    }

    public class file_persistent extends file {
        public final String m_filename;

        public file_persistent() {
            super();
            String str = util.get_confdir(set.this.m_app_context) + "/" + set.this.m_name + ".db";
            this.m_filename = str;
            if (util.file_exists(str)) {
                load();
            } else if (!util.is_first_run()) {
                import_from_shared(set.this.get_shared());
            }
        }

        private void import_from_shared(SharedPreferences sharedPreferences) {
            this.m_props.putAll(sharedPreferences.getAll());
        }

        private void load() {
            synchronized (this.m_filename) {
                this.m_props.putAll((Map) util.file_load_object(this.m_filename));
            }
        }

        private void save() {
            synchronized (this.m_filename) {
                util.file_save_object(this.m_filename, this.m_props);
            }
        }

        public void clear() {
            super.clear();
            save();
        }

        public Object put(Object obj, Object obj2) {
            Object put = super.put(obj, obj2);
            save();
            return put;
        }
    }

    public interface listener {
        void on_changed(String str);
    }

    public class property_change_listener implements PropertyChangeListener {
        public property_change_listener() {
        }

        public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
        }
    }

    public set(Context context, String str) {
        this.m_app_context = context.getApplicationContext();
        this.m_name = str;
        if (str.equals("conf")) {
            this.m_is_persistent = true;
        }
        if (this.m_is_persistent && !this.m_use_file_persistent) {
            load_shared();
        }
        get_file(true);
    }

    private boolean check_not_null(String str, Object obj) {
        if (obj != null) {
            return true;
        }
        util.perr("set_null", str);
        return false;
    }

    private file get_file() {
        return get_file(false);
    }

    private file get_file(boolean z) {
        file file2 = m_files.get(this.m_name);
        if (file2 != null) {
            return file2;
        }
        if (z) {
            file file3 = new file();
            if (this.m_is_persistent) {
                if (this.m_use_file_persistent) {
                    file3 = new file_persistent();
                } else {
                    file3.put_all(this.m_storage.getAll());
                }
            }
            file file4 = file3;
            m_files.put(this.m_name, file4);
            return file4;
        }
        util.perr("get_file_null", this.m_name);
        return get_file(true);
    }

    /* access modifiers changed from: private */
    public SharedPreferences get_shared() {
        String str = this.m_name;
        if ("org.hola".equals(this.m_app_context.getPackageName())) {
            str = a.a("lumsdk_api_", str);
        }
        return this.m_app_context.getSharedPreferences(str, 0);
    }

    private void load_shared() {
        this.m_storage = get_shared();
    }

    @SuppressLint({"ApplySharedPref"})
    public final void clear() {
        zerr(5, "clear");
        if (util.is_bcast_client()) {
            util.bcast_client_clear(this.m_name);
        }
        if (util.is_bcast_server() && this.m_is_persistent && !this.m_use_file_persistent) {
            this.m_storage.edit().clear().commit();
        }
        get_file().clear();
    }

    public final void del(String str) {
        if (util.is_bcast_client()) {
            util.bcast_client_del(this.m_name, str);
        }
        if (exist(str)) {
            zerr(5, "del " + str);
            if (util.is_bcast_server() && this.m_is_persistent && !this.m_use_file_persistent) {
                this.m_storage.edit().remove(str).apply();
            }
            get_file().remove(str);
        }
    }

    public final void detach() {
        if (this.m_listener_active) {
            get_file().unregister_listener(this.m_pcl);
            this.m_listener_active = false;
        }
    }

    public final void dump() {
        zerr(7, "dump:");
        for (Map.Entry next : get_entries().entrySet()) {
            StringBuilder a2 = a.a(" - '");
            a2.append((String) next.getKey());
            a2.append("'='");
            a2.append(next.getValue().toString());
            a2.append("'");
            zerr(7, a2.toString());
        }
    }

    public final boolean exist(String str) {
        return get_file().containsKey(str);
    }

    public final boolean get_bool(String str) {
        return get_bool(str, false);
    }

    public final boolean get_bool(String str, boolean z) {
        if (!exist(str)) {
            return z;
        }
        try {
            return ((Boolean) get_file().get(str)).booleanValue();
        } catch (NullPointerException unused) {
            util.perr("get_bool_file_null", this.m_name + "/" + str);
            return z;
        }
    }

    public Map<String, ?> get_entries() {
        return this.m_storage.getAll();
    }

    public final float get_float(String str) {
        return get_float(str, 0.0f);
    }

    public final float get_float(String str, float f2) {
        return !exist(str) ? f2 : ((Float) get_file().get(str)).floatValue();
    }

    public final int get_int(String str) {
        if (!exist(str)) {
            return 0;
        }
        file file2 = get_file();
        if (file2 != null) {
            return ((Integer) file2.get(str)).intValue();
        }
        util.perr("get_int_file_null", this.m_name + "/" + str);
        return 0;
    }

    public final long get_long(String str) {
        return get_long(str, 0);
    }

    public final long get_long(String str, long j) {
        if (!exist(str)) {
            return j;
        }
        try {
            return ((Long) get_file().get(str)).longValue();
        } catch (NullPointerException unused) {
            util.perr("get_long_file_null", this.m_name + "/" + str);
            return j;
        }
    }

    public final String get_str(String str) {
        return get_str(str, "");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0007, code lost:
        r2 = (java.lang.String) get_file().get(r2);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String get_str(java.lang.String r2, java.lang.String r3) {
        /*
            r1 = this;
            boolean r0 = r1.exist(r2)
            if (r0 != 0) goto L_0x0007
            return r3
        L_0x0007:
            io.lum.sdk.set$file r0 = r1.get_file()
            java.lang.Object r2 = r0.get(r2)
            java.lang.String r2 = (java.lang.String) r2
            if (r2 != 0) goto L_0x0014
            return r3
        L_0x0014:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.set.get_str(java.lang.String, java.lang.String):java.lang.String");
    }

    public void notify_change(String str) {
        synchronized (this.m_listeners) {
            for (listener on_changed : this.m_listeners) {
                on_changed.on_changed(str);
            }
        }
    }

    public final void register_listener(listener listener2) {
        if (!this.m_listener_active) {
            get_file().register_listener(this.m_pcl);
            this.m_listener_active = true;
        }
        synchronized (this.m_listeners) {
            this.m_listeners.add(listener2);
        }
    }

    public final void set(String str, Boolean bool) {
        if (check_not_null(str, bool)) {
            if (get_bool(str) != bool.booleanValue()) {
                zerr(7, "set " + str + "=" + bool);
            }
            String simpleName = bool.getClass().getSimpleName();
            String valueOf = String.valueOf(bool);
            if (util.is_bcast_client()) {
                util.bcast_client_set(this.m_name, str, valueOf, simpleName);
            }
            get_file().put(str, bool);
            if (util.is_bcast_server()) {
                if (this.m_is_persistent && !this.m_use_file_persistent) {
                    this.m_storage.edit().putBoolean(str, bool.booleanValue()).apply();
                }
                util.bcast_handler_notify(this.m_name, str, valueOf, simpleName);
            }
        }
    }

    public final void set(String str, Float f2) {
        if (check_not_null(str, f2)) {
            if (get_float(str) != f2.floatValue()) {
                zerr(7, "set " + str + "=" + f2);
            }
            String simpleName = f2.getClass().getSimpleName();
            String valueOf = String.valueOf(f2);
            if (util.is_bcast_client()) {
                util.bcast_client_set(this.m_name, str, valueOf, simpleName);
            }
            get_file().put(str, f2);
            if (util.is_bcast_server()) {
                if (this.m_is_persistent && !this.m_use_file_persistent) {
                    this.m_storage.edit().putFloat(str, f2.floatValue()).apply();
                }
                util.bcast_handler_notify(this.m_name, str, valueOf, simpleName);
            }
        }
    }

    public final void set(String str, Integer num) {
        if (check_not_null(str, num)) {
            if (get_int(str) != num.intValue()) {
                zerr(7, "set " + str + "=" + num);
            }
            String simpleName = num.getClass().getSimpleName();
            String valueOf = String.valueOf(num);
            if (util.is_bcast_client()) {
                util.bcast_client_set(this.m_name, str, valueOf, simpleName);
            }
            get_file().put(str, num);
            if (util.is_bcast_server()) {
                if (this.m_is_persistent && !this.m_use_file_persistent) {
                    this.m_storage.edit().putInt(str, num.intValue()).apply();
                }
                util.bcast_handler_notify(this.m_name, str, valueOf, simpleName);
            }
        }
    }

    public final void set(String str, Long l) {
        if (check_not_null(str, l)) {
            if (get_long(str) != l.longValue()) {
                zerr(7, "set " + str + "=" + l);
            }
            String simpleName = l.getClass().getSimpleName();
            String valueOf = String.valueOf(l);
            if (util.is_bcast_client()) {
                util.bcast_client_set(this.m_name, str, valueOf, simpleName);
            }
            get_file().put(str, l);
            if (util.is_bcast_server()) {
                if (this.m_is_persistent && !this.m_use_file_persistent) {
                    this.m_storage.edit().putLong(str, l.longValue()).apply();
                }
                util.bcast_handler_notify(this.m_name, str, valueOf, simpleName);
            }
        }
    }

    public final void set(String str, String str2) {
        if (check_not_null(str, str2)) {
            if (!get_str(str).equals(str2)) {
                zerr(7, "set " + str + "=" + str2);
            }
            String simpleName = str2.getClass().getSimpleName();
            if (util.is_bcast_client()) {
                util.bcast_client_set(this.m_name, str, str2, simpleName);
            }
            get_file().put(str, str2);
            if (util.is_bcast_server()) {
                if (this.m_is_persistent && !this.m_use_file_persistent) {
                    this.m_storage.edit().putString(str, str2).apply();
                }
                util.bcast_handler_notify(this.m_name, str, str2, simpleName);
            }
        }
    }

    public final void unregister_listener(listener listener2) {
        synchronized (this.m_listeners) {
            this.m_listeners.remove(listener2);
        }
    }

    public final void zerr(int i, String str) {
        if (!util.is_bcast_client()) {
            String str2 = this.m_is_persistent ? this.m_use_file_persistent ? "file" : "shared" : "memory";
            StringBuilder a2 = a.a("lumsdk/");
            a2.append(this.m_name);
            String sb = a2.toString();
            util._zerr(sb, i, str2 + " " + str);
        }
    }
}
