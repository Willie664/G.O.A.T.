package io.lum.sdk;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Debug;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import b.a.a.a.a;
import d.a.a.b;
import d.a.a.c;
import io.lum.sdk.bcast;
import java.io.IOException;
import java.lang.Thread;
import org.json.JSONException;
import org.json.JSONObject;

public class api {
    public static final int CHOICE_ADS = 2;
    public static final int CHOICE_DISABLED = 5;
    public static final int CHOICE_FREE = 1;
    public static final int CHOICE_NONE = 0;
    public static final int CHOICE_NOT_PEER = 4;
    public static final int CHOICE_PEER = 1;
    public static final int CHOICE_SUBSCRIPTION = 3;
    public static final int DIALOG_CHOOSE = 1;
    public static final int DIALOG_PEER = 2;
    public static final String INTEGRATION_GUIDE_URL = "https://tinyurl.com/yav4vgu7";
    public static final int JOB_SCHED_ID = 1000;
    public static final Boolean init_lock = true;
    public static Boolean inited = false;
    public static int m_app_name_color = Color.parseColor("#0288d1");
    public static int m_bg_color = Color.parseColor("#ffffff");
    public static int m_bottom_color = Color.parseColor("#003d5b");
    public static int m_btn_color = 0;
    public static BTN_NOT_PEER_TXT m_btn_not_peer_txt = BTN_NOT_PEER_TXT.ADS;
    public static int m_btn_txt_not_peer_color = Color.parseColor("#9f9f9f");
    public static int m_btn_txt_peer_color = Color.parseColor("#ffffff");
    public static int m_choice;
    public static conf m_conf;
    public static DIALOG_TYPE m_dialog_type = DIALOG_TYPE.PEER1;
    public static Long m_display_ms = 0L;
    public static boolean m_dlg_cancellable = false;
    public static Typeface m_font;
    public static int m_max_job_id = 1000;
    public static int m_min_job_id = 1;
    public static boolean m_no_vendor = false;
    public static on_selection_listener m_on_selection_listener;
    public static String m_partner_id = "";
    public static Thread.UncaughtExceptionHandler m_prev_exception_handler;
    public static on_ready_listener m_ready_listener;
    public static String m_tos_link = "link to tos";
    public static String m_tracking_id = null;
    public static int m_txt_color = Color.parseColor("#666666");

    public enum BTN_NOT_PEER_TXT {
        ADS,
        LIMITED,
        PREMIUM,
        NO_DONATE,
        NOT_AGREE,
        I_DISAGREE,
        SUBSCRIPTION,
        PAY
    }

    public enum BTN_PEER_TXT {
        NO_ADS,
        PREMIUM,
        FREE,
        DONATE,
        I_AGREE
    }

    public enum DIALOG_TYPE {
        PEER1
    }

    public static abstract class conf_listener {
        public abstract void on_change(String str, String str2);
    }

    public interface on_ready_listener {
        void on_supported();

        void on_unsupported(String str);
    }

    public interface on_selection_listener {
        void on_user_selection(int i);
    }

    public static class state {
        public String[] files;
        public String info;
        public String source = "collect";
        public int status;

        public state(int i, String str) {
            this.status = i;
            this.info = str;
        }

        public boolean is_active() {
            return this.status >= 20;
        }

        public boolean is_effective() {
            return this.status >= 19;
        }

        public boolean is_used() {
            return this.status >= 22;
        }

        public String toString() {
            return String.format("status=%s, filenames=%s, info=\n%s\n, source=%s", new Object[]{Integer.valueOf(this.status), TextUtils.join(",", this.files), this.info, this.source});
        }
    }

    public static void _init(Context context) {
        Long valueOf;
        if (!inited.booleanValue()) {
            synchronized (init_lock) {
                if (!inited.booleanValue()) {
                    try {
                        util.util_init(context, "app", m_tracking_id);
                        is_supported(context);
                        util.start_svc_host(context, "init");
                        conf conf = new conf(context);
                        m_conf = conf;
                        int load_choice = util.load_choice(conf);
                        m_choice = load_choice;
                        if (load_choice == 0 && is_restricted_country(context)) {
                            m_choice = 4;
                            util.save_choice(context, 4);
                        }
                        m_conf.set(conf.PARTNERID, m_partner_id);
                        m_conf.set(conf.MIN_JOB_ID, m_min_job_id);
                        m_conf.set(conf.MAX_JOB_ID, m_max_job_id);
                        util.perr_funnel(conf.FUNNEL_01_API_INIT);
                        util.perr("init");
                        util.perr_funnel_main_send("00_api_init");
                        if (util.sdk_disabled(false)) {
                            call_selection_listener(5);
                            inited = true;
                            m_display_ms = Long.valueOf(System.currentTimeMillis());
                            return;
                        }
                        m_prev_exception_handler = Thread.getDefaultUncaughtExceptionHandler();
                        Thread.setDefaultUncaughtExceptionHandler(new c(context));
                        inited = true;
                        valueOf = Long.valueOf(System.currentTimeMillis());
                        m_display_ms = valueOf;
                    } catch (Exception e2) {
                        util.e2s(e2);
                        util.perr(3, "init_exception", e2.getMessage(), util.e2s(e2), true);
                        inited = true;
                        valueOf = Long.valueOf(System.currentTimeMillis());
                    } catch (Throwable th) {
                        inited = true;
                        m_display_ms = Long.valueOf(System.currentTimeMillis());
                        throw th;
                    }
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0014, code lost:
        if (r2 == 4) goto L_0x000b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(android.app.Activity r1, int r2) {
        /*
            r0 = 0
            m_choice = r0
            r0 = 1
            if (r2 != r0) goto L_0x000e
            java.lang.String r2 = "09_api_popup_dismiss_free"
            io.lum.sdk.util.perr_funnel_main_send(r2)
        L_0x000b:
            m_choice = r0
            goto L_0x0017
        L_0x000e:
            java.lang.String r0 = "08_api_popup_dismiss_not_free"
            io.lum.sdk.util.perr_funnel_main_send(r0)
            r0 = 4
            if (r2 != r0) goto L_0x0017
            goto L_0x000b
        L_0x0017:
            int r2 = m_choice
            io.lum.sdk.util.save_choice(r1, r2)
            int r1 = m_choice
            call_selection_listener(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.api.a(android.app.Activity, int):void");
    }

    public static /* synthetic */ void a(Context context, Thread thread, Throwable th) {
        StringBuilder sb = new StringBuilder();
        for (Throwable th2 = th; th2 != null; th2 = th2.getCause()) {
            sb.append("cause:\n");
            sb.append(Log.getStackTraceString(th2));
        }
        String sb2 = sb.toString();
        boolean z = !sb2.contains(BuildConfig.APPLICATION_ID) || sb2.contains("at io.lum.sdk.api.call_selection_listener");
        String str = z ? "host_app_crash" : "crash";
        boolean contains = sb2.contains("OutOfMemoryError");
        if (!z || (!contains && !sb2.contains("Thread starting during runtime shutdown"))) {
            StringBuilder a2 = a.a("pid ");
            a2.append(Process.myPid());
            a2.append(" apkid ");
            a2.append(context.getPackageName());
            String sb3 = a2.toString();
            util.perr_p(3, str, sb3, "" + sb);
            if (contains) {
                try {
                    util.perr_p(3, "oom_dump", "", sb2);
                    Debug.dumpHprofData(util.get_cachedir(context) + "/log/sdk.dmp");
                } catch (IOException unused) {
                }
            }
        } else {
            util.perr_p(3, "crash_ignore", "", sb2);
        }
        if (z) {
            m_prev_exception_handler.uncaughtException(thread, th);
        }
    }

    public static /* synthetic */ void a(Runnable runnable, Runnable runnable2, Runnable runnable3, int i) {
        if (i == 1) {
            runnable.run();
        } else if (i != 3) {
            runnable3.run();
        } else {
            runnable2.run();
        }
    }

    public static int calc_choice(int i) {
        if (i != 1 || !util.is_blacklisted()) {
            return i;
        }
        return 4;
    }

    public static void call_selection_listener(int i) {
        on_selection_listener on_selection_listener2 = m_on_selection_listener;
        if (on_selection_listener2 != null) {
            on_selection_listener2.on_user_selection(calc_choice(i));
        }
    }

    public static void check_before_init(String str) {
        synchronized (init_lock) {
            if (inited.booleanValue()) {
                String.format("api.%s() should be called before api.init()", new Object[]{str});
            }
        }
    }

    public static void check_init(String str) {
        synchronized (init_lock) {
            if (!inited.booleanValue()) {
                throw_integration_error(String.format("api.init() should be called before api.%s()", new Object[]{str}));
            }
        }
    }

    public static void clear_selection(Context context) {
        deprecated("clear_selection", "opt_out");
        check_init("clear_selection");
        util.perr("opt_out", "");
        util.perr_funnel_main_send("100_api_opt_out");
        m_choice = 0;
        util.save_choice(context, 0);
        call_selection_listener(m_choice);
    }

    public static void deprecated(String str) {
        util.perr(3, str, true);
        String.format("api.%s is deprecated and will be ignored. Refer to Luminati Android SDK Integration Guide at: %s", new Object[]{str, INTEGRATION_GUIDE_URL});
    }

    public static void deprecated(String str, String str2) {
        util.perr(3, str, true);
        String.format("api.%s is deprecated and will be removed soon. Use api.%s. Refer to Luminati Android SDK Integration Guide at: %s", new Object[]{str, str2, INTEGRATION_GUIDE_URL});
    }

    public static state get_state(Context context) {
        if (!util.is_sdk_state_restricted()) {
            return util.get_sdk_state(context, true);
        }
        util.perr(3, "get_state_restricted", true);
        return null;
    }

    public static int get_user_selection(Context context) {
        check_init("get_user_selection");
        return calc_choice(m_choice);
    }

    public static void init(Activity activity, boolean z) {
        _init(activity);
        popup(activity, z);
    }

    public static void init(Context context) {
        _init(context);
    }

    public static boolean is_restricted_country(Context context) {
        return util.is_restricted(context.getPackageName());
    }

    public static void is_supported(Context context) {
        if (m_ready_listener != null) {
            if (is_restricted_country(context)) {
                m_ready_listener.on_unsupported("restricted_country");
            } else {
                evaluation.set_listener(m_ready_listener);
            }
        }
    }

    public static void opt_out(Context context) {
        init(context);
        util.save_choice(context, 4);
        util.perr("opt_out");
        util.perr_funnel_main_send("100_api_opt_out");
    }

    public static void popup(Activity activity, boolean z) {
        check_init("popup");
        try {
            if (m_choice != 0) {
                if (!z || is_restricted_country(activity)) {
                    call_selection_listener(m_choice);
                    return;
                }
            }
            show_popup(activity);
        } catch (Exception e2) {
            util.perr(3, "popup_exception", "" + e2, util.e2s(e2), true);
        }
    }

    public static void register_callbacks(Runnable runnable, Runnable runnable2, Runnable runnable3) {
        set_selection_listener(new d.a.a.a(runnable, runnable3, runnable2));
    }

    public static void report_popup_display() {
        synchronized (m_display_ms) {
            m_display_ms = Long.valueOf(System.currentTimeMillis());
        }
        util.perr_funnel(conf.FUNNEL_03_POPUP_DISPLAY);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0102, code lost:
        r7.set(r8, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x010a, code lost:
        r7.set(r8, true);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0137, code lost:
        io.lum.sdk.util.share_text(r7, r2, r0, r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x013a, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object run_debug(android.app.Activity r7, java.lang.String... r8) {
        /*
            java.lang.String r0 = r7.getPackageName()
            boolean r0 = io.lum.sdk.util.is_test_app(r0)
            r1 = 0
            if (r0 != 0) goto L_0x000c
            return r1
        L_0x000c:
            r0 = 0
            r2 = r8[r0]
            r3 = -1
            int r4 = r2.hashCode()
            r5 = 2
            r6 = 1
            switch(r4) {
                case -2036410735: goto L_0x00b2;
                case -1613817264: goto L_0x00a8;
                case -846429736: goto L_0x009d;
                case -846383534: goto L_0x0092;
                case -765591341: goto L_0x0088;
                case -733291940: goto L_0x007d;
                case -132880679: goto L_0x0073;
                case -132871841: goto L_0x0069;
                case 428121327: goto L_0x005e;
                case 1146707560: goto L_0x0054;
                case 1162886151: goto L_0x0049;
                case 1165791212: goto L_0x003e;
                case 1222229499: goto L_0x0033;
                case 1295776509: goto L_0x0027;
                case 1511272222: goto L_0x001b;
                default: goto L_0x0019;
            }
        L_0x0019:
            goto L_0x00bc
        L_0x001b:
            java.lang.String r4 = "emulate_mobile_off"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 8
            goto L_0x00bc
        L_0x0027:
            java.lang.String r4 = "emulate_roaming_off"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 10
            goto L_0x00bc
        L_0x0033:
            java.lang.String r4 = "switch_proxy_on"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 5
            goto L_0x00bc
        L_0x003e:
            java.lang.String r4 = "share_sdk_state"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 1
            goto L_0x00bc
        L_0x0049:
            java.lang.String r4 = "share_sdk_popup"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 4
            goto L_0x00bc
        L_0x0054:
            java.lang.String r4 = "get_state"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 2
            goto L_0x00bc
        L_0x005e:
            java.lang.String r4 = "get_version"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 14
            goto L_0x00bc
        L_0x0069:
            java.lang.String r4 = "share_sdk_log"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 3
            goto L_0x00bc
        L_0x0073:
            java.lang.String r4 = "share_sdk_cid"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 0
            goto L_0x00bc
        L_0x007d:
            java.lang.String r4 = "clear_data"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 11
            goto L_0x00bc
        L_0x0088:
            java.lang.String r4 = "switch_proxy_off"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 6
            goto L_0x00bc
        L_0x0092:
            java.lang.String r4 = "restart_java"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 12
            goto L_0x00bc
        L_0x009d:
            java.lang.String r4 = "restart_host"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 13
            goto L_0x00bc
        L_0x00a8:
            java.lang.String r4 = "emulate_mobile_on"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 7
            goto L_0x00bc
        L_0x00b2:
            java.lang.String r4 = "emulate_roaming_on"
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x00bc
            r3 = 9
        L_0x00bc:
            java.lang.String r2 = "debug"
            switch(r3) {
                case 0: goto L_0x0131;
                case 1: goto L_0x011b;
                case 2: goto L_0x0116;
                case 3: goto L_0x0112;
                case 4: goto L_0x010e;
                case 5: goto L_0x0106;
                case 6: goto L_0x00fe;
                case 7: goto L_0x00f9;
                case 8: goto L_0x00f4;
                case 9: goto L_0x00ef;
                case 10: goto L_0x00ea;
                case 11: goto L_0x00e1;
                case 12: goto L_0x00dd;
                case 13: goto L_0x00d9;
                case 14: goto L_0x00c3;
                default: goto L_0x00c1;
            }
        L_0x00c1:
            goto L_0x013a
        L_0x00c3:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.INSTALL_VERSION
            java.lang.String r7 = r7.get_str(r8)
            boolean r8 = r7.isEmpty()
            if (r8 != 0) goto L_0x013a
            io.lum.sdk.conf r8 = m_conf
            io.lum.sdk.conf$key r0 = io.lum.sdk.conf.INSTALL_VERSION
            r8.set(r0, (java.lang.String) r7)
            goto L_0x013a
        L_0x00d9:
            io.lum.sdk.util.restart_svc_host(r7, r2)
            goto L_0x013a
        L_0x00dd:
            io.lum.sdk.util.restart_svc_thread(r2)
            goto L_0x013a
        L_0x00e1:
            set_user_selection(r7, r0)
            io.lum.sdk.conf r7 = m_conf
            r7.clear()
            goto L_0x013a
        L_0x00ea:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_ROAMING
            goto L_0x0102
        L_0x00ef:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_ROAMING
            goto L_0x010a
        L_0x00f4:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_MOBILE
            goto L_0x0102
        L_0x00f9:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_MOBILE
            goto L_0x010a
        L_0x00fe:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_FORCE_PROXY
        L_0x0102:
            r7.set(r8, (boolean) r0)
            goto L_0x013a
        L_0x0106:
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r8 = io.lum.sdk.conf.DBG_FORCE_PROXY
        L_0x010a:
            r7.set(r8, (boolean) r6)
            goto L_0x013a
        L_0x010e:
            io.lum.sdk.util.share_screenshot(r7)
            goto L_0x013a
        L_0x0112:
            io.lum.sdk.util.share_log(r7)
            goto L_0x013a
        L_0x0116:
            io.lum.sdk.api$state r7 = get_state(r7)
            return r7
        L_0x011b:
            java.lang.String r0 = ""
            java.lang.StringBuilder r0 = b.a.a.a.a.a(r0)
            io.lum.sdk.api$state r2 = get_state(r7)
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            r8 = r8[r6]
            java.lang.String r2 = "sdk state"
            goto L_0x0137
        L_0x0131:
            r0 = r8[r6]
            r8 = r8[r5]
            java.lang.String r2 = "cid"
        L_0x0137:
            io.lum.sdk.util.share_text(r7, r2, r0, r8)
        L_0x013a:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.api.run_debug(android.app.Activity, java.lang.String[]):java.lang.Object");
    }

    public static void set_app_name_color(String str) {
        if (str != null) {
            m_app_name_color = Color.parseColor(str);
        }
    }

    public static void set_bg_color(String str) {
        if (str != null) {
            m_bg_color = Color.parseColor(str);
        }
    }

    public static void set_bottom_background(int i) {
    }

    public static void set_btn_color(String str) {
        if (str != null) {
            m_btn_color = Color.parseColor(str);
        }
    }

    @Deprecated
    public static void set_btn_drawable(int i, int i2) {
    }

    public static void set_btn_not_peer_txt(BTN_NOT_PEER_TXT btn_not_peer_txt) {
        check_before_init("set_btn_not_peer_txt");
        m_btn_not_peer_txt = btn_not_peer_txt;
    }

    public static void set_btn_peer_txt(BTN_PEER_TXT btn_peer_txt) {
        deprecated("set_btn_peer_txt");
    }

    public static void set_btn_txt_color(String str, String str2) {
        if (str != null) {
            m_btn_txt_peer_color = Color.parseColor(str);
        }
        if (str2 != null) {
            m_btn_txt_not_peer_color = Color.parseColor(str2);
        }
    }

    public static void set_cancellable(boolean z) {
        m_dlg_cancellable = z;
    }

    public static void set_conf_listener(Context context, final conf_listener conf_listener2) {
        String packageName = context.getPackageName();
        if (util.is_test_app(packageName) || !util.is_restricted(packageName)) {
            util.m_bcast_client.add_listener(new bcast.client.listener() {
                public void on_notify(Bundle bundle) {
                    try {
                        if (bundle.getString("name").equals("conf")) {
                            conf_listener2.on_change(bundle.getString("key"), bundle.getString("value"));
                        }
                    } catch (Exception e2) {
                        util.perr(3, "conf_listener_exception", String.valueOf(bundle), util.e2s(e2), true);
                    }
                }
            });
        }
    }

    @Deprecated
    public static void set_dialog_type(DIALOG_TYPE dialog_type) {
        m_dialog_type = dialog_type;
    }

    public static void set_font(Typeface typeface) {
        m_font = typeface;
    }

    @Deprecated
    public static void set_hola_sla_link(boolean z) {
    }

    public static void set_is_debug() {
        util.set_force_is_debug();
    }

    public static void set_jobid_range(int i, int i2) {
        check_before_init("set_jobid_range");
        if (i == 0) {
            throw new IllegalArgumentException("min should be greater than 0");
        } else if ((i2 - i) + 1 >= 100) {
            m_min_job_id = i;
            m_max_job_id = i2;
        } else {
            throw new IllegalArgumentException(String.format("range should include at least %d IDs", new Object[]{100}));
        }
    }

    public static void set_no_vendor(Context context) {
        if (!zon_conf.get_sdk_app_conf(context.getPackageName()).optBoolean("set_no_vendor")) {
            util.perr(3, "set_no_vendor_restricted", true);
            return;
        }
        check_before_init("set_no_vendor");
        m_no_vendor = true;
    }

    public static void set_partner_id(String str) {
        m_partner_id = str;
    }

    public static void set_ready_listener(Context context, on_ready_listener on_ready_listener2) {
        check_before_init("set_ready_listener");
        m_ready_listener = on_ready_listener2;
    }

    public static void set_selection_listener(on_selection_listener on_selection_listener2) {
        check_before_init("on_selection_listener");
        m_on_selection_listener = on_selection_listener2;
    }

    public static void set_sla_link(boolean z) {
    }

    public static void set_top_background(int i) {
    }

    public static void set_tos_link(String str) {
        check_before_init("set_tos_link");
        m_tos_link = str;
    }

    public static void set_tracking_id(String str) {
        check_before_init("set_tracking_id");
        m_tracking_id = str;
    }

    public static void set_txt_color(String str) {
        if (str != null) {
            m_txt_color = Color.parseColor(str);
        }
    }

    public static void set_user_selection(Context context, int i) {
        String str;
        if (!zon_conf.get_sdk_app_conf(context.getPackageName()).optBoolean("set_user_selection")) {
            util.perr(3, "set_user_selection_restricted", true);
            return;
        }
        check_init("set_user_selection");
        if (is_restricted_country(context)) {
            util.perr(5, "restricted_country", true);
            i = 4;
        }
        util.perr_funnel(conf.FUNNEL_02_POPUP_CALL);
        util.perr_funnel(conf.FUNNEL_03_POPUP_DISPLAY);
        util.save_choice(context, i);
        int i2 = m_choice;
        m_choice = i;
        if (i != i2) {
            String valueOf = m_display_ms.longValue() > 0 ? String.valueOf(System.currentTimeMillis() - m_display_ms.longValue()) : "";
            if (m_choice == 1) {
                util.perr_funnel(conf.FUNNEL_04_DIALOG_CHOSE_PEER);
                str = "user_chose_peer";
            } else {
                str = "user_chose_not_peer";
            }
            util.perr(str, valueOf);
            try {
                JSONObject put = new JSONObject().put("ms", valueOf);
                if (m_choice == 1) {
                    put.put("close2", true);
                }
                util.perr("popup_close", put.toString());
            } catch (JSONException unused) {
            }
        }
    }

    public static void show_popup(Activity activity) {
        util.perr_funnel(conf.FUNNEL_02_POPUP_CALL);
        FragmentManager fragmentManager = activity.getFragmentManager();
        FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
        Fragment findFragmentByTag = fragmentManager.findFragmentByTag(peer_dialog.TAG);
        if (findFragmentByTag != null) {
            beginTransaction.remove(findFragmentByTag);
        }
        beginTransaction.addToBackStack((String) null);
        peer_dialog peer_dialog = new peer_dialog();
        peer_dialog.set_dialog(m_dialog_type);
        peer_dialog.set_tos_link(m_tos_link);
        peer_dialog.set_btn_not_peer_txt(m_btn_not_peer_txt);
        peer_dialog.set_colors(m_bg_color, m_btn_color, m_txt_color, m_app_name_color, m_btn_txt_peer_color, m_btn_txt_not_peer_color);
        peer_dialog.set_font(m_font);
        peer_dialog.set_on_dissmiss_listener(new b(activity));
        peer_dialog.set_no_vendor(m_no_vendor);
        peer_dialog.setCancelable(m_dlg_cancellable);
        peer_dialog.show(beginTransaction, peer_dialog.TAG);
        report_popup_display();
    }

    public static boolean state_restricted(String str) {
        return !zon_conf.get_sdk_app_conf(str).optBoolean("get_state");
    }

    public static void throw_integration_error(String str) {
        throw new RuntimeException(String.format("Invalid Luminati SDK integration: %s. Refer to Luminati Android SDK Integration Guide at: %s", new Object[]{str, INTEGRATION_GUIDE_URL}));
    }
}
