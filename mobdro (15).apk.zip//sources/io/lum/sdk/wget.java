package io.lum.sdk;

import android.os.Handler;
import android.os.Looper;
import b.a.a.a.a;
import d.a.a.o1;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;

public class wget {
    public connection_impl m_attempt;
    public long m_end_ms;
    public String m_filename;
    public Handler m_handler;
    public int m_hard_timeout_ms;
    public Looper m_looper = null;
    public int m_max_attempts;
    public int m_num_attempts;
    public final option[] m_options;
    public int m_proxy_agent_retry;
    public int m_retry_interval_ms;
    public int m_soft_timeout_ms;
    public long m_start_ms;
    public final String m_url;

    /* renamed from: io.lum.sdk.wget$10  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass10 {
        public static final /* synthetic */ int[] $SwitchMap$io$lum$sdk$wget$connection$state;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0015 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x001c */
        static {
            /*
                io.lum.sdk.wget$connection$state[] r0 = io.lum.sdk.wget.connection.state.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$io$lum$sdk$wget$connection$state = r0
                io.lum.sdk.wget$connection$state r1 = io.lum.sdk.wget.connection.state.RESPONSE     // Catch:{ NoSuchFieldError -> 0x000e }
                r1 = 1
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x000e }
            L_0x000e:
                int[] r0 = $SwitchMap$io$lum$sdk$wget$connection$state     // Catch:{ NoSuchFieldError -> 0x0015 }
                io.lum.sdk.wget$connection$state r1 = io.lum.sdk.wget.connection.state.ERROR     // Catch:{ NoSuchFieldError -> 0x0015 }
                r1 = 2
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x0015 }
            L_0x0015:
                int[] r0 = $SwitchMap$io$lum$sdk$wget$connection$state     // Catch:{ NoSuchFieldError -> 0x001c }
                io.lum.sdk.wget$connection$state r1 = io.lum.sdk.wget.connection.state.TIMEOUT     // Catch:{ NoSuchFieldError -> 0x001c }
                r1 = 3
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x001c }
            L_0x001c:
                int[] r0 = $SwitchMap$io$lum$sdk$wget$connection$state     // Catch:{ NoSuchFieldError -> 0x0023 }
                io.lum.sdk.wget$connection$state r1 = io.lum.sdk.wget.connection.state.CANCELED     // Catch:{ NoSuchFieldError -> 0x0023 }
                r1 = 4
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x0023 }
            L_0x0023:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.wget.AnonymousClass10.<clinit>():void");
        }
    }

    public interface connection {

        public enum state {
            RUNNING,
            RESPONSE,
            ERROR,
            TIMEOUT,
            CANCELED
        }

        JSONObject as_json();

        String as_string();

        int get_code();

        state get_state();
    }

    public final class connection_impl implements connection {
        public HttpURLConnection m_conn;
        public long m_end_ms = 0;
        public IOException m_error = null;
        public String m_req_body = null;
        public String m_res_body = null;
        public int m_res_code = -1;
        public String m_res_message = "";
        public long m_start_ms = util.time_monotonic_ms();
        public connection.state m_state = connection.state.RUNNING;
        public Thread m_thread;
        public int m_timeout_ms = 30000;
        public URL m_url;

        public connection_impl(String str) {
            this.m_thread = util.thread_run((Runnable) new o1(this, str), "connection_impl", str);
        }

        /* access modifiers changed from: private */
        public synchronized void onreport(connection.state state) {
            wget wget;
            String str;
            if (this.m_state == connection.state.RUNNING) {
                if (this.m_end_ms == 0) {
                    this.m_end_ms = util.time_monotonic_ms();
                }
                this.m_state = state;
                if (this.m_thread == null) {
                    util.perr("m_thread_null");
                }
                wget.this.m_handler.removeCallbacksAndMessages(this);
                int ordinal = this.m_state.ordinal();
                int i = 4;
                if (ordinal != 1) {
                    if (ordinal == 2) {
                        wget = wget.this;
                        str = this.m_error.toString() + " (" + get_duration_ms() + "ms)";
                    } else if (ordinal == 3) {
                        this.m_res_message = "Timeout";
                        wget = wget.this;
                        str = "TIMEOUT (" + get_duration_ms() + "ms)";
                    } else if (ordinal == 4) {
                        this.m_res_message = "Canceled";
                        wget = wget.this;
                        str = "CANCELED (" + get_duration_ms() + "ms)";
                    }
                    wget.zerr(3, str);
                } else {
                    wget wget2 = wget.this;
                    if (this.m_res_code < 400) {
                        i = 7;
                    }
                    wget2.zerr(i, "HTTP " + this.m_res_code + " " + this.m_res_message + " (" + get_duration_ms() + "ms)");
                }
                wget.this.onattemptdone(this);
            }
        }

        /* access modifiers changed from: private */
        public void report(final connection.state state, long j) {
            AnonymousClass1 r0 = new Runnable() {
                public void run() {
                    connection_impl.this.onreport(state);
                }
            };
            if (j != 0) {
                wget.this.m_handler.postAtTime(r0, this, j);
            } else {
                wget.this.m_handler.post(r0);
            }
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(12:133|134|135|136|(1:138)|139|140|(0)(0)|144|145|146|(0)(0)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(5:35|36|(2:40|41)|42|43) */
        /* JADX WARNING: Code restructure failed: missing block: B:142:0x0211, code lost:
            r12 = io.lum.sdk.wget.connection.state.RESPONSE;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:143:0x0214, code lost:
            r12 = io.lum.sdk.wget.connection.state.ERROR;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:148:0x021d, code lost:
            r12 = r11.m_conn;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:198:?, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:97:0x0188, code lost:
            if (r4 != null) goto L_0x018a;
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:139:0x020d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:42:0x00e2 */
        /* JADX WARNING: Removed duplicated region for block: B:142:0x0211 A[Catch:{ all -> 0x01db }] */
        /* JADX WARNING: Removed duplicated region for block: B:143:0x0214 A[Catch:{ all -> 0x01db }] */
        /* JADX WARNING: Removed duplicated region for block: B:148:0x021d A[Catch:{ NullPointerException -> 0x0246 }] */
        /* JADX WARNING: Removed duplicated region for block: B:198:? A[RETURN, SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:40:0x00df A[SYNTHETIC, Splitter:B:40:0x00df] */
        /* JADX WARNING: Removed duplicated region for block: B:47:0x00e6 A[Catch:{ all -> 0x018e, NullPointerException -> 0x0102, SocketTimeoutException -> 0x0220, IOException -> 0x01de }] */
        /* JADX WARNING: Removed duplicated region for block: B:51:0x00ed A[SYNTHETIC, Splitter:B:51:0x00ed] */
        /* JADX WARNING: Removed duplicated region for block: B:57:0x00fb A[SYNTHETIC, Splitter:B:57:0x00fb] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public /* synthetic */ void a(java.lang.String r12) {
            /*
                r11 = this;
                java.lang.String r0 = ""
                java.lang.String r1 = "wget_m_conn_null"
                r2 = 0
                java.net.URL r4 = new java.net.URL     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r4.<init>(r12)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r11.m_url = r4     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.Proxy r4 = java.net.Proxy.NO_PROXY     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget r5 = io.lum.sdk.wget.this     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r5 = r5.m_num_attempts     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r5 <= 0) goto L_0x0046
                io.lum.sdk.sdk_proxy_pool r4 = io.lum.sdk.util.m_sdk_proxy_pool     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r4 != 0) goto L_0x0029
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0025 }
                if (r12 == 0) goto L_0x0028
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0025 }
                r12.disconnect()     // Catch:{ NullPointerException -> 0x0025 }
                goto L_0x0028
            L_0x0025:
                io.lum.sdk.util.perr(r1)
            L_0x0028:
                return
            L_0x0029:
                java.net.Proxy r4 = new java.net.Proxy     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.Proxy$Type r5 = java.net.Proxy.Type.HTTP     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.InetSocketAddress r6 = new java.net.InetSocketAddress     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.sdk_proxy_pool r7 = io.lum.sdk.util.m_sdk_proxy_pool     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r7 = r7.get_host()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.sdk_proxy_pool r8 = io.lum.sdk.util.m_sdk_proxy_pool     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r8 = r8.get_port()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r6.<init>(r7, r8)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r4.<init>(r5, r6)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget r5 = io.lum.sdk.wget.this     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget.access$808(r5)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x0046:
                java.net.URL r5 = r11.m_url     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.URLConnection r5 = r5.openConnection(r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r5 = (java.net.HttpURLConnection) r5     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r11.m_conn = r5     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.Proxy$Type r5 = java.net.Proxy.Type.DIRECT     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.Proxy$Type r4 = r4.type()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                boolean r4 = r5.equals(r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r4 != 0) goto L_0x006b
                java.lang.String r4 = "x-proxy"
                io.lum.sdk.sdk_proxy_pool r5 = io.lum.sdk.util.m_sdk_proxy_pool     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r5 = r5.get_details()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget$option r4 = io.lum.sdk.wget.header(r4, r5)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r4.apply((io.lum.sdk.wget.connection_impl) r11)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x006b:
                io.lum.sdk.wget r4 = io.lum.sdk.wget.this     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget$option[] r4 = r4.m_options     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r5 = r4.length     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r6 = 0
                r7 = 0
            L_0x0074:
                if (r7 >= r5) goto L_0x007e
                r8 = r4[r7]     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r8.apply((io.lum.sdk.wget.connection_impl) r11)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r7 = r7 + 1
                goto L_0x0074
            L_0x007e:
                java.lang.String r4 = io.lum.sdk.util.cmd2url(r0)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                boolean r12 = r12.startsWith(r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r12 == 0) goto L_0x0091
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r4 = "Origin"
                java.lang.String r5 = "app://hola-ui"
                r12.setRequestProperty(r4, r5)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x0091:
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r4 = r11.m_timeout_ms     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r12.setConnectTimeout(r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r4 = r11.m_timeout_ms     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r12.setReadTimeout(r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r12 = r11.m_timeout_ms     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r12 <= 0) goto L_0x00ae
                io.lum.sdk.wget$connection$state r12 = io.lum.sdk.wget.connection.state.TIMEOUT     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                long r4 = r11.m_start_ms     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r7 = r11.m_timeout_ms     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                long r7 = (long) r7     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                long r4 = r4 + r7
                r11.report(r12, r4)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x00ae:
                java.lang.String r12 = r11.m_req_body     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r4 = 0
                if (r12 == 0) goto L_0x00e7
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r5 = 1
                r12.setDoOutput(r5)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r5 = r11.m_req_body     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r5 = r5.length()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r12.setFixedLengthStreamingMode(r5)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x00e3, all -> 0x00dc }
                java.io.OutputStream r12 = r12.getOutputStream()     // Catch:{ NullPointerException -> 0x00e3, all -> 0x00dc }
                java.lang.String r5 = r11.m_req_body     // Catch:{ NullPointerException -> 0x00da, all -> 0x00d7 }
                byte[] r5 = r5.getBytes()     // Catch:{ NullPointerException -> 0x00da, all -> 0x00d7 }
                r12.write(r5)     // Catch:{ NullPointerException -> 0x00da, all -> 0x00d7 }
            L_0x00d3:
                r12.close()     // Catch:{ IllegalStateException -> 0x00e7 }
                goto L_0x00e7
            L_0x00d7:
                r0 = move-exception
                r4 = r12
                goto L_0x00dd
            L_0x00da:
                goto L_0x00e4
            L_0x00dc:
                r0 = move-exception
            L_0x00dd:
                if (r4 == 0) goto L_0x00e2
                r4.close()     // Catch:{ IllegalStateException -> 0x00e2 }
            L_0x00e2:
                throw r0     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x00e3:
                r12 = r4
            L_0x00e4:
                if (r12 == 0) goto L_0x00e7
                goto L_0x00d3
            L_0x00e7:
                io.lum.sdk.wget$connection$state r12 = r11.m_state     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget$connection$state r5 = io.lum.sdk.wget.connection.state.RUNNING     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r12 == r5) goto L_0x00fb
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x00f7 }
                if (r12 == 0) goto L_0x00fa
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x00f7 }
                r12.disconnect()     // Catch:{ NullPointerException -> 0x00f7 }
                goto L_0x00fa
            L_0x00f7:
                io.lum.sdk.util.perr(r1)
            L_0x00fa:
                return
            L_0x00fb:
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0102 }
                java.io.InputStream r12 = r12.getInputStream()     // Catch:{ NullPointerException -> 0x0102 }
                goto L_0x012b
            L_0x0102:
                r12 = move-exception
                java.lang.StackTraceElement[] r5 = r12.getStackTrace()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r5 = r5[r6]     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r7 = r5.getClassName()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r8 = "java.net.NetworkInterface"
                boolean r7 = r7.equals(r8)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r7 == 0) goto L_0x012a
                java.lang.String r5 = r5.getMethodName()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r7 = "getNetworkInterfacesList"
                boolean r5 = r5.equals(r7)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r5 != 0) goto L_0x0122
                goto L_0x012a
            L_0x0122:
                java.io.IOException r0 = new java.io.IOException     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r4 = "Android internal error"
                r0.<init>(r4, r12)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                throw r0     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x012a:
                r12 = r4
            L_0x012b:
                java.io.ByteArrayOutputStream r5 = new java.io.ByteArrayOutputStream     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r5.<init>()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget r7 = io.lum.sdk.wget.this     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r7 = r7.m_filename     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r7 == 0) goto L_0x0143
                java.io.FileOutputStream r4 = new java.io.FileOutputStream     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget r7 = io.lum.sdk.wget.this     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r7 = r7.m_filename     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r4.<init>(r7)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x0143:
                r7 = 4096(0x1000, float:5.74E-42)
                byte[] r7 = new byte[r7]     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x0147:
                int r8 = r12.read(r7)     // Catch:{ Exception -> 0x0190 }
                if (r8 <= 0) goto L_0x015d
                io.lum.sdk.wget$connection$state r9 = r11.m_state     // Catch:{ Exception -> 0x0190 }
                io.lum.sdk.wget$connection$state r10 = io.lum.sdk.wget.connection.state.RUNNING     // Catch:{ Exception -> 0x0190 }
                if (r9 != r10) goto L_0x015d
                if (r4 == 0) goto L_0x0159
                r4.write(r7, r6, r8)     // Catch:{ Exception -> 0x0190 }
                goto L_0x0147
            L_0x0159:
                r5.write(r7, r6, r8)     // Catch:{ Exception -> 0x0190 }
                goto L_0x0147
            L_0x015d:
                io.lum.sdk.wget$connection$state r6 = r11.m_state     // Catch:{ Exception -> 0x0190 }
                io.lum.sdk.wget$connection$state r7 = io.lum.sdk.wget.connection.state.RUNNING     // Catch:{ Exception -> 0x0190 }
                if (r6 == r7) goto L_0x017c
                r5.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r12.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r4 == 0) goto L_0x016e
                r4.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x016e:
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0178 }
                if (r12 == 0) goto L_0x017b
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0178 }
                r12.disconnect()     // Catch:{ NullPointerException -> 0x0178 }
                goto L_0x017b
            L_0x0178:
                io.lum.sdk.util.perr(r1)
            L_0x017b:
                return
            L_0x017c:
                java.lang.String r6 = r5.toString()     // Catch:{ Exception -> 0x0190 }
                r11.m_res_body = r6     // Catch:{ Exception -> 0x0190 }
                r5.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r12.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r4 == 0) goto L_0x01b0
            L_0x018a:
                r4.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                goto L_0x01b0
            L_0x018e:
                r0 = move-exception
                goto L_0x01cd
            L_0x0190:
                r6 = move-exception
                java.lang.String r7 = "inputstream_read_exception"
                java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ all -> 0x018e }
                r8.<init>()     // Catch:{ all -> 0x018e }
                r8.append(r0)     // Catch:{ all -> 0x018e }
                r8.append(r6)     // Catch:{ all -> 0x018e }
                java.lang.String r0 = r8.toString()     // Catch:{ all -> 0x018e }
                io.lum.sdk.util.perr((java.lang.String) r7, (java.lang.String) r0)     // Catch:{ all -> 0x018e }
                r5.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r12 == 0) goto L_0x01ad
                r12.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x01ad:
                if (r4 == 0) goto L_0x01b0
                goto L_0x018a
            L_0x01b0:
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                int r12 = r12.getResponseCode()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r11.m_res_code = r12     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.lang.String r12 = r12.getResponseMessage()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r11.m_res_message = r12     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                io.lum.sdk.wget$connection$state r12 = io.lum.sdk.wget.connection.state.RESPONSE     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                r11.report(r12, r2)     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
                if (r12 == 0) goto L_0x0249
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
                goto L_0x0242
            L_0x01cd:
                r5.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
                if (r12 == 0) goto L_0x01d5
                r12.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x01d5:
                if (r4 == 0) goto L_0x01da
                r4.close()     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x01da:
                throw r0     // Catch:{ SocketTimeoutException -> 0x0220, IOException -> 0x01de }
            L_0x01db:
                r12 = move-exception
                goto L_0x024a
            L_0x01de:
                r12 = move-exception
                io.lum.sdk.wget$connection$state r0 = r11.m_state     // Catch:{ all -> 0x01db }
                io.lum.sdk.wget$connection$state r4 = io.lum.sdk.wget.connection.state.RUNNING     // Catch:{ all -> 0x01db }
                if (r0 == r4) goto L_0x01f3
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x01ef }
                if (r12 == 0) goto L_0x01f2
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x01ef }
                r12.disconnect()     // Catch:{ NullPointerException -> 0x01ef }
                goto L_0x01f2
            L_0x01ef:
                io.lum.sdk.util.perr(r1)
            L_0x01f2:
                return
            L_0x01f3:
                r11.m_error = r12     // Catch:{ all -> 0x01db }
                java.lang.String r12 = r12.toString()     // Catch:{ all -> 0x01db }
                r11.m_res_message = r12     // Catch:{ all -> 0x01db }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ Exception -> 0x020d }
                int r12 = r12.getResponseCode()     // Catch:{ Exception -> 0x020d }
                r11.m_res_code = r12     // Catch:{ Exception -> 0x020d }
                if (r12 <= 0) goto L_0x020d
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ Exception -> 0x020d }
                java.lang.String r12 = r12.getResponseMessage()     // Catch:{ Exception -> 0x020d }
                r11.m_res_message = r12     // Catch:{ Exception -> 0x020d }
            L_0x020d:
                int r12 = r11.m_res_code     // Catch:{ all -> 0x01db }
                if (r12 <= 0) goto L_0x0214
                io.lum.sdk.wget$connection$state r12 = io.lum.sdk.wget.connection.state.RESPONSE     // Catch:{ all -> 0x01db }
                goto L_0x0216
            L_0x0214:
                io.lum.sdk.wget$connection$state r12 = io.lum.sdk.wget.connection.state.ERROR     // Catch:{ all -> 0x01db }
            L_0x0216:
                r11.report(r12, r2)     // Catch:{ all -> 0x01db }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
                if (r12 == 0) goto L_0x0249
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
                goto L_0x0242
            L_0x0220:
                r12 = move-exception
                io.lum.sdk.wget$connection$state r0 = r11.m_state     // Catch:{ all -> 0x01db }
                io.lum.sdk.wget$connection$state r4 = io.lum.sdk.wget.connection.state.RUNNING     // Catch:{ all -> 0x01db }
                if (r0 == r4) goto L_0x0235
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0231 }
                if (r12 == 0) goto L_0x0234
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0231 }
                r12.disconnect()     // Catch:{ NullPointerException -> 0x0231 }
                goto L_0x0234
            L_0x0231:
                io.lum.sdk.util.perr(r1)
            L_0x0234:
                return
            L_0x0235:
                r11.m_error = r12     // Catch:{ all -> 0x01db }
                io.lum.sdk.wget$connection$state r12 = io.lum.sdk.wget.connection.state.TIMEOUT     // Catch:{ all -> 0x01db }
                r11.report(r12, r2)     // Catch:{ all -> 0x01db }
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
                if (r12 == 0) goto L_0x0249
                java.net.HttpURLConnection r12 = r11.m_conn     // Catch:{ NullPointerException -> 0x0246 }
            L_0x0242:
                r12.disconnect()     // Catch:{ NullPointerException -> 0x0246 }
                goto L_0x0249
            L_0x0246:
                io.lum.sdk.util.perr(r1)
            L_0x0249:
                return
            L_0x024a:
                java.net.HttpURLConnection r0 = r11.m_conn     // Catch:{ NullPointerException -> 0x0254 }
                if (r0 == 0) goto L_0x0257
                java.net.HttpURLConnection r0 = r11.m_conn     // Catch:{ NullPointerException -> 0x0254 }
                r0.disconnect()     // Catch:{ NullPointerException -> 0x0254 }
                goto L_0x0257
            L_0x0254:
                io.lum.sdk.util.perr(r1)
            L_0x0257:
                goto L_0x0259
            L_0x0258:
                throw r12
            L_0x0259:
                goto L_0x0258
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.wget.connection_impl.a(java.lang.String):void");
        }

        public JSONObject as_json() {
            try {
                if (this.m_res_body != null) {
                    return new JSONObject(this.m_res_body);
                }
                return null;
            } catch (JSONException e2) {
                wget.this.zerr(3, e2.toString());
                return null;
            }
        }

        public String as_string() {
            return this.m_res_body;
        }

        public int get_code() {
            return this.m_res_code;
        }

        public long get_duration_ms() {
            long j = this.m_end_ms;
            if (j != 0) {
                return j - this.m_start_ms;
            }
            throw new IllegalStateException();
        }

        public connection.state get_state() {
            return this.m_state;
        }
    }

    public static abstract class option {
        public void apply(connection_impl connection_impl) {
        }

        public void apply(wget wget) {
        }
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x003e */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x003e A[LOOP:1: B:8:0x003e->B:30:0x003e, LOOP_START, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public wget(java.lang.String r4, io.lum.sdk.wget.option... r5) {
        /*
            r3 = this;
            r3.<init>()
            r0 = 0
            r3.m_looper = r0
            r0 = 0
            r3.m_hard_timeout_ms = r0
            r1 = 10000(0x2710, float:1.4013E-41)
            r3.m_soft_timeout_ms = r1
            long r1 = io.lum.sdk.util.time_monotonic_ms()
            r3.m_start_ms = r1
            r1 = 0
            r3.m_end_ms = r1
            r1 = 1
            r3.m_max_attempts = r1
            r3.m_num_attempts = r0
            r3.m_proxy_agent_retry = r0
            r1 = 1000(0x3e8, float:1.401E-42)
            r3.m_retry_interval_ms = r1
            r3.m_url = r4
            r3.m_options = r5
            int r1 = r5.length
        L_0x0027:
            if (r0 >= r1) goto L_0x0033
            r2 = r5[r0]
            if (r2 == 0) goto L_0x0030
            r2.apply((io.lum.sdk.wget) r3)
        L_0x0030:
            int r0 = r0 + 1
            goto L_0x0027
        L_0x0033:
            io.lum.sdk.wget$6 r5 = new io.lum.sdk.wget$6
            r5.<init>()
            java.lang.String r0 = "wget"
            io.lum.sdk.util.thread_run((java.lang.Runnable) r5, (java.lang.String) r0, (java.lang.String) r4)
            monitor-enter(r3)
        L_0x003e:
            android.os.Looper r4 = r3.m_looper     // Catch:{ all -> 0x0073 }
            if (r4 != 0) goto L_0x0046
            r3.wait()     // Catch:{ InterruptedException -> 0x003e }
            goto L_0x003e
        L_0x0046:
            monitor-exit(r3)     // Catch:{ all -> 0x0073 }
            int r4 = r3.m_soft_timeout_ms
            if (r4 <= 0) goto L_0x0058
            android.os.Handler r4 = r3.m_handler
            io.lum.sdk.wget$7 r5 = new io.lum.sdk.wget$7
            r5.<init>()
            int r0 = r3.m_soft_timeout_ms
            long r0 = (long) r0
            r4.postDelayed(r5, r0)
        L_0x0058:
            int r4 = r3.m_hard_timeout_ms
            if (r4 <= 0) goto L_0x0069
            android.os.Handler r4 = r3.m_handler
            io.lum.sdk.wget$8 r5 = new io.lum.sdk.wget$8
            r5.<init>()
            int r0 = r3.m_hard_timeout_ms
            long r0 = (long) r0
            r4.postDelayed(r5, r0)
        L_0x0069:
            io.lum.sdk.wget$connection_impl r4 = new io.lum.sdk.wget$connection_impl
            java.lang.String r5 = r3.m_url
            r4.<init>(r5)
            r3.m_attempt = r4
            return
        L_0x0073:
            r4 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0073 }
            goto L_0x0077
        L_0x0076:
            throw r4
        L_0x0077:
            goto L_0x0076
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.wget.<init>(java.lang.String, io.lum.sdk.wget$option[]):void");
    }

    public static /* synthetic */ int access$808(wget wget) {
        int i = wget.m_proxy_agent_retry;
        wget.m_proxy_agent_retry = i + 1;
        return i;
    }

    public static option attempts(final int i) {
        return new option() {
            public void apply(wget wget) {
                int unused = wget.m_max_attempts = i;
            }
        };
    }

    public static option body(final String str, final String str2) {
        return new option() {
            public void apply(connection_impl connection_impl) {
                connection_impl.m_conn.setRequestProperty("Content-Type", str2);
                connection_impl.m_req_body = str;
            }
        };
    }

    public static option body(JSONObject jSONObject) {
        return body(jSONObject.toString(), "application/json");
    }

    public static option header(final String str, final String str2) {
        return new option() {
            public void apply(connection_impl connection_impl) {
                connection_impl.m_conn.setRequestProperty(str, str2);
            }
        };
    }

    /* access modifiers changed from: private */
    public void onattemptdone(connection_impl connection_impl2) {
        if (connection_impl2.get_state() == connection.state.CANCELED || this.m_num_attempts == this.m_max_attempts || accept(connection_impl2)) {
            if (this.m_end_ms == 0) {
                this.m_end_ms = util.time_monotonic_ms();
            }
            this.m_handler.removeCallbacksAndMessages((Object) null);
            Looper looper = this.m_looper;
            if (looper != null) {
                looper.quit();
            }
            int ordinal = connection_impl2.get_state().ordinal();
            if (ordinal == 1) {
                onresponse(connection_impl2);
            } else if (ordinal == 2) {
                onerror(connection_impl2);
            } else if (ordinal == 3) {
                ontimeout(connection_impl2);
            }
        } else {
            this.m_num_attempts++;
            StringBuilder a2 = a.a("RETRY (");
            a2.append(this.m_num_attempts);
            a2.append("/");
            a2.append(this.m_max_attempts);
            a2.append(") in ");
            zerr(5, a.a(a2, this.m_retry_interval_ms, "ms"));
            this.m_handler.postDelayed(new Runnable() {
                public void run() {
                    wget wget = wget.this;
                    connection_impl unused = wget.m_attempt = new connection_impl(wget.m_url);
                }
            }, (long) this.m_retry_interval_ms);
        }
    }

    public static option retry_interval_ms(final int i) {
        return new option() {
            public void apply(wget wget) {
                int unused = wget.m_retry_interval_ms = i;
            }
        };
    }

    public static option soft_timeout_ms(final int i) {
        return new option() {
            public void apply(wget wget) {
                int unused = wget.m_soft_timeout_ms = i;
            }
        };
    }

    /* access modifiers changed from: private */
    public void zerr(int i, String str) {
        StringBuilder a2 = a.a("lumsdk/wget ");
        a2.append(this.m_url);
        util._zerr(a2.toString(), i, str);
    }

    public boolean accept(connection connection2) {
        return connection2.get_state() == connection.state.RESPONSE && connection2.get_code() < 500;
    }

    public void cancel() {
        this.m_attempt.report(connection.state.CANCELED, 0);
    }

    public final long get_duration_ms() {
        long j = this.m_end_ms;
        if (j != 0) {
            return j - this.m_start_ms;
        }
        throw new IllegalStateException();
    }

    public void ondone(connection connection2) {
    }

    public void onerror(connection connection2) {
        onfailure(connection2);
    }

    public void onfailure(connection connection2) {
        ondone(connection2);
    }

    public void onresponse(connection connection2) {
        if (connection2.get_code() < 400) {
            if (this.m_proxy_agent_retry > 0) {
                util.m_sdk_proxy_pool.success("wget");
            }
            onsuccess(connection2);
            return;
        }
        if (this.m_proxy_agent_retry > 0) {
            util.m_sdk_proxy_pool.failure("wget");
        }
        onerror(connection2);
    }

    public void onslow() {
    }

    public void onsuccess(connection connection2) {
        ondone(connection2);
    }

    public void ontimeout(connection connection2) {
        onfailure(connection2);
    }
}
