package io.lum.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import io.lum.sdk.set_strict;
import io.lum.sdk.util;
import java.util.HashMap;
import java.util.Map;

public class state extends set_strict<key> {
    public static final key BATTERY_LEVEL = new key("battery_level");
    public static final key MOBILE_CONNECTED = new key("mobile_connected");
    public static final key MOBILE_ENABLE = new key("mobile_enable");
    public static final key ON_CALL = new key("on_call");
    public static final key SCREEN_ON = new key("screen_on");
    public static final key USING_BATTERY = new key("using_battery");
    public static final key WIFI_CONNECTED = new key("wifi_connected");
    public static boolean s_inited;

    public static class key {
        public static final Map<String, key> s_register = new HashMap();
        public final String m_name;

        public key(String str) {
            this.m_name = str;
            s_register.put(str, this);
        }

        public String toString() {
            return this.m_name;
        }
    }

    public static abstract class listener extends set_strict.listener<key> {
    }

    public state(Context context) {
        super(context, "state");
        synchronized (state.class) {
            if (!s_inited) {
                s_inited = true;
                clear();
                collect(context);
            }
        }
    }

    private void collect(Context context) {
        boolean z;
        boolean z2;
        update_battery_state(context);
        update_screen_state();
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.m_app_context.getSystemService("connectivity")).getActiveNetworkInfo();
        boolean z3 = true;
        if (activeNetworkInfo != null) {
            int type = activeNetworkInfo.getType();
            z2 = type == 1;
            z = type == 0;
        } else {
            z = false;
            z2 = false;
        }
        set(WIFI_CONNECTED, z2);
        set(MOBILE_CONNECTED, z);
        key key2 = ON_CALL;
        if (((TelephonyManager) this.m_app_context.getSystemService("phone")).getCallState() != 2) {
            z3 = false;
        }
        set(key2, z3);
    }

    private float get_battery_level(Intent intent) {
        int intExtra = intent.getIntExtra("level", -1);
        int intExtra2 = intent.getIntExtra("scale", 0);
        float f2 = (intExtra <= -1 || intExtra2 <= 0) ? -1.0f : ((float) intExtra) / ((float) intExtra2);
        zerr(5, String.format("level: %s, scale: %s", new Object[]{Integer.valueOf(intExtra), Integer.valueOf(intExtra2)}));
        return f2;
    }

    private void update_battery_level(float f2) {
        set(BATTERY_LEVEL, f2);
    }

    private void update_battery_state(Context context) {
        Intent registerReceiver = this.m_app_context.registerReceiver((BroadcastReceiver) null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        boolean z = false;
        if (registerReceiver == null) {
            util.perr("battery_init_status", "registerReceiver no battery sticky intent");
            set(USING_BATTERY, false);
            return;
        }
        boolean z2 = registerReceiver.getIntExtra("plugged", -1) < 1;
        if (z2) {
            float f2 = get_battery_level(registerReceiver);
            if (f2 == 0.0f) {
                util.perr(4, "battery_level_0", true);
                if (!util.is_tv(context)) {
                    util.perr(4, "battery_level_0_not_tv", true);
                }
                update_battery_level(f2);
                z2 = z;
            } else if (util.is_tv(context)) {
                util.perr(5, "battery_level_not_0_tv", true);
            }
            z = z2;
            update_battery_level(f2);
            z2 = z;
        } else {
            update_battery_level(registerReceiver);
        }
        set(USING_BATTERY, z2);
    }

    public key resolve_key(String str) {
        return key.s_register.get(str);
    }

    public void update_battery_level(Intent intent) {
        update_battery_level(get_battery_level(intent));
    }

    public void update_screen_state() {
        update_screen_state(false);
    }

    public void update_screen_state(boolean z) {
        final boolean z2 = z;
        new util.with_feedback(this.m_app_context, "screen_state", false, true, 30000) {
            public boolean check() {
                if (z2) {
                    return false;
                }
                return util.is_screen_used(state.this.m_app_context);
            }

            public void next(boolean z) {
                state.this.set(state.SCREEN_ON, z);
            }
        };
    }
}
