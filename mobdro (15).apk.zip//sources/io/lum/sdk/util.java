package io.lum.sdk;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.PowerManager;
import android.os.Process;
import android.os.StatFs;
import android.os.StrictMode;
import android.support.v4.media.session.PlaybackStateCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.ActivityChooserModel;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.leanback.widget.ParallaxTarget;
import androidx.mediarouter.media.MediaRouter;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import b.a.a.a.a;
import d.a.a.d1;
import d.a.a.e1;
import d.a.a.f1;
import d.a.a.g1;
import d.a.a.i1;
import d.a.a.j1;
import d.a.a.k1;
import d.a.a.l1;
import d.a.a.m1;
import io.lum.sdk.api;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpPost;
import io.lum.sdk.async.http.AsyncHttpResponse;
import io.lum.sdk.async.http.body.JSONObjectBody;
import io.lum.sdk.bcast;
import io.lum.sdk.conf;
import io.lum.sdk.perr;
import io.lum.sdk.wget;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.lang.Thread;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class util {
    public static volatile String ACTION_DISPLAY_CHANGE = null;
    public static volatile String ACTION_NET_SVC_KEEPALIVE = null;
    public static volatile String ACTION_SVC_KEEPALIVE = null;
    public static boolean IS_FIRST_RUN = false;
    public static final int LALERT = 1;
    public static final int LCONSOLE = 256;
    public static final int LCRIT = 2;
    public static final int LDEBUG = 7;
    public static final int LDOCANCEL = 1024;
    public static final int LDOEXIT = 512;
    public static final int LDOFLUSH = 8192;
    public static final int LDOPASS = 4096;
    public static final int LEMERG = 0;
    public static final int LERR = 3;
    public static final int LEXIT = 514;
    public static final int LFLAGS_MASK = 65280;
    public static final int LINFO = 6;
    public static final int LLONGMSG = 2048;
    public static final int LNOTICE = 5;
    public static final int LPANIC = 512;
    public static final int LSEVERITY_MASK = 15;
    public static final int LWARNING = 4;
    public static final int MS_HOUR = 3600000;
    public static final int MS_MIN = 60000;
    public static final int MS_SEC = 1000;
    public static final String NOTIFICATION_CHANNEL_ID = "001";
    public static final int NSEC_PER_MS = 1000000;
    public static final int PERR_SEND = 1;
    public static volatile String apkid = null;
    public static util instance = null;
    public static volatile String m_app_name = null;
    @SuppressLint({"StaticFieldLeak"})
    public static volatile bcast.client m_bcast_client = null;
    public static volatile Object m_bcast_client_lock = new Object();
    public static volatile bcast_handler m_bcast_handler = null;
    public static volatile Object m_bcast_handler_lock = new Object();
    public static Boolean m_blacklisted = null;
    public static final Object m_blacklisted_lock = new Object();
    public static String m_cachedir = null;
    public static final String m_certs_filename = "lumsdk_certs.txt";
    public static cloud_config m_cloud_config = null;
    public static volatile conf m_conf = null;
    public static JSONObject m_def_sdk_state_files = null;
    public static Boolean m_force_is_debug = null;
    public static boolean m_http_send_proxy = false;
    public static int m_http_send_proxy_retries = 0;
    public static Boolean m_http_send_wget = false;
    public static Boolean m_is_debug = null;
    public static Boolean m_is_debug_layout = null;
    public static Boolean m_is_miui = null;
    public static volatile Boolean m_is_online = false;
    public static Boolean m_is_test_app = null;
    public static Boolean m_is_tv = null;
    public static volatile job_keepalive m_job_keepalive = null;
    public static volatile keepalive m_keepalive = null;
    public static final Object m_keepalive_lock = new Object();
    public static volatile ArrayList<String> m_logs = new ArrayList<>();
    public static String m_membuf = "";
    public static final String m_miui_apkid = "com.miui.system";
    public static final Object m_mobile_usage_lock = new Object();
    public static AtomicInteger m_notification_id = new AtomicInteger((int) Math.abs(System.currentTimeMillis() % FragmentStateAdapter.GRACE_WINDOW_TIME_MS));
    public static final Boolean m_oom_dump_lock = true;
    public static Boolean m_oom_dump_written = false;
    public static String m_path = null;
    public static volatile perr m_perr = new perr();
    public static Handler m_perr_handler = null;
    public static boolean m_perr_inited = false;
    public static final ReentrantReadWriteLock m_perr_lock = new ReentrantReadWriteLock();
    public static String m_perr_p_rx_fmt = "^perr_lum_sdk_android_test\\s(.+)?\\nVersion:\\s([0-9.]+)[\\s\\S]+APKID:\\s\\S+(\\r\\n)+(?:Tracking\\sID:\\s\\w+)?([\\s\\S]*)";
    public static volatile perr_pool m_perr_pool = null;
    public static volatile boolean m_perr_send_pending = false;
    public static volatile Object m_perr_send_pending_lock = new Object();
    public static HandlerThread m_perr_thread = null;
    public static int m_ref = 0;
    public static HashMap<String, File> m_screenshots = new HashMap<>();
    public static ThreadLocal<SimpleDateFormat> m_sdf_sql = new sdf_provider("yyyy.MM.dd HH:mm:ss.SSS", Locale.US);
    public static ThreadLocal<SimpleDateFormat> m_sdf_ts = new sdf_provider("yyyyMMdd_HHmmss", Locale.US);
    public static volatile sdk_proxy_pool m_sdk_proxy_pool = null;
    public static secure_conf m_secure_conf = null;
    public static final String m_shared_prefix = "lumsdk_api";
    @SuppressLint({"StaticFieldLeak"})
    public static volatile svc_client m_svc_client;
    public static volatile String m_tracking_id = "";
    public static int m_util_init_ret = -1;
    public static volatile String m_uuid;
    public static ExecutorService m_zerr_ex = Executors.newSingleThreadExecutor();
    public static File m_zerr_file;
    public static FileWriter m_zerr_filewriter;
    public static final Object m_zerr_lock = new Object();
    public static Pattern perr_file_rx = Pattern.compile("^((\\d{8}_\\d{6})(?:_([\\d.]{9,11}|once))?_perr_([a-z0-9_]+))\\.log$");
    public static volatile perr_funnel perr_funnel_main;
    public static boolean perr_memleak_thread_sent;
    public static volatile HashMap<String, ExecutorService> thread_executors;
    public static volatile HashMap<String, thread_factory> thread_factories = new HashMap<>();
    public static AtomicInteger thread_id = new AtomicInteger(0);
    public static HashMap<AtomicInteger, JSONObject> thread_list = new HashMap<>();
    public static int zerr_level = 5;
    public static final String[] zerr_severity_str = {"EMERGENCY", "ALERT", "CRITICAL", "ERROR", "WARNING", "NOTICE", "INFO", "DEBUG"};

    /* renamed from: io.lum.sdk.util$10  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass10 {
        public static final /* synthetic */ int[] $SwitchMap$io$lum$sdk$util$perr_once;

        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000f */
        static {
            /*
                io.lum.sdk.util$perr_once[] r0 = io.lum.sdk.util.perr_once.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$io$lum$sdk$util$perr_once = r0
                r1 = 2
                io.lum.sdk.util$perr_once r2 = io.lum.sdk.util.perr_once.NONE     // Catch:{ NoSuchFieldError -> 0x000f }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x000f }
            L_0x000f:
                int[] r0 = $SwitchMap$io$lum$sdk$util$perr_once     // Catch:{ NoSuchFieldError -> 0x0016 }
                io.lum.sdk.util$perr_once r2 = io.lum.sdk.util.perr_once.VER     // Catch:{ NoSuchFieldError -> 0x0016 }
                r2 = 0
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0016 }
            L_0x0016:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.AnonymousClass10.<clinit>():void");
        }
    }

    public interface callback_int {
        void run(int i);
    }

    public class cmd_resp {
        public String out;
        public int ret_val;

        public cmd_resp(String str, int i) {
            this.out = str;
            this.ret_val = i;
        }
    }

    public static class exception_handler implements Thread.UncaughtExceptionHandler {
        public String m_name;
        public Runnable m_restart;
        public final int m_restart_cooldown = 10000;
        public long m_restart_ts;
        public int m_restarted_count = 0;
        public final Integer m_restarted_max = 10;
        public int m_zexit_count = 0;
        public final int m_zexit_max = 10;

        public exception_handler(String str, Runnable runnable) {
            this.m_name = str;
            this.m_restart = runnable;
        }

        public void uncaughtException(Thread thread, Throwable th) {
            String str;
            String str2;
            String e2s;
            synchronized (this.m_restarted_max) {
                util._zerr("lumsdk/" + this.m_name + "/exception", 4, util.e2s(th));
                if (System.currentTimeMillis() - this.m_restart_ts >= FragmentStateAdapter.GRACE_WINDOW_TIME_MS) {
                    if (!util.is_shutdown(th)) {
                        String message = th.getMessage();
                        if (message == null || !message.contains("zexit ")) {
                            str = this.m_name + "_crash";
                            str2 = "" + message;
                            e2s = util.e2s(th);
                        } else {
                            int i = this.m_zexit_count + 1;
                            this.m_zexit_count = i;
                            if (i > 10) {
                                util.perr(3, this.m_name + "_zexit_max_exceeded", "count: " + this.m_zexit_count, util.e2s(th), true);
                                return;
                            }
                            str = this.m_name + "_zexit";
                            str2 = "" + message;
                            e2s = util.e2s(th);
                        }
                        util.perr(3, str, str2, e2s, true);
                        int i2 = this.m_restarted_count + 1;
                        this.m_restarted_count = i2;
                        if (i2 > this.m_restarted_max.intValue()) {
                            util.perr(3, this.m_name + "_restart_max_exceeded", "count: " + this.m_restarted_count, util.e2s(th), true);
                            return;
                        }
                        this.m_restart_ts = System.currentTimeMillis();
                        this.m_restart.run();
                    }
                }
            }
        }
    }

    public static class job_keepalive extends keepalive {
        public AtomicInteger m_auto_job_id;
        public int m_job_id = 0;
        public int m_max_job_id;
        public int m_min_job_id;
        public int m_parent_job_id;
        public String m_task_id;

        public job_keepalive(String str, String str2, int i, conf.key key) {
            this.m_target = str;
            this.m_task_id = str2;
            this.m_key = key;
            this.m_parent_job_id = i;
            this.m_min_job_id = util.get_min_job_id();
            this.m_max_job_id = util.get_max_job_id();
        }

        /* access modifiers changed from: private */
        /* renamed from: cancel_job */
        public void a(Context context, int i) {
            int unused = util.zerr(5, String.format("canceling job %s", new Object[]{Integer.valueOf(i)}));
            try {
                svc_job.cancel_job(context, i);
            } catch (NullPointerException unused2) {
            }
        }

        public Runnable reschedule(Context context, int i) {
            this.m_job_id = this.m_parent_job_id;
            return super.schedule(context, i);
        }

        public Runnable schedule(Context context, int i) {
            if (this.m_auto_job_id == null) {
                this.m_auto_job_id = new AtomicInteger(this.m_min_job_id - 1);
            }
            int incrementAndGet = this.m_auto_job_id.incrementAndGet();
            this.m_job_id = incrementAndGet;
            if (incrementAndGet == this.m_max_job_id - 1) {
                util.perr(4, "max_job_id", true);
                this.m_auto_job_id = null;
            }
            return super.schedule(context, i);
        }

        public Runnable schedule_internal(Context context, int i) {
            int i2 = this.m_job_id;
            int unused = util.zerr(5, String.format("scheduling job %s after %sms", new Object[]{Integer.valueOf(i2), Integer.valueOf(i)}));
            svc_job.schedule_job(context, this.m_task_id, i2, i);
            return new k1(this, context, i2);
        }
    }

    public static class keepalive {
        public String m_action;
        public Runnable m_cancel;
        public int m_count = 0;
        public int m_count_modifier;
        public int m_delay;
        public long m_heartbeat_last;
        public conf.key m_key;
        public int m_period;
        public int m_request_code;
        public boolean m_schedule_supported = true;
        public Boolean m_stopped = false;
        public String m_target;
        public Timer m_timer;

        public keepalive() {
        }

        public keepalive(String str, String str2, int i, conf.key key) {
            this.m_target = str;
            this.m_action = str2;
            this.m_request_code = i;
            this.m_key = key;
        }

        /* access modifiers changed from: private */
        public void run(final Context context) {
            handle_heartbeat(context);
            this.m_count += this.m_count_modifier;
            if (this.m_schedule_supported) {
                this.m_cancel = schedule(context, this.m_period + this.m_delay);
            }
            Timer timer = new Timer();
            this.m_timer = timer;
            timer.schedule(new TimerTask() {
                /* JADX WARNING: Code restructure failed: missing block: B:11:0x002d, code lost:
                    io.lum.sdk.util.keepalive.access$2300(r3.this$0, r5);
                 */
                /* JADX WARNING: Code restructure failed: missing block: B:12:0x0034, code lost:
                    return;
                 */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public void run() {
                    /*
                        r3 = this;
                        io.lum.sdk.util$keepalive r0 = io.lum.sdk.util.keepalive.this
                        java.lang.Boolean r0 = r0.m_stopped
                        monitor-enter(r0)
                        io.lum.sdk.util$keepalive r1 = io.lum.sdk.util.keepalive.this     // Catch:{ all -> 0x0035 }
                        java.lang.Boolean r1 = r1.m_stopped     // Catch:{ all -> 0x0035 }
                        boolean r1 = r1.booleanValue()     // Catch:{ all -> 0x0035 }
                        if (r1 == 0) goto L_0x0015
                        monitor-exit(r0)     // Catch:{ all -> 0x0035 }
                        return
                    L_0x0015:
                        io.lum.sdk.util$keepalive r1 = io.lum.sdk.util.keepalive.this     // Catch:{ all -> 0x0035 }
                        java.lang.Runnable r1 = r1.m_cancel     // Catch:{ all -> 0x0035 }
                        if (r1 == 0) goto L_0x002c
                        io.lum.sdk.util$keepalive r1 = io.lum.sdk.util.keepalive.this     // Catch:{ all -> 0x0035 }
                        java.lang.Runnable r1 = r1.m_cancel     // Catch:{ all -> 0x0035 }
                        r1.run()     // Catch:{ all -> 0x0035 }
                        io.lum.sdk.util$keepalive r1 = io.lum.sdk.util.keepalive.this     // Catch:{ all -> 0x0035 }
                        r2 = 0
                        java.lang.Runnable unused = r1.m_cancel = r2     // Catch:{ all -> 0x0035 }
                    L_0x002c:
                        monitor-exit(r0)     // Catch:{ all -> 0x0035 }
                        io.lum.sdk.util$keepalive r0 = io.lum.sdk.util.keepalive.this
                        android.content.Context r1 = r5
                        r0.run(r1)
                        return
                    L_0x0035:
                        r1 = move-exception
                        monitor-exit(r0)     // Catch:{ all -> 0x0035 }
                        throw r1
                    */
                    throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.keepalive.AnonymousClass1.run():void");
                }
            }, (long) this.m_period);
        }

        private void zerr(int i, String str) {
            StringBuilder a2 = a.a("lumsdk/keepalive/");
            a2.append(this.m_target);
            util._zerr(a2.toString(), i, str);
        }

        public /* synthetic */ void a(PendingIntent pendingIntent, AlarmManager alarmManager) {
            zerr(5, "canceling alarm");
            try {
                pendingIntent.cancel();
                alarmManager.cancel(pendingIntent);
            } catch (NullPointerException unused) {
            }
        }

        @SuppressLint({"DefaultLocale"})
        public void handle_heartbeat(Context context) {
            String str;
            String str2;
            String str3;
            StringBuilder sb;
            long currentTimeMillis = System.currentTimeMillis();
            if (this.m_count != 0) {
                this.m_heartbeat_last = currentTimeMillis;
                StringBuilder a2 = a.a("storing last heartbeat: ");
                a2.append(this.m_heartbeat_last);
                zerr(5, a2.toString());
                util.m_conf.set(this.m_key, this.m_heartbeat_last);
                int i = this.m_count;
                String str4 = null;
                if (i == 1) {
                    str4 = "5min";
                    str = "00_5min";
                } else if (i == 4) {
                    str4 = "20min";
                    str = "01_20min";
                } else if (i == 6) {
                    str4 = "30min";
                    str = "02_30min";
                } else if (i % 12 == 0) {
                    int i2 = i / 12;
                    String str5 = i2 + "h";
                    if (((i2 - 1) & i2) == 0) {
                        str4 = String.format("%s_%s", new Object[]{util.pad_number(i2 + 2, 2), str5});
                    }
                    str = str4;
                    str4 = str5;
                } else {
                    str = null;
                }
                if (str4 != null) {
                    zerr(5, a.a("is running for ", str4));
                    if (str != null) {
                        util.perr(this.m_target + "_heartbeat_" + str);
                    }
                }
            } else if (!util.is_first_run()) {
                long j = util.m_conf.get_long(this.m_key);
                long j2 = currentTimeMillis - j;
                zerr(5, String.format("is up after %sms", new Object[]{Long.valueOf(j2)}));
                if (j != 0 && j2 > 3600000) {
                    Integer valueOf = Integer.valueOf(String.valueOf(j2 / 3600000));
                    if (valueOf.intValue() > 24) {
                        sb = new StringBuilder();
                        sb.append(this.m_target);
                        str3 = "_up_after_1d";
                    } else if (valueOf.intValue() > 12) {
                        sb = new StringBuilder();
                        sb.append(this.m_target);
                        str3 = "_up_after_12h";
                    } else {
                        str2 = String.format("%s_up_after_%sh", new Object[]{this.m_target, util.pad_number(valueOf.intValue(), 2)});
                        zerr(5, String.format("prev: %s, diff: %s, duration: %s, id: %s", new Object[]{Long.valueOf(j), Long.valueOf(j2), valueOf, str2}));
                        util.perr(str2, "missed hours: " + valueOf);
                    }
                    sb.append(str3);
                    str2 = sb.toString();
                    zerr(5, String.format("prev: %s, diff: %s, duration: %s, id: %s", new Object[]{Long.valueOf(j), Long.valueOf(j2), valueOf, str2}));
                    util.perr(str2, "missed hours: " + valueOf);
                }
            }
        }

        public Runnable schedule(Context context, int i) {
            if (!this.m_schedule_supported) {
                return null;
            }
            try {
                return schedule_internal(context, i);
            } catch (Exception e2) {
                util.perr(3, a.a(new StringBuilder(), this.m_target, "_keepalive_fail"), e2.getMessage(), util.e2s(e2), true);
                this.m_schedule_supported = false;
                util.perr(3, "keepalive_not_supported", true);
                return null;
            }
        }

        public Runnable schedule_internal(Context context, int i) {
            zerr(5, String.format("schedule alarm after %sms", new Object[]{Integer.valueOf(i)}));
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            Intent intent = new Intent(context, bcast_recv.class);
            intent.setAction(this.m_action);
            PendingIntent broadcast = PendingIntent.getBroadcast(context, this.m_request_code, intent, 268435456);
            set_alarm(alarmManager, 0, System.currentTimeMillis() + ((long) i), broadcast);
            return new l1(this, broadcast, alarmManager);
        }

        @SuppressLint({"NewApi"})
        public void set_alarm(AlarmManager alarmManager, int i, long j, PendingIntent pendingIntent) {
            if (util.m_conf.get_bool(conf.REPEATING_ALARMS)) {
                alarmManager.setInexactRepeating(i, j, 3600000, pendingIntent);
            } else if (util.sdk_version() >= 23) {
                alarmManager.setAndAllowWhileIdle(i, j, pendingIntent);
            } else {
                alarmManager.set(i, j, pendingIntent);
            }
        }

        public void start(Context context, int i, int i2) {
            start(context, i, i2, true);
        }

        public void start(Context context, int i, int i2, boolean z) {
            this.m_period = i;
            this.m_count_modifier = (i / 5) / util.MS_MIN;
            this.m_delay = i2;
            this.m_schedule_supported = z;
            synchronized (this.m_stopped) {
                this.m_stopped = false;
            }
            run(context);
        }

        public void stop() {
            synchronized (this.m_stopped) {
                if (this.m_cancel != null) {
                    this.m_cancel.run();
                }
                this.m_stopped = true;
            }
        }
    }

    public static class mem_info {
        public long m_free;
        public boolean m_is_low_memory;
        public long m_max;
        public long m_total;
        public long m_used = (this.m_total - this.m_free);

        public mem_info(Context context) {
            System.gc();
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            ((ActivityManager) context.getSystemService(ActivityChooserModel.ATTRIBUTE_ACTIVITY)).getMemoryInfo(memoryInfo);
            Runtime runtime = Runtime.getRuntime();
            this.m_free = runtime.freeMemory() / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
            this.m_total = runtime.totalMemory() / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
            this.m_max = runtime.maxMemory() / PlaybackStateCompat.ACTION_SET_CAPTIONING_ENABLED;
            this.m_is_low_memory = memoryInfo.lowMemory;
        }

        public long get_free() {
            return this.m_free;
        }

        public long get_max() {
            return this.m_max;
        }

        public long get_total() {
            return this.m_total;
        }

        public long get_used() {
            return this.m_used;
        }

        public boolean is_low_memory() {
            return this.m_is_low_memory;
        }

        public String toString() {
            StringBuilder a2 = a.a("used= ");
            a2.append(this.m_used);
            a2.append(", total= ");
            a2.append(this.m_total);
            a2.append(", max= ");
            a2.append(this.m_max);
            a2.append(", oom=");
            a2.append(is_low_memory());
            return a2.toString();
        }
    }

    public static class perr_funnel {
        public String m_ns;

        public perr_funnel(String str) {
            this.m_ns = str;
        }

        public void send(String str) {
            send(str, "");
        }

        public void send(String str, String str2) {
            util.perr(5, String.format("lum_sdk_android_%s_%s", new Object[]{this.m_ns, str}), str2, "", perr_once.VER);
        }
    }

    public enum perr_once {
        VER,
        INSTALL,
        NONE
    }

    public static class proc_info_t {
        public int pid;
        public int uid;
    }

    public static class rc4_t {
        public byte[] S = new byte[256];
        public byte[] T = new byte[256];
        public int keylen;

        public rc4_t(byte[] bArr) {
            if (bArr.length < 1 || bArr.length > 256) {
                int unused = util.zerr(MediaRouter.GlobalMediaRouter.CallbackHandler.MSG_PROVIDER_CHANGED, "key must be between 1 and 256 bytes");
            }
            this.keylen = bArr.length;
            for (int i = 0; i < 256; i++) {
                this.S[i] = (byte) i;
                this.T[i] = bArr[i % this.keylen];
            }
            byte b2 = 0;
            for (int i2 = 0; i2 < 256; i2++) {
                byte[] bArr2 = this.S;
                b2 = (b2 + bArr2[i2] + this.T[i2]) & Base64.EQUALS_SIGN_ENC;
                bArr2[i2] = (byte) (bArr2[i2] ^ bArr2[b2]);
                bArr2[b2] = (byte) (bArr2[b2] ^ bArr2[i2]);
                bArr2[i2] = (byte) (bArr2[i2] ^ bArr2[b2]);
            }
        }

        public byte[] decrypt(byte[] bArr) {
            return encrypt(bArr);
        }

        public byte[] encrypt(String str) {
            return encrypt(util.str2bytes(str));
        }

        public byte[] encrypt(byte[] bArr) {
            byte[] bArr2 = new byte[bArr.length];
            int i = 0;
            byte b2 = 0;
            for (int i2 = 0; i2 < bArr.length; i2++) {
                i = (i + 1) & 255;
                byte[] bArr3 = this.S;
                b2 = (b2 + bArr3[i]) & Base64.EQUALS_SIGN_ENC;
                bArr3[i] = (byte) (bArr3[i] ^ bArr3[b2]);
                bArr3[b2] = (byte) (bArr3[b2] ^ bArr3[i]);
                bArr3[i] = (byte) (bArr3[i] ^ bArr3[b2]);
                bArr2[i2] = (byte) (bArr3[(bArr3[i] + bArr3[b2]) & 255] ^ bArr[i2]);
            }
            return bArr2;
        }
    }

    public interface scandir_cb_t {
        int cb(String str, String str2, String str3, Object obj);
    }

    public static class sdf_provider extends ThreadLocal<SimpleDateFormat> {
        public Locale m_locale;
        public String m_pattern;

        public sdf_provider(String str, Locale locale) {
            this.m_pattern = str;
            this.m_locale = locale;
        }

        public SimpleDateFormat initialValue() {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(this.m_pattern, this.m_locale);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            return simpleDateFormat;
        }
    }

    public static class thread_factory implements ThreadFactory {
        public int m_count = 0;
        public String m_name;

        public thread_factory(String str) {
            this.m_name = str;
        }

        public Thread newThread(Runnable runnable) {
            this.m_count++;
            return new Thread(runnable, this.m_name + "_" + this.m_count);
        }
    }

    public static abstract class with_feedback {
        public static final String BY_FEEDBACK = "feedback";
        public static volatile HashMap<String, Integer> m_feedback_retries = new HashMap<>();
        public static volatile HashMap<String, Timer> m_feedback_timers = new HashMap<>();
        public Context m_ctx;
        public boolean m_def_val;
        public long m_delay;
        public boolean m_fbk_val;
        public String m_name;
        public int m_retries;
        public boolean m_retries_exp;
        public Integer m_retries_max;

        public with_feedback(Context context, String str, long j) {
            this(context, str, false, false, j);
        }

        public with_feedback(Context context, String str, boolean z, boolean z2, long j) {
            this(context, str, z, z2, j, true);
        }

        public with_feedback(Context context, String str, boolean z, boolean z2, long j, boolean z3) {
            this(context, str, z, z2, j, z3, 10);
        }

        public with_feedback(Context context, String str, boolean z, boolean z2, long j, boolean z3, Integer num) {
            this.m_name = str;
            this.m_def_val = z;
            this.m_fbk_val = z2;
            this.m_delay = j;
            this.m_retries_max = num;
            this.m_retries_exp = z3;
            this.m_ctx = context;
            run("main");
        }

        /* access modifiers changed from: private */
        public void handle_exception(String str, Exception exc) {
            String format = String.format("error: %s, %s", new Object[]{exc.getMessage(), get_details()});
            StringBuilder b2 = a.b(str, "_");
            b2.append(this.m_name);
            util.perr(5, b2.toString(), format, util.e2s(exc), true);
        }

        private void prepare(String str) {
            Timer timer;
            if (!m_feedback_retries.containsKey(this.m_name)) {
                this.m_retries = 0;
            } else {
                this.m_retries = m_feedback_retries.get(this.m_name).intValue();
                if (BY_FEEDBACK.equals(str)) {
                    this.m_retries++;
                }
            }
            m_feedback_retries.put(this.m_name, Integer.valueOf(this.m_retries));
            if (m_feedback_timers.containsKey(this.m_name) && (timer = m_feedback_timers.get(this.m_name)) != null) {
                int unused = util.zerr(7, String.format("canceling previous %s check", new Object[]{this.m_name}));
                timer.cancel();
                m_feedback_timers.remove(this.m_name);
            }
        }

        /* access modifiers changed from: private */
        public void run(String str) {
            synchronized (m_feedback_timers) {
                prepare(str);
                boolean run_check = run_check();
                run_next(run_check, str);
                set_retry(run_check);
            }
        }

        private boolean run_check() {
            boolean z = this.m_def_val;
            try {
                return check();
            } catch (Exception e2) {
                handle_exception("feedback_check_fail", e2);
                return z;
            }
        }

        private void run_next(boolean z, String str) {
            if (BY_FEEDBACK.equals(str)) {
                if (z != this.m_fbk_val) {
                    int unused = util.zerr(5, String.format("feedback success: %s (%s)", new Object[]{this.m_name, get_details()}));
                } else {
                    return;
                }
            }
            try {
                next(z);
            } catch (Exception e2) {
                handle_exception("feedback_next_fail", e2);
            }
        }

        private void set_retry(boolean z) {
            if (z != this.m_fbk_val) {
                m_feedback_retries.put(this.m_name, 0);
                return;
            }
            try {
                if (util.get_mem_info(this.m_ctx).is_low_memory()) {
                    int unused = util.zerr(5, "skipping retry due to low memory");
                } else if (this.m_retries_max == null || this.m_retries + 1 <= this.m_retries_max.intValue()) {
                    Timer timer = new Timer();
                    int unused2 = util.zerr(7, String.format("scheduling %s check after %sms", new Object[]{this.m_name, Long.valueOf(this.m_delay)}));
                    timer.schedule(new TimerTask() {
                        public void run() {
                            try {
                                with_feedback.this.run(with_feedback.BY_FEEDBACK);
                            } catch (Exception e2) {
                                with_feedback.this.handle_exception("feedback_retry_fail", e2);
                            }
                        }
                    }, this.m_delay);
                    m_feedback_timers.put(this.m_name, timer);
                    if (this.m_retries_exp) {
                        this.m_delay *= 2;
                    }
                } else {
                    on_max_retries();
                }
            } catch (Exception e2) {
                handle_exception("feedback_retry_set_fail", e2);
            }
        }

        public abstract boolean check();

        public String get_details() {
            return String.format("retries: %s, last delay: %s", new Object[]{Integer.valueOf(this.m_retries), Long.valueOf(this.m_delay)});
        }

        public abstract void next(boolean z);

        public void on_max_retries() {
            int unused = util.zerr(4, String.format("feedback_retries_exceeded: %s (%s)", new Object[]{this.m_name, get_details()}));
        }
    }

    public static class zerr {
        public String m_tag;

        public zerr(String str) {
            str = str == null ? "" : str;
            this.m_tag = str;
            if (!str.startsWith("lumsdk/")) {
                StringBuilder a2 = a.a("lumsdk/");
                a2.append(this.m_tag);
                this.m_tag = a2.toString();
            }
        }

        public void debug(String str) {
            util._zerr(this.m_tag, util.is_test_app((String) null) && !util.is_release() ? 5 : 7, str);
        }

        public void err(String str) {
            util._zerr(this.m_tag, 3, str);
        }

        public void err(Throwable th) {
            util._zerr(this.m_tag, 3, util.e2s(th));
        }

        public void notice(String str) {
            util._zerr(this.m_tag, 5, str);
        }

        public String tag() {
            return this.m_tag;
        }
    }

    public static void _perr_p(int i, String str, String str2, String str3, perr_once perr_once2) {
        if (m_perr.is_enabled()) {
            perr(i, str, str2, str3, perr_once2);
            return;
        }
        if (!str.startsWith("lum_sdk_android") && !str.startsWith("vpn_api")) {
            str = a.a("lum_sdk_android_", str);
        }
        zerr(i, "perr " + str + " " + str2 + "\n" + str3);
        perr_p_file(perr_p_filename(str, perr_once2), perr_p_file_str(m_conf == null ? null : m_conf.get_str(conf.CID_VALUE), str, str2, str3), !perr_once2.equals(perr_once.NONE));
        perr_p_try();
    }

    public static int _zerr(String str, int i, String str2) {
        if (!zerr_check(i)) {
            return -1;
        }
        if (is_test_app((String) null)) {
            zerr2log(str, i, str2);
        }
        String str3 = date_now2sql() + " " + str + " " + zerr_level2severity_str(i) + ": " + str2;
        zerr_printf(str3 + "\n");
        synchronized (m_logs) {
            if (m_logs.size() >= 50) {
                m_logs.remove(0);
            }
            m_logs.add(str3.trim());
        }
        if ((zerr_get_flags(i) & 512) == 0) {
            return -1;
        }
        throw new RuntimeException("zexit " + str + " " + str2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0093  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00af  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ int a(java.lang.String r11, java.lang.String r12, java.lang.String r13, java.lang.Object r14) {
        /*
            java.lang.String r14 = ".sending"
            boolean r14 = r12.endsWith(r14)
            r0 = 0
            if (r14 == 0) goto L_0x000d
            file_unlink((java.lang.String) r13)
            return r0
        L_0x000d:
            java.lang.Boolean r14 = m_is_online
            boolean r14 = r14.booleanValue()
            if (r14 != 0) goto L_0x0017
            r11 = -1
            return r11
        L_0x0017:
            java.util.regex.Pattern r14 = perr_file_rx
            java.util.regex.Matcher r12 = r14.matcher(r12)
            boolean r14 = r12.matches()
            if (r14 != 0) goto L_0x0024
            return r0
        L_0x0024:
            r14 = 3
            java.lang.String r1 = r12.group(r14)
            r2 = 4
            java.lang.String r4 = r12.group(r2)
            r2 = 2
            java.lang.String r9 = r12.group(r2)
            if (r1 != 0) goto L_0x003e
            io.lum.sdk.util$perr_once r12 = io.lum.sdk.util.perr_once.NONE
            java.lang.String r1 = "_"
            java.lang.String r1 = b.a.a.a.a.a((java.lang.String) r9, (java.lang.String) r1, (java.lang.String) r4)
            goto L_0x0051
        L_0x003e:
            java.lang.String r12 = "once"
            boolean r12 = r1.equals(r12)
            if (r12 == 0) goto L_0x004b
            io.lum.sdk.util$perr_once r12 = io.lum.sdk.util.perr_once.INSTALL
            r7 = r12
            r1 = r4
            goto L_0x0052
        L_0x004b:
            io.lum.sdk.util$perr_once r12 = io.lum.sdk.util.perr_once.VER
            java.lang.String r1 = b.a.a.a.a.a((java.lang.String) r4, (java.lang.String) r1)
        L_0x0051:
            r7 = r12
        L_0x0052:
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            r12.append(r11)
            java.lang.String r11 = "/"
            r12.append(r11)
            r12.append(r1)
            java.lang.String r11 = ".sent"
            r12.append(r11)
            java.lang.String r11 = r12.toString()
            byte[] r12 = file_read(r13)
            boolean r1 = file_exists(r11)
            java.lang.String r12 = byte2str(r12)
            java.lang.String r3 = m_perr_p_rx_fmt
            r5 = 1
            java.lang.Object[] r6 = new java.lang.Object[r5]
            r6[r0] = r4
            java.lang.String r3 = java.lang.String.format(r3, r6)
            r6 = 9
            java.util.regex.Pattern r3 = java.util.regex.Pattern.compile(r3, r6)
            java.util.regex.Matcher r12 = r3.matcher(r12)
            boolean r3 = r12.lookingAt()
            r6 = 0
            if (r3 == 0) goto L_0x00a3
            java.lang.String r3 = r12.group(r5)
            java.lang.String r2 = r12.group(r2)
            java.lang.String r12 = r12.group(r14)
            r6 = r12
            r8 = r2
            r5 = r3
            goto L_0x00a5
        L_0x00a3:
            r5 = r6
            r8 = r5
        L_0x00a5:
            r3 = 5
            r10 = r1
            perr(r3, r4, r5, r6, r7, r8, r9, r10)
            file_unlink((java.lang.String) r13)
            if (r1 == 0) goto L_0x00b2
            file_unlink((java.lang.String) r11)
        L_0x00b2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.a(java.lang.String, java.lang.String, java.lang.String, java.lang.Object):int");
    }

    public static /* synthetic */ void a(perr.on_finish on_finish, String str, perr.msg msg, String str2, String str3, String str4, String str5, int i) {
        on_finish.run(i == 0);
        if (i < 0) {
            zerr(3, "perr_send_failed " + str);
            if (!m_perr.is_enabled()) {
                _perr_p(msg.m_level, msg.m_errid, str2, str3, msg.m_once);
            }
            if (m_is_online.booleanValue()) {
                update_sdk_info();
            }
        }
        if (msg.m_once != perr_once.NONE && !m_perr.is_enabled()) {
            file_unlink(str4);
            if (i == 0) {
                file_write(str5, "");
            }
        }
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x002c */
    /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x007a */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0039  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(java.lang.String r5) {
        /*
            java.lang.Object r0 = m_zerr_lock
            monitor-enter(r0)
            int r1 = m_ref     // Catch:{ all -> 0x007c }
            if (r1 != 0) goto L_0x001c
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x007c }
            r1.<init>()     // Catch:{ all -> 0x007c }
            java.lang.String r2 = m_membuf     // Catch:{ all -> 0x007c }
            r1.append(r2)     // Catch:{ all -> 0x007c }
            r1.append(r5)     // Catch:{ all -> 0x007c }
            java.lang.String r5 = r1.toString()     // Catch:{ all -> 0x007c }
            m_membuf = r5     // Catch:{ all -> 0x007c }
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            return
        L_0x001c:
            java.io.FileWriter r1 = m_zerr_filewriter     // Catch:{ all -> 0x007c }
            if (r1 != 0) goto L_0x0022
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            return
        L_0x0022:
            java.io.FileWriter r1 = m_zerr_filewriter     // Catch:{ IOException -> 0x002c }
            r1.write(r5)     // Catch:{ IOException -> 0x002c }
            java.io.FileWriter r5 = m_zerr_filewriter     // Catch:{ IOException -> 0x002c }
            r5.flush()     // Catch:{ IOException -> 0x002c }
        L_0x002c:
            java.io.File r5 = m_zerr_file     // Catch:{ all -> 0x007c }
            long r1 = r5.length()     // Catch:{ all -> 0x007c }
            r3 = 2097152(0x200000, double:1.0361308E-317)
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 < 0) goto L_0x007a
            zerr_uninit()     // Catch:{ all -> 0x007c }
            java.lang.String r5 = m_path     // Catch:{ all -> 0x007c }
            if (r5 == 0) goto L_0x006b
            java.lang.String r5 = m_path     // Catch:{ all -> 0x007c }
            boolean r5 = file_exists(r5)     // Catch:{ all -> 0x007c }
            if (r5 == 0) goto L_0x006b
            java.io.File r5 = m_zerr_file     // Catch:{ all -> 0x007c }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x007c }
            r1.<init>()     // Catch:{ all -> 0x007c }
            java.lang.String r2 = m_path     // Catch:{ all -> 0x007c }
            r1.append(r2)     // Catch:{ all -> 0x007c }
            java.lang.String r2 = "/lum_sdk_"
            r1.append(r2)     // Catch:{ all -> 0x007c }
            java.lang.String r2 = m_app_name     // Catch:{ all -> 0x007c }
            r1.append(r2)     // Catch:{ all -> 0x007c }
            java.lang.String r2 = ".log.1"
            r1.append(r2)     // Catch:{ all -> 0x007c }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x007c }
            file_move((java.io.File) r5, (java.lang.String) r1)     // Catch:{ all -> 0x007c }
            goto L_0x0070
        L_0x006b:
            java.io.File r5 = m_zerr_file     // Catch:{ all -> 0x007c }
            file_unlink((java.io.File) r5)     // Catch:{ all -> 0x007c }
        L_0x0070:
            java.io.FileWriter r5 = new java.io.FileWriter     // Catch:{ IOException -> 0x007a }
            java.io.File r1 = m_zerr_file     // Catch:{ IOException -> 0x007a }
            r2 = 1
            r5.<init>(r1, r2)     // Catch:{ IOException -> 0x007a }
            m_zerr_filewriter = r5     // Catch:{ IOException -> 0x007a }
        L_0x007a:
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            return
        L_0x007c:
            r5 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.a(java.lang.String):void");
    }

    public static /* synthetic */ void a(JSONObject jSONObject, int i, Runnable runnable, String str, String str2) {
        thread_list.put(thread_id, jSONObject);
        if (thread_list.size() > 20 && !perr_memleak_thread_sent) {
            perr_memleak_thread_sent = true;
            perr("memleak_thread", jSONObject.toString());
        }
        if (i > 0) {
            try {
                if (!exec_with_timeout(runnable, str, i)) {
                    if (!is_perr(str, str2)) {
                        perr("thread_timeout", jSONObject.toString());
                    }
                    zerr(3, "thread " + str + "(" + str2 + ") expired after " + i + "ms");
                    thread_list.remove(thread_id);
                    return;
                }
            } catch (Exception e2) {
                zerr(3, "thread " + str + "(" + str2 + ") terminated: " + e2s(e2));
            } catch (Throwable th) {
                thread_list.remove(thread_id);
                throw th;
            }
        } else {
            runnable.run();
        }
        zerr(7, "thread " + str + "(" + str2 + ") finished");
        thread_list.remove(thread_id);
    }

    public static /* synthetic */ int access$1204() {
        int i = m_http_send_proxy_retries + 1;
        m_http_send_proxy_retries = i;
        return i;
    }

    public static void add_sdk_state_file(String str, String str2) {
        if (!is_sdk_state_restricted()) {
            try {
                JSONObject jSONObject = new JSONObject(m_conf.get_str(conf.SDK_STATE_FILES, "{}"));
                if (!jSONObject.optString(str, "").equals(str2)) {
                    zerr(5, "adding file: " + str2);
                    m_conf.set(conf.SDK_STATE_FILES, jSONObject.put(str, str2));
                    zerr(5, "files: " + m_conf.get_str(conf.SDK_STATE_FILES));
                }
            } catch (JSONException e2) {
                StringBuilder a2 = a.a("add state file failed: ");
                a2.append(e2s(e2));
                zerr(3, a2.toString());
            }
        }
    }

    public static Boolean apk_exist(Context context, String str) {
        try {
            context.getPackageManager().getApplicationInfo(str, 0);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        } catch (Exception e2) {
            perr(3, "apk_exist_fail", str, e2s(e2), true);
            return null;
        }
    }

    public static int atoi(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException unused) {
            return 0;
        }
    }

    public static /* synthetic */ int b(String str, String str2, String str3, Object obj) {
        if (!str2.matches(".*perr_.+\\.log$")) {
            return 0;
        }
        file_move(str3, m_path + "/" + str2);
        return 0;
    }

    public static void bcast_client_clear(String str) {
        bcast_client_send("clear", str, (String) null, (String) null, (String) null);
    }

    public static void bcast_client_del(String str, String str2) {
        bcast_client_send("del", str, str2, (String) null, (String) null);
    }

    public static void bcast_client_send(String str, String str2, String str3, String str4, String str5) {
        Bundle bundle = new Bundle();
        bundle.putString("action", str);
        bundle.putString("name", str2);
        bundle.putString("key", str3);
        if (str4 != null) {
            bundle.putString("value", str4);
        }
        if (str5 != null) {
            bundle.putString("type", str5);
        }
        m_bcast_client.send_request(bundle, false);
    }

    public static void bcast_client_set(String str, String str2, String str3, String str4) {
        bcast_client_send("set", str, str2, str3, str4);
    }

    public static void bcast_client_svc_action(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("action", str);
        bundle.putString("after", str2);
        m_bcast_client.send_request(bundle, false);
    }

    public static void bcast_handler_notify(String str, String str2, String str3, String str4) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString("action", "set");
            bundle.putString("name", str);
            bundle.putString("key", str2);
            bundle.putString("value", str3);
            bundle.putString("type", str4);
            m_bcast_handler.send_notification(bundle);
        } catch (NullPointerException unused) {
        }
    }

    public static void bcast_handler_notify_bw(String str, int i, int i2) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString("action", "bw_update");
            bundle.putString("type", str);
            bundle.putInt("dn", i);
            bundle.putInt("up", i2);
            m_bcast_handler.send_bw_notification(bundle);
        } catch (NullPointerException unused) {
        }
    }

    public static String bt_get() {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement append : Thread.currentThread().getStackTrace()) {
            sb.append(append);
            sb.append("\n");
        }
        return sb.toString();
    }

    public static String byte2str(byte[] bArr) {
        try {
            return new String(bArr, Charset.forName("UTF-8"));
        } catch (Exception e2) {
            StringBuilder a2 = a.a("cant convert byte2str ");
            a2.append(e2.toString());
            zerr(3, a2.toString());
            return null;
        }
    }

    public static String bytes2hex(byte[] bArr) {
        if (bArr == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int length = bArr.length;
        for (int i = 0; i < length; i++) {
            sb.append(String.format("%02X ", new Object[]{Byte.valueOf(bArr[i])}));
        }
        return sb.toString();
    }

    public static String ccgi_host() {
        return "clientsdk.lum-sdk.io";
    }

    public static void check_mem_usage(Context context, final String str, long j) {
        mem_info mem_info2 = get_mem_info(context);
        zerr(5, mem_info2.toString());
        if (mem_info2.is_low_memory()) {
            perr(3, "low_memory_" + str, true);
        }
        final long j2 = mem_info2.get_used();
        if (j2 > j) {
            thread_run(new Runnable() {
                public void run() {
                    synchronized (util.m_oom_dump_lock) {
                        if (!util.m_oom_dump_written.booleanValue()) {
                            util.perr(3, "mem_usage_exceeded", "Memory usage: " + j2 + "MB", "", true);
                            try {
                                Debug.dumpHprofData(util.m_cachedir + "/log/dump_oom_" + str + ".hprof");
                                Boolean unused = util.m_oom_dump_written = true;
                            } catch (IOException e2) {
                                int unused2 = util.zerr(3, "oom dump failed: " + e2.getMessage());
                                util.perr(3, "oom_dump_failed", e2.toString(), "", true);
                            }
                        }
                    }
                }
            }, "heap_dump");
        }
    }

    public static String cmd2url(String str) {
        return a.a("http://127.0.0.1:6880/", str);
    }

    public static void create_actions(String str) {
        if (ACTION_SVC_KEEPALIVE == null) {
            ACTION_SVC_KEEPALIVE = a.a(str, ".svc_keepalive");
        }
        if (ACTION_NET_SVC_KEEPALIVE == null) {
            ACTION_NET_SVC_KEEPALIVE = a.a(str, ".net_svc_keepalive");
        }
        if (ACTION_DISPLAY_CHANGE == null) {
            ACTION_DISPLAY_CHANGE = a.a(str, ".display_change");
        }
    }

    public static void create_bcast_handler(final Context context, String str) {
        if (m_bcast_handler == null) {
            synchronized (m_bcast_handler_lock) {
                m_cloud_config = new cloud_config();
                create_svc_client(context);
                final ArrayList arrayList = new ArrayList();
                arrayList.add(conf.SDK_STATE_INFO);
                arrayList.add(conf.SDK_STATE_STATUS);
                m_conf.register_listener(new conf.listener() {
                    public void on_changed(conf.key key) {
                        String str;
                        if (key == conf.CHOICE) {
                            int load_choice = util.load_choice(util.m_conf);
                            int unused = util.zerr(5, "choice: " + load_choice);
                            if (load_choice == 1) {
                                util.start_svc_client("choice");
                            } else {
                                util.stop_svc_client("choice");
                            }
                        } else {
                            if (key == conf.DBG_MOBILE) {
                                str = "reconfig_mobile";
                            } else if (key == conf.WS_PING_PROXYJS || key == conf.WS_PING_ZAGENT) {
                                str = "reconfig_ws_ping";
                            } else if (key == conf.SPROXY_SSL) {
                                util.m_conf.del(conf.CACHE_SPROXY_HOST);
                                util.m_conf.del(conf.CACHE_SPROXY_PORT);
                                util.create_sdk_proxy_pool();
                                return;
                            } else if (key == conf.DBG_FORCE_PROXY || key == conf.WS_CONN_PROXYJS_SPROXY) {
                                str = "reconfig_proxyjs_zagents";
                            } else if (key == conf.IS_DEBUG) {
                                util.perr(5, "debug", true);
                                return;
                            } else if (arrayList.contains(key) && !util.is_sdk_state_restricted()) {
                                api.state state = util.get_sdk_state(context, false);
                                try {
                                    int unused2 = util.file_write(util.get_sdk_state_filename(context), new JSONObject().put("status", state.status).put("info", state.info).toString());
                                    return;
                                } catch (JSONException unused3) {
                                    return;
                                }
                            } else {
                                return;
                            }
                            util.restart_svc_thread(str);
                        }
                    }
                });
                perr_funnel_main_send("10_svc_thread_create_success");
                zerr(5, String.format("creating bcast/handler for %s (%s)", new Object[]{m_app_name, Thread.currentThread().getName()}));
                m_bcast_handler = new bcast_handler(context, str);
                perr_funnel_main_send("15_bcast_handler_create_success");
                run_version_tasks();
            }
        }
    }

    @SuppressLint({"NewApi"})
    public static void create_notification_channel(Context context) {
        if (sdk_version() >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "Luminati SDK", 2);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(-16776961);
            get_notification_manager(context).createNotificationChannel(notificationChannel);
        }
    }

    public static void create_sdk_proxy_pool() {
        m_sdk_proxy_pool = sdk_proxy_pool.get_instance(m_conf.get_bool(conf.SPROXY_SSL, true));
    }

    public static void create_svc_client(Context context) {
        if (m_svc_client == null) {
            try {
                m_svc_client = new svc_client(context);
            } catch (Exception e2) {
                perr(3, "svc_client_create_exception", e2.getMessage(), e2s(e2), true);
            }
        }
    }

    public static String date_now2sql() {
        return m_sdf_sql.get().format(new Date());
    }

    public static String date_now2ts() {
        try {
            return m_sdf_ts.get().format(new Date());
        } catch (Exception unused) {
            return null;
        }
    }

    public static String date_ts2sql(String str) {
        try {
            return m_sdf_sql.get().format(m_sdf_ts.get().parse(str));
        } catch (Exception unused) {
            return null;
        }
    }

    public static String decrypt(String str) {
        String str2;
        int indexOf = str.indexOf("=");
        int length = str.length();
        if (indexOf == -1) {
            StringBuilder sb = new StringBuilder();
            int i = length - 3;
            sb.append(str.substring(i));
            sb.append(str.substring(0, i));
            str2 = sb.toString();
        } else {
            StringBuilder sb2 = new StringBuilder();
            int i2 = indexOf - 3;
            sb2.append(str.substring(i2, indexOf));
            sb2.append(str.substring(0, i2));
            sb2.append(str.substring(indexOf, length));
            str2 = sb2.toString();
        }
        return new String(Base64.decode(str2), "UTF-8");
    }

    public static void destroy_bcast_handler() {
        try {
            m_cloud_config.destroy();
        } catch (Exception unused) {
        }
        stop_svc_thread("destroy_bcast_handler");
        m_svc_client = null;
        if (m_bcast_handler != null) {
            m_bcast_handler.destroy();
        }
        m_bcast_handler = null;
    }

    public static void destroy_svc_job_keepalive() {
        synchronized (m_keepalive_lock) {
            if (m_job_keepalive != null) {
                m_job_keepalive.stop();
                m_job_keepalive = null;
            }
        }
    }

    public static long dir_size(File file) {
        long j = 0;
        if (!file.exists()) {
            return 0;
        }
        File[] listFiles = file.listFiles();
        int i = 0;
        while (listFiles != null && i < listFiles.length) {
            if (!file_is_symlink(listFiles[i])) {
                j = (listFiles[i].isDirectory() ? dir_size(listFiles[i]) : listFiles[i].length()) + j;
            }
            i++;
        }
        return j;
    }

    public static long dir_size(String str) {
        return dir_size(new File(str));
    }

    public static int dp_to_px(Context context, int i) {
        return (int) ((((float) i) * context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static String e2s(Throwable th) {
        if (th == null) {
            return "";
        }
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        return stringWriter.toString();
    }

    public static String encrypt(String str) {
        String encode = Base64.encode(str.getBytes("UTF-8"));
        if (!encode.endsWith("=")) {
            return encode.substring(3) + encode.substring(0, 3);
        }
        int indexOf = encode.indexOf("=");
        return encode.substring(3, indexOf) + encode.substring(0, 3) + encode.substring(indexOf);
    }

    public static String escape_sh(String str) {
        if (str == null) {
            return "";
        }
        if (str.matches("^[a-z0-9_\\-\\./:]+$")) {
            return str;
        }
        StringBuilder a2 = a.a("\"");
        a2.append(str.replaceAll("([\\\"`$])", "\\\\$1"));
        a2.append("\"");
        return a2.toString();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:8|9|10|(1:12)|13) */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0031, code lost:
        r12 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0080, code lost:
        if (thread_executors.containsKey(r13) == false) goto L_0x0082;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0082, code lost:
        r2.shutdownNow();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0086, code lost:
        throw r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0021, code lost:
        r12 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:?, code lost:
        r12.cancel(true);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0023 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean exec_with_timeout(java.lang.Runnable r12, java.lang.String r13, int r14) {
        /*
            long r0 = java.lang.System.currentTimeMillis()
            java.util.concurrent.ExecutorService r2 = get_thread_executor(r13)
            java.util.concurrent.Future r12 = r2.submit(r12)
            long r3 = (long) r14
            r14 = 0
            r5 = 1
            java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ TimeoutException -> 0x0023 }
            r12.get(r3, r6)     // Catch:{ TimeoutException -> 0x0023 }
            java.util.HashMap<java.lang.String, java.util.concurrent.ExecutorService> r12 = thread_executors
            boolean r12 = r12.containsKey(r13)
            if (r12 != 0) goto L_0x001f
            r2.shutdownNow()
        L_0x001f:
            r12 = 1
            goto L_0x0032
        L_0x0021:
            r12 = move-exception
            goto L_0x007a
        L_0x0023:
            r12.cancel(r5)     // Catch:{ all -> 0x0021 }
            java.util.HashMap<java.lang.String, java.util.concurrent.ExecutorService> r12 = thread_executors
            boolean r12 = r12.containsKey(r13)
            if (r12 != 0) goto L_0x0031
            r2.shutdownNow()
        L_0x0031:
            r12 = 0
        L_0x0032:
            long r2 = java.lang.System.currentTimeMillis()
            long r2 = r2 - r0
            r0 = 2
            java.lang.Object[] r1 = new java.lang.Object[r0]
            r1[r14] = r13
            java.lang.Long r4 = java.lang.Long.valueOf(r2)
            r1[r5] = r4
            java.lang.String r4 = "%s executed in %sms"
            java.lang.String r1 = java.lang.String.format(r4, r1)
            r4 = 5
            zerr(r4, r1)
            r1 = 7
            int[] r6 = new int[r1]
            r6 = {50, 100, 250, 500, 1000, 1500, 2000} // fill-array
            r7 = 0
        L_0x0053:
            if (r7 >= r1) goto L_0x0079
            r8 = r6[r7]
            long r9 = (long) r8
            int r11 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            if (r11 >= 0) goto L_0x0076
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r0[r14] = r13
            java.lang.Integer r13 = java.lang.Integer.valueOf(r8)
            r0[r5] = r13
            java.lang.String r13 = "%s_exec_elapsed_%s"
            java.lang.String r13 = java.lang.String.format(r13, r0)
            java.lang.String r14 = ""
            java.lang.String r0 = b.a.a.a.a.a((java.lang.String) r14, (long) r2)
            perr((int) r4, (java.lang.String) r13, (java.lang.String) r0, (java.lang.String) r14, (boolean) r5)
            goto L_0x0079
        L_0x0076:
            int r7 = r7 + 1
            goto L_0x0053
        L_0x0079:
            return r12
        L_0x007a:
            java.util.HashMap<java.lang.String, java.util.concurrent.ExecutorService> r14 = thread_executors
            boolean r13 = r14.containsKey(r13)
            if (r13 != 0) goto L_0x0085
            r2.shutdownNow()
        L_0x0085:
            goto L_0x0087
        L_0x0086:
            throw r12
        L_0x0087:
            goto L_0x0086
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.exec_with_timeout(java.lang.Runnable, java.lang.String, int):boolean");
    }

    public static int file_copy(File file, File file2) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr, 0, 1024);
                if (read > 0) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileOutputStream.close();
                    fileInputStream.close();
                    return 0;
                }
            }
        } catch (Exception unused) {
            return -1;
        }
    }

    public static int file_copy(String str, String str2) {
        return file_copy(new File(str), new File(str2));
    }

    public static boolean file_exists(String str) {
        return new File(str).exists();
    }

    public static boolean file_exists(String str, String str2) {
        try {
            File file = new File(str);
            if (!file.exists()) {
                return false;
            }
            File[] listFiles = file.listFiles();
            int length = listFiles.length;
            int i = 0;
            while (i < length) {
                try {
                    if (Pattern.matches(str2, listFiles[i].getName())) {
                        return true;
                    }
                    i++;
                } catch (NullPointerException unused) {
                }
            }
            return false;
        } catch (NullPointerException unused2) {
        }
    }

    public static boolean file_is_exec(String str) {
        return new File(str).canExecute();
    }

    public static boolean file_is_symlink(File file) {
        try {
            if (file.getParent() != null) {
                file = new File(file.getParentFile().getCanonicalFile(), file.getName());
            }
            return !file.getCanonicalFile().equals(file.getAbsoluteFile());
        } catch (IOException unused) {
            return false;
        }
    }

    public static boolean file_is_symlink(String str) {
        return file_is_symlink(new File(str));
    }

    public static Object file_load_object(String str) {
        Object obj = null;
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(str));
            obj = objectInputStream.readObject();
            objectInputStream.close();
        } catch (Exception e2) {
            zerr(3, "file_load_object Exception: " + e2);
        }
        zerr(7, "file_load_object " + str + ": " + obj);
        return obj;
    }

    public static int file_move(File file, File file2) {
        return (file_copy(file, file2) < 0 || file_unlink(file) < 0) ? -1 : 0;
    }

    public static int file_move(File file, String str) {
        return file_move(file, new File(str));
    }

    public static int file_move(String str, String str2) {
        return file_move(new File(str), new File(str2));
    }

    public static byte[] file_read(String str) {
        String str2;
        byte[] bArr;
        String str3;
        StringBuilder sb;
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(str, "r");
            try {
                long length = randomAccessFile.length();
                bArr = new byte[((int) Math.min(length, 65536))];
                if (length > 65536) {
                    zerr(3, "file to bigger than 65536");
                }
                try {
                    randomAccessFile.readFully(bArr);
                } catch (UnsupportedEncodingException e2) {
                    sb = a.a("file_read failed ");
                    str3 = e2.toString();
                } catch (IOException e3) {
                    sb = a.a("file_read failed ");
                    str3 = e3.toString();
                }
                sb.append(str3);
                zerr(3, sb.toString());
                randomAccessFile.close();
                return bArr;
            } catch (IOException e4) {
                str2 = "failed getting length of " + str + " " + e4.toString();
                zerr(3, str2);
                return null;
            }
            try {
                randomAccessFile.close();
                return bArr;
            } catch (IOException unused) {
                str2 = a.a("file_read failed closing ", str);
                zerr(3, str2);
                return null;
            }
        } catch (IOException unused2) {
            return null;
        }
    }

    public static String file_read_line(String str) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(str));
            String readLine = bufferedReader.readLine();
            bufferedReader.close();
            return readLine;
        } catch (Exception unused) {
            return null;
        }
    }

    public static boolean file_rm(String str) {
        return new File(str).delete();
    }

    public static void file_save_object(String str, Object obj) {
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(str));
            objectOutputStream.writeObject(obj);
            objectOutputStream.flush();
            objectOutputStream.close();
        } catch (IOException e2) {
            zerr(3, "file_save_object Exception: " + e2);
        }
        zerr(7, String.format("file_save_object %s: %s", new Object[]{str, obj}));
    }

    public static long file_size(String str) {
        return new File(str).length();
    }

    public static int file_unlink(File file) {
        return file.delete() ? 0 : -1;
    }

    public static int file_unlink(String str) {
        return file_unlink(new File(str));
    }

    public static int file_write(String str, InputStream inputStream) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(str);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr, 0, 1024);
                if (read > 0) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileOutputStream.close();
                    inputStream.close();
                    return 0;
                }
            }
        } catch (IOException unused) {
            return -1;
        }
    }

    public static int file_write(String str, String str2) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(str));
            bufferedWriter.write(str2);
            bufferedWriter.close();
            return 0;
        } catch (IOException unused) {
            return -1;
        }
    }

    public static int file_write_line(String str, String str2) {
        return file_write(str, str2 + "\n");
    }

    public static void fix_disabled(Context context) {
        if ((apkid.equals("tv.peel.samsung.app") || apkid.equals("com.peel.remote") || apkid.equals("com.peel.app")) && !is_first_run()) {
            int load_choice = load_choice(m_conf);
            if (load_choice == 5 || load_choice == 0) {
                int i = 0;
                try {
                    String str = get_cachedir(context);
                    String str2 = str + "/log/lum_sdk_app.log.tmp";
                    file_copy(str + "/log/lum_sdk_app.log", str2);
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(str2));
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        } else if (readLine.contains("vpn_api_set_user_selection_restricted")) {
                            i = is_restricted(apkid) ? 4 : 1;
                        }
                    }
                    bufferedReader.close();
                    file_unlink(str2);
                } catch (IOException unused) {
                }
                save_choice(context, i);
                if (i == 1) {
                    perr(5, "restore_user_choice", true);
                    perr_funnel(conf.FUNNEL_02_POPUP_CALL);
                    perr_funnel(conf.FUNNEL_03_POPUP_DISPLAY);
                    perr_funnel(conf.FUNNEL_04_DIALOG_CHOSE_PEER);
                }
            }
        }
    }

    public static boolean force_is_debug() {
        Boolean bool = m_force_is_debug;
        if (bool != null) {
            return bool.booleanValue();
        }
        Boolean valueOf = Boolean.valueOf(m_conf.get_bool(conf.FORCE_IS_DEBUG));
        m_force_is_debug = valueOf;
        if (valueOf.booleanValue()) {
            perr(5, "force_debug", true);
        }
        return m_force_is_debug.booleanValue();
    }

    public static String generate_uuid() {
        StringBuilder a2 = a.a("sdk-android-");
        a2.append(UUID.randomUUID().toString().replace("-", ""));
        return a2.toString();
    }

    public static String get_abi() {
        return Build.VERSION.SDK_INT < 21 ? Build.CPU_ABI : Build.SUPPORTED_ABIS[0];
    }

    public static String get_active_interface_name() {
        String str;
        String str2;
        String str3 = null;
        try {
            Process exec = Runtime.getRuntime().exec(new String[]{"ip", "route", "get", "1.1.1.1"});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            exec.waitFor();
            Pattern compile = Pattern.compile(String.format("%s via %s dev (\\S+)", new Object[]{"1.1.1.1", "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}"}));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                Matcher matcher = compile.matcher(readLine);
                if (matcher.find()) {
                    str3 = matcher.group(1);
                    break;
                }
            }
            bufferedReader.close();
        } catch (InterruptedException e2) {
            str2 = e2s(e2);
            str = "InterruptedException";
            perr(3, "get_active_interface_name", str, str2, true);
            return str3;
        } catch (IOException e3) {
            str2 = e2s(e3);
            str = "IOException";
            perr(3, "get_active_interface_name", str, str2, true);
            return str3;
        }
        return str3;
    }

    public static long get_app_total_bytes() {
        int i = getuid();
        return TrafficStats.getUidTxBytes(i) + TrafficStats.getUidRxBytes(i);
    }

    public static String get_cachedir(Context context) {
        String str = m_cachedir;
        if (str != null) {
            return str;
        }
        try {
            File cacheDir = context.getCacheDir();
            if (cacheDir != null) {
                String file = cacheDir.toString();
                m_cachedir = file;
                return file;
            }
        } catch (Exception unused) {
        }
        StringBuilder a2 = a.a("/data/data/");
        a2.append(context.getPackageName());
        a2.append("/cache");
        m_cachedir = a2.toString();
        StringBuilder a3 = a.a("Context.getCacheDir() = null, falling back to ");
        a3.append(m_cachedir);
        zerr(3, a3.toString());
        return m_cachedir;
    }

    public static String get_certs_filename(Context context) {
        return get_cachedir(context) + "/" + m_certs_filename;
    }

    public static String get_confdir(Context context) {
        int i = 0;
        while (i < 3) {
            try {
                return context.getFilesDir().toString();
            } catch (NullPointerException unused) {
                i++;
            }
        }
        return context.getFilesDir().toString();
    }

    public static ConnectivityManager get_connectivity_manager(Context context) {
        return (ConnectivityManager) context.getSystemService("connectivity");
    }

    @SuppressLint({"NewApi"})
    public static String get_cpu_abi() {
        if (sdk_version() >= 21) {
            return TextUtils.join("_", Build.SUPPORTED_ABIS);
        }
        return Build.CPU_ABI + "_" + Build.CPU_ABI2;
    }

    public static String get_current_interface_name() {
        String str = get_active_interface_name();
        return str == null ? get_default_interface_name() : str;
    }

    public static db_helper get_db_helper(Context context) {
        return new db_helper(context, "org.hola".equals(context.getPackageName()) ? "lum_sdk_topvpn.db" : "topvpn.db");
    }

    public static String get_default_interface_name() {
        String str;
        String str2;
        String str3 = null;
        try {
            Process exec = Runtime.getRuntime().exec(new String[]{"ip", "route"});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            exec.waitFor();
            Pattern compile = Pattern.compile(String.format("default via %s dev (\\S+)", new Object[]{"\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}"}));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                Matcher matcher = compile.matcher(readLine);
                if (matcher.find()) {
                    str3 = matcher.group(1);
                    break;
                }
            }
            bufferedReader.close();
        } catch (InterruptedException e2) {
            str2 = e2s(e2);
            str = "InterruptedException";
            perr(3, "get_default_interface_name", str, str2, true);
            return str3;
        } catch (IOException e3) {
            str2 = e2s(e3);
            str = "IOException";
            perr(3, "get_default_interface_name", str, str2, true);
            return str3;
        }
        return str3;
    }

    public static String get_device() {
        return Build.MANUFACTURER + " " + Build.BRAND + " " + Build.MODEL;
    }

    public static String get_dldir(Context context) {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/Hola";
    }

    public static Object get_field(Object obj, String str, StringBuilder sb) {
        Class<?> cls = obj.getClass();
        try {
            Field declaredField = cls.getDeclaredField(str);
            declaredField.setAccessible(true);
            try {
                return declaredField.get(obj);
            } catch (IllegalAccessException e2) {
                if (sb != null) {
                    sb.setLength(0);
                    sb.append("illegal access to " + str + " in " + cls + " " + e2.getMessage());
                }
                return null;
            }
        } catch (NoSuchFieldException e3) {
            if (sb != null) {
                sb.setLength(0);
                sb.append("no field " + str + " in " + cls + " " + e3.getMessage());
            }
            return null;
        }
    }

    public static ArrayList<String> get_installed_certs() {
        String message;
        String e2s;
        String str;
        ArrayList<String> arrayList = new ArrayList<>();
        try {
            KeyStore instance2 = KeyStore.getInstance("AndroidCAStore");
            if (instance2 == null) {
                return arrayList;
            }
            try {
                instance2.load((InputStream) null, (char[]) null);
                try {
                    Enumeration<String> aliases = instance2.aliases();
                    if (aliases == null) {
                        return arrayList;
                    }
                    while (aliases.hasMoreElements()) {
                        try {
                            X509Certificate x509Certificate = (X509Certificate) instance2.getCertificate(aliases.nextElement());
                            if (x509Certificate != null) {
                                arrayList.add(x509Certificate.getIssuerDN().getName());
                            }
                        } catch (KeyStoreException e2) {
                            perr(3, "get_certs_alias_err", e2.getMessage(), e2s(e2), true);
                        }
                    }
                    return arrayList;
                } catch (KeyStoreException e3) {
                    message = e3.getMessage();
                    e2s = e2s(e3);
                    str = "get_certs_aliases_err";
                    perr(3, str, message, e2s, true);
                    return arrayList;
                }
            } catch (Exception e4) {
                message = e4.getMessage();
                e2s = e2s(e4);
                str = "get_certs_load_err";
                perr(3, str, message, e2s, true);
                return arrayList;
            }
        } catch (KeyStoreException e5) {
            message = e5.getMessage();
            e2s = e2s(e5);
            str = "get_certs_keystore_err";
            perr(3, str, message, e2s, true);
            return arrayList;
        }
    }

    public static ArrayList<String> get_log_filenames(Context context) {
        ArrayList<String> arrayList = new ArrayList<>();
        File file = new File(get_cachedir(context).concat("/log"));
        String[] strArr = {"app", "bcast_recv", "svc_host", "svc_job"};
        for (int i = 0; i < 4; i++) {
            String format = String.format("%s/%s%s", new Object[]{file, a.a("lum_sdk_", strArr[i]), ".log"});
            if (new File(format).exists()) {
                arrayList.add(format);
            }
        }
        return arrayList;
    }

    public static ArrayList<File> get_logs(Context context) {
        ArrayList<File> arrayList = new ArrayList<>();
        new File(get_cachedir(context.getApplicationContext()).concat("/log"));
        File externalCacheDir = context.getExternalCacheDir();
        Iterator<String> it = get_log_filenames(context).iterator();
        while (it.hasNext()) {
            try {
                File file = new File(it.next());
                File createTempFile = File.createTempFile(file.getName(), ".log", externalCacheDir);
                file_copy(file, createTempFile);
                arrayList.add(createTempFile);
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        return arrayList;
    }

    public static int get_max_job_id() {
        int i;
        try {
            i = m_conf.get_int(conf.MAX_JOB_ID);
        } catch (NullPointerException unused) {
            i = 0;
        }
        if (i == 0) {
            return 1000;
        }
        return i;
    }

    public static mem_info get_mem_info(Context context) {
        return new mem_info(context);
    }

    public static int get_min_job_id() {
        int i;
        try {
            i = m_conf.get_int(conf.MIN_JOB_ID);
        } catch (NullPointerException unused) {
            i = 0;
        }
        if (i == 0) {
            return 1;
        }
        return i;
    }

    public static long get_mobile_total_bytes() {
        return TrafficStats.getMobileTxBytes() + TrafficStats.getMobileRxBytes();
    }

    public static JSONArray get_mobile_usage_json(Context context) {
        return get_mobile_usage_json(context, true);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00a6, code lost:
        if (r7 == null) goto L_0x00ab;
     */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00b4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static org.json.JSONArray get_mobile_usage_json(android.content.Context r7, boolean r8) {
        /*
            r0 = 0
            if (r8 == 0) goto L_0x000f
            java.lang.Object r8 = m_mobile_usage_lock
            monitor-enter(r8)
            org.json.JSONArray r7 = get_mobile_usage_json(r7, r0)     // Catch:{ all -> 0x000c }
            monitor-exit(r8)     // Catch:{ all -> 0x000c }
            return r7
        L_0x000c:
            r7 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x000c }
            throw r7
        L_0x000f:
            org.json.JSONArray r8 = new org.json.JSONArray
            r8.<init>()
            boolean r1 = is_tv(r7)
            if (r1 == 0) goto L_0x001b
            return r8
        L_0x001b:
            r1 = 0
            io.lum.sdk.db_helper r7 = get_db_helper(r7)     // Catch:{ Exception -> 0x0092, all -> 0x008f }
            android.database.sqlite.SQLiteDatabase r7 = r7.getWritableDatabase()     // Catch:{ Exception -> 0x0092, all -> 0x008f }
            java.lang.String r2 = "SELECT * FROM mobile_usage ORDER BY _id DESC LIMIT 8"
            android.database.Cursor r1 = r7.rawQuery(r2, r1)     // Catch:{ Exception -> 0x008d }
            if (r1 != 0) goto L_0x0035
            if (r1 == 0) goto L_0x0031
            r1.close()
        L_0x0031:
            r7.close()
            return r8
        L_0x0035:
            int r2 = r1.getColumnCount()     // Catch:{ Exception -> 0x008d }
        L_0x0039:
            boolean r3 = r1.moveToNext()     // Catch:{ Exception -> 0x008d }
            if (r3 == 0) goto L_0x0059
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch:{ Exception -> 0x008d }
            r3.<init>()     // Catch:{ Exception -> 0x008d }
            r4 = 0
        L_0x0045:
            if (r4 >= r2) goto L_0x0055
            java.lang.String r5 = r1.getColumnName(r4)     // Catch:{ Exception -> 0x0052 }
            java.lang.String r6 = r1.getString(r4)     // Catch:{ Exception -> 0x0052 }
            r3.put(r5, r6)     // Catch:{ Exception -> 0x0052 }
        L_0x0052:
            int r4 = r4 + 1
            goto L_0x0045
        L_0x0055:
            r8.put(r3)     // Catch:{ Exception -> 0x008d }
            goto L_0x0039
        L_0x0059:
            io.lum.sdk.conf r0 = m_conf     // Catch:{ Exception -> 0x008d }
            if (r0 == 0) goto L_0x0089
            io.lum.sdk.conf r0 = m_conf     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf$key r2 = io.lum.sdk.conf.CURR_MOBILE_USAGE_DATE     // Catch:{ Exception -> 0x008d }
            long r2 = r0.get_long(r2)     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf r0 = m_conf     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf$key r4 = io.lum.sdk.conf.LAST_USAGE_PERR     // Catch:{ Exception -> 0x008d }
            long r4 = r0.get_long(r4)     // Catch:{ Exception -> 0x008d }
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 == 0) goto L_0x0089
            io.lum.sdk.conf r0 = m_conf     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf$key r2 = io.lum.sdk.conf.LAST_USAGE_PERR     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf r3 = m_conf     // Catch:{ Exception -> 0x008d }
            io.lum.sdk.conf$key r4 = io.lum.sdk.conf.CURR_MOBILE_USAGE_DATE     // Catch:{ Exception -> 0x008d }
            long r3 = r3.get_long(r4)     // Catch:{ Exception -> 0x008d }
            r0.set(r2, (long) r3)     // Catch:{ Exception -> 0x008d }
            java.lang.String r0 = "mobile_bw_usage"
            java.lang.String r2 = r8.toString()     // Catch:{ Exception -> 0x008d }
            perr((java.lang.String) r0, (java.lang.String) r2)     // Catch:{ Exception -> 0x008d }
        L_0x0089:
            r1.close()
            goto L_0x00a8
        L_0x008d:
            r0 = move-exception
            goto L_0x0094
        L_0x008f:
            r8 = move-exception
            r7 = r1
            goto L_0x00ad
        L_0x0092:
            r0 = move-exception
            r7 = r1
        L_0x0094:
            java.lang.String r2 = "get_mobile_usage_json_error"
            java.lang.String r3 = r0.getMessage()     // Catch:{ all -> 0x00ac }
            java.lang.String r0 = e2s(r0)     // Catch:{ all -> 0x00ac }
            perr((java.lang.String) r2, (java.lang.String) r3, (java.lang.String) r0)     // Catch:{ all -> 0x00ac }
            if (r1 == 0) goto L_0x00a6
            r1.close()
        L_0x00a6:
            if (r7 == 0) goto L_0x00ab
        L_0x00a8:
            r7.close()
        L_0x00ab:
            return r8
        L_0x00ac:
            r8 = move-exception
        L_0x00ad:
            if (r1 == 0) goto L_0x00b2
            r1.close()
        L_0x00b2:
            if (r7 == 0) goto L_0x00b7
            r7.close()
        L_0x00b7:
            goto L_0x00b9
        L_0x00b8:
            throw r8
        L_0x00b9:
            goto L_0x00b8
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.get_mobile_usage_json(android.content.Context, boolean):org.json.JSONArray");
    }

    public static NetworkInfo get_network_info(Context context) {
        try {
            return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        } catch (NullPointerException unused) {
            return null;
        }
    }

    public static int get_notification_id() {
        return m_notification_id.incrementAndGet();
    }

    public static NotificationManager get_notification_manager(Context context) {
        return (NotificationManager) context.getSystemService("notification");
    }

    public static String get_os_ver() {
        StringBuilder a2 = a.a("Android ");
        a2.append(Build.VERSION.RELEASE);
        return a2.toString();
    }

    public static File get_perr_db(Context context) {
        try {
            File file = new File(get_perr_db_filename(context));
            if (!file.exists()) {
                return null;
            }
            File createTempFile = File.createTempFile(perr.columns.TABLE_NAME, ".db", context.getExternalCacheDir());
            file_copy(file, createTempFile);
            return createTempFile;
        } catch (IOException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static String get_perr_db_filename(Context context) {
        return context.getDatabasePath("lum_sdk_perr.db").getAbsolutePath();
    }

    public static String get_public_ua() {
        String property = System.getProperty("http.agent");
        if (property == null || property.isEmpty()) {
            property = zon_conf.CONF.optString("DEFAULT_UA", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0");
        }
        zerr(7, "User-Agent: " + property);
        return property;
    }

    public static String get_recent_logs() {
        String join;
        synchronized (m_logs) {
            join = TextUtils.join("\n", m_logs);
        }
        return join;
    }

    public static File get_screenshot(String str) {
        return m_screenshots.get(str);
    }

    public static ArrayList<String> get_screenshot_filenames() {
        ArrayList<String> arrayList = new ArrayList<>();
        String[] strArr = {"portrait", "landscape"};
        for (int i = 0; i < 2; i++) {
            String str = strArr[i];
            File file = get_screenshot("popup_" + str);
            if (file != null) {
                arrayList.add(file.getAbsolutePath());
            }
        }
        return arrayList;
    }

    public static api.state get_sdk_state(Context context, boolean z) {
        api.state state = null;
        if (is_sdk_state_restricted()) {
            return null;
        }
        api.state state2 = new api.state(m_conf.get_int(conf.SDK_STATE_STATUS), m_conf.get_str(conf.SDK_STATE_INFO));
        String str = get_sdk_state_filename(context);
        if (z && file_exists(str)) {
            try {
                JSONObject jSONObject = new JSONObject(byte2str(file_read(str)));
                state = new api.state(jSONObject.optInt("status", 0), jSONObject.optString("info"));
            } catch (JSONException unused) {
            }
            if (state != null && state.status >= state2.status) {
                state.source = "restore";
                state2 = state;
            }
        }
        ArrayList arrayList = new ArrayList();
        try {
            JSONObject jSONObject2 = new JSONObject(m_conf.get_str(conf.SDK_STATE_FILES, "{}"));
            Iterator<String> keys = jSONObject2.keys();
            while (keys.hasNext()) {
                arrayList.add(jSONObject2.getString(keys.next()));
            }
            arrayList.addAll(get_log_filenames(context));
            String str2 = get_perr_db_filename(context);
            if (file_exists(str2)) {
                arrayList.add(str2);
            }
        } catch (JSONException unused2) {
        }
        state2.files = (String[]) arrayList.toArray(new String[0]);
        return state2;
    }

    public static String get_sdk_state_filename(Context context) {
        return get_confdir(context) + "/sdk_state.json";
    }

    public static SharedPreferences get_shared_prefs(Context context) {
        return context.getSharedPreferences(m_shared_prefix, 0);
    }

    public static String get_ssl_servername(String str, conf.key key, String str2) {
        return has_sni() ? str : m_conf == null ? str2 : m_conf.get_str(key, str2);
    }

    public static job_keepalive get_svc_job_keepalive(int i) {
        if (m_job_keepalive == null) {
            synchronized (m_keepalive_lock) {
                m_job_keepalive = new job_keepalive("svc_job", m_uuid, i, conf.LAST_SVC_HEARTBEAT);
            }
        }
        return m_job_keepalive;
    }

    public static keepalive get_svc_keepalive() {
        if (m_keepalive == null) {
            synchronized (m_keepalive_lock) {
                m_keepalive = new keepalive("svc", ACTION_SVC_KEEPALIVE, 10000, conf.LAST_SVC_HEARTBEAT);
            }
        }
        return m_keepalive;
    }

    public static ExecutorService get_thread_executor(String str) {
        if (thread_executors == null) {
            thread_executors = new HashMap<>();
            thread_executors.put("svc_start", Executors.newSingleThreadExecutor(get_thread_factory("svc_start")));
        }
        return thread_executors.containsKey(str) ? thread_executors.get(str) : Executors.newSingleThreadExecutor(get_thread_factory(str));
    }

    public static thread_factory get_thread_factory(String str) {
        if (!thread_factories.containsKey(str)) {
            thread_factories.put(str, new thread_factory(str));
        }
        return thread_factories.get(str);
    }

    public static long get_today() {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.set(11, 0);
        gregorianCalendar.set(12, 0);
        gregorianCalendar.set(13, 0);
        gregorianCalendar.set(14, 0);
        return gregorianCalendar.getTime().getTime();
    }

    public static String get_ua() {
        return "lumsdk 1.177.86";
    }

    public static String get_uuid(Context context) {
        if (m_uuid != null) {
            return m_uuid;
        }
        m_uuid = m_conf.get_str(conf.UUID);
        if (!m_uuid.isEmpty()) {
            return m_uuid;
        }
        m_uuid = generate_uuid();
        StringBuilder a2 = a.a("generated new uuid ");
        a2.append(m_uuid);
        zerr(5, a2.toString());
        m_secure_conf.save(conf.UUID, m_uuid);
        return m_uuid;
    }

    public static String get_workdir(Context context) {
        String str;
        String str2;
        StringBuilder sb;
        File file;
        if (Environment.getExternalStorageState().equals("mounted")) {
            try {
                file = context.getExternalCacheDir();
            } catch (Exception unused) {
                file = null;
            }
            if (file != null && path_writeable(file.toString())) {
                return file.toString();
            }
            zerr(3, "no free space on external storage");
        }
        String str3 = get_cachedir(context);
        if (!file_exists(str3)) {
            try {
                mkdir_p(str3);
            } catch (SecurityException unused2) {
                perr("cache_mkdir_failed", str3);
                sb = new StringBuilder();
                str2 = "failed to create cache dir: ";
            }
        }
        try {
            StatFs statFs = new StatFs(str3);
            if (((long) statFs.getBlockSize()) * ((long) statFs.getBlockCount()) < 1073741824) {
                StringBuilder a2 = a.a("less than 1GB in internal memory: ");
                a2.append(((long) statFs.getBlockSize()) * ((long) statFs.getBlockCount()));
                a2.append(" block ");
                a2.append(statFs.getBlockSize());
                a2.append(" count ");
                a2.append(statFs.getBlockCount());
                str = a2.toString();
                zerr(3, str);
                return null;
            } else if (path_writeable(str3)) {
                return str3;
            } else {
                return null;
            }
        } catch (IllegalArgumentException unused3) {
            perr("cache_stat_failed", str3);
            sb = new StringBuilder();
            str2 = "failed to stat cache dir: ";
            str = a.a(sb, str2, str3);
            zerr(3, str);
            return null;
        }
    }

    public static int getuid() {
        return Process.myUid();
    }

    public static boolean has_connectivity_action() {
        return sdk_version() < 28;
    }

    public static boolean has_current_interface_name() {
        return get_current_interface_name() != null;
    }

    public static boolean has_job_scheduler() {
        return sdk_version() >= 26;
    }

    public static boolean has_network_callback() {
        return sdk_version() >= 21;
    }

    public static boolean has_sni() {
        return sdk_version() >= 17;
    }

    public static void http_send_perr(String str, JSONObject jSONObject, String str2, String str3, callback_int callback_int2) {
        final JSONObject jSONObject2 = new JSONObject();
        if (str2 != null) {
            try {
                jSONObject2.put("filehead", str2);
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        if (str3 != null) {
            jSONObject2.put("bt", str3);
        }
        if (jSONObject != null) {
            jSONObject2.put("info", jSONObject);
        }
        StringBuilder a2 = a.a("https://");
        a2.append(perr_host());
        a2.append("/client_cgi");
        a2.append(str);
        final String sb = a2.toString();
        if (m_http_send_wget.booleanValue()) {
            http_send_wget(sb, jSONObject2, callback_int2);
            return;
        }
        AsyncHttpPost asyncHttpPost = new AsyncHttpPost(sb);
        if (!has_sni()) {
            StringBuilder a3 = a.a("https://");
            a3.append(get_ssl_servername((String) null, conf.PERR_SSL_HOST, zon_conf.PERR_SSL_HOST));
            asyncHttpPost.set_domain_uri(Uri.parse(a3.toString()));
        }
        asyncHttpPost.setBody(new JSONObjectBody(jSONObject2));
        asyncHttpPost.setHeader("User-Agent", get_ua());
        asyncHttpPost.setHeader("Connection", "close");
        if (m_http_send_proxy || (m_conf != null && m_conf.get_bool(conf.DBG_FORCE_PROXY))) {
            asyncHttpPost.enable_proxy(m_sdk_proxy_pool.get_host(), m_sdk_proxy_pool.get_port(), m_sdk_proxy_pool.get_domain(), m_sdk_proxy_pool.get_ssl());
            asyncHttpPost.set_header("x-proxy", m_sdk_proxy_pool.get_details(), false);
            if (m_uuid != null) {
                asyncHttpPost.set_header("x-uuid", m_uuid, true);
            }
        }
        final String str4 = str;
        final JSONObject jSONObject3 = jSONObject;
        final String str5 = str2;
        final String str6 = str3;
        final callback_int callback_int3 = callback_int2;
        AsyncHttpClient.getDefaultInstance().executeString(asyncHttpPost, new AsyncHttpClient.StringCallback() {
            public static /* synthetic */ void a(callback_int callback_int, Exception exc, int i) {
                callback_int.run(i);
                if (i >= 0) {
                    util.perr(3, "http_send_proxy", exc.getMessage(), util.e2s(exc), true);
                }
            }

            public static /* synthetic */ void b(callback_int callback_int, Exception exc, int i) {
                callback_int.run(i);
                if (i < 0) {
                    synchronized (util.m_is_online) {
                        util.m_is_online = false;
                    }
                    return;
                }
                synchronized (util.m_http_send_wget) {
                    Boolean unused = util.m_http_send_wget = true;
                }
                util.perr(3, "http_send_wget", exc.getMessage(), util.e2s(exc), true);
            }

            public void onCompleted(Exception exc, AsyncHttpResponse asyncHttpResponse, String str) {
                if (exc != null) {
                    int unused = util.zerr(3, "http_send_perr_request_fail: " + exc);
                    if (!util.m_is_online.booleanValue() || util.m_perr_pool.failure()) {
                        return;
                    }
                    if (!util.m_http_send_proxy) {
                        util.m_perr_pool.reset();
                        boolean unused2 = util.m_http_send_proxy = true;
                        util.http_send_perr(str4, jSONObject3, str5, str6, new e1(callback_int3, exc));
                    } else if (!util.m_sdk_proxy_pool.failure(perr.columns.TABLE_NAME) || util.access$1204() >= 3) {
                        util.http_send_wget(sb, jSONObject2, new d1(callback_int3, exc));
                    }
                } else {
                    util.m_perr_pool.success();
                    if (util.m_http_send_proxy) {
                        util.m_sdk_proxy_pool.success(perr.columns.TABLE_NAME);
                    }
                    int unused3 = util.zerr(7, "http_send_perr response: " + str);
                    callback_int3.run(0);
                }
            }
        });
    }

    public static void http_send_wget(String str, JSONObject jSONObject, final callback_int callback_int2) {
        new wget(str, new wget.option[]{wget.body(jSONObject), m_uuid != null ? wget.header("x-uuid", m_uuid) : null, wget.header("Connection", "close")}) {
            public void onfailure(wget.connection connection) {
                super.onfailure(connection);
                callback_int2.run(-1);
            }

            public void onsuccess(wget.connection connection) {
                super.onsuccess(connection);
                callback_int2.run(0);
            }
        };
    }

    public static int import_choice(Context context, int i) {
        return get_shared_prefs(context).getInt("choice", i);
    }

    public static String import_conf(Context context, String str, String str2) {
        zerr(5, String.format("import %s from shared", new Object[]{str}));
        return get_shared_prefs(context).getString(str, str2);
    }

    public static String import_tracking_id(Context context, String str) {
        return import_conf(context, "tracking_id", str);
    }

    public static String import_uuid(Context context, String str) {
        return import_conf(context, "uuid", str);
    }

    public static boolean is_architecture_supported() {
        String str = get_abi();
        return str.equals("armeabi-v7a") || str.equals("arm64-v8a") || str.equals("x86") || str.equals("x86_64");
    }

    public static boolean is_bcast_client() {
        return m_bcast_client != null && !is_set_handler_thread();
    }

    public static boolean is_bcast_server() {
        return m_bcast_handler != null && is_set_handler_thread();
    }

    public static boolean is_blacklisted() {
        Boolean bool = m_blacklisted;
        if (bool != null) {
            return bool.booleanValue();
        }
        synchronized (m_blacklisted_lock) {
            if (m_conf == null) {
                return false;
            }
            String str = m_conf.get_str(conf.BLACKLISTED);
            if (!str.isEmpty()) {
                zerr(5, "blacklisted from cache: " + str);
                Boolean bool2 = true;
                m_blacklisted = bool2;
                boolean booleanValue = bool2.booleanValue();
                return booleanValue;
            } else if (country_to_tzs.is_country(zon_conf.BLACKLISTED_COUNTRIES)) {
                String id = TimeZone.getDefault().getID();
                perr(5, "blacklisted_timezone", id, "", true);
                m_conf.set(conf.BLACKLISTED, id);
                Boolean bool3 = true;
                m_blacklisted = bool3;
                boolean booleanValue2 = bool3.booleanValue();
                return booleanValue2;
            } else {
                Boolean bool4 = false;
                m_blacklisted = bool4;
                boolean booleanValue3 = bool4.booleanValue();
                return booleanValue3;
            }
        }
    }

    public static boolean is_debug() {
        if (force_is_debug()) {
            return true;
        }
        Boolean bool = m_is_debug;
        if (bool != null) {
            return bool.booleanValue();
        }
        boolean optBoolean = zon_conf.get_sdk_app_conf(apkid).optBoolean("testing", is_test_app(apkid));
        zerr(5, "is_debug default: " + optBoolean);
        Boolean valueOf = Boolean.valueOf(m_conf.get_bool(conf.IS_DEBUG, optBoolean));
        m_is_debug = valueOf;
        if (valueOf.booleanValue()) {
            perr(5, "debug", (Object) "default: " + optBoolean, true);
        }
        return m_is_debug.booleanValue();
    }

    public static boolean is_debug_layout() {
        Boolean bool = m_is_debug_layout;
        if (bool != null) {
            return bool.booleanValue();
        }
        Boolean valueOf = Boolean.valueOf(m_conf.get_bool(conf.IS_DEBUG_LAYOUT));
        m_is_debug_layout = valueOf;
        return valueOf.booleanValue();
    }

    public static boolean is_first_run() {
        return IS_FIRST_RUN;
    }

    public static boolean is_miui(Context context) {
        if (m_is_miui == null) {
            m_is_miui = apk_exist(context, m_miui_apkid);
        }
        Boolean bool = m_is_miui;
        if (bool == null) {
            return false;
        }
        if (bool.booleanValue()) {
            perr(5, "is_miui", true);
        }
        return m_is_miui.booleanValue();
    }

    public static boolean is_online(Context context) {
        final Context context2 = context;
        new with_feedback(context, "is_online", 30000) {
            public boolean check() {
                NetworkInfo activeNetworkInfo = util.get_connectivity_manager(context2).getActiveNetworkInfo();
                return activeNetworkInfo != null && activeNetworkInfo.isConnected();
            }

            public void next(boolean z) {
                int unused = util.zerr(5, "is online: " + z);
                synchronized (util.m_is_online) {
                    util.m_is_online = Boolean.valueOf(z);
                }
                if (util.m_is_online.booleanValue() && util.m_perr_inited) {
                    util.perr_send_pending();
                }
            }
        };
        return m_is_online.booleanValue();
    }

    public static boolean is_perr(String str, String str2) {
        if (!str.equals("wget") && !str.equals("connection_impl")) {
            return false;
        }
        String[] strArr = (String[]) zon_conf.PERR_DOMAINS.toArray(new String[0]);
        if (strArr == null || strArr.length < 1) {
            strArr = new String[]{perr_host()};
        }
        for (String contains : strArr) {
            if (str2.contains(contains)) {
                return true;
            }
        }
        return false;
    }

    public static boolean is_release() {
        String optString = zon_conf.CONF.optString("CONFIG_MAKEFLAGS");
        return optString.contains("CONFIG_BATREQ=y") && optString.contains("RELEASE=y");
    }

    public static boolean is_restricted(String str) {
        if (force_is_debug()) {
            return false;
        }
        JSONObject jSONObject = zon_conf.get_sdk_app_conf(str);
        JSONArray optJSONArray = jSONObject.optJSONArray("allowed_countries");
        if (optJSONArray != null && optJSONArray.length() > 0) {
            return !country_to_tzs.is_country(optJSONArray);
        }
        JSONArray optJSONArray2 = jSONObject.optJSONArray("restricted_countries");
        if (optJSONArray2 == null || optJSONArray2.length() <= 0) {
            return false;
        }
        return country_to_tzs.is_country(optJSONArray2);
    }

    public static boolean is_roaming(Context context) {
        return is_roaming(context, (NetworkInfo) null, "");
    }

    public static boolean is_roaming(Context context, NetworkInfo networkInfo, String str) {
        if (m_conf != null && m_conf.exist(conf.DBG_ROAMING)) {
            return m_conf.get_bool(conf.DBG_ROAMING);
        }
        if (str != null && !str.equals(dev_util.TYPE_MOBILE)) {
            return false;
        }
        if (networkInfo == null) {
            try {
                networkInfo = get_network_info(context);
            } catch (NullPointerException unused) {
                try {
                    return ((TelephonyManager) context.getSystemService("phone")).isNetworkRoaming();
                } catch (NullPointerException unused2) {
                    return false;
                }
            }
        }
        return networkInfo.isRoaming();
    }

    @SuppressLint({"NewApi"})
    public static boolean is_screen_on(Context context) {
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        boolean z = powerManager == null || !powerManager.isScreenOn();
        if (z || Build.VERSION.SDK_INT < 20) {
            return !z;
        }
        DisplayManager displayManager = (DisplayManager) context.getSystemService("display");
        if (displayManager == null) {
            return false;
        }
        for (Display state : displayManager.getDisplays()) {
            if (state.getState() != 1) {
                return true;
            }
        }
        return false;
    }

    @SuppressLint({"NewApi"})
    public static boolean is_screen_used(Context context) {
        if (!is_screen_on(context)) {
            return false;
        }
        try {
            KeyguardManager keyguardManager = (KeyguardManager) context.getSystemService("keyguard");
            return sdk_version() < 16 ? keyguardManager.inKeyguardRestrictedInputMode() : !keyguardManager.isKeyguardLocked();
        } catch (Exception e2) {
            perr(3, "is_screen_used_exception", e2.getMessage(), e2s(e2), true);
            return true;
        }
    }

    public static boolean is_sdk_state_restricted() {
        return !zon_conf.get_sdk_app_conf(apkid).optBoolean("get_state");
    }

    public static boolean is_set_handler_thread() {
        return Thread.currentThread().getName().equals(bcast_handler.THREAD_NAME);
    }

    public static boolean is_shutdown(Throwable th) {
        try {
            return th.getMessage().contains("android.os.DeadSystemException") || th.getStackTrace().toString().contains("android.os.DeadSystemException");
        } catch (NullPointerException unused) {
            return false;
        }
    }

    public static boolean is_test_app(String str) {
        Boolean bool = m_is_test_app;
        if (bool != null) {
            return bool.booleanValue();
        }
        if (str != null) {
            Boolean valueOf = Boolean.valueOf("io.lum.sdk_test".equals(str));
            m_is_test_app = valueOf;
            return valueOf.booleanValue();
        } else if (apkid == null) {
            return false;
        } else {
            return is_test_app(apkid);
        }
    }

    public static boolean is_tv(Context context) {
        boolean z;
        if (m_is_tv == null) {
            if (m_conf == null || !m_conf.get_bool(conf.DBG_TV)) {
                try {
                    m_is_tv = Boolean.valueOf(((UiModeManager) context.getSystemService("uimode")).getCurrentModeType() == 4);
                } catch (Exception unused) {
                    z = false;
                }
            } else {
                z = true;
                m_is_tv = z;
            }
            perr(5, m_is_tv.booleanValue() ? "is_tv" : "is_not_tv", true);
        }
        return m_is_tv.booleanValue();
    }

    public static int load_choice(conf conf) {
        return conf.get_int(conf.CHOICE);
    }

    public static ArrayList<String> load_installed_certs(Context context) {
        return (ArrayList) file_load_object(get_certs_filename(context));
    }

    public static String log_build_info() {
        StringBuilder a2 = a.a("Version: 1.177.86\nTag: Ntag-1_177_86\nBuild date: 29-Mar-20 13:57:13\nMakeflags: DIST=APP ARCH=ANDROID RELEASE=y AUTO_SIGN=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_LUM_SDK_COMPILE=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_BATREQ_FROM=lum_android_sdk CONFIG_BATREQ=y CONFIG_BAT_CYCLE=y CONFIG_BAT_PLATFORM=app_androidr\nOS Version: ");
        a2.append(get_os_ver());
        a2.append("\nDevice: ");
        a2.append(get_device());
        a2.append("\nCPU ABI: ");
        a2.append(get_cpu_abi());
        a2.append("\nUUID: ");
        String str = "N\\A";
        a2.append(m_uuid != null ? m_uuid : str);
        a2.append("\nPERR Version: ");
        a2.append(m_perr != null ? m_perr.get_db_ver() : str);
        a2.append("\nWS conn proxyjs force ip: ");
        if (m_conf != null) {
            str = m_conf.get_str(conf.WS_CONN_PROXYJS_FORCE_IP, "default");
        }
        a2.append(str);
        a2.append(apkid != null ? a.a(a.a("\nAPKID: "), apkid, "\n") : "");
        String sb = a2.toString();
        if (m_tracking_id == null || m_tracking_id.isEmpty()) {
            return sb;
        }
        StringBuilder b2 = a.b(sb, "\nTracking ID: ");
        b2.append(m_tracking_id);
        return b2.toString();
    }

    public static String log_get_hostname() {
        String property = System.getProperty("net.hostname");
        return property != null ? a.a("Hostname: ", property, "\n") : "";
    }

    public static String log_hdr() {
        StringBuilder a2 = a.a("Hola app logger\n");
        a2.append(log_build_info());
        a2.append(log_get_hostname());
        return a2.toString();
    }

    public static void log_mobile_usage(Context context) {
        boolean z;
        boolean z2;
        boolean z3;
        Context context2 = context;
        if (!is_tv(context)) {
            state state = new state(context2);
            conf conf = m_conf != null ? m_conf : new conf(context2);
            boolean z4 = state.get_bool(state.MOBILE_CONNECTED);
            boolean z5 = state.get_bool(state.WIFI_CONNECTED);
            boolean z6 = conf.get_bool(conf.LAST_ON_MOBILE);
            long j = get_app_total_bytes();
            long j2 = conf.get_long(conf.USAGE_SINCE_BOOT_APP, j);
            long j3 = get_mobile_total_bytes();
            long j4 = conf.get_long(conf.MOBILE_USAGE_SINCE_BOOT, j3);
            long j5 = conf.get_long(conf.CURR_MOBILE_USAGE_DATE);
            if (!z4 || z5) {
                z2 = z4;
                z = z5;
                z3 = false;
            } else {
                z2 = z4;
                z = z5;
                z3 = true;
            }
            long j6 = get_today();
            if (j6 != j5) {
                if (j5 != 0) {
                    save_mobile_usage_to_sql(context);
                }
                reset_daily_mobile_usage_counters(conf, state);
                conf.set(conf.CURR_MOBILE_USAGE_DATE, j6);
                conf.set(conf.LAST_ON_MOBILE, z3);
            } else if (j2 > j) {
                reset_daily_mobile_usage_counters(conf, state);
                conf.set(conf.LAST_ON_MOBILE, z3);
                perr("since_boot_gt_total", "{\"app\":" + j2 + ",\"app_total\":" + j + ",\"mobile\":" + j4 + ",\"mobile_total\":" + j3 + "}");
            } else {
                conf.set(conf.LAST_ON_MOBILE, z3);
                if (!z6) {
                    conf.set(conf.USAGE_SINCE_BOOT_APP, j);
                    return;
                }
                conf.key key = conf.DAILY_MOBILE_USAGE_APP;
                conf.set(key, (conf.get_long(key) + j) - j2);
                if (!z2 || z) {
                    conf.del(conf.LAST_ON_MOBILE);
                }
                if (j3 > 0) {
                    conf.key key2 = conf.DAILY_MOBILE_USAGE;
                    conf.set(key2, (conf.get_long(key2) + j3) - j4);
                    conf.set(conf.MOBILE_USAGE_SINCE_BOOT, j3);
                }
                conf.set(conf.USAGE_SINCE_BOOT_APP, j);
                save_mobile_usage_to_sql(context);
            }
        }
    }

    public static boolean mkdir(String str) {
        return new File(str).mkdir();
    }

    public static boolean mkdir_p(String str) {
        return new File(str).mkdirs();
    }

    public static String pad_number(int i, int i2) {
        StringBuilder sb = new StringBuilder(a.b("", i));
        while (sb.length() < i2) {
            sb.insert(0, "0");
        }
        return sb.toString();
    }

    public static boolean path_writeable(String str) {
        try {
            File createTempFile = File.createTempFile("hola", "tmp", new File(str));
            if (createTempFile != null) {
                createTempFile.delete();
                return true;
            }
        } catch (IOException unused) {
        }
        return false;
    }

    public static int perr(int i, String str, Object obj, Object obj2, boolean z) {
        return perr(i, str, String.valueOf(obj), String.valueOf(obj2), z);
    }

    public static int perr(int i, String str, Object obj, boolean z) {
        return perr(i, str, String.valueOf(obj), "", z);
    }

    public static int perr(int i, String str, String str2) {
        return perr(i, str, str2, "");
    }

    public static int perr(int i, String str, String str2, String str3) {
        return perr(i, str, str2, str3, false);
    }

    public static int perr(int i, String str, String str2, String str3, perr_once perr_once2) {
        return perr(i, str, str2, str3, perr_once2, (String) null, (String) null, false);
    }

    public static int perr(int i, String str, String str2, String str3, perr_once perr_once2, String str4, String str5, boolean z) {
        String str6 = str;
        String str7 = str2;
        if (!m_is_online.booleanValue() && !m_perr.is_enabled()) {
            _perr_p(i, str, str2, str3, perr_once2);
            return -1;
        } else if (!str.matches("[a-z0-9_]+")) {
            perr("perr_invalid_errid", "errid " + str + " msg " + str2);
            return -1;
        } else {
            if (!str.startsWith("vpn_api_") && !str.startsWith("lum_sdk_android_")) {
                str6 = a.a("vpn_api_", str);
            }
            String str8 = str6;
            StringBuilder sb = new StringBuilder();
            sb.append("perr ");
            sb.append(str8);
            sb.append(" ");
            sb.append(str2);
            sb.append("\n");
            String str9 = str3;
            sb.append(str3);
            sb.append("\n");
            zerr(7, sb.toString());
            perr_send_msg(m_perr.create_msg(i, str8, str2, str3, perr_once2, get_recent_logs(), str5 != null ? date_ts2sql(str5) : date_now2sql(), str4 != null ? str4 : "1.177.86", z));
            return -1;
        }
    }

    public static int perr(int i, String str, String str2, String str3, boolean z) {
        return perr(i, str, str2, str3, z ? perr_once.INSTALL : perr_once.NONE);
    }

    public static int perr(int i, String str, boolean z) {
        return perr(i, str, "", "", z);
    }

    public static int perr(String str) {
        return perr(3, str, "", "");
    }

    public static int perr(String str, String str2) {
        return perr(3, str, str2, "");
    }

    public static int perr(String str, String str2, String str3) {
        return perr(3, str, str2, str3);
    }

    public static int perr(String str, Throwable th) {
        return perr(str, th, "");
    }

    public static int perr(String str, Throwable th, String str2) {
        return perr(3, str, str2, e2s(th));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x007d, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized void perr_funnel(io.lum.sdk.conf.key r5) {
        /*
            java.lang.Class<io.lum.sdk.util> r0 = io.lum.sdk.util.class
            monitor-enter(r0)
            io.lum.sdk.conf r1 = m_conf     // Catch:{ all -> 0x007e }
            r2 = 1
            if (r1 != 0) goto L_0x0010
            r5 = 3
            java.lang.String r1 = "perr_funnel_conf_null"
            perr((int) r5, (java.lang.String) r1, (boolean) r2)     // Catch:{ all -> 0x007e }
            monitor-exit(r0)
            return
        L_0x0010:
            io.lum.sdk.conf r1 = m_conf     // Catch:{ all -> 0x007e }
            boolean r1 = r1.get_bool(r5)     // Catch:{ all -> 0x007e }
            if (r1 == 0) goto L_0x001a
            monitor-exit(r0)
            return
        L_0x001a:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x007e }
            r1.<init>()     // Catch:{ all -> 0x007e }
            java.lang.String r3 = "lum_sdk_android_"
            r1.append(r3)     // Catch:{ all -> 0x007e }
            java.lang.String r3 = r5.toString()     // Catch:{ all -> 0x007e }
            r1.append(r3)     // Catch:{ all -> 0x007e }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x007e }
            r3 = 5
            perr((int) r3, (java.lang.String) r1, (boolean) r2)     // Catch:{ all -> 0x007e }
            io.lum.sdk.conf r1 = m_conf     // Catch:{ all -> 0x007e }
            r1.set(r5, (boolean) r2)     // Catch:{ all -> 0x007e }
            boolean r1 = is_sdk_state_restricted()     // Catch:{ all -> 0x007e }
            if (r1 == 0) goto L_0x0040
            monitor-exit(r0)
            return
        L_0x0040:
            java.lang.String r5 = r5.toString()     // Catch:{ all -> 0x007e }
            r1 = 0
            r2 = 2
            java.lang.String r5 = r5.substring(r1, r2)     // Catch:{ all -> 0x007e }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x007e }
            int r5 = r5.intValue()     // Catch:{ all -> 0x007e }
            io.lum.sdk.conf r1 = m_conf     // Catch:{ all -> 0x007e }
            io.lum.sdk.conf$key r2 = io.lum.sdk.conf.SDK_STATE_STATUS     // Catch:{ all -> 0x007e }
            int r1 = r1.get_int(r2)     // Catch:{ all -> 0x007e }
            if (r5 <= r1) goto L_0x007c
            java.lang.String r1 = "lumsdk/state"
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x007e }
            r2.<init>()     // Catch:{ all -> 0x007e }
            java.lang.String r4 = "status="
            r2.append(r4)     // Catch:{ all -> 0x007e }
            r2.append(r5)     // Catch:{ all -> 0x007e }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x007e }
            _zerr(r1, r3, r2)     // Catch:{ all -> 0x007e }
            io.lum.sdk.conf r1 = m_conf     // Catch:{ all -> 0x007e }
            io.lum.sdk.conf$key r2 = io.lum.sdk.conf.SDK_STATE_STATUS     // Catch:{ all -> 0x007e }
            r1.set(r2, (int) r5)     // Catch:{ all -> 0x007e }
            update_sdk_info()     // Catch:{ all -> 0x007e }
        L_0x007c:
            monitor-exit(r0)
            return
        L_0x007e:
            r5 = move-exception
            monitor-exit(r0)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.perr_funnel(io.lum.sdk.conf$key):void");
    }

    public static void perr_funnel_main_send(String str) {
        perr_funnel_main_send(str, "");
    }

    public static void perr_funnel_main_send(String str, String str2) {
        if (perr_funnel_main == null) {
            perr_funnel_main = new perr_funnel("main");
        }
        perr_funnel_main.send(str, str2);
    }

    public static void perr_funnel_v(conf.key key) {
        perr_funnel_v(key, false);
    }

    public static void perr_funnel_v(conf.key key, Boolean bool) {
        perr(5, "lum_sdk_android_" + key, "", "", perr_once.VER);
        if (bool.booleanValue()) {
            perr(5, "lum_sdk_android_mobile_" + key, "", "", perr_once.VER);
        }
    }

    public static String perr_host() {
        if (m_perr_pool != null) {
            return m_perr_pool.get_host();
        }
        zerr(3, "m_perr_pool null");
        int size = zon_conf.PERR_DOMAINS.size();
        return size > 0 ? zon_conf.PERR_DOMAINS.get(new Random().nextInt(size)) : perr_pool.m_fallback_host;
    }

    public static void perr_init() {
        if (!m_perr_inited) {
            m_perr_lock.writeLock().lock();
            try {
                if (!m_perr_inited) {
                    HandlerThread handlerThread = new HandlerThread(perr.columns.TABLE_NAME, -1);
                    m_perr_thread = handlerThread;
                    handlerThread.start();
                    m_perr_handler = new Handler(m_perr_thread.getLooper()) {
                        public static /* synthetic */ void a() {
                            if (util.m_is_online.booleanValue()) {
                                util.perr_send_pending();
                            }
                        }

                        public void handleMessage(Message message) {
                            util.m_perr.handle_message(message, f1.f7252a);
                        }
                    };
                    m_perr_inited = true;
                    m_perr_lock.writeLock().unlock();
                }
            } finally {
                m_perr_lock.writeLock().unlock();
            }
        }
    }

    public static void perr_p(int i, String str, String str2, String str3) {
        perr_p(i, str, str2, str3, false);
    }

    public static void perr_p(int i, String str, String str2, String str3, boolean z) {
        _perr_p(i, str, str2, str3, z ? perr_once.INSTALL : perr_once.NONE);
    }

    public static void perr_p(int i, String str, boolean z) {
        perr_p(i, str, "", "", z);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0059, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void perr_p_file(java.lang.String r3, java.lang.String r4, boolean r5) {
        /*
            java.lang.Object r0 = m_zerr_lock
            monitor-enter(r0)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x005a }
            r1.<init>()     // Catch:{ all -> 0x005a }
            java.lang.String r2 = m_path     // Catch:{ all -> 0x005a }
            r1.append(r2)     // Catch:{ all -> 0x005a }
            java.lang.String r2 = "/"
            r1.append(r2)     // Catch:{ all -> 0x005a }
            r1.append(r3)     // Catch:{ all -> 0x005a }
            java.lang.String r2 = ".log"
            r1.append(r2)     // Catch:{ all -> 0x005a }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x005a }
            if (r5 == 0) goto L_0x003d
            boolean r5 = file_exists(r1)     // Catch:{ all -> 0x005a }
            if (r5 == 0) goto L_0x003d
            r4 = 7
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x005a }
            r5.<init>()     // Catch:{ all -> 0x005a }
            java.lang.String r1 = "perr file exists: "
            r5.append(r1)     // Catch:{ all -> 0x005a }
            r5.append(r3)     // Catch:{ all -> 0x005a }
            java.lang.String r3 = r5.toString()     // Catch:{ all -> 0x005a }
            zerr(r4, r3)     // Catch:{ all -> 0x005a }
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            return
        L_0x003d:
            int r4 = file_write((java.lang.String) r1, (java.lang.String) r4)     // Catch:{ all -> 0x005a }
            if (r4 == 0) goto L_0x0058
            r4 = 3
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x005a }
            r5.<init>()     // Catch:{ all -> 0x005a }
            java.lang.String r1 = "perr failed creating file "
            r5.append(r1)     // Catch:{ all -> 0x005a }
            r5.append(r3)     // Catch:{ all -> 0x005a }
            java.lang.String r3 = r5.toString()     // Catch:{ all -> 0x005a }
            zerr(r4, r3)     // Catch:{ all -> 0x005a }
        L_0x0058:
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            return
        L_0x005a:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x005a }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.perr_p_file(java.lang.String, java.lang.String, boolean):void");
    }

    public static String perr_p_file_str(String str, String str2, String str3, String str4) {
        StringBuilder sb = new StringBuilder();
        sb.append("perr_");
        sb.append(str2);
        sb.append(" ");
        sb.append(str3);
        sb.append("\n");
        sb.append(log_build_info());
        sb.append(log_get_hostname());
        sb.append((str == null || str.isEmpty()) ? "" : a.a("Cid: ", str, " release\n"));
        sb.append("\n");
        if (str4 == null) {
            str4 = "";
        }
        sb.append(str4);
        return sb.toString();
    }

    public static String perr_p_filename(String str, perr_once perr_once2) {
        StringBuilder sb;
        String a2 = a.a("perr_", str);
        String date_now2ts = date_now2ts();
        int ordinal = perr_once2.ordinal();
        if (ordinal == 0) {
            sb = a.b(date_now2ts, "_");
            date_now2ts = "1.177.86";
        } else if (ordinal != 2) {
            sb = a.b(date_now2ts, "_once_");
            sb.append(a2);
            return sb.toString();
        } else {
            sb = new StringBuilder();
        }
        sb.append(date_now2ts);
        sb.append("_");
        sb.append(a2);
        return sb.toString();
    }

    public static void perr_p_try() {
        perr_init();
        if (m_perr_lock.readLock().tryLock()) {
            m_perr_handler.sendEmptyMessage(0);
            m_perr_lock.readLock().unlock();
        }
    }

    public static void perr_send(perr.msg msg, perr.on_finish on_finish) {
        perr.msg msg2 = msg;
        perr.on_finish on_finish2 = on_finish;
        if (msg2.m_dry) {
            on_finish2.run(true);
        } else if (m_perr.is_enabled() || m_path != null) {
            String str = msg2.m_once == perr_once.VER ? "1.177.86" : "";
            String str2 = m_path + "/" + msg2.m_errid + str + ".sent";
            String str3 = m_path + "/" + msg2.m_errid + str + ".sending";
            if (msg2.m_once != perr_once.NONE) {
                String[] strArr = {str2, str3};
                boolean z = false;
                for (int i = 0; i < 2; i++) {
                    String str4 = strArr[i];
                    if (file_exists(str4)) {
                        if (m_perr.is_enabled()) {
                            file_unlink(str4);
                        }
                        if (!z) {
                            on_finish2.run(true);
                            z = true;
                        }
                    }
                }
                if (!z) {
                    if (!m_perr.is_enabled() && file_write(str3, "") != 0) {
                        zerr(3, "perr once: " + str3 + " write failed");
                        on_finish2.run(false);
                        return;
                    }
                } else {
                    return;
                }
            }
            String str5 = msg2.m_msg;
            String str6 = msg2.m_body;
            int i2 = msg2.m_level;
            StringBuilder a2 = a.a("perr_send ");
            a2.append(msg2.m_errid);
            a2.append("; ");
            a2.append(str5);
            a2.append("; ");
            a2.append(str6);
            zerr(i2, a2.toString());
            String str7 = "/perr?" + str2query("id", msg2.m_errid) + "&" + str2query("ver", msg2.m_ver) + "&" + str2query("build", log_build_info());
            if (m_conf != null) {
                String str8 = m_conf.get_str(conf.CID_KEY);
                if (!str8.isEmpty()) {
                    StringBuilder b2 = a.b(str7, "&");
                    b2.append(str2query("cid_key", str8));
                    str7 = b2.toString();
                }
                String str9 = m_conf.get_str(conf.CID_VALUE);
                if (!str9.isEmpty()) {
                    StringBuilder b3 = a.b(str7, "&");
                    b3.append(str2query("cid", str9));
                    str7 = b3.toString();
                }
            }
            if (apkid != null) {
                StringBuilder b4 = a.b(str7, "&");
                b4.append(str2query("apkid", apkid));
                str7 = b4.toString();
            }
            if (m_uuid != null && !m_uuid.isEmpty()) {
                StringBuilder b5 = a.b(str7, "&");
                b5.append(str2query("uuid", m_uuid));
                str7 = b5.toString();
            }
            if (m_tracking_id != null && !m_tracking_id.isEmpty()) {
                StringBuilder b6 = a.b(str7, "&");
                b6.append(str2query("tracking_id", m_tracking_id));
                str7 = b6.toString();
            }
            String str10 = msg2.m_date;
            if (str10 != null && !str10.isEmpty()) {
                StringBuilder b7 = a.b(str7, "&");
                b7.append(str2query("timestamp", msg2.m_date));
                str7 = b7.toString();
            }
            long j = m_conf.get_long(conf.INSTALL_TS);
            if (j > 0) {
                StringBuilder b8 = a.b(str7, "&");
                b8.append(str2query("install_ts", "" + j));
                str7 = b8.toString();
                long j2 = m_conf.get_long(conf.UPDATE_TS);
                if (j2 > 0) {
                    StringBuilder b9 = a.b(str7, "&");
                    b9.append(str2query("update_ts", "" + j2));
                    str7 = b9.toString();
                }
            }
            String str11 = str7;
            String str12 = msg2.m_logs;
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("msg", str5);
            } catch (JSONException e2) {
                msg.zerr(3, e2s(e2));
            }
            try {
                jSONObject.put(perr.columns.BODY, str6);
            } catch (JSONException e3) {
                msg.zerr(3, e2s(e3));
            }
            http_send_perr(str11, jSONObject, str12, (String) null, new m1(on_finish, str11, msg, str5, str6, str3, str2));
        } else {
            on_finish2.run(false);
        }
    }

    public static void perr_send_msg(perr.msg msg) {
        perr_init();
        Message obtainMessage = m_perr_handler.obtainMessage(1, msg);
        m_perr_lock.readLock().lock();
        try {
            m_perr_handler.sendMessage(obtainMessage);
        } finally {
            m_perr_lock.readLock().unlock();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002e, code lost:
        if (m_conf.get_bool(io.lum.sdk.conf.PERR_SEND_PENDING_OLD) == false) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0030, code lost:
        scandir(m_path, d.a.a.h1.f7270a, (java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0046, code lost:
        if ("1.177.86".equals(m_conf.get_str(io.lum.sdk.conf.INIT_VERSION)) == false) goto L_0x004b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0048, code lost:
        r0 = io.lum.sdk.conf.PERR_SEND_PENDING_INSTALL;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004b, code lost:
        r0 = io.lum.sdk.conf.PERR_SEND_PENDING_UPDATE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0053, code lost:
        if (m_conf.get_bool(r0) == false) goto L_0x005a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0055, code lost:
        m_perr.process_pending();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005a, code lost:
        r1 = m_perr_send_pending_lock;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x005c, code lost:
        monitor-enter(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
        m_perr_send_pending = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0060, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0061, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void perr_send_pending() {
        /*
            io.lum.sdk.perr r0 = m_perr
            boolean r0 = r0.is_enabled()
            if (r0 != 0) goto L_0x0009
            return
        L_0x0009:
            java.lang.String r0 = m_app_name
            java.lang.String r1 = "svc"
            boolean r0 = r0.startsWith(r1)
            if (r0 != 0) goto L_0x0014
            return
        L_0x0014:
            io.lum.sdk.conf r0 = m_conf
            if (r0 != 0) goto L_0x0019
            return
        L_0x0019:
            java.lang.Object r0 = m_perr_send_pending_lock
            monitor-enter(r0)
            boolean r1 = m_perr_send_pending     // Catch:{ all -> 0x0065 }
            if (r1 == 0) goto L_0x0022
            monitor-exit(r0)     // Catch:{ all -> 0x0065 }
            return
        L_0x0022:
            r1 = 1
            m_perr_send_pending = r1     // Catch:{ all -> 0x0065 }
            monitor-exit(r0)     // Catch:{ all -> 0x0065 }
            io.lum.sdk.conf r0 = m_conf
            io.lum.sdk.conf$key r1 = io.lum.sdk.conf.PERR_SEND_PENDING_OLD
            boolean r0 = r0.get_bool(r1)
            if (r0 == 0) goto L_0x0038
            java.lang.String r0 = m_path
            d.a.a.h1 r1 = d.a.a.h1.f7270a
            r2 = 0
            scandir(r0, r1, r2)
        L_0x0038:
            io.lum.sdk.conf r0 = m_conf
            io.lum.sdk.conf$key r1 = io.lum.sdk.conf.INIT_VERSION
            java.lang.String r0 = r0.get_str(r1)
            java.lang.String r1 = "1.177.86"
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x004b
            io.lum.sdk.conf$key r0 = io.lum.sdk.conf.PERR_SEND_PENDING_INSTALL
            goto L_0x004d
        L_0x004b:
            io.lum.sdk.conf$key r0 = io.lum.sdk.conf.PERR_SEND_PENDING_UPDATE
        L_0x004d:
            io.lum.sdk.conf r1 = m_conf
            boolean r0 = r1.get_bool(r0)
            if (r0 == 0) goto L_0x005a
            io.lum.sdk.perr r0 = m_perr
            r0.process_pending()
        L_0x005a:
            java.lang.Object r1 = m_perr_send_pending_lock
            monitor-enter(r1)
            r0 = 0
            m_perr_send_pending = r0     // Catch:{ all -> 0x0062 }
            monitor-exit(r1)     // Catch:{ all -> 0x0062 }
            return
        L_0x0062:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0062 }
            throw r0
        L_0x0065:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0065 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.perr_send_pending():void");
    }

    public static void perr_uninit() {
        m_perr_lock.writeLock().lock();
        try {
            if (!m_perr_thread.quit()) {
                zerr(3, "perr thread quit failed");
                return;
            }
            m_perr_thread = null;
            m_perr_inited = false;
            m_perr.uninit();
            m_perr_lock.writeLock().unlock();
        } finally {
            m_perr_lock.writeLock().unlock();
        }
    }

    public static List<proc_info_t> proc_find(String str) {
        return proc_find(str, (String) null);
    }

    public static List<proc_info_t> proc_find(final String str, final String str2) {
        final LinkedList linkedList = new LinkedList();
        scandir("/proc", new scandir_cb_t() {
            /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public int cb(java.lang.String r3, java.lang.String r4, java.lang.String r5, java.lang.Object r6) {
                /*
                    r2 = this;
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    r3.<init>()
                    r3.append(r5)
                    java.lang.String r6 = "/cmdline"
                    r3.append(r6)
                    java.lang.String r3 = r3.toString()
                    java.lang.String r3 = io.lum.sdk.util.file_read_line(r3)
                    r6 = 0
                    if (r3 != 0) goto L_0x0019
                    return r6
                L_0x0019:
                    int r0 = r3.indexOf(r6)
                    if (r0 < 0) goto L_0x0023
                    java.lang.String r3 = r3.substring(r6, r0)
                L_0x0023:
                    java.lang.String r0 = r2
                    boolean r0 = r3.endsWith(r0)
                    if (r0 == 0) goto L_0x008d
                    java.lang.String r0 = r3
                    if (r0 == 0) goto L_0x0036
                    boolean r3 = r3.contains(r0)
                    if (r3 != 0) goto L_0x0036
                    goto L_0x008d
                L_0x0036:
                    java.io.BufferedReader r3 = new java.io.BufferedReader     // Catch:{ IOException -> 0x008d }
                    java.io.FileReader r0 = new java.io.FileReader     // Catch:{ IOException -> 0x008d }
                    java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x008d }
                    r1.<init>()     // Catch:{ IOException -> 0x008d }
                    r1.append(r5)     // Catch:{ IOException -> 0x008d }
                    java.lang.String r5 = "/status"
                    r1.append(r5)     // Catch:{ IOException -> 0x008d }
                    java.lang.String r5 = r1.toString()     // Catch:{ IOException -> 0x008d }
                    r0.<init>(r5)     // Catch:{ IOException -> 0x008d }
                    r3.<init>(r0)     // Catch:{ IOException -> 0x008d }
                L_0x0051:
                    java.lang.String r5 = r3.readLine()     // Catch:{ IOException -> 0x008d }
                    if (r5 == 0) goto L_0x005f
                    java.lang.String r0 = "Uid"
                    boolean r0 = r5.startsWith(r0)     // Catch:{ IOException -> 0x008d }
                    if (r0 == 0) goto L_0x0051
                L_0x005f:
                    r3.close()     // Catch:{ IOException -> 0x008d }
                    if (r5 != 0) goto L_0x0065
                    return r6
                L_0x0065:
                    java.lang.String r3 = "\\t"
                    java.lang.String[] r3 = r5.split(r3)
                    int r5 = r3.length
                    r0 = 2
                    if (r5 >= r0) goto L_0x0070
                    return r6
                L_0x0070:
                    io.lum.sdk.util$proc_info_t r5 = new io.lum.sdk.util$proc_info_t
                    r5.<init>()
                    int r4 = java.lang.Integer.parseInt(r4)
                    r5.pid = r4
                    r4 = 1
                    r3 = r3[r4]     // Catch:{  }
                    java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{  }
                    int r3 = r3.intValue()     // Catch:{  }
                    r5.uid = r3     // Catch:{  }
                    java.util.List r3 = r0
                    r3.add(r5)
                L_0x008d:
                    return r6
                */
                throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.AnonymousClass7.cb(java.lang.String, java.lang.String, java.lang.String, java.lang.Object):int");
            }
        }, (Object) null);
        return linkedList;
    }

    public static void register_cid(String str, String str2, String str3) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("type", str2).put("myip", str3);
            zerr(5, String.format("register cid: %s, payload: %s", new Object[]{str, jSONObject}));
            perr(5, "register_client", (Object) str, (Object) jSONObject, false);
        } catch (JSONException e2) {
            StringBuilder a2 = a.a("register cid invalid payload: ");
            a2.append(e2s(e2));
            zerr(4, a2.toString());
        }
    }

    @TargetApi(21)
    public static void register_network_callback(ConnectivityManager connectivityManager, ConnectivityManager.NetworkCallback networkCallback) {
        try {
            connectivityManager.registerNetworkCallback(new NetworkRequest.Builder().build(), networkCallback);
        } catch (Exception unused) {
        }
    }

    public static void reset_daily_mobile_usage_counters(conf conf, state state) {
        conf.set(conf.DAILY_MOBILE_USAGE, 0);
        conf.set(conf.DAILY_MOBILE_USAGE_APP, 0);
        if (state.get_bool(state.MOBILE_CONNECTED)) {
            conf.set(conf.MOBILE_USAGE_SINCE_BOOT, get_mobile_total_bytes());
        }
        conf.set(conf.USAGE_SINCE_BOOT_APP, get_app_total_bytes());
    }

    public static void restart_svc_client(String str) {
        if (m_svc_client != null) {
            try {
                m_svc_client.restart(str);
            } catch (Exception e2) {
                perr(3, "svc_client_restart_exception", e2.getMessage(), e2s(e2), true);
            }
        }
    }

    public static void restart_svc_host(Context context, String str) {
        svc_host.stop(context, true);
        start_svc_host(context, "restart");
    }

    public static void restart_svc_thread(String str) {
        if (load_choice(m_conf) == 1) {
            if (is_bcast_client()) {
                bcast_client_svc_action("restart_svc_client", str);
            } else if (m_svc_client == null) {
                start_svc_client(str);
            } else {
                restart_svc_client(str);
            }
        }
    }

    public static int rmdir_recursive(File file) {
        if (!file.exists()) {
            zerr(7, "file " + file + " does not exist");
            return 0;
        }
        File[] listFiles = file.listFiles();
        int i = 0;
        while (listFiles != null && i < listFiles.length) {
            if (listFiles[i].isDirectory()) {
                rmdir_recursive(listFiles[i]);
            } else {
                listFiles[i].delete();
            }
            i++;
        }
        return file.delete() ? 0 : -1;
    }

    public static int rmdir_recursive(String str) {
        return rmdir_recursive(new File(str));
    }

    public static void run_version_tasks() {
        String str = m_conf.get_str(conf.INSTALL_VERSION);
        if (!"1.177.86".equals(str)) {
            if (str == null || str.isEmpty()) {
                perr("install");
            } else {
                perr("update", "version: " + str);
                conf.key[] keyArr = {conf.SVC_THREAD_JAVA_CRASHES, conf.SVC_THREAD_JAVA_REVIVALS, conf.SVC_THREAD_JAVA_STUCKS};
                JSONObject jSONObject = new JSONObject();
                for (int i = 0; i < 3; i++) {
                    conf.key key = keyArr[i];
                    try {
                        jSONObject.put(key.toString(), m_conf.get_int(key));
                        m_conf.del(key);
                    } catch (JSONException e2) {
                        zerr(3, e2s(e2));
                    }
                    m_conf.set(key, 0);
                }
                perr(5, "version_report", str, "" + jSONObject);
                m_conf.set(conf.UPDATE_TS, System.currentTimeMillis());
                m_conf.del(conf.APK_CONFIG);
                m_conf.del(conf.APK_CONFIG_LAST_UPDATE);
                m_conf.del(conf.SVC_JOB_KILL_PROCESS);
            }
            m_conf.set(conf.INSTALL_VERSION, "1.177.86");
        }
    }

    public static void save_choice(Context context, int i) {
        m_secure_conf.save(conf.CHOICE, Integer.valueOf(i));
    }

    public static void save_installed_certs(Context context) {
        file_save_object(get_certs_filename(context), get_installed_certs());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0094, code lost:
        if (r1 != null) goto L_0x0096;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
        r1.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00a4, code lost:
        if (r1 != null) goto L_0x0096;
     */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00ab  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void save_mobile_usage_to_sql(android.content.Context r8) {
        /*
            java.lang.Object r0 = m_mobile_usage_lock
            monitor-enter(r0)
            r1 = 0
            io.lum.sdk.db_helper r2 = get_db_helper(r8)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x009a, Exception -> 0x008a }
            android.database.sqlite.SQLiteDatabase r2 = r2.getWritableDatabase()     // Catch:{ SQLiteCantOpenDatabaseException -> 0x009a, Exception -> 0x008a }
            android.content.ContentValues r3 = new android.content.ContentValues     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r3.<init>()     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r4 = "app_bw"
            io.lum.sdk.conf r5 = m_conf     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            io.lum.sdk.conf$key r6 = io.lum.sdk.conf.DAILY_MOBILE_USAGE_APP     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            long r5 = r5.get_long(r6)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.Long r5 = java.lang.Long.valueOf(r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r3.put(r4, r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r4 = "device_bw_since_boot"
            long r5 = get_mobile_total_bytes()     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.Long r5 = java.lang.Long.valueOf(r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r3.put(r4, r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r4 = "device_daily_bw"
            io.lum.sdk.conf r5 = m_conf     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            io.lum.sdk.conf$key r6 = io.lum.sdk.conf.DAILY_MOBILE_USAGE     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            long r5 = r5.get_long(r6)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.Long r5 = java.lang.Long.valueOf(r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r3.put(r4, r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r4 = "mobile_usage"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r5.<init>()     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r6 = "date="
            r5.append(r6)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            io.lum.sdk.conf r6 = m_conf     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            io.lum.sdk.conf$key r7 = io.lum.sdk.conf.CURR_MOBILE_USAGE_DATE     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            long r6 = r6.get_long(r7)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r5.append(r6)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r5 = r5.toString()     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            int r4 = r2.update(r4, r3, r5, r1)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            if (r4 != 0) goto L_0x0077
            java.lang.String r4 = "date"
            io.lum.sdk.conf r5 = m_conf     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            io.lum.sdk.conf$key r6 = io.lum.sdk.conf.CURR_MOBILE_USAGE_DATE     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            long r5 = r5.get_long(r6)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.Long r5 = java.lang.Long.valueOf(r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r3.put(r4, r5)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            java.lang.String r4 = "mobile_usage"
            r2.insert(r4, r1, r3)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
        L_0x0077:
            r1 = 0
            get_mobile_usage_json(r8, r1)     // Catch:{ SQLiteCantOpenDatabaseException -> 0x0085, Exception -> 0x0082, all -> 0x007f }
            r2.close()     // Catch:{ all -> 0x00af }
            goto L_0x00a7
        L_0x007f:
            r8 = move-exception
            r1 = r2
            goto L_0x00a9
        L_0x0082:
            r8 = move-exception
            r1 = r2
            goto L_0x008b
        L_0x0085:
            r8 = move-exception
            r1 = r2
            goto L_0x009b
        L_0x0088:
            r8 = move-exception
            goto L_0x00a9
        L_0x008a:
            r8 = move-exception
        L_0x008b:
            java.lang.String r2 = "save_to_sql_exception"
            java.lang.String r8 = r8.getMessage()     // Catch:{ all -> 0x0088 }
            perr((java.lang.String) r2, (java.lang.String) r8)     // Catch:{ all -> 0x0088 }
            if (r1 == 0) goto L_0x00a7
        L_0x0096:
            r1.close()     // Catch:{ all -> 0x00af }
            goto L_0x00a7
        L_0x009a:
            r8 = move-exception
        L_0x009b:
            java.lang.String r2 = "save_mobile_usage_to_sql_sql_error"
            java.lang.String r8 = r8.getMessage()     // Catch:{ all -> 0x0088 }
            perr((java.lang.String) r2, (java.lang.String) r8)     // Catch:{ all -> 0x0088 }
            if (r1 == 0) goto L_0x00a7
            goto L_0x0096
        L_0x00a7:
            monitor-exit(r0)     // Catch:{ all -> 0x00af }
            return
        L_0x00a9:
            if (r1 == 0) goto L_0x00ae
            r1.close()     // Catch:{ all -> 0x00af }
        L_0x00ae:
            throw r8     // Catch:{ all -> 0x00af }
        L_0x00af:
            r8 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00af }
            goto L_0x00b3
        L_0x00b2:
            throw r8
        L_0x00b3:
            goto L_0x00b2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.save_mobile_usage_to_sql(android.content.Context):void");
    }

    public static void scandir(String str, scandir_cb_t scandir_cb_t2, Object obj) {
        File[] listFiles = new File(str).listFiles();
        if (listFiles != null) {
            int length = listFiles.length;
            int i = 0;
            while (i < length) {
                File file = listFiles[i];
                if (scandir_cb_t2.cb(str, file.getName(), file.getAbsolutePath(), obj) == 0) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x002c A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x002d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean sdk_disabled(boolean r7) {
        /*
            io.lum.sdk.conf r0 = m_conf
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            io.lum.sdk.conf r0 = m_conf
            io.lum.sdk.conf$key r2 = io.lum.sdk.conf.SDK_DISABLED
            boolean r0 = r0.get_bool(r2)
            if (r0 != 0) goto L_0x0011
            return r1
        L_0x0011:
            r0 = 1
            if (r7 == 0) goto L_0x0029
            long r2 = java.lang.System.currentTimeMillis()
            io.lum.sdk.conf r7 = m_conf
            io.lum.sdk.conf$key r4 = io.lum.sdk.conf.SDK_DISABLED_UNTIL
            r5 = 0
            long r4 = r7.get_long(r4, r5)
            int r7 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r7 <= 0) goto L_0x0027
            goto L_0x0029
        L_0x0027:
            r7 = 0
            goto L_0x002a
        L_0x0029:
            r7 = 1
        L_0x002a:
            if (r7 != 0) goto L_0x002d
            return r1
        L_0x002d:
            r7 = 4
            java.lang.String r1 = "sdk_disabled"
            perr((int) r7, (java.lang.String) r1, (boolean) r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.sdk_disabled(boolean):boolean");
    }

    public static boolean sdk_unsupported() {
        return evaluation.get_supported_errid() != null;
    }

    public static int sdk_version() {
        return Build.VERSION.SDK_INT;
    }

    public static void set_bcast_client(Context context) {
        if (!is_set_handler_thread() && m_bcast_client == null) {
            synchronized (m_bcast_client_lock) {
                zerr(5, String.format("creating bcast/client for %s (%s)", new Object[]{m_app_name, Thread.currentThread().getName()}));
                m_bcast_client = new bcast.client(context);
            }
        }
    }

    public static void set_force_is_debug() {
        conf conf = m_conf;
        conf.key key = conf.FORCE_IS_DEBUG;
        Boolean bool = true;
        m_is_debug = bool;
        conf.set(key, bool.booleanValue());
    }

    public static void set_tracking_id(Context context, String str) {
        m_tracking_id = m_conf.get_str(conf.TRACKING_ID);
        if (m_tracking_id.isEmpty() && str != null) {
            m_tracking_id = str;
            m_secure_conf.save(conf.TRACKING_ID, m_tracking_id);
        }
    }

    public static void set_uuid(String str) {
        if (str != null && str.startsWith("sdk-android-")) {
            m_uuid = str;
        }
    }

    public static void share_file(Activity activity, String str, File file) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(file);
        share_files(activity, str, arrayList);
    }

    public static void share_files(Activity activity, String str, ArrayList<File> arrayList) {
        try {
            Intent intent = new Intent("android.intent.action.SEND_MULTIPLE");
            intent.addFlags(1);
            intent.setType("vnd.android.cursor.dir/email");
            intent.putExtra("android.intent.extra.SUBJECT", String.format("Luminati SDK %s %s (%s)", new Object[]{"1.177.86", str, get_device()}));
            ArrayList arrayList2 = new ArrayList();
            Context applicationContext = activity.getApplicationContext();
            String str2 = applicationContext.getPackageName() + ".provider";
            Iterator<File> it = arrayList.iterator();
            while (it.hasNext()) {
                arrayList2.add(FileProvider.getUriForFile(applicationContext, str2, it.next()));
            }
            intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList2);
            activity.startActivity(Intent.createChooser(intent, "Send to..."));
        } catch (Exception e2) {
            StringBuilder a2 = a.a("share files failed: ");
            a2.append(e2s(e2));
            zerr(3, a2.toString());
        }
    }

    public static void share_log(Activity activity) {
        ArrayList<File> arrayList = get_logs(activity);
        arrayList.add(get_perr_db(activity));
        if (arrayList.size() > 0) {
            share_files(activity, perr.columns.LOGS, arrayList);
        }
    }

    public static void share_screenshot(Activity activity) {
        ArrayList arrayList = new ArrayList();
        Iterator<String> it = get_screenshot_filenames().iterator();
        while (it.hasNext()) {
            arrayList.add(new File(it.next()));
        }
        if (arrayList.size() > 0) {
            share_files(activity, "popup", arrayList);
        }
    }

    public static void share_text(Activity activity, String str, String str2, String str3) {
        try {
            zerr(5, String.format("Send text: %s = %s", new Object[]{str, str2}));
            String format = String.format("Luminati SDK %s %s (%s)", new Object[]{"1.177.86", str, get_device()});
            Intent intent = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", str3, (String) null));
            intent.putExtra("android.intent.extra.EMAIL", new String[]{str3});
            intent.putExtra("android.intent.extra.SUBJECT", format);
            intent.putExtra("android.intent.extra.TEXT", str2);
            activity.startActivity(Intent.createChooser(intent, "Send to..."));
        } catch (Exception e2) {
            zerr(3, "share file failed: " + e2);
        }
    }

    public static void sleep_ms(int i) {
        try {
            Thread.sleep((long) i);
        } catch (InterruptedException unused) {
        }
    }

    public static void start_svc_client(String str) {
        if (m_svc_client != null) {
            try {
                m_svc_client.start(str);
            } catch (Exception e2) {
                perr(3, "svc_client_start_exception", e2.getMessage(), e2s(e2), true);
            }
        }
    }

    public static void start_svc_host(final Context context, final String str) {
        perr_funnel_main_send("01_svc_host_start", str);
        m_bcast_client.reset();
        new Timer().schedule(new TimerTask() {
            public void run() {
                if (!util.m_bcast_client.is_connected()) {
                    if (util.ACTION_SVC_KEEPALIVE.equals(str)) {
                        util.perr("svc_host_keepalive");
                    }
                    svc_host.start(context, util.m_uuid);
                }
            }
        }, ItemTouchHelper.Callback.DRAG_SCROLL_ACCELERATION_LIMIT_TIME_MS);
    }

    public static void start_svc_thread(String str) {
        if (is_bcast_client()) {
            bcast_client_svc_action("start_svc", str);
        } else {
            start_svc_client(str);
        }
    }

    public static void stop_svc_client(String str) {
        if (m_svc_client != null) {
            try {
                m_svc_client.destroy(str);
            } catch (Exception e2) {
                perr(3, "svc_client_stop_exception", e2.getMessage(), e2s(e2), true);
            }
        }
    }

    public static void stop_svc_thread(String str) {
        if (is_bcast_client()) {
            bcast_client_svc_action("stop_svc", str);
        } else {
            stop_svc_client(str);
        }
    }

    public static byte[] str2bytes(String str) {
        return str.getBytes();
    }

    public static String str2query(String str, String str2) {
        try {
            return URLEncoder.encode(str, "UTF-8") + "=" + URLEncoder.encode(str2, "UTF-8");
        } catch (UnsupportedEncodingException unused) {
            zerr(3, "unsupported encoding");
            return null;
        }
    }

    public static void take_screenshot(Context context, String str, Window window) {
        if (!m_screenshots.containsKey(str)) {
            try {
                View rootView = window.getDecorView().getRootView();
                rootView.setDrawingCacheEnabled(true);
                Bitmap createBitmap = Bitmap.createBitmap(rootView.getDrawingCache());
                rootView.setDrawingCacheEnabled(false);
                File createTempFile = File.createTempFile(str, ".jpg", context.getExternalCacheDir());
                FileOutputStream fileOutputStream = new FileOutputStream(createTempFile);
                createBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                m_screenshots.put(str, createTempFile);
                add_sdk_state_file("screenshots/" + str, createTempFile.getAbsolutePath());
            } catch (Throwable th) {
                perr(3, a.a("screenshot_failed_", str), th.getMessage(), "", true);
            }
        }
    }

    public static JSONObject thread_info(String str, String str2, String str3, int i) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("bt", str3);
            jSONObject.put("group", str);
            jSONObject.put("info", str2);
            jSONObject.put("start", new Date());
            jSONObject.put("timeout", i);
        } catch (JSONException e2) {
            perr("thread_stringify", "" + e2);
        }
        return jSONObject;
    }

    public static Thread thread_run(Runnable runnable) {
        StringBuilder a2 = a.a("tid");
        a2.append(thread_id.get());
        return thread_run(runnable, a2.toString());
    }

    public static Thread thread_run(Runnable runnable, String str) {
        return thread_run(runnable, str, "", 0);
    }

    public static Thread thread_run(Runnable runnable, String str, int i) {
        return thread_run(runnable, str, "", i);
    }

    public static Thread thread_run(Runnable runnable, String str, String str2) {
        return thread_run(runnable, str, str2, 0);
    }

    public static Thread thread_run(Runnable runnable, String str, String str2, int i) {
        JSONObject thread_info = thread_info(str, str2, bt_get(), i);
        thread_id.incrementAndGet();
        Thread thread = new Thread(new g1(thread_info, i, runnable, str, str2), str);
        thread.start();
        return thread;
    }

    public static long time_monotonic_ms() {
        return System.nanoTime() / ParallaxTarget.PropertyValuesHolderTarget.PSEUDO_DURATION;
    }

    @TargetApi(21)
    public static void unregister_network_callback(ConnectivityManager connectivityManager, ConnectivityManager.NetworkCallback networkCallback) {
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception unused) {
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:51:0x00b2 A[SYNTHETIC, Splitter:B:51:0x00b2] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00b8 A[SYNTHETIC, Splitter:B:55:0x00b8] */
    /* JADX WARNING: Removed duplicated region for block: B:66:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean unzip(java.io.File r7, java.io.File r8, boolean r9) {
        /*
            r0 = 4096(0x1000, float:5.74E-42)
            r1 = 0
            r2 = 1
            r3 = 0
            byte[] r0 = new byte[r0]     // Catch:{ IOException -> 0x00ac }
            java.util.zip.ZipInputStream r4 = new java.util.zip.ZipInputStream     // Catch:{ IOException -> 0x00ac }
            java.io.BufferedInputStream r5 = new java.io.BufferedInputStream     // Catch:{ IOException -> 0x00ac }
            java.io.FileInputStream r6 = new java.io.FileInputStream     // Catch:{ IOException -> 0x00ac }
            r6.<init>(r7)     // Catch:{ IOException -> 0x00ac }
            r5.<init>(r6)     // Catch:{ IOException -> 0x00ac }
            r4.<init>(r5)     // Catch:{ IOException -> 0x00ac }
        L_0x0016:
            java.util.zip.ZipEntry r7 = r4.getNextEntry()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r7 == 0) goto L_0x009f
            if (r9 == 0) goto L_0x002b
            java.lang.String r3 = r7.getName()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r5 = "liblumsdk_svc-"
            boolean r3 = r3.contains(r5)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r3 != 0) goto L_0x002b
            goto L_0x0016
        L_0x002b:
            java.lang.String r3 = r7.getName()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r5 = "/"
            int r5 = r3.lastIndexOf(r5)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            int r5 = r5 + r2
            int r6 = r3.length()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r3 = r3.substring(r5, r6)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.io.File r5 = new java.io.File     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r9 == 0) goto L_0x0043
            goto L_0x0047
        L_0x0043:
            java.lang.String r3 = r7.getName()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
        L_0x0047:
            r5.<init>(r8, r3)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            boolean r3 = r7.isDirectory()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r3 == 0) goto L_0x0052
            r3 = r5
            goto L_0x0056
        L_0x0052:
            java.io.File r3 = r5.getParentFile()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
        L_0x0056:
            boolean r6 = r3.isDirectory()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r6 != 0) goto L_0x007e
            boolean r6 = r3.mkdirs()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r6 == 0) goto L_0x0063
            goto L_0x007e
        L_0x0063:
            java.io.FileNotFoundException r7 = new java.io.FileNotFoundException     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            r8.<init>()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r9 = "Failed to ensure directory: "
            r8.append(r9)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r9 = r3.getAbsolutePath()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            r8.append(r9)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            java.lang.String r8 = r8.toString()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            r7.<init>(r8)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            throw r7     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
        L_0x007e:
            boolean r7 = r7.isDirectory()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            if (r7 == 0) goto L_0x0085
            goto L_0x0016
        L_0x0085:
            java.io.FileOutputStream r7 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            r7.<init>(r5)     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
        L_0x008a:
            int r3 = r4.read(r0)     // Catch:{ all -> 0x009a }
            r5 = -1
            if (r3 == r5) goto L_0x0095
            r7.write(r0, r1, r3)     // Catch:{ all -> 0x009a }
            goto L_0x008a
        L_0x0095:
            r7.close()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            goto L_0x0016
        L_0x009a:
            r8 = move-exception
            r7.close()     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
            throw r8     // Catch:{ IOException -> 0x00a7, all -> 0x00a4 }
        L_0x009f:
            r4.close()     // Catch:{ IOException -> 0x00a2 }
        L_0x00a2:
            r1 = 1
            goto L_0x00b5
        L_0x00a4:
            r7 = move-exception
            r3 = r4
            goto L_0x00b6
        L_0x00a7:
            r7 = move-exception
            r3 = r4
            goto L_0x00ad
        L_0x00aa:
            r7 = move-exception
            goto L_0x00b6
        L_0x00ac:
            r7 = move-exception
        L_0x00ad:
            r7.printStackTrace()     // Catch:{ all -> 0x00aa }
            if (r3 == 0) goto L_0x00b5
            r3.close()     // Catch:{ IOException -> 0x00b5 }
        L_0x00b5:
            return r1
        L_0x00b6:
            if (r3 == 0) goto L_0x00bb
            r3.close()     // Catch:{ IOException -> 0x00bb }
        L_0x00bb:
            goto L_0x00bd
        L_0x00bc:
            throw r7
        L_0x00bd:
            goto L_0x00bc
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.util.unzip(java.io.File, java.io.File, boolean):boolean");
    }

    public static boolean unzip(String str, String str2, boolean z) {
        return unzip(new File(str), new File(str2), z);
    }

    public static void update_sdk_info() {
        synchronized (m_logs) {
            if (!is_sdk_state_restricted()) {
                m_conf.set(conf.SDK_STATE_INFO, TextUtils.join("\n", m_logs));
            }
        }
    }

    public static void util_dbg_set() {
        StrictMode.ThreadPolicy build = new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectAll().penaltyLog().build();
        StrictMode.VmPolicy build2 = new StrictMode.VmPolicy.Builder().detectAll().penaltyLog().penaltyDeath().build();
        StrictMode.setThreadPolicy(build);
        StrictMode.setVmPolicy(build2);
    }

    public static util util_get() {
        if (instance == null) {
            instance = new util();
        }
        return instance;
    }

    public static int util_init(Context context, String str) {
        return util_init(context, str, (String) null);
    }

    public static synchronized int util_init(final Context context, String str, String str2) {
        synchronized (util.class) {
            int i = m_ref + 1;
            m_ref = i;
            if (i > 1) {
                int i2 = m_util_init_ret;
                return i2;
            }
            Util.SUPRESS_DEBUG_EXCEPTIONS = true;
            apkid = context.getPackageName();
            is_test_app(apkid);
            m_app_name = str;
            create_actions(apkid);
            String str3 = get_workdir(context);
            zerr_init(context, str3);
            zerr_printf(log_hdr());
            m_conf = new conf(context);
            m_secure_conf = secure_conf.get_instance(context);
            get_uuid(context);
            m_perr.init(context, m_app_name);
            m_conf.register_listener(new conf.listener() {
                public void on_changed(conf.key key) {
                    if (key == conf.PERR_DB_ENABLED && util.m_perr != null) {
                        util.m_perr.reset(context);
                    }
                }
            });
            set_tracking_id(context, str2);
            set_bcast_client(context);
            create_sdk_proxy_pool();
            m_perr_pool = perr_pool.get_instance();
            if (str3 != null) {
                m_conf.set(conf.WORKDIR, str3);
            }
            is_tv(context);
            is_miui(context);
            is_online(context);
            create_notification_channel(context);
            m_util_init_ret = 0;
            if (m_app_name.startsWith("svc")) {
                usage.init(context);
            }
            int i3 = m_util_init_ret;
            return i3;
        }
    }

    public static void util_mkdir(Context context) {
        zerr_mkdir(context);
        mkdir_p(m_path);
    }

    public static void util_reinit_workdir(Context context, String str) {
        synchronized (util.class) {
            zerr_uninit();
            m_conf.set(conf.WORKDIR, str);
            zerr_init(context, str);
            zerr_printf(log_hdr());
        }
    }

    public static void util_uninit() {
        synchronized (util.class) {
            int i = m_ref - 1;
            m_ref = i;
            if (i == 0) {
                if (m_perr_inited) {
                    perr_uninit();
                }
                zerr_uninit();
                usage.uninit();
            }
        }
    }

    public static int version_cmp(String str, String str2) {
        if (str == null) {
            return -1;
        }
        if (str2 == null) {
            return 1;
        }
        String[] split = str.split("\\.");
        String[] split2 = str2.split("\\.");
        int i = 0;
        while (i < split.length && i < split2.length && atoi(split[i]) == atoi(split2[i])) {
            i++;
        }
        if (i == 3) {
            return 0;
        }
        return atoi(split[i]) - atoi(split2[i]);
    }

    public static int zerr(int i, String str) {
        return _zerr("lumsdk/util", i, str);
    }

    public static void zerr2log(String str, int i, String str2) {
        if (i != 7 && i != 6 && i != 5 && i != 4 && i != 3 && i == 2) {
            Log.wtf(str, str2);
        }
    }

    public static boolean zerr_check(int i) {
        return zerr_get_severity(i) <= zerr_level;
    }

    public static int zerr_get_flags(int i) {
        return i & 65280;
    }

    public static int zerr_get_severity(int i) {
        return i & 15;
    }

    public static void zerr_init(Context context, String str) {
        synchronized (m_zerr_lock) {
            String zerr_mkdir = zerr_mkdir(context);
            m_path = zerr_mkdir + "/ext/log";
            if (str != null) {
                String str2 = str + "/log";
                m_path = str2;
                mkdir_p(str2);
                scandir(zerr_mkdir + "/ext/log", j1.f7282a, (Object) null);
                rmdir_recursive(zerr_mkdir + "/ext");
            }
        }
    }

    public static String zerr_level2severity_str(int i) {
        return zerr_severity_str[zerr_get_severity(i)];
    }

    public static String zerr_mkdir(Context context) {
        String str = get_cachedir(context);
        String str2 = str + "/log";
        mkdir_p(str2);
        m_zerr_file = new File(String.format("%s/lum_sdk_%s.log", new Object[]{str2, m_app_name}));
        if ("app".equals(m_app_name) && !m_zerr_file.exists()) {
            IS_FIRST_RUN = true;
            zerr(5, "set is_first_run");
        }
        try {
            fix_disabled(context);
            m_zerr_filewriter = new FileWriter(m_zerr_file, true);
            if (!m_membuf.equals("")) {
                zerr_printf(m_membuf);
                m_membuf = "";
            }
        } catch (IOException e2) {
            "zerr_mkdir failed: " + e2;
        }
        return str;
    }

    public static void zerr_printf(String str) {
        m_zerr_ex.submit(new i1(str));
    }

    public static int zerr_str2level(String str) {
        int i = 0;
        while (true) {
            String[] strArr = zerr_severity_str;
            if (i >= strArr.length) {
                return -1;
            }
            if (strArr[i].equals(str)) {
                return i;
            }
            i++;
        }
    }

    public static void zerr_uninit() {
        synchronized (m_zerr_lock) {
            if (m_zerr_filewriter != null) {
                try {
                    m_zerr_filewriter.flush();
                    m_zerr_filewriter.close();
                } catch (IOException unused) {
                }
                m_zerr_filewriter = null;
            }
        }
    }

    public cmd_resp exec(String[] strArr) {
        int i;
        StringBuilder sb = new StringBuilder();
        try {
            Process exec = Runtime.getRuntime().exec(strArr);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getErrorStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
            }
            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            while (true) {
                String readLine2 = bufferedReader2.readLine();
                if (readLine2 == null) {
                    break;
                }
                sb.append(readLine2);
            }
            i = exec.waitFor();
        } catch (Exception e2) {
            sb.append(e2);
            i = 0;
        }
        return new cmd_resp(sb.toString(), i);
    }
}
