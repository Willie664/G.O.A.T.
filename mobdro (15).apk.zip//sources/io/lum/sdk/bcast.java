package io.lum.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import androidx.core.app.NotificationCompat;
import b.a.a.a.a;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public abstract class bcast {
    public static String CLIENT_INIT = null;
    public static String CLIENT_REQ = null;
    public static String SERVER_INIT = null;
    public static String SERVER_NOTIFY = null;
    public static String SERVER_NOTIFY_BW = null;
    public static String SERVER_RESP = null;
    public static String SERVER_START = null;
    public static final int ZERR_MSG_LVL = 7;

    public static class base {
        public Context m_ctx;

        public base(Context context) {
            Context applicationContext = context.getApplicationContext();
            this.m_ctx = applicationContext;
            String packageName = applicationContext.getPackageName();
            String unused = bcast.CLIENT_INIT = packageName + ".bcast.client_init";
            String unused2 = bcast.SERVER_INIT = packageName + ".bcast.server_init";
            String unused3 = bcast.SERVER_START = packageName + ".bcast.server_start";
            String unused4 = bcast.CLIENT_REQ = packageName + ".bcast.client_req";
            String unused5 = bcast.SERVER_RESP = packageName + ".bcast.server_resp";
            String unused6 = bcast.SERVER_NOTIFY = packageName + ".bcast.server_notify";
            bcast.SERVER_NOTIFY_BW = packageName + ".bcast.server_notify_bw";
        }
    }

    public static class client extends base {
        public Boolean m_is_connected = false;
        public ArrayList<listener> m_listeners = new ArrayList<>();
        public Runnable m_on_start = new Runnable() {
            public void run() {
                Boolean unused = client.this.m_is_connected = true;
                client.this.send_scheduled();
            }
        };
        public final HashMap<String, task> m_queue = new HashMap<>();
        public bcast_recv m_receiver;
        public String m_receiver_id;
        public String m_service_id;
        public final ArrayList<Intent> m_task_queue = new ArrayList<>();

        public class bcast_recv extends BroadcastReceiver {
            public static final /* synthetic */ boolean $assertionsDisabled = false;

            public bcast_recv() {
            }

            public void onReceive(Context context, Intent intent) {
                String action;
                HashMap access$900;
                if (intent != null && (action = intent.getAction()) != null) {
                    if (bcast.SERVER_START.equals(action)) {
                        client.this.zerr(7, "server started, attaching");
                        client.this.m_queue.remove(client.this.m_receiver_id);
                        client.this.get_svc_state("server start");
                        return;
                    }
                    String stringExtra = intent.getStringExtra("service_id");
                    String stringExtra2 = intent.getStringExtra("receiver_id");
                    if (stringExtra != null) {
                        if (bcast.SERVER_INIT.equals(action) && !stringExtra.equals(client.this.m_service_id)) {
                            client.this.zerr(5, "server registered");
                        }
                        String unused = client.this.m_service_id = stringExtra;
                        if (bcast.SERVER_NOTIFY.equals(action)) {
                            Bundle bundleExtra = intent.getBundleExtra(NotificationCompat.CATEGORY_EVENT);
                            Iterator it = client.this.m_listeners.iterator();
                            while (it.hasNext()) {
                                ((listener) it.next()).on_notify(bundleExtra);
                            }
                        } else if (client.this.m_receiver_id.equals(stringExtra2)) {
                            String stringExtra3 = intent.getStringExtra("task_id");
                            client client = client.this;
                            client.zerr(7, "new message [" + stringExtra3 + "]: " + action);
                            synchronized (client.this.m_queue) {
                                if (!client.this.m_queue.containsKey(stringExtra3)) {
                                    bcast.send_perr("task_not_found", stringExtra3);
                                    return;
                                }
                                try {
                                    ((task) client.this.m_queue.get(stringExtra3)).run();
                                    access$900 = client.this.m_queue;
                                } catch (Exception e2) {
                                    bcast.send_perr("task_execution_failed", e2.getMessage());
                                    access$900 = client.this.m_queue;
                                } catch (Throwable th) {
                                    client.this.m_queue.remove(stringExtra3);
                                    throw th;
                                }
                                access$900.remove(stringExtra3);
                            }
                        }
                    }
                }
            }
        }

        public static abstract class listener {
            public abstract void on_notify(Bundle bundle);
        }

        public class task {
            public Date m_date = new Date();
            public Runnable m_r;

            public task(Runnable runnable) {
                if (runnable != null) {
                    this.m_r = runnable;
                }
            }

            public void run() {
                Runnable runnable = this.m_r;
                if (runnable != null) {
                    runnable.run();
                }
            }
        }

        public client(Context context) {
            super(context);
            create_receiver();
            get_id();
            get_svc_state("start");
            zerr(5, "created");
        }

        private void _send(Intent intent, String str) {
            _send(intent, str, false);
        }

        private void _send(final Intent intent, final String str, boolean z) {
            intent.putExtra("service_id", this.m_service_id);
            this.m_ctx.sendBroadcast(intent);
            if (!z) {
                new Timer().schedule(new TimerTask() {
                    public void run() {
                        synchronized (client.this.m_queue) {
                            if (client.this.m_queue.containsKey(str)) {
                                client.this.m_queue.remove(str);
                                String format = String.format("id: %s, intent: %s, timeout: %sms", new Object[]{str, intent.toString(), 30000L});
                                bcast.send_perr("req_timeout", format);
                                client client = client.this;
                                client.zerr(3, "request timeout: " + format);
                            }
                        }
                    }
                }, 30000);
            }
        }

        private void create_receiver() {
            this.m_receiver_id = UUID.randomUUID().toString();
            this.m_receiver = new bcast_recv() {
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(bcast.SERVER_START);
            intentFilter.addAction(bcast.SERVER_INIT);
            intentFilter.addAction(bcast.SERVER_RESP);
            intentFilter.addAction(bcast.SERVER_NOTIFY);
            this.m_ctx.registerReceiver(this.m_receiver, intentFilter);
        }

        /* access modifiers changed from: private */
        public void get_svc_state(String str) {
            zerr(5, a.a("get state: ", str));
            send_intent(bcast.CLIENT_INIT, (Bundle) null, this.m_on_start, true, this.m_receiver_id, false);
        }

        private void send_intent(String str, Bundle bundle, Runnable runnable, Boolean bool, String str2, boolean z) {
            synchronized (this.m_queue) {
                this.m_queue.put(str2, new task(runnable));
            }
            Intent intent = new Intent(str);
            intent.putExtra("notify", z);
            intent.putExtra("task_id", str2);
            intent.putExtra("receiver_id", this.m_receiver_id);
            String str3 = this.m_service_id;
            if (str3 != null) {
                intent.putExtra("service_id", str3);
            }
            if (bundle != null) {
                intent.putExtra("data", bundle);
            }
            if (bool.booleanValue() || this.m_is_connected.booleanValue()) {
                _send(intent, str2, bool.booleanValue());
                return;
            }
            synchronized (this.m_task_queue) {
                this.m_task_queue.add(intent);
            }
        }

        /* access modifiers changed from: private */
        public void send_scheduled() {
            synchronized (this.m_task_queue) {
                Iterator<Intent> it = this.m_task_queue.iterator();
                while (it.hasNext()) {
                    Intent next = it.next();
                    _send(next, next.getStringExtra("task_id"));
                }
                this.m_task_queue.clear();
            }
        }

        /* access modifiers changed from: private */
        public void zerr(int i, String str) {
            StringBuilder a2 = a.a("lumsdk/bcast/client/");
            a2.append(this.m_receiver_id);
            util._zerr(a2.toString(), i, str);
        }

        public void add_listener(listener listener2) {
            this.m_listeners.add(listener2);
        }

        public String get_id() {
            return this.m_receiver_id;
        }

        public boolean is_connected() {
            return this.m_is_connected.booleanValue();
        }

        public void reset() {
            if (this.m_is_connected.booleanValue()) {
                this.m_is_connected = false;
                String str = this.m_receiver_id;
                zerr(5, "reset");
                get_id();
                zerr(5, "created from " + str);
                get_svc_state("reset");
            }
        }

        public void send_request(Bundle bundle, boolean z) {
            send_intent(bcast.CLIENT_REQ, bundle, (Runnable) null, false, UUID.randomUUID().toString(), z);
        }
    }

    public static abstract class server extends base {
        public HashMap<String, String> m_msgs;
        public bcast_recv m_receiver;
        public String m_service_id;

        public class bcast_recv extends BroadcastReceiver {
            public bcast_recv() {
            }

            /* JADX WARNING: Code restructure failed: missing block: B:3:0x004c, code lost:
                r4 = r8.this$0.on_receive(r2);
             */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void onReceive(android.content.Context r9, android.content.Intent r10) {
                /*
                    r8 = this;
                    java.lang.String r9 = r10.getAction()     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r0 = "task_id"
                    java.lang.String r0 = r10.getStringExtra(r0)     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r1 = "receiver_id"
                    java.lang.String r1 = r10.getStringExtra(r1)     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r2 = "data"
                    android.os.Bundle r2 = r10.getBundleExtra(r2)     // Catch:{ NullPointerException -> 0x0068 }
                    io.lum.sdk.bcast$server r3 = io.lum.sdk.bcast.server.this     // Catch:{ NullPointerException -> 0x0068 }
                    java.util.HashMap r3 = r3.m_msgs     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.Object r3 = r3.get(r9)     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r3 = (java.lang.String) r3     // Catch:{ NullPointerException -> 0x0068 }
                    io.lum.sdk.bcast$server r4 = io.lum.sdk.bcast.server.this     // Catch:{ NullPointerException -> 0x0068 }
                    r5 = 7
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ NullPointerException -> 0x0068 }
                    r6.<init>()     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r7 = "new message ["
                    r6.append(r7)     // Catch:{ NullPointerException -> 0x0068 }
                    r6.append(r0)     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r7 = "]: "
                    r6.append(r7)     // Catch:{ NullPointerException -> 0x0068 }
                    r6.append(r9)     // Catch:{ NullPointerException -> 0x0068 }
                    java.lang.String r6 = r6.toString()     // Catch:{ NullPointerException -> 0x0068 }
                    r4.zerr(r5, r6)     // Catch:{ NullPointerException -> 0x0068 }
                    r4 = 1
                    java.lang.String r5 = io.lum.sdk.bcast.CLIENT_REQ     // Catch:{ NullPointerException -> 0x0068 }
                    boolean r9 = r5.equals(r9)     // Catch:{ NullPointerException -> 0x0068 }
                    if (r9 == 0) goto L_0x0062
                    io.lum.sdk.bcast$server r9 = io.lum.sdk.bcast.server.this     // Catch:{ NullPointerException -> 0x0068 }
                    boolean r4 = r9.on_receive(r2)     // Catch:{ NullPointerException -> 0x0068 }
                    if (r4 == 0) goto L_0x0062
                    java.lang.String r9 = "notify"
                    r5 = 0
                    boolean r9 = r10.getBooleanExtra(r9, r5)     // Catch:{ NullPointerException -> 0x0068 }
                    if (r9 == 0) goto L_0x0062
                    io.lum.sdk.bcast$server r9 = io.lum.sdk.bcast.server.this     // Catch:{ NullPointerException -> 0x0068 }
                    r9.send_notification(r2)     // Catch:{ NullPointerException -> 0x0068 }
                L_0x0062:
                    io.lum.sdk.bcast$server r9 = io.lum.sdk.bcast.server.this     // Catch:{ NullPointerException -> 0x0068 }
                    r9.send_reply(r3, r0, r1, r4)     // Catch:{ NullPointerException -> 0x0068 }
                    goto L_0x0072
                L_0x0068:
                    r9 = move-exception
                    java.lang.String r9 = io.lum.sdk.util.e2s(r9)
                    java.lang.String r10 = "bcast_exception"
                    io.lum.sdk.bcast.send_perr(r10, r9)
                L_0x0072:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.bcast.server.bcast_recv.onReceive(android.content.Context, android.content.Intent):void");
            }
        }

        public server(Context context, String str) {
            super(context);
            this.m_service_id = str == null ? UUID.randomUUID().toString() : str;
            HashMap<String, String> hashMap = new HashMap<>();
            this.m_msgs = hashMap;
            hashMap.put(bcast.CLIENT_INIT, bcast.SERVER_INIT);
            this.m_msgs.put(bcast.CLIENT_REQ, bcast.SERVER_RESP);
            create_receiver();
            Intent intent = new Intent(bcast.SERVER_START);
            intent.putExtra("task_id", str);
            intent.putExtra("receiver_id", str);
            send_broadcast(intent);
            zerr(5, "created");
        }

        private void create_receiver() {
            this.m_receiver = new bcast_recv();
            IntentFilter intentFilter = new IntentFilter();
            for (String addAction : this.m_msgs.keySet()) {
                intentFilter.addAction(addAction);
            }
            this.m_ctx.registerReceiver(this.m_receiver, intentFilter);
        }

        private void destroy_receiver() {
            this.m_ctx.unregisterReceiver(this.m_receiver);
        }

        private void send_broadcast(Intent intent) {
            intent.putExtra("service_id", this.m_service_id);
            this.m_ctx.sendBroadcast(intent);
        }

        /* access modifiers changed from: private */
        public void send_reply(String str, String str2, String str3, boolean z) {
            Intent intent = new Intent(str);
            intent.putExtra("task_id", str2);
            intent.putExtra("receiver_id", str3);
            intent.putExtra("success", z);
            send_broadcast(intent);
        }

        /* access modifiers changed from: private */
        public void zerr(int i, String str) {
            StringBuilder a2 = a.a("lumsdk/bcast/server/");
            a2.append(this.m_service_id);
            util._zerr(a2.toString(), i, str);
        }

        public void destroy() {
            destroy_receiver();
        }

        public abstract boolean on_receive(Bundle bundle);

        public void send_notification(Bundle bundle) {
            send_notification(bundle, bcast.SERVER_NOTIFY);
        }

        public void send_notification(Bundle bundle, String str) {
            Intent intent = new Intent(str);
            intent.putExtra(NotificationCompat.CATEGORY_EVENT, bundle);
            send_broadcast(intent);
        }
    }

    public static void send_perr(String str, String str2) {
        util.perr(3, str, str2, "", true);
    }
}
