package io.lum.sdk;

import android.content.Context;
import io.lum.sdk.set_strict;
import java.util.HashMap;
import java.util.Map;

public class conf extends set_strict<key> {
    public static final key APK_CONFIG = new key("apk_config");
    public static final key APK_CONFIG_LAST_UPDATE = new key("apk_config_last_update");
    public static final key BLACKLISTED = new key("blacklisted");
    public static final key CACHE_PERR_HOST = new key("cache_perr_host");
    public static final key CACHE_PERR_HOST_TS = new key("cache_perr_host_ts");
    public static final key CACHE_PERR_HOST_TTL = new key("cache_perr_host_ttl");
    public static final key CACHE_SPROXY_DOMAIN = new key("cache_proxy_domain");
    public static final key CACHE_SPROXY_DOMAIN_TS = new key("cache_proxy_domain_ts");
    public static final key CACHE_SPROXY_DOMAIN_TTL = new key("cache_proxy_domain_ttl");
    public static final key CACHE_SPROXY_HOST = new key("cache_proxy_host");
    public static final key CACHE_SPROXY_HOST_TS = new key("cache_proxy_host_ts");
    public static final key CACHE_SPROXY_HOST_TTL = new key("cache_proxy_host_ttl");
    public static final key CACHE_SPROXY_PORT = new key("cache_proxy_port");
    public static final key CACHE_SPROXY_PORT_TS = new key("cache_proxy_port_ts");
    public static final key CACHE_SPROXY_PORT_TTL = new key("cache_proxy_port_ttl");
    public static final key CCGI_SSL_HOST = new key("ccgi_ssl_host");
    public static final key CHOICE = new key("choice");
    public static final key CID_KEY = new key("cid_key");
    public static final key CID_KV = new key("cid_kv");
    public static final key CID_VALUE = new key("cid_value");
    public static final key CLOUD_CONFIG = new key("cloud_config");
    public static final key CLOUD_CONFIG_LAST_UPDATE = new key("cloud_config_last_update");
    public static final key COUNTRY_LOCAL_MYIP = new key("country_local_myip");
    public static final key CURR_MOBILE_USAGE_DATE = new key("curr_mobile_usage_date");
    public static final key DAILY_MOBILE_USAGE = new key("daily_mobile_usage");
    public static final key DAILY_MOBILE_USAGE_APP = new key("daily_mobile_usage_app");
    public static final key DBG_FORCE_PROXY = new key("dbg_force_proxy");
    public static final key DBG_MOBILE = new key("dbg_mobile");
    public static final key DBG_ROAMING = new key("dbg_roaming");
    public static final key DBG_TV = new key("dbg_tv");
    public static final key DISABLE_TLS1 = new key("support_tls1");
    public static final key FORCE_IS_DEBUG = new key("force_is_debug");
    public static final key FUNNEL_01_API_INIT = new key("01_api_init");
    public static final key FUNNEL_02_POPUP_CALL = new key("02_popup_call");
    public static final key FUNNEL_03_POPUP_DISPLAY = new key("03_popup_display");
    public static final key FUNNEL_04_DIALOG_CHOSE_PEER = new key("04_dialog_chose_peer");
    public static final key FUNNEL_05_SERVICE_START_FAIL = new key("05_service_start_fail");
    public static final key FUNNEL_06_SERVICE_START = new key("06_service_start");
    public static final key FUNNEL_17_BCAST_RECV_SVC_START = new key("17_bcast_recv_svc_start");
    public static final key FUNNEL_18_SVC_INIT = new key("18_svc_init");
    public static final key FUNNEL_19_SVC_CONNECTED = new key("19_svc_connected");
    public static final key FUNNEL_20_SVC_TUN_READY = new key("20_svc_tun_ready");
    public static final key FUNNEL_21_SVC_TUN_START = new key("21_svc_tun_start");
    public static final key FUNNEL_22_SVC_TUN_1B = new key("22_svc_tun_1b");
    public static final key FUNNEL_30_SVC_UP_5MIN = new key("30_svc_up_5min");
    public static final key FUNNEL_32_SVC_UP_30MIN = new key("32_svc_up_30min");
    public static final key FUNNEL_34_SVC_UP_1H = new key("34_svc_up_1h");
    public static final key FUNNEL_36_SVC_UP_2H = new key("36_svc_up_2h");
    public static final key FUNNEL_38_SVC_UP_6H = new key("38_svc_up_6h");
    public static final key FUNNEL_40_SVC_UP_12H = new key("40_svc_up_12h");
    public static final key FUNNEL_CHECK = new key("funnel_check");
    public static final key FUNNEL_DEV_00_MONITOR_INIT = new key("dev_00_monitor_init");
    public static final key FUNNEL_DEV_01_MONITOR_START = new key("dev_01_monitor_start");
    public static final key FUNNEL_DEV_02_CONN_UP = new key("dev_02_conn_up");
    public static final key FUNNEL_DEV_03_CONN_TEST_PASS = new key("dev_03_conn_test_pass");
    public static final key FUNNEL_DEV_04_CONN_INIT = new key("dev_04_conn_init");
    public static final key FUNNEL_DEV_05_CONN_FAIL = new key("dev_05_conn_fail");
    public static final key FUNNEL_DEV_05_CONN_OK = new key("dev_05_conn_ok");
    public static final key FUNNEL_DEV_06_TUN_INIT = new key("dev_06_tun_init");
    public static final key FUNNEL_DEV_07_TUN_USE = new key("dev_07_tun_use");
    public static final key FUNNEL_DEV_08_TUN_1B = new key("dev_08_tun_1b");
    public static final key FUNNEL_DISABLED = new key("funnel_disabled");
    public static final key INITED = new key("inited");
    public static final key INIT_VERSION = new key("init_version");
    public static final key INSTALL = new key("install");
    public static final key INSTALL_TS = new key("install_ts");
    public static final key INSTALL_VERSION = new key("install_version");
    public static final key IS_DEBUG = new key("is_debug");
    public static final key IS_DEBUG_LAYOUT = new key("is_debug_layout");
    public static final key IS_SUPPORTED_ERRID = new key("is_supported_errid");
    public static final key IS_SUPPORTED_ERRID_TS = new key("is_supported_errid_ts");
    public static final key IS_SUPPORTED_EXPIRE = new key("is_supported_expire");
    public static final key IS_SUPPORTED_TS = new key("is_supported_ts");
    public static final key LAST_NET_SVC_HEARTBEAT = new key("last_net_svc_heartbeat");
    public static final key LAST_ON_MOBILE = new key("last_on_mobile");
    public static final key LAST_SVC_HEARTBEAT = new key("last_svc_heartbeat");
    public static final key LAST_USAGE_PERR = new key("last_usage_perr");
    public static final key LAST_WORKING_HOST_CCGI = new key("last_working_host_ccgi");
    public static final key LAST_WORKING_PROT_CCGI = new key("last_working_prot_ccgi");
    public static final key LAST_WORKING_PROXY_CCGI = new key("last_working_proxy_ccgi");
    public static final key MAX_JOB_ID = new key("max_job_id");
    public static final key MIN_JOB_ID = new key("min_job_id");
    public static final key MOBILE_USAGE_SINCE_BOOT = new key("mobile_usage_since_boot");
    public static final key NET_SVC_HEARTBEAT_COUNT = new key("net_svc_heartbeat_count");
    public static final key NON_FIRST_RUN = new key("not_first_run");
    public static final key PARTNERID = new key("partnerid");
    public static final key PERR_DB_ENABLED = new key("perr_db_enabled");
    public static final key PERR_IDS = new key("perr_ids");
    public static final key PERR_MIN_VER = new key("perr_min_ver");
    public static final key PERR_SEND_PENDING_INSTALL = new key("perr_send_install");
    public static final key PERR_SEND_PENDING_OLD = new key("perr_send_pending_old");
    public static final key PERR_SEND_PENDING_UPDATE = new key("perr_send_update");
    public static final key PERR_SSL_HOST = new key("perr_ssl_host");
    public static final key PUSH_STATUS_REPORT = new key("push_status_report");
    public static final key PUSH_STATUS_REPORT_DELAY = new key("push_status_report_delay");
    public static final key PUSH_STATUS_REPORT_ERR_FREQ = new key("push_status_report_err_freq");
    public static final key PUSH_STATUS_REPORT_FREQ = new key("push_status_report_freq");
    public static final key REPEATING_ALARMS = new key("repeating_alarms");
    public static final key SDK_DISABLED = new key("sdk_disabled");
    public static final key SDK_DISABLED_UNTIL = new key("sdk_disabled_until");
    public static final key SDK_STATE_FILES = new key("sdk_state_files");
    public static final key SDK_STATE_INFO = new key("sdk_state_info");
    public static final key SDK_STATE_STATUS = new key("sdk_state_status");
    public static final key SECURE_CONF_MIGRATE = new key("secure_conf_migrate");
    public static final key SECURE_CONF_SIGNATURE = new key("secure_conf_signature");
    public static final key SECURE_CONF_SIGNATURE_TYPE = new key("secure_conf_signature_type");
    public static final key SECURE_CONF_UPDATE_TS = new key("secure_conf_update_ts");
    public static final key SPROXY_SSL = new key("sproxy_ssl");
    public static final key SPROXY_SSL_HOST = new key("sproxy_ssl_host");
    public static final key SVC_FALLBACK = new key("svc_fallback");
    public static final key SVC_FALLBACK_EMBED = new key("svc_fallback_embed");
    public static final key SVC_FALLBACK_FOR = new key("svc_fallback_for");
    public static final key SVC_FALLBACK_LEGACY = new key("svc_fallback_legacy");
    public static final key SVC_FALLBACK_UNTIL = new key("svc_fallback_until");
    public static final key SVC_JOB_KEEPALIVE_PERIOD = new key("svc_job_keepalive_period");
    public static final key SVC_JOB_KILL_PROCESS = new key("svc_job_kill_process");
    public static final key SVC_JOB_MAX_DURATION = new key("svc_job_max_duration");
    public static final key SVC_JOB_NEXT_RUN_DELAY = new key("svc_job_next_run_delay");
    public static final key SVC_KEEPALIVE_PERIOD = new key("svc_keepalive_period");
    public static final key SVC_THREAD_JAVA_CRASHES = new key("svc_thread_java_crashes");
    public static final key SVC_THREAD_JAVA_REVIVALS = new key("svc_thread_java_revivals");
    public static final key SVC_THREAD_JAVA_STUCKS = new key("svc_thread_java_stucks");
    public static final key TAKE_POPUP_SCREENSHOT = new key("take_popup_screenshot");
    public static final key TRACKING_ID = new key("tracking_id");
    public static final key UPDATE_TS = new key("update_ts");
    public static final key USAGE_SINCE_BOOT_APP = new key("usage_since_boot_app");
    public static final key USAGE_STATS = new key("usage_stats");
    public static final key USAGE_STATS_BYTES = new key("usage_stats_bytes");
    public static final key USAGE_STATS_QUALITY = new key("usage_stats_quality");
    public static final key USAGE_STATS_TS = new key("usage_stats_ts");
    public static final key UUID = new key("uuid");
    public static final key WORKDIR = new key("workdir");
    public static final key WS_CONN_PROXYJS = new key("ws_conn_proxyjs");
    public static final key WS_CONN_PROXYJS_EXT_IP_CHECK = new key("ws_conn_proxyjs_ext_ip_check");
    public static final key WS_CONN_PROXYJS_FORCE_IP = new key("ws_conn_proxyjs_force_ip");
    public static final key WS_CONN_PROXYJS_SPROXY = new key("ws_conn_proxyjs_sproxy");
    public static final key WS_CONN_ZAGENT = new key("ws_conn_zagent");
    public static final key WS_PING_PROXYJS = new key("ws_ping_proxyjs");
    public static final key WS_PING_PROXYJS_INTERVAL = new key("ws_ping_proxyjs_interval");
    public static final key WS_PING_PROXYJS_TIMEOUT = new key("ws_ping_proxyjs_timeout");
    public static final key WS_PING_ZAGENT = new key("ws_ping_zagent");
    public static final key WS_PING_ZAGENT_INTERVAL = new key("ws_ping_zagent_interval");
    public static final key WS_PING_ZAGENT_TIMEOUT = new key("ws_ping_zagent_timeout");

    public static class key {
        public static final Map<String, key> s_register = new HashMap();
        public final String m_name;

        public key(String str) {
            this.m_name = str;
            s_register.put(str, this);
        }

        public String toString() {
            return this.m_name;
        }
    }

    public static abstract class listener extends set_strict.listener<key> {
    }

    public conf(Context context) {
        super(context, "conf");
        synchronized (conf.class) {
            if (!get_bool(INITED, false)) {
                set(INSTALL, true);
                set(INITED, true);
                set(INIT_VERSION, "1.177.86");
                set(INSTALL_TS, System.currentTimeMillis());
            }
        }
    }

    public key resolve_key(String str) {
        return (key) key.s_register.get(str);
    }
}
