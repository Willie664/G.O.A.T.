package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import b.a.a.a.a;
import com.applovin.sdk.AppLovinMediationProvider;
import d.a.a.a0;
import d.a.a.b0;
import d.a.a.c0;
import d.a.a.d0;
import d.a.a.g;
import d.a.a.h;
import d.a.a.i;
import d.a.a.j;
import d.a.a.k;
import d.a.a.l;
import d.a.a.m;
import d.a.a.n;
import d.a.a.o;
import d.a.a.p;
import d.a.a.q;
import d.a.a.r;
import d.a.a.t;
import d.a.a.u;
import d.a.a.v;
import d.a.a.w;
import d.a.a.x;
import d.a.a.y;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpGet;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.conf;
import io.lum.sdk.perr;
import io.lum.sdk.state;
import io.lum.sdk.util;
import java.io.File;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class dev_conn {
    public ArrayList<cidr_utils> m_blocked_ips = new ArrayList<>();
    public String m_bw_path;
    public etask m_bw_task = null;
    public String m_cid;
    public conf m_conf;
    public String m_conf_dir;
    public boolean m_conn_init_err_perr_sent = false;
    public Context m_ctx;
    public dev m_dev;
    public boolean m_disable_proxyjs_resolve;
    public int m_domain_index = 0;
    public etask m_down_task = null;
    public AtomicReference<String> m_ext_ip = new AtomicReference<>((Object) null);
    public String m_force_proxy_domain;
    public String m_force_proxy_ip;
    public Integer m_force_proxy_port;
    public boolean m_ignore_local_ip = false;
    public String m_ip = "";
    public int m_ip_index;
    public boolean m_is_redirect = false;
    public boolean m_is_retry = false;
    public String m_last_proxy_domain = null;
    public String m_last_proxy_url = null;
    public int m_last_vfd = 1;
    public InetAddress m_local_ip;
    public String m_local_ip_addr;
    public JSONObject m_myip;
    public String m_myip_s;
    public int m_port_index = 0;
    public ArrayList<Integer> m_ports = zon_conf.PROXY_PORTS;
    public boolean m_proxy_alias_used = false;
    public int m_proxy_conn_fails = 0;
    public final int m_proxy_conn_fails_max = 3;
    public AtomicBoolean m_proxyjs_conn_mfr = new AtomicBoolean(false);
    public AtomicBoolean m_proxyjs_conn_sproxy = new AtomicBoolean(false);
    public String m_proxyjs_conn_sproxy_enable;
    public String m_proxyjs_conn_sproxy_host = "";
    public WebSocket m_proxyjs_ws = null;
    public boolean m_push_status_report_allowed = false;
    public boolean m_push_status_report_enabled;
    public long m_push_status_report_err_freq = 900000;
    public long m_push_status_report_freq = 300000;
    public boolean m_redirect_enabled = true;
    public state m_state;
    public state.listener m_state_listener = new state.listener() {
        public void on_changed(state.key key) {
            Iterator it = dev_conn.this.m_status_report_keys.iterator();
            while (it.hasNext()) {
                if (((report_key) it.next()).matches(key)) {
                    dev_conn.this.status_report(key.toString());
                    return;
                }
            }
        }
    };
    public final Object m_state_sync = new Object();
    public Timer m_status_report_allow_timer;
    public ArrayList<report_key> m_status_report_keys = new ArrayList<>();
    public final Object m_status_report_lock = new Object();
    public ArrayList<String> m_status_reports = new ArrayList<>();
    public etask<Boolean> m_test_socket_task = null;
    public int m_test_socket_task_timeout = 10000;
    public Timer m_test_socket_task_timer;
    public etask<Boolean> m_test_task = null;
    public JSONObject m_tun_bw_count = new JSONObject();
    public boolean m_tun_bw_dirty = false;
    public etask m_up_task = null;
    public String m_uuid;
    public int m_wait_ms = 1000;
    public wbm_server m_wbm_server = null;
    public final Object m_ws_sync = new Object();
    public HashSet<WebSocket> m_zagents_ws;
    public util.zerr m_zerr;
    public String m_zerr_tag;
    public final Object m_zws_sync = new Object();

    public static class milestone {
        public long m_dn = 0;
        public int m_index = 0;
        public stone[] m_stones = {new stone(1, "1b"), new stone(1000, "1kb"), new stone(10000, "10kb"), new stone(100000, "100kb")};
        public JSONArray m_timeline = new JSONArray();
        public long m_up = 0;

        public class stone {
            public String name;
            public int val;

            public stone(int i, String str) {
                this.val = i;
                this.name = str;
            }
        }

        public JSONArray flush() {
            JSONArray jSONArray = this.m_timeline;
            this.m_timeline = new JSONArray();
            return jSONArray;
        }

        public boolean update(int i, int i2) {
            long j = this.m_dn + ((long) i);
            this.m_dn = j;
            long j2 = (long) i2;
            long j3 = this.m_up + j2;
            this.m_up = j3;
            if (j == 0 && j3 != 0 && j3 == j2) {
                dev_util.timeline_push(this.m_timeline, "up_1b");
            }
            int i3 = this.m_index;
            stone[] stoneArr = this.m_stones;
            if (i3 >= stoneArr.length || this.m_dn < ((long) stoneArr[i3].val)) {
                return false;
            }
            JSONArray jSONArray = this.m_timeline;
            StringBuilder a2 = a.a("dn_");
            a2.append(this.m_stones[this.m_index].name);
            dev_util.timeline_push(jSONArray, a2.toString());
            this.m_index++;
            return true;
        }
    }

    public class report_key {
        public state.key m_key;
        public boolean m_value;

        public report_key(state.key key, boolean z) {
            this.m_key = key;
            this.m_value = z;
        }

        public boolean matches(state.key key) {
            return key == this.m_key && this.m_value == dev_conn.this.m_state.get_bool(key);
        }
    }

    public dev_conn(Context context, InetAddress inetAddress, dev dev) {
        this.m_dev = dev;
        this.m_ctx = context;
        this.m_uuid = util.get_uuid(context);
        conf conf = new conf(this.m_ctx);
        this.m_conf = conf;
        this.m_disable_proxyjs_resolve = conf.get_str(conf.WS_CONN_PROXYJS_FORCE_IP).equals("always");
        this.m_ip_index = new Random().nextInt(zon_conf.PROXY_IPS.size());
        String str = this.m_conf.get_bool(conf.DBG_FORCE_PROXY) ? "always" : this.m_conf.get_str(conf.WS_CONN_PROXYJS_SPROXY, "failure");
        this.m_proxyjs_conn_sproxy_enable = str;
        if (str.equals("always")) {
            this.m_proxyjs_conn_sproxy.set(true);
        }
        this.m_state = new state(this.m_ctx);
        this.m_local_ip = inetAddress;
        if (inetAddress != null) {
            this.m_local_ip_addr = inetAddress.getHostAddress();
        }
        this.m_zagents_ws = new HashSet<>();
        StringBuilder a2 = a.a("dev_conn/");
        a2.append(this.m_dev.m_name);
        a2.append("/");
        a2.append(this.m_local_ip_addr);
        String sb = a2.toString();
        this.m_zerr_tag = sb;
        this.m_zerr = new util.zerr(sb);
        boolean z = this.m_conf.get_bool(conf.PUSH_STATUS_REPORT, util.is_test_app(this.m_ctx.getPackageName()));
        this.m_push_status_report_enabled = z;
        if (z) {
            long j = this.m_conf.get_long(conf.PUSH_STATUS_REPORT_DELAY, secure_conf.MISMATCH_DELAY);
            this.m_push_status_report_freq = this.m_conf.get_long(conf.PUSH_STATUS_REPORT_FREQ, this.m_push_status_report_freq);
            this.m_push_status_report_err_freq = this.m_conf.get_long(conf.PUSH_STATUS_REPORT_ERR_FREQ, this.m_push_status_report_err_freq);
            this.m_status_report_keys.add(new report_key(state.SCREEN_ON, false));
            this.m_status_report_keys.add(new report_key(state.ON_CALL, false));
            this.m_status_report_keys.add(new report_key(state.USING_BATTERY, false));
            this.m_state.register_listener(this.m_state_listener);
            allow_status_report(true, j);
            util.zerr zerr = this.m_zerr;
            StringBuilder a3 = a.a("status report settings: ");
            a3.append(String.format("delay: %sms, freq: %sms, err freq: %sms", new Object[]{Long.valueOf(j), Long.valueOf(this.m_push_status_report_freq), Long.valueOf(this.m_push_status_report_err_freq)}));
            zerr.debug(a3.toString());
        }
        this.m_conf_dir = util.get_confdir(context);
        String a4 = a.a(new StringBuilder(), this.m_conf_dir, "/db");
        if (!util.file_exists(a4)) {
            util.mkdir(a4);
        }
        this.m_bw_path = a.a(a.b(a4, "/bw_"), this.m_dev.m_name, ".db");
    }

    private void allow_status_report(final boolean z, long j) {
        Timer timer = this.m_status_report_allow_timer;
        if (timer != null) {
            timer.cancel();
        }
        Timer timer2 = new Timer();
        this.m_status_report_allow_timer = timer2;
        timer2.schedule(new TimerTask() {
            public void run() {
                synchronized (dev_conn.this.m_status_report_lock) {
                    boolean unused = dev_conn.this.m_push_status_report_allowed = z;
                }
            }
        }, j);
    }

    private etask bw_store_init() {
        load_bw();
        this.m_tun_bw_dirty = false;
        return etask.interval(new o(this), secure_conf.MISMATCH_DELAY);
    }

    private synchronized void bw_update(String str, int i, int i2) {
        try {
            if (!this.m_tun_bw_count.has(str)) {
                this.m_tun_bw_count.put(str, new JSONObject().put("daily", new JSONArray()).put("min", 0L).put(AppLovinMediationProvider.MAX, 0L));
            }
            JSONObject jSONObject = this.m_tun_bw_count.getJSONObject(str);
            long currentTimeMillis = System.currentTimeMillis();
            if (jSONObject.getLong("min") > currentTimeMillis || jSONObject.getLong(AppLovinMediationProvider.MAX) <= currentTimeMillis) {
                Calendar calendar = dev_util.get_day_start();
                Calendar calendar2 = dev_util.get_day_start();
                calendar2.add(5, 1);
                Calendar calendar3 = dev_util.get_day_start();
                calendar3.add(2, -1);
                long timeInMillis = calendar3.getTimeInMillis();
                jSONObject.put("min", calendar.getTimeInMillis());
                jSONObject.put(AppLovinMediationProvider.MAX, calendar2.getTimeInMillis());
                JSONObject put = new JSONObject().put("start", calendar.getTimeInMillis()).put("dn", 0).put("up", 0);
                JSONArray jSONArray = jSONObject.getJSONArray("daily");
                dev_util.unshift_json_array(jSONArray, put);
                JSONArray jSONArray2 = new JSONArray();
                for (int i3 = 0; i3 < jSONArray.length(); i3++) {
                    if (jSONArray.getJSONObject(i3).getLong("start") >= timeInMillis) {
                        jSONArray2.put(jSONArray.getJSONObject(i3));
                    }
                }
                jSONObject.put("daily", jSONArray2);
            }
            JSONObject jSONObject2 = jSONObject.getJSONArray("daily").getJSONObject(0);
            jSONObject2.put("dn", jSONObject2.getLong("dn") + ((long) i));
            jSONObject2.put("up", jSONObject2.getLong("up") + ((long) i2));
            this.m_tun_bw_count.put(str, jSONObject);
            this.m_tun_bw_dirty = true;
        } catch (Throwable th) {
            util.perr(3, "dev_conn_tun_bw_calc_err", th, (Object) this.m_zerr.tag(), true);
        }
        return;
    }

    private void check_milestones(WebSocket webSocket, milestone milestone2, int i, int i2, int i3) {
        util.perr_funnel(conf.FUNNEL_22_SVC_TUN_1B);
        perr_funnel_v(conf.FUNNEL_DEV_08_TUN_1B);
        try {
            if (milestone2.update(i2, i3)) {
                webSocket.send(ipc_post("tun_report", new JSONObject().put("vfd", i).put("timeline", milestone2.flush())));
            }
        } catch (JSONException e2) {
            this.m_zerr.err((Throwable) e2);
        }
    }

    private void cid_set(JSONObject jSONObject) {
        this.m_cid = jSONObject.getString("cid");
        util.zerr zerr = this.m_zerr;
        StringBuilder a2 = a.a("got new cid = ");
        a2.append(this.m_cid);
        zerr.debug(a2.toString());
        String str = this.m_cid;
        if (str == null || str.isEmpty()) {
            StringBuilder a3 = a.a("value: ");
            a3.append(this.m_cid);
            util.perr("cid_java_empty", a3.toString());
            return;
        }
        evaluation.set_is_supported();
        String.format("%s [%s]", new Object[]{this.m_cid, this.m_dev.m_name});
        this.m_conf.set(conf.CID_KEY, this.m_dev.m_name);
        this.m_conf.set(conf.CID_VALUE, this.m_cid);
        this.m_conf.set(conf.CID_KV, dev_util.build_cid_kv(this.m_dev.m_name, this.m_cid));
        util.file_save_object(dev_util.get_cid_filename(this.m_conf_dir, this.m_dev.m_name), this.m_cid);
        if (this.m_myip != null) {
            try {
                util.register_cid(this.m_cid.split("/")[1], this.m_dev.m_name, this.m_myip_s);
            } catch (Exception unused) {
            }
        }
    }

    private JSONObject cmd_tun(JSONObject jSONObject, mux mux, WebSocket webSocket) {
        JSONObject jSONObject2 = jSONObject;
        mux mux2 = mux;
        if (!jSONObject2.has("host") || !jSONObject2.has("port")) {
            return null;
        }
        report_state("peer");
        util.perr_funnel(conf.FUNNEL_21_SVC_TUN_START);
        perr_funnel_v(conf.FUNNEL_DEV_07_TUN_USE);
        JSONObject jSONObject3 = new JSONObject();
        String string = jSONObject2.getString("host");
        int i = jSONObject2.getInt("port");
        JSONArray jSONArray = new JSONArray();
        dev_util.timeline_push(jSONArray, "init");
        Inet4Address resolve_domain_random = dev_util.resolve_domain_random(string);
        dev_util.timeline_push(jSONArray, "dns");
        if (resolve_domain_random == null) {
            return jSONObject3.put(NotificationCompat.CATEGORY_ERROR, "DNS failed: no results");
        }
        String hostAddress = resolve_domain_random.getHostAddress();
        if (is_ip_blocked(resolve_domain_random)) {
            return jSONObject3.put(NotificationCompat.CATEGORY_ERROR, "Blocked IP " + hostAddress);
        }
        InetSocketAddress inetSocketAddress = new InetSocketAddress(resolve_domain_random, i);
        int i2 = get_vfd(jSONObject);
        if (i2 == 0) {
            i2 = this.m_last_vfd + 1;
            this.m_last_vfd = i2;
        }
        int i3 = i2;
        try {
            if (jSONObject2.has("stream_opt")) {
                JSONObject jSONObject4 = jSONObject2.getJSONObject("stream_opt");
                if (jSONObject4.has("use_ack") && jSONObject4.optBoolean("use_ack")) {
                    int optInt = jSONObject2.optInt("win_size", 1048576);
                    int optInt2 = jSONObject2.optInt("rmt_win_size", optInt);
                    mux2.set_client_stream_opt(i3, optInt, jSONObject4.optInt("readableHighWaterMark", 0));
                    if (optInt2 > 0) {
                        mux2.set_stream_opt(i3, optInt2);
                    }
                }
            }
        } catch (JSONException unused) {
        }
        etask zwait = etask.zwait();
        String string2 = jSONObject2.getString("bw_type");
        AsyncServer asyncServer = AsyncServer.getDefault().set_local_address(get_local_address());
        String str = NotificationCompat.CATEGORY_ERROR;
        w wVar = r1;
        JSONArray jSONArray2 = jSONArray;
        int i4 = i3;
        w wVar2 = new w(this, zwait, mux, i3, string2, webSocket);
        asyncServer.connectSocket(inetSocketAddress, wVar);
        try {
            zwait.yield();
            this.m_zerr.notice("tunnel established");
            return jSONObject3.put("vfd", i4).put("timeline", jSONArray2).put("sock_opt", new JSONObject().put("host", inetSocketAddress.getAddress().getHostAddress()).put("port", i).put("localAddress", this.m_local_ip_addr));
        } catch (Exception e2) {
            Exception exc = e2;
            StringBuilder a2 = a.a("Connection failed: ");
            a2.append(exc.toString());
            return jSONObject3.put(str, a2.toString());
        }
    }

    private JSONObject cmd_tun_close(JSONObject jSONObject, mux mux) {
        if (!jSONObject.has("vfd")) {
            return null;
        }
        if (mux.close(jSONObject.getInt("vfd"))) {
            util.perr(5, "tun_close", true);
        }
        return new JSONObject();
    }

    private void conn_open_single() {
        this.m_ext_ip.set((Object) null);
        try {
            set_blocked_ip(zon_conf.BLOCKED_IPS);
        } catch (JSONException e2) {
            this.m_zerr.err((Throwable) e2);
        }
        String[] strArr = get_proxy_addr();
        String str = strArr[0];
        String str2 = strArr[1];
        util.perr_funnel(conf.FUNNEL_18_SVC_INIT);
        perr_funnel_v(conf.FUNNEL_DEV_04_CONN_INIT);
        AsyncHttpGet prepare_ws_request = prepare_ws_request(str2, str, this.m_conf.get_str(conf.WS_CONN_PROXYJS), this.m_proxyjs_conn_sproxy.get(), 15000);
        this.m_zerr.notice(String.format("proxyjs conn try: %s (%s) [%s:%s]", new Object[]{str2, str, prepare_ws_request.getProxyHost(), Integer.valueOf(prepare_ws_request.getProxyPort())}));
        AsyncHttpClient.getDefaultInstance().websocket((AsyncHttpRequest) prepare_ws_request, new String[]{"wss"}, (AsyncHttpClient.WebSocketConnectCallback) new n(this, str2, str, prepare_ws_request));
    }

    private void connect(String str, int i, String str2, int i2, Runnable runnable) {
        String str3 = str;
        String str4 = get_wss_uri(str, Integer.valueOf(i));
        String str5 = this.m_conf.get_str(conf.WS_CONN_ZAGENT);
        String format = String.format("%s (%s) (%s)", new Object[]{str3, str4, str2});
        util.zerr zerr = this.m_zerr;
        zerr.debug("zagent conn try: " + format);
        AsyncHttpClient.getDefaultInstance().websocket((AsyncHttpRequest) prepare_ws_request(str4, str2, str5, false, 5000), new String[]{"wss"}, (AsyncHttpClient.WebSocketConnectCallback) new y(this, i2, runnable, format, str2, str3, str4, i));
    }

    private void connect(JSONObject jSONObject) {
        if (jSONObject.has("host") && jSONObject.has("port") && jSONObject.has("servername")) {
            util.zerr zerr = this.m_zerr;
            zerr.debug("connect: " + jSONObject);
            util.perr_funnel(conf.FUNNEL_20_SVC_TUN_READY);
            perr_funnel_v(conf.FUNNEL_DEV_06_TUN_INIT);
            String optString = jSONObject.optString("host");
            int optInt = jSONObject.optInt("port", 443);
            connect(optString, optInt, jSONObject.optString("servername"), 0, get_connect_fallback(1, jSONObject, optString, optInt));
        }
    }

    private JSONObject connect_dns(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        if (!jSONObject.has("domain")) {
            return null;
        }
        List<Inet4Address> resolve_domain = dev_util.resolve_domain(jSONObject.getString("domain"));
        JSONArray jSONArray = new JSONArray();
        if (resolve_domain == null) {
            return jSONObject2;
        }
        String string = jSONObject.getString("resolve_type");
        char c2 = 65535;
        if (string.hashCode() == -341328952 && string.equals("resolve4")) {
            c2 = 0;
        }
        Iterator<Inet4Address> it = resolve_domain.iterator();
        if (c2 != 0) {
            while (it.hasNext()) {
                InetAddress next = it.next();
                if (!next.isLoopbackAddress()) {
                    JSONObject jSONObject3 = new JSONObject();
                    jSONObject3.put("address", next.getHostAddress());
                    jSONObject3.put("family", next instanceof Inet4Address ? 4 : 6);
                    jSONArray.put(jSONObject3);
                }
            }
        } else {
            while (it.hasNext()) {
                InetAddress next2 = it.next();
                if (!next2.isLoopbackAddress() && (next2 instanceof Inet4Address)) {
                    jSONArray.put(next2.getHostAddress());
                }
            }
        }
        jSONObject2.put("res", jSONArray);
        if (!jSONObject.has("get_servers")) {
            return jSONObject2;
        }
        try {
            String[] strArr = dev_util.get_dns_servers(this.m_ctx);
            if (strArr == null) {
                return jSONObject2;
            }
            JSONArray jSONArray2 = new JSONArray();
            for (String put : strArr) {
                jSONArray2.put(put);
            }
            jSONObject2.put("servers", jSONArray2);
            return jSONObject2;
        } catch (Exception e2) {
            util.perr(3, "dev_conn_tun_cmd_dns_err", (Object) e2, (Object) this.m_zerr.tag(), true);
        }
    }

    private JSONObject get_app_bytes_obj() {
        return new JSONObject().put("bw", util.get_mobile_usage_json(this.m_ctx)).put("battery_level", (double) this.m_state.get_float(state.BATTERY_LEVEL)).put("using_battery", this.m_state.get_bool(state.USING_BATTERY)).put("screen_on", this.m_state.get_bool(state.SCREEN_ON)).put("mobile_connected", this.m_dev.is_mobile()).put("wifi_connected", this.m_dev.is_wifi()).put("on_call", this.m_state.get_bool(state.ON_CALL)).put("roaming", this.m_dev.is_roaming());
    }

    private Runnable get_connect_fallback(int i, JSONObject jSONObject, String str, int i2) {
        if (i >= 10) {
            return null;
        }
        String str2 = get_connect_fallback_suffix(i);
        String str3 = util.get_ssl_servername(jSONObject.optString("servername" + str2, ""), conf.SPROXY_SSL_HOST, zon_conf.SPROXY_SSL_HOST);
        if (str3.isEmpty()) {
            return null;
        }
        int optInt = jSONObject.optInt("port" + str2, i2);
        return new d0(this, jSONObject.optString("host" + str2, str), optInt, str3, i, jSONObject);
    }

    private String get_connect_fallback_suffix(int i) {
        return i > 0 ? a.b("_a", i) : "";
    }

    private InetSocketAddress get_local_address() {
        if (this.m_local_ip == null || this.m_ignore_local_ip) {
            return null;
        }
        return new InetSocketAddress(this.m_local_ip, 0);
    }

    private String get_old_cid() {
        String str = dev_util.get_cid_filename(this.m_conf_dir, this.m_dev.m_name);
        if (!util.file_exists(str)) {
            return "";
        }
        String str2 = (String) util.file_load_object(str);
        if (str2 == null && this.m_conf.get_str(conf.CID_KEY).equals(this.m_dev.m_name)) {
            str2 = this.m_conf.get_str(conf.CID_VALUE);
        }
        return str2 == null ? "" : str2;
    }

    private String[] get_proxy_addr() {
        String str;
        this.m_proxy_alias_used = false;
        String str2 = this.m_force_proxy_domain;
        String str3 = null;
        if (str2 != null) {
            String str4 = get_wss_uri(this.m_force_proxy_ip, this.m_force_proxy_port);
            this.m_force_proxy_domain = null;
            this.m_force_proxy_ip = null;
            this.m_force_proxy_port = null;
            return new String[]{str2, str4};
        }
        String str5 = this.m_last_proxy_url;
        if (str5 != null) {
            String str6 = this.m_last_proxy_domain;
            this.m_last_proxy_domain = null;
            this.m_last_proxy_url = null;
            return new String[]{str6, str5};
        }
        ArrayList<String> arrayList = zon_conf.PROXY_DOMAINS;
        ArrayList<String> arrayList2 = zon_conf.PROXY_IPS;
        if (!this.m_disable_proxyjs_resolve) {
            while (true) {
                if (this.m_domain_index >= arrayList.size()) {
                    str = null;
                    break;
                }
                int i = this.m_domain_index;
                this.m_domain_index = i + 1;
                str = arrayList.get(i);
                Inet4Address resolve_domain_random = dev_util.resolve_domain_random(str, arrayList2);
                if (resolve_domain_random != null) {
                    str3 = resolve_domain_random.getHostAddress();
                    break;
                }
            }
            if (str3 == null) {
                util.perr(3, "proxyjs_domain_resolve_fail", true);
            }
        } else {
            str = null;
        }
        if (str3 == null) {
            ArrayList<String> arrayList3 = zon_conf.PROXY_IPS_A1;
            ArrayList<String> arrayList4 = zon_conf.PROXY_DOMAINS_A1;
            if (this.m_ip_index < arrayList3.size()) {
                int i2 = this.m_ip_index;
                this.m_ip_index = i2 + 1;
                str3 = arrayList3.get(i2);
                str = arrayList4.get(0);
            }
            if (str3 == null) {
                this.m_ip_index = 0;
                this.m_domain_index = 0;
                this.m_port_index = (this.m_port_index + 1) % this.m_ports.size();
                return get_proxy_addr();
            }
            this.m_proxy_alias_used = true;
        }
        return new String[]{str, get_wss_uri(str3, this.m_ports.get(this.m_port_index))};
    }

    @SuppressLint({"SimpleDateFormat"})
    private JSONObject get_usage_obj() {
        return new JSONObject().put("app_bytes", get_app_bytes_obj().toString().replace("\\/", "/")).put("total_bytes", "").put("ts", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
    }

    private int get_vfd(JSONObject jSONObject) {
        if (!jSONObject.has("vfd")) {
            return 0;
        }
        int i = jSONObject.getInt("vfd");
        if (this.m_last_vfd >= i) {
            return i;
        }
        this.m_last_vfd = i;
        return i;
    }

    private String get_wss_uri(String str) {
        return get_wss_uri(str, (Integer) null);
    }

    private String get_wss_uri(String str, Integer num) {
        String a2 = a.a("wss://", str);
        if (num == null) {
            return a2;
        }
        return a2 + ":" + num;
    }

    private String ipc_post(String str, JSONObject jSONObject) {
        return new JSONObject().put("type", "ipc_post").put("cmd", str).put("msg", jSONObject).toString().replace("\\/", "/");
    }

    private String ipc_result(String str, int i, JSONObject jSONObject) {
        JSONObject put = new JSONObject().put("type", "ipc_result").put("cmd", str).put("msg", jSONObject);
        if (i >= 0) {
            put.put("cookie", i);
        }
        return put.toString().replace("\\/", "/");
    }

    private boolean is_ip_blocked(InetAddress inetAddress) {
        Iterator<cidr_utils> it = this.m_blocked_ips.iterator();
        while (it.hasNext()) {
            try {
                if (it.next().is_in_range(inetAddress.getHostAddress())) {
                    return true;
                }
            } catch (UnknownHostException e2) {
                this.m_zerr.err((Throwable) e2);
            }
        }
        return false;
    }

    private void load_bw() {
        this.m_tun_bw_count = new JSONObject();
        if (util.file_exists(this.m_bw_path)) {
            try {
                String str = (String) util.file_load_object(this.m_bw_path);
                if (str == null) {
                    byte[] file_read = util.file_read(this.m_conf_dir + "/db/bw.db");
                    if (file_read != null) {
                        str = util.byte2str(file_read);
                    }
                }
                if (str != null) {
                    this.m_tun_bw_count = new JSONObject(str);
                }
            } catch (JSONException e2) {
                util.perr(3, "load_bw_fail", e2.getMessage(), util.e2s(e2), true);
            }
        }
    }

    private void perr_funnel_v(conf.key key) {
        util.perr_funnel_v(key, Boolean.valueOf(this.m_dev.is_mobile()));
    }

    private JSONObject perr_process() {
        return new JSONObject().put("ok", true).put("sent", 0).put("failed", 0);
    }

    private AsyncHttpGet prepare_ws_request(String str, String str2, String str3, boolean z, int i) {
        AsyncHttpGet asyncHttpGet = new AsyncHttpGet(str.replace("wss://", "https://"));
        asyncHttpGet.set_local_address(get_local_address());
        asyncHttpGet.set_domain_uri(Uri.parse(get_wss_uri(str2)));
        if (z) {
            this.m_proxyjs_conn_sproxy_host = util.m_sdk_proxy_pool.get_host();
            int i2 = util.m_sdk_proxy_pool.get_port();
            String str4 = util.m_sdk_proxy_pool.get_domain();
            boolean z2 = util.m_sdk_proxy_pool.get_ssl();
            util.zerr zerr = this.m_zerr;
            StringBuilder a2 = a.a("using proxy: ");
            a2.append(util.m_sdk_proxy_pool.get_details());
            zerr.notice(a2.toString());
            asyncHttpGet.enable_proxy(this.m_proxyjs_conn_sproxy_host, i2, str4, z2);
            asyncHttpGet.set_header("x-uuid", this.m_uuid, true).set_header("x-forwarded-host", str2, true).set_header("x-forwarded-port", String.valueOf(this.m_ports.get(this.m_port_index)), true).set_header("x-forwarded-proto", "https", true);
            if (!this.m_ip.isEmpty()) {
                asyncHttpGet.set_header("x-forwarded-for", this.m_ip, true);
            } else {
                util.perr(3, "proxyjs_conn_zagents_no_ip", true);
            }
        }
        if (!str3.isEmpty()) {
            asyncHttpGet.setHeader("Connection", str3);
        }
        asyncHttpGet.setTimeout(i);
        return asyncHttpGet;
    }

    private JSONObject remote_wbm(JSONObject jSONObject, mux mux) {
        if (this.m_wbm_server == null) {
            this.m_wbm_server = new wbm_server(5000);
        }
        JSONObject jSONObject2 = new JSONObject();
        int i = jSONObject.getInt("vfd");
        etask zwait = etask.zwait();
        AsyncServer.getDefault().set_local_address(get_local_address()).connectSocket(new InetSocketAddress("127.0.0.1", 5000), new r(this, zwait, mux, i));
        return jSONObject2;
    }

    private void report_state(String str) {
        String str2 = this.m_ignore_local_ip ? "ip_ignore" : this.m_local_ip == null ? "ip_none" : null;
        if (str2 != null) {
            util.perr(5, String.format("dev_conn_%s_%s", new Object[]{str2, str}), (Object) this, (Object) this.m_dev, true);
        }
    }

    private void set_blocked_ip(JSONArray jSONArray) {
        this.m_blocked_ips.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                this.m_blocked_ips.add(new cidr_utils(jSONArray.getString(i)));
            } catch (UnknownHostException e2) {
                this.m_zerr.err((Throwable) e2);
            }
        }
    }

    private JSONObject status_get(JSONObject jSONObject) {
        JSONObject jSONObject2 = jSONObject;
        JSONObject jSONObject3 = new JSONObject();
        int i = 1;
        jSONObject3.put("is_java", true);
        jSONObject3.put("usage", get_usage_obj());
        jSONObject3.put("mobile_connected", this.m_dev.is_mobile());
        jSONObject3.put("roaming", this.m_dev.is_roaming());
        jSONObject3.put("is_debug", util.is_debug());
        jSONObject3.put("is_tv", util.is_tv(this.m_ctx));
        if (jSONObject2.has("ts")) {
            jSONObject3.put("ts_diff", System.currentTimeMillis() - jSONObject2.getLong("ts"));
        }
        if (jSONObject2.has("raw_bw")) {
            return jSONObject3.put("bw", this.m_tun_bw_count);
        }
        JSONObject jSONObject4 = new JSONObject();
        Iterator<String> keys = this.m_tun_bw_count.keys();
        while (keys.hasNext()) {
            String next = keys.next();
            JSONObject jSONObject5 = this.m_tun_bw_count.getJSONObject(next);
            if (jSONObject5 != null) {
                JSONObject jSONObject6 = new JSONObject();
                JSONArray jSONArray = jSONObject5.getJSONArray("daily");
                if (!(jSONArray == null || jSONArray.length() == 0)) {
                    jSONObject6.put("first", jSONArray.getJSONObject(0).getLong("start")).put("last", jSONArray.getJSONObject(jSONArray.length() - i).getLong("start")).put("count", jSONArray.length());
                    long j = 0;
                    long j2 = 0;
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        j = jSONArray.getJSONObject(i2).getLong("dn") + j;
                        j2 += jSONArray.getJSONObject(i2).getLong("up");
                    }
                    jSONObject6.put("dn", j).put("up", j2);
                    jSONObject4.put(next, jSONObject6);
                    i = 1;
                }
            }
        }
        return jSONObject3.put("bw", jSONObject4);
    }

    private etask<Boolean> test_socket(InetSocketAddress inetSocketAddress) {
        util.zerr zerr = this.m_zerr;
        zerr.notice("test socket: " + inetSocketAddress);
        etask<Boolean> run = etask.run(new k(this, inetSocketAddress));
        this.m_test_socket_task = run;
        return run;
    }

    private void toobusy(JSONObject jSONObject) {
        if (this.m_redirect_enabled && jSONObject != null) {
            this.m_zerr.notice("redirect: toobusy");
            this.m_last_proxy_domain = null;
            this.m_last_proxy_url = null;
            this.m_is_redirect = true;
            retry();
        }
    }

    private void tun_ack(JSONObject jSONObject, mux mux) {
        this.m_zerr.debug(String.format("ack: %s", new Object[]{jSONObject}));
        int i = get_vfd(jSONObject);
        if (i == 0) {
            util.perr(3, "dev_conn_ack_no_vfd", true);
        } else {
            mux.ack(i, jSONObject.optInt("ack", 0));
        }
    }

    private JSONObject tun_fin(JSONObject jSONObject, mux mux) {
        this.m_zerr.debug(String.format("fin: %s", new Object[]{jSONObject}));
        if (jSONObject.getInt("fin") == 1) {
            int i = get_vfd(jSONObject);
            if (i == 0) {
                util.perr(3, "dev_conn_fin_no_vfd", true);
            } else {
                mux.close(i);
            }
        }
        return jSONObject;
    }

    private void tun_vfd(JSONObject jSONObject, mux mux) {
        this.m_zerr.debug(String.format("vfd: %s", new Object[]{jSONObject}));
        int i = get_vfd(jSONObject);
        if (i == 0) {
            util.perr(3, "dev_conn_vfd_no_vfd", true);
            return;
        }
        int optInt = jSONObject.optInt("win_size", 0);
        if (optInt > 0) {
            mux.set_stream_opt(i, optInt);
        }
    }

    private JSONObject tunnel_init(JSONObject jSONObject, String str) {
        String str2;
        String str3;
        if (str.equals("proxyjs")) {
            report_state("client");
            util.perr_funnel(conf.FUNNEL_19_SVC_CONNECTED);
            perr_funnel_v(conf.FUNNEL_DEV_05_CONN_OK);
            if (this.m_disable_proxyjs_resolve && this.m_conf.get_str(conf.WS_CONN_PROXYJS_FORCE_IP, "failure").equals("failure")) {
                util.perr(5, "conn_init_ok_force_ip", (Object) this.m_dev.m_name, (Object) this.m_myip, true);
            }
        }
        util.zerr zerr = this.m_zerr;
        StringBuilder b2 = a.b("tunnel_init: ", str);
        if (util.is_test_app((String) null)) {
            str2 = " " + jSONObject;
        } else {
            str2 = "";
        }
        b2.append(str2);
        zerr.notice(b2.toString());
        JSONObject jSONObject2 = new JSONObject();
        if (jSONObject != null && this.m_conf.get_bool(conf.WS_CONN_PROXYJS_EXT_IP_CHECK)) {
            String optString = jSONObject.optString("ext_ip");
            if (optString.isEmpty()) {
                this.m_zerr.err(String.format("no ext_ip (%s): %s", new Object[]{str, jSONObject}));
                util.perr(3, "dev_conn_no_ext_ip", true);
                util.perr(3, "dev_conn_no_ext_ip_" + str, true);
            } else if (str.equals("proxyjs")) {
                this.m_ext_ip.set(optString);
            } else {
                String str4 = this.m_ext_ip.get();
                if (str4 != null) {
                    if (!str4.equals(optString)) {
                        String format = String.format("expected: %s, actual: %s", new Object[]{str4, optString});
                        if (this.m_proxyjs_conn_sproxy.get()) {
                            str3 = "dev_conn_ip_mfr_proxy";
                        } else if (this.m_proxyjs_conn_sproxy_enable.equals("failure")) {
                            this.m_zerr.notice("enabling sproxy after IP mismatch");
                            this.m_proxyjs_conn_sproxy.set(true);
                            str3 = "dev_conn_ip_mfr_direct_to_proxy";
                        } else {
                            str3 = "dev_conn_ip_mfr_direct";
                        }
                        util.perr(3, str3, format);
                        this.m_proxyjs_conn_mfr.set(true);
                        this.m_dev.on_ip_conn_fail(this.m_local_ip);
                        return jSONObject2;
                    } else if (this.m_proxyjs_conn_mfr.getAndSet(false)) {
                        util.perr(3, this.m_proxyjs_conn_sproxy.get() ? "dev_conn_ip_mfr_fin_proxy" : "dev_conn_ip_mfr_fin_direct", str4);
                    }
                }
            }
        }
        jSONObject2.put(perr.columns.VER, "1.177.86").put("confdir", this.m_conf_dir).put("arch", dev_util.get_arch()).put("release", Build.VERSION.RELEASE).put("old_cid", get_old_cid()).put("makeflags", config.CONFIG_MAKEFLAGS).put("platform", "linux").put("apkid", this.m_ctx.getPackageName()).put("type", this.m_dev.m_type).put("ifname", this.m_dev.m_name).put("mobile_enable", this.m_state.get_bool(state.MOBILE_ENABLE)).put("cid", this.m_cid).put("android_ver", "1.177.86").put("usage", get_usage_obj()).put("android_sdk_ver", Build.VERSION.SDK_INT).put("partnerid", this.m_conf.get_str(conf.PARTNERID)).put("uuid", this.m_uuid).put("client_conf", new JSONObject()).put("db", new JSONObject()).put("mobile_connected", this.m_dev.is_mobile()).put("roaming", this.m_dev.is_roaming()).put("sdk_version", "1.177.86").put("is_debug", util.is_debug()).put("is_tv", util.is_tv(this.m_ctx));
        if (!util.m_tracking_id.isEmpty()) {
            jSONObject2.put("tracking_id", util.m_tracking_id);
        }
        if (this.m_proxyjs_conn_sproxy.get()) {
            jSONObject2.put("proxy", this.m_proxyjs_conn_sproxy_host);
            JSONObject jSONObject3 = this.m_myip;
            if (jSONObject3 != null) {
                jSONObject2.put("myip", jSONObject3);
            }
        }
        return jSONObject2;
    }

    private void tunnel_redirect(JSONObject jSONObject) {
        if (this.m_redirect_enabled && jSONObject != null) {
            this.m_zerr.notice(String.format("redirect: %s", new Object[]{jSONObject}));
            String str = this.m_last_proxy_domain;
            if (str == null) {
                str = zon_conf.PROXY_DOMAINS.get(0);
            }
            this.m_force_proxy_domain = jSONObject.optString("host", str);
            this.m_force_proxy_ip = jSONObject.optString("ip");
            this.m_force_proxy_port = Integer.valueOf(jSONObject.optInt("port", zon_conf.PROXY_PORTS.get(0).intValue()));
            this.m_is_redirect = true;
            retry();
        }
    }

    private void up(int i) {
        synchronized (this.m_state_sync) {
            if (this.m_up_task == null) {
                perr_funnel_v(conf.FUNNEL_DEV_02_CONN_UP);
                etask etask = this.m_down_task;
                this.m_down_task = null;
                this.m_zerr.notice("up");
                this.m_up_task = etask.run((Runnable) new i(this, etask, i));
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:2|3|4|5|6|7|9) */
    /* JADX WARNING: Code restructure failed: missing block: B:10:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:4:0x0006 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:6:0x0009 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void ws_close(io.lum.sdk.async.http.WebSocket r1) {
        /*
            r0 = this;
            if (r1 != 0) goto L_0x0003
            return
        L_0x0003:
            r1.end()     // Catch:{ Exception -> 0x0006 }
        L_0x0006:
            r1.close()     // Catch:{ Exception -> 0x0009 }
        L_0x0009:
            io.lum.sdk.async.AsyncServer r1 = r1.getServer()     // Catch:{ Exception -> 0x0010 }
            r1.stop()     // Catch:{ Exception -> 0x0010 }
        L_0x0010:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_conn.ws_close(io.lum.sdk.async.http.WebSocket):void");
    }

    public /* synthetic */ Boolean a(InetSocketAddress inetSocketAddress) {
        boolean z;
        InetAddress inetAddress;
        int i;
        try {
            ArrayList<JSONObject> arrayList = zon_conf.TEST_SITES;
            int i2 = 1000;
            while (true) {
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    JSONObject jSONObject = arrayList.get(i3);
                    URI create = URI.create(jSONObject.getString("url"));
                    String string = jSONObject.getString("ip");
                    String host = create.getHost();
                    String str = "GET " + create.getPath() + " HTTP/1.1\r\nHost: " + host + "\r\n\r\n";
                    Pattern compile = Pattern.compile(jSONObject.getString("match"));
                    Inet4Address resolve_domain_random = dev_util.resolve_domain_random(host);
                    int i4 = create.getScheme().equals("http") ? 80 : 443;
                    ArrayList arrayList2 = new ArrayList();
                    if (resolve_domain_random != null) {
                        arrayList2.add(resolve_domain_random);
                    }
                    arrayList2.add(InetAddress.getByName(string));
                    Iterator it = arrayList2.iterator();
                    while (it.hasNext()) {
                        inetAddress = (InetAddress) it.next();
                        this.m_zerr.notice("test_socket: ip: " + inetAddress + ":" + i4);
                        InetSocketAddress inetSocketAddress2 = new InetSocketAddress(inetAddress, i4);
                        etask zwait = etask.zwait();
                        ArrayList<JSONObject> arrayList3 = arrayList;
                        i = i4;
                        String str2 = host;
                        final URI uri = create;
                        final Cancellable connectSocket = AsyncServer.getDefault().set_local_address(inetSocketAddress).connectSocket(inetSocketAddress2, new p(this, zwait, compile, jSONObject, str));
                        Timer timer = new Timer();
                        this.m_test_socket_task_timer = timer;
                        final etask etask = zwait;
                        timer.schedule(new TimerTask() {
                            public void run() {
                                try {
                                    connectSocket.cancel();
                                } catch (Exception unused) {
                                }
                                etask etask = etask;
                                StringBuilder a2 = a.a("Request timeout: ");
                                a2.append(uri);
                                etask.zthrow(new Exception(a2.toString()));
                            }
                        }, (long) this.m_test_socket_task_timeout);
                        try {
                            if (!((Boolean) etask.yield()).booleanValue()) {
                                throw new Exception("Unexpected response");
                            }
                        } catch (InterruptedException | ExecutionException unused) {
                        } catch (Exception e2) {
                            util.perr(3, "dev_conn_test_socket_err", String.format("conn: %s, host: %s:%s, uri: %s, local_ip: %s", new Object[]{this.m_zerr.tag(), str2, Integer.valueOf(i), uri, this.m_local_ip}), util.e2s(e2), true);
                            create = uri;
                            arrayList = arrayList3;
                            i4 = i;
                            host = str2;
                        }
                    }
                    ArrayList<JSONObject> arrayList4 = arrayList;
                }
                ArrayList<JSONObject> arrayList5 = arrayList;
                if (!this.m_is_retry) {
                    z = false;
                    try {
                        return false;
                    } catch (Exception unused2) {
                        return Boolean.valueOf(z);
                    }
                } else {
                    i2 = Math.min(i2 * 2, 1800000);
                    Thread.sleep((long) i2);
                    this.m_zerr.notice(String.format("retrying after %sms", new Object[]{Integer.valueOf(i2)}));
                    arrayList = arrayList5;
                }
            }
            this.m_zerr.notice("test_socket passed: ip: " + inetAddress + ":" + i);
            return true;
        } catch (Exception unused3) {
            z = false;
            return Boolean.valueOf(z);
        }
    }

    public /* synthetic */ void a() {
        if (this.m_tun_bw_dirty) {
            this.m_zerr.debug("bw_store");
            util.file_save_object(this.m_bw_path, this.m_tun_bw_count.toString());
            this.m_tun_bw_dirty = false;
        }
    }

    public /* synthetic */ void a(int i, Runnable runnable, String str, String str2, String str3, String str4, int i2, Exception exc, WebSocket webSocket) {
        String str5 = str3;
        Exception exc2 = exc;
        WebSocket webSocket2 = webSocket;
        String str6 = get_connect_fallback_suffix(i);
        if (exc2 != null) {
            util.zerr zerr = this.m_zerr;
            zerr.err("" + exc2);
            util.perr(3, "dev_conn_tun_init_err" + str6, exc.getMessage(), util.e2s(exc), true);
            util.update_sdk_info();
            if (runnable != null) {
                this.m_zerr.notice(String.format("zagent conn fallback: %s (%s)", new Object[]{str, Integer.valueOf(i)}));
                runnable.run();
                return;
            }
            return;
        }
        if (i > 0) {
            util.perr(3, "dev_conn_tun_init_success" + str6, (Object) str2, true);
        } else {
            String str7 = str2;
        }
        synchronized (this.m_zws_sync) {
            this.m_zagents_ws.add(webSocket2);
        }
        mux create = mux.create(webSocket2, this.m_zerr);
        util.zerr zerr2 = this.m_zerr;
        zerr2.notice("zagent conn established: " + str5);
        webSocket2.setStringCallback(new g(this, str4, create, webSocket2));
        webSocket2.setClosedCallback(new a0(this, create, webSocket2, str5));
        if (this.m_conf.get_bool(conf.WS_PING_ZAGENT)) {
            ws_ping.run(a.a("dev_conn/ws_ping/zagent/", str5), webSocket2, this.m_conf.get_int(conf.WS_PING_ZAGENT_INTERVAL), this.m_conf.get_int(conf.WS_PING_ZAGENT_TIMEOUT), new t(this, webSocket, str3, i2, str2, i, runnable));
        }
    }

    public /* synthetic */ void a(WebSocket webSocket) {
        ws_close(webSocket);
        util.perr(3, "proxyjs_ping_timeout", true);
    }

    public /* synthetic */ void a(WebSocket webSocket, int i, milestone milestone2, Exception exc) {
        try {
            webSocket.send(ipc_post("tun_destroy", new JSONObject().put("vfd", i).put("timeline", milestone2.flush())));
        } catch (JSONException e2) {
            this.m_zerr.err((Throwable) e2);
        }
    }

    public /* synthetic */ void a(WebSocket webSocket, String str, int i, String str2, int i2, Runnable runnable) {
        ws_close(webSocket);
        util.perr(3, "zagent_ping_timeout", (Object) "host: " + str, true);
        try {
            connect(str, i, str2, i2, runnable);
        } catch (Exception e2) {
            util.perr(3, "zagent_reconnect_failed", e2.getMessage(), util.e2s(e2), true);
        }
    }

    public /* synthetic */ void a(etask etask) {
        WebSocket[] webSocketArr;
        if (etask != null) {
            etask.cancel();
        }
        etask etask2 = this.m_bw_task;
        if (etask2 != null) {
            etask2.cancel();
        }
        etask<Boolean> etask3 = this.m_test_task;
        if (etask3 != null) {
            etask3.cancel();
        }
        etask<Boolean> etask4 = this.m_test_socket_task;
        if (etask4 != null) {
            etask4.cancel();
        }
        try {
            WebSocket[] webSocketArr2 = new WebSocket[0];
            synchronized (this.m_zws_sync) {
                webSocketArr = (WebSocket[]) this.m_zagents_ws.toArray(webSocketArr2);
            }
            for (WebSocket ws_close : webSocketArr) {
                ws_close(ws_close);
            }
            synchronized (this.m_ws_sync) {
                ws_close(this.m_proxyjs_ws);
                this.m_proxyjs_ws = null;
            }
        } catch (Exception e2) {
            try {
                util.perr(3, "dev_conn_down_err", (Object) e2, (Object) this.m_zerr.tag(), true);
            } catch (Throwable th) {
                this.m_down_task = null;
                throw th;
            }
        }
        this.m_down_task = null;
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:32:0x00af */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x006f A[Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af, all -> 0x0009 }] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x007e A[SYNTHETIC, Splitter:B:24:0x007e] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b7 A[Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af, all -> 0x0009 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ void a(io.lum.sdk.etask r7, int r8) {
        /*
            r6 = this;
            r0 = 3
            r1 = 0
            r2 = 1
            if (r7 == 0) goto L_0x000c
            r7.yield()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            goto L_0x000c
        L_0x0009:
            r7 = move-exception
            goto L_0x00d6
        L_0x000c:
            if (r8 <= 0) goto L_0x0012
            long r7 = (long) r8     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.Thread.sleep(r7)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
        L_0x0012:
            java.net.InetSocketAddress r7 = r6.get_local_address()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            io.lum.sdk.etask r8 = r6.test_socket(r7)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.Object r8 = r8.yield()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.Boolean r8 = (java.lang.Boolean) r8     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            boolean r8 = r8.booleanValue()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            if (r8 != 0) goto L_0x0094
            android.content.Context r3 = r6.m_ctx     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            boolean r3 = io.lum.sdk.util.is_online(r3)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            boolean r4 = r6.m_is_retry     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            if (r4 == 0) goto L_0x0047
            java.lang.String r7 = "conn_up_fail_after_retry"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r4.<init>()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r5 = "online: "
            r4.append(r5)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r4.append(r3)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r3 = r4.toString()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            io.lum.sdk.util.perr((int) r0, (java.lang.String) r7, (java.lang.Object) r3, (boolean) r2)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            goto L_0x0094
        L_0x0047:
            if (r3 == 0) goto L_0x0094
            io.lum.sdk.dev_monitor r8 = io.lum.sdk.dev.get_monitor()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            boolean r8 = r8.has_single_active_interface()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            if (r8 == 0) goto L_0x006c
            io.lum.sdk.util$zerr r8 = r6.m_zerr     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r3 = "conn test failed but device is online"
            r8.notice(r3)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            if (r7 == 0) goto L_0x006c
            io.lum.sdk.etask r7 = r6.test_socket(r1)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.Object r7 = r7.yield()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.Boolean r7 = (java.lang.Boolean) r7     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            boolean r7 = r7.booleanValue()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r7 = r7 ^ r2
            goto L_0x006d
        L_0x006c:
            r7 = 1
        L_0x006d:
            if (r7 == 0) goto L_0x007e
            io.lum.sdk.util$zerr r7 = r6.m_zerr     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r8 = "conn test retry"
            r7.notice(r8)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.m_is_retry = r2     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.retry()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.m_up_task = r1
            return
        L_0x007e:
            io.lum.sdk.util$zerr r7 = r6.m_zerr     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r8 = "raw conn test passed"
            r7.notice(r8)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r7 = "conn_test_socket_raw_pass"
            io.lum.sdk.util.perr((int) r0, (java.lang.String) r7, (boolean) r2)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            io.lum.sdk.util$zerr r7 = r6.m_zerr     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r8 = "ignoring local ip"
            r7.notice(r8)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.m_ignore_local_ip = r2     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r8 = 1
        L_0x0094:
            if (r8 != 0) goto L_0x00a0
            io.lum.sdk.util$zerr r7 = r6.m_zerr     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            java.lang.String r8 = "no internet connection"
            r7.notice(r8)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.m_up_task = r1
            return
        L_0x00a0:
            io.lum.sdk.conf$key r7 = io.lum.sdk.conf.FUNNEL_DEV_03_CONN_TEST_PASS     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.perr_funnel_v(r7)     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            io.lum.sdk.etask r7 = r6.bw_store_init()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.m_bw_task = r7     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            r6.conn_open_single()     // Catch:{ InterruptedException | CancellationException -> 0x00cc, Exception -> 0x00af }
            goto L_0x00d3
        L_0x00af:
            android.content.Context r7 = r6.m_ctx     // Catch:{ all -> 0x0009 }
            boolean r7 = io.lum.sdk.util.is_online(r7)     // Catch:{ all -> 0x0009 }
            if (r7 == 0) goto L_0x00c4
            java.lang.String r7 = "dev_conn_up_err"
            io.lum.sdk.util$zerr r8 = r6.m_zerr     // Catch:{ all -> 0x0009 }
            java.lang.String r8 = r8.tag()     // Catch:{ all -> 0x0009 }
            java.lang.String r3 = ""
            io.lum.sdk.util.perr((int) r0, (java.lang.String) r7, (java.lang.String) r8, (java.lang.String) r3, (boolean) r2)     // Catch:{ all -> 0x0009 }
        L_0x00c4:
            io.lum.sdk.dev r7 = r6.m_dev     // Catch:{ all -> 0x0009 }
            java.net.InetAddress r8 = r6.m_local_ip     // Catch:{ all -> 0x0009 }
            r7.on_ip_conn_fail(r8)     // Catch:{ all -> 0x0009 }
            goto L_0x00d3
        L_0x00cc:
            io.lum.sdk.util$zerr r7 = r6.m_zerr     // Catch:{ all -> 0x0009 }
            java.lang.String r8 = "up interrupted"
            r7.notice(r8)     // Catch:{ all -> 0x0009 }
        L_0x00d3:
            r6.m_up_task = r1
            return
        L_0x00d6:
            r6.m_up_task = r1
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_conn.a(io.lum.sdk.etask, int):void");
    }

    public /* synthetic */ void a(etask etask, mux mux, int i, Exception exc, AsyncSocket asyncSocket) {
        if (exc != null) {
            util.zerr zerr = this.m_zerr;
            zerr.err("remote_wbm: " + exc);
            etask.zthrow(exc);
            return;
        }
        mux.pipe(asyncSocket, i, q.f7337a, x.f7391a, new c0(this));
        etask.zcontinue(null);
    }

    public /* synthetic */ void a(etask etask, mux mux, int i, String str, WebSocket webSocket, Exception exc, AsyncSocket asyncSocket) {
        if (exc != null) {
            this.m_zerr.err((Throwable) exc);
            etask.zthrow(exc);
            return;
        }
        milestone milestone2 = new milestone();
        String str2 = str;
        WebSocket webSocket2 = webSocket;
        milestone milestone3 = milestone2;
        int i2 = i;
        m mVar = new m(this, str2, webSocket2, milestone3, i2);
        h hVar = new h(this, str2, webSocket2, milestone3, i2);
        mux.pipe(asyncSocket, i, mVar, hVar, new l(this, webSocket, i, milestone2));
        etask.zcontinue(null);
    }

    public /* synthetic */ void a(etask etask, Pattern pattern, JSONObject jSONObject, String str, Exception exc, AsyncSocket asyncSocket) {
        if (exc != null) {
            this.m_zerr.err((Throwable) exc);
            etask.zthrow(exc);
            util.update_sdk_info();
            return;
        }
        asyncSocket.setDataCallback(new v(this, pattern, etask, jSONObject));
        Util.writeAll((DataSink) asyncSocket, str.getBytes(), (CompletedCallback) null);
    }

    public /* synthetic */ void a(mux mux, WebSocket webSocket, String str, Exception exc) {
        mux.close();
        synchronized (this.m_zws_sync) {
            this.m_zagents_ws.remove(webSocket);
        }
        util.zerr zerr = this.m_zerr;
        zerr.notice("zagent conn closed " + str);
    }

    public /* synthetic */ void a(mux mux, Exception exc) {
        this.m_zerr.notice("proxyjs conn closed");
        this.m_dev.on_ip_conn_fail(this.m_local_ip);
        mux.close();
        synchronized (this.m_ws_sync) {
            this.m_proxyjs_ws = null;
        }
    }

    public /* synthetic */ void a(Exception exc) {
        util.zerr zerr = this.m_zerr;
        zerr.err("remote_wbm pipe err: " + exc);
    }

    public /* synthetic */ void a(String str, int i, String str2, int i2, JSONObject jSONObject) {
        connect(str, i, str2, i2, get_connect_fallback(i2 + 1, jSONObject, str, i));
    }

    public /* synthetic */ void a(String str, WebSocket webSocket, milestone milestone2, int i, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        bw_update(str, byteBufferList.remaining(), 0);
        check_milestones(webSocket, milestone2, i, byteBufferList.remaining(), 0);
    }

    public /* synthetic */ void a(String str, mux mux, WebSocket webSocket, String str2) {
        etask.run((Runnable) new b0(this, str2, str, mux, webSocket));
    }

    /* JADX WARNING: Removed duplicated region for block: B:62:0x0204 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0205  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ void a(java.lang.String r11, java.lang.String r12, io.lum.sdk.async.http.AsyncHttpGet r13, java.lang.Exception r14, io.lum.sdk.async.http.WebSocket r15) {
        /*
            r10 = this;
            java.lang.String r0 = "%s (%s)"
            java.lang.String r1 = "dev_conn"
            r2 = 5
            r3 = 0
            r4 = 1
            if (r14 == 0) goto L_0x0180
            r13 = 0
            r10.m_last_proxy_domain = r13
            r10.m_last_proxy_url = r13
            java.util.concurrent.atomic.AtomicBoolean r13 = r10.m_proxyjs_conn_sproxy
            boolean r13 = r13.get()
            java.lang.String r5 = ""
            if (r13 == 0) goto L_0x001f
            io.lum.sdk.sdk_proxy_pool r13 = io.lum.sdk.util.m_sdk_proxy_pool
            r13.failure(r1)
            r10.m_proxyjs_conn_sproxy_host = r5
        L_0x001f:
            boolean r13 = r10.m_is_redirect
            r1 = 3
            if (r13 == 0) goto L_0x0035
            java.lang.String r13 = r14.getMessage()
            java.lang.String r6 = io.lum.sdk.util.e2s(r14)
            java.lang.String r7 = "redirect_disabled"
            io.lum.sdk.util.perr((int) r1, (java.lang.String) r7, (java.lang.String) r13, (java.lang.String) r6, (boolean) r4)
            r10.m_redirect_enabled = r3
            r10.m_is_redirect = r3
        L_0x0035:
            boolean r13 = r10.m_disable_proxyjs_resolve
            java.lang.String r3 = "failure"
            if (r13 != 0) goto L_0x0050
            io.lum.sdk.conf r13 = r10.m_conf
            io.lum.sdk.conf$key r6 = io.lum.sdk.conf.WS_CONN_PROXYJS_FORCE_IP
            java.lang.String r13 = r13.get_str(r6)
            boolean r13 = r13.equals(r3)
            if (r13 == 0) goto L_0x0050
            java.lang.String r13 = "proxyjs_disable_domain_resolve"
            io.lum.sdk.util.perr((int) r2, (java.lang.String) r13, (boolean) r4)
            r10.m_disable_proxyjs_resolve = r4
        L_0x0050:
            android.content.Context r13 = r10.m_ctx
            java.lang.String[] r13 = io.lum.sdk.dev_util.get_user_proxy((android.content.Context) r13)
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            if (r13 == 0) goto L_0x0069
            int r6 = r13.length
            r7 = 0
        L_0x005f:
            if (r7 >= r6) goto L_0x0069
            r8 = r13[r7]
            r2.append(r8)
            int r7 = r7 + 1
            goto L_0x005f
        L_0x0069:
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            io.lum.sdk.util$zerr r6 = r10.m_zerr
            java.lang.String r6 = r6.tag()
            r13.append(r6)
            java.lang.String r6 = " failed: "
            r13.append(r6)
            r13.append(r14)
            java.lang.String r13 = r13.toString()
            boolean r6 = r14 instanceof java.util.concurrent.TimeoutException
            if (r6 == 0) goto L_0x0088
            goto L_0x008c
        L_0x0088:
            java.lang.String r5 = io.lum.sdk.util.e2s(r14)
        L_0x008c:
            int r14 = r2.length()
            if (r14 <= 0) goto L_0x00a9
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            r14.append(r13)
            java.lang.String r13 = "\n proxy: \n"
            r14.append(r13)
            r14.append(r2)
            java.lang.String r13 = r14.toString()
            java.lang.String r14 = "conn_init_err_proxy"
            goto L_0x00ab
        L_0x00a9:
            java.lang.String r14 = "conn_init_err"
        L_0x00ab:
            boolean r2 = r10.m_conn_init_err_perr_sent
            if (r2 != 0) goto L_0x00f5
            if (r15 == 0) goto L_0x00ef
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            io.lum.sdk.async.AsyncSocket r15 = r15.getSocket()
            io.lum.sdk.async.AsyncSSLSocket r15 = (io.lum.sdk.async.AsyncSSLSocket) r15
            java.security.cert.X509Certificate[] r15 = r15.getPeerCertificates()
            int r6 = r15.length
            r7 = 0
        L_0x00c2:
            if (r7 >= r6) goto L_0x00d9
            r8 = r15[r7]
            java.security.Principal r8 = r8.getIssuerDN()
            java.lang.String r8 = r8.getName()
            java.lang.String r9 = "\n"
            r2.append(r9)
            r2.append(r8)
            int r7 = r7 + 1
            goto L_0x00c2
        L_0x00d9:
            io.lum.sdk.util$zerr r15 = r10.m_zerr
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "remote certs: \n"
            r6.append(r7)
            r6.append(r2)
            java.lang.String r2 = r6.toString()
            r15.notice(r2)
        L_0x00ef:
            io.lum.sdk.util.perr((int) r1, (java.lang.String) r14, (java.lang.String) r13, (java.lang.String) r5, (boolean) r4)
            r10.m_conn_init_err_perr_sent = r4
            goto L_0x010d
        L_0x00f5:
            io.lum.sdk.util$zerr r15 = r10.m_zerr
            r2 = 4
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r6 = 0
            r2[r6] = r14
            r2[r4] = r11
            r14 = 2
            r2[r14] = r13
            r2[r1] = r5
            java.lang.String r13 = "%s %s: %s \n %s"
            java.lang.String r13 = java.lang.String.format(r13, r2)
            r15.err((java.lang.String) r13)
        L_0x010d:
            r13 = 2
            boolean r14 = r10.m_proxy_alias_used
            if (r14 == 0) goto L_0x012a
            android.content.Context r14 = r10.m_ctx
            boolean r14 = io.lum.sdk.util.is_online(r14)
            if (r14 == 0) goto L_0x012a
            java.lang.Object[] r13 = new java.lang.Object[r13]
            r14 = 0
            r13[r14] = r11
            r13[r4] = r12
            java.lang.String r11 = java.lang.String.format(r0, r13)
            java.lang.String r12 = "proxyjs_conn_alias_fail"
            io.lum.sdk.util.perr((int) r1, (java.lang.String) r12, (java.lang.Object) r11, (boolean) r4)
        L_0x012a:
            java.util.concurrent.atomic.AtomicBoolean r11 = r10.m_proxyjs_conn_sproxy
            boolean r11 = r11.get()
            if (r11 != 0) goto L_0x015b
            java.lang.String r11 = r10.m_proxyjs_conn_sproxy_enable
            boolean r11 = r11.equals(r3)
            if (r11 == 0) goto L_0x015b
            int r11 = r10.m_proxy_conn_fails
            int r11 = r11 + r4
            r10.m_proxy_conn_fails = r11
            if (r11 < r1) goto L_0x015b
            io.lum.sdk.util$zerr r12 = r10.m_zerr
            java.lang.Object[] r13 = new java.lang.Object[r4]
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            r14 = 0
            r13[r14] = r11
            java.lang.String r11 = "enabling sproxy after %s fails"
            java.lang.String r11 = java.lang.String.format(r11, r13)
            r12.notice(r11)
            java.util.concurrent.atomic.AtomicBoolean r11 = r10.m_proxyjs_conn_sproxy
            r11.set(r4)
            goto L_0x0170
        L_0x015b:
            java.util.concurrent.atomic.AtomicBoolean r11 = r10.m_proxyjs_conn_sproxy
            boolean r11 = r11.get()
            if (r11 == 0) goto L_0x0170
            android.content.Context r11 = r10.m_ctx
            boolean r11 = io.lum.sdk.util.is_online(r11)
            if (r11 == 0) goto L_0x0170
            java.lang.String r11 = "connpxjs"
            io.lum.sdk.evaluation.set_is_unsupported(r11)
        L_0x0170:
            io.lum.sdk.conf$key r11 = io.lum.sdk.conf.FUNNEL_DEV_05_CONN_FAIL
            r10.perr_funnel_v(r11)
            io.lum.sdk.dev r11 = r10.m_dev
            java.net.InetAddress r12 = r10.m_local_ip
            r11.on_ip_conn_fail(r12)
            io.lum.sdk.util.update_sdk_info()
            return
        L_0x0180:
            java.util.concurrent.atomic.AtomicBoolean r14 = r10.m_proxyjs_conn_sproxy
            boolean r14 = r14.get()
            java.lang.String r3 = ":"
            if (r14 == 0) goto L_0x01af
            io.lum.sdk.sdk_proxy_pool r14 = io.lum.sdk.util.m_sdk_proxy_pool
            r14.success(r1)
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            java.lang.String r0 = r13.getProxyHost()
            r14.append(r0)
            r14.append(r3)
            int r13 = r13.getProxyPort()
            r14.append(r13)
            java.lang.String r13 = r14.toString()
            java.lang.String r14 = "proxyjs_conn_zagents"
            io.lum.sdk.util.perr((int) r2, (java.lang.String) r14, (java.lang.String) r11, (java.lang.String) r13, (boolean) r4)
            goto L_0x01c5
        L_0x01af:
            boolean r13 = r10.m_proxy_alias_used
            if (r13 == 0) goto L_0x01c5
            r13 = 2
            java.lang.Object[] r13 = new java.lang.Object[r13]
            r14 = 0
            r13[r14] = r11
            r13[r4] = r12
            java.lang.String r13 = java.lang.String.format(r0, r13)
            java.lang.String r0 = "proxyjs_conn_alias"
            io.lum.sdk.util.perr((int) r2, (java.lang.String) r0, (java.lang.Object) r13, (boolean) r4)
            goto L_0x01c6
        L_0x01c5:
            r14 = 0
        L_0x01c6:
            r10.m_is_redirect = r14
            io.lum.sdk.util$zerr r13 = r10.m_zerr
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            java.lang.String r0 = "proxyjs conn established: "
            r14.append(r0)
            r14.append(r11)
            java.lang.String r14 = r14.toString()
            r13.notice(r14)
            r10.m_proxyjs_ws = r15
            r10.m_last_proxy_url = r11
            r10.m_last_proxy_domain = r12
            io.lum.sdk.util$zerr r12 = r10.m_zerr
            io.lum.sdk.mux r12 = io.lum.sdk.mux.create(r15, r12)
            d.a.a.z r13 = new d.a.a.z
            r13.<init>(r10, r11, r12, r15)
            r15.setStringCallback(r13)
            d.a.a.e0 r13 = new d.a.a.e0
            r13.<init>(r10, r12)
            r15.setClosedCallback(r13)
            io.lum.sdk.conf r12 = r10.m_conf
            io.lum.sdk.conf$key r13 = io.lum.sdk.conf.WS_PING_PROXYJS
            boolean r12 = r12.get_bool(r13)
            if (r12 != 0) goto L_0x0205
            return
        L_0x0205:
            java.lang.String[] r11 = r11.split(r3)
            r11 = r11[r4]
            r12 = 2
            java.lang.String r11 = r11.substring(r12)
            java.lang.String r12 = "dev_conn/ws_ping/proxyjs/"
            java.lang.String r11 = b.a.a.a.a.a((java.lang.String) r12, (java.lang.String) r11)
            io.lum.sdk.conf r12 = r10.m_conf
            io.lum.sdk.conf$key r13 = io.lum.sdk.conf.WS_PING_PROXYJS_INTERVAL
            int r12 = r12.get_int(r13)
            io.lum.sdk.conf r13 = r10.m_conf
            io.lum.sdk.conf$key r14 = io.lum.sdk.conf.WS_PING_PROXYJS_TIMEOUT
            int r13 = r13.get_int(r14)
            d.a.a.s r14 = new d.a.a.s
            r14.<init>(r10, r15)
            io.lum.sdk.ws_ping.run(r11, r15, r12, r13, r14)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_conn.a(java.lang.String, java.lang.String, io.lum.sdk.async.http.AsyncHttpGet, java.lang.Exception, io.lum.sdk.async.http.WebSocket):void");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ void a(java.lang.String r12, java.lang.String r13, io.lum.sdk.mux r14, io.lum.sdk.async.http.WebSocket r15) {
        /*
            r11 = this;
            java.lang.String r0 = "cookie"
            java.lang.String r1 = ""
            r2 = 1
            r3 = 3
            io.lum.sdk.util$zerr r4 = r11.m_zerr     // Catch:{ Exception -> 0x0102 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0102 }
            r5.<init>()     // Catch:{ Exception -> 0x0102 }
            java.lang.String r6 = "zagent req str: "
            r5.append(r6)     // Catch:{ Exception -> 0x0102 }
            r5.append(r12)     // Catch:{ Exception -> 0x0102 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0102 }
            r4.debug(r5)     // Catch:{ Exception -> 0x0102 }
            org.json.JSONObject r4 = new org.json.JSONObject     // Catch:{ Exception -> 0x0102 }
            r4.<init>(r12)     // Catch:{ Exception -> 0x0102 }
            r12 = 0
            java.lang.String r5 = "msg"
            org.json.JSONObject r5 = r4.optJSONObject(r5)     // Catch:{ Exception -> 0x0102 }
            java.lang.String r6 = "cmd"
            java.lang.String r6 = r4.optString(r6, r1)     // Catch:{ Exception -> 0x0102 }
            int r7 = r6.hashCode()     // Catch:{ Exception -> 0x0102 }
            r8 = 4
            r9 = 2
            r10 = -1
            switch(r7) {
                case 99625: goto L_0x0061;
                case 115213: goto L_0x0057;
                case 194741574: goto L_0x004d;
                case 248333705: goto L_0x0043;
                case 300387975: goto L_0x0039;
                default: goto L_0x0038;
            }     // Catch:{ Exception -> 0x0102 }
        L_0x0038:
            goto L_0x006b
        L_0x0039:
            java.lang.String r7 = "tunnel_init"
            boolean r7 = r6.equals(r7)     // Catch:{ Exception -> 0x0102 }
            if (r7 == 0) goto L_0x006b
            r7 = 0
            goto L_0x006c
        L_0x0043:
            java.lang.String r7 = "status_get"
            boolean r7 = r6.equals(r7)     // Catch:{ Exception -> 0x0102 }
            if (r7 == 0) goto L_0x006b
            r7 = 1
            goto L_0x006c
        L_0x004d:
            java.lang.String r7 = "tun_close"
            boolean r7 = r6.equals(r7)     // Catch:{ Exception -> 0x0102 }
            if (r7 == 0) goto L_0x006b
            r7 = 3
            goto L_0x006c
        L_0x0057:
            java.lang.String r7 = "tun"
            boolean r7 = r6.equals(r7)     // Catch:{ Exception -> 0x0102 }
            if (r7 == 0) goto L_0x006b
            r7 = 2
            goto L_0x006c
        L_0x0061:
            java.lang.String r7 = "dns"
            boolean r7 = r6.equals(r7)     // Catch:{ Exception -> 0x0102 }
            if (r7 == 0) goto L_0x006b
            r7 = 4
            goto L_0x006c
        L_0x006b:
            r7 = -1
        L_0x006c:
            if (r7 == 0) goto L_0x00a1
            if (r7 == r2) goto L_0x0086
            if (r7 == r9) goto L_0x0081
            if (r7 == r3) goto L_0x007c
            if (r7 == r8) goto L_0x0077
            goto L_0x00a7
        L_0x0077:
            org.json.JSONObject r12 = r11.connect_dns(r5)     // Catch:{ Exception -> 0x0102 }
            goto L_0x00a7
        L_0x007c:
            org.json.JSONObject r12 = r11.cmd_tun_close(r5, r14)     // Catch:{ Exception -> 0x0102 }
            goto L_0x00a7
        L_0x0081:
            org.json.JSONObject r12 = r11.cmd_tun(r5, r14, r15)     // Catch:{ Exception -> 0x0102 }
            goto L_0x00a7
        L_0x0086:
            io.lum.sdk.util$zerr r12 = r11.m_zerr     // Catch:{ Exception -> 0x0102 }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0102 }
            r7.<init>()     // Catch:{ Exception -> 0x0102 }
            java.lang.String r8 = "status_get: "
            r7.append(r8)     // Catch:{ Exception -> 0x0102 }
            r7.append(r13)     // Catch:{ Exception -> 0x0102 }
            java.lang.String r13 = r7.toString()     // Catch:{ Exception -> 0x0102 }
            r12.debug(r13)     // Catch:{ Exception -> 0x0102 }
            org.json.JSONObject r12 = r11.status_get(r5)     // Catch:{ Exception -> 0x0102 }
            goto L_0x00a7
        L_0x00a1:
            java.lang.String r12 = "zagent"
            org.json.JSONObject r12 = r11.tunnel_init(r5, r12)     // Catch:{ Exception -> 0x0102 }
        L_0x00a7:
            java.lang.String r13 = "type"
            java.lang.String r13 = r4.optString(r13, r1)     // Catch:{ Exception -> 0x0102 }
            java.lang.String r1 = "ipc_post"
            boolean r13 = r13.equals(r1)     // Catch:{ Exception -> 0x0102 }
            if (r13 == 0) goto L_0x00b6
            return
        L_0x00b6:
            java.lang.String r13 = "ack"
            boolean r13 = r4.has(r13)     // Catch:{ Exception -> 0x0102 }
            if (r13 == 0) goto L_0x00c2
            r11.tun_ack(r4, r14)     // Catch:{ Exception -> 0x0102 }
            return
        L_0x00c2:
            java.lang.String r13 = "vfd"
            boolean r13 = r4.has(r13)     // Catch:{ Exception -> 0x0102 }
            if (r13 == 0) goto L_0x00ce
            r11.tun_vfd(r4, r14)     // Catch:{ Exception -> 0x0102 }
            return
        L_0x00ce:
            java.lang.String r13 = "fin"
            boolean r13 = r4.has(r13)     // Catch:{ Exception -> 0x0102 }
            if (r13 == 0) goto L_0x00da
            org.json.JSONObject r12 = r11.tun_fin(r4, r14)     // Catch:{ Exception -> 0x0102 }
        L_0x00da:
            boolean r13 = r4.has(r0)     // Catch:{ Exception -> 0x0102 }
            if (r13 == 0) goto L_0x00e4
            int r10 = r4.getInt(r0)     // Catch:{ Exception -> 0x0102 }
        L_0x00e4:
            java.lang.String r12 = r11.ipc_result(r6, r10, r12)     // Catch:{ Exception -> 0x0102 }
            io.lum.sdk.util$zerr r13 = r11.m_zerr     // Catch:{ Exception -> 0x0102 }
            java.lang.StringBuilder r14 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0102 }
            r14.<init>()     // Catch:{ Exception -> 0x0102 }
            java.lang.String r0 = "zagent resp str: "
            r14.append(r0)     // Catch:{ Exception -> 0x0102 }
            r14.append(r12)     // Catch:{ Exception -> 0x0102 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x0102 }
            r13.debug(r14)     // Catch:{ Exception -> 0x0102 }
            r15.send((java.lang.String) r12)     // Catch:{ Exception -> 0x0102 }
            goto L_0x010e
        L_0x0102:
            r12 = move-exception
            io.lum.sdk.util$zerr r13 = r11.m_zerr
            java.lang.String r13 = r13.tag()
            java.lang.String r14 = "dev_conn_tun_cmd_err"
            io.lum.sdk.util.perr((int) r3, (java.lang.String) r14, (java.lang.Object) r12, (java.lang.Object) r13, (boolean) r2)
        L_0x010e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_conn.a(java.lang.String, java.lang.String, io.lum.sdk.mux, io.lum.sdk.async.http.WebSocket):void");
    }

    public /* synthetic */ void a(Pattern pattern, etask etask, JSONObject jSONObject, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        try {
            this.m_test_socket_task_timer.cancel();
        } catch (Exception unused) {
        }
        String str = new String(byteBufferList.getAllByteArray());
        boolean find = pattern.matcher(str).find();
        etask.zcontinue(Boolean.valueOf(find));
        if (!find) {
            util.zerr zerr = this.m_zerr;
            zerr.notice("unexpected response: " + str);
        } else if (jSONObject.optBoolean("myip")) {
            try {
                this.m_myip_s = str.split("\\r\\n\\r\\n")[1].trim();
                JSONObject jSONObject2 = new JSONObject(this.m_myip_s);
                this.m_myip = jSONObject2;
                jSONObject2.put("ts", System.currentTimeMillis());
                this.m_ip = this.m_myip.optString("ip");
            } catch (Exception unused2) {
            }
        }
    }

    public /* synthetic */ void b(String str, WebSocket webSocket, milestone milestone2, int i, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        bw_update(str, 0, byteBufferList.remaining());
        check_milestones(webSocket, milestone2, i, 0, byteBufferList.remaining());
    }

    public /* synthetic */ void b(String str, mux mux, WebSocket webSocket, String str2) {
        etask.run((Runnable) new u(this, str2, str, mux, webSocket));
    }

    public /* synthetic */ void b(String str, String str2, mux mux, WebSocket webSocket) {
        util.zerr zerr = this.m_zerr;
        zerr.debug("proxyjs req str: " + str);
        try {
            JSONObject jSONObject = new JSONObject(str);
            JSONObject jSONObject2 = null;
            String string = jSONObject.getString("cmd");
            JSONObject optJSONObject = jSONObject.optJSONObject("msg");
            char c2 = 65535;
            switch (string.hashCode()) {
                case -1140373171:
                    if (string.equals("toobusy")) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 248333705:
                    if (string.equals("status_get")) {
                        c2 = 4;
                        break;
                    }
                    break;
                case 300387975:
                    if (string.equals("tunnel_init")) {
                        c2 = 0;
                        break;
                    }
                    break;
                case 769908065:
                    if (string.equals("cid_set")) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 951351530:
                    if (string.equals("connect")) {
                        c2 = 6;
                        break;
                    }
                    break;
                case 1041653641:
                    if (string.equals("remote_wbm")) {
                        c2 = 7;
                        break;
                    }
                    break;
                case 1623428563:
                    if (string.equals("tunnel_redirect")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 1698525989:
                    if (string.equals("perr_process")) {
                        c2 = 5;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    jSONObject2 = tunnel_init(optJSONObject, "proxyjs");
                    break;
                case 1:
                    tunnel_redirect(optJSONObject);
                    break;
                case 2:
                    toobusy(optJSONObject);
                    break;
                case 3:
                    cid_set(optJSONObject);
                    break;
                case 4:
                    util.zerr zerr2 = this.m_zerr;
                    zerr2.debug("status_get: " + str2);
                    jSONObject2 = status_get(optJSONObject);
                    break;
                case 5:
                    jSONObject2 = perr_process();
                    break;
                case 6:
                    connect(optJSONObject);
                    break;
                case 7:
                    jSONObject2 = remote_wbm(optJSONObject, mux);
                    break;
                default:
                    jSONObject2 = new JSONObject().put("message", "This method is unsupported");
                    break;
            }
            if (!jSONObject.getString("type").equals("ipc_post")) {
                String ipc_result = ipc_result(string, jSONObject.getInt("cookie"), jSONObject2);
                util.zerr zerr3 = this.m_zerr;
                zerr3.debug("proxyjs resp str: " + ipc_result);
                webSocket.send(ipc_result);
            }
        } catch (Throwable th) {
            util.perr("conn_cmd_err", th, this.m_zerr.tag());
        }
    }

    public void destroy() {
        try {
            down();
        } catch (Exception unused) {
        }
        if (this.m_push_status_report_enabled) {
            this.m_state.unregister_listener(this.m_state_listener);
            allow_status_report(false, 0);
        }
    }

    public void down() {
        synchronized (this.m_state_sync) {
            if (this.m_down_task == null) {
                this.m_zerr.notice("down");
                etask etask = this.m_up_task;
                this.m_up_task = null;
                this.m_down_task = etask.run((Runnable) new j(this, etask));
            }
        }
    }

    public void retry() {
        down();
        up(this.m_wait_ms);
        this.m_wait_ms = Math.min(this.m_wait_ms * 2, 1800000);
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:657)
        	at java.util.ArrayList.get(ArrayList.java:433)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:698)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    public void status_report(java.lang.String r10) {
        /*
            r9 = this;
            java.lang.Object r0 = r9.m_status_report_lock
            monitor-enter(r0)
            boolean r1 = r9.m_push_status_report_allowed     // Catch:{ all -> 0x008c }
            r2 = 2
            r3 = 0
            r4 = 1
            if (r1 != 0) goto L_0x0025
            java.lang.String r1 = "ts: %s, after: %s"
            java.util.ArrayList<java.lang.String> r5 = r9.m_status_reports     // Catch:{ all -> 0x008c }
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ all -> 0x008c }
            long r6 = java.lang.System.currentTimeMillis()     // Catch:{ all -> 0x008c }
            java.lang.Long r6 = java.lang.Long.valueOf(r6)     // Catch:{ all -> 0x008c }
            r2[r3] = r6     // Catch:{ all -> 0x008c }
            r2[r4] = r10     // Catch:{ all -> 0x008c }
            java.lang.String r10 = java.lang.String.format(r1, r2)     // Catch:{ all -> 0x008c }
            r5.add(r10)     // Catch:{ all -> 0x008c }
            monitor-exit(r0)     // Catch:{ all -> 0x008c }
            return
        L_0x0025:
            r9.m_push_status_report_allowed = r3     // Catch:{ all -> 0x008c }
            r1 = 3
            org.json.JSONObject r5 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0072 }
            r5.<init>()     // Catch:{ JSONException -> 0x0072 }
            org.json.JSONObject r5 = r9.status_get(r5)     // Catch:{ JSONException -> 0x0072 }
            java.lang.Object r6 = r9.m_ws_sync     // Catch:{ JSONException -> 0x0072 }
            monitor-enter(r6)     // Catch:{ JSONException -> 0x0072 }
            io.lum.sdk.async.http.WebSocket r7 = r9.m_proxyjs_ws     // Catch:{ all -> 0x006f }
            if (r7 == 0) goto L_0x006d
            io.lum.sdk.async.http.WebSocket r7 = r9.m_proxyjs_ws     // Catch:{ all -> 0x006f }
            java.lang.String r8 = "status_report"
            java.lang.String r8 = r9.ipc_post(r8, r5)     // Catch:{ all -> 0x006f }
            r7.send((java.lang.String) r8)     // Catch:{ all -> 0x006f }
            java.lang.String r7 = "status_report"
            java.lang.String r8 = "after: %s, status: %s"
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ all -> 0x006f }
            r2[r3] = r10     // Catch:{ all -> 0x006f }
            r2[r4] = r5     // Catch:{ all -> 0x006f }
            java.lang.String r10 = java.lang.String.format(r8, r2)     // Catch:{ all -> 0x006f }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x006f }
            r2.<init>()     // Catch:{ all -> 0x006f }
            java.lang.String r5 = "history: "
            r2.append(r5)     // Catch:{ all -> 0x006f }
            java.util.ArrayList<java.lang.String> r5 = r9.m_status_reports     // Catch:{ all -> 0x006f }
            r2.append(r5)     // Catch:{ all -> 0x006f }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x006f }
            io.lum.sdk.util.perr((int) r1, (java.lang.String) r7, (java.lang.String) r10, (java.lang.String) r2)     // Catch:{ all -> 0x006f }
            java.util.ArrayList<java.lang.String> r10 = r9.m_status_reports     // Catch:{ all -> 0x006f }
            r10.clear()     // Catch:{ all -> 0x006f }
            r3 = 1
        L_0x006d:
            monitor-exit(r6)     // Catch:{ all -> 0x006f }
            goto L_0x0080
        L_0x006f:
            r10 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x006f }
            throw r10     // Catch:{ JSONException -> 0x0072 }
        L_0x0072:
            r10 = move-exception
            java.lang.String r2 = "push_status_report_failed"
            java.lang.String r5 = r10.getMessage()     // Catch:{ all -> 0x008c }
            java.lang.String r10 = io.lum.sdk.util.e2s(r10)     // Catch:{ all -> 0x008c }
            io.lum.sdk.util.perr((int) r1, (java.lang.String) r2, (java.lang.String) r5, (java.lang.String) r10, (boolean) r4)     // Catch:{ all -> 0x008c }
        L_0x0080:
            monitor-exit(r0)     // Catch:{ all -> 0x008c }
            if (r3 == 0) goto L_0x0086
            long r0 = r9.m_push_status_report_freq
            goto L_0x0088
        L_0x0086:
            long r0 = r9.m_push_status_report_err_freq
        L_0x0088:
            r9.allow_status_report(r4, r0)
            return
        L_0x008c:
            r10 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x008c }
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_conn.status_report(java.lang.String):void");
    }

    public void up() {
        this.m_wait_ms = 1000;
        up(0);
    }

    public JSONObject wget(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        if (!(jSONObject.get("url") instanceof String) || !(jSONObject.get("fpath") instanceof String)) {
            util.zerr zerr = this.m_zerr;
            StringBuilder a2 = a.a("Malformed wget request: ");
            a2.append(jSONObject.toString());
            zerr.err(a2.toString());
            return null;
        }
        try {
            long currentTimeMillis = System.currentTimeMillis();
            String string = jSONObject.getString("fpath");
            int lastIndexOf = string.lastIndexOf(47);
            String substring = string.substring(0, lastIndexOf);
            String substring2 = string.substring(lastIndexOf + 1);
            AsyncHttpGet asyncHttpGet = new AsyncHttpGet(jSONObject.getString("url"));
            AsyncHttpClient defaultInstance = AsyncHttpClient.getDefaultInstance();
            File file = (File) defaultInstance.executeFile(asyncHttpGet, substring + "/" + substring2, (AsyncHttpClient.FileCallback) null).get();
            long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
            long length = file.length();
            jSONObject2.put("dur", currentTimeMillis2);
            jSONObject2.put("fsize", length);
            jSONObject2.put("sha1sum", dev_util.SHA1(file));
        } catch (Exception e2) {
            util.perr(3, "dev_conn_cmd_wget_err", (Object) e2, (Object) this.m_zerr.tag(), true);
        }
        return jSONObject2;
    }
}
