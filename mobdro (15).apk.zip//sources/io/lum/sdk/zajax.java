package io.lum.sdk;

import android.net.Uri;
import b.a.a.a.a;
import d.a.a.a2;
import d.a.a.v1;
import d.a.a.w1;
import d.a.a.x1;
import d.a.a.y1;
import d.a.a.z1;
import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpGet;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import org.json.JSONObject;

public class zajax {
    public int m_ajax_done;
    public aq_wrapper m_aq_wrapper = new aq_wrapper();
    public boolean m_done;
    public String m_host;
    public int m_ip_index;
    public String[] m_ips;
    public final Object m_lock = new Object();
    public String m_prot;
    public String m_uri;

    public static class aq_wrapper {
        public String m_proxy_domain;
        public String m_proxy_host = "";
        public int m_proxy_port;
        public boolean m_proxy_ssl = false;

        public interface callback {
            boolean run(String str, JSONObject jSONObject);
        }

        private void zerr(int i, String str) {
            util._zerr("lumsdk/zajax/aq_wrapper", i, str);
        }

        public /* synthetic */ void a(String str, String str2, callback callback2) {
            JSONObject jSONObject = null;
            try {
                AsyncHttpGet asyncHttpGet = new AsyncHttpGet(str);
                if (!util.has_sni()) {
                    asyncHttpGet.set_domain_uri(Uri.parse("https://" + str2));
                }
                asyncHttpGet.setHeader("User-Agent", util.get_ua());
                asyncHttpGet.setTimeout(10000);
                if (!this.m_proxy_host.isEmpty()) {
                    asyncHttpGet.enable_proxy(this.m_proxy_host, this.m_proxy_port, this.m_proxy_domain, this.m_proxy_ssl);
                    asyncHttpGet.setHeader("Connection", "close");
                }
                jSONObject = (JSONObject) AsyncHttpClient.getDefaultInstance().executeJSONObject(asyncHttpGet, (AsyncHttpClient.JSONObjectCallback) null).get();
            } catch (Exception e2) {
                zerr(5, "fail: " + e2);
            }
            callback2.run(str, jSONObject);
        }

        public void ajax(String str, callback callback2) {
            ajax((String) null, str, callback2);
        }

        public void ajax(String str, String str2, callback callback2) {
            util.thread_run(new z1(this, str2, str, callback2), "aq_wrapper_ajax");
        }

        public void proxy(String str, int i) {
            this.m_proxy_host = str;
            this.m_proxy_port = i;
        }

        public void proxy(String str, int i, String str2, boolean z) {
            proxy(str, i);
            this.m_proxy_domain = str2;
            this.m_proxy_ssl = z;
        }
    }

    public zajax(String[] strArr, String str, String str2, String str3) {
        this.m_ips = rotate_array(strArr);
        this.m_prot = str;
        this.m_host = str2;
        if (str3 != null) {
            set_uri(str3);
        }
    }

    private void cache_addr(String str, String str2, boolean z) {
        String str3 = util.m_conf.get_str(conf.LAST_WORKING_PROT_CCGI);
        String str4 = util.m_conf.get_str(conf.LAST_WORKING_HOST_CCGI);
        boolean z2 = util.m_conf.get_bool(conf.LAST_WORKING_PROXY_CCGI);
        util.m_conf.set(conf.LAST_WORKING_PROT_CCGI, str);
        util.m_conf.set(conf.LAST_WORKING_HOST_CCGI, str2);
        util.m_conf.set(conf.LAST_WORKING_PROXY_CCGI, z);
        if (str4.isEmpty()) {
            if (z2 != z || !str3.equals(str) || !str4.equals(str2)) {
                StringBuilder a2 = a.a("protocol: ");
                if (!str3.equals(str)) {
                    a2.append(str3);
                    a2.append(" -> ");
                }
                a2.append(str);
                a2.append(", host: ");
                if (!str4.equals(str2)) {
                    a2.append(str4);
                    a2.append(" -> ");
                }
                a2.append(str2);
                a2.append(", proxy: ");
                String str5 = "yes";
                String str6 = z ? str5 : "no";
                if (z2 != z) {
                    if (!z2) {
                        str5 = "no";
                    }
                    a2.append(str5);
                    a2.append(" -> ");
                }
                a2.append(str6);
                util.perr("ajax_host_changed", a2.toString());
            }
        }
    }

    private void inc_ips_i() {
        this.m_ip_index = (this.m_ip_index + 1) % this.m_ips.length;
    }

    private String[] rotate_array(String[] strArr) {
        int length = strArr.length;
        String[] strArr2 = new String[length];
        int nextInt = new Random().nextInt(length);
        for (int i = 0; i < length; i++) {
            strArr2[i] = strArr[(i + nextInt) % length];
        }
        return strArr2;
    }

    public static void zerr(int i, String str) {
        util._zerr("lumsdk/zajax", i, str);
    }

    public /* synthetic */ boolean a(aq_wrapper.callback callback, String str, String str2, JSONObject jSONObject) {
        if (callback.run(str2, jSONObject)) {
            cache_addr("http://", str, false);
            zerr(5, "ajax direct " + str2);
            return true;
        }
        inc_ips_i();
        return true;
    }

    public /* synthetic */ boolean a(aq_wrapper.callback callback, String str, JSONObject jSONObject) {
        if (!callback.run(str, jSONObject)) {
            return true;
        }
        cache_addr(this.m_prot, this.m_host, false);
        zerr(5, "ajax retry " + str);
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0027, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ boolean a(io.lum.sdk.zajax.aq_wrapper.callback r6, boolean r7, io.lum.sdk.etask r8, java.lang.String r9, org.json.JSONObject r10) {
        /*
            r5 = this;
            java.lang.Object r0 = r5.m_lock
            monitor-enter(r0)
            int r1 = r5.m_ajax_done     // Catch:{ all -> 0x0028 }
            r2 = 1
            int r1 = r1 + r2
            r5.m_ajax_done = r1     // Catch:{ all -> 0x0028 }
            boolean r3 = r5.m_done     // Catch:{ all -> 0x0028 }
            r4 = 0
            if (r3 == 0) goto L_0x0010
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return r4
        L_0x0010:
            r3 = 3
            if (r1 == r3) goto L_0x0018
            if (r10 == 0) goto L_0x0016
            goto L_0x0018
        L_0x0016:
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return r4
        L_0x0018:
            r5.m_done = r2     // Catch:{ all -> 0x0028 }
            r6.run(r9, r10)     // Catch:{ all -> 0x0028 }
            if (r7 == 0) goto L_0x0026
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r2)     // Catch:{ all -> 0x0028 }
            r8.zcontinue(r6)     // Catch:{ all -> 0x0028 }
        L_0x0026:
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return r2
        L_0x0028:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.zajax.a(io.lum.sdk.zajax$aq_wrapper$callback, boolean, io.lum.sdk.etask, java.lang.String, org.json.JSONObject):boolean");
    }

    public /* synthetic */ boolean a(boolean z, aq_wrapper.callback callback, boolean z2, etask etask, String str, JSONObject jSONObject) {
        if (jSONObject != null) {
            if (z) {
                util.m_sdk_proxy_pool.success("wget");
            }
            callback.run(str, jSONObject);
            if (z2) {
                etask.zcontinue(true);
            }
            return false;
        }
        if (z) {
            util.m_sdk_proxy_pool.failure("wget");
        } else {
            inc_ips_i();
        }
        String str2 = this.m_ips[this.m_ip_index];
        y1 y1Var = new y1(this, callback, z2, etask);
        if (str2 != null) {
            aq_wrapper aq_wrapper2 = this.m_aq_wrapper;
            StringBuilder b2 = a.b("http://", str2);
            b2.append(this.m_uri);
            aq_wrapper2.ajax(b2.toString(), new a2(this, y1Var, str2));
        }
        String str3 = this.m_prot + this.m_host + this.m_uri;
        this.m_aq_wrapper.ajax(str3, new x1(this, y1Var));
        if (!str3.contains("country=") && util.m_conf.exist(conf.COUNTRY_LOCAL_MYIP)) {
            StringBuilder b3 = a.b(str3, "&");
            b3.append(util.str2query("country", util.m_conf.get_str(conf.COUNTRY_LOCAL_MYIP).toLowerCase()));
            str3 = b3.toString();
        }
        String str4 = util.m_sdk_proxy_pool.get_host();
        int i = util.m_sdk_proxy_pool.get_port();
        this.m_aq_wrapper.proxy(str4, i, util.m_sdk_proxy_pool.get_domain(), util.m_sdk_proxy_pool.get_ssl());
        this.m_aq_wrapper.ajax(str3, new w1(this, y1Var));
        zerr(5, String.format("ajax with zagent %s:%s url %s", new Object[]{str4, Integer.valueOf(i), str3}));
        this.m_aq_wrapper.proxy("", -1);
        return true;
    }

    public void ajax(aq_wrapper.callback callback) {
        ajax(callback, false);
    }

    public void ajax(aq_wrapper.callback callback, boolean z) {
        etask zwait = etask.zwait();
        String str = util.m_conf.get_str(conf.LAST_WORKING_HOST_CCGI);
        String str2 = util.m_conf.get_str(conf.LAST_WORKING_PROT_CCGI);
        String str3 = util.get_ssl_servername((String) null, conf.CCGI_SSL_HOST, zon_conf.CCGI_SSL_HOST);
        boolean z2 = util.m_conf.get_bool(conf.DBG_FORCE_PROXY, util.m_conf.get_bool(conf.LAST_WORKING_PROXY_CCGI));
        if (str.isEmpty() || str2.isEmpty()) {
            str = this.m_host;
            str2 = this.m_prot;
        } else if (z2) {
            this.m_aq_wrapper.proxy(util.m_sdk_proxy_pool.get_host(), util.m_sdk_proxy_pool.get_port(), util.m_sdk_proxy_pool.get_domain(), util.m_sdk_proxy_pool.get_ssl());
            if (!this.m_uri.contains("country=") && util.m_conf.exist(conf.COUNTRY_LOCAL_MYIP)) {
                this.m_uri += "&" + util.str2query("country", util.m_conf.get_str(conf.COUNTRY_LOCAL_MYIP).toLowerCase());
            }
        }
        aq_wrapper aq_wrapper2 = this.m_aq_wrapper;
        StringBuilder b2 = a.b(str2, str);
        b2.append(this.m_uri);
        aq_wrapper2.ajax(str3, b2.toString(), new v1(this, z2, callback, z, zwait));
        this.m_aq_wrapper.proxy("", -1);
        if (z) {
            try {
                zwait.yield();
            } catch (InterruptedException | ExecutionException e2) {
                StringBuilder a2 = a.a("sync failed: ");
                a2.append(util.e2s(e2));
                zerr(3, a2.toString());
            }
        }
    }

    public /* synthetic */ boolean b(aq_wrapper.callback callback, String str, JSONObject jSONObject) {
        if (callback.run(str, jSONObject)) {
            util.m_sdk_proxy_pool.success("zajax");
            cache_addr(this.m_prot, this.m_host, true);
            zerr(5, "ajax proxy zagent " + str);
        } else {
            util.m_sdk_proxy_pool.failure("zajax");
        }
        return true;
    }

    public zajax set_uri(String str) {
        this.m_uri = str;
        return this;
    }
}
