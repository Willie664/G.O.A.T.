package io.lum.sdk;

import b.a.a.a.a;
import d.a.a.n1;
import io.lum.sdk.async.http.server.AsyncHttpServer;
import io.lum.sdk.async.http.server.AsyncHttpServerRequest;
import io.lum.sdk.async.http.server.AsyncHttpServerResponse;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.GZIPOutputStream;

public class wbm_server {
    public wbm_server(int i) {
        AsyncHttpServer asyncHttpServer = new AsyncHttpServer();
        init_fs_cgi(asyncHttpServer);
        asyncHttpServer.listen(i);
    }

    private String get_dir_page(String str, File file) {
        String str2 = str;
        if (!file.canRead()) {
            return "<h1>Has no permissions</h1>";
        }
        File[] listFiles = file.listFiles();
        String a2 = a.a("<h2>Index of ", str2, "</h2>");
        String a3 = a.a("<a href=\"/fs_cgi/", str2, "/..\">/..</a><br/>");
        StringBuilder sb = new StringBuilder("<div>");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yy HH:mm:ss", new Locale("en", "US"));
        for (File file2 : listFiles) {
            String absolutePath = file2.getAbsolutePath();
            String name = file2.getName();
            Date date = new Date();
            date.setTime(file2.lastModified() + ((long) (date.getTimezoneOffset() * util.MS_MIN)));
            sb.append(simpleDateFormat.format(date));
            sb.append(normalize_str(String.valueOf(file2.length())));
            sb.append("   ");
            sb.append("<a href=\"/fs_cgi/");
            sb.append(absolutePath);
            sb.append("\">");
            sb.append(name);
            sb.append("</a>  ");
            sb.append("(<a href=\"/fs_cgi/");
            sb.append(absolutePath);
            sb.append("?gzip=1\">.gz");
            sb.append("</a>)<br/>");
        }
        sb.append("</div>");
        return a2 + "<pre><hr>" + a3 + sb + "</pre>";
    }

    private void init_fs_cgi(AsyncHttpServer asyncHttpServer) {
        asyncHttpServer.get("/fs.cgi/.*", new n1(this));
    }

    private String normalize_str(String str) {
        if (str.length() >= 10) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10 - str.length(); i++) {
            sb.append(" ");
        }
        return sb + str;
    }

    private void send_gzip_file(File file, AsyncHttpServerResponse asyncHttpServerResponse) {
        try {
            String name = file.getName();
            String substring = name.substring(0, name.lastIndexOf(46));
            if (!file.renameTo(new File(substring + ".gz"))) {
                util._zerr("wbm_server", 3, "file rename failed");
            }
            byte[] bArr = new byte[1024];
            FileInputStream fileInputStream = new FileInputStream(file);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read > 0) {
                    gZIPOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    gZIPOutputStream.finish();
                    asyncHttpServerResponse.send(file.getName() + ".gz", byteArrayOutputStream.toByteArray());
                    gZIPOutputStream.close();
                    return;
                }
            }
        } catch (IOException e2) {
            util._zerr("wbm_server", 2, "get gzip error: " + e2);
        }
    }

    public /* synthetic */ void a(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        String str;
        String path = asyncHttpServerRequest.getPath();
        String substring = path.length() > 8 ? path.substring(8) : "/";
        if (substring.charAt(substring.length() - 1) == '/') {
            substring = substring.substring(0, substring.length() - 1);
        }
        if (substring.length() == 0) {
            substring = "/";
        }
        File file = new File(substring);
        if (file.isDirectory()) {
            str = get_dir_page(substring, file);
        } else if (substring.equals("/")) {
            str = "Root is not accesible";
        } else if (asyncHttpServerRequest.get("gzip") != null) {
            send_gzip_file(file, asyncHttpServerResponse);
            return;
        } else {
            asyncHttpServerResponse.setContentType("application/force-download");
            asyncHttpServerResponse.sendFile(file);
            return;
        }
        asyncHttpServerResponse.send(str);
    }
}
