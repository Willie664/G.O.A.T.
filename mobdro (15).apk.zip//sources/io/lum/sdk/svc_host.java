package io.lum.sdk;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import d.a.a.a1;
import io.lum.sdk.util;
import java.util.Timer;
import java.util.TimerTask;

public class svc_host extends Service {
    public static final String FALLBACK_LEGACY = "legacy";
    public static final String FALLBACK_NONE = "none";
    public static int m_retries = 0;
    public static int m_retries_max = 3;
    public static boolean m_svc_fallback_legacy = false;
    public static boolean m_svc_fallback_legacy_enable = false;
    public static boolean m_svc_fallback_loaded = false;
    public static Boolean m_svc_lock = false;
    public static int m_svc_start_timeout = 2000;
    public static long m_svc_verify_ms = FragmentStateAdapter.GRACE_WINDOW_TIME_MS;
    public static Timer start_validate_timer = new Timer();

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0034, code lost:
        if ((io.lum.sdk.util.has_job_scheduler() ? r4.startForegroundService(r0) : r4.startService(r0)) != null) goto L_0x0036;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0014, code lost:
        if (io.lum.sdk.svc_job.schedule_job(r4, r5) == 1) goto L_0x0036;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(android.content.Context r4, java.lang.String r5) {
        /*
            boolean r0 = m_svc_fallback_legacy
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x0019
            boolean r0 = io.lum.sdk.util.has_job_scheduler()
            if (r0 != 0) goto L_0x000d
            goto L_0x0019
        L_0x000d:
            io.lum.sdk.svc_job.cancel_jobs(r4)
            int r0 = io.lum.sdk.svc_job.schedule_job(r4, r5)
            if (r0 != r2) goto L_0x0017
            goto L_0x0036
        L_0x0017:
            r2 = 0
            goto L_0x0036
        L_0x0019:
            android.content.Intent r0 = new android.content.Intent
            java.lang.Class<io.lum.sdk.svc_host> r3 = io.lum.sdk.svc_host.class
            r0.<init>(r4, r3)
            java.lang.String r3 = "task_id"
            r0.putExtra(r3, r5)
            boolean r3 = io.lum.sdk.util.has_job_scheduler()
            if (r3 == 0) goto L_0x0030
            android.content.ComponentName r0 = r4.startForegroundService(r0)
            goto L_0x0034
        L_0x0030:
            android.content.ComponentName r0 = r4.startService(r0)
        L_0x0034:
            if (r0 == 0) goto L_0x0017
        L_0x0036:
            if (r2 == 0) goto L_0x003c
            start_validate(r4, r5)
            goto L_0x004a
        L_0x003c:
            java.lang.String r0 = "denial"
            boolean r4 = start_retry(r4, r5, r0)
            if (r4 != 0) goto L_0x004a
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r1)
            m_svc_lock = r4
        L_0x004a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.svc_host.a(android.content.Context, java.lang.String):void");
    }

    private void start() {
        if (util.has_job_scheduler()) {
            startForeground(util.get_notification_id(), new Notification.Builder(this).setChannelId(util.NOTIFICATION_CHANNEL_ID).build());
        }
        if (util.util_init(this, "svc_host") < 0) {
            util.perr_funnel_main_send("02_svc_host_start_fail", "util_init");
            util.perr(3, "svc_host_start_fail_util_init", true);
            return;
        }
        int i = new conf(this).get_int(conf.SVC_KEEPALIVE_PERIOD);
        if (i <= 60000) {
            i = util.MS_HOUR;
        }
        util.get_svc_keepalive().start(this, i, util.MS_MIN);
        util.create_bcast_handler(this, util.get_uuid(this));
    }

    public static void start(Context context, String str) {
        start(context, str, false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0019, code lost:
        m_svc_fallback_legacy = false;
        m_retries = 0;
        r8.getPackageName();
        r10 = new io.lum.sdk.conf(r8);
        m_svc_fallback_legacy_enable = r10.get_bool(io.lum.sdk.conf.SVC_FALLBACK_LEGACY, true);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0039, code lost:
        if (r10.get_long(io.lum.sdk.conf.SVC_FALLBACK_UNTIL) <= java.lang.System.currentTimeMillis()) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x003b, code lost:
        r10 = r10.get_str(io.lum.sdk.conf.SVC_FALLBACK, FALLBACK_NONE);
        zerr_s(5, "last svc fallback: " + r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x005f, code lost:
        if (r10.hashCode() == -1106578487) goto L_0x0062;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0068, code lost:
        if (r10.equals(FALLBACK_LEGACY) == false) goto L_0x006b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x006b, code lost:
        r0 = 65535;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x006c, code lost:
        if (r0 == 0) goto L_0x006f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0071, code lost:
        if (m_svc_fallback_legacy_enable == false) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0073, code lost:
        zerr_s(5, "applying last svc fallback: " + r10);
        m_svc_fallback_legacy = true;
        m_svc_fallback_loaded = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x008b, code lost:
        r10 = "starting";
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void start(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            r0 = 0
            r1 = 5
            r2 = 1
            if (r10 != 0) goto L_0x0091
            java.lang.Boolean r10 = m_svc_lock
            monitor-enter(r10)
            java.lang.Boolean r3 = m_svc_lock     // Catch:{ all -> 0x008e }
            boolean r3 = r3.booleanValue()     // Catch:{ all -> 0x008e }
            if (r3 == 0) goto L_0x0012
            monitor-exit(r10)     // Catch:{ all -> 0x008e }
            return
        L_0x0012:
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r2)     // Catch:{ all -> 0x008e }
            m_svc_lock = r3     // Catch:{ all -> 0x008e }
            monitor-exit(r10)     // Catch:{ all -> 0x008e }
            m_svc_fallback_legacy = r0
            m_retries = r0
            r8.getPackageName()
            io.lum.sdk.conf r10 = new io.lum.sdk.conf
            r10.<init>(r8)
            io.lum.sdk.conf$key r3 = io.lum.sdk.conf.SVC_FALLBACK_LEGACY
            boolean r3 = r10.get_bool(r3, r2)
            m_svc_fallback_legacy_enable = r3
            io.lum.sdk.conf$key r3 = io.lum.sdk.conf.SVC_FALLBACK_UNTIL
            long r3 = r10.get_long(r3)
            long r5 = java.lang.System.currentTimeMillis()
            int r7 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r7 <= 0) goto L_0x008b
            io.lum.sdk.conf$key r3 = io.lum.sdk.conf.SVC_FALLBACK
            java.lang.String r4 = "none"
            java.lang.String r10 = r10.get_str(r3, r4)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "last svc fallback: "
            r3.append(r4)
            r3.append(r10)
            java.lang.String r3 = r3.toString()
            zerr_s(r1, r3)
            r3 = -1
            int r4 = r10.hashCode()
            r5 = -1106578487(0xffffffffbe0af3c9, float:-0.13569559)
            if (r4 == r5) goto L_0x0062
            goto L_0x006b
        L_0x0062:
            java.lang.String r4 = "legacy"
            boolean r4 = r10.equals(r4)
            if (r4 == 0) goto L_0x006b
            goto L_0x006c
        L_0x006b:
            r0 = -1
        L_0x006c:
            if (r0 == 0) goto L_0x006f
            goto L_0x008b
        L_0x006f:
            boolean r0 = m_svc_fallback_legacy_enable
            if (r0 == 0) goto L_0x008b
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r3 = "applying last svc fallback: "
            r0.append(r3)
            r0.append(r10)
            java.lang.String r10 = r0.toString()
            zerr_s(r1, r10)
            m_svc_fallback_legacy = r2
            m_svc_fallback_loaded = r2
        L_0x008b:
            java.lang.String r10 = "starting"
            goto L_0x00ad
        L_0x008e:
            r8 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x008e }
            throw r8
        L_0x0091:
            r10 = 2
            java.lang.Object[] r10 = new java.lang.Object[r10]
            int r3 = m_retries
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r10[r0] = r3
            boolean r0 = m_svc_fallback_legacy
            if (r0 == 0) goto L_0x00a3
            java.lang.String r0 = " (fallback: legacy)"
            goto L_0x00a5
        L_0x00a3:
            java.lang.String r0 = ""
        L_0x00a5:
            r10[r2] = r0
            java.lang.String r0 = "start retry: %s %s"
            java.lang.String r10 = java.lang.String.format(r0, r10)
        L_0x00ad:
            zerr_s(r1, r10)
            d.a.a.z0 r10 = new d.a.a.z0
            r10.<init>(r8, r9)
            int r8 = m_svc_start_timeout
            java.lang.String r9 = "svc_host_start"
            io.lum.sdk.util.thread_run((java.lang.Runnable) r10, (java.lang.String) r9, (int) r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.svc_host.start(android.content.Context, java.lang.String, boolean):void");
    }

    public static boolean start_retry(Context context, String str, String str2) {
        int i = m_retries + 1;
        m_retries = i;
        if (i < m_retries_max) {
            start(context, str, true);
            return true;
        } else if (!util.has_job_scheduler() || m_svc_fallback_legacy || !m_svc_fallback_legacy_enable) {
            Object[] objArr = new Object[3];
            objArr[0] = Integer.valueOf(m_retries);
            objArr[1] = m_svc_fallback_legacy ? FALLBACK_LEGACY : FALLBACK_NONE;
            objArr[2] = str2;
            String format = String.format("retries: %s, fallback: %s, reason: %s", objArr);
            util.perr_funnel_main_send("49_svc_host_start_fail", format);
            zerr_s(3, "svc host start failed: " + str2);
            util.perr(3, "svc_host_start_fail", format, "", true);
            if (m_svc_fallback_legacy) {
                util.perr(3, "svc_host_start_fail_legacy", true);
            }
            util.perr_funnel(conf.FUNNEL_05_SERVICE_START_FAIL);
            return false;
        } else {
            zerr_s(5, "trying fallback: legacy");
            m_retries = 0;
            m_svc_fallback_legacy = true;
            start(context, str, true);
            return true;
        }
    }

    public static void start_validate(final Context context, final String str) {
        start_validate_timer.schedule(new TimerTask() {
            public void run() {
                if (util.m_bcast_client.is_connected()) {
                    String str = svc_host.m_svc_fallback_legacy ? svc_host.FALLBACK_LEGACY : svc_host.FALLBACK_NONE;
                    String format = String.format("retries: %s, fallback: %s", new Object[]{Integer.valueOf(svc_host.m_retries), str});
                    if (!svc_host.FALLBACK_NONE.equals(str)) {
                        util.perr(5, "svc_host_start_fallback", format, "", true);
                        util.perr(5, "svc_host_start_fallback_" + str, format, "", true);
                        if (!svc_host.m_svc_fallback_loaded) {
                            conf conf = new conf(context);
                            long j = conf.get_long(conf.SVC_FALLBACK_FOR, 3600000);
                            int unused = svc_host.zerr_s(5, "saving last svc fallback for " + j + "ms");
                            conf.set(conf.SVC_FALLBACK, str);
                            conf.set(conf.SVC_FALLBACK_UNTIL, System.currentTimeMillis() + j);
                        }
                    } else {
                        util.perr(5, "svc_host_start", format, "", true);
                    }
                    if (svc_host.m_retries > 0) {
                        util.perr(3, "svc_host_start_retries", format, "", true);
                    }
                    util.perr_funnel_main_send("50_svc_host_start_success", format);
                    Boolean unused2 = svc_host.m_svc_lock = false;
                } else if (!svc_host.start_retry(context, str, "timeout")) {
                    Boolean unused3 = svc_host.m_svc_lock = false;
                }
            }
        }, m_svc_verify_ms);
    }

    private void stop() {
        util.destroy_bcast_handler();
        util.get_svc_keepalive().stop();
        util.util_uninit();
    }

    public static void stop(Context context, boolean z) {
        zerr_s(5, "stopping");
        if (!m_svc_fallback_legacy && util.has_job_scheduler()) {
            svc_job.cancel_job(context);
        } else if (!context.stopService(new Intent(context, svc_host.class)) && !z) {
            zerr_s(3, "nothing found to stop");
        }
    }

    public static int zerr_s(int i, String str) {
        return util._zerr("lumsdk/svc_host:s", i, str);
    }

    public /* synthetic */ void a() {
        stop();
        start();
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onDestroy() {
        stop();
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            util.set_uuid(intent.getStringExtra("task_id"));
        } catch (Exception unused) {
        }
        Thread.setDefaultUncaughtExceptionHandler(new util.exception_handler("svc_host", new a1(this)));
        start();
        return 1;
    }

    public void onTaskRemoved(Intent intent) {
        util.get_svc_keepalive().schedule(this, 5000);
        util.log_mobile_usage(this);
        onDestroy();
        if (util.has_job_scheduler()) {
            stopForeground(true);
        } else {
            stopSelf();
        }
    }
}
