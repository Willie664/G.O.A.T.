package io.lum.sdk;

import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import android.os.Process;
import b.a.a.a.a;
import d.a.a.b1;
import d.a.a.c1;
import io.lum.sdk.util;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

@SuppressLint({"NewApi"})
public class svc_job extends JobService {
    public int m_job_id = 0;
    public JobParameters m_job_params;
    public int m_keepalive_period = util.MS_HOUR;
    public boolean m_kill_process = false;
    public int m_max_duration = 570000;
    public final Object m_max_duration_lock = new Object();
    public Timer m_max_duration_timer;
    public int m_next_run_delay = util.MS_MIN;
    public boolean m_running = false;
    public final Object m_running_lock = new Object();

    public static /* synthetic */ void a(int i, ArrayList arrayList, JobInfo jobInfo) {
        int id = jobInfo.getId();
        if (id >= util.get_min_job_id() && id <= util.get_max_job_id() && id != i) {
            arrayList.add(Integer.valueOf(jobInfo.getId()));
        }
    }

    public static void cancel_job(JobScheduler jobScheduler, int i) {
        jobScheduler.cancel(i);
    }

    public static void cancel_job(Context context) {
        cancel_job(context, util.get_max_job_id());
    }

    public static void cancel_job(Context context, int i) {
        cancel_job(get_job_scheduler(context), i);
    }

    public static void cancel_jobs(JobScheduler jobScheduler, ArrayList<Integer> arrayList) {
        Iterator<Integer> it = arrayList.iterator();
        while (it.hasNext()) {
            jobScheduler.cancel(it.next().intValue());
        }
    }

    public static void cancel_jobs(Context context) {
        cancel_pending(context, 0);
    }

    public static void cancel_pending(Context context, int i) {
        ArrayList arrayList = new ArrayList();
        JobScheduler jobScheduler = get_job_scheduler(context);
        get_pending_jobs(jobScheduler).forEach(new c1(i, arrayList));
        if (arrayList.size() > 0) {
            zerr_s(5, "cancel pending");
            cancel_jobs(jobScheduler, arrayList);
        }
    }

    private void create_stop_timer() {
        synchronized (this.m_max_duration_lock) {
            if (this.m_max_duration_timer == null) {
                Timer timer = new Timer();
                this.m_max_duration_timer = timer;
                timer.schedule(new TimerTask() {
                    public void run() {
                        try {
                            svc_job.this.zerr(5, String.format("self-stop after %sms", new Object[]{Integer.valueOf(svc_job.this.m_max_duration)}));
                            svc_job.cancel_job((Context) svc_job.this, svc_job.this.m_job_id);
                            svc_job.this.finish();
                        } catch (Exception unused) {
                        }
                    }
                }, (long) this.m_max_duration);
            }
        }
    }

    private void destroy_stop_timer() {
        synchronized (this.m_max_duration_lock) {
            if (this.m_max_duration_timer != null) {
                this.m_max_duration_timer.cancel();
                this.m_max_duration_timer = null;
            }
        }
    }

    /* access modifiers changed from: private */
    public synchronized void finish() {
        if (this.m_job_params != null) {
            zerr(5, "finish job");
            jobFinished(this.m_job_params, false);
            this.m_job_params = null;
        }
    }

    public static JobScheduler get_job_scheduler(Context context) {
        return (JobScheduler) context.getSystemService(JobScheduler.class);
    }

    public static List<JobInfo> get_pending_jobs(JobScheduler jobScheduler) {
        List<JobInfo> allPendingJobs = jobScheduler.getAllPendingJobs();
        int size = allPendingJobs.size();
        if (size == 0) {
            zerr_s(5, "no pending jobs");
        } else {
            zerr_s(5, "pending jobs: " + allPendingJobs);
            if (size > 2) {
                util.perr(3, "too_many_jobs", true);
            }
        }
        return allPendingJobs;
    }

    public static int schedule_job(Context context, String str) {
        return schedule_job(context, str, util.get_max_job_id(), 0);
    }

    public static int schedule_job(Context context, String str, int i, int i2) {
        JobInfo.Builder builder = new JobInfo.Builder(i, new ComponentName(context, svc_job.class));
        if (str != null) {
            PersistableBundle persistableBundle = new PersistableBundle();
            persistableBundle.putString("task_id", str);
            builder.setExtras(persistableBundle);
        }
        builder.setMinimumLatency((long) i2);
        builder.setOverrideDeadline(86400000);
        return get_job_scheduler(context).schedule(builder.build());
    }

    private void schedule_next_run() {
        zerr(5, String.format("schedule next run in %sms", new Object[]{Integer.valueOf(this.m_next_run_delay)}));
        util.get_svc_job_keepalive(this.m_job_id).reschedule(this, this.m_next_run_delay);
    }

    private boolean start() {
        synchronized (this.m_running_lock) {
            if (this.m_running) {
                return true;
            }
            this.m_running = true;
            if (util.util_init(this, "svc_job") < 0) {
                util.perr_funnel_main_send("02_svc_host_start_fail", "util_init");
                util.perr(3, "svc_host_job_fail_util_init", true);
                this.m_running = false;
                return false;
            }
            zerr(5, "starting svc_job");
            conf conf = new conf(this);
            this.m_kill_process = conf.get_bool(conf.SVC_JOB_KILL_PROCESS);
            int i = conf.get_int(conf.SVC_JOB_KEEPALIVE_PERIOD);
            if (i > 60000) {
                this.m_keepalive_period = i;
            }
            util.get_svc_job_keepalive(this.m_job_id).start(this, this.m_keepalive_period, util.MS_MIN);
            int i2 = conf.get_int(conf.SVC_JOB_NEXT_RUN_DELAY);
            if (i2 > 5000) {
                this.m_next_run_delay = i2;
            }
            int i3 = conf.get_int(conf.SVC_JOB_MAX_DURATION);
            if (i3 > 300000) {
                this.m_max_duration = i3;
            }
            create_stop_timer();
            util.create_bcast_handler(this, util.get_uuid(this));
            return true;
        }
    }

    private void stop() {
        synchronized (this.m_running_lock) {
            if (this.m_running) {
                this.m_running = false;
                util.destroy_svc_job_keepalive();
                util.destroy_bcast_handler();
                util.util_uninit();
            }
        }
    }

    /* access modifiers changed from: private */
    public void zerr(int i, String str) {
        StringBuilder a2 = a.a("lumsdk/svc_job/");
        a2.append(this.m_job_id);
        util._zerr(a2.toString(), i, str);
    }

    public static void zerr_s(int i, String str) {
        util._zerr("lumsdk/svc_job:s", i, str);
    }

    public /* synthetic */ void a() {
        zerr(4, "restart after exception");
        stop();
        start();
    }

    public void onCreate() {
        super.onCreate();
        zerr_s(5, "on create svc_job");
        Thread.setDefaultUncaughtExceptionHandler(new util.exception_handler("svc_job", new b1(this)));
    }

    public void onDestroy() {
        zerr(5, "on destroy svc_job");
        super.onDestroy();
        if (this.m_kill_process) {
            zerr(5, "exit");
            Process.killProcess(Process.myPid());
        }
    }

    public boolean onStartJob(JobParameters jobParameters) {
        this.m_job_params = jobParameters;
        int jobId = jobParameters.getJobId();
        this.m_job_id = jobId;
        cancel_pending(this, jobId);
        zerr(5, "on start svc_job");
        util.set_uuid(jobParameters.getExtras().getString("task_id"));
        return start();
    }

    public boolean onStopJob(JobParameters jobParameters) {
        zerr(5, "on stop svc_job");
        try {
            destroy_stop_timer();
            schedule_next_run();
            stop();
        } catch (Exception e2) {
            util.perr(3, "on_stop_job_exception", e2.getMessage(), util.e2s(e2), true);
        } catch (Throwable th) {
            finish();
            throw th;
        }
        finish();
        return false;
    }
}
