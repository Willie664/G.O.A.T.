package io.lum.sdk;

import android.os.Bundle;
import b.a.a.a.a;
import io.lum.sdk.api;
import io.lum.sdk.bcast;
import io.lum.sdk.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class evaluation {
    public static final String ERRID_CONN_PROXYJS = "connpxjs";
    public static final String ERRID_RESTRICTED = "restricted";
    public static final String ERRID_TLS1 = "tls1";
    public static final HashMap<String, Integer> m_errors = new HashMap<>();
    public static Long m_finish_ms;
    public static long m_is_supported_expire = util.m_conf.get_long(conf.IS_SUPPORTED_EXPIRE, 86400000);
    public static long m_is_supported_ts = util.m_conf.get_long(conf.IS_SUPPORTED_TS);
    public static final ArrayList<api.on_ready_listener> m_listeners = new ArrayList<>();
    public static Long m_start_ms;
    public static final util.zerr m_zerr = new util.zerr("eval");

    static {
        m_errors.put(ERRID_CONN_PROXYJS, 300000);
        m_errors.put(ERRID_TLS1, 86400000);
        util.zerr zerr = m_zerr;
        StringBuilder a2 = a.a("creating from ");
        a2.append(util.m_app_name);
        zerr.notice(a2.toString());
        Boolean bool = get_is_supported((Boolean) null);
        if (bool == null) {
            start();
            return;
        }
        util.zerr zerr2 = m_zerr;
        zerr2.notice("supported: " + bool);
    }

    public static String check_supported_errid() {
        if (util.is_restricted((String) null)) {
            return ERRID_RESTRICTED;
        }
        if (util.sdk_version() >= 19 || !util.m_conf.get_bool(conf.DISABLE_TLS1)) {
            return null;
        }
        return ERRID_TLS1;
    }

    public static synchronized void emit_is_supported(long j) {
        synchronized (evaluation.class) {
            m_is_supported_ts = j;
            Iterator<api.on_ready_listener> it = m_listeners.iterator();
            while (it.hasNext()) {
                it.next().on_supported();
            }
            m_listeners.clear();
            finish();
        }
    }

    public static synchronized void emit_is_unsupported(String str) {
        synchronized (evaluation.class) {
            m_is_supported_ts = 0;
            Iterator<api.on_ready_listener> it = m_listeners.iterator();
            while (it.hasNext()) {
                it.next().on_unsupported(str);
            }
            m_listeners.clear();
            finish();
        }
    }

    public static void finish() {
        if (m_finish_ms == null && m_start_ms != null) {
            Long valueOf = Long.valueOf(System.currentTimeMillis());
            m_finish_ms = valueOf;
            long longValue = valueOf.longValue() - m_start_ms.longValue();
            m_zerr.notice(String.format("resolved in %sms", new Object[]{Long.valueOf(longValue)}));
            util.perr(5, "evaluation_finished", "" + longValue, "", true);
        }
    }

    public static Boolean get_is_supported(Boolean bool) {
        if (check_supported_errid() != null) {
            return false;
        }
        if (m_is_supported_ts > 0) {
            long currentTimeMillis = System.currentTimeMillis() - m_is_supported_ts;
            if (currentTimeMillis > 0 && currentTimeMillis < m_is_supported_expire) {
                return true;
            }
            m_is_supported_ts = 0;
        }
        if (load_supported_errid() == null) {
            return false;
        }
        return bool;
    }

    public static String get_supported_errid() {
        String check_supported_errid = check_supported_errid();
        return check_supported_errid != null ? check_supported_errid : load_supported_errid();
    }

    public static String load_supported_errid() {
        String str = util.m_conf.get_str(conf.IS_SUPPORTED_ERRID);
        if (str.isEmpty()) {
            return null;
        }
        if (!m_errors.containsKey(str)) {
            util.zerr zerr = m_zerr;
            zerr.err("unregistered errid: " + str);
            return null;
        }
        long j = util.m_conf.get_long(conf.IS_SUPPORTED_ERRID_TS);
        if (j <= 0) {
            return null;
        }
        Integer num = m_errors.get(str);
        long currentTimeMillis = System.currentTimeMillis() - j;
        if (num != null && currentTimeMillis <= ((long) num.intValue()) && currentTimeMillis >= 0) {
            return str;
        }
        util.m_conf.del(conf.IS_SUPPORTED_ERRID);
        util.m_conf.del(conf.IS_SUPPORTED_ERRID_TS);
        return null;
    }

    public static synchronized void set_is_supported() {
        synchronized (evaluation.class) {
            if (!get_is_supported(false).booleanValue()) {
                long currentTimeMillis = System.currentTimeMillis();
                util.m_conf.set(conf.IS_SUPPORTED_TS, currentTimeMillis);
                emit_is_supported(currentTimeMillis);
                m_zerr.notice("set supported");
                util.perr("supported");
            }
        }
    }

    public static void set_is_unsupported(String str) {
        if (!get_is_supported(false).booleanValue()) {
            util.zerr zerr = m_zerr;
            zerr.notice("set unsupported: " + str);
            if (!m_errors.containsKey(str)) {
                util.zerr zerr2 = m_zerr;
                zerr2.err("unknown errid: " + str);
            }
            util.m_conf.del(conf.IS_SUPPORTED_TS);
            util.m_conf.set(conf.IS_SUPPORTED_ERRID, str);
            util.m_conf.set(conf.IS_SUPPORTED_ERRID_TS, System.currentTimeMillis());
            emit_is_unsupported(str);
            util.perr("unsupported");
        }
    }

    public static synchronized void set_listener(api.on_ready_listener on_ready_listener) {
        synchronized (evaluation.class) {
            if (get_is_supported(false).booleanValue()) {
                on_ready_listener.on_supported();
                return;
            }
            String str = get_supported_errid();
            if (str != null) {
                on_ready_listener.on_unsupported(str);
            } else {
                m_listeners.add(on_ready_listener);
            }
        }
    }

    public static void start() {
        if (m_start_ms == null) {
            m_start_ms = Long.valueOf(System.currentTimeMillis());
            m_zerr.notice("waiting");
            if (util.is_bcast_client()) {
                util.m_bcast_client.add_listener(new bcast.client.listener() {
                    public void on_notify(Bundle bundle) {
                        if (bundle != null && "conf".equals(bundle.getString("name"))) {
                            String string = bundle.getString("key");
                            String string2 = bundle.getString("value");
                            if (string2 != null) {
                                if (conf.IS_SUPPORTED_TS.toString().equals(string)) {
                                    long parseLong = Long.parseLong(string2);
                                    if (parseLong > 0) {
                                        evaluation.emit_is_supported(parseLong);
                                    }
                                } else if (conf.IS_SUPPORTED_ERRID.toString().equals(string) && !string2.isEmpty()) {
                                    evaluation.emit_is_unsupported(string2);
                                }
                            }
                        }
                    }
                });
            }
        }
    }
}
