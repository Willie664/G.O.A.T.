package io.lum.sdk;

import java.math.BigInteger;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public class cidr_utils {
    public final int PREFIX_LENGTH;
    public InetAddress m_end_addr;
    public InetAddress m_inet_addr;
    public InetAddress m_start_addr;

    public cidr_utils(String str) {
        String str2;
        int indexOf = str.indexOf("/");
        if (indexOf >= 0) {
            String substring = str.substring(0, indexOf);
            str2 = str.substring(indexOf + 1);
            str = substring;
        } else {
            str2 = "32";
        }
        this.m_inet_addr = InetAddress.getByName(str);
        this.PREFIX_LENGTH = Integer.parseInt(str2);
        calculate();
    }

    private void calculate() {
        ByteBuffer byteBuffer;
        int i = 16;
        if (this.m_inet_addr.getAddress().length == 4) {
            byteBuffer = ByteBuffer.allocate(4).putInt(-1);
            i = 4;
        } else {
            byteBuffer = ByteBuffer.allocate(16).putLong(-1).putLong(-1);
        }
        BigInteger shiftRight = new BigInteger(1, byteBuffer.array()).not().shiftRight(this.PREFIX_LENGTH);
        BigInteger and = new BigInteger(1, ByteBuffer.wrap(this.m_inet_addr.getAddress()).array()).and(shiftRight);
        BigInteger add = and.add(shiftRight.not());
        byte[] bArr = to_bytes(and.toByteArray(), i);
        byte[] bArr2 = to_bytes(add.toByteArray(), i);
        this.m_start_addr = InetAddress.getByAddress(bArr);
        this.m_end_addr = InetAddress.getByAddress(bArr2);
    }

    private byte[] to_bytes(byte[] bArr, int i) {
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i2 < i && (bArr.length - 1) - i2 >= 0) {
            arrayList.add(0, Byte.valueOf(bArr[(bArr.length - 1) - i2]));
            i2++;
        }
        int size = arrayList.size();
        for (int i3 = 0; i3 < i - size; i3++) {
            arrayList.add(0, (byte) 0);
        }
        byte[] bArr2 = new byte[arrayList.size()];
        for (int i4 = 0; i4 < arrayList.size(); i4++) {
            bArr2[i4] = ((Byte) arrayList.get(i4)).byteValue();
        }
        return bArr2;
    }

    public boolean is_in_range(String str) {
        InetAddress byName = InetAddress.getByName(str);
        BigInteger bigInteger = new BigInteger(1, this.m_start_addr.getAddress());
        BigInteger bigInteger2 = new BigInteger(1, this.m_end_addr.getAddress());
        BigInteger bigInteger3 = new BigInteger(1, byName.getAddress());
        int compareTo = bigInteger.compareTo(bigInteger3);
        int compareTo2 = bigInteger3.compareTo(bigInteger2);
        return (compareTo < 0 || compareTo == 0) && (compareTo2 < 0 || compareTo2 == 0);
    }
}
