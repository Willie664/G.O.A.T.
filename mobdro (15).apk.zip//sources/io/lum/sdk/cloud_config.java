package io.lum.sdk;

import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpGet;
import io.lum.sdk.async.http.AsyncHttpResponse;
import java.util.Timer;
import org.json.JSONObject;

public class cloud_config extends remote_config {
    public static Timer m_timer;
    public int m_retry_delay = 15000;

    public cloud_config() {
        super(conf.CLOUD_CONFIG, conf.CLOUD_CONFIG_LAST_UPDATE, util.MS_HOUR);
        m_timer = new Timer();
    }

    /* access modifiers changed from: private */
    public JSONObject base64_decode(String str) {
        return new JSONObject(util.decrypt(str));
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Can't wrap try/catch for region: R(6:6|7|8|9|10|11) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x000c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void schedule_update(int r5) {
        /*
            r4 = this;
            monitor-enter(r4)
            java.util.Timer r0 = m_timer     // Catch:{ all -> 0x001e }
            if (r0 != 0) goto L_0x0007
            monitor-exit(r4)
            return
        L_0x0007:
            java.util.Timer r0 = m_timer     // Catch:{ Exception -> 0x000c }
            r0.cancel()     // Catch:{ Exception -> 0x000c }
        L_0x000c:
            java.util.Timer r0 = new java.util.Timer     // Catch:{ all -> 0x001e }
            r0.<init>()     // Catch:{ all -> 0x001e }
            m_timer = r0     // Catch:{ all -> 0x001e }
            io.lum.sdk.cloud_config$1 r1 = new io.lum.sdk.cloud_config$1     // Catch:{ all -> 0x001e }
            r1.<init>()     // Catch:{ all -> 0x001e }
            long r2 = (long) r5     // Catch:{ all -> 0x001e }
            r0.schedule(r1, r2)     // Catch:{ all -> 0x001e }
            monitor-exit(r4)
            return
        L_0x001e:
            r5 = move-exception
            monitor-exit(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.cloud_config.schedule_update(int):void");
    }

    public synchronized void destroy() {
        try {
            m_timer.cancel();
        } catch (Exception unused) {
        }
        m_timer = null;
    }

    public void set_json(JSONObject jSONObject) {
        zon_conf.set_zagent_ips(jSONObject.optJSONArray("zagent_sdk_ips"));
        zon_conf.set_zagent_ips_ssl(jSONObject.optJSONArray("zagent_sdk_ips_ssl"));
        zon_conf.set_zagent_domains(jSONObject.optJSONArray("zagent_sdk_domains"));
        zon_conf.set_perr_domains(jSONObject.optJSONArray("perr_domains"));
        zon_conf.set_proxyjs_domains_a1(jSONObject.optJSONArray("proxyjs_domains_a1"));
    }

    public synchronized void update() {
        if (m_timer != null) {
            final String str = zon_conf.CLOUD_CONFIG_URL;
            AsyncHttpGet asyncHttpGet = new AsyncHttpGet(str);
            asyncHttpGet.setHeader("User-Agent", util.get_public_ua());
            AsyncHttpClient.getDefaultInstance().executeString(asyncHttpGet, new AsyncHttpClient.StringCallback() {
                public void onCompleted(Exception exc, AsyncHttpResponse asyncHttpResponse, String str) {
                    if (exc != null) {
                        cloud_config cloud_config = cloud_config.this;
                        int unused = cloud_config.m_retry_delay = cloud_config.m_retry_delay * 2;
                        cloud_config.this.zerr(3, String.format("request to %s failed: %s, retrying in %s", new Object[]{str, util.e2s(exc), Integer.valueOf(cloud_config.this.m_retry_delay)}));
                        cloud_config cloud_config2 = cloud_config.this;
                        cloud_config2.schedule_update(cloud_config2.m_retry_delay);
                        return;
                    }
                    cloud_config cloud_config3 = cloud_config.this;
                    int i = cloud_config3.m_expire;
                    try {
                        JSONObject access$200 = cloud_config3.base64_decode(str);
                        i = access$200.optInt("expire", i);
                        util.m_conf.set(conf.CLOUD_CONFIG, access$200.toString());
                    } catch (Exception e2) {
                        cloud_config.this.zerr(3, String.format("parse failed: %s", new Object[]{util.e2s(e2)}));
                    }
                    cloud_config.this.schedule_update(i);
                }
            });
        }
    }
}
