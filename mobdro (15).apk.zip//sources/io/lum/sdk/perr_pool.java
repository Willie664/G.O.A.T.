package io.lum.sdk;

import io.lum.sdk.util;

public class perr_pool {
    public static final String m_fallback_host = "perr.lum-sdk.io";
    public static volatile perr_pool m_instance;
    public final String HOST = "perr_host";
    public option_pool m_options;
    public util.zerr m_zerr;

    public perr_pool() {
        String simpleName = perr_pool.class.getSimpleName();
        this.m_zerr = new util.zerr(simpleName);
        this.m_options = new option_pool(simpleName).add(option_pool.strings("perr_host", zon_conf.PERR_DOMAINS, conf.CACHE_PERR_HOST, conf.CACHE_PERR_HOST_TS, conf.CACHE_PERR_HOST_TTL, 0, true));
    }

    private synchronized String get_details() {
        return get_host();
    }

    public static perr_pool get_instance() {
        if (m_instance == null) {
            m_instance = new perr_pool();
        }
        return m_instance;
    }

    public synchronized boolean failure() {
        util.zerr zerr = this.m_zerr;
        zerr.notice("failure: " + get_details());
        return this.m_options.next();
    }

    public synchronized String get_host() {
        String str;
        str = (String) this.m_options.get("perr_host");
        if (str == null) {
            this.m_zerr.err("host null, falling back to perr.lum-sdk.io");
            str = m_fallback_host;
        }
        return str;
    }

    public synchronized void reset() {
        this.m_options.reset();
    }

    public synchronized void success() {
        if (this.m_options.save()) {
            util.zerr zerr = this.m_zerr;
            zerr.notice("success: " + get_details());
            util.perr(5, "perr_success", (Object) get_details(), true);
            util.perr(5, String.format("perr_success_%s", new Object[]{get_host().replace("-", "_").replace(".", "__")}), true);
        }
    }
}
