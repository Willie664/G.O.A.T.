package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import b.a.a.a.a;
import io.lum.sdk.util;
import java.net.InetAddress;
import java.util.HashMap;

public class dev {
    @SuppressLint({"StaticFieldLeak"})
    public static dev_monitor m_monitor;
    public boolean m_is_roaming = false;
    public boolean m_is_up = false;
    public final HashMap<InetAddress, dev_conn> m_local_ips = new HashMap<>();
    public String m_name;
    public NetworkInfo m_pending_net_info;
    public String m_type;
    public util.zerr m_zerr = new util.zerr("dev");

    public dev(String str, String str2, NetworkInfo networkInfo) {
        this.m_name = str;
        this.m_type = str2;
        this.m_pending_net_info = networkInfo;
    }

    @SuppressLint({"NewApi"})
    public static dev create(Network network, Context context) {
        NetworkCapabilities networkCapabilities;
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        LinkProperties linkProperties = connectivityManager.getLinkProperties(network);
        if (linkProperties == null || (networkCapabilities = connectivityManager.getNetworkCapabilities(network)) == null) {
            return null;
        }
        return create(linkProperties.getInterfaceName(), dev_util.get_type(networkCapabilities, context), connectivityManager.getNetworkInfo(network));
    }

    public static dev create(String str, NetworkInfo networkInfo, Context context) {
        return create(str, dev_util.get_type(networkInfo, context), networkInfo);
    }

    public static dev create(String str, String str2, NetworkInfo networkInfo) {
        if (dev_util.TYPE_VPN.equals(str2)) {
            util.perr(3, "using_vpn", str, networkInfo.toString(), true);
            return null;
        } else if (str == null || str2 == null) {
            return null;
        } else {
            return new dev(str, str2, networkInfo);
        }
    }

    public static dev_monitor get_monitor() {
        return m_monitor;
    }

    public static void set_monitor(dev_monitor dev_monitor) {
        m_monitor = dev_monitor;
    }

    public void down() {
        util.zerr zerr = this.m_zerr;
        StringBuilder a2 = a.a("down: ");
        a2.append(toString());
        zerr.notice(a2.toString());
        this.m_is_up = false;
        for (dev_conn down : this.m_local_ips.values()) {
            down.down();
        }
        util.zerr zerr2 = this.m_zerr;
        StringBuilder a3 = a.a("down ok: ");
        a3.append(toString());
        zerr2.notice(a3.toString());
    }

    public boolean is_mobile() {
        return dev_util.TYPE_MOBILE.equals(this.m_type);
    }

    public boolean is_roaming() {
        return this.m_is_roaming;
    }

    public boolean is_up() {
        return this.m_is_up;
    }

    public boolean is_wifi() {
        return dev_util.TYPE_WIFI.equals(this.m_type);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0016, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void on_ip_conn_fail(java.net.InetAddress r2) {
        /*
            r1 = this;
            monitor-enter(r1)
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r0 = r1.m_local_ips     // Catch:{ all -> 0x0017 }
            java.lang.Object r2 = r0.get(r2)     // Catch:{ all -> 0x0017 }
            io.lum.sdk.dev_conn r2 = (io.lum.sdk.dev_conn) r2     // Catch:{ all -> 0x0017 }
            boolean r0 = r1.m_is_up     // Catch:{ all -> 0x0017 }
            if (r0 == 0) goto L_0x0015
            if (r2 != 0) goto L_0x0010
            goto L_0x0015
        L_0x0010:
            r2.retry()     // Catch:{ all -> 0x0017 }
            monitor-exit(r1)
            return
        L_0x0015:
            monitor-exit(r1)
            return
        L_0x0017:
            r2 = move-exception
            monitor-exit(r1)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev.on_ip_conn_fail(java.net.InetAddress):void");
    }

    public void pick_net_info(dev dev) {
        this.m_pending_net_info = dev.m_pending_net_info;
    }

    public String toString() {
        String format;
        synchronized (this.m_local_ips) {
            format = String.format("name: %s; type: %s; local_ips: %s; up: %s", new Object[]{this.m_name, this.m_type, this.m_local_ips, Boolean.valueOf(this.m_is_up)});
        }
        return format;
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:77:0x011d */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0086  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00aa A[DONT_GENERATE] */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ac A[DONT_GENERATE, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0123  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void update(android.content.Context r11) {
        /*
            r10 = this;
            monitor-enter(r10)
            java.util.HashSet r0 = new java.util.HashSet     // Catch:{ all -> 0x0172 }
            r0.<init>()     // Catch:{ all -> 0x0172 }
            boolean r1 = r10.m_is_up     // Catch:{ all -> 0x0172 }
            r2 = 0
            r10.m_is_up = r2     // Catch:{ all -> 0x0172 }
            boolean r3 = r10.m_is_roaming     // Catch:{ all -> 0x0172 }
            r10.m_is_roaming = r2     // Catch:{ all -> 0x0172 }
            r4 = 1
            r5 = 3
            r6 = 0
            java.lang.String r7 = r10.m_name     // Catch:{ Exception -> 0x006b }
            java.net.NetworkInterface r7 = java.net.NetworkInterface.getByName(r7)     // Catch:{ Exception -> 0x006b }
            android.net.NetworkInfo r8 = r10.m_pending_net_info     // Catch:{ Exception -> 0x0069 }
            if (r8 == 0) goto L_0x0025
            android.net.NetworkInfo r8 = r10.m_pending_net_info     // Catch:{ Exception -> 0x0069 }
            boolean r8 = r8.isConnected()     // Catch:{ Exception -> 0x0069 }
        L_0x0022:
            r10.m_is_up = r8     // Catch:{ Exception -> 0x0069 }
            goto L_0x002a
        L_0x0025:
            boolean r8 = r7.isUp()     // Catch:{ Exception -> 0x0069 }
            goto L_0x0022
        L_0x002a:
            boolean r8 = r10.m_is_up     // Catch:{ Exception -> 0x0069 }
            if (r8 == 0) goto L_0x0094
            java.util.HashSet r0 = io.lum.sdk.dev_util.get_ips(r7)     // Catch:{ Exception -> 0x0069 }
            if (r1 != 0) goto L_0x004e
            boolean r8 = r0.isEmpty()     // Catch:{ Exception -> 0x0069 }
            if (r8 == 0) goto L_0x004e
            io.lum.sdk.dev_monitor r8 = get_monitor()     // Catch:{ Exception -> 0x0069 }
            boolean r8 = r8.has_single_active_interface()     // Catch:{ Exception -> 0x0069 }
            if (r8 == 0) goto L_0x004e
            io.lum.sdk.util$zerr r8 = r10.m_zerr     // Catch:{ Exception -> 0x0069 }
            java.lang.String r9 = "no ips, using single device fallback"
            r8.notice(r9)     // Catch:{ Exception -> 0x0069 }
            r0.add(r6)     // Catch:{ Exception -> 0x0069 }
        L_0x004e:
            boolean r8 = r0.isEmpty()     // Catch:{ Exception -> 0x0069 }
            if (r8 == 0) goto L_0x0057
            r10.m_is_up = r2     // Catch:{ Exception -> 0x0069 }
            goto L_0x0094
        L_0x0057:
            android.net.NetworkInfo r2 = r10.m_pending_net_info     // Catch:{ Exception -> 0x0069 }
            java.lang.String r8 = r10.m_type     // Catch:{ Exception -> 0x0069 }
            boolean r2 = io.lum.sdk.util.is_roaming(r11, r2, r8)     // Catch:{ Exception -> 0x0069 }
            r10.m_is_roaming = r2     // Catch:{ Exception -> 0x0069 }
            if (r2 == 0) goto L_0x0094
            java.lang.String r2 = "is_roaming"
            io.lum.sdk.util.perr((int) r5, (java.lang.String) r2, (boolean) r4)     // Catch:{ Exception -> 0x0069 }
            goto L_0x0094
        L_0x0069:
            r0 = move-exception
            goto L_0x006d
        L_0x006b:
            r0 = move-exception
            r7 = r6
        L_0x006d:
            java.util.HashSet r2 = new java.util.HashSet     // Catch:{ all -> 0x0172 }
            r2.<init>()     // Catch:{ all -> 0x0172 }
            if (r7 != 0) goto L_0x0086
            java.lang.String r7 = "lost_ifdev"
            java.lang.String r7 = io.lum.sdk.dev_util.perr_id(r7)     // Catch:{ all -> 0x0172 }
            java.lang.String r8 = r10.toString()     // Catch:{ all -> 0x0172 }
            java.lang.String r0 = io.lum.sdk.util.e2s(r0)     // Catch:{ all -> 0x0172 }
            io.lum.sdk.util.perr((int) r5, (java.lang.String) r7, (java.lang.String) r8, (java.lang.String) r0, (boolean) r4)     // Catch:{ all -> 0x0172 }
            goto L_0x0093
        L_0x0086:
            java.lang.String r4 = "update_err"
            java.lang.String r4 = io.lum.sdk.dev_util.perr_id(r4)     // Catch:{ all -> 0x0172 }
            java.lang.String r5 = r10.toString()     // Catch:{ all -> 0x0172 }
            io.lum.sdk.util.perr((java.lang.String) r4, (java.lang.Throwable) r0, (java.lang.String) r5)     // Catch:{ all -> 0x0172 }
        L_0x0093:
            r0 = r2
        L_0x0094:
            r10.m_pending_net_info = r6     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r2 = r10.m_local_ips     // Catch:{ all -> 0x0172 }
            java.util.Set r2 = r2.keySet()     // Catch:{ all -> 0x0172 }
            boolean r2 = r2.equals(r0)     // Catch:{ all -> 0x0172 }
            if (r2 == 0) goto L_0x00ac
            boolean r2 = r10.m_is_up     // Catch:{ all -> 0x0172 }
            if (r1 != r2) goto L_0x00ac
            boolean r2 = r10.m_is_roaming     // Catch:{ all -> 0x0172 }
            if (r3 != r2) goto L_0x00ac
            monitor-exit(r10)
            return
        L_0x00ac:
            io.lum.sdk.util$zerr r2 = r10.m_zerr     // Catch:{ all -> 0x0172 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0172 }
            r4.<init>()     // Catch:{ all -> 0x0172 }
            java.lang.String r5 = "update: "
            r4.append(r5)     // Catch:{ all -> 0x0172 }
            java.lang.String r5 = r10.toString()     // Catch:{ all -> 0x0172 }
            r4.append(r5)     // Catch:{ all -> 0x0172 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0172 }
            r2.notice(r4)     // Catch:{ all -> 0x0172 }
            java.util.Iterator r2 = r0.iterator()     // Catch:{ all -> 0x0172 }
        L_0x00ca:
            boolean r4 = r2.hasNext()     // Catch:{ all -> 0x0172 }
            if (r4 == 0) goto L_0x010f
            java.lang.Object r4 = r2.next()     // Catch:{ all -> 0x0172 }
            java.net.InetAddress r4 = (java.net.InetAddress) r4     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r5 = r10.m_local_ips     // Catch:{ all -> 0x0172 }
            java.lang.Object r5 = r5.get(r4)     // Catch:{ all -> 0x0172 }
            io.lum.sdk.dev_conn r5 = (io.lum.sdk.dev_conn) r5     // Catch:{ all -> 0x0172 }
            if (r5 != 0) goto L_0x00f9
            io.lum.sdk.dev_conn r5 = new io.lum.sdk.dev_conn     // Catch:{ all -> 0x0172 }
            r5.<init>(r11, r4, r10)     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r7 = r10.m_local_ips     // Catch:{ all -> 0x0172 }
            monitor-enter(r7)     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r8 = r10.m_local_ips     // Catch:{ all -> 0x00f6 }
            r8.put(r4, r5)     // Catch:{ all -> 0x00f6 }
            monitor-exit(r7)     // Catch:{ all -> 0x00f6 }
            boolean r4 = r10.m_is_up     // Catch:{ all -> 0x0172 }
            if (r4 == 0) goto L_0x00ca
        L_0x00f2:
            r5.up()     // Catch:{ all -> 0x0172 }
            goto L_0x00ca
        L_0x00f6:
            r11 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x00f6 }
            throw r11     // Catch:{ all -> 0x0172 }
        L_0x00f9:
            boolean r4 = r10.m_is_up     // Catch:{ all -> 0x0172 }
            if (r1 == r4) goto L_0x0105
            r5.down()     // Catch:{ all -> 0x0172 }
            boolean r4 = r10.m_is_up     // Catch:{ all -> 0x0172 }
            if (r4 == 0) goto L_0x00ca
            goto L_0x00f2
        L_0x0105:
            boolean r4 = r10.m_is_roaming     // Catch:{ all -> 0x0172 }
            if (r3 == r4) goto L_0x00ca
            java.lang.String r4 = "roaming"
            r5.status_report(r4)     // Catch:{ all -> 0x0172 }
            goto L_0x00ca
        L_0x010f:
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r11 = r10.m_local_ips     // Catch:{ all -> 0x0172 }
            monitor-enter(r11)     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r1 = r10.m_local_ips     // Catch:{ all -> 0x016f }
            java.util.Set r1 = r1.keySet()     // Catch:{ all -> 0x016f }
            java.util.Iterator r1 = r1.iterator()     // Catch:{ all -> 0x016f }
            monitor-exit(r11)     // Catch:{ all -> 0x016f }
        L_0x011d:
            boolean r11 = r1.hasNext()     // Catch:{ all -> 0x0172 }
            if (r11 == 0) goto L_0x0153
            java.lang.Object r11 = r1.next()     // Catch:{ all -> 0x0172 }
            java.net.InetAddress r11 = (java.net.InetAddress) r11     // Catch:{ all -> 0x0172 }
            boolean r2 = r0.contains(r11)     // Catch:{ all -> 0x0172 }
            if (r2 == 0) goto L_0x0130
            goto L_0x011d
        L_0x0130:
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r2 = r10.m_local_ips     // Catch:{ all -> 0x0172 }
            monitor-enter(r2)     // Catch:{ all -> 0x0172 }
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r3 = r10.m_local_ips     // Catch:{ all -> 0x0150 }
            boolean r3 = r3.containsKey(r11)     // Catch:{ all -> 0x0150 }
            if (r3 == 0) goto L_0x0147
            java.util.HashMap<java.net.InetAddress, io.lum.sdk.dev_conn> r3 = r10.m_local_ips     // Catch:{ all -> 0x0150 }
            java.lang.Object r11 = r3.get(r11)     // Catch:{ all -> 0x0150 }
            io.lum.sdk.dev_conn r11 = (io.lum.sdk.dev_conn) r11     // Catch:{ all -> 0x0150 }
            r1.remove()     // Catch:{ all -> 0x0150 }
            goto L_0x0148
        L_0x0147:
            r11 = r6
        L_0x0148:
            monitor-exit(r2)     // Catch:{ all -> 0x0150 }
            if (r11 != 0) goto L_0x014c
            goto L_0x011d
        L_0x014c:
            r11.destroy()     // Catch:{ Exception -> 0x011d }
            goto L_0x011d
        L_0x0150:
            r11 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x0150 }
            throw r11     // Catch:{ all -> 0x0172 }
        L_0x0153:
            io.lum.sdk.util$zerr r11 = r10.m_zerr     // Catch:{ all -> 0x0172 }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x0172 }
            r0.<init>()     // Catch:{ all -> 0x0172 }
            java.lang.String r1 = "update ok: "
            r0.append(r1)     // Catch:{ all -> 0x0172 }
            java.lang.String r1 = r10.toString()     // Catch:{ all -> 0x0172 }
            r0.append(r1)     // Catch:{ all -> 0x0172 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0172 }
            r11.notice(r0)     // Catch:{ all -> 0x0172 }
            monitor-exit(r10)
            return
        L_0x016f:
            r0 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x016f }
            throw r0     // Catch:{ all -> 0x0172 }
        L_0x0172:
            r11 = move-exception
            monitor-exit(r10)
            goto L_0x0176
        L_0x0175:
            throw r11
        L_0x0176:
            goto L_0x0175
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev.update(android.content.Context):void");
    }
}
