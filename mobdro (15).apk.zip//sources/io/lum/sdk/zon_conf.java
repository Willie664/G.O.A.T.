package io.lum.sdk;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class zon_conf {
    public static JSONObject APPS;
    public static final ArrayList<String> BLACKLISTED_COUNTRIES = new ArrayList<>();
    public static JSONArray BLOCKED_IPS;
    public static String CCGI_SSL_HOST;
    public static String CLOUD_CONFIG_URL;
    public static JSONObject CONF;
    public static final ArrayList<String> PERR_DOMAINS = new ArrayList<>();
    public static String PERR_SSL_HOST;
    public static final ArrayList<String> PROXY_DOMAINS = new ArrayList<>();
    public static final ArrayList<String> PROXY_DOMAINS_A1 = new ArrayList<>();
    public static final ArrayList<String> PROXY_IPS = new ArrayList<>();
    public static final ArrayList<String> PROXY_IPS_A1 = new ArrayList<>();
    public static final ArrayList<Integer> PROXY_PORTS = new ArrayList<>();
    public static String SPROXY_SSL_HOST;
    public static final ArrayList<JSONObject> TEST_SITES = new ArrayList<>();
    public static final ArrayList<String> ZAGENT_DOMAINS = new ArrayList<>();
    public static final ArrayList<String> ZAGENT_IPS = new ArrayList<>();
    public static final ArrayList<String> ZAGENT_IPS_SSL = new ArrayList<>();
    public static final ArrayList<Integer> ZAGENT_PORTS = new ArrayList<>();
    public static final ArrayList<Integer> ZAGENT_PORTS_SSL = new ArrayList<>();

    static {
        try {
            JSONObject jSONObject = new JSONObject("{\"ZON_VERSION\":\"1.177.86\",\"CONFIG_MAKEFLAGS\":\"DIST=APP ARCH=ANDROID RELEASE=y AUTO_SIGN=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_LUM_SDK_COMPILE=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_BATREQ_FROM=lum_android_sdk CONFIG_BATREQ=y CONFIG_BAT_CYCLE=y CONFIG_BAT_PLATFORM=app_androidr\",\"DEFAULT_UA\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0\",\"CLOUD_CONFIG_URL\":\"https://www.dropbox.com/s/g0kg7ejs3zix8nm/cloud_config.dat?dl=1\",\"CLOUD_CONFIG_URL2\":\"https://www.dropbox.com/s/p29mwetn9epwewq/cloud_config2.dat?dl=1\",\"CCGI_SSL_HOST\":\"client.luminati.io\",\"PERR_SSL_HOST\":\"client.luminati.io\",\"SPROXY_SSL_HOST\":\"client.luminatinet.com\",\"SC_RESTORE_REMOVED\":true,\"APPS\":{\"aos.com.aostv\":{\"restricted_countries\":[\"IN\",\"ID\",\"MX\",\"SA\",\"MA\",\"BD\",\"TR\",\"PK\"]},\"com.android.mediasetup\":{\"allowed_countries\":[\"US\",\"CA\",\"GB\"]},\"com.desoline.android.pdfreader\":{\"get_state\":true},\"com.desoline.android.pdfreader.lite\":{\"get_state\":true},\"com.desoline.pdfscanner\":{\"get_state\":true},\"com.freedombox.launcher\":{\"allowed_countries\":[\"US\",\"CA\",\"GB\"],\"testing\":true},\"com.lnt.androidnettv\":{\"set_no_vendor\":true},\"com.nnfw.launcher\":{\"allowed_countries\":[\"US\",\"CA\",\"GB\"]},\"com.peel.app\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true},\"com.peel.remote\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true},\"com.universaltv.launcher\":{\"allowed_countries\":[\"US\",\"CA\",\"GB\"]},\"com.utv.launcher\":{\"allowed_countries\":[\"US\",\"CA\",\"GB\"]},\"io.lum.app\":{\"set_user_selection\":true},\"io.lum.sdk_test\":{\"set_user_selection\":true,\"set_no_vendor\":true,\"get_state\":true,\"testing\":true},\"io.luminati.sdk.app\":{\"set_user_selection\":true},\"io.luminati.va\":{\"set_user_selection\":true},\"io.lumsdk.example\":{\"set_user_selection\":true,\"testing\":true},\"org.hola\":{\"set_user_selection\":true},\"org.hola.gpslocation\":{\"set_user_selection\":true},\"org.hola.gpslocatioo\":{\"set_user_selection\":true},\"org.hola.test_vpn_api\":{\"set_user_selection\":true},\"org.hola.va\":{\"set_user_selection\":true},\"tv.peel.app\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true},\"tv.peel.oem.app\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true,\"testing\":true},\"tv.peel.remote\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true},\"tv.peel.samsung.app\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true},\"tv.peel.smartremote\":{\"restricted_countries\":[\"PT\",\"BD\",\"SA\",\"CO\",\"NG\",\"DO\",\"IQ\",\"IT\",\"IN\",\"TR\",\"PK\",\"DZ\",\"IR\",\"EG\",\"MA\"],\"set_user_selection\":true}},\"compat_ver\":\"1.4.480\",\"svc_fallback_embed\":false,\"svc_fallback_legacy\":true,\"svc_fallback_for\":3600000,\"svc_keepalive\":true,\"svc_keepalive_period\":3600000,\"svc_job_keepalive_period\":3600000,\"svc_job_next_run_delay\":30000,\"svc_job_max_duration\":3570000,\"take_popup_screenshot\":false,\"push_status_report\":false,\"funnel_check\":false,\"perr_ssl_host\":\"client.luminati.io\",\"ccgi_ssl_host\":\"client.luminati.io\",\"sproxy_ssl_host\":\"client.luminatinet.com\",\"perr_min_ver\":\"1.151.631\",\"perr\":{\"*\":{\"max_freq\":300000},\"init\":{\"max_freq\":3600000},\"ajax_host_changed\":{\"max_freq\":3600000},\"apk_config_init\":{\"disabled\":true},\"apk_config_update\":{\"disabled\":true},\"call_listeners_not_on_call\":{\"disabled\":true},\"call_listeners_on_call\":{\"disabled\":true},\"cid_java\":{\"max_freq\":1800000},\"create_device\":{\"disabled\":true},\"register_client\":{\"disabled\":true},\"dev_conn_ip_ip_ignore_client\":{\"disabled\":true},\"dev_conn_ip_ip_none_client\":{\"disabled\":true},\"dev_conn_ip_ip_ignore_peer\":{\"disabled\":true},\"dev_conn_ip_ip_none_peer\":{\"disabled\":true},\"secure_conf_choice_mismatch\":{\"disabled\":true}},\"zagent_sdk_ports\":[22222],\"zagent_sdk_ports_ssl\":[80],\"sdk_disabled_for\":86400000,\"perr_send_pending_install\":false,\"perr_send_pending_update\":false,\"sc_restore_removed\":true}");
            CONF = jSONObject;
            APPS = jSONObject.optJSONObject("APPS");
            CCGI_SSL_HOST = CONF.optString("CCGI_SSL_HOST", "client.luminati.io");
            PERR_SSL_HOST = CONF.optString("PERR_SSL_HOST", "client.luminati.io");
            SPROXY_SSL_HOST = CONF.optString("SPROXY_SSL_HOST", "client.luminatinet.com");
            CLOUD_CONFIG_URL = CONF.optString("CLOUD_CONFIG_URL2", "https://www.dropbox.com/s/p29mwetn9epwewq/cloud_config2.dat?dl=1");
            CONF.optString("DEFAULT_UA", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0");
            BLOCKED_IPS = new JSONArray("[\"127.0.0.0/8\",\"255.255.255.255\",\"10.0.0.0/8\",\"172.16.0.0/12\",\"169.254.0.0/16\",\"192.168.0.0/16\"]");
            JSONArray jSONArray = new JSONArray("[\"54.243.132.124\",\"54.197.238.153\",\"23.23.115.110\",\"23.23.176.28\",\"34.237.189.140\",\"34.230.120.115\",\"54.227.144.19\",\"34.228.163.174\",\"35.169.231.185\",\"35.169.76.132\",\"35.170.3.121\",\"34.231.146.224\",\"35.153.6.150\",\"34.195.75.60\",\"34.237.55.225\",\"35.169.205.0\",\"35.171.66.198\",\"34.237.108.91\",\"35.171.46.63\",\"34.199.117.182\",\"18.208.90.129\",\"18.213.148.154\",\"54.211.212.224\",\"107.22.60.33\",\"18.213.109.20\",\"54.87.86.109\",\"54.146.137.220\",\"184.72.145.94\",\"54.144.197.214\",\"34.192.186.85\"]");
            for (int i = 0; i < jSONArray.length(); i++) {
                String optString = jSONArray.optString(i);
                if (!optString.isEmpty()) {
                    PROXY_IPS.add(optString);
                }
            }
            JSONArray jSONArray2 = new JSONArray("[\"34.230.141.83\",\"23.21.200.81\",\"107.20.155.97\",\"3.225.162.142\",\"3.84.65.241\",\"3.93.139.27\",\"3.93.244.66\",\"34.197.217.233\",\"34.199.53.229\",\"34.200.121.251\",\"34.205.222.157\",\"34.206.156.144\",\"34.207.38.111\",\"34.235.241.233\",\"35.168.34.151\",\"35.169.211.74\",\"35.174.103.49\",\"50.16.231.79\",\"50.17.201.48\",\"50.17.242.205\",\"52.0.103.206\",\"52.2.49.133\",\"52.201.188.167\",\"52.3.30.241\",\"52.55.234.187\",\"52.70.76.94\",\"52.72.235.189\",\"52.87.103.94\",\"52.87.130.182\",\"54.156.208.194\"]");
            for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                String optString2 = jSONArray2.optString(i2);
                if (!optString2.isEmpty()) {
                    PROXY_IPS_A1.add(optString2);
                }
            }
            set_perr_domains(new JSONArray("[\"perr.lum-sdk.io\",\"perr.l-err.biz\",\"perr.l-agent.me\"]"));
            set_zagent_ips(new JSONArray("[\"67.207.94.236\",\"104.248.15.221\",\"178.62.184.59\",\"165.22.10.233\",\"159.89.120.168\",\"165.227.41.187\",\"165.22.147.140\",\"138.68.211.252\",\"167.71.198.52\",\"178.128.208.177\",\"37.139.10.34\",\"192.241.187.94\",\"159.89.194.20\",\"159.89.48.245\",\"165.22.166.60\",\"178.128.116.244\",\"97.107.131.37\",\"104.131.215.200\",\"159.89.91.191\",\"178.62.188.103\",\"157.245.72.157\",\"178.128.106.77\",\"167.99.176.64\",\"45.56.93.90\",\"157.230.34.156\",\"104.131.215.124\",\"157.230.246.70\",\"167.71.131.139\",\"209.97.171.98\",\"104.131.221.208\",\"165.22.175.52\",\"37.139.6.69\",\"106.2.11.243\",\"104.131.223.58\",\"37.139.10.53\",\"178.128.120.151\",\"134.209.96.154\",\"178.128.78.148\",\"167.71.186.50\",\"159.89.120.208\",\"134.209.58.162\",\"37.139.6.76\",\"134.209.73.255\",\"159.89.122.50\",\"159.65.221.37\",\"165.22.145.39\",\"159.89.112.137\",\"134.209.217.34\",\"167.99.255.100\",\"167.71.4.204\",\"178.62.182.249\",\"159.89.120.71\",\"104.248.195.118\",\"167.71.246.211\",\"165.22.233.2\",\"167.71.91.151\",\"165.22.175.55\",\"134.209.96.159\",\"134.209.79.189\",\"134.209.172.148\",\"37.139.3.158\",\"104.248.12.18\",\"134.209.244.34\",\"68.183.234.4\",\"167.71.5.110\",\"165.227.37.234\",\"167.71.128.172\",\"167.71.142.126\",\"206.189.21.181\",\"165.22.164.142\",\"134.209.74.142\",\"138.68.219.228\",\"104.248.155.108\",\"165.22.160.251\",\"67.207.94.241\",\"167.99.71.249\",\"167.99.205.203\",\"165.22.63.155\",\"159.89.127.251\",\"178.128.50.64\",\"165.22.44.49\",\"104.131.220.163\",\"167.71.77.12\",\"157.245.206.50\",\"104.131.221.181\",\"104.131.216.135\",\"165.22.243.227\",\"167.99.197.231\",\"104.248.150.234\",\"104.131.221.189\",\"157.230.119.238\",\"82.196.3.42\",\"45.55.63.183\",\"104.131.223.87\",\"157.230.208.240\",\"157.230.154.155\",\"178.62.190.182\",\"165.227.82.127\",\"106.2.3.105\",\"159.89.92.165\"]"));
            set_zagent_ports(new JSONArray("[22222]"));
            set_zagent_ips_ssl(new JSONArray("[\"159.203.166.29\",\"178.62.187.189\",\"178.128.222.200\",\"165.227.117.65\",\"149.28.170.61\",\"68.183.205.80\",\"134.209.0.246\",\"134.209.167.99\",\"165.22.179.80\",\"206.189.101.108\",\"157.230.213.252\",\"178.128.18.235\",\"104.248.219.159\",\"37.139.10.36\",\"134.209.29.66\",\"178.128.127.243\",\"104.131.215.164\",\"142.93.176.233\",\"68.183.69.172\",\"167.99.199.147\",\"165.22.44.49\",\"206.189.150.207\",\"165.227.215.81\",\"159.65.41.31\",\"162.243.10.56\",\"142.93.176.15\",\"206.81.30.55\",\"67.207.84.216\",\"159.89.80.154\",\"104.131.217.59\",\"167.99.160.30\",\"159.89.90.81\",\"138.197.186.233\",\"165.22.34.137\",\"104.131.216.56\",\"178.128.208.177\",\"104.248.53.74\",\"162.243.10.206\",\"104.248.74.45\",\"165.22.0.245\",\"165.22.118.249\",\"159.89.111.11\",\"165.22.180.158\",\"134.209.34.104\",\"162.243.137.175\",\"157.230.211.2\",\"104.131.215.122\",\"67.207.88.168\",\"192.241.182.77\",\"167.71.171.178\",\"159.89.88.122\",\"134.209.36.4\",\"172.105.61.61\",\"159.65.68.246\",\"67.207.84.227\",\"159.203.118.215\",\"68.183.63.10\",\"165.227.45.39\",\"67.207.88.106\",\"167.71.173.103\",\"167.71.67.67\",\"167.99.142.112\",\"82.196.6.28\",\"165.22.162.255\",\"165.22.182.132\",\"37.139.10.19\",\"104.131.222.72\",\"104.131.216.62\",\"134.209.51.35\",\"165.22.47.242\",\"167.71.77.20\",\"165.227.41.203\",\"157.230.219.223\",\"165.227.199.204\",\"178.62.181.8\",\"104.248.53.45\",\"159.65.123.223\",\"159.89.90.41\",\"104.248.199.7\",\"134.209.123.249\",\"159.203.175.147\",\"104.248.65.116\",\"165.227.37.213\",\"134.209.241.92\",\"167.71.65.17\",\"167.99.140.210\",\"165.227.90.138\",\"165.22.50.37\",\"104.248.48.199\",\"157.230.215.51\",\"104.248.43.84\",\"165.227.209.178\",\"67.207.88.247\",\"165.227.58.75\",\"178.128.116.203\",\"165.22.79.171\",\"192.241.174.104\",\"165.227.46.10\",\"206.189.76.214\",\"157.245.206.57\"]"));
            set_zagent_ports_ssl(new JSONArray("[80]"));
            set_zagent_domains(new JSONArray("[\"l-cdn.com\"]"));
            JSONArray jSONArray3 = new JSONArray("[{\"ip\":\"23.23.185.50\",\"url\":\"http://lumtest.com/myip.json\",\"myip\":true,\"match\":\"\\\\{\\\"ip\\\":\\\"[\\\\d.]+\\\",\\\"country\\\":\\\"[A-Z]+\\\",\\\"asn\\\":\\\\{.+\\\\},\\\"geo\\\":\\\\{.+\\\\}\\\\}\"},{\"ip\":\"54.225.188.98\",\"match\":\"http-test1\",\"url\":\"http://http-test1.luminatinet.com/connection/http-test1.html\"},{\"ip\":\"128.30.52.100\",\"match\":\"region\",\"url\":\"http://www.w3.org/2008/site/js/lang/strings.js\"},{\"ip\":\"92.123.203.91\",\"match\":\"GIF\",\"url\":\"http://i.s-microsoft.com/library/svy/close.gif\"}]");
            for (int i3 = 0; i3 < jSONArray3.length(); i3++) {
                JSONObject optJSONObject = jSONArray3.optJSONObject(i3);
                if (optJSONObject != null) {
                    TEST_SITES.add(optJSONObject);
                }
            }
            set_proxyjs_domains(new JSONArray("[\"proxyjs.luminatinet.com\",\"proxyjs.lum-sdk.io\"]"));
            set_proxyjs_domains_a1(new JSONArray("[\"p.l-conn.net\",\"proxyjs.lum-sdk.io\"]"));
            jsonarray_to_arraylist_i(new JSONArray("[443,7010]"), PROXY_PORTS);
            jsonarray_to_arraylist_s(new JSONArray("[\"IQ\",\"IR\",\"LB\",\"SY\"]"), BLACKLISTED_COUNTRIES);
        } catch (Throwable unused) {
        }
    }

    public static JSONObject get_sdk_app_conf(String str) {
        JSONObject optJSONObject = APPS.optJSONObject(str);
        return optJSONObject != null ? optJSONObject : new JSONObject();
    }

    public static void jsonarray_to_arraylist_i(JSONArray jSONArray, ArrayList<Integer> arrayList) {
        if (jSONArray != null) {
            arrayList.clear();
            for (int i = 0; i < jSONArray.length(); i++) {
                int optInt = jSONArray.optInt(i);
                if (optInt > 0) {
                    arrayList.add(Integer.valueOf(optInt));
                }
            }
        }
    }

    public static void jsonarray_to_arraylist_s(JSONArray jSONArray, ArrayList<String> arrayList) {
        if (jSONArray != null) {
            arrayList.clear();
            for (int i = 0; i < jSONArray.length(); i++) {
                String optString = jSONArray.optString(i);
                if (!optString.isEmpty()) {
                    arrayList.add(optString);
                }
            }
        }
    }

    public static void set_perr_domains(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, PERR_DOMAINS);
    }

    public static void set_proxyjs_domains(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, PROXY_DOMAINS);
    }

    public static void set_proxyjs_domains_a1(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, PROXY_DOMAINS_A1);
    }

    public static void set_zagent_domains(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, ZAGENT_DOMAINS);
    }

    public static void set_zagent_ips(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, ZAGENT_IPS);
    }

    public static void set_zagent_ips_ssl(JSONArray jSONArray) {
        jsonarray_to_arraylist_s(jSONArray, ZAGENT_IPS_SSL);
    }

    public static void set_zagent_ports(JSONArray jSONArray) {
        jsonarray_to_arraylist_i(jSONArray, ZAGENT_PORTS);
    }

    public static void set_zagent_ports_ssl(JSONArray jSONArray) {
        jsonarray_to_arraylist_i(jSONArray, ZAGENT_PORTS_SSL);
    }
}
