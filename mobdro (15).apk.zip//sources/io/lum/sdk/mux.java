package io.lum.sdk;

import android.annotation.SuppressLint;
import d.a.a.i0;
import d.a.a.j0;
import d.a.a.k0;
import d.a.a.l0;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.util;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class mux {
    public static final int MUX_ID_SIZE = 8;
    public final HashMap<Integer, vfd_buffer> m_pipes = new HashMap<>();
    public WebSocket m_ws;
    public util.zerr m_zerr;

    public class vfd_buffer {
        public int m_bytes_pending = 0;
        public int m_bytes_received = 0;
        public int m_bytes_sent = 0;
        public int m_client_buffer_size = 524288;
        public int m_client_win_size = 1048576;
        public int m_id;
        public ByteBufferList m_req_buffer = new ByteBufferList();
        public ByteBufferList m_res_buffer = null;
        public Runnable m_res_cb = null;
        public AsyncSocket m_socket;
        public DataCallback m_socket_up;
        public boolean m_vfd_sent = false;
        public util.zerr m_vfd_zerr;
        public Integer m_win_size = null;

        public vfd_buffer(int i) {
            this.m_id = i;
            this.m_vfd_zerr = new util.zerr(mux.this.m_zerr.tag() + "/" + this.m_id);
        }

        /* access modifiers changed from: private */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x002b, code lost:
            return r0;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public synchronized boolean add(io.lum.sdk.async.ByteBufferList r3) {
            /*
                r2 = this;
                monitor-enter(r2)
                io.lum.sdk.async.ByteBufferList r0 = r2.m_res_buffer     // Catch:{ all -> 0x002e }
                if (r0 != 0) goto L_0x0011
                io.lum.sdk.async.ByteBufferList r0 = new io.lum.sdk.async.ByteBufferList     // Catch:{ all -> 0x002e }
                byte[] r3 = r3.getAllByteArray()     // Catch:{ all -> 0x002e }
                r0.<init>((byte[]) r3)     // Catch:{ all -> 0x002e }
                r2.m_res_buffer = r0     // Catch:{ all -> 0x002e }
                goto L_0x0016
            L_0x0011:
                io.lum.sdk.async.ByteBufferList r0 = r2.m_res_buffer     // Catch:{ all -> 0x002e }
                r3.get((io.lum.sdk.async.ByteBufferList) r0)     // Catch:{ all -> 0x002e }
            L_0x0016:
                r2.recalc_pending()     // Catch:{ all -> 0x002e }
                int r3 = r2.m_client_buffer_size     // Catch:{ all -> 0x002e }
                r0 = 1
                if (r3 <= 0) goto L_0x002c
                io.lum.sdk.async.ByteBufferList r3 = r2.m_res_buffer     // Catch:{ all -> 0x002e }
                int r3 = r3.remaining()     // Catch:{ all -> 0x002e }
                int r1 = r2.m_client_buffer_size     // Catch:{ all -> 0x002e }
                if (r3 <= r1) goto L_0x0029
                goto L_0x002a
            L_0x0029:
                r0 = 0
            L_0x002a:
                monitor-exit(r2)
                return r0
            L_0x002c:
                monitor-exit(r2)
                return r0
            L_0x002e:
                r3 = move-exception
                monitor-exit(r2)
                throw r3
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.mux.vfd_buffer.add(io.lum.sdk.async.ByteBufferList):boolean");
        }

        /* JADX WARNING: Code restructure failed: missing block: B:40:0x0079, code lost:
            return true;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private synchronized boolean flush() {
            /*
                r7 = this;
                monitor-enter(r7)
                io.lum.sdk.async.ByteBufferList r0 = r7.m_res_buffer     // Catch:{ all -> 0x007a }
                r1 = 1
                if (r0 != 0) goto L_0x0008
                monitor-exit(r7)
                return r1
            L_0x0008:
                io.lum.sdk.async.ByteBufferList r0 = r7.m_res_buffer     // Catch:{ all -> 0x007a }
                int r0 = r0.remaining()     // Catch:{ all -> 0x007a }
                if (r0 >= r1) goto L_0x0012
                monitor-exit(r7)
                return r1
            L_0x0012:
                io.lum.sdk.mux r2 = io.lum.sdk.mux.this     // Catch:{ all -> 0x007a }
                io.lum.sdk.async.http.WebSocket r2 = r2.m_ws     // Catch:{ all -> 0x007a }
                r3 = 0
                if (r2 != 0) goto L_0x001d
                monitor-exit(r7)
                return r3
            L_0x001d:
                java.lang.Integer r2 = r7.m_win_size     // Catch:{ all -> 0x007a }
                if (r2 == 0) goto L_0x003c
                java.lang.Integer r2 = r7.m_win_size     // Catch:{ all -> 0x007a }
                int r2 = r2.intValue()     // Catch:{ all -> 0x007a }
                int r4 = r7.m_bytes_pending     // Catch:{ all -> 0x007a }
                int r2 = r2 - r4
                int r2 = java.lang.Math.min(r0, r2)     // Catch:{ all -> 0x007a }
                if (r2 >= r1) goto L_0x0032
                monitor-exit(r7)
                return r3
            L_0x0032:
                io.lum.sdk.async.ByteBufferList r4 = r7.m_res_buffer     // Catch:{ all -> 0x007a }
                io.lum.sdk.async.ByteBufferList r4 = r4.get((int) r2)     // Catch:{ all -> 0x007a }
                r7.send_vfd()     // Catch:{ all -> 0x007a }
                goto L_0x003f
            L_0x003c:
                io.lum.sdk.async.ByteBufferList r4 = r7.m_res_buffer     // Catch:{ all -> 0x007a }
                r2 = r0
            L_0x003f:
                byte[] r4 = r4.getAllByteArray()     // Catch:{ all -> 0x007a }
                io.lum.sdk.async.ByteBufferList r5 = new io.lum.sdk.async.ByteBufferList     // Catch:{ all -> 0x007a }
                r5.<init>((byte[]) r4)     // Catch:{ all -> 0x007a }
                int r4 = r7.m_id     // Catch:{ all -> 0x007a }
                io.lum.sdk.async.ByteBufferList r4 = io.lum.sdk.mux.add_vfd(r5, r4)     // Catch:{ all -> 0x007a }
                io.lum.sdk.mux r5 = io.lum.sdk.mux.this     // Catch:{ all -> 0x007a }
                io.lum.sdk.async.http.WebSocket r5 = r5.m_ws     // Catch:{ all -> 0x007a }
                r6 = 0
                io.lum.sdk.async.Util.writeAll((io.lum.sdk.async.DataSink) r5, (io.lum.sdk.async.ByteBufferList) r4, (io.lum.sdk.async.callback.CompletedCallback) r6)     // Catch:{ all -> 0x007a }
                int r4 = r7.m_bytes_sent     // Catch:{ all -> 0x007a }
                int r4 = r4 + r2
                r7.m_bytes_sent = r4     // Catch:{ all -> 0x007a }
                java.lang.Integer r5 = r7.m_win_size     // Catch:{ all -> 0x007a }
                if (r5 == 0) goto L_0x0064
                r7.send_ack(r4)     // Catch:{ all -> 0x007a }
            L_0x0064:
                r7.recalc_pending()     // Catch:{ all -> 0x007a }
                if (r2 >= r0) goto L_0x006b
                monitor-exit(r7)
                return r3
            L_0x006b:
                r7.m_res_buffer = r6     // Catch:{ all -> 0x007a }
                java.lang.Runnable r0 = r7.m_res_cb     // Catch:{ all -> 0x007a }
                if (r0 == 0) goto L_0x0078
                java.lang.Runnable r0 = r7.m_res_cb     // Catch:{ all -> 0x007a }
                r0.run()     // Catch:{ all -> 0x007a }
                r7.m_res_cb = r6     // Catch:{ all -> 0x007a }
            L_0x0078:
                monitor-exit(r7)
                return r1
            L_0x007a:
                r0 = move-exception
                monitor-exit(r7)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.mux.vfd_buffer.flush():boolean");
        }

        private void request() {
            request((ByteBufferList) null);
        }

        /* access modifiers changed from: private */
        public synchronized boolean response(Runnable runnable) {
            this.m_res_cb = runnable;
            return flush();
        }

        private void send_ack(int i) {
            try {
                mux.this.m_zerr.debug(String.format("ack : %s", new Object[]{Integer.valueOf(i)}));
                mux.this.m_ws.send(new JSONObject().put("vfd", this.m_id).put("ack", i).toString().replace("\\/", "/"));
            } catch (JSONException unused) {
            }
        }

        private void send_fin() {
            try {
                mux.this.m_zerr.debug("fin");
                mux.this.m_ws.send(new JSONObject().put("vfd", this.m_id).put("fin", 1).toString().replace("\\/", "/"));
            } catch (JSONException unused) {
            }
        }

        private void send_vfd() {
            if (!this.m_vfd_sent) {
                try {
                    mux.this.m_zerr.debug("vfd");
                    mux.this.m_ws.send(new JSONObject().put("vfd", this.m_id).put("win_size", this.m_client_win_size).toString().replace("\\/", "/"));
                    this.m_vfd_sent = true;
                } catch (JSONException unused) {
                }
            }
        }

        public synchronized boolean ack(int i) {
            this.m_bytes_received = i;
            recalc_pending();
            return flush();
        }

        public synchronized boolean close() {
            boolean z;
            if (this.m_socket == null) {
                z = false;
            } else {
                this.m_vfd_zerr.debug("close");
                this.m_socket.close();
                z = true;
            }
            return z;
        }

        public synchronized void recalc_pending() {
            this.m_vfd_zerr.debug(String.format("transfered: %s/%s", new Object[]{Integer.valueOf(this.m_bytes_received + this.m_bytes_pending), Integer.valueOf(this.m_bytes_sent)}));
            this.m_bytes_pending = Math.max(0, this.m_bytes_sent - this.m_bytes_received);
        }

        public synchronized void request(ByteBufferList byteBufferList) {
            if (byteBufferList != null) {
                byteBufferList.get(this.m_req_buffer);
            }
            if (this.m_req_buffer.remaining() >= 1) {
                if (this.m_socket != null) {
                    byte[] allByteArray = this.m_req_buffer.getAllByteArray();
                    if (this.m_socket_up != null) {
                        this.m_socket_up.onDataAvailable(this.m_socket, new ByteBufferList(allByteArray));
                    }
                    Util.writeAll((DataSink) this.m_socket, new ByteBufferList(allByteArray), (CompletedCallback) null);
                }
            }
        }

        public synchronized void set_client_stream_opt(int i, int i2) {
            this.m_vfd_zerr.notice(String.format("stream opt: win_size=%s, buffer_size=%s", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
            if (this.m_vfd_sent && i != this.m_client_win_size) {
                this.m_vfd_sent = false;
            }
            this.m_client_win_size = i;
            this.m_client_buffer_size = i2;
        }

        public synchronized void set_socket(AsyncSocket asyncSocket, DataCallback dataCallback) {
            this.m_socket = asyncSocket;
            this.m_socket_up = dataCallback;
            request();
        }

        public synchronized boolean set_win_size(int i) {
            this.m_vfd_zerr.debug(String.format("set win_size: %sB", new Object[]{Integer.valueOf(i)}));
            this.m_win_size = Integer.valueOf(i);
            return flush();
        }
    }

    @SuppressLint({"UseSparseArrays"})
    public mux(WebSocket webSocket, util.zerr zerr) {
        this.m_ws = webSocket;
        this.m_zerr = new util.zerr(zerr.tag() + "/mux");
    }

    public static /* synthetic */ void a(mux mux, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        if (byteBufferList.size() == 0 || byteBufferList.remaining() < 8) {
            byteBufferList.recycle();
            return;
        }
        int i = byteBufferList.getInt();
        byteBufferList.getInt();
        mux.get_vfd_buffer(i, true).request(byteBufferList);
    }

    public static ByteBufferList add_vfd(ByteBufferList byteBufferList, int i) {
        ByteBuffer allocate = ByteBuffer.allocate(8);
        allocate.order(ByteOrder.BIG_ENDIAN).putInt(i);
        allocate.putInt(0).position(0);
        ByteBufferList byteBufferList2 = new ByteBufferList(allocate);
        byteBufferList.get(byteBufferList2);
        return byteBufferList2;
    }

    public static mux create(WebSocket webSocket, util.zerr zerr) {
        mux mux = new mux(webSocket, zerr);
        webSocket.setDataCallback(new j0(mux));
        return mux;
    }

    private vfd_buffer get_vfd_buffer(int i, boolean z) {
        vfd_buffer vfd_buffer2;
        synchronized (this.m_pipes) {
            if (!this.m_pipes.containsKey(Integer.valueOf(i)) && z) {
                this.m_zerr.debug(String.format("create [%s]", new Object[]{Integer.valueOf(i)}));
                this.m_pipes.put(Integer.valueOf(i), new vfd_buffer(i));
            }
            vfd_buffer2 = this.m_pipes.get(Integer.valueOf(i));
        }
        return vfd_buffer2;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:5|6|7|8|9) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0049 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void remove_vfd_buffer(int r7) {
        /*
            r6 = this;
            io.lum.sdk.util$zerr r0 = r6.m_zerr
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "remove vfd: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            r0.notice(r1)
            java.util.HashMap<java.lang.Integer, io.lum.sdk.mux$vfd_buffer> r0 = r6.m_pipes
            monitor-enter(r0)
            java.util.HashMap<java.lang.Integer, io.lum.sdk.mux$vfd_buffer> r1 = r6.m_pipes     // Catch:{ all -> 0x0054 }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0054 }
            boolean r1 = r1.containsKey(r2)     // Catch:{ all -> 0x0054 }
            if (r1 == 0) goto L_0x0052
            io.lum.sdk.util$zerr r1 = r6.m_zerr     // Catch:{ all -> 0x0054 }
            java.lang.String r2 = "remove [%s]"
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x0054 }
            r4 = 0
            java.lang.Integer r5 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0054 }
            r3[r4] = r5     // Catch:{ all -> 0x0054 }
            java.lang.String r2 = java.lang.String.format(r2, r3)     // Catch:{ all -> 0x0054 }
            r1.debug(r2)     // Catch:{ all -> 0x0054 }
            java.util.HashMap<java.lang.Integer, io.lum.sdk.mux$vfd_buffer> r1 = r6.m_pipes     // Catch:{ NullPointerException -> 0x0049 }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r7)     // Catch:{ NullPointerException -> 0x0049 }
            java.lang.Object r1 = r1.get(r2)     // Catch:{ NullPointerException -> 0x0049 }
            io.lum.sdk.mux$vfd_buffer r1 = (io.lum.sdk.mux.vfd_buffer) r1     // Catch:{ NullPointerException -> 0x0049 }
            r1.close()     // Catch:{ NullPointerException -> 0x0049 }
        L_0x0049:
            java.util.HashMap<java.lang.Integer, io.lum.sdk.mux$vfd_buffer> r1 = r6.m_pipes     // Catch:{ all -> 0x0054 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0054 }
            r1.remove(r7)     // Catch:{ all -> 0x0054 }
        L_0x0052:
            monitor-exit(r0)     // Catch:{ all -> 0x0054 }
            return
        L_0x0054:
            r7 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0054 }
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.mux.remove_vfd_buffer(int):void");
    }

    public /* synthetic */ void a(int i, CompletedCallback completedCallback, Exception exc) {
        if (exc != null) {
            this.m_zerr.err(exc.toString());
        }
        this.m_zerr.notice("socket closed");
        remove_vfd_buffer(i);
        completedCallback.onCompleted(exc);
    }

    public /* synthetic */ void a(DataCallback dataCallback, DataEmitter dataEmitter, ByteBufferList byteBufferList, boolean z, AsyncSocket asyncSocket) {
        dataCallback.onDataAvailable(dataEmitter, byteBufferList);
        if (z) {
            asyncSocket.resume();
            this.m_zerr.debug("socket resumed");
        }
    }

    public /* synthetic */ void a(vfd_buffer vfd_buffer2, AsyncSocket asyncSocket, DataCallback dataCallback, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        boolean access$300 = vfd_buffer2.add(byteBufferList);
        if (access$300) {
            asyncSocket.pause();
            this.m_zerr.debug("socket paused");
        }
        boolean unused = vfd_buffer2.response(new k0(this, dataCallback, dataEmitter, byteBufferList, access$300, asyncSocket));
    }

    public void ack(int i, int i2) {
        vfd_buffer vfd_buffer2 = get_vfd_buffer(i, false);
        if (vfd_buffer2 != null) {
            vfd_buffer2.ack(i2);
        }
    }

    public void close() {
        Integer[] numArr;
        Integer[] numArr2 = new Integer[0];
        synchronized (this.m_pipes) {
            numArr = (Integer[]) this.m_pipes.keySet().toArray(numArr2);
        }
        for (Integer intValue : numArr) {
            close(intValue.intValue());
        }
    }

    public boolean close(int i) {
        vfd_buffer vfd_buffer2 = get_vfd_buffer(i, false);
        if (vfd_buffer2 == null) {
            return false;
        }
        vfd_buffer2.close();
        return true;
    }

    public void pipe(AsyncSocket asyncSocket, int i, DataCallback dataCallback, DataCallback dataCallback2, CompletedCallback completedCallback) {
        vfd_buffer vfd_buffer2 = get_vfd_buffer(i, true);
        vfd_buffer2.set_socket(asyncSocket, dataCallback2);
        asyncSocket.setDataCallback(new i0(this, vfd_buffer2, asyncSocket, dataCallback));
        asyncSocket.setClosedCallback(new l0(this, i, completedCallback));
    }

    public void set_client_stream_opt(int i, int i2, int i3) {
        get_vfd_buffer(i, true).set_client_stream_opt(i2, i3);
    }

    public void set_stream_opt(int i, int i2) {
        get_vfd_buffer(i, true).set_win_size(i2);
    }
}
