package io.lum.sdk;

import android.os.Build;
import android.util.Pair;
import d.a.a.d;
import io.lum.sdk.conf;
import io.lum.sdk.perr;
import java.util.HashSet;
import java.util.Iterator;
import org.json.JSONObject;

public class apk_config extends remote_config {
    public zajax m_ccgi;

    public apk_config() {
        super(conf.APK_CONFIG, conf.APK_CONFIG_LAST_UPDATE, util.MS_HOUR);
    }

    private String build_uri(String str) {
        StringBuilder sb = new StringBuilder(str);
        sb.append("?");
        HashSet hashSet = new HashSet();
        hashSet.add(new Pair("is_first_run", "0"));
        hashSet.add(new Pair(perr.columns.VER, "1.177.86 android arm"));
        hashSet.add(new Pair("tag", config.CONFIG_CVS_TAG));
        hashSet.add(new Pair("build_date", config.CONFIG_BUILD_DATE));
        hashSet.add(new Pair("makeflags", config.CONFIG_MAKEFLAGS));
        hashSet.add(new Pair("os_version", util.get_os_ver()));
        hashSet.add(new Pair("device", util.get_device()));
        hashSet.add(new Pair("cpu_abi", Build.CPU_ABI));
        hashSet.add(new Pair("cpu_abi2", Build.CPU_ABI2));
        hashSet.add(new Pair("apkid", util.apkid));
        hashSet.add(new Pair("partnerid", util.m_conf.get_str(conf.PARTNERID)));
        hashSet.add(new Pair("uuid", util.m_conf.get_str(conf.UUID)));
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            String str2query = util.str2query((String) pair.first, (String) pair.second);
            if (str2query != null) {
                sb.append(str2query);
                if (it.hasNext()) {
                    sb.append("&");
                }
            }
        }
        zerr(7, "uri: " + sb);
        return sb.toString();
    }

    public /* synthetic */ boolean a(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            zerr(5, "failed apk_config request: " + str);
            return false;
        }
        String jSONObject2 = jSONObject.toString();
        zerr(5, "update cb: " + jSONObject2);
        set_json(jSONObject);
        util.m_conf.set(this.m_storage_key, jSONObject2);
        return true;
    }

    public void set_json(JSONObject jSONObject) {
        int optInt;
        boolean optBoolean;
        JSONObject jSONObject2 = jSONObject;
        conf.key[] keyArr = {conf.SDK_DISABLED, conf.SVC_FALLBACK_LEGACY, conf.SVC_FALLBACK_EMBED, conf.TAKE_POPUP_SCREENSHOT, conf.SVC_JOB_KILL_PROCESS, conf.REPEATING_ALARMS, conf.PUSH_STATUS_REPORT, conf.PERR_DB_ENABLED, conf.PERR_SEND_PENDING_INSTALL, conf.PERR_SEND_PENDING_UPDATE, conf.PERR_SEND_PENDING_OLD, conf.SPROXY_SSL, conf.IS_DEBUG, conf.WS_PING_PROXYJS, conf.WS_PING_ZAGENT, conf.USAGE_STATS, conf.WS_CONN_PROXYJS_EXT_IP_CHECK, conf.DISABLE_TLS1};
        int i = 0;
        for (int i2 = 18; i < i2; i2 = 18) {
            conf.key key = keyArr[i];
            String key2 = key.toString();
            if (jSONObject2.has(key2) && (optBoolean = jSONObject2.optBoolean(key2, zon_conf.CONF.optBoolean(key2))) != util.m_conf.get_bool(key)) {
                util.m_conf.set(key, optBoolean);
            }
            i++;
        }
        conf.key[] keyArr2 = {conf.SVC_KEEPALIVE_PERIOD, conf.SVC_JOB_KEEPALIVE_PERIOD, conf.SVC_JOB_NEXT_RUN_DELAY, conf.SVC_JOB_MAX_DURATION};
        for (int i3 = 0; i3 < 4; i3++) {
            conf.key key3 = keyArr2[i3];
            String key4 = key3.toString();
            if (jSONObject2.has(key4) && (optInt = jSONObject2.optInt(key4, zon_conf.CONF.optInt(key4))) != util.m_conf.get_int(key3)) {
                util.m_conf.set(key3, optInt);
            }
        }
        conf.key[] keyArr3 = {conf.SVC_FALLBACK_FOR, conf.PUSH_STATUS_REPORT_FREQ, conf.PUSH_STATUS_REPORT_ERR_FREQ, conf.PUSH_STATUS_REPORT_DELAY, conf.WS_PING_PROXYJS_INTERVAL, conf.WS_PING_PROXYJS_TIMEOUT, conf.WS_PING_ZAGENT_INTERVAL, conf.WS_PING_ZAGENT_TIMEOUT, conf.IS_SUPPORTED_EXPIRE};
        for (int i4 = 0; i4 < 9; i4++) {
            conf.key key5 = keyArr3[i4];
            String key6 = key5.toString();
            if (jSONObject2.has(key6)) {
                long optLong = jSONObject2.optLong(key6, zon_conf.CONF.optLong(key6));
                if (optLong != util.m_conf.get_long(key5)) {
                    util.m_conf.set(key5, optLong);
                }
            }
        }
        conf.key[] keyArr4 = {conf.PERR_SSL_HOST, conf.CCGI_SSL_HOST, conf.PERR_MIN_VER, conf.WS_CONN_PROXYJS, conf.WS_CONN_ZAGENT, conf.WS_CONN_PROXYJS_FORCE_IP, conf.WS_CONN_PROXYJS_SPROXY};
        for (int i5 = 0; i5 < 7; i5++) {
            conf.key key7 = keyArr4[i5];
            String key8 = key7.toString();
            if (jSONObject2.has(key8)) {
                String optString = jSONObject2.optString(key8, zon_conf.CONF.optString(key8));
                if (!optString.equals(util.m_conf.get_str(key7))) {
                    util.m_conf.set(key7, optString);
                }
            }
        }
        Pair[] pairArr = {new Pair(conf.WS_CONN_PROXYJS_FORCE_IP, svc_host.FALLBACK_NONE)};
        for (int i6 = 0; i6 < 1; i6++) {
            Pair pair = pairArr[i6];
            conf.key key9 = (conf.key) pair.first;
            String str = (String) pair.second;
            String key10 = key9.toString();
            if (jSONObject2.has(key10)) {
                String optString2 = jSONObject2.optString(key10, zon_conf.CONF.optString(key10, str));
                if (!optString2.equals(util.m_conf.get_str(key9))) {
                    util.m_conf.set(key9, optString2);
                }
            }
        }
        if (jSONObject2.has(perr.columns.TABLE_NAME)) {
            JSONObject optJSONObject = jSONObject2.optJSONObject(perr.columns.TABLE_NAME);
            if (optJSONObject == null) {
                optJSONObject = zon_conf.CONF.optJSONObject(perr.columns.TABLE_NAME);
            }
            JSONObject jSONObject3 = util.m_conf.get_json(conf.PERR_IDS);
            if (optJSONObject != null && !optJSONObject.equals(jSONObject3)) {
                util.m_conf.set(conf.PERR_IDS, optJSONObject);
            }
        }
        if (jSONObject2.has("zagent_sdk_ports")) {
            zon_conf.set_zagent_ports(jSONObject2.optJSONArray("zagent_sdk_ports"));
        }
        if (jSONObject2.has("zagent_sdk_ports_ssl")) {
            zon_conf.set_zagent_ports_ssl(jSONObject2.optJSONArray("zagent_sdk_ports_ssl"));
        }
        if (jSONObject2.optBoolean(conf.SDK_DISABLED.toString())) {
            util.m_conf.set(conf.SDK_DISABLED_UNTIL, jSONObject2.optLong("sdk_disabled_for", 86400000) + System.currentTimeMillis());
            return;
        }
        util.m_conf.del(conf.SDK_DISABLED_UNTIL);
    }

    public synchronized void update() {
        if (this.m_ccgi == null) {
            this.m_ccgi = new zajax(new String[]{"54.243.159.121", "54.197.246.90", "clientsdk.lum-sdk.io", "clientsdk.luminatinet.com", "clientsdk.luminati-china.io"}, "https://", util.ccgi_host(), build_uri("/apk_config.json"));
        }
        this.m_ccgi.ajax(new d(this));
    }
}
