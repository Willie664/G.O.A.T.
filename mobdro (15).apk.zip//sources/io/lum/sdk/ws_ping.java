package io.lum.sdk;

import d.a.a.p1;
import d.a.a.q1;
import d.a.a.r1;
import d.a.a.s1;
import d.a.a.t1;
import d.a.a.u1;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.util;
import java.util.Timer;
import java.util.TimerTask;

public class ws_ping {
    public final Object m_lock = new Object();
    public Runnable m_on_timeout;
    public int m_ping_delay;
    public Timer m_ping_t = null;
    public int m_timeout_delay;
    public Timer m_timeout_t = null;
    public WebSocket m_ws;
    public util.zerr m_zerr;

    public ws_ping(String str, WebSocket webSocket, int i, int i2, Runnable runnable) {
        this.m_zerr = new util.zerr(str);
        this.m_ws = webSocket;
        this.m_ping_delay = i;
        this.m_timeout_delay = i2;
        this.m_on_timeout = runnable;
        this.m_ws.setPongCallback(new s1(this, webSocket.getPongCallback()));
        this.m_ws.setStringCallback(new u1(this, this.m_ws.getStringCallback()));
        this.m_ws.setDataCallback(new p1(this, this.m_ws.getDataCallback()));
        this.m_ws.setClosedCallback(new q1(this, this.m_ws.getClosedCallback()));
        this.m_zerr.notice("create");
        run();
    }

    private void cancel_timer(Timer timer) {
        if (timer != null) {
            timer.cancel();
        }
    }

    private void cancel_timers() {
        synchronized (this.m_lock) {
            cancel_timer(this.m_timeout_t);
            this.m_timeout_t = null;
            cancel_timer(this.m_ping_t);
            this.m_ping_t = null;
        }
    }

    private TimerTask create_timer_task(final Runnable runnable) {
        return new TimerTask() {
            public void run() {
                runnable.run();
            }
        };
    }

    private void destroy() {
        synchronized (this.m_lock) {
            this.m_zerr.notice("destroy");
            cancel_timers();
        }
    }

    private TimerTask get_ping_task() {
        return create_timer_task(new t1(this));
    }

    private TimerTask get_timeout_task() {
        return create_timer_task(new r1(this));
    }

    private void reset() {
        this.m_zerr.debug("reset");
        cancel_timers();
        run();
    }

    public static void run(String str, WebSocket webSocket, int i, int i2, Runnable runnable) {
        new ws_ping(str, webSocket, i < 10000 ? util.MS_MIN : i, i2 < 5000 ? 10000 : i2, runnable);
    }

    public /* synthetic */ void a() {
        synchronized (this.m_lock) {
            this.m_zerr.debug("ping");
            this.m_ws.ping(this.m_zerr.tag());
            cancel_timer(this.m_timeout_t);
            Timer timer = new Timer();
            this.m_timeout_t = timer;
            timer.schedule(get_timeout_task(), (long) this.m_timeout_delay);
        }
    }

    public /* synthetic */ void a(CompletedCallback completedCallback, Exception exc) {
        if (completedCallback != null) {
            completedCallback.onCompleted(exc);
        }
        destroy();
    }

    public /* synthetic */ void a(DataCallback dataCallback, DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        if (dataCallback != null) {
            dataCallback.onDataAvailable(dataEmitter, byteBufferList);
        }
        reset();
    }

    public /* synthetic */ void a(WebSocket.PongCallback pongCallback, String str) {
        if (pongCallback != null) {
            pongCallback.onPongReceived(str);
        }
        this.m_zerr.debug("pong");
        reset();
    }

    public /* synthetic */ void a(WebSocket.StringCallback stringCallback, String str) {
        if (stringCallback != null) {
            stringCallback.onStringAvailable(str);
        }
        reset();
    }

    public /* synthetic */ void b() {
        synchronized (this.m_lock) {
            this.m_zerr.err("ping timeout");
            this.m_on_timeout.run();
        }
    }

    public void run() {
        synchronized (this.m_lock) {
            if (this.m_ping_t == null) {
                this.m_zerr.debug("run");
                Timer timer = new Timer();
                this.m_ping_t = timer;
                timer.schedule(get_ping_task(), (long) this.m_ping_delay);
            }
        }
    }
}
