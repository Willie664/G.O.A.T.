package io.lum.sdk;

import d.a.a.g0;
import d.a.a.h0;
import io.lum.sdk.async.future.SimpleFuture;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class etask<T> {
    public ExecutorService m_es = Executors.newSingleThreadExecutor();
    public Future<T> m_future;
    public final SimpleFuture<T> m_waiter = new SimpleFuture<>();

    public static etask interval(Runnable runnable, long j) {
        return run(new h0(runnable, j));
    }

    public static etask run(Runnable runnable) {
        return new etask().start(runnable);
    }

    public static <T> etask<T> run(Callable<T> callable) {
        return new etask().start(callable);
    }

    private etask start(Runnable runnable) {
        this.m_future = this.m_es.submit(runnable, (Object) null);
        return this;
    }

    private etask<T> start(Callable<T> callable) {
        this.m_future = this.m_es.submit(callable);
        return this;
    }

    public static <T> etask<T> zwait() {
        etask<T> etask = new etask<>();
        etask.start((Callable<T>) new g0(etask));
        return etask;
    }

    public boolean cancel() {
        Future<T> future = this.m_future;
        if (future != null) {
            future.cancel(true);
        }
        this.m_es.shutdownNow();
        try {
            return this.m_es.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException unused) {
            return false;
        }
    }

    public T yield() {
        return this.m_future.get();
    }

    public void zcontinue(T t) {
        this.m_waiter.setComplete(t);
    }

    public void zthrow(Exception exc) {
        this.m_waiter.setComplete(exc);
    }
}
