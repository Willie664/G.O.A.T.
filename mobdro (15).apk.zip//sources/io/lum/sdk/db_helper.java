package io.lum.sdk;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class db_helper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;

    public static class mobile_usage implements BaseColumns {
        public static final String APP_BW = "app_bw";
        public static final String DATE = "date";
        public static final String DEVICE_BW_SINCE_BOOT = "device_bw_since_boot";
        public static final String DEVICE_DAILY_BW = "device_daily_bw";
        public static final String SQL_CREATE = "CREATE TABLE mobile_usage (_id INTEGER PRIMARY KEY,date INTEGER,app_bw INTEGER,device_bw_since_boot INTEGER,device_daily_bw INTEGER)";
        public static final String TABLE_NAME = "mobile_usage";
    }

    public db_helper(Context context, String str) {
        super(context, str, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(mobile_usage.SQL_CREATE);
    }

    public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }
}
