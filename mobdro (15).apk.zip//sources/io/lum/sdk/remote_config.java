package io.lum.sdk;

import b.a.a.a.a;
import io.lum.sdk.conf;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class remote_config {
    public int m_expire;
    public conf.key m_storage_key;

    public remote_config(conf.key key, conf.key key2, int i) {
        this.m_storage_key = key;
        this.m_expire = i;
        set_json(util.m_conf.get_str(this.m_storage_key, "{}"));
        long j = util.m_conf.get_long(key2);
        long time = new Date().getTime();
        long j2 = time - j;
        if (j == 0 || j2 > ((long) i)) {
            util.m_conf.set(key2, time);
            update();
            if (j == 0) {
                util.perr(5, this.m_storage_key + "_init", true);
                return;
            }
            util.perr(5, this.m_storage_key + "_update", a.a("delay: ", j2), "", true);
        }
    }

    private void set_json(String str) {
        if (str != null && !str.isEmpty()) {
            try {
                set_json(new JSONObject(str));
            } catch (JSONException e2) {
                zerr(3, "parsing failed: " + e2);
            }
        }
    }

    public abstract void set_json(JSONObject jSONObject);

    public abstract void update();

    public void zerr(int i, String str) {
        StringBuilder a2 = a.a("lumsdk/");
        a2.append(this.m_storage_key);
        util._zerr(a2.toString(), i, str);
    }
}
