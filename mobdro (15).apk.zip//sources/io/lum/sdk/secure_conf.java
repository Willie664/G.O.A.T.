package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Pair;
import androidx.core.os.EnvironmentCompat;
import b.a.a.a.a;
import d.a.a.r0;
import d.a.a.s0;
import io.lum.sdk.conf;
import io.lum.sdk.util;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class secure_conf {
    public static final String MIN_VER = "1.165.190";
    public static final long MISMATCH_DELAY = 60000;
    public static volatile secure_conf m_instance;
    public static HashMap<conf.key, key_params> m_keys = new HashMap<>();
    public static ArrayList<Integer> m_migrate_milestones = new ArrayList<>();
    public static HashMap<String, signature_method> m_signature_methods = new HashMap<>();
    public static util.zerr m_zerr = new util.zerr("secure_conf");
    public String m_filename;
    public JSONObject m_values = new JSONObject();

    public static class key_params {
        public static final String TYPE_INTEGER = Integer.class.getSimpleName();
        public static final String TYPE_LONG = Long.class.getSimpleName();
        public static final String TYPE_STRING = String.class.getSimpleName();
        public boolean local;
        public boolean readonly;
        public String type;

        public key_params() {
            this(false);
        }

        public key_params(String str) {
            this(false, str, false);
        }

        public key_params(boolean z) {
            this(z, TYPE_STRING, false);
        }

        public key_params(boolean z, String str, boolean z2) {
            this.readonly = z;
            this.type = str;
            this.local = z2;
        }

        public key_params(boolean z, boolean z2) {
            this(z, TYPE_STRING, z2);
        }

        public boolean is_integer() {
            return TYPE_INTEGER.equals(this.type);
        }

        public boolean is_long() {
            return TYPE_LONG.equals(this.type);
        }
    }

    public interface signature_method {
        String run(Context context);
    }

    static {
        m_keys.put(conf.CHOICE, new key_params(key_params.TYPE_INTEGER));
        m_keys.put(conf.SECURE_CONF_UPDATE_TS, new key_params(false, key_params.TYPE_LONG, true));
        m_keys.put(conf.UUID, new key_params(true));
        m_keys.put(conf.TRACKING_ID, new key_params());
        m_keys.put(conf.SECURE_CONF_SIGNATURE, new key_params(true, true));
        m_keys.put(conf.SECURE_CONF_SIGNATURE_TYPE, new key_params(true, true));
        m_migrate_milestones.addAll(Arrays.asList(new Integer[]{1, 2, 5, 10, 50, 100}));
        get_signature_methods();
    }

    public secure_conf(Context context) {
        String str;
        this.m_filename = context.getFilesDir() + "/lumsdk_sc.dat";
        if (read(context)) {
            Pair<String, String> pair = get_signature(context);
            if (pair == null) {
                str = "secure_conf_signature_failed";
            } else if (load(conf.SECURE_CONF_SIGNATURE) == null) {
                save(conf.SECURE_CONF_SIGNATURE, pair.first, false);
                save(conf.SECURE_CONF_SIGNATURE_TYPE, pair.second, false);
                StringBuilder a2 = a.a("type: ");
                a2.append((String) pair.second);
                util.perr_p(5, "secure_conf_signature", (String) pair.first, a2.toString(), true);
                str = "secure_conf_signature_" + ((String) pair.second);
            } else {
                verify(pair);
                sync();
            }
            util.perr_p(5, str, true);
            sync();
        }
    }

    private void export(conf.key key, Object obj, key_params key_params2) {
        Long l;
        Object load_prev = load_prev(key, key_params2);
        if (load_prev != obj) {
            if (!(!key_params2.readonly || load_prev == null || load_prev == "" || (l = get_delay()) == null || l.longValue() < MISMATCH_DELAY)) {
                util.perr_p(3, "secure_conf_mismatch", String.format("current: %s, prev: %s, delay: %sms", new Object[]{obj, load_prev, l}), "", true);
            }
            if (key_params2.is_integer()) {
                util.m_conf.set(key, ((Integer) obj).intValue());
            } else if (key_params2.is_long()) {
                util.m_conf.set(key, ((Long) obj).longValue());
            } else {
                util.m_conf.set(key, (String) obj);
            }
        }
    }

    private Long get_delay() {
        Long l = (Long) load(conf.SECURE_CONF_UPDATE_TS);
        if (l == null) {
            return null;
        }
        return Long.valueOf(System.currentTimeMillis() - l.longValue());
    }

    public static secure_conf get_instance(Context context) {
        if (m_instance == null) {
            m_instance = new secure_conf(context);
        }
        return m_instance;
    }

    public static key_params get_key_params(conf.key key) {
        if (m_keys.containsKey(key)) {
            return m_keys.get(key);
        }
        util.zerr zerr = m_zerr;
        zerr.err("unsupported key: " + key);
        return null;
    }

    public static Pair<String, String> get_signature(Context context) {
        for (Map.Entry next : m_signature_methods.entrySet()) {
            String run = ((signature_method) next.getValue()).run(context);
            String str = (String) next.getKey();
            if (run != null && !run.isEmpty() && !run.equals(EnvironmentCompat.MEDIA_UNKNOWN)) {
                return new Pair<>(run, str);
            }
        }
        return null;
    }

    @SuppressLint({"HardwareIds"})
    public static void get_signature_methods() {
        m_signature_methods.put("android_id", r0.f7347a);
        m_signature_methods.put("serial", s0.f7351a);
    }

    private Object load(conf.key key) {
        key_params key_params2 = get_key_params(key);
        JSONObject jSONObject = this.m_values;
        String optString = jSONObject.optString("" + key);
        if (optString == null) {
            return null;
        }
        if (key_params2 == null) {
            return optString;
        }
        if (optString.isEmpty()) {
            return null;
        }
        return key_params2.is_integer() ? Integer.valueOf(optString) : key_params2.is_long() ? Long.valueOf(optString) : optString;
    }

    private Object load_prev(conf.key key, key_params key_params2) {
        return key_params2.is_integer() ? Integer.valueOf(util.m_conf.get_int(key)) : util.m_conf.get_str(key);
    }

    private void migrate(Context context) {
        int import_choice = util.import_choice(context, util.m_conf.get_int(conf.CHOICE));
        if (import_choice > 0) {
            save(conf.CHOICE, Integer.valueOf(import_choice), false);
        }
        String import_uuid = util.import_uuid(context, util.m_conf.get_str(conf.UUID));
        if (import_uuid != null && !import_uuid.isEmpty()) {
            save(conf.UUID, import_uuid, false);
        }
        String import_tracking_id = util.import_tracking_id(context, util.m_conf.get_str(conf.TRACKING_ID));
        if (import_tracking_id != null && !import_tracking_id.isEmpty()) {
            save(conf.TRACKING_ID, import_tracking_id, false);
        }
        write();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00ca, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized boolean read(android.content.Context r7) {
        /*
            r6 = this;
            monitor-enter(r6)
            java.lang.String r0 = r6.m_filename     // Catch:{ all -> 0x00cb }
            boolean r0 = io.lum.sdk.util.file_exists(r0)     // Catch:{ all -> 0x00cb }
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0061
            java.lang.String r0 = r6.m_filename     // Catch:{ Exception -> 0x0044 }
            byte[] r0 = io.lum.sdk.util.file_read(r0)     // Catch:{ Exception -> 0x0044 }
            java.lang.String r0 = io.lum.sdk.util.byte2str(r0)     // Catch:{ Exception -> 0x0044 }
            if (r0 == 0) goto L_0x003c
            java.lang.String r0 = io.lum.sdk.util.decrypt(r0)     // Catch:{ Exception -> 0x0044 }
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch:{ Exception -> 0x0044 }
            r3.<init>(r0)     // Catch:{ Exception -> 0x0044 }
            r6.m_values = r3     // Catch:{ Exception -> 0x0044 }
            io.lum.sdk.util$zerr r0 = m_zerr     // Catch:{ Exception -> 0x0044 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0044 }
            r3.<init>()     // Catch:{ Exception -> 0x0044 }
            java.lang.String r4 = "m_values: "
            r3.append(r4)     // Catch:{ Exception -> 0x0044 }
            org.json.JSONObject r4 = r6.m_values     // Catch:{ Exception -> 0x0044 }
            r3.append(r4)     // Catch:{ Exception -> 0x0044 }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x0044 }
            r0.debug(r3)     // Catch:{ Exception -> 0x0044 }
            monitor-exit(r6)
            return r2
        L_0x003c:
            java.lang.Error r0 = new java.lang.Error     // Catch:{ Exception -> 0x0044 }
            java.lang.String r3 = "loaded null"
            r0.<init>(r3)     // Catch:{ Exception -> 0x0044 }
            throw r0     // Catch:{ Exception -> 0x0044 }
        L_0x0044:
            r0 = move-exception
            io.lum.sdk.util$zerr r3 = m_zerr     // Catch:{ all -> 0x00cb }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00cb }
            r4.<init>()     // Catch:{ all -> 0x00cb }
            java.lang.String r5 = "read err: "
            r4.append(r5)     // Catch:{ all -> 0x00cb }
            java.lang.String r0 = io.lum.sdk.util.e2s(r0)     // Catch:{ all -> 0x00cb }
            r4.append(r0)     // Catch:{ all -> 0x00cb }
            java.lang.String r0 = r4.toString()     // Catch:{ all -> 0x00cb }
            r3.err((java.lang.String) r0)     // Catch:{ all -> 0x00cb }
            r0 = 1
            goto L_0x0062
        L_0x0061:
            r0 = 0
        L_0x0062:
            io.lum.sdk.conf r3 = io.lum.sdk.util.m_conf     // Catch:{ all -> 0x00cb }
            io.lum.sdk.conf$key r4 = io.lum.sdk.conf.INSTALL_VERSION     // Catch:{ all -> 0x00cb }
            java.lang.String r3 = r3.get_str(r4)     // Catch:{ all -> 0x00cb }
            java.lang.String r4 = "1.165.190"
            int r3 = io.lum.sdk.util.version_cmp(r3, r4)     // Catch:{ all -> 0x00cb }
            if (r3 < 0) goto L_0x0074
            r3 = 1
            goto L_0x0075
        L_0x0074:
            r3 = 0
        L_0x0075:
            r4 = 3
            if (r3 != 0) goto L_0x00b2
            io.lum.sdk.conf r0 = io.lum.sdk.util.m_conf     // Catch:{ all -> 0x00cb }
            io.lum.sdk.conf$key r1 = io.lum.sdk.conf.SECURE_CONF_MIGRATE     // Catch:{ all -> 0x00cb }
            int r0 = r0.get_int(r1)     // Catch:{ all -> 0x00cb }
            java.util.ArrayList<java.lang.Integer> r1 = m_migrate_milestones     // Catch:{ all -> 0x00cb }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)     // Catch:{ all -> 0x00cb }
            boolean r1 = r1.contains(r3)     // Catch:{ all -> 0x00cb }
            if (r1 == 0) goto L_0x00a5
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x00cb }
            r1.<init>()     // Catch:{ all -> 0x00cb }
            java.lang.String r3 = "secure_conf_migrate_removed_"
            r1.append(r3)     // Catch:{ all -> 0x00cb }
            r3 = 2
            java.lang.String r3 = io.lum.sdk.util.pad_number(r0, r3)     // Catch:{ all -> 0x00cb }
            r1.append(r3)     // Catch:{ all -> 0x00cb }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x00cb }
            io.lum.sdk.util.perr_p(r4, r1, r2)     // Catch:{ all -> 0x00cb }
        L_0x00a5:
            r6.migrate(r7)     // Catch:{ all -> 0x00cb }
            io.lum.sdk.conf r7 = io.lum.sdk.util.m_conf     // Catch:{ all -> 0x00cb }
            io.lum.sdk.conf$key r1 = io.lum.sdk.conf.SECURE_CONF_MIGRATE     // Catch:{ all -> 0x00cb }
            int r0 = r0 + r2
            r7.set(r1, (int) r0)     // Catch:{ all -> 0x00cb }
            monitor-exit(r6)
            return r2
        L_0x00b2:
            if (r0 == 0) goto L_0x00b7
            java.lang.String r7 = "secure_conf_corrupted"
            goto L_0x00b9
        L_0x00b7:
            java.lang.String r7 = "secure_conf_removed"
        L_0x00b9:
            io.lum.sdk.util.perr_p(r4, r7, r2)     // Catch:{ all -> 0x00cb }
            org.json.JSONObject r7 = io.lum.sdk.zon_conf.CONF     // Catch:{ all -> 0x00cb }
            java.lang.String r0 = "SC_RESTORE_REMOVED"
            boolean r7 = r7.optBoolean(r0)     // Catch:{ all -> 0x00cb }
            if (r7 == 0) goto L_0x00c9
            r6.restore()     // Catch:{ all -> 0x00cb }
        L_0x00c9:
            monitor-exit(r6)
            return r1
        L_0x00cb:
            r7 = move-exception
            monitor-exit(r6)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.secure_conf.read(android.content.Context):boolean");
    }

    private void restore() {
        save(conf.CHOICE, Integer.valueOf(util.m_conf.get_int(conf.CHOICE)), false);
        save(conf.TRACKING_ID, util.m_conf.get_str(conf.TRACKING_ID), false);
        save(conf.UUID, util.m_conf.get_str(conf.UUID), false);
        write();
    }

    private void sync() {
        for (Map.Entry next : m_keys.entrySet()) {
            conf.key key = (conf.key) next.getKey();
            key_params key_params2 = (key_params) next.getValue();
            Object load = load(key);
            if (load != null) {
                m_zerr.debug(String.format("sync: %s = %s", new Object[]{key, load}));
                export(key, load, key_params2);
            }
        }
    }

    private synchronized void verify(Pair<String, String> pair) {
        verify_choice();
        verify_signature(pair);
    }

    private void verify_choice() {
        Integer num;
        conf.key key = conf.CHOICE;
        Integer num2 = (Integer) load(key);
        key_params key_params2 = get_key_params(key);
        if (num2 == null && key_params2 != null && (num = (Integer) load_prev(key, key_params2)) != null && num.intValue() != 0) {
            util.perr_p(3, "secure_conf_choice_mismatch", String.format("choice: %s, delay: %s", new Object[]{num, get_delay()}), "", true);
        }
    }

    private void verify_signature(Pair<String, String> pair) {
        if (pair != null) {
            String str = (String) load(conf.SECURE_CONF_SIGNATURE);
            if (!((String) pair.first).equals(str)) {
                String str2 = (String) load(conf.SECURE_CONF_SIGNATURE_TYPE);
                String format = String.format("expected: %s (%s), actual: %s (%s)", new Object[]{pair.first, pair.second, str, str2});
                util.perr_p(3, "secure_conf_signature_mismatch", format, "", true);
                Object obj = pair.second;
                if (obj != null && !((String) obj).equals(str2)) {
                    util.perr_p(3, "secure_conf_signature_mismatch_type", format, "", true);
                }
            }
        }
    }

    private synchronized void write() {
        try {
            if (this.m_values.length() != 0) {
                save(conf.SECURE_CONF_UPDATE_TS, Long.valueOf(System.currentTimeMillis()), false);
                util.file_write(this.m_filename, (InputStream) new ByteArrayInputStream(util.encrypt(this.m_values.toString()).getBytes()));
            } else {
                return;
            }
        } catch (Exception e2) {
            util.zerr zerr = m_zerr;
            zerr.err("write err: " + util.e2s(e2));
        }
    }

    public void save(conf.key key, Object obj) {
        save(key, obj, true);
    }

    public void save(conf.key key, Object obj, boolean z) {
        util.zerr zerr;
        String str;
        if (obj == null) {
            zerr = m_zerr;
            str = "save null: " + key;
        } else {
            key_params key_params2 = get_key_params(key);
            String optString = this.m_values.optString("" + key, (String) null);
            String str2 = "" + obj;
            if (!str2.equals(optString)) {
                if (key_params2 == null || !key_params2.readonly || optString == null || optString.isEmpty()) {
                    try {
                        this.m_values.put("" + key, "" + obj);
                    } catch (JSONException e2) {
                        util.zerr zerr2 = m_zerr;
                        StringBuilder a2 = a.a("save error: ");
                        a2.append(util.e2s(e2));
                        zerr2.err(a2.toString());
                    }
                    if (z) {
                        write();
                        if (key_params2 != null && !key_params2.local) {
                            export(key, obj, key_params2);
                            return;
                        }
                        return;
                    }
                    return;
                }
                zerr = m_zerr;
                str = String.format("readonly %s overwrite %s -> %s", new Object[]{key, optString, str2});
            } else {
                return;
            }
        }
        zerr.err(str);
    }
}
