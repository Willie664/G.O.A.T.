package io.lum.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import b.a.a.a.a;
import io.lum.sdk.util;

public class bcast_recv extends BroadcastReceiver {
    public static String NAME_APP = "app";
    public static String NAME_SVC = "svc";
    public static final int REQUEST_CODE_NET_SVC_KEEPALIVE = 10001;
    public static final int REQUEST_CODE_SVC_KEEPALIVE = 10000;
    public static String m_name = "app";
    public static state m_state;

    public static class action_task extends AsyncTask {
        public String m_action;
        public conf m_conf;
        public Context m_ctx;
        public String m_id;
        public Intent m_intent;
        public boolean m_on_battery;
        public boolean m_should_restart;
        public boolean m_should_start;
        public boolean m_should_stop;
        public state m_state;

        public action_task(Context context, Intent intent) {
            this.m_ctx = context;
            this.m_intent = intent;
            this.m_action = String.valueOf(intent.getAction());
        }

        public boolean before_action() {
            String str;
            Thread currentThread = Thread.currentThread();
            StringBuilder a2 = a.a("bcast_recv_");
            a2.append(bcast_recv.m_name);
            a2.append("_action");
            currentThread.setName(a2.toString());
            if (util.util_init(this.m_ctx, "bcast_recv") < 0) {
                return false;
            }
            bcast_recv.zerr(7, "started");
            if (util.is_debug_layout()) {
                return false;
            }
            if (!bcast_recv.m_name.equals(bcast_recv.NAME_SVC)) {
                util.start_svc_host(this.m_ctx, this.m_action);
            }
            this.m_conf = new conf(this.m_ctx);
            this.m_state = new state(this.m_ctx);
            int unused = bcast_recv.zerr(7, "started", this.m_action);
            try {
                Thread currentThread2 = Thread.currentThread();
                currentThread2.setName("bcast_recv_" + bcast_recv.m_name + "action_" + this.m_action);
            } catch (Exception unused2) {
            }
            this.m_id = this.m_intent.getDataString();
            this.m_on_battery = this.m_state.get_bool(state.USING_BATTERY);
            boolean z = util.load_choice(this.m_conf) == 1 && !util.sdk_disabled(true) && !util.sdk_unsupported();
            this.m_should_start = z;
            this.m_should_stop = !z;
            this.m_should_restart = false;
            if (!"android.intent.action.BATTERY_CHANGED".equals(this.m_action)) {
                StringBuilder a3 = a.a("action ");
                a3.append(this.m_action);
                if (this.m_id == null) {
                    str = "";
                } else {
                    StringBuilder a4 = a.a(" ");
                    a4.append(this.m_id);
                    str = a4.toString();
                }
                a3.append(str);
                bcast_recv.zerr(5, a3.toString());
            }
            return true;
        }

        public Object doInBackground(Object[] objArr) {
            try {
                if (before_action()) {
                    do_action();
                    if (this.m_should_stop) {
                        util.stop_svc_thread(this.m_action);
                    } else if (this.m_should_restart) {
                        util.restart_svc_host(this.m_ctx, this.m_action);
                    } else if (this.m_should_start) {
                        util.perr_funnel(conf.FUNNEL_17_BCAST_RECV_SVC_START);
                        util.start_svc_thread(this.m_action);
                    }
                    if (!bcast_recv.m_name.equals(bcast_recv.NAME_SVC)) {
                        util.mem_info mem_info = util.get_mem_info(this.m_ctx);
                        if (mem_info.is_low_memory()) {
                            bcast_recv.zerr(5, mem_info.toString());
                            util.perr(3, "low_memory", true);
                        }
                    }
                    int unused = bcast_recv.zerr(7, "finished", this.m_action);
                    bcast_recv.zerr(7, "shutdown");
                    util.util_uninit();
                    return null;
                }
            } catch (Exception e2) {
                if (!util.is_shutdown(e2)) {
                    int unused2 = bcast_recv.zerr(5, "terminated", this.m_action);
                    util.perr("bcast_recv_exception", Log.getStackTraceString(e2));
                }
            } catch (Throwable th) {
                bcast_recv.zerr(7, "shutdown");
                util.util_uninit();
                throw th;
            }
            bcast_recv.zerr(7, "shutdown");
            util.util_uninit();
            return null;
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void do_action() {
            /*
                r6 = this;
                java.lang.String r0 = r6.m_action
                int r1 = r0.hashCode()
                r2 = 3
                r3 = 0
                r4 = 4
                r5 = 1
                switch(r1) {
                    case -1886648615: goto L_0x005f;
                    case -1514214344: goto L_0x0055;
                    case -1183546688: goto L_0x004a;
                    case -963871873: goto L_0x0040;
                    case -810471698: goto L_0x0036;
                    case -625887599: goto L_0x002c;
                    case 798292259: goto L_0x0022;
                    case 1019184907: goto L_0x0018;
                    case 1737074039: goto L_0x000e;
                    default: goto L_0x000d;
                }
            L_0x000d:
                goto L_0x0069
            L_0x000e:
                java.lang.String r1 = "android.intent.action.MY_PACKAGE_REPLACED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 2
                goto L_0x006a
            L_0x0018:
                java.lang.String r1 = "android.intent.action.ACTION_POWER_CONNECTED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 3
                goto L_0x006a
            L_0x0022:
                java.lang.String r1 = "android.intent.action.BOOT_COMPLETED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 0
                goto L_0x006a
            L_0x002c:
                java.lang.String r1 = "android.intent.action.MEDIA_EJECT"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 6
                goto L_0x006a
            L_0x0036:
                java.lang.String r1 = "android.intent.action.PACKAGE_REPLACED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 1
                goto L_0x006a
            L_0x0040:
                java.lang.String r1 = "android.intent.action.MEDIA_UNMOUNTED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 5
                goto L_0x006a
            L_0x004a:
                java.lang.String r1 = "ACTION_SVC_KEEPALIVE"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 8
                goto L_0x006a
            L_0x0055:
                java.lang.String r1 = "android.intent.action.MEDIA_MOUNTED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 7
                goto L_0x006a
            L_0x005f:
                java.lang.String r1 = "android.intent.action.ACTION_POWER_DISCONNECTED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                r0 = 4
                goto L_0x006a
            L_0x0069:
                r0 = -1
            L_0x006a:
                switch(r0) {
                    case 0: goto L_0x00de;
                    case 1: goto L_0x00bd;
                    case 2: goto L_0x00ba;
                    case 3: goto L_0x00ae;
                    case 4: goto L_0x00a1;
                    case 5: goto L_0x0078;
                    case 6: goto L_0x0078;
                    case 7: goto L_0x0078;
                    case 8: goto L_0x0124;
                    default: goto L_0x006d;
                }
            L_0x006d:
                java.lang.String r0 = io.lum.sdk.util.ACTION_SVC_KEEPALIVE
                java.lang.String r1 = r6.m_action
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x00f4
                return
            L_0x0078:
                java.lang.String r0 = "file://"
                java.lang.StringBuilder r0 = b.a.a.a.a.a(r0)
                io.lum.sdk.conf r1 = r6.m_conf
                io.lum.sdk.conf$key r2 = io.lum.sdk.conf.WORKDIR
                java.lang.String r1 = r1.get_str(r2)
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                android.content.Context r1 = r6.m_ctx
                java.lang.String r1 = io.lum.sdk.util.get_workdir(r1)
                if (r1 == 0) goto L_0x0124
                boolean r0 = r1.equals(r0)
                if (r0 != 0) goto L_0x0124
                android.content.Context r0 = r6.m_ctx
                io.lum.sdk.util.util_reinit_workdir(r0, r1)
                goto L_0x00ba
            L_0x00a1:
                boolean r0 = r6.m_on_battery
                if (r0 != 0) goto L_0x0124
                io.lum.sdk.state r0 = r6.m_state
                io.lum.sdk.state$key r1 = io.lum.sdk.state.USING_BATTERY
                r0.set(r1, (boolean) r5)
                goto L_0x0124
            L_0x00ae:
                boolean r0 = r6.m_on_battery
                if (r0 == 0) goto L_0x0124
                io.lum.sdk.state r0 = r6.m_state
                io.lum.sdk.state$key r1 = io.lum.sdk.state.USING_BATTERY
                r0.set(r1, (boolean) r3)
                goto L_0x0124
            L_0x00ba:
                r6.m_should_restart = r5
                goto L_0x0124
            L_0x00bd:
                java.lang.String r0 = r6.m_id
                if (r0 == 0) goto L_0x00db
                java.lang.String r1 = "package:"
                java.lang.StringBuilder r1 = b.a.a.a.a.a(r1)
                android.content.Context r2 = r6.m_ctx
                java.lang.String r2 = r2.getPackageName()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x00db
                r3 = 1
            L_0x00db:
                r6.m_should_restart = r3
                goto L_0x0124
            L_0x00de:
                android.content.Context r0 = r6.m_ctx
                io.lum.sdk.util.save_mobile_usage_to_sql(r0)
                io.lum.sdk.conf r0 = r6.m_conf
                io.lum.sdk.conf$key r1 = io.lum.sdk.conf.MOBILE_USAGE_SINCE_BOOT
                r2 = 0
                r0.set(r1, (long) r2)
                io.lum.sdk.conf r0 = r6.m_conf
                io.lum.sdk.conf$key r1 = io.lum.sdk.conf.USAGE_SINCE_BOOT_APP
                r0.set(r1, (long) r2)
                goto L_0x0124
            L_0x00f4:
                java.lang.String r0 = io.lum.sdk.util.ACTION_NET_SVC_KEEPALIVE
                java.lang.String r1 = r6.m_action
                boolean r0 = r0.equals(r1)
                if (r0 != 0) goto L_0x0125
                java.lang.String r0 = r6.m_action
                java.lang.String r1 = "ACTION_NET_SVC_KEEPALIVE"
                boolean r0 = r1.equals(r0)
                if (r0 == 0) goto L_0x0109
                goto L_0x0125
            L_0x0109:
                java.lang.String r0 = "unsupported action "
                java.lang.StringBuilder r0 = b.a.a.a.a.a(r0)
                java.lang.String r1 = r6.m_action
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                io.lum.sdk.bcast_recv.zerr(r2, r0)
                java.lang.String r0 = r6.m_action
                java.lang.String r1 = "bcast_recv_unsupported_action"
                java.lang.String r2 = ""
                io.lum.sdk.util.perr((int) r4, (java.lang.String) r1, (java.lang.String) r0, (java.lang.String) r2, (boolean) r5)
            L_0x0124:
                return
            L_0x0125:
                java.lang.String r0 = "net_svc_keepalive"
                io.lum.sdk.util.perr((int) r2, (java.lang.String) r0, (boolean) r5)
                java.lang.String r0 = "restarting svc thread due to keepalive event"
                io.lum.sdk.bcast_recv.zerr(r4, r0)
                io.lum.sdk.conf r0 = r6.m_conf
                io.lum.sdk.conf$key r1 = io.lum.sdk.conf.SVC_THREAD_JAVA_REVIVALS
                int r0 = r0.get_int(r1)
                io.lum.sdk.conf r1 = r6.m_conf
                io.lum.sdk.conf$key r2 = io.lum.sdk.conf.SVC_THREAD_JAVA_REVIVALS
                int r0 = r0 + r5
                r1.set(r2, (int) r0)
                java.lang.String r0 = "keepalive"
                io.lum.sdk.util.restart_svc_thread(r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.bcast_recv.action_task.do_action():void");
        }
    }

    public static int zerr(int i, String str) {
        StringBuilder a2 = a.a("lumsdk/bcast_recv/");
        a2.append(m_name);
        return util._zerr(a2.toString(), i, str);
    }

    public static int zerr(int i, String str, String str2) {
        if ("android.intent.action.BATTERY_CHANGED".equals(str2)) {
            return 0;
        }
        return zerr(i, str + " " + str2);
    }

    public void onReceive(Context context, Intent intent) {
        if (m_state == null) {
            m_state = new state(context);
        }
        new action_task(context, intent).execute(new Object[0]);
    }
}
