package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.HandlerThread;
import d.a.a.f0;
import io.lum.sdk.conf;
import io.lum.sdk.util;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

public class dev_monitor {
    public IntentFilter m_bcast_filter;
    public Handler m_bcast_handler;
    public bcast_recv m_bcast_recv;
    public conf m_conf;
    public conf.listener m_conf_listener;
    public Context m_ctx;
    public final Device_set m_ds;
    public ArrayList<etask> m_etask_on_available = new ArrayList<>();
    public Long m_last_event_ts = 0L;
    public final Object m_locker = new Object();
    public ConnectivityManager.NetworkCallback m_network_cb;
    public util.zerr m_zerr = new util.zerr("dev_monitor");

    public class Device_set {
        public HashMap<String, dev> m_devs = new HashMap<>();

        public Device_set() {
        }

        public synchronized int active_size() {
            int i;
            i = 0;
            for (dev is_up : this.m_devs.values()) {
                if (is_up.is_up()) {
                    i++;
                }
            }
            return i;
        }

        public synchronized void clear() {
            for (dev down : this.m_devs.values()) {
                down.down();
            }
            this.m_devs.clear();
        }

        public synchronized int size() {
            return this.m_devs.values().size();
        }

        public String toString() {
            return this.m_devs.toString();
        }

        public synchronized void update(Context context, dev dev) {
            if (dev != null) {
                if (!this.m_devs.containsKey(dev.m_name)) {
                    this.m_devs.put(dev.m_name, dev);
                } else {
                    this.m_devs.get(dev.m_name).pick_net_info(dev);
                }
            }
            for (dev update : this.m_devs.values()) {
                update.update(context);
            }
        }
    }

    public class bcast_recv extends BroadcastReceiver {
        public bcast_recv() {
        }

        public void onReceive(Context context, Intent intent) {
            dev access$500 = dev_monitor.this.create_active_device();
            dev_monitor.this.m_ds.update(dev_monitor.this.m_ctx, access$500);
            dev_monitor.this.register_event("on_network_connectivity_action", access$500);
        }
    }

    public dev_monitor(final Context context) {
        this.m_ctx = context;
        dev.set_monitor(this);
        this.m_ds = new Device_set();
        create_bcast_recv();
        create_network_cb();
        this.m_conf = new conf(context);
        this.m_conf_listener = new conf.listener() {
            public void on_changed(conf.key key) {
                if (key.equals(conf.DBG_ROAMING)) {
                    dev_monitor.this.m_ds.update(context, (dev) null);
                }
            }
        };
        util.perr_funnel_v(conf.FUNNEL_DEV_00_MONITOR_INIT);
    }

    /* access modifiers changed from: private */
    public dev create_active_device() {
        String str;
        NetworkInfo activeNetworkInfo = util.get_connectivity_manager(this.m_ctx).getActiveNetworkInfo();
        if (activeNetworkInfo == null || !activeNetworkInfo.isConnected() || (str = util.get_current_interface_name()) == null) {
            return null;
        }
        this.m_zerr.notice(String.format("create device: %s (%s)", new Object[]{str, activeNetworkInfo}));
        return dev.create(str, activeNetworkInfo, this.m_ctx);
    }

    private void create_bcast_recv() {
        if (util.has_connectivity_action()) {
            this.m_bcast_recv = new bcast_recv();
            this.m_bcast_filter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            HandlerThread handlerThread = new HandlerThread("dev_mon_bcast_recv_thread");
            handlerThread.start();
            this.m_bcast_handler = new Handler(handlerThread.getLooper());
        }
    }

    @SuppressLint({"NewApi"})
    private void create_devices() {
        if (!util.has_network_callback()) {
            update_device(create_active_device());
            return;
        }
        for (Network create : util.get_connectivity_manager(this.m_ctx).getAllNetworks()) {
            update_device(dev.create(create, this.m_ctx));
        }
    }

    @SuppressLint({"NewApi"})
    private void create_network_cb() {
        if (util.has_network_callback()) {
            this.m_network_cb = new ConnectivityManager.NetworkCallback() {
                public /* synthetic */ void a(Network network) {
                    ConnectivityManager connectivityManager = (ConnectivityManager) dev_monitor.this.m_ctx.getSystemService("connectivity");
                    int i = 0;
                    while (connectivityManager.getNetworkInfo(network) == null && i < 100) {
                        i += 10;
                        try {
                            Thread.sleep((long) i);
                        } catch (InterruptedException unused) {
                            return;
                        }
                    }
                    dev_monitor.this.handle_net_event("network_available", network);
                }

                public void onAvailable(Network network) {
                    dev_monitor.this.m_etask_on_available.add(etask.run((Runnable) new f0(this, network)));
                }

                public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                    dev_monitor.this.handle_net_event("network_capabilities_changed", network, networkCapabilities);
                }

                public void onLinkPropertiesChanged(Network network, LinkProperties linkProperties) {
                    dev_monitor.this.handle_net_event("network_properties_changed", network, linkProperties);
                }

                public void onLosing(Network network, int i) {
                    dev_monitor.this.handle_net_event("network_losing", network);
                }

                public void onLost(Network network) {
                    dev_monitor.this.handle_net_event("network_lost", network);
                }

                public void onUnavailable() {
                    dev_monitor.this.handle_net_event("network_unavailable", (Network) null);
                }
            };
        }
    }

    /* access modifiers changed from: private */
    public void handle_net_event(String str, Network network) {
        handle_net_event(str, network, (Object) null);
    }

    /* access modifiers changed from: private */
    public void handle_net_event(String str, Network network, Object obj) {
        if (network == null) {
            this.m_ds.update(this.m_ctx, (dev) null);
            register_event(str, this.m_ds);
            return;
        }
        dev create = dev.create(network, this.m_ctx);
        this.m_ds.update(this.m_ctx, create);
        register_event(str, create, obj);
    }

    private void register_bcast_recv() {
        if (util.has_connectivity_action()) {
            this.m_ctx.registerReceiver(this.m_bcast_recv, this.m_bcast_filter, (String) null, this.m_bcast_handler);
        }
    }

    /* access modifiers changed from: private */
    public void register_event(String str, Object obj) {
        register_event(str, obj, (Object) null);
    }

    private void register_event(String str, Object obj, Object obj2) {
        synchronized (this.m_last_event_ts) {
            this.m_last_event_ts = Long.valueOf(new Date().getTime());
        }
        String valueOf = String.valueOf(obj);
        if (obj2 != null) {
            valueOf = valueOf + " " + obj2;
        }
        this.m_zerr.notice(String.format("event: %s (%s)", new Object[]{str, valueOf}));
    }

    private void register_network_cb() {
        if (util.has_network_callback()) {
            util.register_network_callback(util.get_connectivity_manager(this.m_ctx), this.m_network_cb);
        }
    }

    private void unregister_bcast_recv() {
        if (util.has_connectivity_action()) {
            try {
                this.m_ctx.unregisterReceiver(this.m_bcast_recv);
            } catch (IllegalArgumentException unused) {
            }
        }
    }

    private void unregister_network_cb() {
        if (util.has_network_callback()) {
            Iterator<etask> it = this.m_etask_on_available.iterator();
            while (it.hasNext()) {
                etask next = it.next();
                util.zerr zerr = this.m_zerr;
                zerr.debug("canceling " + next);
                try {
                    next.cancel();
                } catch (Exception unused) {
                }
            }
            util.unregister_network_callback(util.get_connectivity_manager(this.m_ctx), this.m_network_cb);
        }
    }

    private void update_device(dev dev) {
        this.m_ds.update(this.m_ctx, dev);
    }

    public void force_update() {
        this.m_ds.update(this.m_ctx, (dev) null);
    }

    public int get_active_dev_count() {
        return this.m_ds.active_size();
    }

    public long get_last_event_ts() {
        long longValue;
        synchronized (this.m_last_event_ts) {
            longValue = this.m_last_event_ts.longValue();
        }
        return longValue;
    }

    public boolean has_single_active_interface() {
        return this.m_ds.active_size() == 1;
    }

    public void start() {
        synchronized (this.m_locker) {
            util.perr_funnel_v(conf.FUNNEL_DEV_01_MONITOR_START);
            create_devices();
            register_bcast_recv();
            register_network_cb();
            this.m_conf.register_listener(this.m_conf_listener);
            register_event("start", this.m_ds);
        }
    }

    public void stop() {
        synchronized (this.m_locker) {
            register_event("stop", this.m_ds);
            this.m_conf.unregister_listener(this.m_conf_listener);
            unregister_network_cb();
            unregister_bcast_recv();
            this.m_ds.clear();
            this.m_zerr.notice("stop ok");
        }
    }
}
