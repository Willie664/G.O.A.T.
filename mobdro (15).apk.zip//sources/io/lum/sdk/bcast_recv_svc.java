package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import d.a.a.e;
import d.a.a.f;
import io.lum.sdk.bcast_recv;
import java.util.Timer;
import java.util.TimerTask;

public class bcast_recv_svc extends bcast_recv {
    public static final Object m_on_call_lock = new Object();
    public call_listeners m_call_listeners;
    public Context m_ctx;
    public DisplayManager.DisplayListener m_display_listener;
    public HandlerThread m_display_thread;

    public static class action_task extends bcast_recv.action_task {
        public action_task(Context context, Intent intent) {
            super(context, intent);
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* JADX WARNING: Code restructure failed: missing block: B:49:0x00c3, code lost:
            if (io.lum.sdk.dev_util.TYPE_MOBILE.equals(r0) != false) goto L_0x00c7;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void do_action() {
            /*
                r8 = this;
                java.lang.String r0 = r8.m_action
                int r1 = r0.hashCode()
                r2 = 5
                r3 = 4
                r4 = 3
                r5 = 2
                r6 = 0
                r7 = 1
                switch(r1) {
                    case -2128145023: goto L_0x0042;
                    case -1538406691: goto L_0x0038;
                    case -1454123155: goto L_0x002e;
                    case -1172645946: goto L_0x0024;
                    case 823795052: goto L_0x001a;
                    case 1947666138: goto L_0x0010;
                    default: goto L_0x000f;
                }
            L_0x000f:
                goto L_0x004c
            L_0x0010:
                java.lang.String r1 = "android.intent.action.ACTION_SHUTDOWN"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 0
                goto L_0x004d
            L_0x001a:
                java.lang.String r1 = "android.intent.action.USER_PRESENT"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 3
                goto L_0x004d
            L_0x0024:
                java.lang.String r1 = "android.net.conn.CONNECTIVITY_CHANGE"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 4
                goto L_0x004d
            L_0x002e:
                java.lang.String r1 = "android.intent.action.SCREEN_ON"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 2
                goto L_0x004d
            L_0x0038:
                java.lang.String r1 = "android.intent.action.BATTERY_CHANGED"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 5
                goto L_0x004d
            L_0x0042:
                java.lang.String r1 = "android.intent.action.SCREEN_OFF"
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x004c
                r0 = 1
                goto L_0x004d
            L_0x004c:
                r0 = -1
            L_0x004d:
                if (r0 == 0) goto L_0x00e6
                if (r0 == r7) goto L_0x00e0
                if (r0 == r5) goto L_0x00e0
                if (r0 == r4) goto L_0x00e0
                if (r0 == r3) goto L_0x009d
                if (r0 == r2) goto L_0x0095
                java.lang.String r0 = io.lum.sdk.util.ACTION_DISPLAY_CHANGE
                java.lang.String r1 = r8.m_action
                boolean r0 = r0.equals(r1)
                if (r0 == 0) goto L_0x0069
                io.lum.sdk.state r0 = r8.m_state
                r0.update_screen_state()
                return
            L_0x0069:
                int r0 = io.lum.sdk.util.sdk_version()
                r1 = 17
                if (r0 < r1) goto L_0x0091
                java.lang.String r0 = r8.m_action
                java.lang.String r1 = "android.intent.action.DREAMING_STARTED"
                boolean r0 = r1.equals(r0)
                if (r0 == 0) goto L_0x0081
                io.lum.sdk.state r0 = r8.m_state
                r0.update_screen_state(r7)
                return
            L_0x0081:
                java.lang.String r0 = r8.m_action
                java.lang.String r1 = "android.intent.action.DREAMING_STOPPED"
                boolean r0 = r1.equals(r0)
                if (r0 == 0) goto L_0x0091
                io.lum.sdk.state r0 = r8.m_state
                r0.update_screen_state()
                return
            L_0x0091:
                super.do_action()
                goto L_0x00ed
            L_0x0095:
                io.lum.sdk.state r0 = r8.m_state
                android.content.Intent r1 = r8.m_intent
                r0.update_battery_level((android.content.Intent) r1)
                goto L_0x00ed
            L_0x009d:
                android.content.Context r0 = r8.m_ctx
                java.lang.String r1 = "connectivity"
                java.lang.Object r0 = r0.getSystemService(r1)
                android.net.ConnectivityManager r0 = (android.net.ConnectivityManager) r0
                android.net.NetworkInfo r0 = r0.getActiveNetworkInfo()
                if (r0 == 0) goto L_0x00c6
                android.content.Context r1 = r8.m_ctx
                java.lang.String r0 = io.lum.sdk.dev_util.get_type((android.net.NetworkInfo) r0, (android.content.Context) r1)
                java.lang.String r1 = "wl"
                boolean r1 = r1.equals(r0)
                if (r1 == 0) goto L_0x00bd
                r6 = 1
                goto L_0x00c6
            L_0x00bd:
                java.lang.String r1 = "3g"
                boolean r0 = r1.equals(r0)
                if (r0 == 0) goto L_0x00c6
                goto L_0x00c7
            L_0x00c6:
                r7 = 0
            L_0x00c7:
                io.lum.sdk.state r0 = r8.m_state
                io.lum.sdk.state$key r1 = io.lum.sdk.state.WIFI_CONNECTED
                r0.set(r1, (boolean) r6)
                io.lum.sdk.state r0 = r8.m_state
                io.lum.sdk.state$key r1 = io.lum.sdk.state.MOBILE_CONNECTED
                r0.set(r1, (boolean) r7)
                android.content.Context r0 = r8.m_ctx
                io.lum.sdk.util.log_mobile_usage(r0)
                android.content.Context r0 = r8.m_ctx
                io.lum.sdk.util.is_online(r0)
                goto L_0x00ed
            L_0x00e0:
                io.lum.sdk.state r0 = r8.m_state
                r0.update_screen_state()
                goto L_0x00ed
            L_0x00e6:
                android.content.Context r0 = r8.m_ctx
                io.lum.sdk.util.log_mobile_usage(r0)
                r8.m_should_stop = r7
            L_0x00ed:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.bcast_recv_svc.action_task.do_action():void");
        }
    }

    public class call_listeners {
        public final int m_call_duration_max = util.MS_HOUR;
        public Timer m_call_timer;
        public AudioManager.OnAudioFocusChangeListener m_focus_listener;
        public AudioManager m_manager;
        public final int m_restart_ms = 30000;

        public call_listeners() {
            bcast_recv.zerr(5, "call_listeners init");
            this.m_manager = (AudioManager) bcast_recv_svc.this.m_ctx.getSystemService("audio");
            this.m_focus_listener = new f(this);
        }

        /* access modifiers changed from: private */
        public void on_focus_change(int i) {
            bcast_recv.zerr(5, "call_listeners on_focus_change: " + i);
            if (i == -2) {
                int mode = this.m_manager.getMode();
                bcast_recv.zerr(5, "call_listeners focus loss mode: " + mode);
                if (mode > 0) {
                    bcast_recv_svc.set_on_call(bcast_recv_svc.this.m_ctx, true, "call_listeners.on_focus_change");
                    Timer timer = new Timer();
                    this.m_call_timer = timer;
                    timer.schedule(new TimerTask() {
                        public void run() {
                            util.perr(3, "long_call", "duration: 3600000", "", true);
                            call_listeners.this.restart();
                        }
                    }, 3600000);
                }
            } else if (i == 1) {
                bcast_recv_svc.set_on_call(bcast_recv_svc.this.m_ctx, false, "call_listeners.on_focus_change");
                Timer timer2 = this.m_call_timer;
                if (timer2 != null) {
                    timer2.cancel();
                    this.m_call_timer = null;
                }
            }
        }

        /* access modifiers changed from: private */
        public void restart() {
            stop();
            new Timer().schedule(new TimerTask() {
                public void run() {
                    try {
                        call_listeners.this.start();
                    } catch (Exception unused) {
                    }
                }
            }, 30000);
        }

        public synchronized void start() {
            int requestAudioFocus = this.m_manager.requestAudioFocus(this.m_focus_listener, 0, 1);
            if (requestAudioFocus != 1) {
                bcast_recv.zerr(4, "call_listeners start fail: " + requestAudioFocus);
            } else {
                bcast_recv.zerr(5, "call_listeners start");
                bcast_recv_svc.set_on_call(bcast_recv_svc.this.m_ctx, false, "call_listeners.start");
            }
        }

        public synchronized void stop() {
            try {
                this.m_manager.abandonAudioFocus(this.m_focus_listener);
            } catch (Exception unused) {
            }
            bcast_recv.zerr(5, "call_listeners stop");
        }
    }

    @SuppressLint({"InlinedApi"})
    public bcast_recv_svc(Context context) {
        this.m_ctx = context.getApplicationContext();
        bcast_recv.m_name = bcast_recv.NAME_SVC;
        register_display_listener();
        if (!util.is_tv(context)) {
            if (util.sdk_version() < 23) {
                call_listeners call_listeners2 = new call_listeners();
                this.m_call_listeners = call_listeners2;
                call_listeners2.start();
            } else {
                register_phone_state_listener();
            }
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
        intentFilter.addAction("android.intent.action.ACTION_POWER_DISCONNECTED");
        intentFilter.addAction("android.intent.action.ACTION_SHUTDOWN");
        intentFilter.addAction("android.intent.action.SCREEN_ON");
        intentFilter.addAction("android.intent.action.SCREEN_OFF");
        intentFilter.addAction("android.intent.action.USER_PRESENT");
        intentFilter.addAction("android.intent.action.NEW_OUTGOING_CALL");
        intentFilter.addAction("android.intent.action.BATTERY_CHANGED");
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        if (util.sdk_version() >= 17) {
            intentFilter.addAction("android.intent.action.DREAMING_STARTED");
            intentFilter.addAction("android.intent.action.DREAMING_STOPPED");
        }
        HandlerThread handlerThread = new HandlerThread("bcast_recv_thread");
        handlerThread.start();
        this.m_ctx.registerReceiver(this, intentFilter, (String) null, new Handler(handlerThread.getLooper()));
    }

    public static boolean get_on_call(Context context) {
        boolean z;
        synchronized (m_on_call_lock) {
            z = new state(context).get_bool(state.ON_CALL);
        }
        return z;
    }

    public static void on_call_state_changed(Context context, int i) {
        boolean z = false;
        bcast_recv.zerr(5, String.format("on_call: PHONE_STATE_CHANGED: %s, prev: %s", new Object[]{Integer.valueOf(i), Boolean.valueOf(get_on_call(context))}));
        if (i == 2) {
            z = true;
        }
        set_on_call(context, z, "android.intent.action.PHONE_STATE");
    }

    private void register_phone_state_listener() {
        new Handler(this.m_ctx.getMainLooper()).post(new e(this));
    }

    public static void set_on_call(Context context, boolean z, String str) {
        synchronized (m_on_call_lock) {
            boolean z2 = get_on_call(context);
            if (z2 != z) {
                String format = String.format("set on_call: %s -> %s (%s)", new Object[]{Boolean.valueOf(z2), Boolean.valueOf(z), str});
                bcast_recv.zerr(5, format);
                new state(context).set(state.ON_CALL, z);
                StringBuilder sb = new StringBuilder();
                sb.append("call_listeners_");
                sb.append(z ? "on_call" : "not_on_call");
                util.perr(5, sb.toString(), format, "", true);
            }
        }
    }

    public /* synthetic */ void a() {
        ((TelephonyManager) this.m_ctx.getSystemService("phone")).listen(new PhoneStateListener() {
            public void onCallStateChanged(int i, String str) {
                super.onCallStateChanged(i, str);
                bcast_recv_svc.on_call_state_changed(bcast_recv_svc.this.m_ctx, i);
            }
        }, 32);
    }

    public void destroy() {
        call_listeners call_listeners2;
        this.m_ctx.unregisterReceiver(this);
        unregister_display_listener();
        if (!util.is_tv(this.m_ctx) && (call_listeners2 = this.m_call_listeners) != null) {
            call_listeners2.stop();
        }
    }

    public void onReceive(Context context, Intent intent) {
        new action_task(context, intent).execute(new Object[0]);
    }

    @SuppressLint({"NewApi"})
    public void register_display_listener() {
        if (this.m_display_listener == null && Build.VERSION.SDK_INT >= 20) {
            this.m_display_listener = new DisplayManager.DisplayListener() {
                public void onDisplayAdded(int i) {
                }

                public void onDisplayChanged(int i) {
                    bcast_recv_svc bcast_recv_svc = bcast_recv_svc.this;
                    bcast_recv_svc.onReceive(bcast_recv_svc.m_ctx, new Intent(util.ACTION_DISPLAY_CHANGE));
                }

                public void onDisplayRemoved(int i) {
                }
            };
            HandlerThread handlerThread = new HandlerThread("display_state_listener");
            this.m_display_thread = handlerThread;
            handlerThread.start();
            ((DisplayManager) this.m_ctx.getSystemService("display")).registerDisplayListener(this.m_display_listener, new Handler(this.m_display_thread.getLooper()));
        }
    }

    @SuppressLint({"NewApi"})
    public void unregister_display_listener() {
        if (this.m_display_listener != null) {
            ((DisplayManager) this.m_ctx.getSystemService("display")).unregisterDisplayListener(this.m_display_listener);
            this.m_display_thread.quit();
            this.m_display_listener = null;
        }
    }
}
