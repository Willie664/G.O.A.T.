package io.lum.sdk;

import android.text.TextUtils;
import b.a.a.a.a;
import io.lum.sdk.util;
import java.util.ArrayList;

public class sdk_proxy_pool {
    public static volatile sdk_proxy_pool m_instance;
    public final String DOMAIN = "proxy_domain";
    public final String HOST = "proxy_host";
    public final String PORT = "proxy_port";
    public ArrayList<String> m_domains;
    public ArrayList<String> m_ips;
    public option_pool m_options;
    public ArrayList<Integer> m_ports;
    public boolean m_ssl;
    public util.zerr m_zerr;

    public sdk_proxy_pool(boolean z) {
        this.m_ssl = z;
        String simpleName = sdk_proxy_pool.class.getSimpleName();
        this.m_zerr = new util.zerr(simpleName);
        option_pool option_pool = new option_pool(simpleName);
        this.m_options = option_pool;
        this.m_ips = zon_conf.ZAGENT_IPS;
        this.m_ports = zon_conf.ZAGENT_PORTS;
        ArrayList<String> arrayList = zon_conf.ZAGENT_DOMAINS;
        this.m_domains = arrayList;
        if (this.m_ssl) {
            this.m_ips = zon_conf.ZAGENT_IPS_SSL;
            this.m_ports = zon_conf.ZAGENT_PORTS_SSL;
            option_pool.add(option_pool.strings("proxy_domain", arrayList, conf.CACHE_SPROXY_DOMAIN, conf.CACHE_SPROXY_DOMAIN_TS, conf.CACHE_SPROXY_DOMAIN_TTL, 86400000, false));
        }
        validate();
        this.m_options.add(option_pool.strings("proxy_host", this.m_ips, conf.CACHE_SPROXY_HOST, conf.CACHE_SPROXY_HOST_TS, conf.CACHE_SPROXY_HOST_TTL, 1800000, true)).add(option_pool.numbers("proxy_port", this.m_ports, conf.CACHE_SPROXY_PORT, conf.CACHE_SPROXY_PORT_TS, conf.CACHE_SPROXY_PORT_TTL, 0, false));
    }

    private synchronized int get_current_port() {
        return ((Integer) this.m_options.get_current("proxy_port")).intValue();
    }

    public static sdk_proxy_pool get_instance(boolean z) {
        if (m_instance == null) {
            m_instance = new sdk_proxy_pool(z);
        }
        return m_instance;
    }

    private void validate() {
        if (this.m_ips.isEmpty()) {
            StringBuilder a2 = a.a("ssl=");
            a2.append(this.m_ssl);
            util.perr(3, "sdk_proxy_pool_ips_empty", (Object) a2.toString(), true);
            this.m_ips.add(this.m_ssl ? "157.230.51.192" : "106.2.11.89");
        }
        if (this.m_ports.isEmpty()) {
            StringBuilder a3 = a.a("ssl=");
            a3.append(this.m_ssl);
            util.perr(3, "sdk_proxy_pool_ports_empty", (Object) a3.toString(), true);
            this.m_ports.add(Integer.valueOf(this.m_ssl ? 80 : 22222));
        }
        if (this.m_domains.isEmpty()) {
            StringBuilder a4 = a.a("ssl=");
            a4.append(this.m_ssl);
            util.perr(3, "sdk_proxy_pool_domains_empty", (Object) a4.toString(), true);
            this.m_domains.add("l-cdn.com");
        }
    }

    public synchronized boolean failure(String str) {
        String format;
        util.zerr zerr = this.m_zerr;
        zerr.notice("failure: " + get_details() + " " + str);
        this.m_options.next();
        if (this.m_ssl) {
            util.perr(5, "proxy_failure_ssl", str, get_details(), true);
            util.perr(5, "proxy_failure_ssl_" + str, (Object) get_details(), true);
            format = String.format("proxy_failure_ssl_%s_port_%s", new Object[]{str, Integer.valueOf(get_current_port())});
        } else {
            util.perr(5, "proxy_failure", str, get_details(), true);
            util.perr(5, "proxy_failure_" + str, (Object) get_details(), true);
            format = String.format("proxy_failure_%s_port_%s", new Object[]{str, Integer.valueOf(get_current_port())});
        }
        util.perr(5, format, true);
        return true;
    }

    public synchronized String get_details() {
        return this.m_options.get_details();
    }

    public synchronized String get_domain() {
        if (!this.m_ssl) {
            return null;
        }
        String str = (String) this.m_options.get_current("proxy_domain");
        if (str == null) {
            util.perr(3, "sdk_proxy_pool_domain_null", (Object) "ssl=" + this.m_ssl, true);
            str = this.m_domains.get(0);
        }
        String str2 = (String) this.m_options.get_current("proxy_host");
        if (str2 == null) {
            util.perr(3, "sdk_proxy_pool_domain_host_null", (Object) "ssl=" + this.m_ssl, true);
            str2 = this.m_ips.get(0);
        }
        return util.get_ssl_servername(TextUtils.join(".", new String[]{str2.replace(".", "-"), str}), conf.SPROXY_SSL_HOST, zon_conf.SPROXY_SSL_HOST);
    }

    public synchronized String get_host() {
        String str;
        str = (String) this.m_options.get("proxy_host");
        if (str == null) {
            util.perr(3, "sdk_proxy_pool_host_null", (Object) "ssl=" + this.m_ssl, true);
            str = this.m_ips.get(0);
        }
        return str;
    }

    public synchronized int get_port() {
        Integer num;
        num = (Integer) this.m_options.get("proxy_port");
        if (num == null) {
            util.perr(3, "sdk_proxy_pool_port_null", (Object) "ssl=" + this.m_ssl, true);
            num = this.m_ports.get(0);
        }
        return num.intValue();
    }

    public synchronized boolean get_ssl() {
        return this.m_ssl;
    }

    public synchronized void success(String str) {
        String format;
        if (this.m_options.save()) {
            util.zerr zerr = this.m_zerr;
            zerr.notice("success: " + get_details() + " " + str);
            if (this.m_ssl) {
                util.perr(5, "proxy_success_ssl", str, get_details(), true);
                util.perr(5, "proxy_success_ssl_" + str, (Object) get_details(), true);
                format = String.format("proxy_success_ssl_%s_port_%s", new Object[]{str, Integer.valueOf(get_current_port())});
            } else {
                util.perr(5, "proxy_success", str, get_details(), true);
                util.perr(5, "proxy_success_" + str, (Object) get_details(), true);
                format = String.format("proxy_success_%s_port_%s", new Object[]{str, Integer.valueOf(get_current_port())});
            }
            util.perr(5, format, true);
        }
    }
}
