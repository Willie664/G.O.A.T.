package io.lum.sdk;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.text.Html;
import android.text.Spannable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import b.a.a.a.a;
import d.a.a.m0;
import d.a.a.n0;
import d.a.a.o0;
import io.lum.sdk.api;
import org.json.JSONException;
import org.json.JSONObject;

public class peer_dialog extends DialogFragment {
    public static final String TAG = "lum_sdk_popup";
    public static int m_app_icon = 0;
    public static volatile String m_app_name = "";
    public static volatile int m_app_name_color = 0;
    public static volatile int m_bg_color = 0;
    public static volatile int m_btn_color = 0;
    public static volatile api.BTN_NOT_PEER_TXT m_btn_not_peer_txt = api.BTN_NOT_PEER_TXT.ADS;
    public static volatile api.BTN_PEER_TXT m_btn_peer_txt = api.BTN_PEER_TXT.I_AGREE;
    public static volatile int m_btn_txt_not_peer_color = 0;
    public static volatile int m_btn_txt_peer_color = 0;
    public static volatile Typeface m_font = null;
    public static volatile peer_dialog_dissmiss m_pdd = null;
    public static volatile boolean m_take_screenshot = false;
    public static volatile String m_tos_link = "";
    public static volatile int m_txt_color;
    public static volatile api.DIALOG_TYPE m_type;
    public long m_display_ms = 0;
    public final int m_layout_id = R.layout.lumsdk_peer_03_2019;
    public boolean m_no_vendor = false;
    public int m_radio_choice = 0;
    public float m_screen_density;
    public float m_screen_height;
    public String m_screen_orientation;
    public float m_screen_width;

    /* renamed from: io.lum.sdk.peer_dialog$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT;

        /* JADX WARNING: Can't wrap try/catch for region: R(20:0|(2:1|2)|3|5|6|7|8|9|11|12|13|(2:15|16)|17|(2:19|20)|21|23|24|25|26|28) */
        /* JADX WARNING: Can't wrap try/catch for region: R(23:0|1|2|3|5|6|7|8|9|11|12|13|15|16|17|19|20|21|23|24|25|26|28) */
        /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0039 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0016 */
        static {
            /*
                io.lum.sdk.api$BTN_NOT_PEER_TXT[] r0 = io.lum.sdk.api.BTN_NOT_PEER_TXT.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT = r0
                r1 = 1
                io.lum.sdk.api$BTN_NOT_PEER_TXT r2 = io.lum.sdk.api.BTN_NOT_PEER_TXT.ADS     // Catch:{ NoSuchFieldError -> 0x000f }
                r2 = 0
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x000f }
            L_0x000f:
                r0 = 2
                int[] r2 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x0016 }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r3 = io.lum.sdk.api.BTN_NOT_PEER_TXT.LIMITED     // Catch:{ NoSuchFieldError -> 0x0016 }
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0016 }
            L_0x0016:
                int[] r1 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x001d }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r2 = io.lum.sdk.api.BTN_NOT_PEER_TXT.NO_DONATE     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 3
                r1[r2] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r1 = 4
                int[] r2 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x0024 }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r3 = io.lum.sdk.api.BTN_NOT_PEER_TXT.PREMIUM     // Catch:{ NoSuchFieldError -> 0x0024 }
                r2[r0] = r1     // Catch:{ NoSuchFieldError -> 0x0024 }
            L_0x0024:
                r0 = 5
                int[] r2 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x002b }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r3 = io.lum.sdk.api.BTN_NOT_PEER_TXT.NOT_AGREE     // Catch:{ NoSuchFieldError -> 0x002b }
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x002b }
            L_0x002b:
                r1 = 6
                int[] r2 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x0032 }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r3 = io.lum.sdk.api.BTN_NOT_PEER_TXT.I_DISAGREE     // Catch:{ NoSuchFieldError -> 0x0032 }
                r2[r0] = r1     // Catch:{ NoSuchFieldError -> 0x0032 }
            L_0x0032:
                r0 = 7
                int[] r2 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x0039 }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r3 = io.lum.sdk.api.BTN_NOT_PEER_TXT.SUBSCRIPTION     // Catch:{ NoSuchFieldError -> 0x0039 }
                r2[r1] = r0     // Catch:{ NoSuchFieldError -> 0x0039 }
            L_0x0039:
                int[] r1 = $SwitchMap$io$lum$sdk$api$BTN_NOT_PEER_TXT     // Catch:{ NoSuchFieldError -> 0x0041 }
                io.lum.sdk.api$BTN_NOT_PEER_TXT r2 = io.lum.sdk.api.BTN_NOT_PEER_TXT.PAY     // Catch:{ NoSuchFieldError -> 0x0041 }
                r2 = 8
                r1[r0] = r2     // Catch:{ NoSuchFieldError -> 0x0041 }
            L_0x0041:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.peer_dialog.AnonymousClass1.<clinit>():void");
        }
    }

    public interface peer_dialog_dissmiss {
        void on_peer_dailog_dismiss(int i);
    }

    private void build_hyperlink(TextView textView, String str) {
        textView.setText((Spannable) Html.fromHtml("<a href=" + str + ">" + textView.getText() + "</a>"));
        textView.setOnClickListener(new m0(this, str));
    }

    private int[] get_colored_text_view_ids() {
        return new int[]{R.id.lumsdk_peer_msg_1, R.id.lumsdk_peer_msg_2, R.id.lumsdk_peer_msg_3_1, R.id.lumsdk_peer_msg_3_2_1, R.id.lumsdk_peer_msg_3_2_2, R.id.lumsdk_peer_msg_3_3, R.id.lumsdk_peer_msg_4_1, R.id.lumsdk_peer_msg_4_2, R.id.lumsdk_peer_msg_4_3, R.id.more_top, R.id.more_bottom, R.id.tos};
    }

    private int get_not_peer_txt() {
        if (util.is_blacklisted()) {
            return R.string.lumsdk_disagree;
        }
        int i = R.string.lumsdk_free;
        switch (m_btn_not_peer_txt.ordinal()) {
            case 0:
                return R.string.lumsdk_prefer_ads;
            case 1:
                return R.string.lumsdk_limited;
            case 2:
                return R.string.lumsdk_premium;
            case 3:
                return R.string.lumsdk_no_donate;
            case 4:
                return R.string.lumsdk_i_dont_agree;
            case 5:
                return R.string.lumsdk_i_disagree;
            case 6:
                return R.string.lumsdk_subscription;
            case 7:
                return R.string.lumsdk_pay;
            default:
                return i;
        }
    }

    private int get_peer_txt() {
        return R.string.lumsdk_i_agree;
    }

    private void get_screen_metrics() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.m_screen_density = displayMetrics.density;
        this.m_screen_width = (float) displayMetrics.widthPixels;
        this.m_screen_height = (float) displayMetrics.heightPixels;
        this.m_screen_orientation = getResources().getConfiguration().orientation == 1 ? "portrait" : "landscape";
        StringBuilder a2 = a.a("screen_dimensions_");
        a2.append(this.m_screen_orientation);
        String sb = a2.toString();
        StringBuilder a3 = a.a("width: ");
        a3.append(this.m_screen_width);
        a3.append(", height: ");
        a3.append(this.m_screen_height);
        a3.append(", density: ");
        a3.append(this.m_screen_density);
        util.perr(3, sb, a3.toString(), "", true);
    }

    private int[] get_text_view_ids() {
        return new int[]{R.id.lumsdk_peer_msg_1, R.id.lumsdk_peer_msg_2, R.id.lumsdk_peer_msg_3_1, R.id.lumsdk_peer_msg_3_2_1, R.id.lumsdk_peer_msg_3_2_2, R.id.lumsdk_peer_msg_3_3, R.id.lumsdk_peer_msg_4_1, R.id.lumsdk_peer_msg_4_2, R.id.lumsdk_peer_msg_4_3, R.id.main_peer, R.id.lumsdk_sub_peer, R.id.main_not_peer};
    }

    private void init(View view) {
        int i;
        if (m_type == api.DIALOG_TYPE.PEER1) {
            get_screen_metrics();
            Resources resources = getResources();
            ((TextView) view.findViewById(R.id.app_name)).setText(m_app_name);
            ((ImageView) view.findViewById(R.id.app_icon)).setImageResource(m_app_icon);
            view.findViewById(R.id.lumsdk_bg).setBackgroundColor(m_bg_color);
            ((TextView) view.findViewById(R.id.lumsdk_peer_msg_2)).setText((Spannable) Html.fromHtml(String.format("<span>%s <b>%s</b> %s</span>", new Object[]{resources.getString(R.string.lumsdk_peer_msg_2_1), resources.getString(R.string.lumsdk_peer_msg_2_2), resources.getString(R.string.lumsdk_peer_msg_2_3)})));
            ((TextView) view.findViewById(R.id.main_peer)).setText(get_peer_txt());
            ((TextView) view.findViewById(R.id.main_not_peer)).setText(get_not_peer_txt());
            if (this.m_no_vendor) {
                i = util.is_blacklisted() ? R.string.lumsdk_peer_msg_1b_no_vendor : R.string.lumsdk_peer_msg_1_no_vendor;
                ((TextView) view.findViewById(R.id.lumsdk_network_label_2)).setText(resources.getString(R.string.lumsdk_network_txt_2_no_vendor));
                int[] iArr = {R.id.more_bottom};
                for (int i2 = 0; i2 < 1; i2++) {
                    ((TextView) view.findViewById(iArr[i2])).setText("");
                }
            } else {
                i = util.is_blacklisted() ? R.string.lumsdk_peer_msg_1b : R.string.lumsdk_peer_msg_1;
            }
            ((TextView) view.findViewById(R.id.lumsdk_peer_msg_1)).setText(String.format(resources.getString(i), new Object[]{m_app_name}));
            build_hyperlink((TextView) view.findViewById(R.id.tos), m_tos_link);
            build_hyperlink((TextView) view.findViewById(R.id.more_top), resources.getString(R.string.lumsdk_more_top_url));
            if (!this.m_no_vendor) {
                build_hyperlink((TextView) view.findViewById(R.id.more_bottom), resources.getString(R.string.lumsdk_more_bottom_url));
            }
            int[] iArr2 = get_colored_text_view_ids();
            int length = iArr2.length;
            for (int i3 = 0; i3 < length; i3++) {
                int i4 = iArr2[i3];
                set_text_size(view, Integer.valueOf(i4), i4 == R.id.lumsdk_peer_msg_3_2_2);
                set_text_color(view, Integer.valueOf(i4), m_txt_color);
            }
            set_text_color(view, Integer.valueOf(R.id.app_name), m_app_name_color);
            set_text_color(view, Integer.valueOf(R.id.main_peer), m_btn_txt_peer_color);
            set_text_color(view, Integer.valueOf(R.id.main_not_peer), m_btn_txt_not_peer_color);
            if (m_btn_color != 0) {
                set_btn_peer_bg(view, R.id.btn_peer, m_btn_color);
                set_btn_not_peer_bg(view, R.id.btn_not_peer, m_btn_color);
                set_btn_not_peer_bg(view, R.id.tos, m_btn_color);
            }
            if (m_font != null) {
                for (int valueOf : get_text_view_ids()) {
                    set_text_font(view, Integer.valueOf(valueOf), m_font);
                }
            }
            view.findViewById(R.id.btn_peer).setOnClickListener(new o0(this));
            view.findViewById(R.id.btn_not_peer).setOnClickListener(new n0(this));
        }
    }

    private void open_browser(String str) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    private void set_btn_not_peer_bg(View view, int i, int i2) {
        try {
            Drawable[] children = ((DrawableContainer.DrawableContainerState) ((StateListDrawable) view.findViewById(i).getBackground()).getConstantState()).getChildren();
            int dp_to_px = util.dp_to_px(view.getContext(), 1);
            ((GradientDrawable) children[0]).setStroke(dp_to_px, i2);
            ((GradientDrawable) children[1]).setStroke(dp_to_px, i2);
        } catch (Exception e2) {
            util.perr("set_btn_colors_err", e2.getMessage());
        }
    }

    private void set_btn_peer_bg(View view, int i, int i2) {
        try {
            Drawable[] children = ((DrawableContainer.DrawableContainerState) ((StateListDrawable) view.findViewById(i).getBackground()).getConstantState()).getChildren();
            ((GradientDrawable) children[2]).setColor(i2);
            ((GradientDrawable) children[1]).setColor(i2);
        } catch (Exception e2) {
            util.perr("set_btn_colors_err", e2.getMessage());
        }
    }

    private void set_text_color(View view, Integer num, int i) {
        TextView textView = (TextView) view.findViewById(num.intValue());
        if (textView != null) {
            textView.setTextColor(i);
        }
    }

    private void set_text_font(View view, Integer num, Typeface typeface) {
        TextView textView = (TextView) view.findViewById(num.intValue());
        if (textView != null) {
            textView.setTypeface(typeface);
        }
    }

    private void set_text_size(View view, Integer num, boolean z) {
        TextView textView = (TextView) view.findViewById(num.intValue());
        if (textView != null) {
            float floor = (float) Math.floor((double) textView.getTextSize());
            float floor2 = (float) Math.floor((double) (this.m_screen_width / floor));
            double d2 = 28.0d;
            if (!this.m_screen_orientation.equals("portrait")) {
                double d3 = (double) (this.m_screen_height / this.m_screen_width);
                Double.isNaN(d3);
                double d4 = (double) 56;
                Double.isNaN(d4);
                d2 = d4 / (d3 / 0.5357d);
            }
            double d5 = 0.75d;
            if (!z) {
                d5 = 1.0d;
            }
            double d6 = (double) this.m_screen_width;
            Double.isNaN(d6);
            float floor3 = (float) Math.floor((d6 / d2) * d5);
            if (util.is_tv((Context) null)) {
                double d7 = (double) floor3;
                Double.isNaN(d7);
                floor3 = (float) (d7 * 0.8d);
            }
            textView.setTextSize(floor3 / this.m_screen_density);
            StringBuilder sb = new StringBuilder();
            sb.append("popup_text_transform");
            sb.append(z ? "_small" : "");
            sb.append("_");
            sb.append(this.m_screen_orientation);
            String sb2 = sb.toString();
            util._zerr("lumsdk/peer_dialog", 7, sb2 + ": " + floor + "/" + floor2 + " -> " + floor3 + "/" + Math.floor(d2));
        }
    }

    public /* synthetic */ void a(View view) {
        util.perr_funnel(conf.FUNNEL_04_DIALOG_CHOSE_PEER);
        String valueOf = String.valueOf(System.currentTimeMillis() - this.m_display_ms);
        util.perr("user_chose_peer", valueOf);
        try {
            util.perr("popup_close", new JSONObject().put("close2", true).put("ms", valueOf).toString());
        } catch (JSONException unused) {
        }
        this.m_radio_choice = 1;
        dismiss();
    }

    public /* synthetic */ void a(String str, View view) {
        open_browser(str);
    }

    public /* synthetic */ void b(View view) {
        String valueOf = String.valueOf(System.currentTimeMillis() - this.m_display_ms);
        util.perr("user_chose_not_peer", valueOf);
        try {
            util.perr("popup_close", new JSONObject().put("ms", valueOf).toString());
        } catch (JSONException unused) {
        }
        this.m_radio_choice = 4;
        dismiss();
    }

    public void dismiss() {
        if (m_take_screenshot) {
            Activity activity = getActivity();
            StringBuilder a2 = a.a("popup_");
            a2.append(this.m_screen_orientation);
            util.take_screenshot(activity, a2.toString(), getDialog().getWindow());
        }
        super.dismiss();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (m_type == api.DIALOG_TYPE.PEER1) {
            View inflate = ((LayoutInflater) getActivity().getApplicationContext().getSystemService("layout_inflater")).inflate(this.m_layout_id, (ViewGroup) null);
            ViewGroup viewGroup = (ViewGroup) getView();
            viewGroup.removeAllViews();
            viewGroup.addView(inflate);
            init(inflate);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (bundle == null) {
            Activity activity = getActivity();
            conf conf = new conf(activity.getApplicationContext());
            String packageName = activity.getPackageName();
            m_take_screenshot = util.is_test_app(packageName) || conf.get_bool(conf.TAKE_POPUP_SCREENSHOT, true);
            try {
                PackageManager packageManager = getActivity().getPackageManager();
                ApplicationInfo applicationInfo = packageManager.getPackageInfo(packageName, 0).applicationInfo;
                m_app_name = applicationInfo.loadLabel(packageManager).toString();
                m_app_icon = applicationInfo.icon;
            } catch (PackageManager.NameNotFoundException unused) {
            }
        }
        Dialog onCreateDialog = super.onCreateDialog(bundle);
        Window window = onCreateDialog.getWindow();
        if (window != null) {
            window.requestFeature(1);
        }
        return onCreateDialog;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        View inflate = layoutInflater.inflate(this.m_layout_id, viewGroup, false);
        init(inflate);
        return inflate;
    }

    public void onDestroyView() {
        try {
            Dialog dialog = getDialog();
            if (dialog != null && getRetainInstance()) {
                dialog.setDismissMessage((Message) null);
            }
        } catch (Exception unused) {
        }
        super.onDestroyView();
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (m_pdd != null && this.m_radio_choice > 0) {
            m_pdd.on_peer_dailog_dismiss(this.m_radio_choice);
        }
        super.onDismiss(dialogInterface);
    }

    public void onStart() {
        super.onStart();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        getDialog().getWindow().setLayout(-1, -1);
    }

    public void set_btn_not_peer_txt(api.BTN_NOT_PEER_TXT btn_not_peer_txt) {
        m_btn_not_peer_txt = btn_not_peer_txt;
    }

    public void set_colors(int i, int i2, int i3, int i4, int i5, int i6) {
        m_bg_color = i;
        m_btn_color = i2;
        m_app_name_color = i4;
        m_txt_color = i3;
        m_btn_txt_peer_color = i5;
        m_btn_txt_not_peer_color = i6;
    }

    public void set_dialog(api.DIALOG_TYPE dialog_type) {
        m_type = dialog_type;
    }

    public void set_font(Typeface typeface) {
        m_font = typeface;
    }

    public void set_no_vendor(boolean z) {
        this.m_no_vendor = z;
    }

    public void set_on_dissmiss_listener(peer_dialog_dissmiss peer_dialog_dissmiss2) {
        m_pdd = peer_dialog_dissmiss2;
    }

    public void set_tos_link(String str) {
        m_tos_link = str;
    }

    public int show(FragmentTransaction fragmentTransaction, String str) {
        this.m_display_ms = System.currentTimeMillis();
        return super.show(fragmentTransaction, str);
    }
}
