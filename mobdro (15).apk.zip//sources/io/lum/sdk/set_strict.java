package io.lum.sdk;

import android.content.Context;
import io.lum.sdk.set;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class set_strict<key_type> extends set {

    public static abstract class listener<key_type> implements set.listener {
        public abstract void on_changed(key_type key_type);

        public void on_changed(String str) {
        }
    }

    public set_strict(Context context, String str) {
        super(context, str);
    }

    public final void del(key_type key_type) {
        del(key_type.toString());
    }

    public final boolean exist(key_type key_type) {
        return exist(key_type.toString());
    }

    public final boolean get_bool(key_type key_type) {
        return get_bool(key_type.toString());
    }

    public final boolean get_bool(key_type key_type, boolean z) {
        return get_bool(key_type.toString(), z);
    }

    public final float get_float(key_type key_type) {
        return get_float(key_type.toString());
    }

    public final float get_float(key_type key_type, float f2) {
        return get_float(key_type.toString(), f2);
    }

    public final int get_int(key_type key_type) {
        return get_int(key_type.toString());
    }

    public final JSONObject get_json(key_type key_type) {
        try {
            return new JSONObject(get_str(key_type));
        } catch (JSONException unused) {
            return new JSONObject();
        }
    }

    public final long get_long(key_type key_type) {
        return get_long(key_type.toString());
    }

    public final long get_long(key_type key_type, long j) {
        return get_long(key_type.toString(), j);
    }

    public final String get_str(key_type key_type) {
        return get_str(key_type.toString());
    }

    public final String get_str(key_type key_type, String str) {
        return get_str(key_type.toString(), str);
    }

    public void notify_change(String str) {
        Object resolve_key = resolve_key(str);
        synchronized (this.m_listeners) {
            for (set.listener next : this.m_listeners) {
                if (resolve_key == null || !(next instanceof listener)) {
                    next.on_changed(str);
                } else {
                    ((listener) next).on_changed(resolve_key);
                }
            }
        }
    }

    public abstract key_type resolve_key(String str);

    public final void set(key_type key_type, float f2) {
        set(key_type.toString(), Float.valueOf(f2));
    }

    public final void set(key_type key_type, int i) {
        set(key_type.toString(), Integer.valueOf(i));
    }

    public final void set(key_type key_type, long j) {
        set(key_type.toString(), Long.valueOf(j));
    }

    public final void set(key_type key_type, String str) {
        set(key_type.toString(), str);
    }

    public final void set(key_type key_type, JSONObject jSONObject) {
        set(key_type, jSONObject.toString());
    }

    public final void set(key_type key_type, boolean z) {
        set(key_type.toString(), Boolean.valueOf(z));
    }
}
