package io.lum.sdk.async;

import d.a.a.b2.r;
import d.a.a.b2.s;
import d.a.a.b2.t;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.WritableCallback;

public class BufferedDataSink implements DataSink {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public boolean endPending;
    public boolean forceBuffering;
    public DataSink mDataSink;
    public int mMaxBuffer = Integer.MAX_VALUE;
    public final ByteBufferList mPendingWrites = new ByteBufferList();
    public WritableCallback mWritable;

    public BufferedDataSink(DataSink dataSink) {
        setDataSink(dataSink);
    }

    /* access modifiers changed from: private */
    public void writePending() {
        boolean isEmpty;
        WritableCallback writableCallback;
        if (!this.forceBuffering) {
            synchronized (this.mPendingWrites) {
                this.mDataSink.write(this.mPendingWrites);
                isEmpty = this.mPendingWrites.isEmpty();
            }
            if (isEmpty && this.endPending) {
                this.mDataSink.end();
            }
            if (isEmpty && (writableCallback = this.mWritable) != null) {
                writableCallback.onWriteable();
            }
        }
    }

    public void end() {
        if (getServer().getAffinity() != Thread.currentThread()) {
            getServer().post(new t(this));
            return;
        }
        synchronized (this.mPendingWrites) {
            if (this.mPendingWrites.hasRemaining()) {
                this.endPending = true;
            } else {
                this.mDataSink.end();
            }
        }
    }

    public void forceBuffering(boolean z) {
        this.forceBuffering = z;
        if (!z) {
            writePending();
        }
    }

    public CompletedCallback getClosedCallback() {
        return this.mDataSink.getClosedCallback();
    }

    public DataSink getDataSink() {
        return this.mDataSink;
    }

    public int getMaxBuffer() {
        return this.mMaxBuffer;
    }

    public AsyncServer getServer() {
        return this.mDataSink.getServer();
    }

    public WritableCallback getWriteableCallback() {
        return this.mWritable;
    }

    public boolean isBuffering() {
        return this.mPendingWrites.hasRemaining() || this.forceBuffering;
    }

    public boolean isOpen() {
        return this.mDataSink.isOpen();
    }

    public boolean isWritable() {
        boolean z;
        synchronized (this.mPendingWrites) {
            z = this.mPendingWrites.remaining() < this.mMaxBuffer;
        }
        return z;
    }

    public void onDataAccepted(ByteBufferList byteBufferList) {
    }

    public int remaining() {
        return this.mPendingWrites.remaining();
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        this.mDataSink.setClosedCallback(completedCallback);
    }

    public void setDataSink(DataSink dataSink) {
        this.mDataSink = dataSink;
        dataSink.setWriteableCallback(new s(this));
    }

    public void setMaxBuffer(int i) {
        this.mMaxBuffer = i;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        this.mWritable = writableCallback;
    }

    public void write(ByteBufferList byteBufferList) {
        if (getServer().getAffinity() != Thread.currentThread()) {
            synchronized (this.mPendingWrites) {
                if (this.mPendingWrites.remaining() < this.mMaxBuffer) {
                    onDataAccepted(byteBufferList);
                    byteBufferList.get(this.mPendingWrites);
                    getServer().post(new r(this));
                    return;
                }
                return;
            }
        }
        onDataAccepted(byteBufferList);
        if (!isBuffering()) {
            this.mDataSink.write(byteBufferList);
        }
        synchronized (this.mPendingWrites) {
            byteBufferList.get(this.mPendingWrites);
        }
    }
}
