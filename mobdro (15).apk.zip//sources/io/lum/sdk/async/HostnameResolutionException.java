package io.lum.sdk.async;

public class HostnameResolutionException extends Exception {
    public HostnameResolutionException(String str) {
        super(str);
    }
}
