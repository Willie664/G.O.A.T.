package io.lum.sdk.async.wrapper;

import io.lum.sdk.async.DataEmitter;

public interface DataEmitterWrapper extends DataEmitter {
    DataEmitter getDataEmitter();
}
