package io.lum.sdk.async.wrapper;

import io.lum.sdk.async.AsyncSocket;

public interface AsyncSocketWrapper extends AsyncSocket, DataEmitterWrapper {
    AsyncSocket getSocket();
}
