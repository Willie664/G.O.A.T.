package io.lum.sdk.async.util;

import android.os.Handler;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.future.Cancellable;

public class TimeoutBase {
    public long delay;
    public Handlerish handlerish;

    public interface Handlerish {
        void post(Runnable runnable);

        Object postDelayed(Runnable runnable, long j);

        void removeAllCallbacks(Object obj);
    }

    public TimeoutBase(final Handler handler, long j) {
        this.delay = j;
        this.handlerish = new Handlerish() {
            public void post(Runnable runnable) {
                handler.post(runnable);
            }

            public Object postDelayed(Runnable runnable, long j) {
                handler.postDelayed(runnable, j);
                return runnable;
            }

            public void removeAllCallbacks(Object obj) {
                if (obj != null) {
                    handler.removeCallbacks((Runnable) obj);
                }
            }
        };
    }

    public TimeoutBase(final AsyncServer asyncServer, long j) {
        this.delay = j;
        this.handlerish = new Handlerish() {
            public void post(Runnable runnable) {
                asyncServer.post(runnable);
            }

            public Object postDelayed(Runnable runnable, long j) {
                return asyncServer.postDelayed(runnable, j);
            }

            public void removeAllCallbacks(Object obj) {
                if (obj != null) {
                    ((Cancellable) obj).cancel();
                }
            }
        };
    }

    public void onCallback() {
    }

    public void setDelay(long j) {
        this.delay = j;
    }
}
