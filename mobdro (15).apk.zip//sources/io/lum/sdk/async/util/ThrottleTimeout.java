package io.lum.sdk.async.util;

import android.os.Handler;
import d.a.a.b2.x.b;
import d.a.a.b2.x.c;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.callback.ValueCallback;
import io.lum.sdk.async.util.TimeoutBase;
import java.util.ArrayList;
import java.util.List;

public class ThrottleTimeout<T> extends TimeoutBase {
    public ValueCallback<List<T>> callback;
    public Object cancellable;
    public ThrottleMode throttleMode = ThrottleMode.Collect;
    public ArrayList<T> values = new ArrayList<>();

    public enum ThrottleMode {
        Collect,
        Meter
    }

    public ThrottleTimeout(Handler handler, long j, ValueCallback<List<T>> valueCallback) {
        super(handler, j);
        this.callback = valueCallback;
    }

    public ThrottleTimeout(AsyncServer asyncServer, long j, ValueCallback<List<T>> valueCallback) {
        super(asyncServer, j);
        this.callback = valueCallback;
    }

    /* access modifiers changed from: private */
    public void runCallback() {
        this.cancellable = null;
        ArrayList arrayList = new ArrayList(this.values);
        this.values.clear();
        this.callback.onResult(arrayList);
    }

    public /* synthetic */ void a(Object obj) {
        TimeoutBase.Handlerish handlerish;
        b bVar;
        this.values.add(obj);
        if (this.throttleMode == ThrottleMode.Collect) {
            this.handlerish.removeAllCallbacks(this.cancellable);
            handlerish = this.handlerish;
            bVar = new b(this);
        } else if (this.cancellable == null) {
            runCallback();
            handlerish = this.handlerish;
            bVar = new b(this);
        } else {
            return;
        }
        this.cancellable = handlerish.postDelayed(bVar, this.delay);
    }

    public synchronized void postThrottled(T t) {
        this.handlerish.post(new c(this, t));
    }

    public void setCallback(ValueCallback<List<T>> valueCallback) {
        this.callback = valueCallback;
    }

    public void setThrottleMode(ThrottleMode throttleMode2) {
        this.throttleMode = throttleMode2;
    }
}
