package io.lum.sdk.async.util;

import android.os.Handler;
import d.a.a.b2.x.a;
import io.lum.sdk.async.AsyncServer;

public class IdleTimeout extends TimeoutBase {
    public Runnable callback;
    public Object cancellable;

    public IdleTimeout(Handler handler, long j) {
        super(handler, j);
    }

    public IdleTimeout(AsyncServer asyncServer, long j) {
        super(asyncServer, j);
    }

    public /* synthetic */ void a() {
        this.handlerish.removeAllCallbacks(this.cancellable);
    }

    public void cancel() {
        this.handlerish.post(new a(this));
    }

    public void reset() {
        this.handlerish.removeAllCallbacks(this.cancellable);
        this.cancellable = this.handlerish.postDelayed(this.callback, this.delay);
    }

    public void setTimeout(Runnable runnable) {
        this.callback = runnable;
    }
}
