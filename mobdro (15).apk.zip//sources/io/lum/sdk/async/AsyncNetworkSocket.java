package io.lum.sdk.async;

import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.util.Allocator;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;

public class AsyncNetworkSocket implements AsyncSocket {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public Allocator allocator;
    public boolean closeReported;
    public ChannelWrapper mChannel;
    public CompletedCallback mClosedHander;
    public CompletedCallback mCompletedCallback;
    public DataCallback mDataHandler;
    public boolean mEndReported;
    public SelectionKey mKey;
    public boolean mPaused = false;
    public Exception mPendingEndException;
    public AsyncServer mServer;
    public WritableCallback mWriteableHandler;
    public ByteBufferList pending = new ByteBufferList();
    public InetSocketAddress socketAddress;

    private void closeInternal() {
        this.mKey.cancel();
        try {
            this.mChannel.close();
        } catch (IOException unused) {
        }
    }

    private void handleRemaining(int i) {
        SelectionKey selectionKey;
        int i2;
        if (this.mKey.isValid()) {
            if (i > 0) {
                selectionKey = this.mKey;
                i2 = selectionKey.interestOps() | 4;
            } else {
                selectionKey = this.mKey;
                i2 = selectionKey.interestOps() & -5;
            }
            selectionKey.interestOps(i2);
            return;
        }
        throw new IOException(new CancelledKeyException());
    }

    private void spitPending() {
        if (this.pending.hasRemaining()) {
            Util.emitAllData(this, this.pending);
        }
    }

    public void attach(DatagramChannel datagramChannel) {
        this.mChannel = new DatagramChannelWrapper(datagramChannel);
        this.allocator = new Allocator(8192);
    }

    public void attach(SocketChannel socketChannel, InetSocketAddress inetSocketAddress) {
        this.socketAddress = inetSocketAddress;
        this.allocator = new Allocator();
        this.mChannel = new SocketChannelWrapper(socketChannel);
    }

    public String charset() {
        return null;
    }

    public void close() {
        closeInternal();
        reportClose((Exception) null);
    }

    public void end() {
        this.mChannel.shutdownOutput();
    }

    public ChannelWrapper getChannel() {
        return this.mChannel;
    }

    public CompletedCallback getClosedCallback() {
        return this.mClosedHander;
    }

    public DataCallback getDataCallback() {
        return this.mDataHandler;
    }

    public CompletedCallback getEndCallback() {
        return this.mCompletedCallback;
    }

    public InetAddress getLocalAddress() {
        return this.mChannel.getLocalAddress();
    }

    public int getLocalPort() {
        return this.mChannel.getLocalPort();
    }

    public InetSocketAddress getRemoteAddress() {
        return this.socketAddress;
    }

    public AsyncServer getServer() {
        return this.mServer;
    }

    public Object getSocket() {
        return getChannel().getSocket();
    }

    public WritableCallback getWriteableCallback() {
        return this.mWriteableHandler;
    }

    public boolean isChunked() {
        return this.mChannel.isChunked();
    }

    public boolean isOpen() {
        return this.mChannel.isConnected() && this.mKey.isValid();
    }

    public boolean isPaused() {
        return this.mPaused;
    }

    public void onDataWritable() {
        if (!this.mChannel.isChunked()) {
            SelectionKey selectionKey = this.mKey;
            selectionKey.interestOps(selectionKey.interestOps() & -5);
        }
        WritableCallback writableCallback = this.mWriteableHandler;
        if (writableCallback != null) {
            writableCallback.onWriteable();
        }
    }

    public int onReadable() {
        long j;
        int i;
        spitPending();
        boolean z = false;
        if (this.mPaused) {
            return 0;
        }
        ByteBuffer allocate = this.allocator.allocate();
        try {
            j = (long) this.mChannel.read(allocate);
        } catch (Exception e2) {
            closeInternal();
            reportEndPending(e2);
            reportClose(e2);
            j = -1;
        }
        if (j < 0) {
            closeInternal();
            z = true;
            i = 0;
        } else {
            i = (int) (((long) 0) + j);
        }
        if (j > 0) {
            this.allocator.track(j);
            allocate.flip();
            this.pending.add(allocate);
            Util.emitAllData(this, this.pending);
        } else {
            ByteBufferList.reclaim(allocate);
        }
        if (z) {
            reportEndPending((Exception) null);
            reportClose((Exception) null);
        }
        return i;
    }

    public void pause() {
        if (this.mServer.getAffinity() != Thread.currentThread()) {
            this.mServer.run(new Runnable() {
                public void run() {
                    AsyncNetworkSocket.this.pause();
                }
            });
        } else if (!this.mPaused) {
            this.mPaused = true;
            try {
                this.mKey.interestOps(this.mKey.interestOps() & -2);
            } catch (Exception unused) {
            }
        }
    }

    public void reportClose(Exception exc) {
        if (!this.closeReported) {
            this.closeReported = true;
            CompletedCallback completedCallback = this.mClosedHander;
            if (completedCallback != null) {
                completedCallback.onCompleted(exc);
                this.mClosedHander = null;
            }
        }
    }

    public void reportEnd(Exception exc) {
        if (!this.mEndReported) {
            this.mEndReported = true;
            CompletedCallback completedCallback = this.mCompletedCallback;
            if (completedCallback != null) {
                completedCallback.onCompleted(exc);
            }
        }
    }

    public void reportEndPending(Exception exc) {
        if (this.pending.hasRemaining()) {
            this.mPendingEndException = exc;
        } else {
            reportEnd(exc);
        }
    }

    public void resume() {
        if (this.mServer.getAffinity() != Thread.currentThread()) {
            this.mServer.run(new Runnable() {
                public void run() {
                    AsyncNetworkSocket.this.resume();
                }
            });
        } else if (this.mPaused) {
            this.mPaused = false;
            try {
                this.mKey.interestOps(this.mKey.interestOps() | 1);
            } catch (Exception unused) {
            }
            spitPending();
            if (!isOpen()) {
                reportEndPending(this.mPendingEndException);
            }
        }
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        this.mClosedHander = completedCallback;
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.mDataHandler = dataCallback;
    }

    public void setEndCallback(CompletedCallback completedCallback) {
        this.mCompletedCallback = completedCallback;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        this.mWriteableHandler = writableCallback;
    }

    public void setup(AsyncServer asyncServer, SelectionKey selectionKey) {
        this.mServer = asyncServer;
        this.mKey = selectionKey;
    }

    public void write(final ByteBufferList byteBufferList) {
        if (this.mServer.getAffinity() != Thread.currentThread()) {
            this.mServer.run(new Runnable() {
                public void run() {
                    AsyncNetworkSocket.this.write(byteBufferList);
                }
            });
        } else if (this.mChannel.isConnected()) {
            try {
                int remaining = byteBufferList.remaining();
                ByteBuffer[] allArray = byteBufferList.getAllArray();
                this.mChannel.write(allArray);
                byteBufferList.addAll(allArray);
                handleRemaining(byteBufferList.remaining());
                this.mServer.onDataSent(remaining - byteBufferList.remaining());
            } catch (IOException e2) {
                closeInternal();
                reportEndPending(e2);
                reportClose(e2);
            }
        }
    }
}
