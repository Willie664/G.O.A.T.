package io.lum.sdk.async;

import android.os.Handler;
import android.os.SystemClock;
import d.a.a.b2.i;
import d.a.a.b2.j;
import d.a.a.b2.k;
import d.a.a.b2.l;
import d.a.a.b2.m;
import d.a.a.b2.n;
import d.a.a.b2.o;
import d.a.a.b2.p;
import d.a.a.b2.q;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.callback.ListenCallback;
import io.lum.sdk.async.callback.SocketCreateCallback;
import io.lum.sdk.async.callback.ValueFunction;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.future.SimpleFuture;
import io.lum.sdk.async.util.StreamUtility;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.channels.ClosedSelectorException;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class AsyncServer {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final String LOGTAG = "NIO";
    public static final long QUEUE_EMPTY = Long.MAX_VALUE;
    public static final Comparator<InetAddress> ipSorter = new Comparator<InetAddress>() {
        public int compare(InetAddress inetAddress, InetAddress inetAddress2) {
            boolean z = inetAddress instanceof Inet4Address;
            if (z && (inetAddress2 instanceof Inet4Address)) {
                return 0;
            }
            if (!(inetAddress instanceof Inet6Address) || !(inetAddress2 instanceof Inet6Address)) {
                return (!z || !(inetAddress2 instanceof Inet6Address)) ? 1 : -1;
            }
            return 0;
        }
    };
    public static AsyncServer mInstance = new AsyncServer();
    public static ExecutorService synchronousResolverWorkers = newSynchronousWorkers("AsyncServer-resolver-");
    public static ExecutorService synchronousWorkers = newSynchronousWorkers("AsyncServer-worker-");
    public static final ThreadLocal<AsyncServer> threadServer = new ThreadLocal<>();
    public boolean killed;
    public Thread mAffinity;
    public String mName;
    public PriorityQueue<Scheduled> mQueue;
    public SelectorWrapper mSelector;
    public InetSocketAddress m_local_address;
    public int postCounter;

    public static class AsyncSelectorException extends IOException {
        public AsyncSelectorException(Exception exc) {
            super(exc);
        }
    }

    public class ConnectFuture extends SimpleFuture<AsyncNetworkSocket> {
        public ConnectCallback callback;
        public SocketChannel socket;

        public ConnectFuture() {
        }

        public void cancelCleanup() {
            super.cancelCleanup();
            try {
                if (this.socket != null) {
                    this.socket.close();
                }
            } catch (IOException unused) {
            }
        }
    }

    public static class NamedThreadFactory implements ThreadFactory {
        public final ThreadGroup group;
        public final String namePrefix;
        public final AtomicInteger threadNumber = new AtomicInteger(1);

        public NamedThreadFactory(String str) {
            SecurityManager securityManager = System.getSecurityManager();
            this.group = securityManager != null ? securityManager.getThreadGroup() : Thread.currentThread().getThreadGroup();
            this.namePrefix = str;
        }

        public Thread newThread(Runnable runnable) {
            ThreadGroup threadGroup = this.group;
            Thread thread = new Thread(threadGroup, runnable, this.namePrefix + this.threadNumber.getAndIncrement(), 0);
            if (thread.isDaemon()) {
                thread.setDaemon(false);
            }
            if (thread.getPriority() != 5) {
                thread.setPriority(5);
            }
            return thread;
        }
    }

    public static class ObjectHolder<T> {
        public T held;

        public ObjectHolder() {
        }
    }

    public static class RunnableWrapper implements Runnable {
        public Handler handler;
        public boolean hasRun;
        public Runnable runnable;
        public ThreadQueue threadQueue;

        public RunnableWrapper() {
        }

        public void run() {
            synchronized (this) {
                if (!this.hasRun) {
                    this.hasRun = true;
                    try {
                        this.runnable.run();
                    } finally {
                        this.threadQueue.remove(this);
                        this.handler.removeCallbacks(this);
                        this.threadQueue = null;
                        this.handler = null;
                        this.runnable = null;
                    }
                }
            }
        }
    }

    public static class Scheduled implements Cancellable, Runnable {
        public boolean cancelled;
        public Runnable runnable;
        public AsyncServer server;
        public long time;

        public Scheduled(AsyncServer asyncServer, Runnable runnable2, long j) {
            this.server = asyncServer;
            this.runnable = runnable2;
            this.time = j;
        }

        public boolean cancel() {
            boolean remove;
            synchronized (this.server) {
                remove = this.server.mQueue.remove(this);
                this.cancelled = remove;
            }
            return remove;
        }

        public boolean isCancelled() {
            return this.cancelled;
        }

        public boolean isDone() {
            boolean z;
            synchronized (this.server) {
                z = !this.cancelled && !this.server.mQueue.contains(this);
            }
            return z;
        }

        public void run() {
            this.runnable.run();
        }
    }

    public static class Scheduler implements Comparator<Scheduled> {
        public static Scheduler INSTANCE = new Scheduler();

        public int compare(Scheduled scheduled, Scheduled scheduled2) {
            long j = scheduled.time;
            long j2 = scheduled2.time;
            if (j == j2) {
                return 0;
            }
            return j > j2 ? 1 : -1;
        }
    }

    public AsyncServer() {
        this((String) null);
    }

    public AsyncServer(String str) {
        this.postCounter = 0;
        this.mQueue = new PriorityQueue<>(1, Scheduler.INSTANCE);
        this.mName = str == null ? "AsyncServer" : str;
    }

    public static /* synthetic */ InetAddress a(InetAddress inetAddress) {
        return inetAddress;
    }

    public static /* synthetic */ InetAddress a(InetAddress[] inetAddressArr) {
        return inetAddressArr[0];
    }

    public static /* synthetic */ void a(SelectorWrapper selectorWrapper) {
        try {
            selectorWrapper.wakeupOnce();
        } catch (Exception unused) {
        }
    }

    public static /* synthetic */ void a(Runnable runnable, Semaphore semaphore) {
        runnable.run();
        semaphore.release();
    }

    public static /* synthetic */ void b(SelectorWrapper selectorWrapper) {
        try {
            selectorWrapper.wakeupOnce();
        } catch (Exception unused) {
        }
    }

    private Cancellable createDatagram(ValueFunction<InetAddress> valueFunction, int i, boolean z, FutureCallback<AsyncDatagramSocket> futureCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setCallback(futureCallback);
        post(new k(this, valueFunction, i, z, simpleFuture));
        return simpleFuture;
    }

    public static AsyncServer getCurrentThreadServer() {
        return threadServer.get();
    }

    public static AsyncServer getDefault() {
        return mInstance;
    }

    /* access modifiers changed from: private */
    public void handleSocket(AsyncNetworkSocket asyncNetworkSocket) {
        SelectionKey register = asyncNetworkSocket.getChannel().register(this.mSelector.getSelector());
        register.attach(asyncNetworkSocket);
        asyncNetworkSocket.setup(this, register);
    }

    public static long lockAndRunQueue(AsyncServer asyncServer, PriorityQueue<Scheduled> priorityQueue) {
        long j = Long.MAX_VALUE;
        while (true) {
            Scheduled scheduled = null;
            synchronized (asyncServer) {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                if (priorityQueue.size() > 0) {
                    Scheduled scheduled2 = (Scheduled) priorityQueue.remove();
                    if (scheduled2.time <= elapsedRealtime) {
                        scheduled = scheduled2;
                    } else {
                        j = scheduled2.time - elapsedRealtime;
                        priorityQueue.add(scheduled2);
                    }
                }
            }
            if (scheduled == null) {
                asyncServer.postCounter = 0;
                return j;
            }
            scheduled.run();
        }
        while (true) {
        }
    }

    public static ExecutorService newSynchronousWorkers(String str) {
        return new ThreadPoolExecutor(1, 4, 10, TimeUnit.SECONDS, new LinkedBlockingQueue(), new NamedThreadFactory(str));
    }

    public static void post(Handler handler, Runnable runnable) {
        RunnableWrapper runnableWrapper = new RunnableWrapper();
        ThreadQueue orCreateThreadQueue = ThreadQueue.getOrCreateThreadQueue(handler.getLooper().getThread());
        runnableWrapper.threadQueue = orCreateThreadQueue;
        runnableWrapper.handler = handler;
        runnableWrapper.runnable = runnable;
        orCreateThreadQueue.add((Runnable) runnableWrapper);
        handler.post(runnableWrapper);
        orCreateThreadQueue.queueSemaphore.release();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        runLoop(r4, r0, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        r0.getSelector().close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0036 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void run() {
        /*
            r4 = this;
            monitor-enter(r4)
            io.lum.sdk.async.SelectorWrapper r0 = r4.mSelector     // Catch:{ all -> 0x003e }
            if (r0 != 0) goto L_0x002d
            io.lum.sdk.async.SelectorWrapper r0 = new io.lum.sdk.async.SelectorWrapper     // Catch:{ IOException -> 0x0024 }
            java.nio.channels.spi.SelectorProvider r1 = java.nio.channels.spi.SelectorProvider.provider()     // Catch:{ IOException -> 0x0024 }
            java.nio.channels.spi.AbstractSelector r1 = r1.openSelector()     // Catch:{ IOException -> 0x0024 }
            r0.<init>(r1)     // Catch:{ IOException -> 0x0024 }
            r4.mSelector = r0     // Catch:{ IOException -> 0x0024 }
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r1 = r4.mQueue     // Catch:{ IOException -> 0x0024 }
            io.lum.sdk.async.AsyncServer$8 r2 = new io.lum.sdk.async.AsyncServer$8     // Catch:{ all -> 0x003e }
            java.lang.String r3 = r4.mName     // Catch:{ all -> 0x003e }
            r2.<init>(r3, r0, r1)     // Catch:{ all -> 0x003e }
            r4.mAffinity = r2     // Catch:{ all -> 0x003e }
            r2.start()     // Catch:{ all -> 0x003e }
            monitor-exit(r4)     // Catch:{ all -> 0x003e }
            return
        L_0x0024:
            r0 = move-exception
            java.lang.RuntimeException r1 = new java.lang.RuntimeException     // Catch:{ all -> 0x003e }
            java.lang.String r2 = "unable to create selector?"
            r1.<init>(r2, r0)     // Catch:{ all -> 0x003e }
            throw r1     // Catch:{ all -> 0x003e }
        L_0x002d:
            io.lum.sdk.async.SelectorWrapper r0 = r4.mSelector     // Catch:{ all -> 0x003e }
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r1 = r4.mQueue     // Catch:{ all -> 0x003e }
            monitor-exit(r4)     // Catch:{ all -> 0x003e }
            runLoop(r4, r0, r1)     // Catch:{ AsyncSelectorException -> 0x0036 }
            goto L_0x003d
        L_0x0036:
            java.nio.channels.Selector r0 = r0.getSelector()     // Catch:{ Exception -> 0x003d }
            r0.close()     // Catch:{ Exception -> 0x003d }
        L_0x003d:
            return
        L_0x003e:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x003e }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncServer.run():void");
    }

    public static void run(AsyncServer asyncServer, SelectorWrapper selectorWrapper, PriorityQueue<Scheduled> priorityQueue) {
        while (true) {
            try {
                runLoop(asyncServer, selectorWrapper, priorityQueue);
            } catch (AsyncSelectorException e2) {
                boolean z = e2.getCause() instanceof ClosedSelectorException;
                StreamUtility.closeQuietly(selectorWrapper);
            }
            synchronized (asyncServer) {
                if (!selectorWrapper.isOpen() || (selectorWrapper.keys().size() <= 0 && priorityQueue.size() <= 0)) {
                    shutdownEverything(selectorWrapper);
                }
            }
        }
        shutdownEverything(selectorWrapper);
        if (asyncServer.mSelector == selectorWrapper) {
            asyncServer.mQueue = new PriorityQueue<>(1, Scheduler.INSTANCE);
            asyncServer.mSelector = null;
            asyncServer.mAffinity = null;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: java.nio.channels.SelectionKey} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: java.nio.channels.SelectionKey} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v10, resolved type: java.io.Closeable[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v11, resolved type: java.nio.channels.SocketChannel} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: java.nio.channels.SelectionKey} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: java.nio.channels.SelectionKey} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: java.nio.channels.SelectionKey} */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0026, code lost:
        if (r11 == false) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002a, code lost:
        if (r0 != Long.MAX_VALUE) goto L_0x0030;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
        r10.select();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0030, code lost:
        r10.select(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0033, code lost:
        r11 = r10.selectedKeys();
        r0 = r11.iterator();
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void runLoop(io.lum.sdk.async.AsyncServer r9, io.lum.sdk.async.SelectorWrapper r10, java.util.PriorityQueue<io.lum.sdk.async.AsyncServer.Scheduled> r11) {
        /*
            long r0 = lockAndRunQueue(r9, r11)
            monitor-enter(r9)     // Catch:{ Exception -> 0x0125 }
            int r11 = r10.selectNow()     // Catch:{ all -> 0x0122 }
            r2 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            r4 = 0
            r5 = 1
            if (r11 != 0) goto L_0x0024
            java.util.Set r11 = r10.keys()     // Catch:{ all -> 0x0122 }
            int r11 = r11.size()     // Catch:{ all -> 0x0122 }
            if (r11 != 0) goto L_0x0022
            int r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r11 != 0) goto L_0x0022
            monitor-exit(r9)     // Catch:{ all -> 0x0122 }
            return
        L_0x0022:
            r11 = 1
            goto L_0x0025
        L_0x0024:
            r11 = 0
        L_0x0025:
            monitor-exit(r9)     // Catch:{ all -> 0x0122 }
            if (r11 == 0) goto L_0x0033
            int r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r11 != 0) goto L_0x0030
            r10.select()     // Catch:{ Exception -> 0x0125 }
            goto L_0x0033
        L_0x0030:
            r10.select(r0)     // Catch:{ Exception -> 0x0125 }
        L_0x0033:
            java.util.Set r11 = r10.selectedKeys()
            java.util.Iterator r0 = r11.iterator()
        L_0x003b:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x011e
            java.lang.Object r1 = r0.next()
            java.nio.channels.SelectionKey r1 = (java.nio.channels.SelectionKey) r1
            boolean r2 = r1.isAcceptable()     // Catch:{ CancelledKeyException -> 0x011b }
            r3 = 0
            if (r2 == 0) goto L_0x0099
            java.nio.channels.SelectableChannel r2 = r1.channel()     // Catch:{ CancelledKeyException -> 0x011b }
            java.nio.channels.ServerSocketChannel r2 = (java.nio.channels.ServerSocketChannel) r2     // Catch:{ CancelledKeyException -> 0x011b }
            java.nio.channels.SocketChannel r2 = r2.accept()     // Catch:{ IOException -> 0x008b }
            if (r2 != 0) goto L_0x005b
            goto L_0x003b
        L_0x005b:
            r2.configureBlocking(r4)     // Catch:{ IOException -> 0x0088 }
            java.nio.channels.Selector r6 = r10.getSelector()     // Catch:{ IOException -> 0x0088 }
            java.nio.channels.SelectionKey r3 = r2.register(r6, r5)     // Catch:{ IOException -> 0x0088 }
            java.lang.Object r1 = r1.attachment()     // Catch:{ IOException -> 0x0088 }
            io.lum.sdk.async.callback.ListenCallback r1 = (io.lum.sdk.async.callback.ListenCallback) r1     // Catch:{ IOException -> 0x0088 }
            io.lum.sdk.async.AsyncNetworkSocket r6 = new io.lum.sdk.async.AsyncNetworkSocket     // Catch:{ IOException -> 0x0088 }
            r6.<init>()     // Catch:{ IOException -> 0x0088 }
            java.net.Socket r7 = r2.socket()     // Catch:{ IOException -> 0x0088 }
            java.net.SocketAddress r7 = r7.getRemoteSocketAddress()     // Catch:{ IOException -> 0x0088 }
            java.net.InetSocketAddress r7 = (java.net.InetSocketAddress) r7     // Catch:{ IOException -> 0x0088 }
            r6.attach(r2, r7)     // Catch:{ IOException -> 0x0088 }
            r6.setup(r9, r3)     // Catch:{ IOException -> 0x0088 }
            r3.attach(r6)     // Catch:{ IOException -> 0x0088 }
            r1.onAccepted(r6)     // Catch:{ IOException -> 0x0088 }
            goto L_0x003b
        L_0x0088:
            r1 = r3
            r3 = r2
            goto L_0x008c
        L_0x008b:
            r1 = r3
        L_0x008c:
            java.io.Closeable[] r2 = new java.io.Closeable[r5]     // Catch:{ CancelledKeyException -> 0x011b }
            r2[r4] = r3     // Catch:{ CancelledKeyException -> 0x011b }
            io.lum.sdk.async.util.StreamUtility.closeQuietly(r2)     // Catch:{ CancelledKeyException -> 0x011b }
            if (r1 == 0) goto L_0x003b
            r1.cancel()     // Catch:{ CancelledKeyException -> 0x011b }
            goto L_0x003b
        L_0x0099:
            boolean r2 = r1.isReadable()     // Catch:{ CancelledKeyException -> 0x011b }
            if (r2 == 0) goto L_0x00ad
            java.lang.Object r1 = r1.attachment()     // Catch:{ CancelledKeyException -> 0x011b }
            io.lum.sdk.async.AsyncNetworkSocket r1 = (io.lum.sdk.async.AsyncNetworkSocket) r1     // Catch:{ CancelledKeyException -> 0x011b }
            int r1 = r1.onReadable()     // Catch:{ CancelledKeyException -> 0x011b }
            r9.onDataReceived(r1)     // Catch:{ CancelledKeyException -> 0x011b }
            goto L_0x003b
        L_0x00ad:
            boolean r2 = r1.isWritable()     // Catch:{ CancelledKeyException -> 0x011b }
            if (r2 == 0) goto L_0x00be
            java.lang.Object r1 = r1.attachment()     // Catch:{ CancelledKeyException -> 0x011b }
            io.lum.sdk.async.AsyncNetworkSocket r1 = (io.lum.sdk.async.AsyncNetworkSocket) r1     // Catch:{ CancelledKeyException -> 0x011b }
            r1.onDataWritable()     // Catch:{ CancelledKeyException -> 0x011b }
            goto L_0x003b
        L_0x00be:
            boolean r2 = r1.isConnectable()     // Catch:{ CancelledKeyException -> 0x011b }
            if (r2 == 0) goto L_0x0113
            java.lang.Object r2 = r1.attachment()     // Catch:{ CancelledKeyException -> 0x011b }
            io.lum.sdk.async.AsyncServer$ConnectFuture r2 = (io.lum.sdk.async.AsyncServer.ConnectFuture) r2     // Catch:{ CancelledKeyException -> 0x011b }
            java.nio.channels.SelectableChannel r6 = r1.channel()     // Catch:{ CancelledKeyException -> 0x011b }
            java.nio.channels.SocketChannel r6 = (java.nio.channels.SocketChannel) r6     // Catch:{ CancelledKeyException -> 0x011b }
            r1.interestOps(r5)     // Catch:{ CancelledKeyException -> 0x011b }
            r6.finishConnect()     // Catch:{ IOException -> 0x00fb }
            io.lum.sdk.async.AsyncNetworkSocket r7 = new io.lum.sdk.async.AsyncNetworkSocket     // Catch:{ IOException -> 0x00fb }
            r7.<init>()     // Catch:{ IOException -> 0x00fb }
            r7.setup(r9, r1)     // Catch:{ IOException -> 0x00fb }
            java.net.Socket r8 = r6.socket()     // Catch:{ IOException -> 0x00fb }
            java.net.SocketAddress r8 = r8.getRemoteSocketAddress()     // Catch:{ IOException -> 0x00fb }
            java.net.InetSocketAddress r8 = (java.net.InetSocketAddress) r8     // Catch:{ IOException -> 0x00fb }
            r7.attach(r6, r8)     // Catch:{ IOException -> 0x00fb }
            r1.attach(r7)     // Catch:{ IOException -> 0x00fb }
            boolean r1 = r2.setComplete(r7)     // Catch:{ CancelledKeyException -> 0x011b }
            if (r1 == 0) goto L_0x003b
            io.lum.sdk.async.callback.ConnectCallback r1 = r2.callback     // Catch:{ CancelledKeyException -> 0x011b }
            r1.onConnectCompleted(r3, r7)     // Catch:{ CancelledKeyException -> 0x011b }
            goto L_0x003b
        L_0x00fb:
            r7 = move-exception
            r1.cancel()     // Catch:{ CancelledKeyException -> 0x011b }
            java.io.Closeable[] r1 = new java.io.Closeable[r5]     // Catch:{ CancelledKeyException -> 0x011b }
            r1[r4] = r6     // Catch:{ CancelledKeyException -> 0x011b }
            io.lum.sdk.async.util.StreamUtility.closeQuietly(r1)     // Catch:{ CancelledKeyException -> 0x011b }
            boolean r1 = r2.setComplete((java.lang.Exception) r7)     // Catch:{ CancelledKeyException -> 0x011b }
            if (r1 == 0) goto L_0x003b
            io.lum.sdk.async.callback.ConnectCallback r1 = r2.callback     // Catch:{ CancelledKeyException -> 0x011b }
            r1.onConnectCompleted(r7, r3)     // Catch:{ CancelledKeyException -> 0x011b }
            goto L_0x003b
        L_0x0113:
            java.lang.RuntimeException r1 = new java.lang.RuntimeException     // Catch:{ CancelledKeyException -> 0x011b }
            java.lang.String r2 = "Unknown key state."
            r1.<init>(r2)     // Catch:{ CancelledKeyException -> 0x011b }
            throw r1     // Catch:{ CancelledKeyException -> 0x011b }
        L_0x011b:
            goto L_0x003b
        L_0x011e:
            r11.clear()
            return
        L_0x0122:
            r10 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x0122 }
            throw r10     // Catch:{ Exception -> 0x0125 }
        L_0x0125:
            r9 = move-exception
            io.lum.sdk.async.AsyncServer$AsyncSelectorException r10 = new io.lum.sdk.async.AsyncServer$AsyncSelectorException
            r10.<init>(r9)
            goto L_0x012d
        L_0x012c:
            throw r10
        L_0x012d:
            goto L_0x012c
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncServer.runLoop(io.lum.sdk.async.AsyncServer, io.lum.sdk.async.SelectorWrapper, java.util.PriorityQueue):void");
    }

    public static void shutdownEverything(SelectorWrapper selectorWrapper) {
        shutdownKeys(selectorWrapper);
        StreamUtility.closeQuietly(selectorWrapper);
    }

    public static void shutdownKeys(SelectorWrapper selectorWrapper) {
        try {
            for (SelectionKey next : selectorWrapper.keys()) {
                StreamUtility.closeQuietly(next.channel());
                try {
                    next.cancel();
                } catch (Exception unused) {
                }
            }
        } catch (Exception unused2) {
        }
    }

    public static void wakeup(SelectorWrapper selectorWrapper) {
        synchronousWorkers.execute(new m(selectorWrapper));
    }

    public /* synthetic */ void a(AsyncDatagramSocket asyncDatagramSocket, InetAddress inetAddress, int i, boolean z) {
        try {
            DatagramChannel open = DatagramChannel.open();
            try {
                asyncDatagramSocket.attach(open);
                InetSocketAddress inetSocketAddress = inetAddress == null ? new InetSocketAddress(i) : new InetSocketAddress(inetAddress, i);
                if (z) {
                    open.socket().setReuseAddress(z);
                }
                open.socket().bind(inetSocketAddress);
                handleSocket(asyncDatagramSocket);
            } catch (IOException unused) {
                StreamUtility.closeQuietly(open);
            }
        } catch (Exception unused2) {
        }
    }

    public /* synthetic */ void a(AsyncDatagramSocket asyncDatagramSocket, DatagramChannel datagramChannel, SocketAddress socketAddress) {
        try {
            handleSocket(asyncDatagramSocket);
            datagramChannel.connect(socketAddress);
        } catch (IOException unused) {
            StreamUtility.closeQuietly(datagramChannel);
        }
    }

    public /* synthetic */ void a(ValueFunction valueFunction, int i, boolean z, SimpleFuture simpleFuture) {
        DatagramChannel datagramChannel;
        try {
            datagramChannel = DatagramChannel.open();
            try {
                AsyncDatagramSocket asyncDatagramSocket = new AsyncDatagramSocket();
                asyncDatagramSocket.attach(datagramChannel);
                InetSocketAddress inetSocketAddress = valueFunction == null ? new InetSocketAddress(i) : new InetSocketAddress((InetAddress) valueFunction.getValue(), i);
                if (z) {
                    datagramChannel.socket().setReuseAddress(z);
                }
                datagramChannel.socket().bind(inetSocketAddress);
                handleSocket(asyncDatagramSocket);
                if (!simpleFuture.setComplete(asyncDatagramSocket)) {
                    datagramChannel.close();
                }
            } catch (Exception e2) {
                e = e2;
                StreamUtility.closeQuietly(datagramChannel);
                simpleFuture.setComplete(e);
            }
        } catch (Exception e3) {
            e = e3;
            datagramChannel = null;
            StreamUtility.closeQuietly(datagramChannel);
            simpleFuture.setComplete(e);
        }
    }

    public AsyncDatagramSocket connectDatagram(String str, int i) {
        final DatagramChannel open = DatagramChannel.open();
        AsyncDatagramSocket asyncDatagramSocket = new AsyncDatagramSocket();
        asyncDatagramSocket.attach(open);
        final String str2 = str;
        final int i2 = i;
        final AsyncDatagramSocket asyncDatagramSocket2 = asyncDatagramSocket;
        run(new Runnable() {
            public void run() {
                try {
                    InetSocketAddress inetSocketAddress = new InetSocketAddress(str2, i2);
                    AsyncServer.this.handleSocket(asyncDatagramSocket2);
                    open.connect(inetSocketAddress);
                } catch (IOException unused) {
                    StreamUtility.closeQuietly(open);
                }
            }
        });
        return asyncDatagramSocket;
    }

    public AsyncDatagramSocket connectDatagram(SocketAddress socketAddress) {
        AsyncDatagramSocket asyncDatagramSocket = new AsyncDatagramSocket();
        DatagramChannel open = DatagramChannel.open();
        asyncDatagramSocket.attach(open);
        j jVar = new j(this, asyncDatagramSocket, open, socketAddress);
        if (getAffinity() != Thread.currentThread()) {
            run(jVar);
            return asyncDatagramSocket;
        }
        jVar.run();
        return asyncDatagramSocket;
    }

    public ConnectFuture connectResolvedInetSocketAddress(InetSocketAddress inetSocketAddress, ConnectCallback connectCallback, SocketCreateCallback socketCreateCallback) {
        ConnectFuture connectFuture = new ConnectFuture();
        final ConnectFuture connectFuture2 = connectFuture;
        final ConnectCallback connectCallback2 = connectCallback;
        final SocketCreateCallback socketCreateCallback2 = socketCreateCallback;
        final InetSocketAddress inetSocketAddress2 = inetSocketAddress;
        post(new Runnable() {
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: java.nio.channels.SelectionKey} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: java.io.Closeable[]} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: java.nio.channels.SelectionKey} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: java.nio.channels.SocketChannel} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: java.nio.channels.SelectionKey} */
            /* JADX WARNING: Multi-variable type inference failed */
            /* JADX WARNING: Removed duplicated region for block: B:18:0x0061  */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r5 = this;
                    io.lum.sdk.async.AsyncServer$ConnectFuture r0 = r2
                    boolean r0 = r0.isCancelled()
                    if (r0 == 0) goto L_0x0009
                    return
                L_0x0009:
                    io.lum.sdk.async.AsyncServer$ConnectFuture r0 = r2
                    io.lum.sdk.async.callback.ConnectCallback r1 = r3
                    r0.callback = r1
                    r1 = 0
                    r2 = 0
                    java.nio.channels.SocketChannel r3 = java.nio.channels.SocketChannel.open()     // Catch:{ all -> 0x005d }
                    r0.socket = r3     // Catch:{ all -> 0x005d }
                    io.lum.sdk.async.AsyncServer r0 = io.lum.sdk.async.AsyncServer.this     // Catch:{ all -> 0x005b }
                    java.net.InetSocketAddress r0 = r0.m_local_address     // Catch:{ all -> 0x005b }
                    if (r0 == 0) goto L_0x002c
                    java.net.Socket r0 = r3.socket()     // Catch:{ all -> 0x005b }
                    io.lum.sdk.async.AsyncServer r4 = io.lum.sdk.async.AsyncServer.this     // Catch:{ all -> 0x005b }
                    java.net.InetSocketAddress r4 = r4.m_local_address     // Catch:{ all -> 0x005b }
                    r0.bind(r4)     // Catch:{ all -> 0x005b }
                L_0x002c:
                    r3.configureBlocking(r1)     // Catch:{ all -> 0x005b }
                    io.lum.sdk.async.AsyncServer r0 = io.lum.sdk.async.AsyncServer.this     // Catch:{ all -> 0x005b }
                    io.lum.sdk.async.SelectorWrapper r0 = r0.mSelector     // Catch:{ all -> 0x005b }
                    java.nio.channels.Selector r0 = r0.getSelector()     // Catch:{ all -> 0x005b }
                    r4 = 8
                    java.nio.channels.SelectionKey r2 = r3.register(r0, r4)     // Catch:{ all -> 0x005b }
                    io.lum.sdk.async.AsyncServer$ConnectFuture r0 = r2     // Catch:{ all -> 0x005b }
                    r2.attach(r0)     // Catch:{ all -> 0x005b }
                    io.lum.sdk.async.callback.SocketCreateCallback r0 = r4     // Catch:{ all -> 0x005b }
                    if (r0 == 0) goto L_0x0055
                    io.lum.sdk.async.callback.SocketCreateCallback r0 = r4     // Catch:{ all -> 0x005b }
                    java.net.Socket r4 = r3.socket()     // Catch:{ all -> 0x005b }
                    int r4 = r4.getLocalPort()     // Catch:{ all -> 0x005b }
                    r0.onSocketCreated(r4)     // Catch:{ all -> 0x005b }
                L_0x0055:
                    java.net.InetSocketAddress r0 = r5     // Catch:{ all -> 0x005b }
                    r3.connect(r0)     // Catch:{ all -> 0x005b }
                    goto L_0x0076
                L_0x005b:
                    r0 = move-exception
                    goto L_0x005f
                L_0x005d:
                    r0 = move-exception
                    r3 = r2
                L_0x005f:
                    if (r2 == 0) goto L_0x0064
                    r2.cancel()
                L_0x0064:
                    r2 = 1
                    java.io.Closeable[] r2 = new java.io.Closeable[r2]
                    r2[r1] = r3
                    io.lum.sdk.async.util.StreamUtility.closeQuietly(r2)
                    io.lum.sdk.async.AsyncServer$ConnectFuture r1 = r2
                    java.lang.RuntimeException r2 = new java.lang.RuntimeException
                    r2.<init>(r0)
                    r1.setComplete((java.lang.Exception) r2)
                L_0x0076:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncServer.AnonymousClass3.run():void");
            }
        });
        return connectFuture;
    }

    public Cancellable connectResolvedInetSocketAddress(InetSocketAddress inetSocketAddress, ConnectCallback connectCallback) {
        return connectResolvedInetSocketAddress(inetSocketAddress, connectCallback, (SocketCreateCallback) null);
    }

    public Cancellable connectSocket(String str, int i, ConnectCallback connectCallback) {
        return connectSocket(InetSocketAddress.createUnresolved(str, i), connectCallback);
    }

    public Cancellable connectSocket(final InetSocketAddress inetSocketAddress, final ConnectCallback connectCallback) {
        if (!inetSocketAddress.isUnresolved()) {
            return connectResolvedInetSocketAddress(inetSocketAddress, connectCallback);
        }
        final SimpleFuture simpleFuture = new SimpleFuture();
        Future<InetAddress> byName = getByName(inetSocketAddress.getHostName());
        simpleFuture.setParent(byName);
        byName.setCallback(new FutureCallback<InetAddress>() {
            public void onCompleted(Exception exc, InetAddress inetAddress) {
                if (exc != null) {
                    connectCallback.onConnectCompleted(exc, (AsyncSocket) null);
                    simpleFuture.setComplete(exc);
                    return;
                }
                simpleFuture.setComplete((ConnectFuture) AsyncServer.this.connectResolvedInetSocketAddress(new InetSocketAddress(inetAddress, inetSocketAddress.getPort()), connectCallback));
            }
        });
        return simpleFuture;
    }

    public Cancellable createDatagram(String str, int i, boolean z, FutureCallback<AsyncDatagramSocket> futureCallback) {
        return createDatagram((ValueFunction<InetAddress>) new i(str), i, z, futureCallback);
    }

    public Cancellable createDatagram(InetAddress inetAddress, int i, boolean z, FutureCallback<AsyncDatagramSocket> futureCallback) {
        return createDatagram((ValueFunction<InetAddress>) new l(inetAddress), i, z, futureCallback);
    }

    public void dump() {
        post(new Runnable() {
            public void run() {
                if (AsyncServer.this.mSelector != null) {
                    AsyncServer.this.mSelector.keys().size();
                    for (SelectionKey selectionKey : AsyncServer.this.mSelector.keys()) {
                        "Key: " + selectionKey;
                    }
                }
            }
        });
    }

    public Thread getAffinity() {
        return this.mAffinity;
    }

    public Future<InetAddress[]> getAllByName(final String str) {
        final SimpleFuture simpleFuture = new SimpleFuture();
        synchronousResolverWorkers.execute(new Runnable() {
            public void run() {
                try {
                    final InetAddress[] allByName = InetAddress.getAllByName(str);
                    Arrays.sort(allByName, AsyncServer.ipSorter);
                    if (allByName == null || allByName.length == 0) {
                        throw new HostnameResolutionException("no addresses for host");
                    }
                    AsyncServer.this.post(new Runnable() {
                        public void run() {
                            simpleFuture.setComplete((Exception) null, allByName);
                        }
                    });
                } catch (Exception e2) {
                    AsyncServer.this.post(new Runnable() {
                        public void run() {
                            simpleFuture.setComplete(e2, null);
                        }
                    });
                }
            }
        });
        return simpleFuture;
    }

    public Future<InetAddress> getByName(String str) {
        return getAllByName(str).thenConvert(n.f7088a);
    }

    public boolean isAffinityThread() {
        return this.mAffinity == Thread.currentThread();
    }

    public boolean isAffinityThreadOrStopped() {
        Thread thread = this.mAffinity;
        return thread == null || thread == Thread.currentThread();
    }

    public boolean isRunning() {
        return this.mSelector != null;
    }

    public void kill() {
        synchronized (this) {
            this.killed = true;
        }
        stop(false);
    }

    public AsyncServerSocket listen(InetAddress inetAddress, int i, ListenCallback listenCallback) {
        ObjectHolder objectHolder = new ObjectHolder();
        final InetAddress inetAddress2 = inetAddress;
        final int i2 = i;
        final ListenCallback listenCallback2 = listenCallback;
        final ObjectHolder objectHolder2 = objectHolder;
        run(new Runnable() {
            public void run() {
                final ServerSocketChannelWrapper serverSocketChannelWrapper;
                final ServerSocketChannel serverSocketChannel;
                IOException e2;
                try {
                    serverSocketChannel = ServerSocketChannel.open();
                    try {
                        serverSocketChannelWrapper = new ServerSocketChannelWrapper(serverSocketChannel);
                        try {
                            serverSocketChannel.socket().bind(inetAddress2 == null ? new InetSocketAddress(i2) : new InetSocketAddress(inetAddress2, i2));
                            final SelectionKey register = serverSocketChannelWrapper.register(AsyncServer.this.mSelector.getSelector());
                            register.attach(listenCallback2);
                            ListenCallback listenCallback = listenCallback2;
                            ObjectHolder objectHolder = objectHolder2;
                            T r5 = new AsyncServerSocket() {
                                public int getLocalPort() {
                                    return serverSocketChannel.socket().getLocalPort();
                                }

                                public void stop() {
                                    StreamUtility.closeQuietly(serverSocketChannelWrapper);
                                    try {
                                        register.cancel();
                                    } catch (Exception unused) {
                                    }
                                }
                            };
                            objectHolder.held = r5;
                            listenCallback.onListening(r5);
                        } catch (IOException e3) {
                            e2 = e3;
                            StreamUtility.closeQuietly(serverSocketChannelWrapper, serverSocketChannel);
                            listenCallback2.onCompleted(e2);
                        }
                    } catch (IOException e4) {
                        IOException iOException = e4;
                        serverSocketChannelWrapper = null;
                        e2 = iOException;
                        StreamUtility.closeQuietly(serverSocketChannelWrapper, serverSocketChannel);
                        listenCallback2.onCompleted(e2);
                    }
                } catch (IOException e5) {
                    serverSocketChannelWrapper = null;
                    e2 = e5;
                    serverSocketChannel = null;
                    StreamUtility.closeQuietly(serverSocketChannelWrapper, serverSocketChannel);
                    listenCallback2.onCompleted(e2);
                }
            }
        });
        return (AsyncServerSocket) objectHolder.held;
    }

    public void onDataReceived(int i) {
    }

    public void onDataSent(int i) {
    }

    public AsyncDatagramSocket openDatagram() {
        return openDatagram((InetAddress) null, 0, false);
    }

    public AsyncDatagramSocket openDatagram(InetAddress inetAddress, int i, boolean z) {
        AsyncDatagramSocket asyncDatagramSocket = new AsyncDatagramSocket();
        p pVar = new p(this, asyncDatagramSocket, inetAddress, i, z);
        if (getAffinity() != Thread.currentThread()) {
            run(pVar);
            return asyncDatagramSocket;
        }
        pVar.run();
        return asyncDatagramSocket;
    }

    public Cancellable post(CompletedCallback completedCallback, Exception exc) {
        return post(new o(completedCallback, exc));
    }

    public Cancellable post(Runnable runnable) {
        return postDelayed(runnable, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0057, code lost:
        return r7;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public io.lum.sdk.async.future.Cancellable postDelayed(java.lang.Runnable r5, long r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            boolean r0 = r4.killed     // Catch:{ all -> 0x0058 }
            if (r0 == 0) goto L_0x0009
            io.lum.sdk.async.future.Cancellable r5 = io.lum.sdk.async.future.SimpleCancellable.CANCELLED     // Catch:{ all -> 0x0058 }
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return r5
        L_0x0009:
            r0 = 0
            int r2 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
            if (r2 <= 0) goto L_0x0015
            long r0 = android.os.SystemClock.elapsedRealtime()     // Catch:{ all -> 0x0058 }
            long r0 = r0 + r6
            goto L_0x003a
        L_0x0015:
            int r2 = (r6 > r0 ? 1 : (r6 == r0 ? 0 : -1))
            if (r2 != 0) goto L_0x0021
            int r6 = r4.postCounter     // Catch:{ all -> 0x0058 }
            int r7 = r6 + 1
            r4.postCounter = r7     // Catch:{ all -> 0x0058 }
            long r0 = (long) r6     // Catch:{ all -> 0x0058 }
            goto L_0x003a
        L_0x0021:
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r6 = r4.mQueue     // Catch:{ all -> 0x0058 }
            int r6 = r6.size()     // Catch:{ all -> 0x0058 }
            if (r6 <= 0) goto L_0x003a
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r6 = r4.mQueue     // Catch:{ all -> 0x0058 }
            java.lang.Object r6 = r6.peek()     // Catch:{ all -> 0x0058 }
            io.lum.sdk.async.AsyncServer$Scheduled r6 = (io.lum.sdk.async.AsyncServer.Scheduled) r6     // Catch:{ all -> 0x0058 }
            long r6 = r6.time     // Catch:{ all -> 0x0058 }
            r2 = 1
            long r6 = r6 - r2
            long r0 = java.lang.Math.min(r0, r6)     // Catch:{ all -> 0x0058 }
        L_0x003a:
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r6 = r4.mQueue     // Catch:{ all -> 0x0058 }
            io.lum.sdk.async.AsyncServer$Scheduled r7 = new io.lum.sdk.async.AsyncServer$Scheduled     // Catch:{ all -> 0x0058 }
            r7.<init>(r4, r5, r0)     // Catch:{ all -> 0x0058 }
            r6.add(r7)     // Catch:{ all -> 0x0058 }
            io.lum.sdk.async.SelectorWrapper r5 = r4.mSelector     // Catch:{ all -> 0x0058 }
            if (r5 != 0) goto L_0x004b
            r4.run()     // Catch:{ all -> 0x0058 }
        L_0x004b:
            boolean r5 = r4.isAffinityThread()     // Catch:{ all -> 0x0058 }
            if (r5 != 0) goto L_0x0056
            io.lum.sdk.async.SelectorWrapper r5 = r4.mSelector     // Catch:{ all -> 0x0058 }
            wakeup(r5)     // Catch:{ all -> 0x0058 }
        L_0x0056:
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            return r7
        L_0x0058:
            r5 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0058 }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncServer.postDelayed(java.lang.Runnable, long):io.lum.sdk.async.future.Cancellable");
    }

    public Cancellable postImmediate(Runnable runnable) {
        if (Thread.currentThread() != getAffinity()) {
            return postDelayed(runnable, -1);
        }
        runnable.run();
        return null;
    }

    public void run(Runnable runnable) {
        if (Thread.currentThread() == this.mAffinity) {
            post(runnable);
            lockAndRunQueue(this, this.mQueue);
            return;
        }
        synchronized (this) {
            if (!this.killed) {
                Semaphore semaphore = new Semaphore(0);
                post(new q(runnable, semaphore));
                try {
                    semaphore.acquire();
                } catch (InterruptedException unused) {
                }
            }
        }
    }

    public AsyncServer set_local_address(InetSocketAddress inetSocketAddress) {
        this.m_local_address = inetSocketAddress;
        return this;
    }

    public void stop() {
        stop(false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:?, code lost:
        r2.acquire();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x003f, code lost:
        if (r0 != false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0041, code lost:
        if (r9 == false) goto L_?;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void stop(boolean r9) {
        /*
            r8 = this;
            monitor-enter(r8)
            boolean r0 = r8.isAffinityThread()     // Catch:{ all -> 0x0047 }
            io.lum.sdk.async.SelectorWrapper r1 = r8.mSelector     // Catch:{ all -> 0x0047 }
            if (r1 != 0) goto L_0x000b
            monitor-exit(r8)     // Catch:{ all -> 0x0047 }
            return
        L_0x000b:
            java.util.concurrent.Semaphore r2 = new java.util.concurrent.Semaphore     // Catch:{ all -> 0x0047 }
            r3 = 0
            r2.<init>(r3)     // Catch:{ all -> 0x0047 }
            java.util.PriorityQueue<io.lum.sdk.async.AsyncServer$Scheduled> r3 = r8.mQueue     // Catch:{ all -> 0x0047 }
            io.lum.sdk.async.AsyncServer$Scheduled r4 = new io.lum.sdk.async.AsyncServer$Scheduled     // Catch:{ all -> 0x0047 }
            io.lum.sdk.async.AsyncServer$1 r5 = new io.lum.sdk.async.AsyncServer$1     // Catch:{ all -> 0x0047 }
            r5.<init>(r1, r2)     // Catch:{ all -> 0x0047 }
            r6 = 0
            r4.<init>(r8, r5, r6)     // Catch:{ all -> 0x0047 }
            r3.add(r4)     // Catch:{ all -> 0x0047 }
            java.util.concurrent.ExecutorService r3 = synchronousWorkers     // Catch:{ all -> 0x0047 }
            d.a.a.b2.h r4 = new d.a.a.b2.h     // Catch:{ all -> 0x0047 }
            r4.<init>(r1)     // Catch:{ all -> 0x0047 }
            r3.execute(r4)     // Catch:{ all -> 0x0047 }
            shutdownKeys(r1)     // Catch:{ all -> 0x0047 }
            java.util.PriorityQueue r1 = new java.util.PriorityQueue     // Catch:{ all -> 0x0047 }
            r3 = 1
            io.lum.sdk.async.AsyncServer$Scheduler r4 = io.lum.sdk.async.AsyncServer.Scheduler.INSTANCE     // Catch:{ all -> 0x0047 }
            r1.<init>(r3, r4)     // Catch:{ all -> 0x0047 }
            r8.mQueue = r1     // Catch:{ all -> 0x0047 }
            r1 = 0
            r8.mSelector = r1     // Catch:{ all -> 0x0047 }
            r8.mAffinity = r1     // Catch:{ all -> 0x0047 }
            monitor-exit(r8)     // Catch:{ all -> 0x0047 }
            if (r0 != 0) goto L_0x0046
            if (r9 == 0) goto L_0x0046
            r2.acquire()     // Catch:{ Exception -> 0x0046 }
        L_0x0046:
            return
        L_0x0047:
            r9 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x0047 }
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncServer.stop(boolean):void");
    }
}
