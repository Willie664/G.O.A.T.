package io.lum.sdk.async.future;

public interface ThenCallback<T, F> {
    T then(F f2);
}
