package io.lum.sdk.async.future;

public interface FutureCallback<T> {
    void onCompleted(Exception exc, T t);
}
