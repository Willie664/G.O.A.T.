package io.lum.sdk.async.future;

import android.text.TextUtils;
import d.a.a.b2.u.a;
import d.a.a.b2.u.b;
import d.a.a.b2.u.c;
import d.a.a.b2.u.d;
import d.a.a.b2.u.e;
import d.a.a.b2.u.f;
import d.a.a.b2.u.g;
import d.a.a.b2.u.h;
import d.a.a.b2.u.i;
import d.a.a.b2.u.j;
import d.a.a.b2.u.k;
import d.a.a.b2.u.l;
import d.a.a.b2.u.m;
import d.a.a.b2.u.n;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.http.body.StringBody;
import java.io.InvalidObjectException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class Converter<R> {
    public static final ConverterEntries Converters = new ConverterEntries();
    public static final String MIME_ALL = "*/*";
    public MultiFuture<R> future = new MultiFuture<>();
    public String futureMime;
    public Converters<Object, Object> outputs;

    public static class ConverterEntries {
        public ArrayList<ConverterEntry> list;

        public ConverterEntries() {
            this.list = new ArrayList<>();
        }

        public ConverterEntries(ConverterEntries converterEntries) {
            ArrayList<ConverterEntry> arrayList = new ArrayList<>();
            this.list = arrayList;
            arrayList.addAll(converterEntries.list);
        }

        public synchronized <F, T> void addConverter(Class<F> cls, String str, Class<T> cls2, String str2, int i, TypeConverter<T, F> typeConverter) {
            if (TextUtils.isEmpty(str)) {
                str = "*/*";
            }
            String str3 = str;
            if (TextUtils.isEmpty(str2)) {
                str2 = "*/*";
            }
            this.list.add(new ConverterEntry(cls, str3, cls2, str2, i, typeConverter));
        }

        public synchronized <F, T> void addConverter(Class<F> cls, String str, Class<T> cls2, String str2, TypeConverter<T, F> typeConverter) {
            addConverter(cls, str, cls2, str2, 1, typeConverter);
        }

        public synchronized boolean removeConverter(TypeConverter typeConverter) {
            Iterator<ConverterEntry> it = this.list.iterator();
            while (it.hasNext()) {
                ConverterEntry next = it.next();
                if (next.typeConverter == typeConverter) {
                    return this.list.remove(next);
                }
            }
            return false;
        }
    }

    public static class ConverterEntry<F, T> {
        public int distance;
        public MimedType<F> from;
        public MimedType<T> to;
        public TypeConverter<T, F> typeConverter;

        public ConverterEntry(Class<F> cls, String str, Class<T> cls2, String str2, int i, TypeConverter<T, F> typeConverter2) {
            this.from = new MimedType<>(cls, str);
            this.to = new MimedType<>(cls2, str2);
            this.distance = i;
            this.typeConverter = typeConverter2;
        }

        public boolean equals(Object obj) {
            ConverterEntry converterEntry = (ConverterEntry) obj;
            return this.from.equals(converterEntry.from) && this.to.equals(converterEntry.to);
        }

        public int hashCode() {
            return this.from.hashCode() ^ this.to.hashCode();
        }
    }

    public static class ConverterTransformers<F, T> extends LinkedHashMap<MimedType<T>, MultiTransformer<T, F>> {
    }

    public static class Converters<F, T> extends EnsureHashMap<MimedType<F>, ConverterTransformers<F, T>> {
        public static <F, T> void add(ConverterTransformers<F, T> converterTransformers, ConverterTransformers<F, T> converterTransformers2) {
            if (converterTransformers2 != null) {
                converterTransformers.putAll(converterTransformers2);
            }
        }

        public ConverterTransformers<F, T> getAll(MimedType<T> mimedType) {
            ConverterTransformers<F, T> converterTransformers = new ConverterTransformers<>();
            for (MimedType mimedType2 : keySet()) {
                if (mimedType2.isTypeOf((MimedType) mimedType)) {
                    add(converterTransformers, (ConverterTransformers) get(mimedType2));
                }
            }
            return converterTransformers;
        }

        public ConverterTransformers makeDefault() {
            return new ConverterTransformers();
        }
    }

    public static abstract class EnsureHashMap<K, V> extends LinkedHashMap<K, V> {
        public synchronized V ensure(K k) {
            if (!containsKey(k)) {
                put(k, makeDefault());
            }
            return get(k);
        }

        public abstract V makeDefault();
    }

    public static class MimedData<T> {
        public T data;
        public String mime;

        public MimedData(T t, String str) {
            this.data = t;
            this.mime = str;
        }
    }

    public static class MimedType<T> {
        public String mime;
        public Class<T> type;

        public MimedType(Class<T> cls, String str) {
            this.type = cls;
            this.mime = str;
        }

        public boolean equals(Object obj) {
            MimedType mimedType = (MimedType) obj;
            return this.type.equals(mimedType.type) && this.mime.equals(mimedType.mime);
        }

        public int hashCode() {
            return this.type.hashCode() ^ this.mime.hashCode();
        }

        public boolean isTypeOf(MimedType mimedType) {
            if (!this.type.isAssignableFrom(mimedType.type)) {
                return false;
            }
            return isTypeOf(mimedType.mime);
        }

        public boolean isTypeOf(String str) {
            String[] split = str.split("/");
            String[] split2 = this.mime.split("/");
            if ("*".equals(split2[0]) || split[0].equals(split2[0])) {
                return "*".equals(split2[1]) || split[1].equals(split2[1]);
            }
            return false;
        }

        public String primary() {
            return this.mime.split("/")[0];
        }

        public String secondary() {
            return this.mime.split("/")[1];
        }

        public String toString() {
            return this.type.getSimpleName() + " " + this.mime;
        }
    }

    public static class MultiTransformer<T, F> extends MultiTransformFuture<MimedData<Future<T>>, MimedData<Future<F>>> {
        public TypeConverter<T, F> converter;
        public String converterMime;
        public int distance;

        public MultiTransformer(TypeConverter<T, F> typeConverter, String str, int i) {
            this.converter = typeConverter;
            this.converterMime = str;
            this.distance = i;
        }

        public static /* synthetic */ void a(MultiFuture multiFuture, Exception exc, Future future) {
            if (exc != null) {
                multiFuture.setComplete(exc);
            } else {
                multiFuture.setComplete(future);
            }
        }

        public /* synthetic */ Future a(String str, Object obj) {
            return this.converter.convert(obj, str);
        }

        public void transform(MimedData<Future<F>> mimedData) {
            String str = mimedData.mime;
            MultiFuture multiFuture = new MultiFuture();
            setComplete(new MimedData(multiFuture, Converter.mimeReplace(str, this.converterMime)));
            ((Future) mimedData.data).thenConvert(new h(this, str)).setCallback(new i(multiFuture));
        }
    }

    public static class PathInfo {
        public MimedType candidate;
        public String mime;
        public MultiTransformer<Object, Object> transformer;

        public static int distance(ArrayDeque<PathInfo> arrayDeque) {
            Iterator<PathInfo> it = arrayDeque.iterator();
            int i = 0;
            while (it.hasNext()) {
                i += it.next().transformer.distance;
            }
            return i;
        }
    }

    static {
        f fVar = f.f7111a;
        n nVar = n.f7122a;
        m mVar = m.f7121a;
        b bVar = b.f7104a;
        c cVar = c.f7106a;
        a aVar = a.f7101a;
        k kVar = k.f7117a;
        e eVar = e.f7110a;
        j jVar = j.f7116a;
        g gVar = g.f7112a;
        Converters.addConverter(ByteBuffer.class, (String) null, ByteBufferList.class, (String) null, aVar);
        Converters.addConverter(String.class, (String) null, byte[].class, StringBody.CONTENT_TYPE, kVar);
        Converters.addConverter(byte[].class, (String) null, ByteBufferList.class, (String) null, fVar);
        Converters.addConverter(ByteBufferList.class, (String) null, byte[].class, (String) null, nVar);
        Converters.addConverter(ByteBufferList.class, (String) null, ByteBuffer.class, (String) null, mVar);
        Converters.addConverter(ByteBufferList.class, StringBody.CONTENT_TYPE, String.class, (String) null, bVar);
        Converters.addConverter(byte[].class, (String) null, ByteBuffer.class, (String) null, cVar);
        Converters.addConverter(String.class, "application/json", JSONObject.class, (String) null, eVar);
        Converters.addConverter(JSONObject.class, (String) null, String.class, "application/json", jVar);
        Converters.addConverter(byte[].class, StringBody.CONTENT_TYPE, String.class, (String) null, gVar);
    }

    public Converter(Future future2, String str) {
        this.futureMime = TextUtils.isEmpty(str) ? "*/*" : str;
        this.future.setComplete(future2);
    }

    public static /* synthetic */ Future a(ByteBufferList byteBufferList, String str) {
        return new SimpleFuture(byteBufferList.getAllByteArray());
    }

    public static /* synthetic */ Future a(MimedData mimedData) {
        return (Future) mimedData.data;
    }

    public static /* synthetic */ Future a(String str, String str2) {
        return new SimpleFuture(str.getBytes());
    }

    public static /* synthetic */ Future a(ByteBuffer byteBuffer, String str) {
        return new SimpleFuture(new ByteBufferList(ByteBufferList.deepCopy(byteBuffer)));
    }

    public static /* synthetic */ Future a(byte[] bArr, String str) {
        return new SimpleFuture(new String(bArr));
    }

    public static /* synthetic */ Future b(ByteBufferList byteBufferList, String str) {
        return new SimpleFuture(byteBufferList.getAll());
    }

    public static /* synthetic */ Future b(byte[] bArr, String str) {
        return new SimpleFuture(new ByteBufferList(ByteBufferList.deepCopy(ByteBuffer.wrap(bArr))));
    }

    public static /* synthetic */ Future c(ByteBufferList byteBufferList, String str) {
        return new SimpleFuture(byteBufferList.peekString());
    }

    public static /* synthetic */ Future c(byte[] bArr, String str) {
        return new SimpleFuture(ByteBufferList.deepCopy(ByteBuffer.wrap(bArr)));
    }

    public static <T> Converter<T> convert(Future<T> future2) {
        return convert(future2, (String) null);
    }

    public static <T> Converter<T> convert(Future<T> future2, String str) {
        return new Converter<>(future2, str);
    }

    public static String mimeReplace(String str, String str2) {
        String[] split = str2.split("/");
        String[] split2 = str.split("/");
        return b.a.a.a.a.a(!"*".equals(split[0]) ? split[0] : split2[0], "/", !"*".equals(split[1]) ? split[1] : split2[1]);
    }

    private <T> boolean search(MimedType<T> mimedType, ArrayDeque<PathInfo> arrayDeque, ArrayDeque<PathInfo> arrayDeque2, MimedType mimedType2, HashSet<MimedType> hashSet) {
        if (mimedType.isTypeOf(mimedType2)) {
            arrayDeque.clear();
            arrayDeque.addAll(arrayDeque2);
            return true;
        }
        boolean z = false;
        if ((!arrayDeque.isEmpty() && PathInfo.distance(arrayDeque2) >= PathInfo.distance(arrayDeque)) || hashSet.contains(mimedType2)) {
            return false;
        }
        hashSet.add(mimedType2);
        ConverterTransformers<Object, Object> all = this.outputs.getAll(mimedType2);
        for (K k : all.keySet()) {
            MimedType mimedType3 = new MimedType(k.type, mimeReplace(mimedType2.mime, k.mime));
            PathInfo pathInfo = new PathInfo();
            pathInfo.transformer = (MultiTransformer) all.get(k);
            pathInfo.mime = mimedType3.mime;
            pathInfo.candidate = k;
            arrayDeque2.addLast(pathInfo);
            try {
                z |= search(mimedType, arrayDeque, arrayDeque2, mimedType3, hashSet);
            } finally {
                arrayDeque2.removeLast();
            }
        }
        if (z) {
            hashSet.remove(mimedType2);
        }
        return z;
    }

    private final synchronized <T> Future<T> to(Class cls, Class<T> cls2, String str) {
        if (TextUtils.isEmpty(str)) {
            str = "*/*";
        }
        if (this.outputs == null) {
            this.outputs = new Converters<>();
            Iterator<ConverterEntry> it = getConverters().list.iterator();
            while (it.hasNext()) {
                ConverterEntry next = it.next();
                ((ConverterTransformers) this.outputs.ensure(next.from)).put(next.to, new MultiTransformer(next.typeConverter, next.to.mime, next.distance));
            }
        }
        MimedType mimedType = new MimedType(cls2, str);
        ArrayDeque arrayDeque = new ArrayDeque();
        if (search(mimedType, arrayDeque, new ArrayDeque(), new MimedType(cls, this.futureMime), new HashSet())) {
            PathInfo pathInfo = (PathInfo) arrayDeque.removeFirst();
            new SimpleFuture(new MimedData(this.future, this.futureMime)).setCallback(pathInfo.transformer);
            while (!arrayDeque.isEmpty()) {
                PathInfo pathInfo2 = (PathInfo) arrayDeque.removeFirst();
                pathInfo.transformer.setCallback(pathInfo2.transformer);
                pathInfo = pathInfo2;
            }
            return pathInfo.transformer.then(d.f7108a);
        }
        return new SimpleFuture((Exception) new InvalidObjectException("unable to find converter"));
    }

    /* access modifiers changed from: private */
    /* renamed from: to */
    public final synchronized <T> Future<T> a(Object obj, Class<T> cls, String str) {
        if (cls.isInstance(obj)) {
            return new SimpleFuture(obj);
        }
        return to((Class) obj.getClass(), cls, str);
    }

    public ConverterEntries getConverters() {
        return new ConverterEntries(Converters);
    }

    public final <T> Future<T> to(Class<T> cls) {
        return to(cls, (String) null);
    }

    public <T> Future<T> to(Class<T> cls, String str) {
        return this.future.then(new l(this, cls, str));
    }
}
