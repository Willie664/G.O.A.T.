package io.lum.sdk.async.future;

import d.a.a.b2.u.q;
import io.lum.sdk.async.future.SimpleFuture;
import java.util.ArrayList;
import java.util.Iterator;

public class MultiFuture<T> extends SimpleFuture<T> {
    public final SimpleFuture.FutureCallbackInternal<T> internalCallback = new q(this);
    public ArrayList<SimpleFuture.FutureCallbackInternal<T>> internalCallbacks;

    public MultiFuture() {
    }

    public MultiFuture(Future<T> future) {
        super(future);
    }

    public MultiFuture(Exception exc) {
        super(exc);
    }

    public MultiFuture(T t) {
        super(t);
    }

    public /* synthetic */ void a(Exception exc, Object obj, SimpleFuture.FutureCallsite futureCallsite) {
        ArrayList<SimpleFuture.FutureCallbackInternal<T>> arrayList;
        synchronized (this) {
            arrayList = this.internalCallbacks;
            this.internalCallbacks = null;
        }
        if (arrayList != null) {
            Iterator<SimpleFuture.FutureCallbackInternal<T>> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().onCompleted(exc, obj, futureCallsite);
            }
        }
    }

    public void setCallbackInternal(SimpleFuture.FutureCallsite futureCallsite, SimpleFuture.FutureCallbackInternal<T> futureCallbackInternal) {
        synchronized (this) {
            if (futureCallbackInternal != null) {
                if (this.internalCallbacks == null) {
                    this.internalCallbacks = new ArrayList<>();
                }
                this.internalCallbacks.add(futureCallbackInternal);
            }
        }
        super.setCallbackInternal(futureCallsite, this.internalCallback);
    }
}
