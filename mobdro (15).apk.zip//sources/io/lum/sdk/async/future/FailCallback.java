package io.lum.sdk.async.future;

public interface FailCallback {
    void fail(Exception exc);
}
