package io.lum.sdk.async.future;

public interface FailRecoverCallback<T> {
    Future<T> fail(Exception exc);
}
