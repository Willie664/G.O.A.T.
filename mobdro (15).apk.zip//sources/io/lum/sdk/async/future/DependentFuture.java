package io.lum.sdk.async.future;

public interface DependentFuture<T> extends DependentCancellable, Future<T> {
}
