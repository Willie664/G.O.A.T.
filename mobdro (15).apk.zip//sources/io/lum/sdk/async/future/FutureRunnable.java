package io.lum.sdk.async.future;

public interface FutureRunnable<T> {
    T run();
}
