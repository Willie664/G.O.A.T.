package io.lum.sdk.async.future;

public interface DependentCancellable extends Cancellable {
    boolean setParent(Cancellable cancellable);
}
