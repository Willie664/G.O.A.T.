package io.lum.sdk.async.future;

public abstract class TransformFuture<T, F> extends SimpleFuture<T> implements FutureCallback<F> {
    public TransformFuture() {
    }

    public TransformFuture(F f2) {
        onCompleted((Exception) null, f2);
    }

    public void error(Exception exc) {
        setComplete(exc);
    }

    public void onCompleted(Exception exc, F f2) {
        if (!isCancelled()) {
            if (exc != null) {
                error(exc);
                return;
            }
            try {
                transform(f2);
            } catch (Exception e2) {
                error(e2);
            }
        }
    }

    public abstract void transform(F f2);
}
