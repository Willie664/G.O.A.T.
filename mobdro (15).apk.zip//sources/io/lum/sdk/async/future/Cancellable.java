package io.lum.sdk.async.future;

public interface Cancellable {
    boolean cancel();

    boolean isCancelled();

    boolean isDone();
}
