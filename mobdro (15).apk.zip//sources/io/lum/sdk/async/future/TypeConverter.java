package io.lum.sdk.async.future;

public interface TypeConverter<T, F> {
    Future<T> convert(F f2, String str);
}
