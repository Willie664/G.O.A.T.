package io.lum.sdk.async.future;

public interface FailConvertCallback<T> {
    T fail(Exception exc);
}
