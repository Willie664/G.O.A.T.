package io.lum.sdk.async.future;

import d.a.a.b2.u.a0;
import d.a.a.b2.u.e0;
import d.a.a.b2.u.r;
import d.a.a.b2.u.s;
import d.a.a.b2.u.t;
import d.a.a.b2.u.u;
import d.a.a.b2.u.v;
import d.a.a.b2.u.w;
import d.a.a.b2.u.x;
import d.a.a.b2.u.y;
import d.a.a.b2.u.z;
import io.lum.sdk.async.AsyncSemaphore;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

public class SimpleFuture<T> extends SimpleCancellable implements DependentFuture<T> {
    public Exception exception;
    public FutureCallbackInternal<T> internalCallback;
    public T result;
    public boolean silent;
    public AsyncSemaphore waiter;

    public interface FutureCallbackInternal<T> {
        void onCompleted(Exception exc, T t, FutureCallsite futureCallsite);
    }

    public static class FutureCallsite {
        public FutureCallbackInternal callback;

        /* renamed from: e  reason: collision with root package name */
        public Exception f7914e;
        public Object result;

        public void loop() {
            while (true) {
                FutureCallbackInternal futureCallbackInternal = this.callback;
                if (futureCallbackInternal != null) {
                    Exception exc = this.f7914e;
                    Object obj = this.result;
                    this.callback = null;
                    this.f7914e = null;
                    this.result = null;
                    futureCallbackInternal.onCompleted(exc, obj, this);
                } else {
                    return;
                }
            }
        }
    }

    public SimpleFuture() {
    }

    public SimpleFuture(Future<T> future) {
        setComplete(future);
    }

    public SimpleFuture(Exception exc) {
        setComplete(exc);
    }

    public SimpleFuture(T t) {
        setComplete(t);
    }

    public static /* synthetic */ Future a(FailConvertCallback failConvertCallback, Exception exc) {
        return new SimpleFuture(failConvertCallback.fail(exc));
    }

    public static /* synthetic */ Future a(ThenCallback thenCallback, Object obj) {
        return new SimpleFuture(thenCallback.then(obj));
    }

    public static /* synthetic */ void a(DoneCallback doneCallback, SimpleFuture simpleFuture, Exception e2, Object obj, FutureCallsite futureCallsite) {
        if (e2 == null) {
            try {
                doneCallback.done(e2, obj);
            } catch (Exception e3) {
                e2 = e3;
            }
        }
        simpleFuture.setComplete(e2, obj, futureCallsite);
    }

    public static /* synthetic */ void a(SimpleFuture simpleFuture, FailRecoverCallback failRecoverCallback, Exception exc, Object obj, FutureCallsite futureCallsite) {
        if (exc == null) {
            simpleFuture.setComplete(exc, obj, futureCallsite);
            return;
        }
        try {
            simpleFuture.setComplete(failRecoverCallback.fail(exc), futureCallsite);
        } catch (Exception e2) {
            simpleFuture.setComplete(e2, (Object) null, futureCallsite);
        }
    }

    public static /* synthetic */ void a(SimpleFuture simpleFuture, ThenFutureCallback thenFutureCallback, Exception exc, Object obj, FutureCallsite futureCallsite) {
        if (exc != null) {
            simpleFuture.setComplete(exc, (Object) null, futureCallsite);
            return;
        }
        try {
            simpleFuture.setComplete(thenFutureCallback.then(obj), futureCallsite);
        } catch (Exception e2) {
            simpleFuture.setComplete(e2, (Object) null, futureCallsite);
        }
    }

    public static /* synthetic */ void a(SuccessCallback successCallback, SimpleFuture simpleFuture, Exception e2, Object obj, FutureCallsite futureCallsite) {
        if (e2 == null) {
            try {
                successCallback.success(obj);
            } catch (Exception e3) {
                e2 = e3;
            }
        }
        simpleFuture.setComplete(e2, obj, futureCallsite);
    }

    private boolean cancelInternal(boolean z) {
        FutureCallbackInternal handleInternalCompleteLocked;
        if (!super.cancel()) {
            return false;
        }
        synchronized (this) {
            this.exception = new CancellationException();
            releaseWaiterLocked();
            handleInternalCompleteLocked = handleInternalCompleteLocked();
            this.silent = z;
        }
        handleCallbackUnlocked((FutureCallsite) null, handleInternalCompleteLocked);
        return true;
    }

    private T getResultOrThrow() {
        if (this.exception == null) {
            return this.result;
        }
        throw new ExecutionException(this.exception);
    }

    private void handleCallbackUnlocked(FutureCallsite futureCallsite, FutureCallbackInternal<T> futureCallbackInternal) {
        if (!this.silent && futureCallbackInternal != null) {
            boolean z = false;
            if (futureCallsite == null) {
                z = true;
                futureCallsite = new FutureCallsite();
            }
            futureCallsite.callback = futureCallbackInternal;
            futureCallsite.f7914e = this.exception;
            futureCallsite.result = this.result;
            if (z) {
                futureCallsite.loop();
            }
        }
    }

    private FutureCallbackInternal<T> handleInternalCompleteLocked() {
        FutureCallbackInternal<T> futureCallbackInternal = this.internalCallback;
        this.internalCallback = null;
        return futureCallbackInternal;
    }

    private Future<T> setComplete(Future<T> future, FutureCallsite futureCallsite) {
        setParent(future);
        SimpleFuture simpleFuture = new SimpleFuture();
        if (future instanceof SimpleFuture) {
            ((SimpleFuture) future).setCallbackInternal(futureCallsite, new v(this, simpleFuture));
        } else {
            future.setCallback(new a0(this, simpleFuture));
        }
        return simpleFuture;
    }

    private boolean setComplete(Exception exc, T t, FutureCallsite futureCallsite) {
        synchronized (this) {
            if (!super.setComplete()) {
                return false;
            }
            this.result = t;
            this.exception = exc;
            releaseWaiterLocked();
            FutureCallbackInternal handleInternalCompleteLocked = handleInternalCompleteLocked();
            handleCallbackUnlocked(futureCallsite, handleInternalCompleteLocked);
            return true;
        }
    }

    public /* synthetic */ void a(SimpleFuture simpleFuture, Exception exc, Object obj) {
        CancellationException cancellationException = null;
        if (!setComplete(exc, obj, (FutureCallsite) null)) {
            cancellationException = new CancellationException();
        }
        simpleFuture.setComplete((Exception) cancellationException);
    }

    public /* synthetic */ void a(SimpleFuture simpleFuture, Exception exc, Object obj, FutureCallsite futureCallsite) {
        simpleFuture.setComplete(setComplete(exc, obj, futureCallsite) ? null : new CancellationException(), obj, futureCallsite);
    }

    public boolean cancel() {
        return cancelInternal(this.silent);
    }

    public boolean cancel(boolean z) {
        return cancel();
    }

    public boolean cancelSilently() {
        return cancelInternal(true);
    }

    public Future<T> done(DoneCallback<T> doneCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setParent(this);
        setCallbackInternal((FutureCallsite) null, new w(doneCallback, simpleFuture));
        return simpleFuture;
    }

    public AsyncSemaphore ensureWaiterLocked() {
        if (this.waiter == null) {
            this.waiter = new AsyncSemaphore();
        }
        return this.waiter;
    }

    public /* synthetic */ Future<T> executorThread(Executor executor) {
        return e0.$default$executorThread(this, executor);
    }

    public Future<T> fail(FailCallback failCallback) {
        return failRecover(new z(failCallback));
    }

    public Future<T> failConvert(FailConvertCallback<T> failConvertCallback) {
        return failRecover(new u(failConvertCallback));
    }

    public Future<T> failRecover(FailRecoverCallback<T> failRecoverCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setParent(this);
        setCallbackInternal((FutureCallsite) null, new s(simpleFuture, failRecoverCallback));
        return simpleFuture;
    }

    public T get() {
        synchronized (this) {
            if (!isCancelled()) {
                if (!isDone()) {
                    AsyncSemaphore ensureWaiterLocked = ensureWaiterLocked();
                    ensureWaiterLocked.acquire();
                    return getResultOrThrow();
                }
            }
            T resultOrThrow = getResultOrThrow();
            return resultOrThrow;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0017, code lost:
        if (r0.tryAcquire(r2, r4) == false) goto L_0x001e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001d, code lost:
        return getResultOrThrow();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0023, code lost:
        throw new java.util.concurrent.TimeoutException();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public T get(long r2, java.util.concurrent.TimeUnit r4) {
        /*
            r1 = this;
            monitor-enter(r1)
            boolean r0 = r1.isCancelled()     // Catch:{ all -> 0x002a }
            if (r0 != 0) goto L_0x0024
            boolean r0 = r1.isDone()     // Catch:{ all -> 0x002a }
            if (r0 == 0) goto L_0x000e
            goto L_0x0024
        L_0x000e:
            io.lum.sdk.async.AsyncSemaphore r0 = r1.ensureWaiterLocked()     // Catch:{ all -> 0x002a }
            monitor-exit(r1)     // Catch:{ all -> 0x002a }
            boolean r2 = r0.tryAcquire(r2, r4)
            if (r2 == 0) goto L_0x001e
            java.lang.Object r2 = r1.getResultOrThrow()
            return r2
        L_0x001e:
            java.util.concurrent.TimeoutException r2 = new java.util.concurrent.TimeoutException
            r2.<init>()
            throw r2
        L_0x0024:
            java.lang.Object r2 = r1.getResultOrThrow()     // Catch:{ all -> 0x002a }
            monitor-exit(r1)     // Catch:{ all -> 0x002a }
            return r2
        L_0x002a:
            r2 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x002a }
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.future.SimpleFuture.get(long, java.util.concurrent.TimeUnit):java.lang.Object");
    }

    @Deprecated
    public Object getCallback() {
        return this.internalCallback;
    }

    public void releaseWaiterLocked() {
        AsyncSemaphore asyncSemaphore = this.waiter;
        if (asyncSemaphore != null) {
            asyncSemaphore.release();
            this.waiter = null;
        }
    }

    public SimpleFuture<T> reset() {
        super.reset();
        this.result = null;
        this.exception = null;
        this.waiter = null;
        this.internalCallback = null;
        this.silent = false;
        return this;
    }

    public void setCallback(FutureCallback<T> futureCallback) {
        if (futureCallback == null) {
            setCallbackInternal((FutureCallsite) null, (FutureCallbackInternal) null);
        } else {
            setCallbackInternal((FutureCallsite) null, new t(futureCallback));
        }
    }

    public void setCallbackInternal(FutureCallsite futureCallsite, FutureCallbackInternal<T> futureCallbackInternal) {
        synchronized (this) {
            this.internalCallback = futureCallbackInternal;
            if (isDone() || isCancelled()) {
                FutureCallbackInternal handleInternalCompleteLocked = handleInternalCompleteLocked();
                handleCallbackUnlocked(futureCallsite, handleInternalCompleteLocked);
            }
        }
    }

    public Future<T> setComplete(Future<T> future) {
        return setComplete(future, (FutureCallsite) null);
    }

    public boolean setComplete() {
        return setComplete((Object) null);
    }

    public boolean setComplete(Exception exc) {
        return setComplete(exc, (Object) null, (FutureCallsite) null);
    }

    public boolean setComplete(Exception exc, T t) {
        return setComplete(exc, t, (FutureCallsite) null);
    }

    public boolean setComplete(T t) {
        return setComplete((Exception) null, t, (FutureCallsite) null);
    }

    public boolean setCompleteException(Exception exc) {
        return setComplete(exc, (Object) null, (FutureCallsite) null);
    }

    public Future<T> setCompleteFuture(Future<T> future) {
        return setComplete(future, (FutureCallsite) null);
    }

    public boolean setCompleteValue(T t) {
        return setComplete((Exception) null, t, (FutureCallsite) null);
    }

    public boolean setParent(Cancellable cancellable) {
        return super.setParent(cancellable);
    }

    public Future<T> success(SuccessCallback<T> successCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setParent(this);
        setCallbackInternal((FutureCallsite) null, new y(successCallback, simpleFuture));
        return simpleFuture;
    }

    public <R> Future<R> then(ThenFutureCallback<R, T> thenFutureCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setParent(this);
        setCallbackInternal((FutureCallsite) null, new r(simpleFuture, thenFutureCallback));
        return simpleFuture;
    }

    public <R> Future<R> thenConvert(ThenCallback<R, T> thenCallback) {
        return then(new x(thenCallback));
    }

    public T tryGet() {
        return this.result;
    }

    public Exception tryGetException() {
        return this.exception;
    }
}
