package io.lum.sdk.async.future;

public interface SuccessCallback<T> {
    void success(T t);
}
