package io.lum.sdk.async.future;

public interface ThenFutureCallback<T, F> {
    Future<T> then(F f2);
}
