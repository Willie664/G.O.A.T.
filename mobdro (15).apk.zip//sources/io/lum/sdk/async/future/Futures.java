package io.lum.sdk.async.future;

import d.a.a.b2.u.d0;
import d.a.a.b2.u.p;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Futures {
    public static <T, F> Future<T> loopUntil(Iterable<F> iterable, ThenFutureCallback<T, F> thenFutureCallback) {
        SimpleFuture simpleFuture = new SimpleFuture();
        loopUntil(iterable.iterator(), thenFutureCallback, simpleFuture, (Exception) null);
        return simpleFuture;
    }

    public static <T, F> Future<T> loopUntil(F[] fArr, ThenFutureCallback<T, F> thenFutureCallback) {
        return loopUntil(Arrays.asList(fArr), thenFutureCallback);
    }

    public static <T, F> void loopUntil(Iterator<F> it, ThenFutureCallback<T, F> thenFutureCallback, SimpleFuture<T> simpleFuture, Exception e2) {
        while (it.hasNext()) {
            try {
                Future<T> then = thenFutureCallback.then(it.next());
                simpleFuture.getClass();
                then.success(new d0(simpleFuture)).fail(new p(it, thenFutureCallback, simpleFuture));
                return;
            } catch (Exception e3) {
                e2 = e3;
            }
        }
        if (e2 == null) {
            simpleFuture.setComplete(new Exception("empty list"));
        } else {
            simpleFuture.setComplete(e2);
        }
    }

    public static <T> Future<List<T>> waitAll(final List<Future<T>> list) {
        final ArrayList arrayList = new ArrayList();
        final SimpleFuture simpleFuture = new SimpleFuture();
        if (list.isEmpty()) {
            simpleFuture.setComplete(arrayList);
            return simpleFuture;
        }
        list.get(0).setCallback(new FutureCallback<T>() {
            public int count = 0;

            public void onCompleted(Exception exc, T t) {
                arrayList.add(t);
                int i = this.count + 1;
                this.count = i;
                if (i < list.size()) {
                    ((Future) list.get(this.count)).setCallback(this);
                } else {
                    simpleFuture.setComplete(arrayList);
                }
            }
        });
        return simpleFuture;
    }

    public static <T> Future<List<T>> waitAll(Future<T>... futureArr) {
        return waitAll(Arrays.asList(futureArr));
    }
}
