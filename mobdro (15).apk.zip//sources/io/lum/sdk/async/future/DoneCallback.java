package io.lum.sdk.async.future;

public interface DoneCallback<T> {
    void done(Exception exc, T t);
}
