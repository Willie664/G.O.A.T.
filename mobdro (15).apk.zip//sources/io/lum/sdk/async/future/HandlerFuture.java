package io.lum.sdk.async.future;

import android.os.Handler;
import android.os.Looper;

public class HandlerFuture<T> extends SimpleFuture<T> {
    public Handler handler;

    public HandlerFuture() {
        Looper myLooper = Looper.myLooper();
        this.handler = new Handler(myLooper == null ? Looper.getMainLooper() : myLooper);
    }

    public void setCallback(final FutureCallback<T> futureCallback) {
        super.setCallback(new FutureCallback<T>() {
            public void onCompleted(final Exception exc, final T t) {
                if (Looper.myLooper() == HandlerFuture.this.handler.getLooper()) {
                    futureCallback.onCompleted(exc, t);
                } else {
                    HandlerFuture.this.handler.post(new Runnable() {
                        public void run() {
                            AnonymousClass1.this.onCompleted(exc, t);
                        }
                    });
                }
            }
        });
    }
}
