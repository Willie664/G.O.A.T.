package io.lum.sdk.async;

public interface AsyncSocket extends DataEmitter, DataSink {
    AsyncServer getServer();
}
