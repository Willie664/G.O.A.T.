package io.lum.sdk.async;

import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.util.StreamUtility;
import java.io.File;
import java.nio.channels.FileChannel;

public class FileDataEmitter extends DataEmitterBase {
    public DataCallback callback;
    public FileChannel channel;
    public File file;
    public boolean paused;
    public ByteBufferList pending = new ByteBufferList();
    public Runnable pumper = new Runnable() {
        /* JADX WARNING: Removed duplicated region for block: B:13:0x004d A[Catch:{ Exception -> 0x0073 }] */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x0046 A[SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r3 = this;
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                java.nio.channels.FileChannel r0 = r0.channel     // Catch:{ Exception -> 0x0073 }
                if (r0 != 0) goto L_0x0017
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                java.io.FileInputStream r1 = new java.io.FileInputStream     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r2 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                java.io.File r2 = r2.file     // Catch:{ Exception -> 0x0073 }
                r1.<init>(r2)     // Catch:{ Exception -> 0x0073 }
                java.nio.channels.FileChannel r1 = r1.getChannel()     // Catch:{ Exception -> 0x0073 }
                r0.channel = r1     // Catch:{ Exception -> 0x0073 }
            L_0x0017:
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x0073 }
                boolean r0 = r0.isEmpty()     // Catch:{ Exception -> 0x0073 }
                if (r0 != 0) goto L_0x0035
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r1 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r1 = r1.pending     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.Util.emitAllData(r0, r1)     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x0073 }
                boolean r0 = r0.isEmpty()     // Catch:{ Exception -> 0x0073 }
                if (r0 != 0) goto L_0x0035
                return
            L_0x0035:
                r0 = 8192(0x2000, float:1.14794E-41)
                java.nio.ByteBuffer r0 = io.lum.sdk.async.ByteBufferList.obtain(r0)     // Catch:{ Exception -> 0x0073 }
                r1 = -1
                io.lum.sdk.async.FileDataEmitter r2 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                java.nio.channels.FileChannel r2 = r2.channel     // Catch:{ Exception -> 0x0073 }
                int r2 = r2.read(r0)     // Catch:{ Exception -> 0x0073 }
                if (r1 != r2) goto L_0x004d
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                r1 = 0
                r0.report(r1)     // Catch:{ Exception -> 0x0073 }
                return
            L_0x004d:
                r0.flip()     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r1 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r1 = r1.pending     // Catch:{ Exception -> 0x0073 }
                r1.add((java.nio.ByteBuffer) r0)     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r1 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r1 = r1.pending     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.Util.emitAllData(r0, r1)     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x0073 }
                int r0 = r0.remaining()     // Catch:{ Exception -> 0x0073 }
                if (r0 != 0) goto L_0x0079
                io.lum.sdk.async.FileDataEmitter r0 = io.lum.sdk.async.FileDataEmitter.this     // Catch:{ Exception -> 0x0073 }
                boolean r0 = r0.isPaused()     // Catch:{ Exception -> 0x0073 }
                if (r0 == 0) goto L_0x0035
                goto L_0x0079
            L_0x0073:
                r0 = move-exception
                io.lum.sdk.async.FileDataEmitter r1 = io.lum.sdk.async.FileDataEmitter.this
                r1.report(r0)
            L_0x0079:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.FileDataEmitter.AnonymousClass1.run():void");
        }
    };
    public AsyncServer server;

    public FileDataEmitter(AsyncServer asyncServer, File file2) {
        this.server = asyncServer;
        this.file = file2;
        boolean z = !asyncServer.isAffinityThread();
        this.paused = z;
        if (!z) {
            doResume();
        }
    }

    private void doResume() {
        this.server.post(this.pumper);
    }

    public void close() {
        try {
            this.channel.close();
        } catch (Exception unused) {
        }
    }

    public DataCallback getDataCallback() {
        return this.callback;
    }

    public AsyncServer getServer() {
        return this.server;
    }

    public boolean isChunked() {
        return false;
    }

    public boolean isPaused() {
        return this.paused;
    }

    public void pause() {
        this.paused = true;
    }

    public void report(Exception exc) {
        StreamUtility.closeQuietly(this.channel);
        super.report(exc);
    }

    public void resume() {
        this.paused = false;
        doResume();
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.callback = dataCallback;
    }
}
