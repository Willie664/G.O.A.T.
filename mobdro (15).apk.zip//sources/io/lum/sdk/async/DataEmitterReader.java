package io.lum.sdk.async;

import io.lum.sdk.async.callback.DataCallback;

public class DataEmitterReader implements DataCallback {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public ByteBufferList mPendingData = new ByteBufferList();
    public DataCallback mPendingRead;
    public int mPendingReadLength;

    private boolean handlePendingData(DataEmitter dataEmitter) {
        if (this.mPendingReadLength > this.mPendingData.remaining()) {
            return false;
        }
        DataCallback dataCallback = this.mPendingRead;
        this.mPendingRead = null;
        dataCallback.onDataAvailable(dataEmitter, this.mPendingData);
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDataAvailable(io.lum.sdk.async.DataEmitter r4, io.lum.sdk.async.ByteBufferList r5) {
        /*
            r3 = this;
        L_0x0000:
            int r0 = r5.remaining()
            int r1 = r3.mPendingReadLength
            io.lum.sdk.async.ByteBufferList r2 = r3.mPendingData
            int r2 = r2.remaining()
            int r1 = r1 - r2
            int r0 = java.lang.Math.min(r0, r1)
            io.lum.sdk.async.ByteBufferList r1 = r3.mPendingData
            r5.get(r1, r0)
            r5.remaining()
            boolean r0 = r3.handlePendingData(r4)
            if (r0 == 0) goto L_0x0023
            io.lum.sdk.async.callback.DataCallback r0 = r3.mPendingRead
            if (r0 != 0) goto L_0x0000
        L_0x0023:
            r5.remaining()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.DataEmitterReader.onDataAvailable(io.lum.sdk.async.DataEmitter, io.lum.sdk.async.ByteBufferList):void");
    }

    public void read(int i, DataCallback dataCallback) {
        this.mPendingReadLength = i;
        this.mPendingRead = dataCallback;
        this.mPendingData.recycle();
    }
}
