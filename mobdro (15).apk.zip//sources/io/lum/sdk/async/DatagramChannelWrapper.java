package io.lum.sdk.async;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;

public class DatagramChannelWrapper extends ChannelWrapper {
    public InetSocketAddress address;
    public DatagramChannel mChannel;

    public DatagramChannelWrapper(DatagramChannel datagramChannel) {
        super(datagramChannel);
        this.mChannel = datagramChannel;
    }

    public void disconnect() {
        this.mChannel.disconnect();
    }

    public InetAddress getLocalAddress() {
        return this.mChannel.socket().getLocalAddress();
    }

    public int getLocalPort() {
        return this.mChannel.socket().getLocalPort();
    }

    public InetSocketAddress getRemoteAddress() {
        return this.address;
    }

    public Object getSocket() {
        return this.mChannel.socket();
    }

    public boolean isChunked() {
        return true;
    }

    public boolean isConnected() {
        return this.mChannel.isConnected();
    }

    public int read(ByteBuffer byteBuffer) {
        if (!isConnected()) {
            int position = byteBuffer.position();
            InetSocketAddress inetSocketAddress = (InetSocketAddress) this.mChannel.receive(byteBuffer);
            this.address = inetSocketAddress;
            if (inetSocketAddress == null) {
                return -1;
            }
            return byteBuffer.position() - position;
        }
        this.address = null;
        return this.mChannel.read(byteBuffer);
    }

    public long read(ByteBuffer[] byteBufferArr) {
        return this.mChannel.read(byteBufferArr);
    }

    public long read(ByteBuffer[] byteBufferArr, int i, int i2) {
        return this.mChannel.read(byteBufferArr, i, i2);
    }

    public SelectionKey register(Selector selector) {
        return register(selector, 1);
    }

    public SelectionKey register(Selector selector, int i) {
        return this.mChannel.register(selector, i);
    }

    public void shutdownInput() {
    }

    public void shutdownOutput() {
    }

    public int write(ByteBuffer byteBuffer) {
        return this.mChannel.write(byteBuffer);
    }

    public int write(ByteBuffer[] byteBufferArr) {
        return (int) this.mChannel.write(byteBufferArr);
    }
}
