package io.lum.sdk.async;

import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.ScatteringByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.spi.AbstractSelectableChannel;

public abstract class ChannelWrapper implements ReadableByteChannel, ScatteringByteChannel {
    public AbstractSelectableChannel mChannel;

    public ChannelWrapper(AbstractSelectableChannel abstractSelectableChannel) {
        abstractSelectableChannel.configureBlocking(false);
        this.mChannel = abstractSelectableChannel;
    }

    public void close() {
        this.mChannel.close();
    }

    public abstract InetAddress getLocalAddress();

    public abstract int getLocalPort();

    public abstract Object getSocket();

    public boolean isChunked() {
        return false;
    }

    public abstract boolean isConnected();

    public boolean isOpen() {
        return this.mChannel.isOpen();
    }

    public abstract SelectionKey register(Selector selector);

    public SelectionKey register(Selector selector, int i) {
        return this.mChannel.register(selector, i);
    }

    public abstract void shutdownInput();

    public abstract void shutdownOutput();

    public abstract int write(ByteBuffer byteBuffer);

    public abstract int write(ByteBuffer[] byteBufferArr);
}
