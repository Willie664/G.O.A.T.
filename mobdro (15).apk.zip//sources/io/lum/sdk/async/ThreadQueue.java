package io.lum.sdk.async;

import java.util.LinkedList;
import java.util.WeakHashMap;
import java.util.concurrent.Semaphore;

public class ThreadQueue extends LinkedList<Runnable> {
    public static final WeakHashMap<Thread, ThreadQueue> mThreadQueues = new WeakHashMap<>();
    public Semaphore queueSemaphore = new Semaphore(0);
    public AsyncSemaphore waiter;

    public static ThreadQueue getOrCreateThreadQueue(Thread thread) {
        ThreadQueue threadQueue;
        synchronized (mThreadQueues) {
            threadQueue = mThreadQueues.get(thread);
            if (threadQueue == null) {
                threadQueue = new ThreadQueue();
                mThreadQueues.put(thread, threadQueue);
            }
        }
        return threadQueue;
    }

    public static void release(AsyncSemaphore asyncSemaphore) {
        synchronized (mThreadQueues) {
            for (ThreadQueue next : mThreadQueues.values()) {
                if (next.waiter == asyncSemaphore) {
                    next.queueSemaphore.release();
                }
            }
        }
    }

    public boolean add(Runnable runnable) {
        boolean add;
        synchronized (this) {
            add = super.add(runnable);
        }
        return add;
    }

    public Runnable remove() {
        synchronized (this) {
            if (isEmpty()) {
                return null;
            }
            Runnable runnable = (Runnable) super.remove();
            return runnable;
        }
    }

    public boolean remove(Object obj) {
        boolean remove;
        synchronized (this) {
            remove = super.remove(obj);
        }
        return remove;
    }
}
