package io.lum.sdk.async;

import android.annotation.TargetApi;
import android.os.Looper;
import io.lum.sdk.async.util.ArrayDeque;
import io.lum.sdk.async.util.Charsets;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;

@TargetApi(9)
public class ByteBufferList {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final ByteBuffer EMPTY_BYTEBUFFER = ByteBuffer.allocate(0);
    public static final Object LOCK = new Object();
    public static int MAX_ITEM_SIZE = 262144;
    public static int MAX_SIZE = 1048576;
    public static int currentSize = 0;
    public static int maxItem = 0;
    public static PriorityQueue<ByteBuffer> reclaimed = new PriorityQueue<>(8, new Reclaimer());
    public ArrayDeque<ByteBuffer> mBuffers = new ArrayDeque<>();
    public ByteOrder order = ByteOrder.BIG_ENDIAN;
    public int remaining = 0;

    public static class Reclaimer implements Comparator<ByteBuffer> {
        public int compare(ByteBuffer byteBuffer, ByteBuffer byteBuffer2) {
            if (byteBuffer.capacity() == byteBuffer2.capacity()) {
                return 0;
            }
            return byteBuffer.capacity() > byteBuffer2.capacity() ? 1 : -1;
        }
    }

    public ByteBufferList() {
    }

    public ByteBufferList(byte[] bArr) {
        add(ByteBuffer.wrap(bArr));
    }

    public ByteBufferList(ByteBuffer... byteBufferArr) {
        addAll(byteBufferArr);
    }

    private void addRemaining(int i) {
        if (remaining() >= 0) {
            this.remaining += i;
        }
    }

    public static ByteBuffer deepCopy(ByteBuffer byteBuffer) {
        if (byteBuffer == null) {
            return null;
        }
        return (ByteBuffer) obtain(byteBuffer.remaining()).put(byteBuffer.duplicate()).flip();
    }

    public static PriorityQueue<ByteBuffer> getReclaimed() {
        Looper mainLooper = Looper.getMainLooper();
        if (mainLooper == null || Thread.currentThread() != mainLooper.getThread()) {
            return reclaimed;
        }
        return null;
    }

    public static ByteBuffer obtain(int i) {
        PriorityQueue<ByteBuffer> reclaimed2;
        ByteBuffer byteBuffer;
        if (i <= maxItem && (reclaimed2 = getReclaimed()) != null) {
            synchronized (LOCK) {
                do {
                    if (reclaimed2.size() > 0) {
                        byteBuffer = (ByteBuffer) reclaimed2.remove();
                        if (reclaimed2.size() == 0) {
                            maxItem = 0;
                        }
                        currentSize -= byteBuffer.capacity();
                    }
                } while (byteBuffer.capacity() < i);
                return byteBuffer;
            }
        }
        return ByteBuffer.allocate(Math.max(8192, i));
    }

    public static void obtainArray(ByteBuffer[] byteBufferArr, int i) {
        int i2;
        PriorityQueue<ByteBuffer> reclaimed2 = getReclaimed();
        int i3 = 0;
        if (reclaimed2 != null) {
            synchronized (LOCK) {
                i2 = 0;
                while (reclaimed2.size() > 0 && i3 < i && i2 < byteBufferArr.length - 1) {
                    ByteBuffer byteBuffer = (ByteBuffer) reclaimed2.remove();
                    currentSize -= byteBuffer.capacity();
                    i3 += Math.min(i - i3, byteBuffer.capacity());
                    byteBufferArr[i2] = byteBuffer;
                    i2++;
                }
            }
        } else {
            i2 = 0;
        }
        if (i3 < i) {
            byteBufferArr[i2] = ByteBuffer.allocate(Math.max(8192, i - i3));
            i2++;
        }
        while (i2 < byteBufferArr.length) {
            byteBufferArr[i2] = EMPTY_BYTEBUFFER;
            i2++;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.nio.ByteBuffer read(int r8) {
        /*
            r7 = this;
            int r0 = r7.remaining()
            if (r0 < r8) goto L_0x0077
        L_0x0006:
            io.lum.sdk.async.util.ArrayDeque<java.nio.ByteBuffer> r0 = r7.mBuffers
            java.lang.Object r0 = r0.peek()
            java.nio.ByteBuffer r0 = (java.nio.ByteBuffer) r0
            if (r0 == 0) goto L_0x0022
            boolean r1 = r0.hasRemaining()
            if (r1 != 0) goto L_0x0022
            io.lum.sdk.async.util.ArrayDeque<java.nio.ByteBuffer> r0 = r7.mBuffers
            java.lang.Object r0 = r0.remove()
            java.nio.ByteBuffer r0 = (java.nio.ByteBuffer) r0
            reclaim(r0)
            goto L_0x0006
        L_0x0022:
            if (r0 != 0) goto L_0x0027
            java.nio.ByteBuffer r8 = EMPTY_BYTEBUFFER
            return r8
        L_0x0027:
            int r1 = r0.remaining()
            if (r1 < r8) goto L_0x002e
            goto L_0x0070
        L_0x002e:
            java.nio.ByteBuffer r0 = obtain(r8)
            r0.limit(r8)
            byte[] r1 = r0.array()
            r2 = 0
            r3 = 0
        L_0x003b:
            r4 = r3
        L_0x003c:
            if (r2 >= r8) goto L_0x005e
            io.lum.sdk.async.util.ArrayDeque<java.nio.ByteBuffer> r4 = r7.mBuffers
            java.lang.Object r4 = r4.remove()
            java.nio.ByteBuffer r4 = (java.nio.ByteBuffer) r4
            int r5 = r8 - r2
            int r6 = r4.remaining()
            int r5 = java.lang.Math.min(r5, r6)
            r4.get(r1, r2, r5)
            int r2 = r2 + r5
            int r5 = r4.remaining()
            if (r5 != 0) goto L_0x003c
            reclaim(r4)
            goto L_0x003b
        L_0x005e:
            if (r4 == 0) goto L_0x006b
            int r8 = r4.remaining()
            if (r8 <= 0) goto L_0x006b
            io.lum.sdk.async.util.ArrayDeque<java.nio.ByteBuffer> r8 = r7.mBuffers
            r8.addFirst(r4)
        L_0x006b:
            io.lum.sdk.async.util.ArrayDeque<java.nio.ByteBuffer> r8 = r7.mBuffers
            r8.addFirst(r0)
        L_0x0070:
            java.nio.ByteOrder r8 = r7.order
            java.nio.ByteBuffer r8 = r0.order(r8)
            return r8
        L_0x0077:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "count : "
            java.lang.StringBuilder r1 = b.a.a.a.a.a(r1)
            int r2 = r7.remaining()
            r1.append(r2)
            java.lang.String r2 = "/"
            r1.append(r2)
            r1.append(r8)
            java.lang.String r8 = r1.toString()
            r0.<init>(r8)
            goto L_0x0097
        L_0x0096:
            throw r0
        L_0x0097:
            goto L_0x0096
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.ByteBufferList.read(int):java.nio.ByteBuffer");
    }

    public static void reclaim(ByteBuffer byteBuffer) {
        PriorityQueue<ByteBuffer> reclaimed2;
        if (byteBuffer != null && !byteBuffer.isDirect() && byteBuffer.arrayOffset() == 0 && byteBuffer.array().length == byteBuffer.capacity() && byteBuffer.capacity() >= 8192 && byteBuffer.capacity() <= MAX_ITEM_SIZE && (reclaimed2 = getReclaimed()) != null) {
            synchronized (LOCK) {
                while (currentSize > MAX_SIZE && reclaimed2.size() > 0 && reclaimed2.peek().capacity() < byteBuffer.capacity()) {
                    currentSize -= ((ByteBuffer) reclaimed2.remove()).capacity();
                }
                if (currentSize <= MAX_SIZE) {
                    byteBuffer.position(0);
                    byteBuffer.limit(byteBuffer.capacity());
                    currentSize += byteBuffer.capacity();
                    reclaimed2.add(byteBuffer);
                    maxItem = Math.max(maxItem, byteBuffer.capacity());
                }
            }
        }
    }

    public static boolean reclaimedContains(ByteBuffer byteBuffer) {
        Iterator<ByteBuffer> it = reclaimed.iterator();
        while (it.hasNext()) {
            if (it.next() == byteBuffer) {
                return true;
            }
        }
        return false;
    }

    public static void setMaxItemSize(int i) {
        MAX_ITEM_SIZE = i;
    }

    public static void setMaxPoolSize(int i) {
        MAX_SIZE = i;
    }

    public static void writeOutputStream(OutputStream outputStream, ByteBuffer byteBuffer) {
        int i;
        int i2;
        byte[] bArr;
        if (byteBuffer.isDirect()) {
            bArr = new byte[byteBuffer.remaining()];
            i2 = 0;
            i = byteBuffer.remaining();
            byteBuffer.get(bArr);
        } else {
            bArr = byteBuffer.array();
            i2 = byteBuffer.arrayOffset() + byteBuffer.position();
            i = byteBuffer.remaining();
        }
        outputStream.write(bArr, i2, i);
    }

    public ByteBufferList add(ByteBufferList byteBufferList) {
        byteBufferList.get(this);
        return this;
    }

    public ByteBufferList add(ByteBuffer byteBuffer) {
        if (byteBuffer.remaining() <= 0) {
            reclaim(byteBuffer);
            return this;
        }
        addRemaining(byteBuffer.remaining());
        if (this.mBuffers.size() > 0) {
            ByteBuffer last = this.mBuffers.getLast();
            if (last.capacity() - last.limit() >= byteBuffer.remaining()) {
                last.mark();
                last.position(last.limit());
                last.limit(last.capacity());
                last.put(byteBuffer);
                last.limit(last.position());
                last.reset();
                reclaim(byteBuffer);
                trim();
                return this;
            }
        }
        this.mBuffers.add(byteBuffer);
        trim();
        return this;
    }

    public ByteBufferList addAll(ByteBufferList... byteBufferListArr) {
        for (ByteBufferList byteBufferList : byteBufferListArr) {
            byteBufferList.get(this);
        }
        return this;
    }

    public ByteBufferList addAll(ByteBuffer... byteBufferArr) {
        for (ByteBuffer add : byteBufferArr) {
            add(add);
        }
        return this;
    }

    public void addFirst(ByteBuffer byteBuffer) {
        if (byteBuffer.remaining() <= 0) {
            reclaim(byteBuffer);
            return;
        }
        addRemaining(byteBuffer.remaining());
        if (this.mBuffers.size() > 0) {
            ByteBuffer first = this.mBuffers.getFirst();
            if (first.position() >= byteBuffer.remaining()) {
                first.position(first.position() - byteBuffer.remaining());
                first.mark();
                first.put(byteBuffer);
                first.reset();
                reclaim(byteBuffer);
                return;
            }
        }
        this.mBuffers.addFirst(byteBuffer);
    }

    public byte get() {
        byte b2 = read(1).get();
        this.remaining--;
        return b2;
    }

    public ByteBufferList get(int i) {
        ByteBufferList byteBufferList = new ByteBufferList();
        get(byteBufferList, i);
        return byteBufferList.order(this.order);
    }

    public void get(ByteBufferList byteBufferList) {
        get(byteBufferList, remaining());
    }

    public void get(ByteBufferList byteBufferList, int i) {
        if (remaining() >= i) {
            int i2 = 0;
            while (true) {
                if (i2 >= i) {
                    break;
                }
                ByteBuffer remove = this.mBuffers.remove();
                int remaining2 = remove.remaining();
                if (remaining2 == 0) {
                    reclaim(remove);
                } else {
                    int i3 = remaining2 + i2;
                    if (i3 > i) {
                        int i4 = i - i2;
                        ByteBuffer obtain = obtain(i4);
                        obtain.limit(i4);
                        remove.get(obtain.array(), 0, i4);
                        byteBufferList.add(obtain);
                        this.mBuffers.addFirst(remove);
                        break;
                    }
                    byteBufferList.add(remove);
                    i2 = i3;
                }
            }
            this.remaining -= i;
            return;
        }
        throw new IllegalArgumentException("length");
    }

    public void get(byte[] bArr) {
        get(bArr, 0, bArr.length);
    }

    public void get(byte[] bArr, int i, int i2) {
        if (remaining() >= i2) {
            int i3 = i2;
            while (i3 > 0) {
                ByteBuffer peek = this.mBuffers.peek();
                int min = Math.min(peek.remaining(), i3);
                if (bArr != null) {
                    peek.get(bArr, i, min);
                } else {
                    peek.position(peek.position() + min);
                }
                i3 -= min;
                i += min;
                if (peek.remaining() == 0) {
                    ByteBuffer remove = this.mBuffers.remove();
                    reclaim(peek);
                }
            }
            this.remaining -= i2;
            return;
        }
        throw new IllegalArgumentException("length");
    }

    public ByteBuffer getAll() {
        if (remaining() == 0) {
            return EMPTY_BYTEBUFFER;
        }
        read(remaining());
        return remove();
    }

    public ByteBuffer[] getAllArray() {
        ByteBuffer[] byteBufferArr = (ByteBuffer[]) this.mBuffers.toArray(new ByteBuffer[this.mBuffers.size()]);
        this.mBuffers.clear();
        this.remaining = 0;
        return byteBufferArr;
    }

    public byte[] getAllByteArray() {
        byte[] bArr = new byte[remaining()];
        get(bArr);
        return bArr;
    }

    public char getByteChar() {
        char c2 = (char) read(1).get();
        this.remaining--;
        return c2;
    }

    public byte[] getBytes(int i) {
        byte[] bArr = new byte[i];
        get(bArr);
        return bArr;
    }

    public int getInt() {
        int i = read(4).getInt();
        this.remaining -= 4;
        return i;
    }

    public long getLong() {
        long j = read(8).getLong();
        this.remaining -= 8;
        return j;
    }

    public short getShort() {
        short s = read(2).getShort();
        this.remaining -= 2;
        return s;
    }

    public boolean hasRemaining() {
        return remaining() > 0;
    }

    public boolean isEmpty() {
        return this.remaining == 0;
    }

    public ByteBufferList order(ByteOrder byteOrder) {
        this.order = byteOrder;
        return this;
    }

    public ByteOrder order() {
        return this.order;
    }

    public byte peek() {
        return read(1).get(this.mBuffers.peekFirst().position());
    }

    public byte[] peekBytes(int i) {
        byte[] bArr = new byte[i];
        read(i).get(bArr, this.mBuffers.peekFirst().position(), i);
        return bArr;
    }

    public int peekInt() {
        return read(4).getInt(this.mBuffers.peekFirst().position());
    }

    public long peekLong() {
        return read(8).getLong(this.mBuffers.peekFirst().position());
    }

    public short peekShort() {
        return read(2).getShort(this.mBuffers.peekFirst().position());
    }

    public String peekString() {
        return peekString((Charset) null);
    }

    public String peekString(Charset charset) {
        int i;
        int i2;
        byte[] bArr;
        if (charset == null) {
            charset = Charsets.UTF_8;
        }
        StringBuilder sb = new StringBuilder();
        Iterator<ByteBuffer> it = this.mBuffers.iterator();
        while (it.hasNext()) {
            ByteBuffer next = it.next();
            if (next.isDirect()) {
                bArr = new byte[next.remaining()];
                i2 = 0;
                i = next.remaining();
                next.get(bArr);
            } else {
                bArr = next.array();
                i2 = next.arrayOffset() + next.position();
                i = next.remaining();
            }
            sb.append(new String(bArr, i2, i, charset));
        }
        return sb.toString();
    }

    public String readString() {
        return readString((Charset) null);
    }

    public String readString(Charset charset) {
        String peekString = peekString(charset);
        recycle();
        return peekString;
    }

    public void recycle() {
        while (this.mBuffers.size() > 0) {
            reclaim(this.mBuffers.remove());
        }
        this.remaining = 0;
    }

    public int remaining() {
        return this.remaining;
    }

    public ByteBuffer remove() {
        ByteBuffer remove = this.mBuffers.remove();
        this.remaining -= remove.remaining();
        return remove;
    }

    public int size() {
        return this.mBuffers.size();
    }

    public ByteBufferList skip(int i) {
        get((byte[]) null, 0, i);
        return this;
    }

    public void spewString() {
        System.out.println(peekString());
    }

    public void trim() {
        read(0);
    }
}
