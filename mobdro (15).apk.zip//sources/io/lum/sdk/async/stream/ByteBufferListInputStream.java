package io.lum.sdk.async.stream;

import io.lum.sdk.Base64;
import io.lum.sdk.async.ByteBufferList;
import java.io.InputStream;

public class ByteBufferListInputStream extends InputStream {
    public ByteBufferList bb;

    public ByteBufferListInputStream(ByteBufferList byteBufferList) {
        this.bb = byteBufferList;
    }

    public int read() {
        if (this.bb.remaining() <= 0) {
            return -1;
        }
        return this.bb.get() & Base64.EQUALS_SIGN_ENC;
    }

    public int read(byte[] bArr) {
        return read(bArr, 0, bArr.length);
    }

    public int read(byte[] bArr, int i, int i2) {
        if (this.bb.remaining() <= 0) {
            return -1;
        }
        int min = Math.min(i2, this.bb.remaining());
        this.bb.get(bArr, i, min);
        return min;
    }
}
