package io.lum.sdk.async.stream;

import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.WritableCallback;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class OutputStreamDataSink implements DataSink {
    public Exception closeException;
    public boolean closeReported;
    public CompletedCallback mClosedCallback;
    public OutputStream mStream;
    public WritableCallback mWritable;
    public WritableCallback outputStreamCallback;
    public AsyncServer server;

    public OutputStreamDataSink(AsyncServer asyncServer) {
        this(asyncServer, (OutputStream) null);
    }

    public OutputStreamDataSink(AsyncServer asyncServer, OutputStream outputStream) {
        this.server = asyncServer;
        setOutputStream(outputStream);
    }

    public void end() {
        try {
            if (this.mStream != null) {
                this.mStream.close();
            }
            reportClose((Exception) null);
        } catch (IOException e2) {
            reportClose(e2);
        }
    }

    public CompletedCallback getClosedCallback() {
        return this.mClosedCallback;
    }

    public OutputStream getOutputStream() {
        return this.mStream;
    }

    public AsyncServer getServer() {
        return this.server;
    }

    public WritableCallback getWriteableCallback() {
        return this.mWritable;
    }

    public boolean isOpen() {
        return this.closeReported;
    }

    public void reportClose(Exception exc) {
        if (!this.closeReported) {
            this.closeReported = true;
            this.closeException = exc;
            CompletedCallback completedCallback = this.mClosedCallback;
            if (completedCallback != null) {
                completedCallback.onCompleted(exc);
            }
        }
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        this.mClosedCallback = completedCallback;
    }

    public void setOutputStream(OutputStream outputStream) {
        this.mStream = outputStream;
    }

    public void setOutputStreamWritableCallback(WritableCallback writableCallback) {
        this.outputStreamCallback = writableCallback;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        this.mWritable = writableCallback;
    }

    public void write(ByteBufferList byteBufferList) {
        while (byteBufferList.size() > 0) {
            try {
                ByteBuffer remove = byteBufferList.remove();
                getOutputStream().write(remove.array(), remove.arrayOffset() + remove.position(), remove.remaining());
                ByteBufferList.reclaim(remove);
            } catch (IOException e2) {
                reportClose(e2);
            } catch (Throwable th) {
                byteBufferList.recycle();
                throw th;
            }
        }
        byteBufferList.recycle();
    }
}
