package io.lum.sdk.async.stream;

import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import java.io.InputStream;

public class InputStreamDataEmitter implements DataEmitter {
    public DataCallback callback;
    public CompletedCallback endCallback;
    public InputStream inputStream;
    public int mToAlloc = 0;
    public boolean paused;
    public ByteBufferList pending = new ByteBufferList();
    public Runnable pumper = new Runnable() {
        /* JADX WARNING: Removed duplicated region for block: B:10:0x004d A[Catch:{ Exception -> 0x007e }] */
        /* JADX WARNING: Removed duplicated region for block: B:17:0x0046 A[SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r4 = this;
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x007e }
                boolean r0 = r0.isEmpty()     // Catch:{ Exception -> 0x007e }
                if (r0 != 0) goto L_0x0023
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.AsyncServer r0 = r0.getServer()     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter$2$1 r1 = new io.lum.sdk.async.stream.InputStreamDataEmitter$2$1     // Catch:{ Exception -> 0x007e }
                r1.<init>()     // Catch:{ Exception -> 0x007e }
                r0.run(r1)     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x007e }
                boolean r0 = r0.isEmpty()     // Catch:{ Exception -> 0x007e }
                if (r0 != 0) goto L_0x0023
                return
            L_0x0023:
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                int r0 = r0.mToAlloc     // Catch:{ Exception -> 0x007e }
                r1 = 4096(0x1000, float:5.74E-42)
                int r0 = java.lang.Math.max(r0, r1)     // Catch:{ Exception -> 0x007e }
                r1 = 262144(0x40000, float:3.67342E-40)
                int r0 = java.lang.Math.min(r0, r1)     // Catch:{ Exception -> 0x007e }
                java.nio.ByteBuffer r0 = io.lum.sdk.async.ByteBufferList.obtain(r0)     // Catch:{ Exception -> 0x007e }
                r1 = -1
                io.lum.sdk.async.stream.InputStreamDataEmitter r2 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                java.io.InputStream r2 = r2.inputStream     // Catch:{ Exception -> 0x007e }
                byte[] r3 = r0.array()     // Catch:{ Exception -> 0x007e }
                int r2 = r2.read(r3)     // Catch:{ Exception -> 0x007e }
                if (r1 != r2) goto L_0x004d
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                r1 = 0
                r0.report(r1)     // Catch:{ Exception -> 0x007e }
                return
            L_0x004d:
                io.lum.sdk.async.stream.InputStreamDataEmitter r1 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                int r3 = r2 * 2
                r1.mToAlloc = r3     // Catch:{ Exception -> 0x007e }
                r0.limit(r2)     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter r1 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.ByteBufferList r1 = r1.pending     // Catch:{ Exception -> 0x007e }
                r1.add((java.nio.ByteBuffer) r0)     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.AsyncServer r0 = r0.getServer()     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter$2$2 r1 = new io.lum.sdk.async.stream.InputStreamDataEmitter$2$2     // Catch:{ Exception -> 0x007e }
                r1.<init>()     // Catch:{ Exception -> 0x007e }
                r0.run(r1)     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                io.lum.sdk.async.ByteBufferList r0 = r0.pending     // Catch:{ Exception -> 0x007e }
                int r0 = r0.remaining()     // Catch:{ Exception -> 0x007e }
                if (r0 != 0) goto L_0x0084
                io.lum.sdk.async.stream.InputStreamDataEmitter r0 = io.lum.sdk.async.stream.InputStreamDataEmitter.this     // Catch:{ Exception -> 0x007e }
                boolean r0 = r0.isPaused()     // Catch:{ Exception -> 0x007e }
                if (r0 == 0) goto L_0x0023
                goto L_0x0084
            L_0x007e:
                r0 = move-exception
                io.lum.sdk.async.stream.InputStreamDataEmitter r1 = io.lum.sdk.async.stream.InputStreamDataEmitter.this
                r1.report(r0)
            L_0x0084:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.stream.InputStreamDataEmitter.AnonymousClass2.run():void");
        }
    };
    public AsyncServer server;

    public InputStreamDataEmitter(AsyncServer asyncServer, InputStream inputStream2) {
        this.server = asyncServer;
        this.inputStream = inputStream2;
        doResume();
    }

    private void doResume() {
        new Thread(this.pumper).start();
    }

    /* access modifiers changed from: private */
    public void report(final Exception exc) {
        getServer().post(new Runnable() {
            public void run() {
                Exception e2 = exc;
                try {
                    InputStreamDataEmitter.this.inputStream.close();
                } catch (Exception e3) {
                    e2 = e3;
                }
                CompletedCallback completedCallback = InputStreamDataEmitter.this.endCallback;
                if (completedCallback != null) {
                    completedCallback.onCompleted(e2);
                }
            }
        });
    }

    public String charset() {
        return null;
    }

    public void close() {
        report((Exception) null);
        try {
            this.inputStream.close();
        } catch (Exception unused) {
        }
    }

    public DataCallback getDataCallback() {
        return this.callback;
    }

    public CompletedCallback getEndCallback() {
        return this.endCallback;
    }

    public AsyncServer getServer() {
        return this.server;
    }

    public boolean isChunked() {
        return false;
    }

    public boolean isPaused() {
        return this.paused;
    }

    public void pause() {
        this.paused = true;
    }

    public void resume() {
        this.paused = false;
        doResume();
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.callback = dataCallback;
    }

    public void setEndCallback(CompletedCallback completedCallback) {
        this.endCallback = completedCallback;
    }
}
