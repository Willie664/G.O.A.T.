package io.lum.sdk.async.stream;

import io.lum.sdk.async.AsyncServer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class FileDataSink extends OutputStreamDataSink {
    public File file;

    public FileDataSink(AsyncServer asyncServer, File file2) {
        super(asyncServer);
        this.file = file2;
    }

    public OutputStream getOutputStream() {
        OutputStream outputStream = super.getOutputStream();
        if (outputStream != null) {
            return outputStream;
        }
        FileOutputStream fileOutputStream = new FileOutputStream(this.file);
        setOutputStream(fileOutputStream);
        return fileOutputStream;
    }
}
