package io.lum.sdk.async;

import android.content.Context;
import android.util.Base64;
import android.util.Pair;
import d.a.a.b2.a;
import d.a.a.b2.b;
import d.a.a.b2.c;
import d.a.a.b2.d;
import d.a.a.b2.e;
import d.a.a.b2.f;
import d.a.a.b2.g;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.ListenCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.SimpleCancellable;
import io.lum.sdk.async.http.SSLEngineSNIConfigurator;
import io.lum.sdk.async.util.Allocator;
import io.lum.sdk.async.util.StreamUtility;
import io.lum.sdk.async.wrapper.AsyncSocketWrapper;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigInteger;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Calendar;
import java.util.Date;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.StrictHostnameVerifier;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

public class AsyncSSLSocketWrapper implements AsyncSSLSocket, AsyncSocketWrapper {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final String LOGTAG = "AsyncSSLSocketWrapper";
    public static SSLContext defaultSSLContext;
    public static TrustManager[] trustAllManagers;
    public static SSLContext trustAllSSLContext;
    public static HostnameVerifier trustAllVerifier;
    public boolean clientMode;
    public final DataCallback dataCallback = new DataCallback() {
        public final Allocator allocator = new Allocator().setMinAlloc(8192);
        public final ByteBufferList buffered = new ByteBufferList();

        /* JADX WARNING: Removed duplicated region for block: B:38:0x0025 A[LOOP:0: B:9:0x0025->B:38:0x0025, LOOP_END, SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:40:0x00c0 A[SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onDataAvailable(io.lum.sdk.async.DataEmitter r8, io.lum.sdk.async.ByteBufferList r9) {
            /*
                r7 = this;
                io.lum.sdk.async.AsyncSSLSocketWrapper r8 = io.lum.sdk.async.AsyncSSLSocketWrapper.this
                boolean r0 = r8.mUnwrapping
                if (r0 == 0) goto L_0x0007
                return
            L_0x0007:
                r0 = 1
                r1 = 0
                r8.mUnwrapping = r0     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                r9.get((io.lum.sdk.async.ByteBufferList) r8)     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                boolean r8 = r8.hasRemaining()     // Catch:{ SSLException -> 0x00cd }
                if (r8 == 0) goto L_0x0023
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                java.nio.ByteBuffer r8 = r8.getAll()     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r9 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                r9.add((java.nio.ByteBuffer) r8)     // Catch:{ SSLException -> 0x00cd }
            L_0x0023:
                java.nio.ByteBuffer r8 = io.lum.sdk.async.ByteBufferList.EMPTY_BYTEBUFFER     // Catch:{ SSLException -> 0x00cd }
            L_0x0025:
                int r9 = r8.remaining()     // Catch:{ SSLException -> 0x00cd }
                if (r9 != 0) goto L_0x0039
                io.lum.sdk.async.ByteBufferList r9 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                int r9 = r9.size()     // Catch:{ SSLException -> 0x00cd }
                if (r9 <= 0) goto L_0x0039
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                java.nio.ByteBuffer r8 = r8.remove()     // Catch:{ SSLException -> 0x00cd }
            L_0x0039:
                int r9 = r8.remaining()     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.AsyncSSLSocketWrapper r2 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r2 = r2.pending     // Catch:{ SSLException -> 0x00cd }
                int r2 = r2.remaining()     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.util.Allocator r3 = r7.allocator     // Catch:{ SSLException -> 0x00cd }
                java.nio.ByteBuffer r3 = r3.allocate()     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.AsyncSSLSocketWrapper r4 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngine r4 = r4.engine     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngineResult r4 = r4.unwrap(r8, r3)     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.AsyncSSLSocketWrapper r5 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.AsyncSSLSocketWrapper r6 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r6 = r6.pending     // Catch:{ SSLException -> 0x00cd }
                r5.addToPending(r6, r3)     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.util.Allocator r3 = r7.allocator     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.AsyncSSLSocketWrapper r5 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r5 = r5.pending     // Catch:{ SSLException -> 0x00cd }
                int r5 = r5.remaining()     // Catch:{ SSLException -> 0x00cd }
                int r5 = r5 - r2
                long r5 = (long) r5     // Catch:{ SSLException -> 0x00cd }
                r3.track(r5)     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngineResult$Status r3 = r4.getStatus()     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngineResult$Status r5 = javax.net.ssl.SSLEngineResult.Status.BUFFER_OVERFLOW     // Catch:{ SSLException -> 0x00cd }
                r6 = -1
                if (r3 != r5) goto L_0x0083
                io.lum.sdk.async.util.Allocator r9 = r7.allocator     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.util.Allocator r3 = r7.allocator     // Catch:{ SSLException -> 0x00cd }
                int r3 = r3.getMinAlloc()     // Catch:{ SSLException -> 0x00cd }
                int r3 = r3 * 2
                r9.setMinAlloc(r3)     // Catch:{ SSLException -> 0x00cd }
            L_0x0081:
                r9 = -1
                goto L_0x00a7
            L_0x0083:
                javax.net.ssl.SSLEngineResult$Status r3 = r4.getStatus()     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngineResult$Status r5 = javax.net.ssl.SSLEngineResult.Status.BUFFER_UNDERFLOW     // Catch:{ SSLException -> 0x00cd }
                if (r3 != r5) goto L_0x00a7
                io.lum.sdk.async.ByteBufferList r9 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                r9.addFirst(r8)     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                int r8 = r8.size()     // Catch:{ SSLException -> 0x00cd }
                if (r8 > r0) goto L_0x0099
                goto L_0x00c5
            L_0x0099:
                io.lum.sdk.async.ByteBufferList r8 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                java.nio.ByteBuffer r8 = r8.getAll()     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r9 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                r9.addFirst(r8)     // Catch:{ SSLException -> 0x00cd }
                java.nio.ByteBuffer r8 = io.lum.sdk.async.ByteBufferList.EMPTY_BYTEBUFFER     // Catch:{ SSLException -> 0x00cd }
                goto L_0x0081
            L_0x00a7:
                io.lum.sdk.async.AsyncSSLSocketWrapper r3 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                javax.net.ssl.SSLEngineResult$HandshakeStatus r4 = r4.getHandshakeStatus()     // Catch:{ SSLException -> 0x00cd }
                r3.handleHandshakeStatus(r4)     // Catch:{ SSLException -> 0x00cd }
                int r3 = r8.remaining()     // Catch:{ SSLException -> 0x00cd }
                if (r3 != r9) goto L_0x0025
                io.lum.sdk.async.AsyncSSLSocketWrapper r9 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                io.lum.sdk.async.ByteBufferList r9 = r9.pending     // Catch:{ SSLException -> 0x00cd }
                int r9 = r9.remaining()     // Catch:{ SSLException -> 0x00cd }
                if (r2 != r9) goto L_0x0025
                io.lum.sdk.async.ByteBufferList r9 = r7.buffered     // Catch:{ SSLException -> 0x00cd }
                r9.addFirst(r8)     // Catch:{ SSLException -> 0x00cd }
            L_0x00c5:
                io.lum.sdk.async.AsyncSSLSocketWrapper r8 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ SSLException -> 0x00cd }
                r8.onDataAvailable()     // Catch:{ SSLException -> 0x00cd }
                goto L_0x00d3
            L_0x00cb:
                r8 = move-exception
                goto L_0x00d8
            L_0x00cd:
                r8 = move-exception
                io.lum.sdk.async.AsyncSSLSocketWrapper r9 = io.lum.sdk.async.AsyncSSLSocketWrapper.this     // Catch:{ all -> 0x00cb }
                r9.report(r8)     // Catch:{ all -> 0x00cb }
            L_0x00d3:
                io.lum.sdk.async.AsyncSSLSocketWrapper r8 = io.lum.sdk.async.AsyncSSLSocketWrapper.this
                r8.mUnwrapping = r1
                return
            L_0x00d8:
                io.lum.sdk.async.AsyncSSLSocketWrapper r9 = io.lum.sdk.async.AsyncSSLSocketWrapper.this
                r9.mUnwrapping = r1
                goto L_0x00de
            L_0x00dd:
                throw r8
            L_0x00de:
                goto L_0x00dd
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncSSLSocketWrapper.AnonymousClass6.onDataAvailable(io.lum.sdk.async.DataEmitter, io.lum.sdk.async.ByteBufferList):void");
        }
    };
    public SSLEngine engine;
    public boolean finishedHandshake;
    public HandshakeCallback handshakeCallback;
    public HostnameVerifier hostnameVerifier;
    public DataCallback mDataCallback;
    public CompletedCallback mEndCallback;
    public Exception mEndException;
    public boolean mEnded;
    public String mHost;
    public int mPort;
    public BufferedDataSink mSink;
    public AsyncSocket mSocket;
    public boolean mUnwrapping;
    public boolean mWrapping;
    public WritableCallback mWriteableCallback;
    public X509Certificate[] peerCertificates;
    public final ByteBufferList pending = new ByteBufferList();
    public TrustManager[] trustManagers;
    public ByteBufferList writeList = new ByteBufferList();

    public interface HandshakeCallback {
        void onHandshakeCompleted(Exception exc, AsyncSSLSocket asyncSSLSocket);
    }

    public static class ObjectHolder<T> {
        public T held;

        public ObjectHolder() {
        }
    }

    static {
        try {
            defaultSSLContext = SSLContext.getInstance("Default");
        } catch (Exception e2) {
            try {
                defaultSSLContext = SSLContext.getInstance("TLS");
                defaultSSLContext.init((KeyManager[]) null, new TrustManager[]{new X509TrustManager() {
                    public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
                    }

                    public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
                        for (X509Certificate x509Certificate : x509CertificateArr) {
                            if (!(x509Certificate == null || x509Certificate.getCriticalExtensionOIDs() == null)) {
                                x509Certificate.getCriticalExtensionOIDs().remove("2.5.29.15");
                            }
                        }
                    }

                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }
                }}, (SecureRandom) null);
            } catch (Exception e3) {
                e2.printStackTrace();
                e3.printStackTrace();
            }
        }
        try {
            trustAllSSLContext = SSLContext.getInstance("TLS");
            TrustManager[] trustManagerArr = {new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
                }

                public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            }};
            trustAllManagers = trustManagerArr;
            trustAllSSLContext.init((KeyManager[]) null, trustManagerArr, (SecureRandom) null);
            trustAllVerifier = b.f7046a;
        } catch (Exception e4) {
            e4.printStackTrace();
        }
    }

    public AsyncSSLSocketWrapper(AsyncSocket asyncSocket, String str, int i, SSLEngine sSLEngine, TrustManager[] trustManagerArr, HostnameVerifier hostnameVerifier2, boolean z) {
        this.mSocket = asyncSocket;
        this.hostnameVerifier = hostnameVerifier2;
        this.clientMode = z;
        this.trustManagers = trustManagerArr;
        this.engine = sSLEngine;
        this.mHost = str;
        this.mPort = i;
        sSLEngine.setUseClientMode(z);
        BufferedDataSink bufferedDataSink = new BufferedDataSink(asyncSocket);
        this.mSink = bufferedDataSink;
        bufferedDataSink.setWriteableCallback(new WritableCallback() {
            public void onWriteable() {
                WritableCallback writableCallback = AsyncSSLSocketWrapper.this.mWriteableCallback;
                if (writableCallback != null) {
                    writableCallback.onWriteable();
                }
            }
        });
        this.mSocket.setEndCallback(new CompletedCallback() {
            public void onCompleted(Exception exc) {
                CompletedCallback completedCallback;
                AsyncSSLSocketWrapper asyncSSLSocketWrapper = AsyncSSLSocketWrapper.this;
                if (!asyncSSLSocketWrapper.mEnded) {
                    asyncSSLSocketWrapper.mEnded = true;
                    asyncSSLSocketWrapper.mEndException = exc;
                    if (!asyncSSLSocketWrapper.pending.hasRemaining() && (completedCallback = AsyncSSLSocketWrapper.this.mEndCallback) != null) {
                        completedCallback.onCompleted(exc);
                    }
                }
            }
        });
        this.mSocket.setDataCallback(this.dataCallback);
    }

    public static /* synthetic */ void a(Context context, String str, ObjectHolder objectHolder, AsyncServer asyncServer, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        try {
            Pair<KeyPair, Certificate> selfSignCertificate = selfSignCertificate(context, str);
            AsyncServer asyncServer2 = asyncServer;
            objectHolder.held = listenSecure(asyncServer2, ((KeyPair) selfSignCertificate.first).getPrivate(), (Certificate) selfSignCertificate.second, inetAddress, i, listenCallback);
        } catch (Exception e2) {
            listenCallback.onCompleted(e2);
        }
    }

    public static /* synthetic */ void a(SimpleCancellable simpleCancellable, ConnectCallback connectCallback, Exception exc, AsyncSSLSocket asyncSSLSocket) {
        if (!simpleCancellable.setComplete()) {
            if (asyncSSLSocket != null) {
                asyncSSLSocket.close();
            }
        } else if (exc != null) {
            connectCallback.onConnectCompleted(exc, (AsyncSocket) null);
        } else {
            connectCallback.onConnectCompleted((Exception) null, asyncSSLSocket);
        }
    }

    public static /* synthetic */ void a(SimpleCancellable simpleCancellable, ConnectCallback connectCallback, String str, int i, boolean z, Exception exc, AsyncSocket asyncSocket) {
        HostnameVerifier hostnameVerifier2 = null;
        if (exc == null) {
            SSLEngine createSSLEngine = (z ? trustAllSSLContext : defaultSSLContext).createSSLEngine(str, i);
            TrustManager[] trustManagerArr = z ? trustAllManagers : null;
            if (z) {
                hostnameVerifier2 = trustAllVerifier;
            }
            handshake(asyncSocket, str, i, createSSLEngine, trustManagerArr, hostnameVerifier2, true, new f(simpleCancellable, connectCallback));
        } else if (simpleCancellable.setComplete()) {
            connectCallback.onConnectCompleted(exc, (AsyncSocket) null);
        }
    }

    public static /* synthetic */ void a(final PrivateKey privateKey, final Certificate certificate, AsyncServer asyncServer, InetAddress inetAddress, int i, ListenCallback listenCallback, ObjectHolder objectHolder) {
        try {
            KeyStore instance = KeyStore.getInstance(KeyStore.getDefaultType());
            instance.load((KeyStore.LoadStoreParameter) null);
            instance.setKeyEntry("key", privateKey, (char[]) null, new Certificate[]{certificate});
            KeyManagerFactory instance2 = KeyManagerFactory.getInstance("X509");
            instance2.init(instance, "".toCharArray());
            TrustManagerFactory instance3 = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            instance3.init(instance);
            SSLContext instance4 = SSLContext.getInstance("TLS");
            instance4.init(instance2.getKeyManagers(), instance3.getTrustManagers(), (SecureRandom) null);
            final AsyncServerSocket listenSecure = listenSecure(asyncServer, instance4, inetAddress, i, listenCallback);
            objectHolder.held = new AsyncSSLServerSocket() {
                public Certificate getCertificate() {
                    return certificate;
                }

                public int getLocalPort() {
                    return listenSecure.getLocalPort();
                }

                public PrivateKey getPrivateKey() {
                    return privateKey;
                }

                public void stop() {
                    listenSecure.stop();
                }
            };
        } catch (Exception e2) {
            listenCallback.onCompleted(e2);
        }
    }

    public static /* synthetic */ void a(byte[] bArr, byte[] bArr2, ObjectHolder objectHolder, AsyncServer asyncServer, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        try {
            PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(bArr);
            AsyncServer asyncServer2 = asyncServer;
            objectHolder.held = listenSecure(asyncServer2, KeyFactory.getInstance("RSA").generatePrivate(pKCS8EncodedKeySpec), CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(bArr2)), inetAddress, i, listenCallback);
        } catch (Exception e2) {
            listenCallback.onCompleted(e2);
        }
    }

    public static /* synthetic */ boolean a(String str, SSLSession sSLSession) {
        return true;
    }

    public static Cancellable connectSocket(AsyncServer asyncServer, String str, int i, ConnectCallback connectCallback) {
        return connectSocket(asyncServer, str, i, false, connectCallback);
    }

    public static Cancellable connectSocket(AsyncServer asyncServer, String str, int i, boolean z, ConnectCallback connectCallback) {
        SimpleCancellable simpleCancellable = new SimpleCancellable();
        simpleCancellable.setParent(asyncServer.connectSocket(str, i, new g(simpleCancellable, connectCallback, str, i, z)));
        return simpleCancellable;
    }

    public static SSLContext getDefaultSSLContext() {
        return defaultSSLContext;
    }

    /* access modifiers changed from: private */
    public void handleHandshakeStatus(SSLEngineResult.HandshakeStatus handshakeStatus) {
        if (handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_TASK) {
            this.engine.getDelegatedTask().run();
        }
        if (handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
            write(this.writeList);
        }
        if (handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_UNWRAP) {
            this.dataCallback.onDataAvailable(this, new ByteBufferList());
        }
        try {
            if (this.finishedHandshake) {
                return;
            }
            if (this.engine.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING || this.engine.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.FINISHED) {
                if (this.clientMode) {
                    boolean z = false;
                    try {
                        this.peerCertificates = (X509Certificate[]) this.engine.getSession().getPeerCertificates();
                        if (this.mHost != null) {
                            if (this.hostnameVerifier == null) {
                                new StrictHostnameVerifier().verify(this.mHost, StrictHostnameVerifier.getCNs(this.peerCertificates[0]), StrictHostnameVerifier.getDNSSubjectAlts(this.peerCertificates[0]));
                            } else if (!this.hostnameVerifier.verify(this.mHost, this.engine.getSession())) {
                                throw new SSLException("hostname <" + this.mHost + "> has been denied");
                            }
                        }
                        e = null;
                        z = true;
                    } catch (SSLException e2) {
                        e = e2;
                    }
                    this.finishedHandshake = true;
                    if (!z) {
                        AsyncSSLException asyncSSLException = new AsyncSSLException(e);
                        report(asyncSSLException);
                        if (!asyncSSLException.getIgnore()) {
                            throw asyncSSLException;
                        }
                    }
                } else {
                    this.finishedHandshake = true;
                }
                this.handshakeCallback.onHandshakeCompleted((Exception) null, this);
                this.handshakeCallback = null;
                this.mSocket.setClosedCallback((CompletedCallback) null);
                getServer().post(new Runnable() {
                    public void run() {
                        WritableCallback writableCallback = AsyncSSLSocketWrapper.this.mWriteableCallback;
                        if (writableCallback != null) {
                            writableCallback.onWriteable();
                        }
                    }
                });
                onDataAvailable();
            }
        } catch (Exception e3) {
            report(e3);
        }
    }

    public static void handshake(AsyncSocket asyncSocket, String str, int i, SSLEngine sSLEngine, TrustManager[] trustManagerArr, HostnameVerifier hostnameVerifier2, boolean z, HandshakeCallback handshakeCallback2) {
        final HandshakeCallback handshakeCallback3 = handshakeCallback2;
        AsyncSSLSocketWrapper asyncSSLSocketWrapper = new AsyncSSLSocketWrapper(asyncSocket, str, i, sSLEngine, trustManagerArr, hostnameVerifier2, z);
        asyncSSLSocketWrapper.handshakeCallback = handshakeCallback3;
        AnonymousClass3 r1 = new CompletedCallback() {
            public void onCompleted(Exception exc) {
                if (exc != null) {
                    handshakeCallback3.onHandshakeCompleted(exc, (AsyncSSLSocket) null);
                } else {
                    handshakeCallback3.onHandshakeCompleted(new SSLException("socket closed during handshake"), (AsyncSSLSocket) null);
                }
            }
        };
        AsyncSocket asyncSocket2 = asyncSocket;
        asyncSocket.setClosedCallback(r1);
        try {
            asyncSSLSocketWrapper.engine.beginHandshake();
            asyncSSLSocketWrapper.handleHandshakeStatus(asyncSSLSocketWrapper.engine.getHandshakeStatus());
        } catch (SSLException e2) {
            asyncSSLSocketWrapper.report(e2);
        }
    }

    public static AsyncSSLServerSocket listenSecure(Context context, AsyncServer asyncServer, String str, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        ObjectHolder objectHolder = new ObjectHolder();
        asyncServer.run(new e(context, str, objectHolder, asyncServer, inetAddress, i, listenCallback));
        return (AsyncSSLServerSocket) objectHolder.held;
    }

    public static AsyncSSLServerSocket listenSecure(AsyncServer asyncServer, String str, String str2, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        return listenSecure(asyncServer, Base64.decode(str, 0), Base64.decode(str2, 0), inetAddress, i, listenCallback);
    }

    public static AsyncSSLServerSocket listenSecure(AsyncServer asyncServer, PrivateKey privateKey, Certificate certificate, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        ObjectHolder objectHolder = new ObjectHolder();
        asyncServer.run(new c(privateKey, certificate, asyncServer, inetAddress, i, listenCallback, objectHolder));
        return (AsyncSSLServerSocket) objectHolder.held;
    }

    public static AsyncSSLServerSocket listenSecure(AsyncServer asyncServer, byte[] bArr, byte[] bArr2, InetAddress inetAddress, int i, ListenCallback listenCallback) {
        ObjectHolder objectHolder = new ObjectHolder();
        asyncServer.run(new d(bArr, bArr2, objectHolder, asyncServer, inetAddress, i, listenCallback));
        return (AsyncSSLServerSocket) objectHolder.held;
    }

    public static AsyncServerSocket listenSecure(AsyncServer asyncServer, final SSLContext sSLContext, InetAddress inetAddress, final int i, final ListenCallback listenCallback) {
        final AnonymousClass9 r0 = new SSLEngineSNIConfigurator() {
            public SSLEngine createEngine(SSLContext sSLContext, String str, int i) {
                SSLEngine createEngine = super.createEngine(sSLContext, str, i);
                createEngine.setEnabledCipherSuites(new String[]{"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"});
                return createEngine;
            }
        };
        return asyncServer.listen(inetAddress, i, new ListenCallback() {
            public static /* synthetic */ void a(AsyncSocket asyncSocket, ListenCallback listenCallback, Exception exc, AsyncSSLSocket asyncSSLSocket) {
                if (exc != null) {
                    asyncSocket.close();
                } else {
                    listenCallback.onAccepted(asyncSSLSocket);
                }
            }

            public void onAccepted(AsyncSocket asyncSocket) {
                int i = i;
                AsyncSSLSocketWrapper.handshake(asyncSocket, (String) null, i, r0.createEngine(sSLContext, (String) null, i), (TrustManager[]) null, (HostnameVerifier) null, false, new a(asyncSocket, listenCallback));
            }

            public void onCompleted(Exception exc) {
                listenCallback.onCompleted(exc);
            }

            public void onListening(AsyncServerSocket asyncServerSocket) {
                listenCallback.onListening(asyncServerSocket);
            }
        });
    }

    /* access modifiers changed from: private */
    public void report(Exception exc) {
        HandshakeCallback handshakeCallback2 = this.handshakeCallback;
        if (handshakeCallback2 != null) {
            this.handshakeCallback = null;
            this.mSocket.setDataCallback(new DataCallback.NullDataCallback());
            this.mSocket.end();
            this.mSocket.setClosedCallback((CompletedCallback) null);
            this.mSocket.close();
            handshakeCallback2.onHandshakeCompleted(exc, (AsyncSSLSocket) null);
            return;
        }
        CompletedCallback endCallback = getEndCallback();
        if (endCallback != null) {
            endCallback.onCompleted(exc);
        }
    }

    public static Certificate selfSign(KeyPair keyPair, String str) {
        BouncyCastleProvider bouncyCastleProvider = new BouncyCastleProvider();
        Security.addProvider(bouncyCastleProvider);
        long currentTimeMillis = System.currentTimeMillis();
        Date date = new Date(currentTimeMillis);
        X500Name x500Name = new X500Name(b.a.a.a.a.a("CN=", str));
        BigInteger bigInteger = new BigInteger(Long.toString(currentTimeMillis));
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.add(1, 1);
        Date time = instance.getTime();
        ContentSigner build = new JcaContentSignerBuilder("SHA256WithRSA").build(keyPair.getPrivate());
        JcaX509v3CertificateBuilder jcaX509v3CertificateBuilder = new JcaX509v3CertificateBuilder(x500Name, bigInteger, date, time, x500Name, keyPair.getPublic());
        jcaX509v3CertificateBuilder.addExtension(new ASN1ObjectIdentifier("2.5.29.19"), true, new BasicConstraints(true));
        return new JcaX509CertificateConverter().setProvider(bouncyCastleProvider).getCertificate(jcaX509v3CertificateBuilder.build(build));
    }

    public static Pair<KeyPair, Certificate> selfSignCertificate(Context context, String str) {
        KeyPair keyPair;
        Certificate certificate;
        File fileStreamPath = context.getFileStreamPath(str + "-key.txt");
        try {
            String[] split = StreamUtility.readFile(fileStreamPath).split("\n");
            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(Base64.decode(split[0], 0));
            PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decode(split[1], 0));
            certificate = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(Base64.decode(split[2], 0)));
            KeyFactory instance = KeyFactory.getInstance("RSA");
            keyPair = new KeyPair(instance.generatePublic(x509EncodedKeySpec), instance.generatePrivate(pKCS8EncodedKeySpec));
        } catch (Exception unused) {
            KeyPairGenerator instance2 = KeyPairGenerator.getInstance("RSA");
            instance2.initialize(2048);
            keyPair = instance2.generateKeyPair();
            certificate = selfSign(keyPair, str);
            StreamUtility.writeFile(fileStreamPath, Base64.encodeToString(keyPair.getPublic().getEncoded(), 2) + "\n" + Base64.encodeToString(keyPair.getPrivate().getEncoded(), 2) + "\n" + Base64.encodeToString(certificate.getEncoded(), 2));
        }
        return new Pair<>(keyPair, certificate);
    }

    public void addToPending(ByteBufferList byteBufferList, ByteBuffer byteBuffer) {
        byteBuffer.flip();
        if (byteBuffer.hasRemaining()) {
            byteBufferList.add(byteBuffer);
        } else {
            ByteBufferList.reclaim(byteBuffer);
        }
    }

    public int calculateAlloc(int i) {
        int i2 = (i * 3) / 2;
        if (i2 == 0) {
            return 8192;
        }
        return i2;
    }

    public String charset() {
        return null;
    }

    public void close() {
        this.mSocket.close();
    }

    public void end() {
        this.mSocket.end();
    }

    public CompletedCallback getClosedCallback() {
        return this.mSocket.getClosedCallback();
    }

    public DataCallback getDataCallback() {
        return this.mDataCallback;
    }

    public DataEmitter getDataEmitter() {
        return this.mSocket;
    }

    public CompletedCallback getEndCallback() {
        return this.mEndCallback;
    }

    public String getHost() {
        return this.mHost;
    }

    public X509Certificate[] getPeerCertificates() {
        return this.peerCertificates;
    }

    public int getPort() {
        return this.mPort;
    }

    public SSLEngine getSSLEngine() {
        return this.engine;
    }

    public AsyncServer getServer() {
        return this.mSocket.getServer();
    }

    public AsyncSocket getSocket() {
        return this.mSocket;
    }

    public WritableCallback getWriteableCallback() {
        return this.mWriteableCallback;
    }

    public boolean isChunked() {
        return this.mSocket.isChunked();
    }

    public boolean isOpen() {
        return this.mSocket.isOpen();
    }

    public boolean isPaused() {
        return this.mSocket.isPaused();
    }

    public void onDataAvailable() {
        CompletedCallback completedCallback;
        Util.emitAllData(this, this.pending);
        if (this.mEnded && !this.pending.hasRemaining() && (completedCallback = this.mEndCallback) != null) {
            completedCallback.onCompleted(this.mEndException);
        }
    }

    public void pause() {
        this.mSocket.pause();
    }

    public void resume() {
        this.mSocket.resume();
        onDataAvailable();
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        this.mSocket.setClosedCallback(completedCallback);
    }

    public void setDataCallback(DataCallback dataCallback2) {
        this.mDataCallback = dataCallback2;
    }

    public void setEndCallback(CompletedCallback completedCallback) {
        this.mEndCallback = completedCallback;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        this.mWriteableCallback = writableCallback;
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0088  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void write(io.lum.sdk.async.ByteBufferList r7) {
        /*
            r6 = this;
            boolean r0 = r6.mWrapping
            if (r0 == 0) goto L_0x0005
            return
        L_0x0005:
            io.lum.sdk.async.BufferedDataSink r0 = r6.mSink
            int r0 = r0.remaining()
            if (r0 <= 0) goto L_0x000e
            return
        L_0x000e:
            r0 = 1
            r6.mWrapping = r0
            int r0 = r7.remaining()
            int r0 = r6.calculateAlloc(r0)
            java.nio.ByteBuffer r0 = io.lum.sdk.async.ByteBufferList.obtain(r0)
            r1 = 0
            r2 = r1
        L_0x001f:
            boolean r3 = r6.finishedHandshake
            if (r3 == 0) goto L_0x002b
            int r3 = r7.remaining()
            if (r3 != 0) goto L_0x002b
            goto L_0x009a
        L_0x002b:
            int r3 = r7.remaining()
            java.nio.ByteBuffer[] r4 = r7.getAllArray()     // Catch:{ SSLException -> 0x007e }
            javax.net.ssl.SSLEngine r5 = r6.engine     // Catch:{ SSLException -> 0x007e }
            javax.net.ssl.SSLEngineResult r2 = r5.wrap(r4, r0)     // Catch:{ SSLException -> 0x007e }
            r7.addAll((java.nio.ByteBuffer[]) r4)     // Catch:{ SSLException -> 0x007e }
            r0.flip()     // Catch:{ SSLException -> 0x007e }
            io.lum.sdk.async.ByteBufferList r4 = r6.writeList     // Catch:{ SSLException -> 0x007e }
            r4.add((java.nio.ByteBuffer) r0)     // Catch:{ SSLException -> 0x007e }
            io.lum.sdk.async.ByteBufferList r4 = r6.writeList     // Catch:{ SSLException -> 0x007e }
            int r4 = r4.remaining()     // Catch:{ SSLException -> 0x007e }
            if (r4 <= 0) goto L_0x0053
            io.lum.sdk.async.BufferedDataSink r4 = r6.mSink     // Catch:{ SSLException -> 0x007e }
            io.lum.sdk.async.ByteBufferList r5 = r6.writeList     // Catch:{ SSLException -> 0x007e }
            r4.write(r5)     // Catch:{ SSLException -> 0x007e }
        L_0x0053:
            int r0 = r0.capacity()     // Catch:{ SSLException -> 0x007e }
            javax.net.ssl.SSLEngineResult$Status r4 = r2.getStatus()     // Catch:{ SSLException -> 0x007b }
            javax.net.ssl.SSLEngineResult$Status r5 = javax.net.ssl.SSLEngineResult.Status.BUFFER_OVERFLOW     // Catch:{ SSLException -> 0x007b }
            if (r4 != r5) goto L_0x0067
            int r0 = r0 * 2
            java.nio.ByteBuffer r0 = io.lum.sdk.async.ByteBufferList.obtain(r0)     // Catch:{ SSLException -> 0x007b }
            r3 = -1
            goto L_0x0082
        L_0x0067:
            int r0 = r7.remaining()     // Catch:{ SSLException -> 0x007b }
            int r0 = r6.calculateAlloc(r0)     // Catch:{ SSLException -> 0x007b }
            java.nio.ByteBuffer r0 = io.lum.sdk.async.ByteBufferList.obtain(r0)     // Catch:{ SSLException -> 0x007b }
            javax.net.ssl.SSLEngineResult$HandshakeStatus r4 = r2.getHandshakeStatus()     // Catch:{ SSLException -> 0x007e }
            r6.handleHandshakeStatus(r4)     // Catch:{ SSLException -> 0x007e }
            goto L_0x0082
        L_0x007b:
            r4 = move-exception
            r0 = r1
            goto L_0x007f
        L_0x007e:
            r4 = move-exception
        L_0x007f:
            r6.report(r4)
        L_0x0082:
            int r4 = r7.remaining()
            if (r3 != r4) goto L_0x0092
            if (r2 == 0) goto L_0x009a
            javax.net.ssl.SSLEngineResult$HandshakeStatus r3 = r2.getHandshakeStatus()
            javax.net.ssl.SSLEngineResult$HandshakeStatus r4 = javax.net.ssl.SSLEngineResult.HandshakeStatus.NEED_WRAP
            if (r3 != r4) goto L_0x009a
        L_0x0092:
            io.lum.sdk.async.BufferedDataSink r3 = r6.mSink
            int r3 = r3.remaining()
            if (r3 == 0) goto L_0x001f
        L_0x009a:
            r7 = 0
            r6.mWrapping = r7
            io.lum.sdk.async.ByteBufferList.reclaim(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.AsyncSSLSocketWrapper.write(io.lum.sdk.async.ByteBufferList):void");
    }
}
