package io.lum.sdk.async;

import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.WritableCallback;

public interface DataSink {
    void end();

    CompletedCallback getClosedCallback();

    AsyncServer getServer();

    WritableCallback getWriteableCallback();

    boolean isOpen();

    void setClosedCallback(CompletedCallback completedCallback);

    void setWriteableCallback(WritableCallback writableCallback);

    void write(ByteBufferList byteBufferList);
}
