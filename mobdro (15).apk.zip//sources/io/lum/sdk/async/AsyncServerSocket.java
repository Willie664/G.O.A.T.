package io.lum.sdk.async;

public interface AsyncServerSocket {
    int getLocalPort();

    void stop();
}
