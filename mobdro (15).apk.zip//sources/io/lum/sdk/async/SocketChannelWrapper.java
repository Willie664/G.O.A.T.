package io.lum.sdk.async;

import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

public class SocketChannelWrapper extends ChannelWrapper {
    public SocketChannel mChannel;

    public SocketChannelWrapper(SocketChannel socketChannel) {
        super(socketChannel);
        this.mChannel = socketChannel;
    }

    public InetAddress getLocalAddress() {
        return this.mChannel.socket().getLocalAddress();
    }

    public int getLocalPort() {
        return this.mChannel.socket().getLocalPort();
    }

    public Object getSocket() {
        return this.mChannel.socket();
    }

    public boolean isConnected() {
        return this.mChannel.isConnected();
    }

    public int read(ByteBuffer byteBuffer) {
        return this.mChannel.read(byteBuffer);
    }

    public long read(ByteBuffer[] byteBufferArr) {
        return this.mChannel.read(byteBufferArr);
    }

    public long read(ByteBuffer[] byteBufferArr, int i, int i2) {
        return this.mChannel.read(byteBufferArr, i, i2);
    }

    public SelectionKey register(Selector selector) {
        return register(selector, 8);
    }

    public void shutdownInput() {
        try {
            this.mChannel.socket().shutdownInput();
        } catch (Exception unused) {
        }
    }

    public void shutdownOutput() {
        try {
            this.mChannel.socket().shutdownOutput();
        } catch (Exception unused) {
        }
    }

    public int write(ByteBuffer byteBuffer) {
        return this.mChannel.write(byteBuffer);
    }

    public int write(ByteBuffer[] byteBufferArr) {
        return (int) this.mChannel.write(byteBufferArr);
    }
}
