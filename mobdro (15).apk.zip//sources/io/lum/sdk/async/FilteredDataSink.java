package io.lum.sdk.async;

public class FilteredDataSink extends BufferedDataSink {
    public FilteredDataSink(DataSink dataSink) {
        super(dataSink);
        setMaxBuffer(0);
    }

    public ByteBufferList filter(ByteBufferList byteBufferList) {
        return byteBufferList;
    }

    public void onDataAccepted(ByteBufferList byteBufferList) {
        ByteBufferList filter = filter(byteBufferList);
        if (filter != byteBufferList) {
            byteBufferList.recycle();
            filter.get(byteBufferList);
        }
    }
}
