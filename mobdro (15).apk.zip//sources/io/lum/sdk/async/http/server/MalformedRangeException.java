package io.lum.sdk.async.http.server;

public class MalformedRangeException extends Exception {
}
