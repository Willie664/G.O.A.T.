package io.lum.sdk.async.http;

public interface NameValuePair {
    String getName();

    String getValue();
}
