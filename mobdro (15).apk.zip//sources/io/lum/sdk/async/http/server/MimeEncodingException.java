package io.lum.sdk.async.http.server;

public class MimeEncodingException extends Exception {
    public MimeEncodingException(String str) {
        super(str);
    }
}
