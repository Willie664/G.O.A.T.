package io.lum.sdk.async.http.filter;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.Util;

public class ChunkedInputFilter extends FilteredDataEmitter {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public int mChunkLength = 0;
    public int mChunkLengthRemaining = 0;
    public State mState = State.CHUNK_LEN;
    public ByteBufferList pending = new ByteBufferList();

    /* renamed from: io.lum.sdk.async.http.filter.ChunkedInputFilter$1  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        public static final /* synthetic */ int[] $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State;

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|(3:11|12|14)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x002b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0016 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0024 */
        static {
            /*
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State[] r0 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State = r0
                r1 = 1
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r2 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.CHUNK_LEN     // Catch:{ NoSuchFieldError -> 0x000f }
                r2 = 0
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x000f }
            L_0x000f:
                int[] r0 = $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State     // Catch:{ NoSuchFieldError -> 0x0016 }
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r2 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.CHUNK_LEN_CR     // Catch:{ NoSuchFieldError -> 0x0016 }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0016 }
            L_0x0016:
                int[] r0 = $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State     // Catch:{ NoSuchFieldError -> 0x001d }
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r1 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.CHUNK     // Catch:{ NoSuchFieldError -> 0x001d }
                r1 = 3
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State     // Catch:{ NoSuchFieldError -> 0x0024 }
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r1 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.CHUNK_CR     // Catch:{ NoSuchFieldError -> 0x0024 }
                r1 = 4
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x0024 }
            L_0x0024:
                int[] r0 = $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State     // Catch:{ NoSuchFieldError -> 0x002b }
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r1 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.CHUNK_CRLF     // Catch:{ NoSuchFieldError -> 0x002b }
                r1 = 5
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x002b }
            L_0x002b:
                int[] r0 = $SwitchMap$io$lum$sdk$async$http$filter$ChunkedInputFilter$State     // Catch:{ NoSuchFieldError -> 0x0032 }
                io.lum.sdk.async.http.filter.ChunkedInputFilter$State r1 = io.lum.sdk.async.http.filter.ChunkedInputFilter.State.COMPLETE     // Catch:{ NoSuchFieldError -> 0x0032 }
                r1 = 6
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x0032 }
            L_0x0032:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.filter.ChunkedInputFilter.AnonymousClass1.<clinit>():void");
        }
    }

    public enum State {
        CHUNK_LEN,
        CHUNK_LEN_CR,
        CHUNK_LEN_CRLF,
        CHUNK,
        CHUNK_CR,
        CHUNK_CRLF,
        COMPLETE,
        ERROR
    }

    private boolean checkByte(char c2, char c3) {
        if (c2 == c3) {
            return true;
        }
        this.mState = State.ERROR;
        report(new ChunkedDataException(c3 + " was expected, got " + c2));
        return false;
    }

    private boolean checkCR(char c2) {
        return checkByte(c2, 13);
    }

    private boolean checkLF(char c2) {
        return checkByte(c2, 10);
    }

    public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        State state;
        if (this.mState == State.ERROR) {
            byteBufferList.recycle();
            return;
        }
        while (byteBufferList.remaining() > 0) {
            try {
                int ordinal = this.mState.ordinal();
                if (ordinal != 0) {
                    if (ordinal != 1) {
                        if (ordinal == 3) {
                            int min = Math.min(this.mChunkLengthRemaining, byteBufferList.remaining());
                            int i = this.mChunkLengthRemaining - min;
                            this.mChunkLengthRemaining = i;
                            if (i == 0) {
                                this.mState = State.CHUNK_CR;
                            }
                            if (min != 0) {
                                byteBufferList.get(this.pending, min);
                                Util.emitAllData(this, this.pending);
                            }
                        } else if (ordinal != 4) {
                            if (ordinal != 5) {
                                if (ordinal == 6) {
                                    return;
                                }
                            } else if (checkLF(byteBufferList.getByteChar())) {
                                if (this.mChunkLength > 0) {
                                    this.mState = State.CHUNK_LEN;
                                } else {
                                    this.mState = State.COMPLETE;
                                    report((Exception) null);
                                }
                                this.mChunkLength = 0;
                            } else {
                                return;
                            }
                        } else if (checkCR(byteBufferList.getByteChar())) {
                            state = State.CHUNK_CRLF;
                        } else {
                            return;
                        }
                    } else if (checkLF(byteBufferList.getByteChar())) {
                        state = State.CHUNK;
                    } else {
                        return;
                    }
                    this.mState = state;
                } else {
                    char byteChar = byteBufferList.getByteChar();
                    if (byteChar == 13) {
                        this.mState = State.CHUNK_LEN_CR;
                    } else {
                        int i2 = this.mChunkLength * 16;
                        this.mChunkLength = i2;
                        if (byteChar >= 'a' && byteChar <= 'f') {
                            this.mChunkLength = (byteChar - 'a') + 10 + i2;
                        } else if (byteChar >= '0' && byteChar <= '9') {
                            this.mChunkLength = (byteChar - '0') + this.mChunkLength;
                        } else if (byteChar < 'A' || byteChar > 'F') {
                            report(new ChunkedDataException("invalid chunk length: " + byteChar));
                            return;
                        } else {
                            this.mChunkLength = (byteChar - 'A') + 10 + this.mChunkLength;
                        }
                    }
                    this.mChunkLengthRemaining = this.mChunkLength;
                }
            } catch (Exception e2) {
                report(e2);
                return;
            }
        }
    }

    public void report(Exception exc) {
        if (exc == null && this.mState != State.COMPLETE) {
            exc = new ChunkedDataException("chunked input ended before final chunk");
        }
        super.report(exc);
    }
}
