package io.lum.sdk.async.http;

import android.text.TextUtils;
import io.lum.sdk.async.util.TaggedList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Headers {
    public final Multimap map = new Multimap() {
        public List<String> newList() {
            return new TaggedList();
        }
    };

    public Headers() {
    }

    public Headers(Map<String, List<String>> map2) {
        for (String next : map2.keySet()) {
            addAll(next, map2.get(next));
        }
    }

    public static Headers parse(String str) {
        String[] split = str.split("\n");
        Headers headers = new Headers();
        for (String trim : split) {
            String trim2 = trim.trim();
            if (!TextUtils.isEmpty(trim2)) {
                headers.addLine(trim2);
            }
        }
        return headers;
    }

    public Headers add(String str, String str2) {
        String lowerCase = str.toLowerCase(Locale.US);
        this.map.add(lowerCase, str2);
        ((TaggedList) this.map.get(lowerCase)).tagNull(str);
        return this;
    }

    public Headers addAll(Headers headers) {
        this.map.putAll(headers.map);
        return this;
    }

    public Headers addAll(String str, List<String> list) {
        for (String add : list) {
            add(str, add);
        }
        return this;
    }

    public Headers addAll(Map<String, List<String>> map2) {
        for (String next : map2.keySet()) {
            for (String add : map2.get(next)) {
                add(next, add);
            }
        }
        return this;
    }

    public Headers addAllMap(Map<String, String> map2) {
        for (String next : map2.keySet()) {
            add(next, map2.get(next));
        }
        return this;
    }

    public Headers addLine(String str) {
        if (str != null) {
            String[] split = str.trim().split(":", 2);
            if (split.length == 2) {
                add(split[0].trim(), split[1].trim());
            } else {
                add(split[0].trim(), "");
            }
        }
        return this;
    }

    public String get(String str) {
        return this.map.getString(str.toLowerCase(Locale.US));
    }

    public List<String> getAll(String str) {
        return (List) this.map.get(str.toLowerCase(Locale.US));
    }

    public Multimap getMultiMap() {
        return this.map;
    }

    public String remove(String str) {
        List<String> removeAll = removeAll(str.toLowerCase(Locale.US));
        if (removeAll == null || removeAll.size() == 0) {
            return null;
        }
        return removeAll.get(0);
    }

    public Headers removeAll(Collection<String> collection) {
        for (String remove : collection) {
            remove(remove);
        }
        return this;
    }

    public List<String> removeAll(String str) {
        return (List) this.map.remove(str.toLowerCase(Locale.US));
    }

    public Headers set(String str, String str2) {
        if (str2 == null || (!str2.contains("\n") && !str2.contains("\r"))) {
            String lowerCase = str.toLowerCase(Locale.US);
            this.map.put(lowerCase, str2);
            ((TaggedList) this.map.get(lowerCase)).tagNull(str);
            return this;
        }
        throw new IllegalArgumentException("value must not contain a new line or line feed");
    }

    public String toPrefixString(String str) {
        StringBuilder stringBuilder = toStringBuilder();
        return stringBuilder.insert(0, str + "\r\n").toString();
    }

    public String toString() {
        return toStringBuilder().toString();
    }

    public StringBuilder toStringBuilder() {
        StringBuilder sb = new StringBuilder(256);
        for (String str : this.map.keySet()) {
            TaggedList taggedList = (TaggedList) this.map.get(str);
            Iterator it = taggedList.iterator();
            while (it.hasNext()) {
                sb.append((String) taggedList.tag());
                sb.append(": ");
                sb.append((String) it.next());
                sb.append("\r\n");
            }
        }
        sb.append("\r\n");
        return sb;
    }
}
