package io.lum.sdk.async.http;

import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.util.UntypedHashtable;

public interface AsyncHttpClientMiddleware {

    public static class GetSocketData extends OnRequestData {
        public ConnectCallback connectCallback;
        public String protocol;
        public Cancellable socketCancellable;
    }

    public static class OnBodyDecoderData extends OnHeadersReceivedData {
        public DataEmitter bodyEmitter;
    }

    public static class OnExchangeHeaderData extends GetSocketData {
        public CompletedCallback receiveHeadersCallback;
        public ResponseHead response;
        public CompletedCallback sendHeadersCallback;
        public AsyncSocket socket;
    }

    public static class OnHeadersReceivedData extends OnRequestSentData {
    }

    public static class OnRequestData {
        public AsyncHttpRequest request;
        public UntypedHashtable state = new UntypedHashtable();
    }

    public static class OnRequestSentData extends OnExchangeHeaderData {
    }

    public static class OnResponseCompleteData extends OnResponseReadyData {
        public Exception exception;
    }

    public static class OnResponseReadyData extends OnBodyDecoderData {
    }

    public interface ResponseHead {
        int code();

        ResponseHead code(int i);

        DataEmitter emitter();

        ResponseHead emitter(DataEmitter dataEmitter);

        ResponseHead headers(Headers headers);

        Headers headers();

        ResponseHead message(String str);

        String message();

        ResponseHead protocol(String str);

        String protocol();

        DataSink sink();

        ResponseHead sink(DataSink dataSink);

        AsyncSocket socket();
    }

    boolean exchangeHeaders(OnExchangeHeaderData onExchangeHeaderData);

    Cancellable getSocket(GetSocketData getSocketData);

    void onBodyDecoder(OnBodyDecoderData onBodyDecoderData);

    void onHeadersReceived(OnHeadersReceivedData onHeadersReceivedData);

    void onRequest(OnRequestData onRequestData);

    void onRequestSent(OnRequestSentData onRequestSentData);

    void onResponseComplete(OnResponseCompleteData onResponseCompleteData);

    AsyncHttpRequest onResponseReady(OnResponseReadyData onResponseReadyData);
}
