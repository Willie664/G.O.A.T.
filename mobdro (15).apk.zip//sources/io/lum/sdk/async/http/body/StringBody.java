package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.parser.StringParser;

public class StringBody implements AsyncHttpRequestBody<String> {
    public static final String CONTENT_TYPE = "text/plain";
    public byte[] mBodyBytes;
    public String string;

    public StringBody() {
    }

    public StringBody(String str) {
        this();
        this.string = str;
    }

    public String get() {
        return toString();
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

    public int length() {
        if (this.mBodyBytes == null) {
            this.mBodyBytes = this.string.getBytes();
        }
        return this.mBodyBytes.length;
    }

    public void parse(DataEmitter dataEmitter, final CompletedCallback completedCallback) {
        new StringParser().parse(dataEmitter).setCallback(new FutureCallback<String>() {
            public void onCompleted(Exception exc, String str) {
                StringBody.this.string = str;
                completedCallback.onCompleted(exc);
            }
        });
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public String toString() {
        return this.string;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        if (this.mBodyBytes == null) {
            this.mBodyBytes = this.string.getBytes();
        }
        Util.writeAll(dataSink, this.mBodyBytes, completedCallback);
    }
}
