package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.NameValuePair;
import java.io.InputStream;
import java.util.List;

public abstract class StreamPart extends Part {
    public StreamPart(String str, long j, List<NameValuePair> list) {
        super(str, j, list);
    }

    public abstract InputStream getInputStream();

    public void write(DataSink dataSink, CompletedCallback completedCallback) {
        try {
            Util.pump(getInputStream(), dataSink, completedCallback);
        } catch (Exception e2) {
            completedCallback.onCompleted(e2);
        }
    }
}
