package io.lum.sdk.async.http;

import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import java.nio.charset.Charset;

public abstract class AsyncHttpResponseImpl extends FilteredDataEmitter implements DataEmitter, AsyncHttpClientMiddleware.ResponseHead, AsyncHttpResponse {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public int code;
    public boolean mCompleted = false;
    public boolean mFirstWrite = true;
    public Headers mHeaders;
    public CompletedCallback mReporter = new CompletedCallback() {
        public void onCompleted(Exception exc) {
            AsyncHttpResponseImpl asyncHttpResponseImpl;
            ConnectionClosedException connectionClosedException;
            if (AsyncHttpResponseImpl.this.headers() == null) {
                asyncHttpResponseImpl = AsyncHttpResponseImpl.this;
                connectionClosedException = new ConnectionClosedException("connection closed before headers received.", exc);
            } else {
                if (exc != null) {
                    asyncHttpResponseImpl = AsyncHttpResponseImpl.this;
                    if (!asyncHttpResponseImpl.mCompleted) {
                        connectionClosedException = new ConnectionClosedException("connection closed before response completed.", exc);
                    }
                }
                AsyncHttpResponseImpl.this.report(exc);
                return;
            }
            asyncHttpResponseImpl.report(connectionClosedException);
        }
    };
    public AsyncHttpRequest mRequest;
    public DataSink mSink;
    public AsyncSocket mSocket;
    public String message;
    public String protocol;

    public AsyncHttpResponseImpl(AsyncHttpRequest asyncHttpRequest) {
        this.mRequest = asyncHttpRequest;
    }

    private void assertContent() {
        if (this.mFirstWrite) {
            this.mFirstWrite = false;
        }
    }

    private void terminate() {
        this.mSocket.setDataCallback(new DataCallback.NullDataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                super.onDataAvailable(dataEmitter, byteBufferList);
                AsyncHttpResponseImpl.this.mSocket.close();
            }
        });
    }

    public String charset() {
        String string;
        Multimap parseSemicolonDelimited = Multimap.parseSemicolonDelimited(headers().get("Content-Type"));
        if (parseSemicolonDelimited == null || (string = parseSemicolonDelimited.getString("charset")) == null || !Charset.isSupported(string)) {
            return null;
        }
        return string;
    }

    public void close() {
        super.close();
        terminate();
    }

    public int code() {
        return this.code;
    }

    public AsyncHttpClientMiddleware.ResponseHead code(int i) {
        this.code = i;
        return this;
    }

    public DataEmitter emitter() {
        return getDataEmitter();
    }

    public AsyncHttpClientMiddleware.ResponseHead emitter(DataEmitter dataEmitter) {
        setDataEmitter(dataEmitter);
        return this;
    }

    public AsyncHttpRequest getRequest() {
        return this.mRequest;
    }

    public AsyncServer getServer() {
        return this.mSocket.getServer();
    }

    public AsyncHttpClientMiddleware.ResponseHead headers(Headers headers) {
        this.mHeaders = headers;
        return this;
    }

    public Headers headers() {
        return this.mHeaders;
    }

    public AsyncHttpClientMiddleware.ResponseHead message(String str) {
        this.message = str;
        return this;
    }

    public String message() {
        return this.message;
    }

    public void onHeadersReceived() {
    }

    public void onHeadersSent() {
        AsyncHttpRequestBody body = this.mRequest.getBody();
        if (body != null) {
            body.write(this.mRequest, this.mSink, new CompletedCallback() {
                public void onCompleted(Exception exc) {
                    AsyncHttpResponseImpl.this.onRequestCompleted(exc);
                }
            });
        } else {
            onRequestCompleted((Exception) null);
        }
    }

    public void onRequestCompleted(Exception exc) {
    }

    public AsyncHttpClientMiddleware.ResponseHead protocol(String str) {
        this.protocol = str;
        return this;
    }

    public String protocol() {
        return this.protocol;
    }

    public void report(Exception exc) {
        super.report(exc);
        terminate();
        this.mSocket.setWriteableCallback((WritableCallback) null);
        this.mSocket.setClosedCallback((CompletedCallback) null);
        this.mSocket.setEndCallback((CompletedCallback) null);
        this.mCompleted = true;
    }

    public void setSocket(AsyncSocket asyncSocket) {
        this.mSocket = asyncSocket;
        if (asyncSocket != null) {
            asyncSocket.setEndCallback(this.mReporter);
        }
    }

    public DataSink sink() {
        return this.mSink;
    }

    public AsyncHttpClientMiddleware.ResponseHead sink(DataSink dataSink) {
        this.mSink = dataSink;
        return this;
    }

    public AsyncSocket socket() {
        return this.mSocket;
    }

    public String toString() {
        Headers headers = this.mHeaders;
        if (headers == null) {
            return super.toString();
        }
        return headers.toPrefixString(this.protocol + " " + this.code + " " + this.message);
    }
}
