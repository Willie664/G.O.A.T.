package io.lum.sdk.async.http;

public class ConnectionFailedException extends Exception {
    public ConnectionFailedException(String str) {
        super(str);
    }
}
