package io.lum.sdk.async.http;

import android.net.Uri;
import b.a.a.a.a;
import io.lum.sdk.async.AsyncSSLException;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import java.net.InetSocketAddress;
import java.util.Locale;

public class AsyncHttpRequest {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final int DEFAULT_TIMEOUT = 30000;
    public static final String HEADER_ACCEPT_ALL = "*/*";
    public String LOGTAG;
    public long executionTime;
    public int logLevel;
    public AsyncHttpRequestBody mBody;
    public boolean mFollowRedirect;
    public String mMethod;
    public Headers mRawHeaders;
    public int mTimeout;
    public Headers m_connect_headers;
    public Uri m_domain_uri;
    public InetSocketAddress m_local_address;
    public String m_proxy_domain;
    public boolean m_proxy_ssl;
    public boolean m_proxy_ssl_connected;
    public String proxyHost;
    public int proxyPort;
    public String requestLineProtocol;
    public Uri uri;

    public AsyncHttpRequest(Uri uri2, String str) {
        this(uri2, str, (Headers) null);
    }

    public AsyncHttpRequest(Uri uri2, String str, Headers headers) {
        this.requestLineProtocol = "HTTP/1.1";
        this.mRawHeaders = new Headers();
        this.mFollowRedirect = true;
        this.mTimeout = 30000;
        this.proxyPort = -1;
        this.m_connect_headers = new Headers();
        this.m_proxy_ssl = false;
        this.m_proxy_ssl_connected = false;
        this.mMethod = str;
        this.uri = uri2;
        if (headers == null) {
            this.mRawHeaders = new Headers();
        } else {
            this.mRawHeaders = headers;
        }
        if (headers == null) {
            setDefaultHeaders(this.mRawHeaders, uri2);
        }
    }

    public static String getDefaultUserAgent() {
        String property = System.getProperty("http.agent");
        if (property != null) {
            return property;
        }
        StringBuilder a2 = a.a("Java");
        a2.append(System.getProperty("java.version"));
        return a2.toString();
    }

    private String getLogMessage(String str) {
        long j = 0;
        if (this.executionTime != 0) {
            j = System.currentTimeMillis() - this.executionTime;
        }
        return String.format(Locale.ENGLISH, "(%d ms) %s: %s", new Object[]{Long.valueOf(j), getUri(), str});
    }

    public static void setDefaultHeaders(Headers headers, Uri uri2) {
        if (uri2 != null) {
            String host = uri2.getHost();
            if (uri2.getPort() != -1) {
                StringBuilder b2 = a.b(host, ":");
                b2.append(uri2.getPort());
                host = b2.toString();
            }
            if (host != null) {
                headers.set("Host", host);
            }
        }
        headers.set("User-Agent", getDefaultUserAgent());
        headers.set("Accept-Encoding", "gzip, deflate");
        headers.set("Connection", "keep-alive");
        headers.set("Accept", "*/*");
    }

    public AsyncHttpRequest addHeader(String str, String str2) {
        getHeaders().add(str, str2);
        return this;
    }

    public void disableProxy() {
        this.proxyHost = null;
        this.proxyPort = -1;
    }

    public void enableProxy(String str, int i) {
        this.proxyHost = str;
        this.proxyPort = i;
    }

    public void enable_proxy(String str, int i, String str2, boolean z) {
        enableProxy(str, i);
        this.m_proxy_ssl = z;
        this.m_proxy_domain = str2;
    }

    public AsyncHttpRequestBody getBody() {
        return this.mBody;
    }

    public boolean getFollowRedirect() {
        return this.mFollowRedirect;
    }

    public Headers getHeaders() {
        return this.mRawHeaders;
    }

    public int getLogLevel() {
        return this.logLevel;
    }

    public String getLogTag() {
        return this.LOGTAG;
    }

    public String getMethod() {
        return this.mMethod;
    }

    public String getPath() {
        return getUri().getEncodedPath();
    }

    public String getProxyHost() {
        return this.proxyHost;
    }

    public int getProxyPort() {
        return this.proxyPort;
    }

    public RequestLine getRequestLine() {
        return new RequestLine() {
            public String getMethod() {
                return AsyncHttpRequest.this.mMethod;
            }

            public ProtocolVersion getProtocolVersion() {
                return new ProtocolVersion("HTTP", 1, 1);
            }

            public String getUri() {
                return AsyncHttpRequest.this.getUri().toString();
            }

            public String toString() {
                AsyncHttpRequest asyncHttpRequest = AsyncHttpRequest.this;
                if (asyncHttpRequest.proxyHost != null) {
                    return String.format(Locale.ENGLISH, "%s %s %s", new Object[]{asyncHttpRequest.mMethod, AsyncHttpRequest.this.getUri(), AsyncHttpRequest.this.requestLineProtocol});
                }
                String path = asyncHttpRequest.getPath();
                if (path == null || path.length() == 0) {
                    path = "/";
                }
                String encodedQuery = AsyncHttpRequest.this.getUri().getEncodedQuery();
                if (!(encodedQuery == null || encodedQuery.length() == 0)) {
                    path = a.a(path, "?", encodedQuery);
                }
                return String.format(Locale.ENGLISH, "%s %s %s", new Object[]{AsyncHttpRequest.this.mMethod, path, AsyncHttpRequest.this.requestLineProtocol});
            }
        };
    }

    public String getRequestLineProtocol() {
        return this.requestLineProtocol;
    }

    public int getTimeout() {
        return this.mTimeout;
    }

    public Uri getUri() {
        return this.uri;
    }

    public Headers get_connect_headers() {
        return this.m_connect_headers;
    }

    public Uri get_domain_uri() {
        return this.m_domain_uri;
    }

    public InetSocketAddress get_local_address() {
        return this.m_local_address;
    }

    public boolean get_proxy_connected() {
        return !this.m_proxy_ssl || this.m_proxy_ssl_connected;
    }

    public Uri get_proxy_domain_uri() {
        StringBuilder a2 = a.a("https://");
        a2.append(this.m_proxy_domain);
        return Uri.parse(a2.toString());
    }

    public boolean hasBody() {
        return true;
    }

    public void logd(String str) {
        if (this.LOGTAG != null && this.logLevel <= 3) {
            getLogMessage(str);
        }
    }

    public void logd(String str, Exception exc) {
        if (this.LOGTAG != null && this.logLevel <= 3) {
            getLogMessage(str);
            exc.getMessage();
        }
    }

    public void loge(String str) {
        if (this.LOGTAG != null && this.logLevel <= 6) {
            getLogMessage(str);
        }
    }

    public void loge(String str, Exception exc) {
        if (this.LOGTAG != null && this.logLevel <= 6) {
            getLogMessage(str);
            exc.getMessage();
        }
    }

    public void logi(String str) {
        if (this.LOGTAG != null && this.logLevel <= 4) {
            getLogMessage(str);
        }
    }

    public void logv(String str) {
        if (this.LOGTAG != null && this.logLevel <= 2) {
            getLogMessage(str);
        }
    }

    public void logw(String str) {
        if (this.LOGTAG != null && this.logLevel <= 5) {
            getLogMessage(str);
        }
    }

    public void onHandshakeException(AsyncSSLException asyncSSLException) {
    }

    public void setBody(AsyncHttpRequestBody asyncHttpRequestBody) {
        this.mBody = asyncHttpRequestBody;
    }

    public AsyncHttpRequest setFollowRedirect(boolean z) {
        this.mFollowRedirect = z;
        return this;
    }

    public AsyncHttpRequest setHeader(String str, String str2) {
        getHeaders().set(str, str2);
        return this;
    }

    public void setLogging(String str, int i) {
        this.LOGTAG = str;
        this.logLevel = i;
    }

    public AsyncHttpRequest setMethod(String str) {
        if (getClass() == AsyncHttpRequest.class) {
            this.mMethod = str;
            return this;
        }
        throw new UnsupportedOperationException("can't change method on a subclass of AsyncHttpRequest");
    }

    public void setRequestLineProtocol(String str) {
        this.requestLineProtocol = str;
    }

    public AsyncHttpRequest setTimeout(int i) {
        this.mTimeout = i;
        return this;
    }

    public AsyncHttpRequest set_connect_header(String str, String str2) {
        get_connect_headers().set(str, str2);
        return this;
    }

    public void set_domain_uri(Uri uri2) {
        this.m_domain_uri = uri2;
    }

    public AsyncHttpRequest set_header(String str, String str2, boolean z) {
        setHeader(str, str2);
        if (z) {
            set_connect_header(str, str2);
        }
        return this;
    }

    public void set_local_address(InetSocketAddress inetSocketAddress) {
        this.m_local_address = inetSocketAddress;
    }

    public void set_proxy_connected() {
        this.m_proxy_ssl_connected = true;
    }

    public String toString() {
        Headers headers = this.mRawHeaders;
        return headers == null ? super.toString() : headers.toPrefixString(this.uri.toString());
    }
}
