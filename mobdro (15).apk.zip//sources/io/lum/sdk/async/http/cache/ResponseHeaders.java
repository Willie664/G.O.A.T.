package io.lum.sdk.async.http.cache;

import android.net.Uri;
import com.mobdro.player.FFmpegPlayer;
import io.lum.sdk.async.http.HttpDate;
import io.lum.sdk.async.http.cache.HeaderParser;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

public final class ResponseHeaders {
    public static final String RECEIVED_MILLIS = "X-Android-Received-Millis";
    public static final String SENT_MILLIS = "X-Android-Sent-Millis";
    public int ageSeconds = -1;
    public String connection;
    public String contentEncoding;
    public long contentLength = -1;
    public String etag;
    public Date expires;
    public final RawHeaders headers;
    public boolean isPublic;
    public Date lastModified;
    public int maxAgeSeconds = -1;
    public boolean mustRevalidate;
    public boolean noCache;
    public boolean noStore;
    public String proxyAuthenticate;
    public long receivedResponseMillis;
    public int sMaxAgeSeconds = -1;
    public long sentRequestMillis;
    public Date servedDate;
    public String transferEncoding;
    public final Uri uri;
    public Set<String> varyFields = Collections.emptySet();
    public String wwwAuthenticate;

    public ResponseHeaders(Uri uri2, RawHeaders rawHeaders) {
        this.uri = uri2;
        this.headers = rawHeaders;
        AnonymousClass1 r9 = new HeaderParser.CacheControlHandler() {
            public void handle(String str, String str2) {
                if (str.equalsIgnoreCase("no-cache")) {
                    boolean unused = ResponseHeaders.this.noCache = true;
                } else if (str.equalsIgnoreCase("no-store")) {
                    boolean unused2 = ResponseHeaders.this.noStore = true;
                } else if (str.equalsIgnoreCase("max-age")) {
                    int unused3 = ResponseHeaders.this.maxAgeSeconds = HeaderParser.parseSeconds(str2);
                } else if (str.equalsIgnoreCase("s-maxage")) {
                    int unused4 = ResponseHeaders.this.sMaxAgeSeconds = HeaderParser.parseSeconds(str2);
                } else if (str.equalsIgnoreCase("public")) {
                    boolean unused5 = ResponseHeaders.this.isPublic = true;
                } else if (str.equalsIgnoreCase("must-revalidate")) {
                    boolean unused6 = ResponseHeaders.this.mustRevalidate = true;
                }
            }
        };
        for (int i = 0; i < rawHeaders.length(); i++) {
            String fieldName = rawHeaders.getFieldName(i);
            String value = rawHeaders.getValue(i);
            if ("Cache-Control".equalsIgnoreCase(fieldName)) {
                HeaderParser.parseCacheControl(value, r9);
            } else if ("Date".equalsIgnoreCase(fieldName)) {
                this.servedDate = HttpDate.parse(value);
            } else if ("Expires".equalsIgnoreCase(fieldName)) {
                this.expires = HttpDate.parse(value);
            } else if ("Last-Modified".equalsIgnoreCase(fieldName)) {
                this.lastModified = HttpDate.parse(value);
            } else if ("ETag".equalsIgnoreCase(fieldName)) {
                this.etag = value;
            } else if ("Pragma".equalsIgnoreCase(fieldName)) {
                if (value.equalsIgnoreCase("no-cache")) {
                    this.noCache = true;
                }
            } else if ("Age".equalsIgnoreCase(fieldName)) {
                this.ageSeconds = HeaderParser.parseSeconds(value);
            } else if ("Vary".equalsIgnoreCase(fieldName)) {
                if (this.varyFields.isEmpty()) {
                    this.varyFields = new TreeSet(String.CASE_INSENSITIVE_ORDER);
                }
                for (String trim : value.split(",")) {
                    this.varyFields.add(trim.trim().toLowerCase(Locale.US));
                }
            } else if ("Content-Encoding".equalsIgnoreCase(fieldName)) {
                this.contentEncoding = value;
            } else if ("Transfer-Encoding".equalsIgnoreCase(fieldName)) {
                this.transferEncoding = value;
            } else if ("Content-Length".equalsIgnoreCase(fieldName)) {
                try {
                    this.contentLength = Long.parseLong(value);
                } catch (NumberFormatException unused) {
                }
            } else if ("Connection".equalsIgnoreCase(fieldName)) {
                this.connection = value;
            } else if ("Proxy-Authenticate".equalsIgnoreCase(fieldName)) {
                this.proxyAuthenticate = value;
            } else if ("WWW-Authenticate".equalsIgnoreCase(fieldName)) {
                this.wwwAuthenticate = value;
            } else if (SENT_MILLIS.equalsIgnoreCase(fieldName)) {
                this.sentRequestMillis = Long.parseLong(value);
            } else if (RECEIVED_MILLIS.equalsIgnoreCase(fieldName)) {
                this.receivedResponseMillis = Long.parseLong(value);
            }
        }
    }

    private long computeAge(long j) {
        Date date = this.servedDate;
        long j2 = 0;
        if (date != null) {
            j2 = Math.max(0, this.receivedResponseMillis - date.getTime());
        }
        int i = this.ageSeconds;
        if (i != -1) {
            j2 = Math.max(j2, TimeUnit.SECONDS.toMillis((long) i));
        }
        long j3 = this.receivedResponseMillis;
        return j2 + (j3 - this.sentRequestMillis) + (j - j3);
    }

    private long computeFreshnessLifetime() {
        int i = this.maxAgeSeconds;
        if (i != -1) {
            return TimeUnit.SECONDS.toMillis((long) i);
        }
        if (this.expires != null) {
            Date date = this.servedDate;
            long time = this.expires.getTime() - (date != null ? date.getTime() : this.receivedResponseMillis);
            if (time > 0) {
                return time;
            }
            return 0;
        } else if (this.lastModified == null || this.uri.getEncodedQuery() != null) {
            return 0;
        } else {
            Date date2 = this.servedDate;
            long time2 = (date2 != null ? date2.getTime() : this.sentRequestMillis) - this.lastModified.getTime();
            if (time2 > 0) {
                return time2 / 10;
            }
            return 0;
        }
    }

    public static boolean isEndToEnd(String str) {
        return !str.equalsIgnoreCase("Connection") && !str.equalsIgnoreCase("Keep-Alive") && !str.equalsIgnoreCase("Proxy-Authenticate") && !str.equalsIgnoreCase("Proxy-Authorization") && !str.equalsIgnoreCase("TE") && !str.equalsIgnoreCase("Trailers") && !str.equalsIgnoreCase("Transfer-Encoding") && !str.equalsIgnoreCase("Upgrade");
    }

    private boolean isFreshnessLifetimeHeuristic() {
        return this.maxAgeSeconds == -1 && this.expires == null;
    }

    public ResponseSource chooseResponseSource(long j, RequestHeaders requestHeaders) {
        if (!isCacheable(requestHeaders)) {
            return ResponseSource.NETWORK;
        }
        if (requestHeaders.isNoCache() || requestHeaders.hasConditions()) {
            return ResponseSource.NETWORK;
        }
        long computeAge = computeAge(j);
        long computeFreshnessLifetime = computeFreshnessLifetime();
        if (requestHeaders.getMaxAgeSeconds() != -1) {
            computeFreshnessLifetime = Math.min(computeFreshnessLifetime, TimeUnit.SECONDS.toMillis((long) requestHeaders.getMaxAgeSeconds()));
        }
        long j2 = 0;
        long millis = requestHeaders.getMinFreshSeconds() != -1 ? TimeUnit.SECONDS.toMillis((long) requestHeaders.getMinFreshSeconds()) : 0;
        if (!this.mustRevalidate && requestHeaders.getMaxStaleSeconds() != -1) {
            j2 = TimeUnit.SECONDS.toMillis((long) requestHeaders.getMaxStaleSeconds());
        }
        if (!this.noCache) {
            long j3 = millis + computeAge;
            if (j3 < j2 + computeFreshnessLifetime) {
                if (j3 >= computeFreshnessLifetime) {
                    this.headers.add("Warning", "110 HttpURLConnection \"Response is stale\"");
                }
                if (computeAge > 86400000 && isFreshnessLifetimeHeuristic()) {
                    this.headers.add("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                }
                return ResponseSource.CACHE;
            }
        }
        String str = this.etag;
        if (str != null) {
            requestHeaders.setIfNoneMatch(str);
        } else {
            Date date = this.lastModified;
            if (!(date == null && (date = this.servedDate) == null)) {
                requestHeaders.setIfModifiedSince(date);
            }
        }
        return requestHeaders.hasConditions() ? ResponseSource.CONDITIONAL_CACHE : ResponseSource.NETWORK;
    }

    public ResponseHeaders combine(ResponseHeaders responseHeaders) {
        RawHeaders rawHeaders = new RawHeaders();
        for (int i = 0; i < this.headers.length(); i++) {
            String fieldName = this.headers.getFieldName(i);
            String value = this.headers.getValue(i);
            if ((!fieldName.equals("Warning") || !value.startsWith(FFmpegPlayer.HW_ACCEL_STATE)) && (!isEndToEnd(fieldName) || responseHeaders.headers.get(fieldName) == null)) {
                rawHeaders.add(fieldName, value);
            }
        }
        for (int i2 = 0; i2 < responseHeaders.headers.length(); i2++) {
            String fieldName2 = responseHeaders.headers.getFieldName(i2);
            if (isEndToEnd(fieldName2)) {
                rawHeaders.add(fieldName2, responseHeaders.headers.getValue(i2));
            }
        }
        return new ResponseHeaders(this.uri, rawHeaders);
    }

    public String getConnection() {
        return this.connection;
    }

    public String getContentEncoding() {
        return this.contentEncoding;
    }

    public long getContentLength() {
        return this.contentLength;
    }

    public String getEtag() {
        return this.etag;
    }

    public Date getExpires() {
        return this.expires;
    }

    public RawHeaders getHeaders() {
        return this.headers;
    }

    public Date getLastModified() {
        return this.lastModified;
    }

    public int getMaxAgeSeconds() {
        return this.maxAgeSeconds;
    }

    public String getProxyAuthenticate() {
        return this.proxyAuthenticate;
    }

    public int getSMaxAgeSeconds() {
        return this.sMaxAgeSeconds;
    }

    public Date getServedDate() {
        return this.servedDate;
    }

    public Uri getUri() {
        return this.uri;
    }

    public Set<String> getVaryFields() {
        return this.varyFields;
    }

    public String getWwwAuthenticate() {
        return this.wwwAuthenticate;
    }

    public boolean hasConnectionClose() {
        return "close".equalsIgnoreCase(this.connection);
    }

    public boolean hasVaryAll() {
        return this.varyFields.contains("*");
    }

    public boolean isCacheable(RequestHeaders requestHeaders) {
        int responseCode = this.headers.getResponseCode();
        if (responseCode == 200 || responseCode == 203 || responseCode == 300 || responseCode == 301 || responseCode == 410) {
            return (!requestHeaders.hasAuthorization() || this.isPublic || this.mustRevalidate || this.sMaxAgeSeconds != -1) && !this.noStore;
        }
        return false;
    }

    public boolean isChunked() {
        return "chunked".equalsIgnoreCase(this.transferEncoding);
    }

    public boolean isContentEncodingGzip() {
        return "gzip".equalsIgnoreCase(this.contentEncoding);
    }

    public boolean isMustRevalidate() {
        return this.mustRevalidate;
    }

    public boolean isNoCache() {
        return this.noCache;
    }

    public boolean isNoStore() {
        return this.noStore;
    }

    public boolean isPublic() {
        return this.isPublic;
    }

    public void setLocalTimestamps(long j, long j2) {
        this.sentRequestMillis = j;
        this.headers.add(SENT_MILLIS, Long.toString(j));
        this.receivedResponseMillis = j2;
        this.headers.add(RECEIVED_MILLIS, Long.toString(j2));
    }

    public void stripContentEncoding() {
        this.contentEncoding = null;
        this.headers.removeAll("Content-Encoding");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0010, code lost:
        r7 = r7.lastModified;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean validate(io.lum.sdk.async.http.cache.ResponseHeaders r7) {
        /*
            r6 = this;
            io.lum.sdk.async.http.cache.RawHeaders r0 = r7.headers
            int r0 = r0.getResponseCode()
            r1 = 1
            r2 = 304(0x130, float:4.26E-43)
            if (r0 != r2) goto L_0x000c
            return r1
        L_0x000c:
            java.util.Date r0 = r6.lastModified
            if (r0 == 0) goto L_0x0023
            java.util.Date r7 = r7.lastModified
            if (r7 == 0) goto L_0x0023
            long r2 = r7.getTime()
            java.util.Date r7 = r6.lastModified
            long r4 = r7.getTime()
            int r7 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r7 >= 0) goto L_0x0023
            return r1
        L_0x0023:
            r7 = 0
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.cache.ResponseHeaders.validate(io.lum.sdk.async.http.cache.ResponseHeaders):boolean");
    }

    public boolean varyMatches(Map<String, List<String>> map, Map<String, List<String>> map2) {
        for (String next : this.varyFields) {
            if (!Objects.equal(map.get(next), map2.get(next))) {
                return false;
            }
        }
        return true;
    }
}
