package io.lum.sdk.async.http.body;

import d.a.a.b2.v.q.a;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.parser.ByteBufferListParser;

public class ByteBufferListRequestBody implements AsyncHttpRequestBody<ByteBufferList> {
    public static String CONTENT_TYPE = "application/binary";
    public ByteBufferList bb;

    public ByteBufferListRequestBody() {
    }

    public ByteBufferListRequestBody(ByteBufferList byteBufferList) {
        this.bb = byteBufferList;
    }

    public /* synthetic */ void a(CompletedCallback completedCallback, Exception exc, ByteBufferList byteBufferList) {
        this.bb = byteBufferList;
        completedCallback.onCompleted(exc);
    }

    public ByteBufferList get() {
        return this.bb;
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

    public int length() {
        return this.bb.remaining();
    }

    public void parse(DataEmitter dataEmitter, CompletedCallback completedCallback) {
        new ByteBufferListParser().parse(dataEmitter).setCallback(new a(this, completedCallback));
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        Util.writeAll(dataSink, this.bb, completedCallback);
    }
}
