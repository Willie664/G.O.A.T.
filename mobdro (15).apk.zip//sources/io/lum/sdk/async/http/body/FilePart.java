package io.lum.sdk.async.http.body;

import io.lum.sdk.async.http.BasicNameValuePair;
import io.lum.sdk.async.http.NameValuePair;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class FilePart extends StreamPart {
    public File file;

    public FilePart(String str, final File file2) {
        super(str, (long) ((int) file2.length()), new ArrayList<NameValuePair>() {
            {
                add(new BasicNameValuePair("filename", file2.getName()));
            }
        });
        this.file = file2;
    }

    public InputStream getInputStream() {
        return new FileInputStream(this.file);
    }

    public String toString() {
        return getName();
    }
}
