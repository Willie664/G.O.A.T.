package io.lum.sdk.async.http;

public class BodyDecoderException extends Exception {
    public BodyDecoderException(String str) {
        super(str);
    }
}
