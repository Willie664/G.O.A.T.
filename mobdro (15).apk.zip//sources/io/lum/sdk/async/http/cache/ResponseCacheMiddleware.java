package io.lum.sdk.async.http.cache;

import android.net.Uri;
import android.util.Base64;
import io.lum.sdk.async.AsyncSSLSocket;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.SimpleCancellable;
import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.http.AsyncHttpGet;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.SimpleMiddleware;
import io.lum.sdk.async.util.Allocator;
import io.lum.sdk.async.util.Charsets;
import io.lum.sdk.async.util.FileCache;
import io.lum.sdk.async.util.StreamUtility;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.CacheResponse;
import java.nio.ByteBuffer;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.SSLEngine;

public class ResponseCacheMiddleware extends SimpleMiddleware {
    public static final String CACHE = "cache";
    public static final String CONDITIONAL_CACHE = "conditional-cache";
    public static final int ENTRY_BODY = 1;
    public static final int ENTRY_COUNT = 2;
    public static final int ENTRY_METADATA = 0;
    public static final String LOGTAG = "AsyncHttpCache";
    public static final String SERVED_FROM = "X-Served-From";
    public FileCache cache;
    public int cacheHitCount;
    public int cacheStoreCount;
    public boolean caching = true;
    public int conditionalCacheHitCount;
    public int networkCount;
    public AsyncServer server;
    public int writeAbortCount;
    public int writeSuccessCount;

    public static class BodyCacher extends FilteredDataEmitter {
        public ByteBufferList cached;
        public EntryEditor editor;

        public BodyCacher() {
        }

        public void abort() {
            EntryEditor entryEditor = this.editor;
            if (entryEditor != null) {
                entryEditor.abort();
                this.editor = null;
            }
        }

        public void close() {
            abort();
            super.close();
        }

        public void commit() {
            EntryEditor entryEditor = this.editor;
            if (entryEditor != null) {
                entryEditor.commit();
                this.editor = null;
            }
        }

        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0047 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onDataAvailable(io.lum.sdk.async.DataEmitter r4, io.lum.sdk.async.ByteBufferList r5) {
            /*
                r3 = this;
                io.lum.sdk.async.ByteBufferList r0 = r3.cached
                if (r0 == 0) goto L_0x0013
                super.onDataAvailable(r4, r0)
                io.lum.sdk.async.ByteBufferList r0 = r3.cached
                int r0 = r0.remaining()
                if (r0 <= 0) goto L_0x0010
                return
            L_0x0010:
                r0 = 0
                r3.cached = r0
            L_0x0013:
                io.lum.sdk.async.ByteBufferList r0 = new io.lum.sdk.async.ByteBufferList
                r0.<init>()
                io.lum.sdk.async.http.cache.ResponseCacheMiddleware$EntryEditor r1 = r3.editor     // Catch:{ Exception -> 0x0047 }
                if (r1 == 0) goto L_0x003e
                io.lum.sdk.async.http.cache.ResponseCacheMiddleware$EntryEditor r1 = r3.editor     // Catch:{ Exception -> 0x0047 }
                r2 = 1
                java.io.FileOutputStream r1 = r1.newOutputStream(r2)     // Catch:{ Exception -> 0x0047 }
                if (r1 == 0) goto L_0x003b
            L_0x0025:
                boolean r2 = r5.isEmpty()     // Catch:{ Exception -> 0x0047 }
                if (r2 != 0) goto L_0x003e
                java.nio.ByteBuffer r2 = r5.remove()     // Catch:{ Exception -> 0x0047 }
                io.lum.sdk.async.ByteBufferList.writeOutputStream(r1, r2)     // Catch:{ all -> 0x0036 }
                r0.add((java.nio.ByteBuffer) r2)     // Catch:{ Exception -> 0x0047 }
                goto L_0x0025
            L_0x0036:
                r1 = move-exception
                r0.add((java.nio.ByteBuffer) r2)     // Catch:{ Exception -> 0x0047 }
                throw r1     // Catch:{ Exception -> 0x0047 }
            L_0x003b:
                r3.abort()     // Catch:{ Exception -> 0x0047 }
            L_0x003e:
                r5.get((io.lum.sdk.async.ByteBufferList) r0)
                r0.get((io.lum.sdk.async.ByteBufferList) r5)
                goto L_0x004b
            L_0x0045:
                r4 = move-exception
                goto L_0x0063
            L_0x0047:
                r3.abort()     // Catch:{ all -> 0x0045 }
                goto L_0x003e
            L_0x004b:
                super.onDataAvailable(r4, r5)
                io.lum.sdk.async.http.cache.ResponseCacheMiddleware$EntryEditor r4 = r3.editor
                if (r4 == 0) goto L_0x0062
                int r4 = r5.remaining()
                if (r4 <= 0) goto L_0x0062
                io.lum.sdk.async.ByteBufferList r4 = new io.lum.sdk.async.ByteBufferList
                r4.<init>()
                r3.cached = r4
                r5.get((io.lum.sdk.async.ByteBufferList) r4)
            L_0x0062:
                return
            L_0x0063:
                r5.get((io.lum.sdk.async.ByteBufferList) r0)
                r0.get((io.lum.sdk.async.ByteBufferList) r5)
                goto L_0x006b
            L_0x006a:
                throw r4
            L_0x006b:
                goto L_0x006a
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.cache.ResponseCacheMiddleware.BodyCacher.onDataAvailable(io.lum.sdk.async.DataEmitter, io.lum.sdk.async.ByteBufferList):void");
        }

        public void report(Exception exc) {
            super.report(exc);
            if (exc != null) {
                abort();
            }
        }
    }

    public static class CacheData {
        public ResponseHeaders cachedResponseHeaders;
        public EntryCacheResponse candidate;
        public long contentLength;
        public FileInputStream[] snapshot;
    }

    public static class CachedBodyEmitter extends FilteredDataEmitter {
        public static final /* synthetic */ boolean $assertionsDisabled = false;
        public Allocator allocator = new Allocator();
        public boolean allowEnd;
        public EntryCacheResponse cacheResponse;
        public boolean paused;
        public ByteBufferList pending = new ByteBufferList();
        public Runnable sendCachedDataRunnable = new Runnable() {
            public void run() {
                CachedBodyEmitter.this.sendCachedDataOnNetworkThread();
            }
        };

        public CachedBodyEmitter(EntryCacheResponse entryCacheResponse, long j) {
            this.cacheResponse = entryCacheResponse;
            this.allocator.setCurrentAlloc((int) j);
        }

        public void close() {
            if (getServer().getAffinity() != Thread.currentThread()) {
                getServer().post(new Runnable() {
                    public void run() {
                        CachedBodyEmitter.this.close();
                    }
                });
                return;
            }
            this.pending.recycle();
            StreamUtility.closeQuietly(this.cacheResponse.getBody());
            super.close();
        }

        public boolean isPaused() {
            return this.paused;
        }

        public void report(Exception exc) {
            if (this.allowEnd) {
                StreamUtility.closeQuietly(this.cacheResponse.getBody());
                super.report(exc);
            }
        }

        public void resume() {
            this.paused = false;
            sendCachedData();
        }

        public void sendCachedData() {
            getServer().post(this.sendCachedDataRunnable);
        }

        public void sendCachedDataOnNetworkThread() {
            if (this.pending.remaining() > 0) {
                super.onDataAvailable(this, this.pending);
                if (this.pending.remaining() > 0) {
                    return;
                }
            }
            try {
                ByteBuffer allocate = this.allocator.allocate();
                int read = this.cacheResponse.getBody().read(allocate.array(), allocate.arrayOffset(), allocate.capacity());
                if (read == -1) {
                    ByteBufferList.reclaim(allocate);
                    this.allowEnd = true;
                    report((Exception) null);
                    return;
                }
                this.allocator.track((long) read);
                allocate.limit(read);
                this.pending.add(allocate);
                super.onDataAvailable(this, this.pending);
                if (this.pending.remaining() <= 0) {
                    getServer().postDelayed(this.sendCachedDataRunnable, 10);
                }
            } catch (IOException e2) {
                this.allowEnd = true;
                report(e2);
            }
        }
    }

    public class CachedSSLSocket extends CachedSocket implements AsyncSSLSocket {
        public CachedSSLSocket(EntryCacheResponse entryCacheResponse, long j) {
            super(entryCacheResponse, j);
        }

        public X509Certificate[] getPeerCertificates() {
            return null;
        }

        public SSLEngine getSSLEngine() {
            return null;
        }
    }

    public class CachedSocket extends CachedBodyEmitter implements AsyncSocket {
        public boolean closed;
        public CompletedCallback closedCallback;
        public boolean open;

        public CachedSocket(EntryCacheResponse entryCacheResponse, long j) {
            super(entryCacheResponse, j);
            this.allowEnd = true;
        }

        public void close() {
            this.open = false;
        }

        public void end() {
        }

        public CompletedCallback getClosedCallback() {
            return this.closedCallback;
        }

        public AsyncServer getServer() {
            return ResponseCacheMiddleware.this.server;
        }

        public WritableCallback getWriteableCallback() {
            return null;
        }

        public boolean isOpen() {
            return this.open;
        }

        public void report(Exception exc) {
            super.report(exc);
            if (!this.closed) {
                this.closed = true;
                CompletedCallback completedCallback = this.closedCallback;
                if (completedCallback != null) {
                    completedCallback.onCompleted(exc);
                }
            }
        }

        public void setClosedCallback(CompletedCallback completedCallback) {
            this.closedCallback = completedCallback;
        }

        public void setWriteableCallback(WritableCallback writableCallback) {
        }

        public void write(ByteBufferList byteBufferList) {
            byteBufferList.recycle();
        }
    }

    public static final class Entry {
        public final String cipherSuite;
        public final Certificate[] localCertificates;
        public final Certificate[] peerCertificates;
        public final String requestMethod;
        public final RawHeaders responseHeaders;
        public final String uri;
        public final RawHeaders varyHeaders;

        public Entry(Uri uri2, RawHeaders rawHeaders, AsyncHttpRequest asyncHttpRequest, RawHeaders rawHeaders2) {
            this.uri = uri2.toString();
            this.varyHeaders = rawHeaders;
            this.requestMethod = asyncHttpRequest.getMethod();
            this.responseHeaders = rawHeaders2;
            this.cipherSuite = null;
            this.peerCertificates = null;
            this.localCertificates = null;
        }

        public Entry(InputStream inputStream) {
            StrictLineReader strictLineReader;
            Throwable th;
            try {
                strictLineReader = new StrictLineReader(inputStream, Charsets.US_ASCII);
                try {
                    this.uri = strictLineReader.readLine();
                    this.requestMethod = strictLineReader.readLine();
                    this.varyHeaders = new RawHeaders();
                    int readInt = strictLineReader.readInt();
                    for (int i = 0; i < readInt; i++) {
                        this.varyHeaders.addLine(strictLineReader.readLine());
                    }
                    RawHeaders rawHeaders = new RawHeaders();
                    this.responseHeaders = rawHeaders;
                    rawHeaders.setStatusLine(strictLineReader.readLine());
                    int readInt2 = strictLineReader.readInt();
                    for (int i2 = 0; i2 < readInt2; i2++) {
                        this.responseHeaders.addLine(strictLineReader.readLine());
                    }
                    this.cipherSuite = null;
                    this.peerCertificates = null;
                    this.localCertificates = null;
                    StreamUtility.closeQuietly(strictLineReader, inputStream);
                } catch (Throwable th2) {
                    th = th2;
                    StreamUtility.closeQuietly(strictLineReader, inputStream);
                    throw th;
                }
            } catch (Throwable th3) {
                Throwable th4 = th3;
                strictLineReader = null;
                th = th4;
                StreamUtility.closeQuietly(strictLineReader, inputStream);
                throw th;
            }
        }

        /* access modifiers changed from: private */
        public boolean isHttps() {
            return this.uri.startsWith("https://");
        }

        private Certificate[] readCertArray(StrictLineReader strictLineReader) {
            int readInt = strictLineReader.readInt();
            if (readInt == -1) {
                return null;
            }
            try {
                CertificateFactory instance = CertificateFactory.getInstance("X.509");
                Certificate[] certificateArr = new Certificate[readInt];
                for (int i = 0; i < readInt; i++) {
                    certificateArr[i] = instance.generateCertificate(new ByteArrayInputStream(Base64.decode(strictLineReader.readLine(), 0)));
                }
                return certificateArr;
            } catch (CertificateException e2) {
                throw new IOException(e2.getMessage());
            }
        }

        private void writeCertArray(Writer writer, Certificate[] certificateArr) {
            if (certificateArr == null) {
                writer.write("-1\n");
                return;
            }
            try {
                writer.write(Integer.toString(certificateArr.length) + 10);
                for (Certificate encoded : certificateArr) {
                    writer.write(Base64.encodeToString(encoded.getEncoded(), 0) + 10);
                }
            } catch (CertificateEncodingException e2) {
                throw new IOException(e2.getMessage());
            }
        }

        public boolean matches(Uri uri2, String str, Map<String, List<String>> map) {
            return this.uri.equals(uri2.toString()) && this.requestMethod.equals(str) && new ResponseHeaders(uri2, this.responseHeaders).varyMatches(this.varyHeaders.toMultimap(), map);
        }

        public void writeTo(EntryEditor entryEditor) {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(entryEditor.newOutputStream(0), Charsets.UTF_8));
            bufferedWriter.write(this.uri + 10);
            bufferedWriter.write(this.requestMethod + 10);
            bufferedWriter.write(Integer.toString(this.varyHeaders.length()) + 10);
            for (int i = 0; i < this.varyHeaders.length(); i++) {
                bufferedWriter.write(this.varyHeaders.getFieldName(i) + ": " + this.varyHeaders.getValue(i) + 10);
            }
            bufferedWriter.write(this.responseHeaders.getStatusLine() + 10);
            bufferedWriter.write(Integer.toString(this.responseHeaders.length()) + 10);
            for (int i2 = 0; i2 < this.responseHeaders.length(); i2++) {
                bufferedWriter.write(this.responseHeaders.getFieldName(i2) + ": " + this.responseHeaders.getValue(i2) + 10);
            }
            if (isHttps()) {
                bufferedWriter.write(10);
                bufferedWriter.write(this.cipherSuite + 10);
                writeCertArray(bufferedWriter, this.peerCertificates);
                writeCertArray(bufferedWriter, this.localCertificates);
            }
            bufferedWriter.close();
        }
    }

    public static class EntryCacheResponse extends CacheResponse {
        public final Entry entry;
        public final FileInputStream snapshot;

        public EntryCacheResponse(Entry entry2, FileInputStream fileInputStream) {
            this.entry = entry2;
            this.snapshot = fileInputStream;
        }

        public FileInputStream getBody() {
            return this.snapshot;
        }

        public Map<String, List<String>> getHeaders() {
            return this.entry.responseHeaders.toMultimap();
        }
    }

    public class EntryEditor {
        public boolean done;
        public String key;
        public FileOutputStream[] outs = new FileOutputStream[2];
        public File[] temps;

        public EntryEditor(String str) {
            this.key = str;
            this.temps = ResponseCacheMiddleware.this.cache.getTempFiles(2);
        }

        public void abort() {
            StreamUtility.closeQuietly(this.outs);
            FileCache.removeFiles(this.temps);
            if (!this.done) {
                ResponseCacheMiddleware.access$608(ResponseCacheMiddleware.this);
                this.done = true;
            }
        }

        public void commit() {
            StreamUtility.closeQuietly(this.outs);
            if (!this.done) {
                ResponseCacheMiddleware.this.cache.commitTempFiles(this.key, this.temps);
                ResponseCacheMiddleware.access$508(ResponseCacheMiddleware.this);
                this.done = true;
            }
        }

        public FileOutputStream newOutputStream(int i) {
            FileOutputStream[] fileOutputStreamArr = this.outs;
            if (fileOutputStreamArr[i] == null) {
                fileOutputStreamArr[i] = new FileOutputStream(this.temps[i]);
            }
            return this.outs[i];
        }
    }

    public static /* synthetic */ int access$508(ResponseCacheMiddleware responseCacheMiddleware) {
        int i = responseCacheMiddleware.writeSuccessCount;
        responseCacheMiddleware.writeSuccessCount = i + 1;
        return i;
    }

    public static /* synthetic */ int access$608(ResponseCacheMiddleware responseCacheMiddleware) {
        int i = responseCacheMiddleware.writeAbortCount;
        responseCacheMiddleware.writeAbortCount = i + 1;
        return i;
    }

    public static ResponseCacheMiddleware addCache(AsyncHttpClient asyncHttpClient, File file, long j) {
        for (AsyncHttpClientMiddleware asyncHttpClientMiddleware : asyncHttpClient.getMiddleware()) {
            if (asyncHttpClientMiddleware instanceof ResponseCacheMiddleware) {
                throw new IOException("Response cache already added to http client");
            }
        }
        ResponseCacheMiddleware responseCacheMiddleware = new ResponseCacheMiddleware();
        responseCacheMiddleware.server = asyncHttpClient.getServer();
        responseCacheMiddleware.cache = new FileCache(file, j, false);
        asyncHttpClient.insertMiddleware(responseCacheMiddleware);
        return responseCacheMiddleware;
    }

    public void clear() {
        FileCache fileCache = this.cache;
        if (fileCache != null) {
            fileCache.clear();
        }
    }

    public int getCacheHitCount() {
        return this.cacheHitCount;
    }

    public int getCacheStoreCount() {
        return this.cacheStoreCount;
    }

    public boolean getCaching() {
        return this.caching;
    }

    public int getConditionalCacheHitCount() {
        return this.conditionalCacheHitCount;
    }

    public FileCache getFileCache() {
        return this.cache;
    }

    public int getNetworkCount() {
        return this.networkCount;
    }

    public Cancellable getSocket(final AsyncHttpClientMiddleware.GetSocketData getSocketData) {
        FileInputStream[] fileInputStreamArr;
        RequestHeaders requestHeaders = new RequestHeaders(getSocketData.request.getUri(), RawHeaders.fromMultimap(getSocketData.request.getHeaders().getMultiMap()));
        getSocketData.state.put("request-headers", requestHeaders);
        if (this.cache == null || !this.caching || requestHeaders.isNoCache()) {
            this.networkCount++;
            return null;
        }
        try {
            fileInputStreamArr = this.cache.get(FileCache.toKeyString(getSocketData.request.getUri()), 2);
            if (fileInputStreamArr == null) {
                try {
                    this.networkCount++;
                    return null;
                } catch (IOException unused) {
                    this.networkCount++;
                    StreamUtility.closeQuietly(fileInputStreamArr);
                    return null;
                }
            } else {
                long available = (long) fileInputStreamArr[1].available();
                Entry entry = new Entry(fileInputStreamArr[0]);
                if (!entry.matches(getSocketData.request.getUri(), getSocketData.request.getMethod(), getSocketData.request.getHeaders().getMultiMap())) {
                    this.networkCount++;
                    StreamUtility.closeQuietly(fileInputStreamArr);
                    return null;
                }
                EntryCacheResponse entryCacheResponse = new EntryCacheResponse(entry, fileInputStreamArr[1]);
                try {
                    Map<String, List<String>> headers = entryCacheResponse.getHeaders();
                    FileInputStream body = entryCacheResponse.getBody();
                    if (headers == null || body == null) {
                        this.networkCount++;
                        StreamUtility.closeQuietly(fileInputStreamArr);
                        return null;
                    }
                    RawHeaders fromMultimap = RawHeaders.fromMultimap(headers);
                    ResponseHeaders responseHeaders = new ResponseHeaders(getSocketData.request.getUri(), fromMultimap);
                    fromMultimap.set("Content-Length", String.valueOf(available));
                    fromMultimap.removeAll("Content-Encoding");
                    fromMultimap.removeAll("Transfer-Encoding");
                    responseHeaders.setLocalTimestamps(System.currentTimeMillis(), System.currentTimeMillis());
                    ResponseSource chooseResponseSource = responseHeaders.chooseResponseSource(System.currentTimeMillis(), requestHeaders);
                    if (chooseResponseSource == ResponseSource.CACHE) {
                        getSocketData.request.logi("Response retrieved from cache");
                        final CachedSocket cachedSSLSocket = entry.isHttps() ? new CachedSSLSocket(entryCacheResponse, available) : new CachedSocket(entryCacheResponse, available);
                        cachedSSLSocket.pending.add(ByteBuffer.wrap(fromMultimap.toHeaderString().getBytes()));
                        this.server.post(new Runnable() {
                            public void run() {
                                getSocketData.connectCallback.onConnectCompleted((Exception) null, cachedSSLSocket);
                                cachedSSLSocket.sendCachedDataOnNetworkThread();
                            }
                        });
                        this.cacheHitCount++;
                        getSocketData.state.put("socket-owner", this);
                        SimpleCancellable simpleCancellable = new SimpleCancellable();
                        simpleCancellable.setComplete();
                        return simpleCancellable;
                    } else if (chooseResponseSource == ResponseSource.CONDITIONAL_CACHE) {
                        getSocketData.request.logi("Response may be served from conditional cache");
                        CacheData cacheData = new CacheData();
                        cacheData.snapshot = fileInputStreamArr;
                        cacheData.contentLength = available;
                        cacheData.cachedResponseHeaders = responseHeaders;
                        cacheData.candidate = entryCacheResponse;
                        getSocketData.state.put("cache-data", cacheData);
                        return null;
                    } else {
                        getSocketData.request.logd("Response can not be served from cache");
                        this.networkCount++;
                        StreamUtility.closeQuietly(fileInputStreamArr);
                        return null;
                    }
                } catch (Exception unused2) {
                    this.networkCount++;
                    StreamUtility.closeQuietly(fileInputStreamArr);
                    return null;
                }
            }
        } catch (IOException unused3) {
            fileInputStreamArr = null;
            this.networkCount++;
            StreamUtility.closeQuietly(fileInputStreamArr);
            return null;
        }
    }

    public void onBodyDecoder(AsyncHttpClientMiddleware.OnBodyDecoderData onBodyDecoderData) {
        if (((CachedSocket) Util.getWrappedSocket(onBodyDecoderData.socket, CachedSocket.class)) != null) {
            onBodyDecoderData.response.headers().set(SERVED_FROM, CACHE);
            return;
        }
        CacheData cacheData = (CacheData) onBodyDecoderData.state.get("cache-data");
        RawHeaders fromMultimap = RawHeaders.fromMultimap(onBodyDecoderData.response.headers().getMultiMap());
        fromMultimap.removeAll("Content-Length");
        fromMultimap.setStatusLine(String.format(Locale.ENGLISH, "%s %s %s", new Object[]{onBodyDecoderData.response.protocol(), Integer.valueOf(onBodyDecoderData.response.code()), onBodyDecoderData.response.message()}));
        ResponseHeaders responseHeaders = new ResponseHeaders(onBodyDecoderData.request.getUri(), fromMultimap);
        onBodyDecoderData.state.put("response-headers", responseHeaders);
        if (cacheData != null) {
            if (cacheData.cachedResponseHeaders.validate(responseHeaders)) {
                onBodyDecoderData.request.logi("Serving response from conditional cache");
                ResponseHeaders combine = cacheData.cachedResponseHeaders.combine(responseHeaders);
                onBodyDecoderData.response.headers(new Headers(combine.getHeaders().toMultimap()));
                onBodyDecoderData.response.code(combine.getHeaders().getResponseCode());
                onBodyDecoderData.response.message(combine.getHeaders().getResponseMessage());
                onBodyDecoderData.response.headers().set(SERVED_FROM, CONDITIONAL_CACHE);
                this.conditionalCacheHitCount++;
                CachedBodyEmitter cachedBodyEmitter = new CachedBodyEmitter(cacheData.candidate, cacheData.contentLength);
                cachedBodyEmitter.setDataEmitter(onBodyDecoderData.bodyEmitter);
                onBodyDecoderData.bodyEmitter = cachedBodyEmitter;
                cachedBodyEmitter.sendCachedData();
                return;
            }
            onBodyDecoderData.state.remove("cache-data");
            StreamUtility.closeQuietly(cacheData.snapshot);
        }
        if (this.caching) {
            RequestHeaders requestHeaders = (RequestHeaders) onBodyDecoderData.state.get("request-headers");
            if (requestHeaders == null || !responseHeaders.isCacheable(requestHeaders) || !onBodyDecoderData.request.getMethod().equals(AsyncHttpGet.METHOD)) {
                this.networkCount++;
                onBodyDecoderData.request.logd("Response is not cacheable");
                return;
            }
            String keyString = FileCache.toKeyString(onBodyDecoderData.request.getUri());
            Entry entry = new Entry(onBodyDecoderData.request.getUri(), requestHeaders.getHeaders().getAll(responseHeaders.getVaryFields()), onBodyDecoderData.request, responseHeaders.getHeaders());
            BodyCacher bodyCacher = new BodyCacher();
            EntryEditor entryEditor = new EntryEditor(keyString);
            try {
                entry.writeTo(entryEditor);
                entryEditor.newOutputStream(1);
                bodyCacher.editor = entryEditor;
                bodyCacher.setDataEmitter(onBodyDecoderData.bodyEmitter);
                onBodyDecoderData.bodyEmitter = bodyCacher;
                onBodyDecoderData.state.put("body-cacher", bodyCacher);
                onBodyDecoderData.request.logd("Caching response");
                this.cacheStoreCount++;
            } catch (Exception unused) {
                entryEditor.abort();
                this.networkCount++;
            }
        }
    }

    public void onResponseComplete(AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData) {
        FileInputStream[] fileInputStreamArr;
        CacheData cacheData = (CacheData) onResponseCompleteData.state.get("cache-data");
        if (!(cacheData == null || (fileInputStreamArr = cacheData.snapshot) == null)) {
            StreamUtility.closeQuietly(fileInputStreamArr);
        }
        CachedSocket cachedSocket = (CachedSocket) Util.getWrappedSocket(onResponseCompleteData.socket, CachedSocket.class);
        if (cachedSocket != null) {
            StreamUtility.closeQuietly(cachedSocket.cacheResponse.getBody());
        }
        BodyCacher bodyCacher = (BodyCacher) onResponseCompleteData.state.get("body-cacher");
        if (bodyCacher == null) {
            return;
        }
        if (onResponseCompleteData.exception != null) {
            bodyCacher.abort();
        } else {
            bodyCacher.commit();
        }
    }

    public void removeFromCache(Uri uri) {
        getFileCache().remove(FileCache.toKeyString(uri));
    }

    public void setCaching(boolean z) {
        this.caching = z;
    }
}
