package io.lum.sdk.async.http.filter;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.FilteredDataSink;
import java.nio.ByteBuffer;

public class ChunkedOutputFilter extends FilteredDataSink {
    public ChunkedOutputFilter(DataSink dataSink) {
        super(dataSink);
    }

    public void end() {
        setMaxBuffer(Integer.MAX_VALUE);
        write(new ByteBufferList());
        setMaxBuffer(0);
    }

    public ByteBufferList filter(ByteBufferList byteBufferList) {
        byteBufferList.addFirst(ByteBuffer.wrap((Integer.toString(byteBufferList.remaining(), 16) + "\r\n").getBytes()));
        byteBufferList.add(ByteBuffer.wrap("\r\n".getBytes()));
        return byteBufferList;
    }
}
