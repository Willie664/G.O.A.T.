package io.lum.sdk.async.http.spdy;

import b.a.a.a.a;
import io.lum.sdk.Base64;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.http.AsyncHttpGet;
import io.lum.sdk.async.http.AsyncHttpPost;
import io.lum.sdk.async.http.spdy.BitArray;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class HpackDraft08 {
    public static final Map<ByteString, Integer> NAME_TO_FIRST_INDEX = nameToFirstIndex();
    public static final int PREFIX_4_BITS = 15;
    public static final int PREFIX_6_BITS = 63;
    public static final int PREFIX_7_BITS = 127;
    public static final Header[] STATIC_HEADER_TABLE = {new Header(Header.TARGET_AUTHORITY, ""), new Header(Header.TARGET_METHOD, (String) AsyncHttpGet.METHOD), new Header(Header.TARGET_METHOD, (String) AsyncHttpPost.METHOD), new Header(Header.TARGET_PATH, "/"), new Header(Header.TARGET_PATH, "/index.html"), new Header(Header.TARGET_SCHEME, "http"), new Header(Header.TARGET_SCHEME, "https"), new Header(Header.RESPONSE_STATUS, "200"), new Header(Header.RESPONSE_STATUS, "204"), new Header(Header.RESPONSE_STATUS, "206"), new Header(Header.RESPONSE_STATUS, "304"), new Header(Header.RESPONSE_STATUS, "400"), new Header(Header.RESPONSE_STATUS, "404"), new Header(Header.RESPONSE_STATUS, "500"), new Header("accept-charset", ""), new Header("accept-encoding", "gzip, deflate"), new Header("accept-language", ""), new Header("accept-ranges", ""), new Header("accept", ""), new Header("access-control-allow-origin", ""), new Header("age", ""), new Header("allow", ""), new Header("authorization", ""), new Header("cache-control", ""), new Header("content-disposition", ""), new Header("content-encoding", ""), new Header("content-language", ""), new Header("content-length", ""), new Header("content-location", ""), new Header("content-range", ""), new Header("content-type", ""), new Header("cookie", ""), new Header("date", ""), new Header("etag", ""), new Header("expect", ""), new Header("expires", ""), new Header("from", ""), new Header("host", ""), new Header("if-match", ""), new Header("if-modified-since", ""), new Header("if-none-match", ""), new Header("if-range", ""), new Header("if-unmodified-since", ""), new Header("last-modified", ""), new Header("link", ""), new Header("location", ""), new Header("max-forwards", ""), new Header("proxy-authenticate", ""), new Header("proxy-authorization", ""), new Header("range", ""), new Header("referer", ""), new Header("refresh", ""), new Header("retry-after", ""), new Header("server", ""), new Header("set-cookie", ""), new Header("strict-transport-security", ""), new Header("transfer-encoding", ""), new Header("user-agent", ""), new Header("vary", ""), new Header("via", ""), new Header("www-authenticate", "")};

    public static final class Reader {
        public final List<Header> emittedHeaders = new ArrayList();
        public BitArray emittedReferencedHeaders;
        public int headerCount;
        public Header[] headerTable;
        public int headerTableByteCount;
        public int maxHeaderTableByteCount;
        public int maxHeaderTableByteCountSetting;
        public int nextHeaderIndex;
        public BitArray referencedHeaders;
        public final ByteBufferList source = new ByteBufferList();

        public Reader(int i) {
            Header[] headerArr = new Header[8];
            this.headerTable = headerArr;
            this.nextHeaderIndex = headerArr.length - 1;
            this.headerCount = 0;
            this.referencedHeaders = new BitArray.FixedCapacity();
            this.emittedReferencedHeaders = new BitArray.FixedCapacity();
            this.headerTableByteCount = 0;
            this.maxHeaderTableByteCountSetting = i;
            this.maxHeaderTableByteCount = i;
        }

        private void adjustHeaderTableByteCount() {
            int i = this.maxHeaderTableByteCount;
            int i2 = this.headerTableByteCount;
            if (i >= i2) {
                return;
            }
            if (i == 0) {
                clearHeaderTable();
            } else {
                evictToRecoverBytes(i2 - i);
            }
        }

        private void clearHeaderTable() {
            clearReferenceSet();
            Arrays.fill(this.headerTable, (Object) null);
            this.nextHeaderIndex = this.headerTable.length - 1;
            this.headerCount = 0;
            this.headerTableByteCount = 0;
        }

        private void clearReferenceSet() {
            this.referencedHeaders.clear();
            this.emittedReferencedHeaders.clear();
        }

        private int evictToRecoverBytes(int i) {
            int i2 = 0;
            if (i > 0) {
                int length = this.headerTable.length;
                while (true) {
                    length--;
                    if (length < this.nextHeaderIndex || i <= 0) {
                        this.referencedHeaders.shiftLeft(i2);
                        this.emittedReferencedHeaders.shiftLeft(i2);
                        Header[] headerArr = this.headerTable;
                        int i3 = this.nextHeaderIndex;
                        System.arraycopy(headerArr, i3 + 1, headerArr, i3 + 1 + i2, this.headerCount);
                        this.nextHeaderIndex += i2;
                    } else {
                        Header[] headerArr2 = this.headerTable;
                        i -= headerArr2[length].hpackSize;
                        this.headerTableByteCount -= headerArr2[length].hpackSize;
                        this.headerCount--;
                        i2++;
                    }
                }
                this.referencedHeaders.shiftLeft(i2);
                this.emittedReferencedHeaders.shiftLeft(i2);
                Header[] headerArr3 = this.headerTable;
                int i32 = this.nextHeaderIndex;
                System.arraycopy(headerArr3, i32 + 1, headerArr3, i32 + 1 + i2, this.headerCount);
                this.nextHeaderIndex += i2;
            }
            return i2;
        }

        private ByteString getName(int i) {
            return (isStaticHeader(i) ? HpackDraft08.STATIC_HEADER_TABLE[i - this.headerCount] : this.headerTable[headerTableIndex(i)]).name;
        }

        private int headerTableIndex(int i) {
            return this.nextHeaderIndex + 1 + i;
        }

        private void insertIntoHeaderTable(int i, Header header) {
            int i2 = header.hpackSize;
            if (i != -1) {
                i2 -= this.headerTable[headerTableIndex(i)].hpackSize;
            }
            int i3 = this.maxHeaderTableByteCount;
            if (i2 > i3) {
                clearHeaderTable();
                this.emittedHeaders.add(header);
                return;
            }
            int evictToRecoverBytes = evictToRecoverBytes((this.headerTableByteCount + i2) - i3);
            if (i == -1) {
                int i4 = this.headerCount + 1;
                Header[] headerArr = this.headerTable;
                if (i4 > headerArr.length) {
                    int length = headerArr.length * 2;
                    Header[] headerArr2 = new Header[length];
                    System.arraycopy(headerArr, 0, headerArr2, headerArr.length, headerArr.length);
                    if (length == 64) {
                        this.referencedHeaders = ((BitArray.FixedCapacity) this.referencedHeaders).toVariableCapacity();
                        this.emittedReferencedHeaders = ((BitArray.FixedCapacity) this.emittedReferencedHeaders).toVariableCapacity();
                    }
                    this.referencedHeaders.shiftLeft(this.headerTable.length);
                    this.emittedReferencedHeaders.shiftLeft(this.headerTable.length);
                    this.nextHeaderIndex = this.headerTable.length - 1;
                    this.headerTable = headerArr2;
                }
                int i5 = this.nextHeaderIndex;
                this.nextHeaderIndex = i5 - 1;
                this.referencedHeaders.set(i5);
                this.headerTable[i5] = header;
                this.headerCount++;
            } else {
                int headerTableIndex = headerTableIndex(i) + evictToRecoverBytes + i;
                this.referencedHeaders.set(headerTableIndex);
                this.headerTable[headerTableIndex] = header;
            }
            this.headerTableByteCount += i2;
        }

        private boolean isStaticHeader(int i) {
            return i >= this.headerCount;
        }

        private int readByte() {
            return this.source.get() & Base64.EQUALS_SIGN_ENC;
        }

        private void readIndexedHeader(int i) {
            if (isStaticHeader(i)) {
                int i2 = i - this.headerCount;
                if (i2 <= HpackDraft08.STATIC_HEADER_TABLE.length - 1) {
                    Header header = HpackDraft08.STATIC_HEADER_TABLE[i2];
                    if (this.maxHeaderTableByteCount == 0) {
                        this.emittedHeaders.add(header);
                    } else {
                        insertIntoHeaderTable(-1, header);
                    }
                } else {
                    StringBuilder a2 = a.a("Header index too large ");
                    a2.append(i2 + 1);
                    throw new IOException(a2.toString());
                }
            } else {
                int headerTableIndex = headerTableIndex(i);
                if (!this.referencedHeaders.get(headerTableIndex)) {
                    this.emittedHeaders.add(this.headerTable[headerTableIndex]);
                    this.emittedReferencedHeaders.set(headerTableIndex);
                }
                this.referencedHeaders.toggle(headerTableIndex);
            }
        }

        private void readLiteralHeaderWithIncrementalIndexingIndexedName(int i) {
            insertIntoHeaderTable(-1, new Header(getName(i), readByteString()));
        }

        private void readLiteralHeaderWithIncrementalIndexingNewName() {
            insertIntoHeaderTable(-1, new Header(HpackDraft08.checkLowercase(readByteString()), readByteString()));
        }

        private void readLiteralHeaderWithoutIndexingIndexedName(int i) {
            this.emittedHeaders.add(new Header(getName(i), readByteString()));
        }

        private void readLiteralHeaderWithoutIndexingNewName() {
            this.emittedHeaders.add(new Header(HpackDraft08.checkLowercase(readByteString()), readByteString()));
        }

        public void emitReferenceSet() {
            int length = this.headerTable.length;
            while (true) {
                length--;
                if (length == this.nextHeaderIndex) {
                    return;
                }
                if (this.referencedHeaders.get(length) && !this.emittedReferencedHeaders.get(length)) {
                    this.emittedHeaders.add(this.headerTable[length]);
                }
            }
        }

        public List<Header> getAndReset() {
            ArrayList arrayList = new ArrayList(this.emittedHeaders);
            this.emittedHeaders.clear();
            this.emittedReferencedHeaders.clear();
            return arrayList;
        }

        public int maxHeaderTableByteCount() {
            return this.maxHeaderTableByteCount;
        }

        public void maxHeaderTableByteCountSetting(int i) {
            this.maxHeaderTableByteCountSetting = i;
            this.maxHeaderTableByteCount = i;
            adjustHeaderTableByteCount();
        }

        public ByteString readByteString() {
            int readByte = readByte();
            boolean z = (readByte & 128) == 128;
            int readInt = readInt(readByte, 127);
            return z ? ByteString.of(Huffman.get().decode(this.source.getBytes(readInt))) : ByteString.of(this.source.getBytes(readInt));
        }

        public void readHeaders() {
            while (this.source.hasRemaining()) {
                byte b2 = this.source.get() & Base64.EQUALS_SIGN_ENC;
                if (b2 == 128) {
                    throw new IOException("index == 0");
                } else if ((b2 & 128) == 128) {
                    readIndexedHeader(readInt(b2, 127) - 1);
                } else if (b2 == 64) {
                    readLiteralHeaderWithIncrementalIndexingNewName();
                } else if ((b2 & 64) == 64) {
                    readLiteralHeaderWithIncrementalIndexingIndexedName(readInt(b2, 63) - 1);
                } else if ((b2 & 32) == 32) {
                    if ((b2 & 16) != 16) {
                        int readInt = readInt(b2, 15);
                        this.maxHeaderTableByteCount = readInt;
                        if (readInt < 0 || readInt > this.maxHeaderTableByteCountSetting) {
                            StringBuilder a2 = a.a("Invalid header table byte count ");
                            a2.append(this.maxHeaderTableByteCount);
                            throw new IOException(a2.toString());
                        }
                        adjustHeaderTableByteCount();
                    } else if ((b2 & 15) == 0) {
                        clearReferenceSet();
                    } else {
                        throw new IOException(a.b("Invalid header table state change ", (int) b2));
                    }
                } else if (b2 == 16 || b2 == 0) {
                    readLiteralHeaderWithoutIndexingNewName();
                } else {
                    readLiteralHeaderWithoutIndexingIndexedName(readInt(b2, 15) - 1);
                }
            }
        }

        public int readInt(int i, int i2) {
            int i3 = i & i2;
            if (i3 < i2) {
                return i3;
            }
            int i4 = 0;
            while (true) {
                int readByte = readByte();
                if ((readByte & 128) == 0) {
                    return i2 + (readByte << i4);
                }
                i2 += (readByte & 127) << i4;
                i4 += 7;
            }
        }

        public void refill(ByteBufferList byteBufferList) {
            byteBufferList.get(this.source);
        }
    }

    public static final class Writer {
        public void writeByteString(ByteBuffer byteBuffer, ByteString byteString) {
            writeInt(byteBuffer, byteString.size(), 127, 0);
            byteBuffer.put(byteString.toByteArray());
        }

        public ByteBufferList writeHeaders(List<Header> list) {
            ByteBufferList byteBufferList = new ByteBufferList();
            ByteBuffer obtain = ByteBufferList.obtain(8192);
            int size = list.size();
            for (int i = 0; i < size; i++) {
                if (obtain.remaining() < obtain.capacity() / 2) {
                    obtain.flip();
                    byteBufferList.add(obtain);
                    obtain = ByteBufferList.obtain(obtain.capacity() * 2);
                }
                ByteString asciiLowercase = list.get(i).name.toAsciiLowercase();
                Integer num = (Integer) HpackDraft08.NAME_TO_FIRST_INDEX.get(asciiLowercase);
                if (num != null) {
                    writeInt(obtain, num.intValue() + 1, 15, 0);
                } else {
                    obtain.put((byte) 0);
                    writeByteString(obtain, asciiLowercase);
                }
                writeByteString(obtain, list.get(i).value);
            }
            byteBufferList.add(obtain);
            return byteBufferList;
        }

        public void writeInt(ByteBuffer byteBuffer, int i, int i2, int i3) {
            int i4;
            if (i < i2) {
                i4 = i | i3;
            } else {
                byteBuffer.put((byte) (i3 | i2));
                i4 = i - i2;
                while (i4 >= 128) {
                    byteBuffer.put((byte) (128 | (i4 & 127)));
                    i4 >>>= 7;
                }
            }
            byteBuffer.put((byte) i4);
        }
    }

    public static ByteString checkLowercase(ByteString byteString) {
        int size = byteString.size();
        int i = 0;
        while (i < size) {
            byte b2 = byteString.getByte(i);
            if (b2 < 65 || b2 > 90) {
                i++;
            } else {
                StringBuilder a2 = a.a("PROTOCOL_ERROR response malformed: mixed case name: ");
                a2.append(byteString.utf8());
                throw new IOException(a2.toString());
            }
        }
        return byteString;
    }

    public static Map<ByteString, Integer> nameToFirstIndex() {
        LinkedHashMap linkedHashMap = new LinkedHashMap(STATIC_HEADER_TABLE.length);
        int i = 0;
        while (true) {
            Header[] headerArr = STATIC_HEADER_TABLE;
            if (i >= headerArr.length) {
                return Collections.unmodifiableMap(linkedHashMap);
            }
            if (!linkedHashMap.containsKey(headerArr[i].name)) {
                linkedHashMap.put(STATIC_HEADER_TABLE[i].name, Integer.valueOf(i));
            }
            i++;
        }
    }
}
