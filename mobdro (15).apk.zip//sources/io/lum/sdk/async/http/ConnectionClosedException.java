package io.lum.sdk.async.http;

public class ConnectionClosedException extends Exception {
    public ConnectionClosedException(String str) {
        super(str);
    }

    public ConnectionClosedException(String str, Throwable th) {
        super(str, th);
    }
}
