package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import java.io.InputStream;

public class StreamBody implements AsyncHttpRequestBody<InputStream> {
    public static final String CONTENT_TYPE = "application/binary";
    public String contentType = "application/binary";
    public int length;
    public InputStream stream;

    public StreamBody(InputStream inputStream, int i) {
        this.stream = inputStream;
        this.length = i;
    }

    public InputStream get() {
        return this.stream;
    }

    public String getContentType() {
        return this.contentType;
    }

    public int length() {
        return this.length;
    }

    public void parse(DataEmitter dataEmitter, CompletedCallback completedCallback) {
        throw new AssertionError("not implemented");
    }

    public boolean readFullyOnRequest() {
        throw new AssertionError("not implemented");
    }

    public StreamBody setContentType(String str) {
        this.contentType = str;
        return this;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        InputStream inputStream = this.stream;
        int i = this.length;
        Util.pump(inputStream, i < 0 ? 2147483647L : (long) i, dataSink, completedCallback);
    }
}
