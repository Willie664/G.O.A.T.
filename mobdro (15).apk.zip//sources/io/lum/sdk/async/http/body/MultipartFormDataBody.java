package io.lum.sdk.async.http.body;

import android.text.TextUtils;
import b.a.a.a.a;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.LineEmitter;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ContinuationCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.future.Continuation;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.server.BoundaryEmitter;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class MultipartFormDataBody extends BoundaryEmitter implements AsyncHttpRequestBody<Multimap> {
    public static final String CONTENT_TYPE = "multipart/form-data";
    public static final String PRIMARY_TYPE = "multipart/";
    public String contentType = CONTENT_TYPE;
    public Headers formData;
    public ByteBufferList lastData;
    public Part lastPart;
    public LineEmitter liner;
    public MultipartCallback mCallback;
    public ArrayList<Part> mParts;
    public int totalToWrite;
    public int written;

    public interface MultipartCallback {
        void onPart(Part part);
    }

    public MultipartFormDataBody() {
    }

    public MultipartFormDataBody(String str) {
        String string = Multimap.parseSemicolonDelimited(str).getString("boundary");
        if (string == null) {
            report(new Exception("No boundary found for multipart/form-data"));
        } else {
            setBoundary(string);
        }
    }

    public void addFilePart(String str, File file) {
        addPart(new FilePart(str, file));
    }

    public void addPart(Part part) {
        if (this.mParts == null) {
            this.mParts = new ArrayList<>();
        }
        this.mParts.add(part);
    }

    public void addStringPart(String str, String str2) {
        addPart(new StringPart(str, str2));
    }

    public Multimap get() {
        return new Multimap(this.formData.getMultiMap());
    }

    public String getContentType() {
        if (getBoundary() == null) {
            StringBuilder a2 = a.a("----------------------------");
            a2.append(UUID.randomUUID().toString().replace("-", ""));
            setBoundary(a2.toString());
        }
        return this.contentType + "; boundary=" + getBoundary();
    }

    public String getField(String str) {
        Headers headers = this.formData;
        if (headers == null) {
            return null;
        }
        return headers.get(str);
    }

    public MultipartCallback getMultipartCallback() {
        return this.mCallback;
    }

    public List<Part> getParts() {
        if (this.mParts == null) {
            return null;
        }
        return new ArrayList(this.mParts);
    }

    public void handleLast() {
        if (this.lastData != null) {
            if (this.formData == null) {
                this.formData = new Headers();
            }
            String peekString = this.lastData.peekString();
            String name = TextUtils.isEmpty(this.lastPart.getName()) ? "unnamed" : this.lastPart.getName();
            StringPart stringPart = new StringPart(name, peekString);
            stringPart.mHeaders = this.lastPart.mHeaders;
            addPart(stringPart);
            this.formData.add(name, peekString);
            this.lastPart = null;
            this.lastData = null;
        }
    }

    public int length() {
        if (getBoundary() == null) {
            StringBuilder a2 = a.a("----------------------------");
            a2.append(UUID.randomUUID().toString().replace("-", ""));
            setBoundary(a2.toString());
        }
        int i = 0;
        Iterator<Part> it = this.mParts.iterator();
        while (it.hasNext()) {
            Part next = it.next();
            String prefixString = next.getRawHeaders().toPrefixString(getBoundaryStart());
            if (next.length() == -1) {
                return -1;
            }
            i = (int) (next.length() + ((long) prefixString.getBytes().length) + ((long) 2) + ((long) i));
        }
        int length = i + getBoundaryEnd().getBytes().length;
        this.totalToWrite = length;
        return length;
    }

    public void onBoundaryEnd() {
        super.onBoundaryEnd();
        handleLast();
    }

    public void onBoundaryStart() {
        final Headers headers = new Headers();
        LineEmitter lineEmitter = new LineEmitter();
        this.liner = lineEmitter;
        lineEmitter.setLineCallback(new LineEmitter.StringCallback() {
            public void onStringAvailable(String str) {
                if (!"\r".equals(str)) {
                    headers.addLine(str);
                    return;
                }
                MultipartFormDataBody.this.handleLast();
                MultipartFormDataBody multipartFormDataBody = MultipartFormDataBody.this;
                multipartFormDataBody.liner = null;
                multipartFormDataBody.setDataCallback((DataCallback) null);
                Part part = new Part(headers);
                MultipartCallback multipartCallback = MultipartFormDataBody.this.mCallback;
                if (multipartCallback != null) {
                    multipartCallback.onPart(part);
                }
                if (MultipartFormDataBody.this.getDataCallback() == null) {
                    MultipartFormDataBody multipartFormDataBody2 = MultipartFormDataBody.this;
                    multipartFormDataBody2.lastPart = part;
                    multipartFormDataBody2.lastData = new ByteBufferList();
                    MultipartFormDataBody.this.setDataCallback(new DataCallback() {
                        public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                            byteBufferList.get(MultipartFormDataBody.this.lastData);
                        }
                    });
                }
            }
        });
        setDataCallback(this.liner);
    }

    public void parse(DataEmitter dataEmitter, CompletedCallback completedCallback) {
        setDataEmitter(dataEmitter);
        setEndCallback(completedCallback);
    }

    public boolean readFullyOnRequest() {
        return false;
    }

    public void setContentType(String str) {
        this.contentType = str;
    }

    public void setMultipartCallback(MultipartCallback multipartCallback) {
        this.mCallback = multipartCallback;
    }

    public String toString() {
        Iterator<Part> it = getParts().iterator();
        return it.hasNext() ? it.next().toString() : "multipart content is empty";
    }

    public void write(AsyncHttpRequest asyncHttpRequest, final DataSink dataSink, final CompletedCallback completedCallback) {
        if (this.mParts != null) {
            Continuation continuation = new Continuation(new CompletedCallback() {
                public void onCompleted(Exception exc) {
                    completedCallback.onCompleted(exc);
                }
            });
            Iterator<Part> it = this.mParts.iterator();
            while (it.hasNext()) {
                final Part next = it.next();
                continuation.add((ContinuationCallback) new ContinuationCallback() {
                    public void onContinue(Continuation continuation, CompletedCallback completedCallback) {
                        byte[] bytes = next.getRawHeaders().toPrefixString(MultipartFormDataBody.this.getBoundaryStart()).getBytes();
                        Util.writeAll(dataSink, bytes, completedCallback);
                        MultipartFormDataBody.this.written += bytes.length;
                    }
                }).add((ContinuationCallback) new ContinuationCallback() {
                    public void onContinue(Continuation continuation, CompletedCallback completedCallback) {
                        long length = next.length();
                        if (length >= 0) {
                            MultipartFormDataBody multipartFormDataBody = MultipartFormDataBody.this;
                            multipartFormDataBody.written = (int) (((long) multipartFormDataBody.written) + length);
                        }
                        next.write(dataSink, completedCallback);
                    }
                }).add((ContinuationCallback) new ContinuationCallback() {
                    public void onContinue(Continuation continuation, CompletedCallback completedCallback) {
                        byte[] bytes = "\r\n".getBytes();
                        Util.writeAll(dataSink, bytes, completedCallback);
                        MultipartFormDataBody.this.written += bytes.length;
                    }
                });
            }
            continuation.add((ContinuationCallback) new ContinuationCallback() {
                public static final /* synthetic */ boolean $assertionsDisabled = false;

                public void onContinue(Continuation continuation, CompletedCallback completedCallback) {
                    byte[] bytes = MultipartFormDataBody.this.getBoundaryEnd().getBytes();
                    Util.writeAll(dataSink, bytes, completedCallback);
                    MultipartFormDataBody.this.written += bytes.length;
                }
            });
            continuation.start();
        }
    }
}
