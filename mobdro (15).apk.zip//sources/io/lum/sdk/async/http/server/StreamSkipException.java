package io.lum.sdk.async.http.server;

public class StreamSkipException extends Exception {
    public StreamSkipException(String str) {
        super(str);
    }
}
