package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.parser.DocumentParser;
import io.lum.sdk.async.util.Charsets;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;

public class DocumentBody implements AsyncHttpRequestBody<Document> {
    public static final String CONTENT_TYPE = "application/xml";
    public ByteArrayOutputStream bout;
    public Document document;

    public DocumentBody() {
        this((Document) null);
    }

    public DocumentBody(Document document2) {
        this.document = document2;
    }

    private void prepare() {
        if (this.bout == null) {
            try {
                DOMSource dOMSource = new DOMSource(this.document);
                Transformer newTransformer = TransformerFactory.newInstance().newTransformer();
                this.bout = new ByteArrayOutputStream();
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(this.bout, Charsets.UTF_8);
                newTransformer.transform(dOMSource, new StreamResult(outputStreamWriter));
                outputStreamWriter.flush();
            } catch (Exception unused) {
            }
        }
    }

    public Document get() {
        return this.document;
    }

    public String getContentType() {
        return CONTENT_TYPE;
    }

    public int length() {
        prepare();
        return this.bout.size();
    }

    public void parse(DataEmitter dataEmitter, final CompletedCallback completedCallback) {
        new DocumentParser().parse(dataEmitter).setCallback(new FutureCallback<Document>() {
            public void onCompleted(Exception exc, Document document) {
                DocumentBody.this.document = document;
                completedCallback.onCompleted(exc);
            }
        });
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        prepare();
        Util.writeAll(dataSink, this.bout.toByteArray(), completedCallback);
    }
}
