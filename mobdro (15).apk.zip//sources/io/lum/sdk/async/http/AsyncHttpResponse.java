package io.lum.sdk.async.http;

import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.DataEmitter;

public interface AsyncHttpResponse extends DataEmitter {
    int code();

    AsyncSocket detachSocket();

    AsyncHttpRequest getRequest();

    Headers headers();

    String message();

    String protocol();
}
