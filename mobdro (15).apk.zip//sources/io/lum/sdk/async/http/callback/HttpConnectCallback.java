package io.lum.sdk.async.http.callback;

import io.lum.sdk.async.http.AsyncHttpResponse;

public interface HttpConnectCallback {
    void onConnectCompleted(Exception exc, AsyncHttpResponse asyncHttpResponse);
}
