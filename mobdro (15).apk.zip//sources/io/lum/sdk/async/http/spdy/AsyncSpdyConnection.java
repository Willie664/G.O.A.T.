package io.lum.sdk.async.http.spdy;

import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.BufferedDataSink;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.future.SimpleFuture;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.spdy.FrameReader;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class AsyncSpdyConnection implements FrameReader.Handler {
    public static final int OKHTTP_CLIENT_WINDOW_SIZE = 16777216;
    public BufferedDataSink bufferedSocket;
    public long bytesLeftInWriteWindow;
    public boolean client = true;
    public int lastGoodStreamId;
    public int nextPingId;
    public int nextStreamId;
    public final Settings okHttpSettings = new Settings();
    public Settings peerSettings = new Settings();
    public Map<Integer, Ping> pings;
    public Protocol protocol;
    public FrameReader reader;
    public boolean receivedInitialPeerSettings = false;
    public boolean shutdown;
    public AsyncSocket socket;
    public Hashtable<Integer, SpdySocket> sockets = new Hashtable<>();
    public int totalWindowRead;
    public Variant variant;
    public FrameWriter writer;

    public class SpdySocket implements AsyncSocket {
        public long bytesLeftInWriteWindow = ((long) AsyncSpdyConnection.this.peerSettings.getInitialWindowSize(65536));
        public CompletedCallback closedCallback;
        public DataCallback dataCallback;
        public CompletedCallback endCallback;
        public SimpleFuture<List<Header>> headers = new SimpleFuture<>();
        public final int id;
        public boolean isOpen = true;
        public boolean paused;
        public ByteBufferList pending = new ByteBufferList();
        public int totalWindowRead;
        public WritableCallback writable;
        public ByteBufferList writing = new ByteBufferList();

        public SpdySocket(int i, boolean z, boolean z2, List<Header> list) {
            this.id = i;
        }

        public void addBytesToWriteWindow(long j) {
            long j2 = this.bytesLeftInWriteWindow;
            long j3 = j + j2;
            this.bytesLeftInWriteWindow = j3;
            if (j3 > 0 && j2 <= 0) {
                Util.writable(this.writable);
            }
        }

        public String charset() {
            return null;
        }

        public void close() {
            this.isOpen = false;
        }

        public void end() {
            try {
                AsyncSpdyConnection.this.writer.data(true, this.id, this.writing);
            } catch (IOException e2) {
                throw new AssertionError(e2);
            }
        }

        public CompletedCallback getClosedCallback() {
            return this.closedCallback;
        }

        public AsyncSpdyConnection getConnection() {
            return AsyncSpdyConnection.this;
        }

        public DataCallback getDataCallback() {
            return this.dataCallback;
        }

        public CompletedCallback getEndCallback() {
            return this.endCallback;
        }

        public AsyncServer getServer() {
            return AsyncSpdyConnection.this.socket.getServer();
        }

        public WritableCallback getWriteableCallback() {
            return this.writable;
        }

        public SimpleFuture<List<Header>> headers() {
            return this.headers;
        }

        public boolean isChunked() {
            return false;
        }

        public boolean isLocallyInitiated() {
            return AsyncSpdyConnection.this.client == ((this.id & 1) == 1);
        }

        public boolean isOpen() {
            return this.isOpen;
        }

        public boolean isPaused() {
            return this.paused;
        }

        public void pause() {
            this.paused = true;
        }

        public void receiveHeaders(List<Header> list, HeadersMode headersMode) {
            this.headers.setComplete(list);
        }

        public void resume() {
            this.paused = false;
        }

        public void setClosedCallback(CompletedCallback completedCallback) {
            this.closedCallback = completedCallback;
        }

        public void setDataCallback(DataCallback dataCallback2) {
            this.dataCallback = dataCallback2;
        }

        public void setEndCallback(CompletedCallback completedCallback) {
            this.endCallback = completedCallback;
        }

        public void setWriteableCallback(WritableCallback writableCallback) {
            this.writable = writableCallback;
        }

        public void updateWindowRead(int i) {
            int i2 = this.totalWindowRead + i;
            this.totalWindowRead = i2;
            if (i2 >= AsyncSpdyConnection.this.okHttpSettings.getInitialWindowSize(65536) / 2) {
                try {
                    AsyncSpdyConnection.this.writer.windowUpdate(this.id, (long) this.totalWindowRead);
                    this.totalWindowRead = 0;
                } catch (IOException e2) {
                    throw new AssertionError(e2);
                }
            }
            AsyncSpdyConnection.this.updateWindowRead(i);
        }

        public void write(ByteBufferList byteBufferList) {
            int min = Math.min(byteBufferList.remaining(), (int) Math.min(this.bytesLeftInWriteWindow, AsyncSpdyConnection.this.bytesLeftInWriteWindow));
            if (min != 0) {
                if (min < byteBufferList.remaining()) {
                    if (!this.writing.hasRemaining()) {
                        byteBufferList.get(this.writing, min);
                        byteBufferList = this.writing;
                    } else {
                        throw new AssertionError("wtf");
                    }
                }
                try {
                    AsyncSpdyConnection.this.writer.data(false, this.id, byteBufferList);
                    this.bytesLeftInWriteWindow -= (long) min;
                } catch (IOException e2) {
                    throw new AssertionError(e2);
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:9:0x0057  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AsyncSpdyConnection(io.lum.sdk.async.AsyncSocket r4, io.lum.sdk.async.http.Protocol r5) {
        /*
            r3 = this;
            r3.<init>()
            java.util.Hashtable r0 = new java.util.Hashtable
            r0.<init>()
            r3.sockets = r0
            r0 = 1
            r3.client = r0
            io.lum.sdk.async.http.spdy.Settings r1 = new io.lum.sdk.async.http.spdy.Settings
            r1.<init>()
            r3.okHttpSettings = r1
            io.lum.sdk.async.http.spdy.Settings r1 = new io.lum.sdk.async.http.spdy.Settings
            r1.<init>()
            r3.peerSettings = r1
            r1 = 0
            r3.receivedInitialPeerSettings = r1
            r3.protocol = r5
            r3.socket = r4
            io.lum.sdk.async.BufferedDataSink r2 = new io.lum.sdk.async.BufferedDataSink
            r2.<init>(r4)
            r3.bufferedSocket = r2
            io.lum.sdk.async.http.Protocol r2 = io.lum.sdk.async.http.Protocol.SPDY_3
            if (r5 != r2) goto L_0x0035
            io.lum.sdk.async.http.spdy.Spdy3 r2 = new io.lum.sdk.async.http.spdy.Spdy3
            r2.<init>()
        L_0x0032:
            r3.variant = r2
            goto L_0x003f
        L_0x0035:
            io.lum.sdk.async.http.Protocol r2 = io.lum.sdk.async.http.Protocol.HTTP_2
            if (r5 != r2) goto L_0x003f
            io.lum.sdk.async.http.spdy.Http20Draft13 r2 = new io.lum.sdk.async.http.spdy.Http20Draft13
            r2.<init>()
            goto L_0x0032
        L_0x003f:
            io.lum.sdk.async.http.spdy.Variant r2 = r3.variant
            io.lum.sdk.async.http.spdy.FrameReader r4 = r2.newReader(r4, r3, r0)
            r3.reader = r4
            io.lum.sdk.async.http.spdy.Variant r4 = r3.variant
            io.lum.sdk.async.BufferedDataSink r2 = r3.bufferedSocket
            io.lum.sdk.async.http.spdy.FrameWriter r4 = r4.newWriter(r2, r0)
            r3.writer = r4
            r3.nextStreamId = r0
            io.lum.sdk.async.http.Protocol r4 = io.lum.sdk.async.http.Protocol.HTTP_2
            if (r5 != r4) goto L_0x005c
            r4 = 1
            int r4 = r4 + 2
            r3.nextStreamId = r4
        L_0x005c:
            r3.nextPingId = r0
            io.lum.sdk.async.http.spdy.Settings r4 = r3.okHttpSettings
            r5 = 7
            r0 = 16777216(0x1000000, float:2.3509887E-38)
            r4.set(r5, r1, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.spdy.AsyncSpdyConnection.<init>(io.lum.sdk.async.AsyncSocket, io.lum.sdk.async.http.Protocol):void");
    }

    private SpdySocket newStream(int i, List<Header> list, boolean z, boolean z2) {
        boolean z3 = !z;
        boolean z4 = !z2;
        if (this.shutdown) {
            return null;
        }
        int i2 = this.nextStreamId;
        this.nextStreamId = i2 + 2;
        SpdySocket spdySocket = new SpdySocket(i2, z3, z4, list);
        if (spdySocket.isOpen()) {
            this.sockets.put(Integer.valueOf(i2), spdySocket);
        }
        if (i == 0) {
            try {
                this.writer.synStream(z3, z4, i2, i, list);
            } catch (IOException e2) {
                throw new AssertionError(e2);
            }
        } else if (!this.client) {
            this.writer.pushPromise(i, i2, list);
        } else {
            throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");
        }
        return spdySocket;
    }

    private boolean pushedStream(int i) {
        return this.protocol == Protocol.HTTP_2 && i != 0 && (i & 1) == 0;
    }

    private synchronized Ping removePing(int i) {
        return this.pings != null ? this.pings.remove(Integer.valueOf(i)) : null;
    }

    private void writePing(boolean z, int i, int i2, Ping ping) {
        if (ping != null) {
            ping.send();
        }
        this.writer.ping(z, i, i2);
    }

    public void ackSettings() {
        try {
            this.writer.ackSettings();
        } catch (IOException e2) {
            throw new AssertionError(e2);
        }
    }

    public void addBytesToWriteWindow(long j) {
        this.bytesLeftInWriteWindow += j;
        for (SpdySocket writable : this.sockets.values()) {
            Util.writable((DataSink) writable);
        }
    }

    public void alternateService(int i, String str, ByteString byteString, String str2, int i2, long j) {
    }

    public void data(boolean z, int i, ByteBufferList byteBufferList) {
        if (!pushedStream(i)) {
            SpdySocket spdySocket = this.sockets.get(Integer.valueOf(i));
            if (spdySocket == null) {
                try {
                    this.writer.rstStream(i, ErrorCode.INVALID_STREAM);
                    byteBufferList.recycle();
                } catch (IOException e2) {
                    throw new AssertionError(e2);
                }
            } else {
                int remaining = byteBufferList.remaining();
                byteBufferList.get(spdySocket.pending);
                spdySocket.updateWindowRead(remaining);
                Util.emitAllData(spdySocket, spdySocket.pending);
                if (z) {
                    this.sockets.remove(Integer.valueOf(i));
                    spdySocket.close();
                    Util.end((DataEmitter) spdySocket, (Exception) null);
                }
            }
        } else {
            throw new AssertionError("push");
        }
    }

    public void error(Exception exc) {
        this.socket.close();
        Iterator<Map.Entry<Integer, SpdySocket>> it = this.sockets.entrySet().iterator();
        while (it.hasNext()) {
            Util.end((DataEmitter) it.next().getValue(), exc);
            it.remove();
        }
    }

    public void goAway(int i, ErrorCode errorCode, ByteString byteString) {
        this.shutdown = true;
        Iterator<Map.Entry<Integer, SpdySocket>> it = this.sockets.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry next = it.next();
            if (((Integer) next.getKey()).intValue() > i && ((SpdySocket) next.getValue()).isLocallyInitiated()) {
                ErrorCode errorCode2 = ErrorCode.REFUSED_STREAM;
                Util.end((DataEmitter) next.getValue(), (Exception) new IOException("REFUSED_STREAM"));
                it.remove();
            }
        }
    }

    public void headers(boolean z, boolean z2, int i, int i2, List<Header> list, HeadersMode headersMode) {
        if (pushedStream(i)) {
            throw new AssertionError("push");
        } else if (!this.shutdown) {
            SpdySocket spdySocket = this.sockets.get(Integer.valueOf(i));
            if (spdySocket == null) {
                if (headersMode.failIfStreamAbsent()) {
                    try {
                        this.writer.rstStream(i, ErrorCode.INVALID_STREAM);
                    } catch (IOException e2) {
                        throw new AssertionError(e2);
                    }
                } else if (i > this.lastGoodStreamId && i % 2 != this.nextStreamId % 2) {
                    throw new AssertionError("unexpected receive stream");
                }
            } else if (headersMode.failIfStreamPresent()) {
                try {
                    this.writer.rstStream(i, ErrorCode.INVALID_STREAM);
                    this.sockets.remove(Integer.valueOf(i));
                } catch (IOException e3) {
                    throw new AssertionError(e3);
                }
            } else {
                spdySocket.receiveHeaders(list, headersMode);
                if (z2) {
                    this.sockets.remove(Integer.valueOf(i));
                    Util.end((DataEmitter) spdySocket, (Exception) null);
                }
            }
        }
    }

    public SpdySocket newStream(List<Header> list, boolean z, boolean z2) {
        return newStream(0, list, z, z2);
    }

    public void ping(boolean z, int i, int i2) {
        if (z) {
            Ping removePing = removePing(i);
            if (removePing != null) {
                removePing.receive();
                return;
            }
            return;
        }
        try {
            writePing(true, i, i2, (Ping) null);
        } catch (IOException e2) {
            throw new AssertionError(e2);
        }
    }

    public void priority(int i, int i2, int i3, boolean z) {
    }

    public void pushPromise(int i, int i2, List<Header> list) {
        throw new AssertionError("pushPromise");
    }

    public void rstStream(int i, ErrorCode errorCode) {
        if (!pushedStream(i)) {
            SpdySocket remove = this.sockets.remove(Integer.valueOf(i));
            if (remove != null) {
                Util.end((DataEmitter) remove, (Exception) new IOException(errorCode.toString()));
                return;
            }
            return;
        }
        throw new AssertionError("push");
    }

    public void sendConnectionPreface() {
        this.writer.connectionPreface();
        this.writer.settings(this.okHttpSettings);
        int initialWindowSize = this.okHttpSettings.getInitialWindowSize(65536);
        if (initialWindowSize != 65536) {
            this.writer.windowUpdate(0, (long) (initialWindowSize - 65536));
        }
    }

    public void settings(boolean z, Settings settings) {
        long j;
        int initialWindowSize = this.peerSettings.getInitialWindowSize(65536);
        if (z) {
            this.peerSettings.clear();
        }
        this.peerSettings.merge(settings);
        try {
            this.writer.ackSettings();
            int initialWindowSize2 = this.peerSettings.getInitialWindowSize(65536);
            if (initialWindowSize2 == -1 || initialWindowSize2 == initialWindowSize) {
                j = 0;
            } else {
                j = (long) (initialWindowSize2 - initialWindowSize);
                if (!this.receivedInitialPeerSettings) {
                    addBytesToWriteWindow(j);
                    this.receivedInitialPeerSettings = true;
                }
            }
            for (SpdySocket addBytesToWriteWindow : this.sockets.values()) {
                addBytesToWriteWindow.addBytesToWriteWindow(j);
            }
        } catch (IOException e2) {
            throw new AssertionError(e2);
        }
    }

    public void updateWindowRead(int i) {
        int i2 = this.totalWindowRead + i;
        this.totalWindowRead = i2;
        if (i2 >= this.okHttpSettings.getInitialWindowSize(65536) / 2) {
            try {
                this.writer.windowUpdate(0, (long) this.totalWindowRead);
                this.totalWindowRead = 0;
            } catch (IOException e2) {
                throw new AssertionError(e2);
            }
        }
    }

    public void windowUpdate(int i, long j) {
        if (i == 0) {
            addBytesToWriteWindow(j);
            return;
        }
        SpdySocket spdySocket = this.sockets.get(Integer.valueOf(i));
        if (spdySocket != null) {
            spdySocket.addBytesToWriteWindow(j);
        }
    }
}
