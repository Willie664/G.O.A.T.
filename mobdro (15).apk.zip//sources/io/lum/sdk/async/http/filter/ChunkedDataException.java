package io.lum.sdk.async.http.filter;

public class ChunkedDataException extends Exception {
    public ChunkedDataException(String str) {
        super(str);
    }
}
