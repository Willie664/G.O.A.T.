package io.lum.sdk.async.http.filter;

import io.lum.sdk.Base64;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.PushParser;
import io.lum.sdk.async.callback.DataCallback;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

public class GZIPInputFilter extends InflaterInputFilter {
    public static final int FCOMMENT = 16;
    public static final int FEXTRA = 4;
    public static final int FHCRC = 2;
    public static final int FNAME = 8;
    public CRC32 crc = new CRC32();
    public boolean mNeedsHeader = true;

    public GZIPInputFilter() {
        super(new Inflater(true));
    }

    public static short peekShort(byte[] bArr, int i, ByteOrder byteOrder) {
        int i2;
        byte b2;
        if (byteOrder == ByteOrder.BIG_ENDIAN) {
            i2 = bArr[i] << 8;
            b2 = bArr[i + 1];
        } else {
            i2 = bArr[i + 1] << 8;
            b2 = bArr[i];
        }
        return (short) ((b2 & Base64.EQUALS_SIGN_ENC) | i2);
    }

    public static int unsignedToBytes(byte b2) {
        return b2 & Base64.EQUALS_SIGN_ENC;
    }

    public void onDataAvailable(final DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        if (this.mNeedsHeader) {
            final PushParser pushParser = new PushParser(dataEmitter);
            pushParser.readByteArray(10, new PushParser.ParseCallback<byte[]>() {
                public int flags;
                public boolean hcrc;

                /* access modifiers changed from: private */
                public void done() {
                    if (this.hcrc) {
                        pushParser.readByteArray(2, new PushParser.ParseCallback<byte[]>() {
                            public void parsed(byte[] bArr) {
                                if (((short) ((int) GZIPInputFilter.this.crc.getValue())) != GZIPInputFilter.peekShort(bArr, 0, ByteOrder.LITTLE_ENDIAN)) {
                                    GZIPInputFilter.this.report(new IOException("CRC mismatch"));
                                    return;
                                }
                                GZIPInputFilter.this.crc.reset();
                                AnonymousClass1 r5 = AnonymousClass1.this;
                                GZIPInputFilter gZIPInputFilter = GZIPInputFilter.this;
                                gZIPInputFilter.mNeedsHeader = false;
                                gZIPInputFilter.setDataEmitter(dataEmitter);
                            }
                        });
                        return;
                    }
                    GZIPInputFilter gZIPInputFilter = GZIPInputFilter.this;
                    gZIPInputFilter.mNeedsHeader = false;
                    gZIPInputFilter.setDataEmitter(dataEmitter);
                }

                /* access modifiers changed from: private */
                public void next() {
                    PushParser pushParser = new PushParser(dataEmitter);
                    AnonymousClass2 r1 = new DataCallback() {
                        public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                            if (AnonymousClass1.this.hcrc) {
                                while (byteBufferList.size() > 0) {
                                    ByteBuffer remove = byteBufferList.remove();
                                    GZIPInputFilter.this.crc.update(remove.array(), remove.position() + remove.arrayOffset(), remove.remaining());
                                    ByteBufferList.reclaim(remove);
                                }
                            }
                            byteBufferList.recycle();
                            AnonymousClass1.this.done();
                        }
                    };
                    int i = this.flags;
                    if ((i & 8) != 0) {
                        pushParser.until((byte) 0, r1);
                    } else if ((i & 16) != 0) {
                        pushParser.until((byte) 0, r1);
                    } else {
                        done();
                    }
                }

                public void parsed(byte[] bArr) {
                    short peekShort = GZIPInputFilter.peekShort(bArr, 0, ByteOrder.LITTLE_ENDIAN);
                    boolean z = true;
                    if (peekShort != -29921) {
                        GZIPInputFilter.this.report(new IOException(String.format(Locale.ENGLISH, "unknown format (magic number %x)", new Object[]{Short.valueOf(peekShort)})));
                        dataEmitter.setDataCallback(new DataCallback.NullDataCallback());
                        return;
                    }
                    byte b2 = bArr[3];
                    this.flags = b2;
                    if ((b2 & 2) == 0) {
                        z = false;
                    }
                    this.hcrc = z;
                    if (z) {
                        GZIPInputFilter.this.crc.update(bArr, 0, bArr.length);
                    }
                    if ((this.flags & 4) != 0) {
                        pushParser.readByteArray(2, new PushParser.ParseCallback<byte[]>() {
                            public void parsed(byte[] bArr) {
                                AnonymousClass1 r0 = AnonymousClass1.this;
                                if (r0.hcrc) {
                                    GZIPInputFilter.this.crc.update(bArr, 0, 2);
                                }
                                pushParser.readByteArray(GZIPInputFilter.peekShort(bArr, 0, ByteOrder.LITTLE_ENDIAN) & 65535, new PushParser.ParseCallback<byte[]>() {
                                    public void parsed(byte[] bArr) {
                                        AnonymousClass1 r0 = AnonymousClass1.this;
                                        if (r0.hcrc) {
                                            GZIPInputFilter.this.crc.update(bArr, 0, bArr.length);
                                        }
                                        AnonymousClass1.this.next();
                                    }
                                });
                            }
                        });
                    } else {
                        next();
                    }
                }
            });
            return;
        }
        super.onDataAvailable(dataEmitter, byteBufferList);
    }
}
