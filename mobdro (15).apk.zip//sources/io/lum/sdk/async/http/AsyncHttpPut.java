package io.lum.sdk.async.http;

import android.net.Uri;

public class AsyncHttpPut extends AsyncHttpRequest {
    public static final String METHOD = "PUT";

    public AsyncHttpPut(Uri uri) {
        super(uri, METHOD);
    }

    public AsyncHttpPut(String str) {
        this(Uri.parse(str));
    }
}
