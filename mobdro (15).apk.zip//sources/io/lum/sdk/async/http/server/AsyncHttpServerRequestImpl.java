package io.lum.sdk.async.http.server;

import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.LineEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.HttpUtil;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import java.io.IOException;
import java.util.HashMap;

public abstract class AsyncHttpServerRequestImpl extends FilteredDataEmitter implements CompletedCallback, AsyncHttpServerRequest {
    public AsyncHttpRequestBody mBody;
    public LineEmitter.StringCallback mHeaderCallback = new LineEmitter.StringCallback() {
        public void onStringAvailable(String str) {
            if (AsyncHttpServerRequestImpl.this.statusLine == null) {
                String unused = AsyncHttpServerRequestImpl.this.statusLine = str;
                if (!AsyncHttpServerRequestImpl.this.statusLine.contains("HTTP/")) {
                    AsyncHttpServerRequestImpl.this.onNotHttp();
                    AsyncHttpServerRequestImpl.this.mSocket.setDataCallback(new DataCallback.NullDataCallback());
                    AsyncHttpServerRequestImpl.this.report(new IOException("data/header received was not not http"));
                }
            } else if (!"\r".equals(str)) {
                AsyncHttpServerRequestImpl.this.mRawHeaders.addLine(str);
            } else {
                AsyncHttpServerRequestImpl asyncHttpServerRequestImpl = AsyncHttpServerRequestImpl.this;
                DataEmitter bodyDecoder = HttpUtil.getBodyDecoder(asyncHttpServerRequestImpl.mSocket, Protocol.HTTP_1_1, asyncHttpServerRequestImpl.mRawHeaders, true);
                AsyncHttpServerRequestImpl asyncHttpServerRequestImpl2 = AsyncHttpServerRequestImpl.this;
                asyncHttpServerRequestImpl2.mBody = asyncHttpServerRequestImpl2.onBody(asyncHttpServerRequestImpl2.mRawHeaders);
                AsyncHttpServerRequestImpl asyncHttpServerRequestImpl3 = AsyncHttpServerRequestImpl.this;
                if (asyncHttpServerRequestImpl3.mBody == null) {
                    asyncHttpServerRequestImpl3.mBody = HttpUtil.getBody(bodyDecoder, asyncHttpServerRequestImpl3.mReporter, AsyncHttpServerRequestImpl.this.mRawHeaders);
                    AsyncHttpServerRequestImpl asyncHttpServerRequestImpl4 = AsyncHttpServerRequestImpl.this;
                    if (asyncHttpServerRequestImpl4.mBody == null) {
                        asyncHttpServerRequestImpl4.mBody = asyncHttpServerRequestImpl4.onUnknownBody(asyncHttpServerRequestImpl4.mRawHeaders);
                        AsyncHttpServerRequestImpl asyncHttpServerRequestImpl5 = AsyncHttpServerRequestImpl.this;
                        if (asyncHttpServerRequestImpl5.mBody == null) {
                            asyncHttpServerRequestImpl5.mBody = new UnknownRequestBody(asyncHttpServerRequestImpl5.mRawHeaders.get("Content-Type"));
                        }
                    }
                }
                AsyncHttpServerRequestImpl asyncHttpServerRequestImpl6 = AsyncHttpServerRequestImpl.this;
                asyncHttpServerRequestImpl6.mBody.parse(bodyDecoder, asyncHttpServerRequestImpl6.mReporter);
                AsyncHttpServerRequestImpl.this.onHeadersReceived();
            }
        }
    };
    public Headers mRawHeaders = new Headers();
    public CompletedCallback mReporter = new CompletedCallback() {
        public void onCompleted(Exception exc) {
            AsyncHttpServerRequestImpl.this.onCompleted(exc);
        }
    };
    public AsyncSocket mSocket;
    public String method;
    public HashMap<String, Object> state = new HashMap<>();
    public String statusLine;

    public String get(String str) {
        String string = getQuery().getString(str);
        if (string != null) {
            return string;
        }
        Object obj = getBody().get();
        if (obj instanceof Multimap) {
            return ((Multimap) obj).getString(str);
        }
        return null;
    }

    public AsyncHttpRequestBody getBody() {
        return this.mBody;
    }

    public DataCallback getDataCallback() {
        return this.mSocket.getDataCallback();
    }

    public Headers getHeaders() {
        return this.mRawHeaders;
    }

    public String getMethod() {
        return this.method;
    }

    public AsyncSocket getSocket() {
        return this.mSocket;
    }

    public HashMap<String, Object> getState() {
        return this.state;
    }

    public String getStatusLine() {
        return this.statusLine;
    }

    public boolean isChunked() {
        return this.mSocket.isChunked();
    }

    public boolean isPaused() {
        return this.mSocket.isPaused();
    }

    public AsyncHttpRequestBody onBody(Headers headers) {
        return null;
    }

    public void onCompleted(Exception exc) {
        report(exc);
    }

    public abstract void onHeadersReceived();

    public void onNotHttp() {
        System.out.println("not http!");
    }

    public AsyncHttpRequestBody onUnknownBody(Headers headers) {
        return null;
    }

    public void pause() {
        this.mSocket.pause();
    }

    public void resume() {
        this.mSocket.resume();
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.mSocket.setDataCallback(dataCallback);
    }

    public void setSocket(AsyncSocket asyncSocket) {
        this.mSocket = asyncSocket;
        LineEmitter lineEmitter = new LineEmitter();
        this.mSocket.setDataCallback(lineEmitter);
        lineEmitter.setLineCallback(this.mHeaderCallback);
        this.mSocket.setEndCallback(new CompletedCallback.NullCompletedCallback());
    }

    public String toString() {
        Headers headers = this.mRawHeaders;
        return headers == null ? super.toString() : headers.toPrefixString(this.statusLine);
    }
}
