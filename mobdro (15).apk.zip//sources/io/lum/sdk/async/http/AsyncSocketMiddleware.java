package io.lum.sdk.async.http;

import android.net.Uri;
import b.a.a.a.a;
import d.a.a.b2.v.j;
import d.a.a.b2.v.p;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.Futures;
import io.lum.sdk.async.future.SimpleCancellable;
import io.lum.sdk.async.future.SimpleFuture;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.util.ArrayDeque;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Hashtable;
import java.util.Locale;

public class AsyncSocketMiddleware extends SimpleMiddleware {
    public boolean connectAllAddresses;
    public Hashtable<String, ConnectionInfo> connectionInfo;
    public int idleTimeoutMs;
    public AsyncHttpClient mClient;
    public int maxConnectionCount;
    public int port;
    public InetSocketAddress proxyAddress;
    public String proxyHost;
    public int proxyPort;
    public String scheme;

    public static class ConnectionInfo {
        public int openCount;
        public ArrayDeque<AsyncHttpClientMiddleware.GetSocketData> queue = new ArrayDeque<>();
        public ArrayDeque<IdleSocketHolder> sockets = new ArrayDeque<>();
    }

    public class IdleSocketHolder {
        public long idleTime = System.currentTimeMillis();
        public AsyncSocket socket;

        public IdleSocketHolder(AsyncSocket asyncSocket) {
            this.socket = asyncSocket;
        }
    }

    public AsyncSocketMiddleware(AsyncHttpClient asyncHttpClient) {
        this(asyncHttpClient, "http", 80);
    }

    public AsyncSocketMiddleware(AsyncHttpClient asyncHttpClient, String str, int i) {
        this.idleTimeoutMs = 300000;
        this.connectionInfo = new Hashtable<>();
        this.maxConnectionCount = Integer.MAX_VALUE;
        this.mClient = asyncHttpClient;
        this.scheme = str;
        this.port = i;
    }

    private ConnectionInfo getOrCreateConnectionInfo(String str) {
        ConnectionInfo connectionInfo2 = this.connectionInfo.get(str);
        if (connectionInfo2 != null) {
            return connectionInfo2;
        }
        ConnectionInfo connectionInfo3 = new ConnectionInfo();
        this.connectionInfo.put(str, connectionInfo3);
        return connectionInfo3;
    }

    private void idleSocket(final AsyncSocket asyncSocket) {
        asyncSocket.setEndCallback(new CompletedCallback() {
            public void onCompleted(Exception exc) {
                asyncSocket.setClosedCallback((CompletedCallback) null);
                asyncSocket.close();
            }
        });
        asyncSocket.setWriteableCallback((WritableCallback) null);
        asyncSocket.setDataCallback(new DataCallback.NullDataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                super.onDataAvailable(dataEmitter, byteBufferList);
                byteBufferList.recycle();
                asyncSocket.setClosedCallback((CompletedCallback) null);
                asyncSocket.close();
            }
        });
    }

    /* access modifiers changed from: private */
    public void maybeCleanupConnectionInfo(String str) {
        ConnectionInfo connectionInfo2 = this.connectionInfo.get(str);
        if (connectionInfo2 != null) {
            while (!connectionInfo2.sockets.isEmpty()) {
                IdleSocketHolder peekLast = connectionInfo2.sockets.peekLast();
                AsyncSocket asyncSocket = peekLast.socket;
                if (peekLast.idleTime + ((long) this.idleTimeoutMs) > System.currentTimeMillis()) {
                    break;
                }
                connectionInfo2.sockets.pop();
                asyncSocket.setClosedCallback((CompletedCallback) null);
                asyncSocket.close();
            }
            if (connectionInfo2.openCount == 0 && connectionInfo2.queue.isEmpty() && connectionInfo2.sockets.isEmpty()) {
                this.connectionInfo.remove(str);
            }
        }
    }

    private void nextConnection(AsyncHttpRequest asyncHttpRequest) {
        Uri uri = asyncHttpRequest.getUri();
        String computeLookup = computeLookup(uri, getSchemePort(uri), asyncHttpRequest.getProxyHost(), asyncHttpRequest.getProxyPort());
        synchronized (this) {
            ConnectionInfo connectionInfo2 = this.connectionInfo.get(computeLookup);
            if (connectionInfo2 != null) {
                connectionInfo2.openCount--;
                while (connectionInfo2.openCount < this.maxConnectionCount && connectionInfo2.queue.size() > 0) {
                    AsyncHttpClientMiddleware.GetSocketData remove = connectionInfo2.queue.remove();
                    SimpleCancellable simpleCancellable = (SimpleCancellable) remove.socketCancellable;
                    if (!simpleCancellable.isCancelled()) {
                        simpleCancellable.setParent(getSocket(remove));
                    }
                }
                maybeCleanupConnectionInfo(computeLookup);
            }
        }
    }

    private void recycleSocket(AsyncSocket asyncSocket, AsyncHttpRequest asyncHttpRequest) {
        final ArrayDeque<IdleSocketHolder> arrayDeque;
        if (asyncSocket != null) {
            Uri uri = asyncHttpRequest.getUri();
            final String computeLookup = computeLookup(uri, getSchemePort(uri), asyncHttpRequest.getProxyHost(), asyncHttpRequest.getProxyPort());
            final IdleSocketHolder idleSocketHolder = new IdleSocketHolder(asyncSocket);
            synchronized (this) {
                arrayDeque = getOrCreateConnectionInfo(computeLookup).sockets;
                arrayDeque.push(idleSocketHolder);
            }
            asyncSocket.setClosedCallback(new CompletedCallback() {
                public void onCompleted(Exception exc) {
                    synchronized (AsyncSocketMiddleware.this) {
                        arrayDeque.remove(idleSocketHolder);
                        AsyncSocketMiddleware.this.maybeCleanupConnectionInfo(computeLookup);
                    }
                }
            });
        }
    }

    public /* synthetic */ Future a(int i, AsyncHttpClientMiddleware.GetSocketData getSocketData, InetAddress inetAddress) {
        SimpleFuture simpleFuture = new SimpleFuture();
        String format = String.format(Locale.ENGLISH, "%s:%s", new Object[]{inetAddress, Integer.valueOf(i)});
        AsyncHttpRequest asyncHttpRequest = getSocketData.request;
        asyncHttpRequest.logv("attempting connection to " + format);
        AsyncServer server = this.mClient.getServer();
        InetSocketAddress inetSocketAddress = new InetSocketAddress(inetAddress, i);
        simpleFuture.getClass();
        server.connectSocket(inetSocketAddress, new p(simpleFuture));
        return simpleFuture;
    }

    public /* synthetic */ Future a(int i, AsyncHttpClientMiddleware.GetSocketData getSocketData, InetAddress[] inetAddressArr) {
        return Futures.loopUntil((F[]) inetAddressArr, new j(this, i, getSocketData));
    }

    public /* synthetic */ void a(AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, Exception exc) {
        wrapCallback(getSocketData, uri, i, false, getSocketData.connectCallback).onConnectCompleted(exc, (AsyncSocket) null);
    }

    public /* synthetic */ void a(AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, Exception exc, AsyncSocket asyncSocket) {
        if (asyncSocket != null) {
            if (exc == null) {
                wrapCallback(getSocketData, uri, i, false, getSocketData.connectCallback).onConnectCompleted((Exception) null, asyncSocket);
                return;
            }
            getSocketData.request.logd("Recycling extra socket leftover from cancelled operation");
            idleSocket(asyncSocket);
            recycleSocket(asyncSocket, getSocketData.request);
        }
    }

    public String computeLookup(Uri uri, int i, String str, int i2) {
        String str2;
        if (str != null) {
            str2 = str + ":" + i2;
        } else {
            str2 = "";
        }
        if (str != null) {
            str2 = str + ":" + i2;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(uri.getScheme());
        sb.append("//");
        sb.append(uri.getHost());
        sb.append(":");
        sb.append(i);
        return a.a(sb, "?proxy=", str2);
    }

    public void disableProxy() {
        this.proxyPort = -1;
        this.proxyHost = null;
        this.proxyAddress = null;
    }

    public void enableProxy(String str, int i) {
        this.proxyHost = str;
        this.proxyPort = i;
        this.proxyAddress = null;
    }

    public boolean getConnectAllAddresses() {
        return this.connectAllAddresses;
    }

    public int getMaxConnectionCount() {
        return this.maxConnectionCount;
    }

    public int getSchemePort(Uri uri) {
        if (uri.getScheme() == null || !uri.getScheme().equals(this.scheme)) {
            return -1;
        }
        return uri.getPort() == -1 ? this.port : uri.getPort();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009a, code lost:
        if (r11.connectAllAddresses == false) goto L_0x00e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009e, code lost:
        if (r11.proxyHost != null) goto L_0x00e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x00a6, code lost:
        if (r12.request.getProxyHost() == null) goto L_0x00a9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00a9, code lost:
        r12.request.logv("Resolving domain and connecting to all available addresses");
        r0 = new io.lum.sdk.async.future.SimpleFuture();
        r0.setComplete(r11.mClient.getServer().getAllByName(r3.getHost()).then(new d.a.a.b2.v.h(r11, r4, r12)).fail(new d.a.a.b2.v.i(r11, r12, r3, r4))).setCallback(new d.a.a.b2.v.g(r11, r12, r3, r4));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00e1, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00e2, code lost:
        r12.request.logd("Connecting socket");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00f0, code lost:
        if (r12.request.getProxyHost() != null) goto L_0x00fd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00f2, code lost:
        r1 = r11.proxyHost;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00f4, code lost:
        if (r1 == null) goto L_0x00fd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00f6, code lost:
        r12.request.enableProxy(r1, r11.proxyPort);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0103, code lost:
        if (r12.request.getProxyHost() == null) goto L_0x0113;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0105, code lost:
        r0 = r12.request.getProxyHost();
        r7 = r12.request.getProxyPort();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x0113, code lost:
        r0 = r12.request.getUri().getHost();
        r7 = r4;
        r5 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x0120, code lost:
        if (r5 == false) goto L_0x0140;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0122, code lost:
        r12.request.logv("Using proxy: " + r0 + ":" + r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0140, code lost:
        r1 = r12.request.get_local_address();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0146, code lost:
        if (r1 == null) goto L_0x015f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0148, code lost:
        r8 = r11.mClient.getServer().set_local_address(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x015e, code lost:
        return r8.connectSocket(r0, r7, wrapCallback(r12, r3, r4, r5, r12.connectCallback));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x015f, code lost:
        r8 = r11.mClient.getServer();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public io.lum.sdk.async.future.Cancellable getSocket(io.lum.sdk.async.http.AsyncHttpClientMiddleware.GetSocketData r12) {
        /*
            r11 = this;
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            android.net.Uri r0 = r0.get_domain_uri()
            if (r0 == 0) goto L_0x0009
            goto L_0x000f
        L_0x0009:
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            android.net.Uri r0 = r0.getUri()
        L_0x000f:
            r3 = r0
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            android.net.Uri r0 = r0.getUri()
            int r4 = r11.getSchemePort(r0)
            r0 = -1
            r1 = 0
            if (r4 != r0) goto L_0x001f
            return r1
        L_0x001f:
            io.lum.sdk.async.util.UntypedHashtable r0 = r12.state
            java.lang.String r2 = "socket-owner"
            r0.put(r2, r11)
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            java.lang.String r0 = r0.getProxyHost()
            io.lum.sdk.async.http.AsyncHttpRequest r2 = r12.request
            int r2 = r2.getProxyPort()
            java.lang.String r0 = r11.computeLookup(r3, r4, r0, r2)
            io.lum.sdk.async.http.AsyncSocketMiddleware$ConnectionInfo r0 = r11.getOrCreateConnectionInfo(r0)
            monitor-enter(r11)
            int r2 = r0.openCount     // Catch:{ all -> 0x0166 }
            int r5 = r11.maxConnectionCount     // Catch:{ all -> 0x0166 }
            if (r2 < r5) goto L_0x004d
            io.lum.sdk.async.future.SimpleCancellable r1 = new io.lum.sdk.async.future.SimpleCancellable     // Catch:{ all -> 0x0166 }
            r1.<init>()     // Catch:{ all -> 0x0166 }
            io.lum.sdk.async.util.ArrayDeque<io.lum.sdk.async.http.AsyncHttpClientMiddleware$GetSocketData> r0 = r0.queue     // Catch:{ all -> 0x0166 }
            r0.add(r12)     // Catch:{ all -> 0x0166 }
            monitor-exit(r11)     // Catch:{ all -> 0x0166 }
            return r1
        L_0x004d:
            int r2 = r0.openCount     // Catch:{ all -> 0x0166 }
            r5 = 1
            int r2 = r2 + r5
            r0.openCount = r2     // Catch:{ all -> 0x0166 }
        L_0x0053:
            io.lum.sdk.async.util.ArrayDeque<io.lum.sdk.async.http.AsyncSocketMiddleware$IdleSocketHolder> r2 = r0.sockets     // Catch:{ all -> 0x0166 }
            boolean r2 = r2.isEmpty()     // Catch:{ all -> 0x0166 }
            if (r2 != 0) goto L_0x0097
            io.lum.sdk.async.util.ArrayDeque<io.lum.sdk.async.http.AsyncSocketMiddleware$IdleSocketHolder> r2 = r0.sockets     // Catch:{ all -> 0x0166 }
            java.lang.Object r2 = r2.pop()     // Catch:{ all -> 0x0166 }
            io.lum.sdk.async.http.AsyncSocketMiddleware$IdleSocketHolder r2 = (io.lum.sdk.async.http.AsyncSocketMiddleware.IdleSocketHolder) r2     // Catch:{ all -> 0x0166 }
            io.lum.sdk.async.AsyncSocket r6 = r2.socket     // Catch:{ all -> 0x0166 }
            long r7 = r2.idleTime     // Catch:{ all -> 0x0166 }
            int r2 = r11.idleTimeoutMs     // Catch:{ all -> 0x0166 }
            long r9 = (long) r2     // Catch:{ all -> 0x0166 }
            long r7 = r7 + r9
            long r9 = java.lang.System.currentTimeMillis()     // Catch:{ all -> 0x0166 }
            int r2 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r2 >= 0) goto L_0x007a
            r6.setClosedCallback(r1)     // Catch:{ all -> 0x0166 }
            r6.close()     // Catch:{ all -> 0x0166 }
            goto L_0x0053
        L_0x007a:
            boolean r2 = r6.isOpen()     // Catch:{ all -> 0x0166 }
            if (r2 != 0) goto L_0x0081
            goto L_0x0053
        L_0x0081:
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request     // Catch:{ all -> 0x0166 }
            java.lang.String r2 = "Reusing keep-alive socket"
            r0.logd(r2)     // Catch:{ all -> 0x0166 }
            io.lum.sdk.async.callback.ConnectCallback r12 = r12.connectCallback     // Catch:{ all -> 0x0166 }
            r12.onConnectCompleted(r1, r6)     // Catch:{ all -> 0x0166 }
            io.lum.sdk.async.future.SimpleCancellable r12 = new io.lum.sdk.async.future.SimpleCancellable     // Catch:{ all -> 0x0166 }
            r12.<init>()     // Catch:{ all -> 0x0166 }
            r12.setComplete()     // Catch:{ all -> 0x0166 }
            monitor-exit(r11)     // Catch:{ all -> 0x0166 }
            return r12
        L_0x0097:
            monitor-exit(r11)     // Catch:{ all -> 0x0166 }
            boolean r0 = r11.connectAllAddresses
            if (r0 == 0) goto L_0x00e2
            java.lang.String r0 = r11.proxyHost
            if (r0 != 0) goto L_0x00e2
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            java.lang.String r0 = r0.getProxyHost()
            if (r0 == 0) goto L_0x00a9
            goto L_0x00e2
        L_0x00a9:
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            java.lang.String r1 = "Resolving domain and connecting to all available addresses"
            r0.logv(r1)
            io.lum.sdk.async.future.SimpleFuture r0 = new io.lum.sdk.async.future.SimpleFuture
            r0.<init>()
            io.lum.sdk.async.http.AsyncHttpClient r1 = r11.mClient
            io.lum.sdk.async.AsyncServer r1 = r1.getServer()
            java.lang.String r2 = r3.getHost()
            io.lum.sdk.async.future.Future r1 = r1.getAllByName(r2)
            d.a.a.b2.v.h r2 = new d.a.a.b2.v.h
            r2.<init>(r11, r4, r12)
            io.lum.sdk.async.future.Future r1 = r1.then(r2)
            d.a.a.b2.v.i r2 = new d.a.a.b2.v.i
            r2.<init>(r11, r12, r3, r4)
            io.lum.sdk.async.future.Future r1 = r1.fail(r2)
            io.lum.sdk.async.future.Future r1 = r0.setComplete(r1)
            d.a.a.b2.v.g r2 = new d.a.a.b2.v.g
            r2.<init>(r11, r12, r3, r4)
            r1.setCallback(r2)
            return r0
        L_0x00e2:
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            java.lang.String r1 = "Connecting socket"
            r0.logd(r1)
            r0 = 0
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            java.lang.String r1 = r1.getProxyHost()
            if (r1 != 0) goto L_0x00fd
            java.lang.String r1 = r11.proxyHost
            if (r1 == 0) goto L_0x00fd
            io.lum.sdk.async.http.AsyncHttpRequest r2 = r12.request
            int r6 = r11.proxyPort
            r2.enableProxy(r1, r6)
        L_0x00fd:
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            java.lang.String r1 = r1.getProxyHost()
            if (r1 == 0) goto L_0x0113
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r12.request
            java.lang.String r0 = r0.getProxyHost()
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            int r1 = r1.getProxyPort()
            r7 = r1
            goto L_0x0120
        L_0x0113:
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            android.net.Uri r1 = r1.getUri()
            java.lang.String r1 = r1.getHost()
            r0 = r1
            r7 = r4
            r5 = 0
        L_0x0120:
            if (r5 == 0) goto L_0x0140
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r6 = "Using proxy: "
            r2.append(r6)
            r2.append(r0)
            java.lang.String r6 = ":"
            r2.append(r6)
            r2.append(r7)
            java.lang.String r2 = r2.toString()
            r1.logv(r2)
        L_0x0140:
            io.lum.sdk.async.http.AsyncHttpRequest r1 = r12.request
            java.net.InetSocketAddress r1 = r1.get_local_address()
            if (r1 == 0) goto L_0x015f
            io.lum.sdk.async.http.AsyncHttpClient r2 = r11.mClient
            io.lum.sdk.async.AsyncServer r2 = r2.getServer()
            io.lum.sdk.async.AsyncServer r8 = r2.set_local_address(r1)
        L_0x0152:
            io.lum.sdk.async.callback.ConnectCallback r6 = r12.connectCallback
            r1 = r11
            r2 = r12
            io.lum.sdk.async.callback.ConnectCallback r12 = r1.wrapCallback(r2, r3, r4, r5, r6)
            io.lum.sdk.async.future.Cancellable r12 = r8.connectSocket(r0, r7, r12)
            return r12
        L_0x015f:
            io.lum.sdk.async.http.AsyncHttpClient r1 = r11.mClient
            io.lum.sdk.async.AsyncServer r8 = r1.getServer()
            goto L_0x0152
        L_0x0166:
            r12 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x0166 }
            goto L_0x016a
        L_0x0169:
            throw r12
        L_0x016a:
            goto L_0x0169
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.AsyncSocketMiddleware.getSocket(io.lum.sdk.async.http.AsyncHttpClientMiddleware$GetSocketData):io.lum.sdk.async.future.Cancellable");
    }

    public boolean isKeepAlive(AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData) {
        return HttpUtil.isKeepAlive(onResponseCompleteData.response.protocol(), onResponseCompleteData.response.headers()) && HttpUtil.isKeepAlive(Protocol.HTTP_1_1, onResponseCompleteData.request.getHeaders());
    }

    public void onResponseComplete(AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData) {
        AsyncSocket asyncSocket;
        if (onResponseCompleteData.state.get("socket-owner") == this) {
            try {
                idleSocket(onResponseCompleteData.socket);
                if (onResponseCompleteData.exception == null) {
                    if (onResponseCompleteData.socket.isOpen()) {
                        if (!isKeepAlive(onResponseCompleteData)) {
                            onResponseCompleteData.request.logv("closing out socket (not keep alive)");
                            onResponseCompleteData.socket.setClosedCallback((CompletedCallback) null);
                            asyncSocket = onResponseCompleteData.socket;
                            asyncSocket.close();
                        }
                        onResponseCompleteData.request.logd("Recycling keep-alive socket");
                        recycleSocket(onResponseCompleteData.socket, onResponseCompleteData.request);
                        nextConnection(onResponseCompleteData.request);
                        return;
                    }
                }
                onResponseCompleteData.request.logv("closing out socket (exception)");
                onResponseCompleteData.socket.setClosedCallback((CompletedCallback) null);
                asyncSocket = onResponseCompleteData.socket;
                asyncSocket.close();
            } finally {
                nextConnection(onResponseCompleteData.request);
            }
        }
    }

    public void setConnectAllAddresses(boolean z) {
        this.connectAllAddresses = z;
    }

    public void setIdleTimeoutMs(int i) {
        this.idleTimeoutMs = i;
    }

    public void setMaxConnectionCount(int i) {
        this.maxConnectionCount = i;
    }

    public ConnectCallback wrapCallback(AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, boolean z, ConnectCallback connectCallback) {
        return connectCallback;
    }
}
