package io.lum.sdk.async.http;

public class RedirectLimitExceededException extends Exception {
    public RedirectLimitExceededException(String str) {
        super(str);
    }
}
