package io.lum.sdk.async.http;

import android.text.TextUtils;
import android.util.Base64;
import d.a.a.b2.v.k;
import d.a.a.b2.v.l;
import d.a.a.b2.v.m;
import d.a.a.b2.v.n;
import d.a.a.b2.v.o;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.BufferedDataSink;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.async.http.server.AsyncHttpServerRequest;
import io.lum.sdk.async.http.server.AsyncHttpServerResponse;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.LinkedList;
import java.util.UUID;

public class WebSocketImpl implements WebSocket {
    public static final String MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    public DataCallback mDataCallback;
    public CompletedCallback mExceptionCallback;
    public HybiParser mParser;
    public WebSocket.PingCallback mPingCallback;
    public WebSocket.PongCallback mPongCallback;
    public BufferedDataSink mSink;
    public AsyncSocket mSocket;
    public WebSocket.StringCallback mStringCallback;
    public LinkedList<ByteBufferList> pending;
    public String protocol;

    public WebSocketImpl(AsyncSocket asyncSocket) {
        this.mSocket = asyncSocket;
        this.mSink = new BufferedDataSink(asyncSocket);
    }

    public WebSocketImpl(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        this(asyncHttpServerRequest.getSocket());
        String str = asyncHttpServerRequest.getHeaders().get("Sec-WebSocket-Key");
        String SHA1 = SHA1(str + MAGIC);
        asyncHttpServerRequest.getHeaders().get("Origin");
        asyncHttpServerResponse.code(101);
        asyncHttpServerResponse.getHeaders().set("Upgrade", "WebSocket");
        asyncHttpServerResponse.getHeaders().set("Connection", "Upgrade");
        asyncHttpServerResponse.getHeaders().set("Sec-WebSocket-Accept", SHA1);
        String str2 = asyncHttpServerRequest.getHeaders().get("Sec-WebSocket-Protocol");
        if (!TextUtils.isEmpty(str2)) {
            asyncHttpServerResponse.getHeaders().set("Sec-WebSocket-Protocol", str2);
        }
        asyncHttpServerResponse.writeHead();
        setupParser(false, false);
    }

    public static String SHA1(String str) {
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA-1");
            instance.update(str.getBytes("iso-8859-1"), 0, str.length());
            return Base64.encodeToString(instance.digest(), 2);
        } catch (Exception unused) {
            return null;
        }
    }

    /* access modifiers changed from: private */
    public void addAndEmit(ByteBufferList byteBufferList) {
        if (this.pending == null) {
            if (!isPaused()) {
                Util.emitAllData(this, byteBufferList);
            }
            if (byteBufferList.remaining() > 0) {
                LinkedList<ByteBufferList> linkedList = new LinkedList<>();
                this.pending = linkedList;
                linkedList.add(byteBufferList);
                return;
            }
            return;
        }
        while (!isPaused()) {
            ByteBufferList remove = this.pending.remove();
            Util.emitAllData(this, remove);
            if (remove.remaining() > 0) {
                this.pending.add(0, remove);
            }
        }
        if (this.pending.size() == 0) {
            this.pending = null;
        }
    }

    public static void addWebSocketUpgradeHeaders(AsyncHttpRequest asyncHttpRequest, String... strArr) {
        Headers headers = asyncHttpRequest.getHeaders();
        String encodeToString = Base64.encodeToString(toByteArray(UUID.randomUUID()), 2);
        headers.set("Sec-WebSocket-Version", "13");
        headers.set("Sec-WebSocket-Key", encodeToString);
        headers.set("Sec-WebSocket-Extensions", "x-webkit-deflate-frame");
        headers.set("Connection", "Upgrade");
        headers.set("Upgrade", "websocket");
        if (strArr != null) {
            for (String add : strArr) {
                headers.add("Sec-WebSocket-Protocol", add);
            }
        }
        headers.set("Pragma", "no-cache");
        headers.set("Cache-Control", "no-cache");
        if (TextUtils.isEmpty(asyncHttpRequest.getHeaders().get("User-Agent"))) {
            asyncHttpRequest.getHeaders().set("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.15 Safari/537.36");
        }
    }

    public static WebSocket finishHandshake(Headers headers, AsyncHttpResponse asyncHttpResponse) {
        String str;
        String str2;
        if (asyncHttpResponse == null || asyncHttpResponse.code() != 101 || !"websocket".equalsIgnoreCase(asyncHttpResponse.headers().get("Upgrade")) || (str = asyncHttpResponse.headers().get("Sec-WebSocket-Accept")) == null || (str2 = headers.get("Sec-WebSocket-Key")) == null) {
            return null;
        }
        if (!str.equalsIgnoreCase(SHA1(str2 + MAGIC).trim())) {
            return null;
        }
        String str3 = headers.get("Sec-WebSocket-Extensions");
        boolean z = false;
        if (str3 != null && str3.equals("x-webkit-deflate-frame")) {
            z = true;
        }
        WebSocketImpl webSocketImpl = new WebSocketImpl(asyncHttpResponse.detachSocket());
        webSocketImpl.protocol = asyncHttpResponse.headers().get("Sec-WebSocket-Protocol");
        webSocketImpl.setupParser(true, z);
        return webSocketImpl;
    }

    private void setupParser(boolean z, boolean z2) {
        AnonymousClass1 r0 = new HybiParser(this.mSocket) {
            public void onDisconnect(int i, String str) {
                WebSocketImpl.this.mSocket.close();
            }

            public void onMessage(String str) {
                if (WebSocketImpl.this.mStringCallback != null) {
                    WebSocketImpl.this.mStringCallback.onStringAvailable(str);
                }
            }

            public void onMessage(byte[] bArr) {
                WebSocketImpl.this.addAndEmit(new ByteBufferList(bArr));
            }

            public void onPing(String str) {
                if (WebSocketImpl.this.mPingCallback != null) {
                    WebSocketImpl.this.mPingCallback.onPingReceived(str);
                }
            }

            public void onPong(String str) {
                if (WebSocketImpl.this.mPongCallback != null) {
                    WebSocketImpl.this.mPongCallback.onPongReceived(str);
                }
            }

            public void report(Exception exc) {
                CompletedCallback completedCallback = WebSocketImpl.this.mExceptionCallback;
                if (completedCallback != null) {
                    completedCallback.onCompleted(exc);
                }
            }

            public void sendFrame(byte[] bArr) {
                WebSocketImpl.this.mSink.write(new ByteBufferList(bArr));
            }
        };
        this.mParser = r0;
        r0.setMasking(z);
        this.mParser.setDeflate(z2);
        if (this.mSocket.isPaused()) {
            this.mSocket.resume();
        }
    }

    public static byte[] toByteArray(UUID uuid) {
        byte[] bArr = new byte[16];
        ByteBuffer.wrap(bArr).asLongBuffer().put(new long[]{uuid.getMostSignificantBits(), uuid.getLeastSignificantBits()});
        return bArr;
    }

    public /* synthetic */ void a(String str) {
        this.mSink.write(new ByteBufferList(ByteBuffer.wrap(this.mParser.pingFrame(str))));
    }

    public /* synthetic */ void a(byte[] bArr) {
        this.mSink.write(new ByteBufferList(this.mParser.frame(bArr)));
    }

    public /* synthetic */ void a(byte[] bArr, int i, int i2) {
        this.mSink.write(new ByteBufferList(this.mParser.frame(bArr, i, i2)));
    }

    public /* synthetic */ void b(String str) {
        this.mSink.write(new ByteBufferList(ByteBuffer.wrap(this.mParser.pongFrame(str))));
    }

    public /* synthetic */ void c(String str) {
        this.mSink.write(new ByteBufferList(this.mParser.frame(str)));
    }

    public String charset() {
        return null;
    }

    public void close() {
        this.mSocket.close();
    }

    public void end() {
        this.mSocket.end();
    }

    public CompletedCallback getClosedCallback() {
        return this.mSocket.getClosedCallback();
    }

    public DataCallback getDataCallback() {
        return this.mDataCallback;
    }

    public CompletedCallback getEndCallback() {
        return this.mExceptionCallback;
    }

    public WebSocket.PongCallback getPongCallback() {
        return this.mPongCallback;
    }

    public String getProtocol() {
        return this.protocol;
    }

    public AsyncServer getServer() {
        return this.mSocket.getServer();
    }

    public AsyncSocket getSocket() {
        return this.mSocket;
    }

    public WebSocket.StringCallback getStringCallback() {
        return this.mStringCallback;
    }

    public WritableCallback getWriteableCallback() {
        return this.mSink.getWriteableCallback();
    }

    public boolean isBuffering() {
        return this.mSink.remaining() > 0;
    }

    public boolean isChunked() {
        return false;
    }

    public boolean isOpen() {
        return this.mSocket.isOpen();
    }

    public boolean isPaused() {
        return this.mSocket.isPaused();
    }

    public void pause() {
        this.mSocket.pause();
    }

    public void ping(String str) {
        getServer().post(new o(this, str));
    }

    public void pong(String str) {
        getServer().post(new m(this, str));
    }

    public void resume() {
        this.mSocket.resume();
    }

    public void send(String str) {
        getServer().post(new n(this, str));
    }

    public void send(byte[] bArr) {
        getServer().post(new l(this, bArr));
    }

    public void send(byte[] bArr, int i, int i2) {
        getServer().post(new k(this, bArr, i, i2));
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        this.mSocket.setClosedCallback(completedCallback);
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.mDataCallback = dataCallback;
    }

    public void setEndCallback(CompletedCallback completedCallback) {
        this.mExceptionCallback = completedCallback;
    }

    public void setPingCallback(WebSocket.PingCallback pingCallback) {
        this.mPingCallback = pingCallback;
    }

    public void setPongCallback(WebSocket.PongCallback pongCallback) {
        this.mPongCallback = pongCallback;
    }

    public void setStringCallback(WebSocket.StringCallback stringCallback) {
        this.mStringCallback = stringCallback;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        this.mSink.setWriteableCallback(writableCallback);
    }

    public void write(ByteBufferList byteBufferList) {
        send(byteBufferList.getAllByteArray());
    }
}
