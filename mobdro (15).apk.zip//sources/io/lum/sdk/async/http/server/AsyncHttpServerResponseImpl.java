package io.lum.sdk.async.http.server;

import android.text.TextUtils;
import d.a.a.b2.v.r.a;
import d.a.a.b2.v.r.b;
import d.a.a.b2.v.r.d;
import d.a.a.b2.v.r.e;
import d.a.a.b2.v.r.f;
import d.a.a.b2.v.r.g;
import d.a.a.b2.v.r.h;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.WritableCallback;
import io.lum.sdk.async.http.AsyncHttpHead;
import io.lum.sdk.async.http.AsyncHttpResponse;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.HttpUtil;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.filter.ChunkedOutputFilter;
import io.lum.sdk.async.parser.AsyncParser;
import io.lum.sdk.async.util.StreamUtility;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class AsyncHttpServerResponseImpl implements AsyncHttpServerResponse {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public CompletedCallback closedCallback;
    public int code = 200;
    public boolean ended;
    public boolean headWritten = false;
    public String httpVersion = "HTTP/1.1";
    public long mContentLength = -1;
    public boolean mEnded;
    public Headers mRawHeaders = new Headers();
    public AsyncHttpServerRequestImpl mRequest;
    public DataSink mSink;
    public AsyncSocket mSocket;
    public WritableCallback writable;

    public AsyncHttpServerResponseImpl(AsyncSocket asyncSocket, AsyncHttpServerRequestImpl asyncHttpServerRequestImpl) {
        this.mSocket = asyncSocket;
        this.mRequest = asyncHttpServerRequestImpl;
        if (HttpUtil.isKeepAlive(Protocol.HTTP_1_1, asyncHttpServerRequestImpl.getHeaders())) {
            this.mRawHeaders.set("Connection", "Keep-Alive");
        }
    }

    public /* synthetic */ void a() {
        WritableCallback writeableCallback = getWriteableCallback();
        if (writeableCallback != null) {
            writeableCallback.onWriteable();
        }
    }

    public /* synthetic */ void a(ByteBufferList byteBufferList, String str) {
        long remaining = (long) byteBufferList.remaining();
        this.mContentLength = remaining;
        this.mRawHeaders.set("Content-Length", Long.toString(remaining));
        if (str != null) {
            this.mRawHeaders.set("Content-Type", str);
        }
        Util.writeAll((DataSink) this, byteBufferList, (CompletedCallback) new f(this));
    }

    public /* synthetic */ void a(AsyncHttpResponse asyncHttpResponse, Exception exc) {
        asyncHttpResponse.setEndCallback(new CompletedCallback.NullCompletedCallback());
        asyncHttpResponse.setDataCallback(new DataCallback.NullDataCallback());
        end();
    }

    public /* synthetic */ void a(InputStream inputStream) {
        Util.pump(inputStream, this.mContentLength, this, new a(this, inputStream));
    }

    public /* synthetic */ void a(InputStream inputStream, Exception exc) {
        StreamUtility.closeQuietly(inputStream);
        onEnd();
    }

    public /* synthetic */ void a(Exception exc) {
        onEnd();
    }

    /* JADX WARNING: type inference failed for: r2v7, types: [io.lum.sdk.async.http.filter.ChunkedOutputFilter, io.lum.sdk.async.BufferedDataSink] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ void a(boolean r2, java.lang.Exception r3) {
        /*
            r1 = this;
            if (r3 == 0) goto L_0x0006
            r1.report(r3)
            return
        L_0x0006:
            if (r2 == 0) goto L_0x0014
            io.lum.sdk.async.http.filter.ChunkedOutputFilter r2 = new io.lum.sdk.async.http.filter.ChunkedOutputFilter
            io.lum.sdk.async.AsyncSocket r3 = r1.mSocket
            r2.<init>(r3)
            r3 = 0
            r2.setMaxBuffer(r3)
            goto L_0x0016
        L_0x0014:
            io.lum.sdk.async.AsyncSocket r2 = r1.mSocket
        L_0x0016:
            r1.mSink = r2
            io.lum.sdk.async.DataSink r2 = r1.mSink
            io.lum.sdk.async.callback.CompletedCallback r3 = r1.closedCallback
            r2.setClosedCallback(r3)
            r2 = 0
            r1.closedCallback = r2
            io.lum.sdk.async.DataSink r3 = r1.mSink
            io.lum.sdk.async.callback.WritableCallback r0 = r1.writable
            r3.setWriteableCallback(r0)
            r1.writable = r2
            boolean r2 = r1.ended
            if (r2 == 0) goto L_0x0033
            r1.end()
            return
        L_0x0033:
            io.lum.sdk.async.AsyncServer r2 = r1.getServer()
            d.a.a.b2.v.r.c r3 = new d.a.a.b2.v.r.c
            r3.<init>(r1)
            r2.post(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.server.AsyncHttpServerResponseImpl.a(boolean, java.lang.Exception):void");
    }

    public /* synthetic */ void b(Exception exc) {
        end();
    }

    public int code() {
        return this.code;
    }

    public AsyncHttpServerResponse code(int i) {
        this.code = i;
        return this;
    }

    public void end() {
        if (!this.ended) {
            this.ended = true;
            if (!this.headWritten || this.mSink != null) {
                if (!this.headWritten) {
                    this.mRawHeaders.remove("Transfer-Encoding");
                }
                DataSink dataSink = this.mSink;
                if (dataSink instanceof ChunkedOutputFilter) {
                    dataSink.end();
                    return;
                }
                if (!this.headWritten) {
                    if (!this.mRequest.getMethod().equalsIgnoreCase(AsyncHttpHead.METHOD)) {
                        send("text/html", "");
                        return;
                    }
                    writeHead();
                }
                onEnd();
            }
        }
    }

    public CompletedCallback getClosedCallback() {
        DataSink dataSink = this.mSink;
        return dataSink != null ? dataSink.getClosedCallback() : this.closedCallback;
    }

    public Headers getHeaders() {
        return this.mRawHeaders;
    }

    public String getHttpVersion() {
        return this.httpVersion;
    }

    public AsyncHttpServerRequest getRequest() {
        return this.mRequest;
    }

    public AsyncServer getServer() {
        return this.mSocket.getServer();
    }

    public AsyncSocket getSocket() {
        return this.mSocket;
    }

    public WritableCallback getWriteableCallback() {
        DataSink dataSink = this.mSink;
        return dataSink != null ? dataSink.getWriteableCallback() : this.writable;
    }

    public void initFirstWrite() {
        boolean z;
        if (!this.headWritten) {
            this.headWritten = true;
            String str = this.mRawHeaders.get("Transfer-Encoding");
            if ("".equals(str)) {
                this.mRawHeaders.removeAll("Transfer-Encoding");
            }
            boolean z2 = ("Chunked".equalsIgnoreCase(str) || str == null) && !"close".equalsIgnoreCase(this.mRawHeaders.get("Connection"));
            if (this.mContentLength < 0) {
                String str2 = this.mRawHeaders.get("Content-Length");
                if (!TextUtils.isEmpty(str2)) {
                    this.mContentLength = Long.valueOf(str2).longValue();
                }
            }
            if (this.mContentLength >= 0 || !z2) {
                z = false;
            } else {
                this.mRawHeaders.set("Transfer-Encoding", "Chunked");
                z = true;
            }
            Util.writeAll((DataSink) this.mSocket, this.mRawHeaders.toPrefixString(String.format(Locale.ENGLISH, "%s %s %s", new Object[]{this.httpVersion, Integer.valueOf(this.code), AsyncHttpServer.getResponseCodeDescription(this.code)})).getBytes(), (CompletedCallback) new e(this, z));
        }
    }

    public boolean isOpen() {
        DataSink dataSink = this.mSink;
        return dataSink != null ? dataSink.isOpen() : this.mSocket.isOpen();
    }

    public void onCompleted(Exception exc) {
        end();
    }

    public void onEnd() {
        this.mEnded = true;
    }

    public void proxy(AsyncHttpResponse asyncHttpResponse) {
        code(asyncHttpResponse.code());
        asyncHttpResponse.headers().removeAll("Transfer-Encoding");
        asyncHttpResponse.headers().removeAll("Content-Encoding");
        asyncHttpResponse.headers().removeAll("Connection");
        getHeaders().addAll(asyncHttpResponse.headers());
        asyncHttpResponse.headers().set("Connection", "close");
        Util.pump((DataEmitter) asyncHttpResponse, (DataSink) this, (CompletedCallback) new d(this, asyncHttpResponse));
    }

    public void redirect(String str) {
        code(302);
        this.mRawHeaders.set("Location", str);
        end();
    }

    public void report(Exception exc) {
    }

    public void send(String str) {
        String str2 = this.mRawHeaders.get("Content-Type");
        if (str2 == null) {
            str2 = "text/html; charset=utf-8";
        }
        send(str2, str);
    }

    public void send(String str, ByteBufferList byteBufferList) {
        getServer().post(new b(this, byteBufferList, str));
    }

    public void send(String str, String str2) {
        try {
            send(str, str2.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e2) {
            throw new AssertionError(e2);
        }
    }

    public void send(String str, ByteBuffer byteBuffer) {
        send(str, new ByteBufferList(byteBuffer));
    }

    public void send(String str, byte[] bArr) {
        send(str, new ByteBufferList(bArr));
    }

    public void send(JSONArray jSONArray) {
        send("application/json; charset=utf-8", jSONArray.toString());
    }

    public void send(JSONObject jSONObject) {
        send("application/json; charset=utf-8", jSONObject.toString());
    }

    public <T> void sendBody(AsyncParser<T> asyncParser, T t) {
        this.mRawHeaders.set("Content-Type", asyncParser.getMime());
        asyncParser.write(this, t, new h(this));
    }

    public void sendFile(File file) {
        try {
            if (this.mRawHeaders.get("Content-Type") == null) {
                this.mRawHeaders.set("Content-Type", AsyncHttpServerRouter.getContentType(file.getAbsolutePath()));
            }
            sendStream(new BufferedInputStream(new FileInputStream(file), 64000), file.length());
        } catch (FileNotFoundException unused) {
            code(404);
            end();
        }
    }

    public void sendStream(InputStream inputStream, long j) {
        long j2;
        InputStream inputStream2 = inputStream;
        long j3 = j - 1;
        String str = this.mRequest.getHeaders().get("Range");
        if (str != null) {
            String[] split = str.split("=");
            if (split.length == 2 && "bytes".equals(split[0])) {
                String[] split2 = split[1].split("-");
                try {
                    if (split2.length <= 2) {
                        long parseLong = !TextUtils.isEmpty(split2[0]) ? Long.parseLong(split2[0]) : 0;
                        if (split2.length == 2 && !TextUtils.isEmpty(split2[1])) {
                            j3 = Long.parseLong(split2[1]);
                        }
                        code(206);
                        getHeaders().set("Content-Range", String.format(Locale.ENGLISH, "bytes %d-%d/%d", new Object[]{Long.valueOf(parseLong), Long.valueOf(j3), Long.valueOf(j)}));
                        j2 = parseLong;
                    } else {
                        throw new MalformedRangeException();
                    }
                } catch (Exception unused) {
                }
            }
            code(416);
            end();
            return;
        }
        j2 = 0;
        try {
            if (j2 == inputStream2.skip(j2)) {
                long j4 = (j3 - j2) + 1;
                this.mContentLength = j4;
                this.mRawHeaders.set("Content-Length", String.valueOf(j4));
                this.mRawHeaders.set("Accept-Ranges", "bytes");
                if (this.mRequest.getMethod().equals(AsyncHttpHead.METHOD)) {
                    writeHead();
                    onEnd();
                } else if (this.mContentLength == 0) {
                    writeHead();
                    StreamUtility.closeQuietly(inputStream2);
                    onEnd();
                } else {
                    getServer().post(new g(this, inputStream2));
                }
            } else {
                throw new StreamSkipException("skip failed to skip requested amount");
            }
        } catch (Exception unused2) {
            code(500);
            end();
        }
    }

    public void setClosedCallback(CompletedCallback completedCallback) {
        DataSink dataSink = this.mSink;
        if (dataSink != null) {
            dataSink.setClosedCallback(completedCallback);
        } else {
            this.closedCallback = completedCallback;
        }
    }

    public void setContentType(String str) {
        this.mRawHeaders.set("Content-Type", str);
    }

    public void setHttpVersion(String str) {
        this.httpVersion = str;
    }

    public void setSocket(AsyncSocket asyncSocket) {
        this.mSocket = asyncSocket;
    }

    public void setWriteableCallback(WritableCallback writableCallback) {
        DataSink dataSink = this.mSink;
        if (dataSink != null) {
            dataSink.setWriteableCallback(writableCallback);
        } else {
            this.writable = writableCallback;
        }
    }

    public String toString() {
        if (this.mRawHeaders == null) {
            return super.toString();
        }
        return this.mRawHeaders.toPrefixString(String.format(Locale.ENGLISH, "%s %s %s", new Object[]{this.httpVersion, Integer.valueOf(this.code), AsyncHttpServer.getResponseCodeDescription(this.code)}));
    }

    public void write(ByteBufferList byteBufferList) {
        DataSink dataSink;
        if (!this.headWritten) {
            initFirstWrite();
        }
        if (byteBufferList.remaining() != 0 && (dataSink = this.mSink) != null) {
            dataSink.write(byteBufferList);
        }
    }

    public void writeHead() {
        initFirstWrite();
    }
}
