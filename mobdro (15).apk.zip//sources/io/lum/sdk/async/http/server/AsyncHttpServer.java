package io.lum.sdk.async.http.server;

import android.annotation.TargetApi;
import io.lum.sdk.async.AsyncSSLSocket;
import io.lum.sdk.async.AsyncSSLSocketWrapper;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncServerSocket;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.callback.ListenCallback;
import io.lum.sdk.async.callback.ValueCallback;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.HttpUtil;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import io.lum.sdk.async.http.server.AsyncHttpServerRouter;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

@TargetApi(5)
public class AsyncHttpServer extends AsyncHttpServerRouter {
    public static Hashtable<Integer, String> mCodes;
    public CompletedCallback mCompletedCallback;
    public ListenCallback mListenCallback = new ListenCallback() {
        public void onAccepted(final AsyncSocket asyncSocket) {
            new AsyncHttpServerRouter.AsyncHttpServerRequestImpl() {
                public String fullPath;
                public boolean handled;
                public boolean hasContinued;
                public final ValueCallback<Exception> onException = new ValueCallback<Exception>() {
                    public void onResult(Exception exc) {
                    }
                };
                public final Runnable onFinally = new Runnable() {
                    public void run() {
                    }
                };
                public String path;
                public HttpServerRequestCallback requestCallback;
                public boolean requestComplete;
                public AsyncHttpServerResponseImpl res;
                public boolean responseComplete;
                public AsyncHttpServerRouter.AsyncHttpServerRequestImpl self = this;

                /* access modifiers changed from: private */
                public void handleOnCompleted() {
                    if (this.requestComplete && this.responseComplete && !AsyncHttpServer.this.isSwitchingProtocols(this.res)) {
                        if (AsyncHttpServer.this.isKeepAlive(this.self, this.res)) {
                            AnonymousClass1.this.onAccepted(asyncSocket);
                        } else {
                            asyncSocket.close();
                        }
                    }
                }

                public String getPath() {
                    return this.path;
                }

                public Multimap getQuery() {
                    String[] split = this.fullPath.split("\\?", 2);
                    return split.length < 2 ? new Multimap() : Multimap.parseQuery(split[1]);
                }

                public String getUrl() {
                    return this.fullPath;
                }

                public AsyncHttpRequestBody onBody(Headers headers) {
                    String[] split = getStatusLine().split(" ");
                    String str = split[1];
                    this.fullPath = str;
                    String decode = URLDecoder.decode(str.split("\\?")[0]);
                    this.path = decode;
                    String str2 = split[0];
                    this.method = str2;
                    AsyncHttpServerRouter.RouteMatch route = AsyncHttpServer.this.route(str2, decode);
                    if (route == null) {
                        return null;
                    }
                    this.matcher = route.matcher;
                    this.requestCallback = route.callback;
                    AsyncHttpRequestBodyProvider asyncHttpRequestBodyProvider = route.bodyCallback;
                    if (asyncHttpRequestBodyProvider == null) {
                        return null;
                    }
                    return asyncHttpRequestBodyProvider.getBody(headers);
                }

                public void onCompleted(Exception exc) {
                    this.requestComplete = true;
                    super.onCompleted(exc);
                    this.mSocket.setDataCallback(new DataCallback.NullDataCallback() {
                        public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                            super.onDataAvailable(dataEmitter, byteBufferList);
                            AnonymousClass1.this.mSocket.close();
                        }
                    });
                    if (exc != null) {
                        this.mSocket.close();
                        return;
                    }
                    handleOnCompleted();
                    if (getBody().readFullyOnRequest() && !this.handled) {
                        onRequest();
                    }
                }

                public void onHeadersReceived() {
                    Headers headers = getHeaders();
                    if (this.hasContinued || !"100-continue".equals(headers.get("Expect"))) {
                        AnonymousClass4 r0 = new AsyncHttpServerResponseImpl(asyncSocket, this) {
                            public void onEnd() {
                                AnonymousClass1.this.responseComplete = true;
                                super.onEnd();
                                this.mSocket.setEndCallback((CompletedCallback) null);
                                AsyncHttpServer.this.onResponseCompleted(getRequest(), AnonymousClass1.this.res);
                                AnonymousClass1.this.handleOnCompleted();
                            }

                            public void report(Exception exc) {
                                super.report(exc);
                                if (exc != null) {
                                    asyncSocket.setDataCallback(new DataCallback.NullDataCallback());
                                    asyncSocket.setEndCallback(new CompletedCallback.NullCompletedCallback());
                                    asyncSocket.close();
                                }
                            }
                        };
                        this.res = r0;
                        boolean onRequest = AsyncHttpServer.this.onRequest(this, r0);
                        this.handled = onRequest;
                        if (!onRequest) {
                            if (this.requestCallback == null) {
                                this.res.code(404);
                                this.res.end();
                            } else if (!getBody().readFullyOnRequest() || this.requestComplete) {
                                onRequest();
                            }
                        }
                    } else {
                        pause();
                        Util.writeAll((DataSink) this.mSocket, "HTTP/1.1 100 Continue\r\n\r\n".getBytes(), (CompletedCallback) new CompletedCallback() {
                            public void onCompleted(Exception exc) {
                                AnonymousClass1.this.resume();
                                if (exc != null) {
                                    AnonymousClass1.this.report(exc);
                                    return;
                                }
                                AnonymousClass1 r2 = AnonymousClass1.this;
                                r2.hasContinued = true;
                                r2.onHeadersReceived();
                            }
                        });
                    }
                }

                public void onRequest() {
                    AsyncHttpServer.this.onRequest(this.requestCallback, this, this.res);
                }

                public AsyncHttpRequestBody onUnknownBody(Headers headers) {
                    return AsyncHttpServer.this.onUnknownBody(headers);
                }
            }.setSocket(asyncSocket);
            asyncSocket.resume();
        }

        public void onCompleted(Exception exc) {
            AsyncHttpServer.this.report(exc);
        }

        public void onListening(AsyncServerSocket asyncServerSocket) {
            AsyncHttpServer.this.mListeners.add(asyncServerSocket);
        }
    };
    public ArrayList<AsyncServerSocket> mListeners = new ArrayList<>();

    public interface WebSocketRequestCallback {
        void onConnected(WebSocket webSocket, AsyncHttpServerRequest asyncHttpServerRequest);
    }

    static {
        Hashtable<Integer, String> hashtable = new Hashtable<>();
        mCodes = hashtable;
        hashtable.put(200, "OK");
        mCodes.put(202, "Accepted");
        mCodes.put(206, "Partial Content");
        mCodes.put(101, "Switching Protocols");
        mCodes.put(301, "Moved Permanently");
        mCodes.put(302, "Found");
        mCodes.put(304, "Not Modified");
        mCodes.put(400, "Bad Request");
        mCodes.put(404, "Not Found");
        mCodes.put(500, "Internal Server Error");
    }

    public static String getResponseCodeDescription(int i) {
        String str = mCodes.get(Integer.valueOf(i));
        return str == null ? "Unknown" : str;
    }

    /* access modifiers changed from: private */
    public void report(Exception exc) {
        CompletedCallback completedCallback = this.mCompletedCallback;
        if (completedCallback != null) {
            completedCallback.onCompleted(exc);
        }
    }

    public CompletedCallback getErrorCallback() {
        return this.mCompletedCallback;
    }

    public ListenCallback getListenCallback() {
        return this.mListenCallback;
    }

    public boolean isKeepAlive(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        return HttpUtil.isKeepAlive(asyncHttpServerResponse.getHttpVersion(), asyncHttpServerRequest.getHeaders());
    }

    public boolean isSwitchingProtocols(AsyncHttpServerResponse asyncHttpServerResponse) {
        return asyncHttpServerResponse.code() == 101;
    }

    public AsyncServerSocket listen(int i) {
        return listen(AsyncServer.getDefault(), i);
    }

    public AsyncServerSocket listen(AsyncServer asyncServer, int i) {
        return asyncServer.listen((InetAddress) null, i, this.mListenCallback);
    }

    public void listenSecure(final int i, final SSLContext sSLContext) {
        AsyncServer.getDefault().listen((InetAddress) null, i, new ListenCallback() {
            public void onAccepted(AsyncSocket asyncSocket) {
                AsyncSSLSocketWrapper.handshake(asyncSocket, (String) null, i, sSLContext.createSSLEngine(), (TrustManager[]) null, (HostnameVerifier) null, false, new AsyncSSLSocketWrapper.HandshakeCallback() {
                    public void onHandshakeCompleted(Exception exc, AsyncSSLSocket asyncSSLSocket) {
                        if (asyncSSLSocket != null) {
                            AsyncHttpServer.this.mListenCallback.onAccepted(asyncSSLSocket);
                        }
                    }
                });
            }

            public void onCompleted(Exception exc) {
                AsyncHttpServer.this.mListenCallback.onCompleted(exc);
            }

            public void onListening(AsyncServerSocket asyncServerSocket) {
                AsyncHttpServer.this.mListenCallback.onListening(asyncServerSocket);
            }
        });
    }

    public void onRequest(HttpServerRequestCallback httpServerRequestCallback, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        if (httpServerRequestCallback != null) {
            try {
                httpServerRequestCallback.onRequest(asyncHttpServerRequest, asyncHttpServerResponse);
            } catch (Exception unused) {
                asyncHttpServerResponse.code(500);
                asyncHttpServerResponse.end();
            }
        }
    }

    public boolean onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        return false;
    }

    public void onResponseCompleted(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
    }

    public AsyncHttpRequestBody onUnknownBody(Headers headers) {
        return new UnknownRequestBody(headers.get("Content-Type"));
    }

    public void setErrorCallback(CompletedCallback completedCallback) {
        this.mCompletedCallback = completedCallback;
    }

    public void stop() {
        ArrayList<AsyncServerSocket> arrayList = this.mListeners;
        if (arrayList != null) {
            Iterator<AsyncServerSocket> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().stop();
            }
        }
    }
}
