package io.lum.sdk.async.http.spdy;

import b.a.a.a.a;
import io.lum.sdk.Base64;
import io.lum.sdk.async.BufferedDataSink;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataEmitterReader;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.spdy.FrameReader;
import io.lum.sdk.async.http.spdy.HpackDraft08;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Http20Draft13 implements Variant {
    public static final ByteString CONNECTION_PREFACE = ByteString.encodeUtf8("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
    public static final byte FLAG_ACK = 1;
    public static final byte FLAG_COMPRESSED = 32;
    public static final byte FLAG_END_HEADERS = 4;
    public static final byte FLAG_END_PUSH_PROMISE = 4;
    public static final byte FLAG_END_SEGMENT = 2;
    public static final byte FLAG_END_STREAM = 1;
    public static final byte FLAG_NONE = 0;
    public static final byte FLAG_PADDED = 8;
    public static final byte FLAG_PRIORITY = 32;
    public static final int MAX_FRAME_SIZE = 16383;
    public static final byte TYPE_CONTINUATION = 9;
    public static final byte TYPE_DATA = 0;
    public static final byte TYPE_GOAWAY = 7;
    public static final byte TYPE_HEADERS = 1;
    public static final byte TYPE_PING = 6;
    public static final byte TYPE_PRIORITY = 2;
    public static final byte TYPE_PUSH_PROMISE = 5;
    public static final byte TYPE_RST_STREAM = 3;
    public static final byte TYPE_SETTINGS = 4;
    public static final byte TYPE_WINDOW_UPDATE = 8;
    public static final Logger logger = Logger.getLogger(Http20Draft13.class.getName());

    public static final class FrameLogger {
        public static final String[] BINARY = new String[256];
        public static final String[] FLAGS = new String[64];
        public static final String[] TYPES = {"DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"};

        static {
            int i = 0;
            int i2 = 0;
            while (true) {
                String[] strArr = BINARY;
                if (i2 >= strArr.length) {
                    break;
                }
                strArr[i2] = String.format(Locale.ENGLISH, "%8s", new Object[]{Integer.toBinaryString(i2)}).replace(' ', '0');
                i2++;
            }
            String[] strArr2 = FLAGS;
            strArr2[0] = "";
            strArr2[1] = "END_STREAM";
            strArr2[2] = "END_SEGMENT";
            strArr2[3] = "END_STREAM|END_SEGMENT";
            int[] iArr = {1, 2, 3};
            strArr2[8] = "PADDED";
            for (int i3 = 0; i3 < 3; i3++) {
                int i4 = iArr[i3];
                FLAGS[i4 | 8] = a.a(new StringBuilder(), FLAGS[i4], "|PADDED");
            }
            String[] strArr3 = FLAGS;
            strArr3[4] = "END_HEADERS";
            strArr3[32] = "PRIORITY";
            strArr3[36] = "END_HEADERS|PRIORITY";
            int[] iArr2 = {4, 32, 36};
            for (int i5 = 0; i5 < 3; i5++) {
                int i6 = iArr2[i5];
                for (int i7 = 0; i7 < 3; i7++) {
                    int i8 = iArr[i7];
                    String[] strArr4 = FLAGS;
                    int i9 = i8 | i6;
                    strArr4[i9] = FLAGS[i8] + '|' + FLAGS[i6];
                    StringBuilder sb = new StringBuilder();
                    sb.append(FLAGS[i8]);
                    sb.append('|');
                    FLAGS[i9 | 8] = a.a(sb, FLAGS[i6], "|PADDED");
                }
            }
            while (true) {
                String[] strArr5 = FLAGS;
                if (i < strArr5.length) {
                    if (strArr5[i] == null) {
                        strArr5[i] = BINARY[i];
                    }
                    i++;
                } else {
                    return;
                }
            }
        }

        public static String formatFlags(byte b2, byte b3) {
            if (b3 == 0) {
                return "";
            }
            if (!(b2 == 2 || b2 == 3)) {
                if (b2 == 4 || b2 == 6) {
                    return b3 == 1 ? "ACK" : BINARY[b3];
                }
                if (!(b2 == 7 || b2 == 8)) {
                    String[] strArr = FLAGS;
                    String str = b3 < strArr.length ? strArr[b3] : BINARY[b3];
                    return (b2 != 5 || (b3 & 4) == 0) ? (b2 != 0 || (b3 & 32) == 0) ? str : str.replace("PRIORITY", "COMPRESSED") : str.replace("HEADERS", "PUSH_PROMISE");
                }
            }
            return BINARY[b3];
        }

        public static String formatHeader(boolean z, int i, int i2, byte b2, byte b3) {
            String[] strArr = TYPES;
            String format = b2 < strArr.length ? strArr[b2] : String.format(Locale.ENGLISH, "0x%02x", new Object[]{Byte.valueOf(b2)});
            String formatFlags = formatFlags(b2, b3);
            Locale locale = Locale.ENGLISH;
            Object[] objArr = new Object[5];
            objArr[0] = z ? "<<" : ">>";
            objArr[1] = Integer.valueOf(i);
            objArr[2] = Integer.valueOf(i2);
            objArr[3] = format;
            objArr[4] = formatFlags;
            return String.format(locale, "%s 0x%08x %5d %-13s %s", objArr);
        }
    }

    public static final class Reader implements FrameReader {
        public final boolean client;
        public int continuingStreamId;
        public final DataEmitter emitter;
        public byte flags;
        public final FrameReader.Handler handler;
        public final HpackDraft08.Reader hpackReader;
        public short length;
        public final DataCallback onFrame = new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                byteBufferList.order(ByteOrder.BIG_ENDIAN);
                Reader.this.w1 = byteBufferList.getInt();
                Reader.this.w2 = byteBufferList.getInt();
                Reader reader = Reader.this;
                int i = reader.w1;
                reader.length = (short) ((1073676288 & i) >> 16);
                reader.type = (byte) ((65280 & i) >> 8);
                reader.flags = (byte) (i & 255);
                reader.streamId = reader.w2 & Integer.MAX_VALUE;
                if (Http20Draft13.logger.isLoggable(Level.FINE)) {
                    Logger access$000 = Http20Draft13.logger;
                    Reader reader2 = Reader.this;
                    access$000.fine(FrameLogger.formatHeader(true, reader2.streamId, reader2.length, reader2.type, reader2.flags));
                }
                DataEmitterReader access$200 = Reader.this.reader;
                Reader reader3 = Reader.this;
                access$200.read(reader3.length, reader3.onFullFrame);
            }
        };
        public final DataCallback onFullFrame = new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                try {
                    switch (Reader.this.type) {
                        case 0:
                            Reader.this.readData(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 1:
                            Reader.this.readHeaders(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 2:
                            Reader.this.readPriority(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 3:
                            Reader.this.readRstStream(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 4:
                            Reader.this.readSettings(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 5:
                            Reader.this.readPushPromise(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 6:
                            Reader.this.readPing(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 7:
                            Reader.this.readGoAway(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 8:
                            Reader.this.readWindowUpdate(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        case 9:
                            Reader.this.readContinuation(byteBufferList, Reader.this.length, Reader.this.flags, Reader.this.streamId);
                            break;
                        default:
                            byteBufferList.recycle();
                            break;
                    }
                    Reader.this.parseFrameHeader();
                } catch (IOException e2) {
                    Reader.this.handler.error(e2);
                }
            }
        };
        public byte pendingHeaderType;
        public int promisedStreamId;
        public final DataEmitterReader reader;
        public int streamId;
        public byte type;
        public int w1;
        public int w2;

        public Reader(DataEmitter dataEmitter, FrameReader.Handler handler2, int i, boolean z) {
            this.emitter = dataEmitter;
            this.client = z;
            this.hpackReader = new HpackDraft08.Reader(i);
            this.handler = handler2;
            this.reader = new DataEmitterReader();
            parseFrameHeader();
        }

        /* access modifiers changed from: private */
        public void parseFrameHeader() {
            this.emitter.setDataCallback(this.reader);
            this.reader.read(8, this.onFrame);
        }

        /* access modifiers changed from: private */
        public void readContinuation(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (i == this.continuingStreamId) {
                readHeaderBlock(byteBufferList, s, 0, b2, i);
                return;
            }
            throw new IOException("continuation stream id mismatch");
        }

        /* access modifiers changed from: private */
        public void readData(ByteBufferList byteBufferList, short s, byte b2, int i) {
            boolean z = true;
            short s2 = 0;
            boolean z2 = (b2 & 1) != 0;
            if ((b2 & 32) == 0) {
                z = false;
            }
            if (!z) {
                if ((b2 & 8) != 0) {
                    s2 = (short) (byteBufferList.get() & Base64.EQUALS_SIGN_ENC);
                }
                short unused = Http20Draft13.lengthWithoutPadding(s, b2, s2);
                this.handler.data(z2, i, byteBufferList);
                byteBufferList.skip(s2);
                return;
            }
            throw Http20Draft13.ioException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
        }

        /* access modifiers changed from: private */
        public void readGoAway(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (s < 8) {
                throw Http20Draft13.ioException("TYPE_GOAWAY length < 8: %s", Short.valueOf(s));
            } else if (i == 0) {
                int i2 = byteBufferList.getInt();
                int i3 = byteBufferList.getInt();
                int i4 = s - 8;
                ErrorCode fromHttp2 = ErrorCode.fromHttp2(i3);
                if (fromHttp2 != null) {
                    ByteString byteString = ByteString.EMPTY;
                    if (i4 > 0) {
                        byteString = ByteString.of(byteBufferList.getBytes(i4));
                    }
                    this.handler.goAway(i2, fromHttp2, byteString);
                    return;
                }
                throw Http20Draft13.ioException("TYPE_GOAWAY unexpected error code: %d", Integer.valueOf(i3));
            } else {
                throw Http20Draft13.ioException("TYPE_GOAWAY streamId != 0", new Object[0]);
            }
        }

        private void readHeaderBlock(ByteBufferList byteBufferList, short s, short s2, byte b2, int i) {
            byteBufferList.skip(s2);
            this.hpackReader.refill(byteBufferList);
            this.hpackReader.readHeaders();
            this.hpackReader.emitReferenceSet();
            if ((b2 & 4) != 0) {
                byte b3 = this.pendingHeaderType;
                if (b3 == 1) {
                    this.handler.headers(false, (b2 & 1) != 0, i, -1, this.hpackReader.getAndReset(), HeadersMode.HTTP_20_HEADERS);
                } else if (b3 == 5) {
                    this.handler.pushPromise(i, this.promisedStreamId, this.hpackReader.getAndReset());
                } else {
                    throw new AssertionError("unknown header type");
                }
            } else {
                this.continuingStreamId = i;
            }
        }

        /* access modifiers changed from: private */
        public void readHeaders(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (i != 0) {
                short s2 = (b2 & 8) != 0 ? (short) (byteBufferList.get() & Base64.EQUALS_SIGN_ENC) : 0;
                if ((b2 & 32) != 0) {
                    readPriority(byteBufferList, i);
                    s = (short) (s - 5);
                }
                short access$1600 = Http20Draft13.lengthWithoutPadding(s, b2, s2);
                this.pendingHeaderType = this.type;
                readHeaderBlock(byteBufferList, access$1600, s2, b2, i);
                return;
            }
            throw Http20Draft13.ioException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
        }

        /* access modifiers changed from: private */
        public void readPing(ByteBufferList byteBufferList, short s, byte b2, int i) {
            boolean z = false;
            if (s != 8) {
                throw Http20Draft13.ioException("TYPE_PING length != 8: %s", Short.valueOf(s));
            } else if (i == 0) {
                int i2 = byteBufferList.getInt();
                int i3 = byteBufferList.getInt();
                if ((b2 & 1) != 0) {
                    z = true;
                }
                this.handler.ping(z, i2, i3);
            } else {
                throw Http20Draft13.ioException("TYPE_PING streamId != 0", new Object[0]);
            }
        }

        private void readPriority(ByteBufferList byteBufferList, int i) {
            int i2 = byteBufferList.getInt();
            this.handler.priority(i, i2 & Integer.MAX_VALUE, (byteBufferList.get() & Base64.EQUALS_SIGN_ENC) + 1, (Integer.MIN_VALUE & i2) != 0);
        }

        /* access modifiers changed from: private */
        public void readPriority(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (s != 5) {
                throw Http20Draft13.ioException("TYPE_PRIORITY length: %d != 5", Short.valueOf(s));
            } else if (i != 0) {
                readPriority(byteBufferList, i);
            } else {
                throw Http20Draft13.ioException("TYPE_PRIORITY streamId == 0", new Object[0]);
            }
        }

        /* access modifiers changed from: private */
        public void readPushPromise(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (i != 0) {
                short s2 = (b2 & 8) != 0 ? (short) (byteBufferList.get() & Base64.EQUALS_SIGN_ENC) : 0;
                this.promisedStreamId = byteBufferList.getInt() & Integer.MAX_VALUE;
                short access$1600 = Http20Draft13.lengthWithoutPadding((short) (s - 4), b2, s2);
                this.pendingHeaderType = 5;
                readHeaderBlock(byteBufferList, access$1600, s2, b2, i);
                return;
            }
            throw Http20Draft13.ioException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
        }

        /* access modifiers changed from: private */
        public void readRstStream(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (s != 4) {
                throw Http20Draft13.ioException("TYPE_RST_STREAM length: %d != 4", Short.valueOf(s));
            } else if (i != 0) {
                int i2 = byteBufferList.getInt();
                ErrorCode fromHttp2 = ErrorCode.fromHttp2(i2);
                if (fromHttp2 != null) {
                    this.handler.rstStream(i, fromHttp2);
                } else {
                    throw Http20Draft13.ioException("TYPE_RST_STREAM unexpected error code: %d", Integer.valueOf(i2));
                }
            } else {
                throw Http20Draft13.ioException("TYPE_RST_STREAM streamId == 0", new Object[0]);
            }
        }

        /* access modifiers changed from: private */
        public void readSettings(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (i != 0) {
                throw Http20Draft13.ioException("TYPE_SETTINGS streamId != 0", new Object[0]);
            } else if ((b2 & 1) != 0) {
                if (s == 0) {
                    this.handler.ackSettings();
                    return;
                }
                throw Http20Draft13.ioException("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
            } else if (s % 6 == 0) {
                Settings settings = new Settings();
                for (int i2 = 0; i2 < s; i2 += 6) {
                    short s2 = byteBufferList.getShort();
                    int i3 = byteBufferList.getInt();
                    if (s2 != 1) {
                        if (s2 != 2) {
                            if (s2 == 3) {
                                s2 = 4;
                            } else if (s2 == 4) {
                                s2 = 7;
                                if (i3 < 0) {
                                    throw Http20Draft13.ioException("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
                                }
                            } else if (s2 != 5) {
                                throw Http20Draft13.ioException("PROTOCOL_ERROR invalid settings id: %s", Short.valueOf(s2));
                            }
                        } else if (!(i3 == 0 || i3 == 1)) {
                            throw Http20Draft13.ioException("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
                        }
                    }
                    settings.set(s2, 0, i3);
                }
                this.handler.settings(false, settings);
                if (settings.getHeaderTableSize() >= 0) {
                    this.hpackReader.maxHeaderTableByteCountSetting(settings.getHeaderTableSize());
                }
            } else {
                throw Http20Draft13.ioException("TYPE_SETTINGS length %% 6 != 0: %s", Short.valueOf(s));
            }
        }

        /* access modifiers changed from: private */
        public void readWindowUpdate(ByteBufferList byteBufferList, short s, byte b2, int i) {
            if (s == 4) {
                long j = ((long) byteBufferList.getInt()) & 2147483647L;
                if (j != 0) {
                    this.handler.windowUpdate(i, j);
                } else {
                    throw Http20Draft13.ioException("windowSizeIncrement was 0", Long.valueOf(j));
                }
            } else {
                throw Http20Draft13.ioException("TYPE_WINDOW_UPDATE length !=4: %s", Short.valueOf(s));
            }
        }
    }

    public static final class Writer implements FrameWriter {
        public final boolean client;
        public boolean closed;
        public final ByteBufferList frameHeader = new ByteBufferList();
        public final HpackDraft08.Writer hpackWriter;
        public final BufferedDataSink sink;

        public Writer(BufferedDataSink bufferedDataSink, boolean z) {
            this.sink = bufferedDataSink;
            this.client = z;
            this.hpackWriter = new HpackDraft08.Writer();
        }

        private void writeContinuationFrames(ByteBufferList byteBufferList, int i) {
            while (byteBufferList.hasRemaining()) {
                int min = Math.min(Http20Draft13.MAX_FRAME_SIZE, byteBufferList.remaining());
                frameHeader(i, min, (byte) 9, byteBufferList.remaining() - min == 0 ? (byte) 4 : 0);
                byteBufferList.get(this.frameHeader, min);
                this.sink.write(this.frameHeader);
            }
        }

        public synchronized void ackSettings() {
            if (!this.closed) {
                frameHeader(0, 0, (byte) 4, (byte) 1);
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void close() {
            this.closed = true;
        }

        public synchronized void connectionPreface() {
            if (this.closed) {
                throw new IOException("closed");
            } else if (this.client) {
                if (Http20Draft13.logger.isLoggable(Level.FINE)) {
                    Http20Draft13.logger.fine(String.format(Locale.ENGLISH, ">> CONNECTION %s", new Object[]{Http20Draft13.CONNECTION_PREFACE.hex()}));
                }
                this.sink.write(new ByteBufferList(Http20Draft13.CONNECTION_PREFACE.toByteArray()));
            }
        }

        public synchronized void data(boolean z, int i, ByteBufferList byteBufferList) {
            if (!this.closed) {
                byte b2 = 0;
                if (z) {
                    b2 = (byte) 1;
                }
                dataFrame(i, b2, byteBufferList);
            } else {
                throw new IOException("closed");
            }
        }

        public void dataFrame(int i, byte b2, ByteBufferList byteBufferList) {
            frameHeader(i, byteBufferList.remaining(), (byte) 0, b2);
            this.sink.write(byteBufferList);
        }

        public void frameHeader(int i, int i2, byte b2, byte b3) {
            if (Http20Draft13.logger.isLoggable(Level.FINE)) {
                Http20Draft13.logger.fine(FrameLogger.formatHeader(false, i, i2, b2, b3));
            }
            if (i2 > 16383) {
                throw Http20Draft13.illegalArgument("FRAME_SIZE_ERROR length > %d: %d", Integer.valueOf(Http20Draft13.MAX_FRAME_SIZE), Integer.valueOf(i2));
            } else if ((Integer.MIN_VALUE & i) == 0) {
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(((i2 & Http20Draft13.MAX_FRAME_SIZE) << 16) | ((b2 & Base64.EQUALS_SIGN_ENC) << 8) | (b3 & Base64.EQUALS_SIGN_ENC));
                order.putInt(i & Integer.MAX_VALUE);
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            } else {
                throw Http20Draft13.illegalArgument("reserved bit set: %s", Integer.valueOf(i));
            }
        }

        public synchronized void goAway(int i, ErrorCode errorCode, byte[] bArr) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.httpCode != -1) {
                frameHeader(0, bArr.length + 8, (byte) 7, (byte) 0);
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(i);
                order.putInt(errorCode.httpCode);
                order.put(bArr);
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            } else {
                throw Http20Draft13.illegalArgument("errorCode.httpCode == -1", new Object[0]);
            }
        }

        public synchronized void headers(int i, List<Header> list) {
            if (!this.closed) {
                headers(false, i, list);
            } else {
                throw new IOException("closed");
            }
        }

        public void headers(boolean z, int i, List<Header> list) {
            if (!this.closed) {
                ByteBufferList writeHeaders = this.hpackWriter.writeHeaders(list);
                long remaining = (long) writeHeaders.remaining();
                int min = (int) Math.min(16383, remaining);
                long j = (long) min;
                byte b2 = remaining == j ? (byte) 4 : 0;
                if (z) {
                    b2 = (byte) (b2 | 1);
                }
                frameHeader(i, min, (byte) 1, b2);
                writeHeaders.get(this.frameHeader, min);
                this.sink.write(this.frameHeader);
                if (remaining > j) {
                    writeContinuationFrames(writeHeaders, i);
                    return;
                }
                return;
            }
            throw new IOException("closed");
        }

        public synchronized void ping(boolean z, int i, int i2) {
            if (!this.closed) {
                frameHeader(0, 8, (byte) 6, z ? (byte) 1 : 0);
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(i);
                order.putInt(i2);
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void pushPromise(int i, int i2, List<Header> list) {
            if (!this.closed) {
                ByteBufferList writeHeaders = this.hpackWriter.writeHeaders(list);
                long remaining = (long) writeHeaders.remaining();
                int min = (int) Math.min(16379, remaining);
                long j = (long) min;
                frameHeader(i, min + 4, (byte) 5, remaining == j ? (byte) 4 : 0);
                ByteBuffer order = ByteBufferList.obtain(8192).order(ByteOrder.BIG_ENDIAN);
                order.putInt(i2 & Integer.MAX_VALUE);
                order.flip();
                this.frameHeader.add(order);
                writeHeaders.get(this.frameHeader, min);
                this.sink.write(this.frameHeader);
                if (remaining > j) {
                    writeContinuationFrames(writeHeaders, i);
                }
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void rstStream(int i, ErrorCode errorCode) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.spdyRstCode != -1) {
                frameHeader(i, 4, (byte) 3, (byte) 0);
                ByteBuffer order = ByteBufferList.obtain(8192).order(ByteOrder.BIG_ENDIAN);
                order.putInt(errorCode.httpCode);
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            } else {
                throw new IllegalArgumentException();
            }
        }

        public synchronized void settings(Settings settings) {
            if (!this.closed) {
                int i = 0;
                frameHeader(0, settings.size() * 6, (byte) 4, (byte) 0);
                ByteBuffer order = ByteBufferList.obtain(8192).order(ByteOrder.BIG_ENDIAN);
                while (i < 10) {
                    if (settings.isSet(i)) {
                        order.putShort((short) (i == 4 ? 3 : i == 7 ? 4 : i));
                        order.putInt(settings.get(i));
                    }
                    i++;
                }
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synReply(boolean z, int i, List<Header> list) {
            if (!this.closed) {
                headers(z, i, list);
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synStream(boolean z, boolean z2, int i, int i2, List<Header> list) {
            if (!z2) {
                try {
                    if (!this.closed) {
                        headers(z, i, list);
                    } else {
                        throw new IOException("closed");
                    }
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                throw new UnsupportedOperationException();
            }
        }

        public synchronized void windowUpdate(int i, long j) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (j == 0 || j > 2147483647L) {
                throw Http20Draft13.illegalArgument("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", Long.valueOf(j));
            } else {
                frameHeader(i, 4, (byte) 8, (byte) 0);
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt((int) j);
                order.flip();
                this.sink.write(this.frameHeader.add(order));
            }
        }
    }

    public static IllegalArgumentException illegalArgument(String str, Object... objArr) {
        throw new IllegalArgumentException(String.format(Locale.ENGLISH, str, objArr));
    }

    public static IOException ioException(String str, Object... objArr) {
        throw new IOException(String.format(Locale.ENGLISH, str, objArr));
    }

    public static short lengthWithoutPadding(short s, byte b2, short s2) {
        if ((b2 & 8) != 0) {
            s = (short) (s - 1);
        }
        if (s2 <= s) {
            return (short) (s - s2);
        }
        throw ioException("PROTOCOL_ERROR padding %s > remaining length %s", Short.valueOf(s2), Short.valueOf(s));
    }

    public Protocol getProtocol() {
        return Protocol.HTTP_2;
    }

    public int maxFrameSize() {
        return MAX_FRAME_SIZE;
    }

    public FrameReader newReader(DataEmitter dataEmitter, FrameReader.Handler handler, boolean z) {
        return new Reader(dataEmitter, handler, 4096, z);
    }

    public FrameWriter newWriter(BufferedDataSink bufferedDataSink, boolean z) {
        return new Writer(bufferedDataSink, z);
    }
}
