package io.lum.sdk.async.http.callback;

import io.lum.sdk.async.callback.ResultCallback;
import io.lum.sdk.async.http.AsyncHttpResponse;

public interface RequestCallback<T> extends ResultCallback<AsyncHttpResponse, T> {
    void onConnect(AsyncHttpResponse asyncHttpResponse);

    void onProgress(AsyncHttpResponse asyncHttpResponse, long j, long j2);
}
