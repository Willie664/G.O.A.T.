package io.lum.sdk.async.http;

import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.http.filter.ChunkedOutputFilter;

public class HttpTransportMiddleware extends SimpleMiddleware {
    public static boolean responseIsEmpty(int i) {
        return (i >= 100 && i <= 199) || i == 204 || i == 304;
    }

    /* JADX WARNING: type inference failed for: r5v1, types: [io.lum.sdk.async.AsyncSocket] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean exchangeHeaders(final io.lum.sdk.async.http.AsyncHttpClientMiddleware.OnExchangeHeaderData r10) {
        /*
            r9 = this;
            java.lang.String r0 = r10.protocol
            io.lum.sdk.async.http.Protocol r0 = io.lum.sdk.async.http.Protocol.get(r0)
            if (r0 == 0) goto L_0x0015
            io.lum.sdk.async.http.Protocol r1 = io.lum.sdk.async.http.Protocol.HTTP_1_0
            if (r0 == r1) goto L_0x0015
            io.lum.sdk.async.http.Protocol r1 = io.lum.sdk.async.http.Protocol.HTTP_1_1
            if (r0 == r1) goto L_0x0015
            boolean r10 = super.exchangeHeaders(r10)
            return r10
        L_0x0015:
            io.lum.sdk.async.http.AsyncHttpRequest r0 = r10.request
            io.lum.sdk.async.http.body.AsyncHttpRequestBody r1 = r0.getBody()
            if (r1 == 0) goto L_0x0064
            int r2 = r1.length()
            if (r2 < 0) goto L_0x003c
            io.lum.sdk.async.http.Headers r2 = r0.getHeaders()
            int r3 = r1.length()
            java.lang.String r3 = java.lang.String.valueOf(r3)
            java.lang.String r4 = "Content-Length"
            r2.set(r4, r3)
        L_0x0034:
            io.lum.sdk.async.http.AsyncHttpClientMiddleware$ResponseHead r2 = r10.response
            io.lum.sdk.async.AsyncSocket r3 = r10.socket
        L_0x0038:
            r2.sink(r3)
            goto L_0x0064
        L_0x003c:
            io.lum.sdk.async.http.Headers r2 = r0.getHeaders()
            java.lang.String r3 = "Connection"
            java.lang.String r2 = r2.get(r3)
            java.lang.String r3 = "close"
            boolean r2 = r3.equals(r2)
            if (r2 == 0) goto L_0x004f
            goto L_0x0034
        L_0x004f:
            io.lum.sdk.async.http.Headers r2 = r0.getHeaders()
            java.lang.String r3 = "Transfer-Encoding"
            java.lang.String r4 = "Chunked"
            r2.set(r3, r4)
            io.lum.sdk.async.http.AsyncHttpClientMiddleware$ResponseHead r2 = r10.response
            io.lum.sdk.async.http.filter.ChunkedOutputFilter r3 = new io.lum.sdk.async.http.filter.ChunkedOutputFilter
            io.lum.sdk.async.AsyncSocket r4 = r10.socket
            r3.<init>(r4)
            goto L_0x0038
        L_0x0064:
            io.lum.sdk.async.http.RequestLine r2 = r0.getRequestLine()
            java.lang.String r2 = r2.toString()
            io.lum.sdk.async.http.Headers r3 = r0.getHeaders()
            java.lang.String r2 = r3.toPrefixString(r2)
            byte[] r3 = r2.getBytes()
            r4 = 1
            if (r1 == 0) goto L_0x008d
            int r5 = r1.length()
            if (r5 < 0) goto L_0x008d
            int r1 = r1.length()
            int r5 = r3.length
            int r1 = r1 + r5
            r5 = 1024(0x400, float:1.435E-42)
            if (r1 >= r5) goto L_0x008d
            r1 = 1
            goto L_0x008e
        L_0x008d:
            r1 = 0
        L_0x008e:
            if (r1 == 0) goto L_0x00a5
            io.lum.sdk.async.BufferedDataSink r1 = new io.lum.sdk.async.BufferedDataSink
            io.lum.sdk.async.http.AsyncHttpClientMiddleware$ResponseHead r5 = r10.response
            io.lum.sdk.async.DataSink r5 = r5.sink()
            r1.<init>(r5)
            r1.forceBuffering(r4)
            io.lum.sdk.async.http.AsyncHttpClientMiddleware$ResponseHead r5 = r10.response
            r5.sink(r1)
            r5 = r1
            goto L_0x00ab
        L_0x00a5:
            r1 = 0
            io.lum.sdk.async.AsyncSocket r5 = r10.socket
            r8 = r5
            r5 = r1
            r1 = r8
        L_0x00ab:
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "\n"
            r6.append(r7)
            r6.append(r2)
            java.lang.String r2 = r6.toString()
            r0.logv(r2)
            io.lum.sdk.async.callback.CompletedCallback r0 = r10.sendHeadersCallback
            io.lum.sdk.async.http.HttpTransportMiddleware$1 r2 = new io.lum.sdk.async.http.HttpTransportMiddleware$1
            r2.<init>(r0, r5)
            io.lum.sdk.async.Util.writeAll((io.lum.sdk.async.DataSink) r1, (byte[]) r3, (io.lum.sdk.async.callback.CompletedCallback) r2)
            io.lum.sdk.async.http.HttpTransportMiddleware$2 r0 = new io.lum.sdk.async.http.HttpTransportMiddleware$2
            r0.<init>(r10)
            io.lum.sdk.async.LineEmitter r1 = new io.lum.sdk.async.LineEmitter
            r1.<init>()
            io.lum.sdk.async.AsyncSocket r10 = r10.socket
            r10.setDataCallback(r1)
            r1.setLineCallback(r0)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.HttpTransportMiddleware.exchangeHeaders(io.lum.sdk.async.http.AsyncHttpClientMiddleware$OnExchangeHeaderData):boolean");
    }

    public void onRequestSent(AsyncHttpClientMiddleware.OnRequestSentData onRequestSentData) {
        Protocol protocol = Protocol.get(onRequestSentData.protocol);
        if ((protocol == null || protocol == Protocol.HTTP_1_0 || protocol == Protocol.HTTP_1_1) && (onRequestSentData.response.sink() instanceof ChunkedOutputFilter)) {
            onRequestSentData.response.sink().end();
        }
    }
}
