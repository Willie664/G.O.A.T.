package io.lum.sdk.async.http.server;

import android.content.Context;
import android.content.res.AssetManager;
import android.text.TextUtils;
import d.a.a.b2.v.r.i;
import d.a.a.b2.v.r.j;
import d.a.a.b2.v.r.k;
import d.a.a.b2.v.r.l;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.SimpleFuture;
import io.lum.sdk.async.http.AsyncHttpGet;
import io.lum.sdk.async.http.AsyncHttpHead;
import io.lum.sdk.async.http.AsyncHttpPost;
import io.lum.sdk.async.http.WebSocket;
import io.lum.sdk.async.http.WebSocketImpl;
import io.lum.sdk.async.http.body.StringBody;
import io.lum.sdk.async.http.server.AsyncHttpServer;
import io.lum.sdk.async.util.StreamUtility;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;

public class AsyncHttpServerRouter implements RouteMatcher {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static Hashtable<String, Future<Manifest>> AppManifests = new Hashtable<>();
    public static Hashtable<String, String> mContentTypes = new Hashtable<>();
    public Callback callback;
    public final ArrayList<RouteInfo> routes = new ArrayList<>();

    public static class Asset {
        public int available;
        public InputStream inputStream;
        public String path;

        public Asset(int i, InputStream inputStream2, String str) {
            this.available = i;
            this.inputStream = inputStream2;
            this.path = str;
        }
    }

    public abstract class AsyncHttpServerRequestImpl extends AsyncHttpServerRequestImpl {
        public Matcher matcher;

        public AsyncHttpServerRequestImpl() {
        }

        public Matcher getMatcher() {
            return this.matcher;
        }

        public void setMatcher(Matcher matcher2) {
            this.matcher = matcher2;
        }
    }

    public class Callback implements HttpServerRequestCallback, RouteMatcher {
        public Callback() {
        }

        public void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
            RouteMatch route = route(asyncHttpServerRequest.getMethod(), asyncHttpServerRequest.getPath());
            if (route == null) {
                asyncHttpServerResponse.code(404);
                asyncHttpServerResponse.end();
                return;
            }
            route.callback.onRequest(asyncHttpServerRequest, asyncHttpServerResponse);
        }

        public RouteMatch route(String str, String str2) {
            return AsyncHttpServerRouter.this.route(str, str2);
        }
    }

    public static class RouteInfo {
        public AsyncHttpRequestBodyProvider bodyCallback;
        public HttpServerRequestCallback callback;
        public String method;
        public Pattern regex;

        public RouteInfo() {
        }
    }

    public static class RouteMatch {
        public final AsyncHttpRequestBodyProvider bodyCallback;
        public final HttpServerRequestCallback callback;
        public final Matcher matcher;
        public final String method;
        public final String path;

        public RouteMatch(String str, String str2, Matcher matcher2, HttpServerRequestCallback httpServerRequestCallback, AsyncHttpRequestBodyProvider asyncHttpRequestBodyProvider) {
            this.method = str;
            this.path = str2;
            this.matcher = matcher2;
            this.callback = httpServerRequestCallback;
            this.bodyCallback = asyncHttpRequestBodyProvider;
        }
    }

    public AsyncHttpServerRouter() {
        mContentTypes.put("js", "application/javascript");
        mContentTypes.put("json", "application/json");
        mContentTypes.put("png", "image/png");
        mContentTypes.put("jpg", "image/jpeg");
        mContentTypes.put("jpeg", "image/jpeg");
        mContentTypes.put("html", "text/html");
        mContentTypes.put("css", "text/css");
        mContentTypes.put("mp4", "video/mp4");
        mContentTypes.put("mov", "video/quicktime");
        mContentTypes.put("wmv", "video/x-ms-wmv");
        mContentTypes.put("txt", StringBody.CONTENT_TYPE);
        this.callback = new Callback();
    }

    public static /* synthetic */ void a(AssetManager assetManager, String str, Context context, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        String replaceAll = asyncHttpServerRequest.getMatcher().replaceAll("");
        Asset assetStream = getAssetStream(assetManager, str + replaceAll);
        if (assetStream == null || assetStream.inputStream == null) {
            asyncHttpServerResponse.code(404);
            asyncHttpServerResponse.end();
        } else if (isClientCached(context, asyncHttpServerRequest, asyncHttpServerResponse, assetStream.path)) {
            StreamUtility.closeQuietly(assetStream.inputStream);
            asyncHttpServerResponse.code(304);
            asyncHttpServerResponse.end();
        } else {
            asyncHttpServerResponse.getHeaders().set("Content-Length", String.valueOf(assetStream.available));
            asyncHttpServerResponse.getHeaders().add("Content-Type", getContentType(assetStream.path));
            asyncHttpServerResponse.code(200);
            Util.pump(assetStream.inputStream, (long) assetStream.available, asyncHttpServerResponse, new i(asyncHttpServerResponse, assetStream));
        }
    }

    public static /* synthetic */ void a(AsyncHttpServerResponse asyncHttpServerResponse, Asset asset, Exception exc) {
        asyncHttpServerResponse.end();
        StreamUtility.closeQuietly(asset.inputStream);
    }

    public static /* synthetic */ void a(String str, AsyncHttpServer.WebSocketRequestCallback webSocketRequestCallback, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        WebSocket checkWebSocketUpgrade = checkWebSocketUpgrade(str, asyncHttpServerRequest, asyncHttpServerResponse);
        if (checkWebSocketUpgrade == null) {
            asyncHttpServerResponse.code(404);
            asyncHttpServerResponse.end();
            return;
        }
        webSocketRequestCallback.onConnected(checkWebSocketUpgrade, asyncHttpServerRequest);
    }

    public static /* synthetic */ void b(AssetManager assetManager, String str, Context context, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        InputStream inputStream;
        int i;
        String replaceAll = asyncHttpServerRequest.getMatcher().replaceAll("");
        Asset assetStream = getAssetStream(assetManager, str + replaceAll);
        if (assetStream == null || (inputStream = assetStream.inputStream) == null) {
            asyncHttpServerResponse.code(404);
            asyncHttpServerResponse.end();
            return;
        }
        StreamUtility.closeQuietly(inputStream);
        if (isClientCached(context, asyncHttpServerRequest, asyncHttpServerResponse, assetStream.path)) {
            i = 304;
        } else {
            asyncHttpServerResponse.getHeaders().set("Content-Length", String.valueOf(assetStream.available));
            asyncHttpServerResponse.getHeaders().add("Content-Type", getContentType(assetStream.path));
            i = 200;
        }
        asyncHttpServerResponse.code(i);
        asyncHttpServerResponse.end();
    }

    public static WebSocket checkWebSocketUpgrade(String str, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        String str2 = asyncHttpServerRequest.getHeaders().get("Connection");
        boolean z = false;
        if (str2 != null) {
            String[] split = str2.split(",");
            int length = split.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    break;
                } else if ("Upgrade".equalsIgnoreCase(split[i].trim())) {
                    z = true;
                    break;
                } else {
                    i++;
                }
            }
        }
        if (!"websocket".equalsIgnoreCase(asyncHttpServerRequest.getHeaders().get("Upgrade")) || !z || !TextUtils.equals(str, asyncHttpServerRequest.getHeaders().get("Sec-WebSocket-Protocol"))) {
            return null;
        }
        return new WebSocketImpl(asyncHttpServerRequest, asyncHttpServerResponse);
    }

    public static synchronized Manifest ensureManifest(Context context) {
        ZipFile zipFile;
        synchronized (AsyncHttpServerRouter.class) {
            Future future = AppManifests.get(context.getPackageName());
            if (future != null) {
                Manifest manifest = (Manifest) future.tryGet();
                return manifest;
            }
            SimpleFuture simpleFuture = new SimpleFuture();
            try {
                zipFile = new ZipFile(context.getPackageResourcePath());
                try {
                    Manifest manifest2 = new Manifest(zipFile.getInputStream(zipFile.getEntry("META-INF/MANIFEST.MF")));
                    simpleFuture.setComplete(manifest2);
                    StreamUtility.closeQuietly(zipFile);
                    AppManifests.put(context.getPackageName(), simpleFuture);
                    return manifest2;
                } catch (Exception e2) {
                    e = e2;
                    try {
                        simpleFuture.setComplete(e);
                        StreamUtility.closeQuietly(zipFile);
                        AppManifests.put(context.getPackageName(), simpleFuture);
                        return null;
                    } catch (Throwable th) {
                        th = th;
                        StreamUtility.closeQuietly(zipFile);
                        AppManifests.put(context.getPackageName(), simpleFuture);
                        throw th;
                    }
                }
            } catch (Exception e3) {
                e = e3;
                zipFile = null;
                simpleFuture.setComplete(e);
                StreamUtility.closeQuietly(zipFile);
                AppManifests.put(context.getPackageName(), simpleFuture);
                return null;
            } catch (Throwable th2) {
                Throwable th3 = th2;
                zipFile = null;
                th = th3;
                StreamUtility.closeQuietly(zipFile);
                AppManifests.put(context.getPackageName(), simpleFuture);
                throw th;
            }
        }
    }

    public static Asset getAssetStream(Context context, String str) {
        return getAssetStream(context.getAssets(), str);
    }

    public static Asset getAssetStream(AssetManager assetManager, String str) {
        try {
            InputStream open = assetManager.open(str);
            return new Asset(open.available(), open, str);
        } catch (IOException unused) {
            String[] strArr = {"/index.htm", "/index.html", "index.htm", "index.html", ".htm", ".html"};
            int i = 0;
            while (i < 6) {
                String str2 = strArr[i];
                try {
                    InputStream open2 = assetManager.open(str + str2);
                    int available = open2.available();
                    return new Asset(available, open2, str + str2);
                } catch (IOException unused2) {
                    i++;
                }
            }
            return null;
        }
    }

    public static String getContentType(String str) {
        return tryGetContentType(str);
    }

    public static boolean isClientCached(Context context, AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse, String str) {
        Manifest ensureManifest = ensureManifest(context);
        if (ensureManifest == null) {
            return false;
        }
        try {
            Map<String, Attributes> entries = ensureManifest.getEntries();
            String value = entries.get("assets/" + str).getValue("SHA-256-Digest");
            if (TextUtils.isEmpty(value)) {
                return false;
            }
            String format = String.format("\"%s\"", new Object[]{value});
            asyncHttpServerResponse.getHeaders().set("ETag", format);
            return TextUtils.equals(asyncHttpServerRequest.getHeaders().get("If-None-Match"), format);
        } catch (Exception unused) {
            return false;
        }
    }

    public static String tryGetContentType(String str) {
        String str2;
        int lastIndexOf = str.lastIndexOf(".");
        if (lastIndexOf == -1 || (str2 = mContentTypes.get(str.substring(lastIndexOf + 1))) == null) {
            return null;
        }
        return str2;
    }

    public void addAction(String str, String str2, HttpServerRequestCallback httpServerRequestCallback) {
        addAction(str, str2, httpServerRequestCallback, (AsyncHttpRequestBodyProvider) null);
    }

    public void addAction(String str, String str2, HttpServerRequestCallback httpServerRequestCallback, AsyncHttpRequestBodyProvider asyncHttpRequestBodyProvider) {
        RouteInfo routeInfo = new RouteInfo();
        routeInfo.regex = Pattern.compile("^" + str2);
        routeInfo.callback = httpServerRequestCallback;
        routeInfo.method = str;
        routeInfo.bodyCallback = asyncHttpRequestBodyProvider;
        synchronized (this.routes) {
            this.routes.add(routeInfo);
        }
    }

    public void directory(Context context, String str, String str2) {
        AssetManager assets = context.getAssets();
        addAction(AsyncHttpGet.METHOD, str, new k(assets, str2, context));
        addAction(AsyncHttpHead.METHOD, str, new j(assets, str2, context));
    }

    public void directory(String str, File file) {
        directory(str, file, false);
    }

    public void directory(String str, final File file, final boolean z) {
        addAction(AsyncHttpGet.METHOD, str, new HttpServerRequestCallback() {
            public void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, final AsyncHttpServerResponse asyncHttpServerResponse) {
                File file = new File(file, asyncHttpServerRequest.getMatcher().replaceAll(""));
                if (file.isDirectory() && z) {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (File file2 : file.listFiles()) {
                        if (file2.isDirectory()) {
                            arrayList.add(file2);
                        } else {
                            arrayList2.add(file2);
                        }
                    }
                    AnonymousClass1 r1 = new Comparator<File>() {
                        public int compare(File file, File file2) {
                            return file.getName().compareTo(file2.getName());
                        }
                    };
                    Collections.sort(arrayList, r1);
                    Collections.sort(arrayList2, r1);
                    arrayList2.addAll(0, arrayList);
                    StringBuilder sb = new StringBuilder();
                    Iterator it = arrayList2.iterator();
                    while (it.hasNext()) {
                        File file3 = (File) it.next();
                        sb.append(String.format("<div><a href='%s'>%s</a></div>", new Object[]{new File(asyncHttpServerRequest.getPath(), file3.getName()).getAbsolutePath(), file3.getName()}));
                    }
                    asyncHttpServerResponse.send(sb.toString());
                } else if (!file.isFile()) {
                    asyncHttpServerResponse.code(404);
                    asyncHttpServerResponse.end();
                } else {
                    try {
                        FileInputStream fileInputStream = new FileInputStream(file);
                        asyncHttpServerResponse.code(200);
                        Util.pump(fileInputStream, (long) fileInputStream.available(), asyncHttpServerResponse, new CompletedCallback() {
                            public void onCompleted(Exception exc) {
                                asyncHttpServerResponse.end();
                            }
                        });
                    } catch (IOException unused) {
                        asyncHttpServerResponse.code(404);
                        asyncHttpServerResponse.end();
                    }
                }
            }
        });
    }

    public void get(String str, HttpServerRequestCallback httpServerRequestCallback) {
        addAction(AsyncHttpGet.METHOD, str, httpServerRequestCallback);
    }

    public HttpServerRequestCallback getCallback() {
        return this.callback;
    }

    public void post(String str, HttpServerRequestCallback httpServerRequestCallback) {
        addAction(AsyncHttpPost.METHOD, str, httpServerRequestCallback);
    }

    public void removeAction(String str, String str2) {
        int i = 0;
        while (i < this.routes.size()) {
            RouteInfo routeInfo = this.routes.get(i);
            if (!TextUtils.equals(routeInfo.method, str) || !str2.equals(routeInfo.regex.toString())) {
                i++;
            } else {
                this.routes.remove(i);
                return;
            }
        }
    }

    public RouteMatch route(String str, String str2) {
        synchronized (this.routes) {
            Iterator<RouteInfo> it = this.routes.iterator();
            while (it.hasNext()) {
                RouteInfo next = it.next();
                if (TextUtils.equals(str, next.method) || next.method == null) {
                    Matcher matcher = next.regex.matcher(str2);
                    if (matcher.matches()) {
                        if (next.callback instanceof RouteMatcher) {
                            RouteMatch route = ((RouteMatcher) next.callback).route(str, matcher.group(1));
                            return route;
                        }
                        RouteMatch routeMatch = new RouteMatch(str, str2, matcher, next.callback, next.bodyCallback);
                        return routeMatch;
                    }
                }
            }
            return null;
        }
    }

    public void websocket(String str, AsyncHttpServer.WebSocketRequestCallback webSocketRequestCallback) {
        websocket(str, (String) null, webSocketRequestCallback);
    }

    public void websocket(String str, String str2, AsyncHttpServer.WebSocketRequestCallback webSocketRequestCallback) {
        get(str, new l(str2, webSocketRequestCallback));
    }
}
