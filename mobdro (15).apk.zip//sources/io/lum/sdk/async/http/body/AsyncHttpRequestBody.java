package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;

public interface AsyncHttpRequestBody<T> {
    T get();

    String getContentType();

    int length();

    void parse(DataEmitter dataEmitter, CompletedCallback completedCallback);

    boolean readFullyOnRequest();

    void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback);
}
