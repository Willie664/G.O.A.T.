package io.lum.sdk.async.http.cache;

import android.net.Uri;
import io.lum.sdk.async.http.HttpDate;
import io.lum.sdk.async.http.cache.HeaderParser;
import java.util.Date;
import java.util.List;
import java.util.Map;

public final class RequestHeaders {
    public String acceptEncoding;
    public String connection;
    public int contentLength = -1;
    public String contentType;
    public boolean hasAuthorization;
    public final RawHeaders headers;
    public String host;
    public String ifModifiedSince;
    public String ifNoneMatch;
    public int maxAgeSeconds = -1;
    public int maxStaleSeconds = -1;
    public int minFreshSeconds = -1;
    public boolean noCache;
    public boolean onlyIfCached;
    public String proxyAuthorization;
    public String transferEncoding;
    public final Uri uri;
    public String userAgent;

    public RequestHeaders(Uri uri2, RawHeaders rawHeaders) {
        this.uri = uri2;
        this.headers = rawHeaders;
        AnonymousClass1 r6 = new HeaderParser.CacheControlHandler() {
            public void handle(String str, String str2) {
                if (str.equalsIgnoreCase("no-cache")) {
                    boolean unused = RequestHeaders.this.noCache = true;
                } else if (str.equalsIgnoreCase("max-age")) {
                    int unused2 = RequestHeaders.this.maxAgeSeconds = HeaderParser.parseSeconds(str2);
                } else if (str.equalsIgnoreCase("max-stale")) {
                    int unused3 = RequestHeaders.this.maxStaleSeconds = HeaderParser.parseSeconds(str2);
                } else if (str.equalsIgnoreCase("min-fresh")) {
                    int unused4 = RequestHeaders.this.minFreshSeconds = HeaderParser.parseSeconds(str2);
                } else if (str.equalsIgnoreCase("only-if-cached")) {
                    boolean unused5 = RequestHeaders.this.onlyIfCached = true;
                }
            }
        };
        for (int i = 0; i < rawHeaders.length(); i++) {
            String fieldName = rawHeaders.getFieldName(i);
            String value = rawHeaders.getValue(i);
            if ("Cache-Control".equalsIgnoreCase(fieldName)) {
                HeaderParser.parseCacheControl(value, r6);
            } else if ("Pragma".equalsIgnoreCase(fieldName)) {
                if (value.equalsIgnoreCase("no-cache")) {
                    this.noCache = true;
                }
            } else if ("If-None-Match".equalsIgnoreCase(fieldName)) {
                this.ifNoneMatch = value;
            } else if ("If-Modified-Since".equalsIgnoreCase(fieldName)) {
                this.ifModifiedSince = value;
            } else if ("Authorization".equalsIgnoreCase(fieldName)) {
                this.hasAuthorization = true;
            } else if ("Content-Length".equalsIgnoreCase(fieldName)) {
                try {
                    this.contentLength = Integer.parseInt(value);
                } catch (NumberFormatException unused) {
                }
            } else if ("Transfer-Encoding".equalsIgnoreCase(fieldName)) {
                this.transferEncoding = value;
            } else if ("User-Agent".equalsIgnoreCase(fieldName)) {
                this.userAgent = value;
            } else if ("Host".equalsIgnoreCase(fieldName)) {
                this.host = value;
            } else if ("Connection".equalsIgnoreCase(fieldName)) {
                this.connection = value;
            } else if ("Accept-Encoding".equalsIgnoreCase(fieldName)) {
                this.acceptEncoding = value;
            } else if ("Content-Type".equalsIgnoreCase(fieldName)) {
                this.contentType = value;
            } else if ("Proxy-Authorization".equalsIgnoreCase(fieldName)) {
                this.proxyAuthorization = value;
            }
        }
    }

    public void addCookies(Map<String, List<String>> map) {
        for (Map.Entry next : map.entrySet()) {
            String str = (String) next.getKey();
            if ("Cookie".equalsIgnoreCase(str) || "Cookie2".equalsIgnoreCase(str)) {
                this.headers.addAll(str, (List) next.getValue());
            }
        }
    }

    public String getAcceptEncoding() {
        return this.acceptEncoding;
    }

    public String getConnection() {
        return this.connection;
    }

    public int getContentLength() {
        return this.contentLength;
    }

    public String getContentType() {
        return this.contentType;
    }

    public RawHeaders getHeaders() {
        return this.headers;
    }

    public String getHost() {
        return this.host;
    }

    public String getIfModifiedSince() {
        return this.ifModifiedSince;
    }

    public String getIfNoneMatch() {
        return this.ifNoneMatch;
    }

    public int getMaxAgeSeconds() {
        return this.maxAgeSeconds;
    }

    public int getMaxStaleSeconds() {
        return this.maxStaleSeconds;
    }

    public int getMinFreshSeconds() {
        return this.minFreshSeconds;
    }

    public String getProxyAuthorization() {
        return this.proxyAuthorization;
    }

    public String getTransferEncoding() {
        return this.transferEncoding;
    }

    public Uri getUri() {
        return this.uri;
    }

    public String getUserAgent() {
        return this.userAgent;
    }

    public boolean hasAuthorization() {
        return this.hasAuthorization;
    }

    public boolean hasConditions() {
        return (this.ifModifiedSince == null && this.ifNoneMatch == null) ? false : true;
    }

    public boolean hasConnectionClose() {
        return "close".equalsIgnoreCase(this.connection);
    }

    public boolean isChunked() {
        return "chunked".equalsIgnoreCase(this.transferEncoding);
    }

    public boolean isNoCache() {
        return this.noCache;
    }

    public boolean isOnlyIfCached() {
        return this.onlyIfCached;
    }

    public void setAcceptEncoding(String str) {
        if (this.acceptEncoding != null) {
            this.headers.removeAll("Accept-Encoding");
        }
        this.headers.add("Accept-Encoding", str);
        this.acceptEncoding = str;
    }

    public void setChunked() {
        if (this.transferEncoding != null) {
            this.headers.removeAll("Transfer-Encoding");
        }
        this.headers.add("Transfer-Encoding", "chunked");
        this.transferEncoding = "chunked";
    }

    public void setConnection(String str) {
        if (this.connection != null) {
            this.headers.removeAll("Connection");
        }
        this.headers.add("Connection", str);
        this.connection = str;
    }

    public void setContentLength(int i) {
        if (this.contentLength != -1) {
            this.headers.removeAll("Content-Length");
        }
        if (i != -1) {
            this.headers.add("Content-Length", Integer.toString(i));
        }
        this.contentLength = i;
    }

    public void setContentType(String str) {
        if (this.contentType != null) {
            this.headers.removeAll("Content-Type");
        }
        this.headers.add("Content-Type", str);
        this.contentType = str;
    }

    public void setHost(String str) {
        if (this.host != null) {
            this.headers.removeAll("Host");
        }
        this.headers.add("Host", str);
        this.host = str;
    }

    public void setIfModifiedSince(Date date) {
        if (this.ifModifiedSince != null) {
            this.headers.removeAll("If-Modified-Since");
        }
        String format = HttpDate.format(date);
        this.headers.add("If-Modified-Since", format);
        this.ifModifiedSince = format;
    }

    public void setIfNoneMatch(String str) {
        if (this.ifNoneMatch != null) {
            this.headers.removeAll("If-None-Match");
        }
        this.headers.add("If-None-Match", str);
        this.ifNoneMatch = str;
    }

    public void setUserAgent(String str) {
        if (this.userAgent != null) {
            this.headers.removeAll("User-Agent");
        }
        this.headers.add("User-Agent", str);
        this.userAgent = str;
    }
}
