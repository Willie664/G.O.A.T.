package io.lum.sdk.async.http.server;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;
import java.nio.ByteBuffer;

public class BoundaryEmitter extends FilteredDataEmitter {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public byte[] boundary;
    public int state = 2;

    public String getBoundary() {
        if (this.boundary == null) {
            return null;
        }
        byte[] bArr = this.boundary;
        return new String(bArr, 4, bArr.length - 4);
    }

    public String getBoundaryEnd() {
        return getBoundaryStart() + "--\r\n";
    }

    public String getBoundaryStart() {
        byte[] bArr = this.boundary;
        return new String(bArr, 2, bArr.length - 2);
    }

    public void onBoundaryEnd() {
    }

    public void onBoundaryStart() {
    }

    public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        MimeEncodingException mimeEncodingException;
        MimeEncodingException mimeEncodingException2;
        if (this.state > 0) {
            ByteBuffer obtain = ByteBufferList.obtain(this.boundary.length);
            obtain.put(this.boundary, 0, this.state);
            obtain.flip();
            byteBufferList.addFirst(obtain);
            this.state = 0;
        }
        int remaining = byteBufferList.remaining();
        byte[] bArr = new byte[remaining];
        byteBufferList.get(bArr);
        int i = 0;
        int i2 = 0;
        while (i < remaining) {
            int i3 = this.state;
            int i4 = -1;
            if (i3 >= 0) {
                byte b2 = bArr[i];
                byte[] bArr2 = this.boundary;
                if (b2 == bArr2[i3]) {
                    int i5 = i3 + 1;
                    this.state = i5;
                    if (i5 != bArr2.length) {
                    }
                } else if (i3 > 0) {
                    i -= i3;
                    this.state = 0;
                }
                i++;
            } else {
                if (i3 == -1) {
                    if (bArr[i] == 13) {
                        this.state = -4;
                        int length = (i - i2) - this.boundary.length;
                        if (!(i2 == 0 && length == 0)) {
                            ByteBuffer put = ByteBufferList.obtain(length).put(bArr, i2, length);
                            put.flip();
                            ByteBufferList byteBufferList2 = new ByteBufferList();
                            byteBufferList2.add(put);
                            super.onDataAvailable(this, byteBufferList2);
                        }
                        onBoundaryStart();
                    } else if (bArr[i] == 45) {
                        this.state = -2;
                    } else {
                        mimeEncodingException2 = new MimeEncodingException("Invalid multipart/form-data. Expected \r or -");
                    }
                    i++;
                } else {
                    i4 = -3;
                    if (i3 != -2) {
                        if (i3 != -3) {
                            if (i3 != -4) {
                                mimeEncodingException = new MimeEncodingException("Invalid multipart/form-data. Unknown state?");
                            } else if (bArr[i] == 10) {
                                i2 = i + 1;
                                this.state = 0;
                            } else {
                                mimeEncodingException = new MimeEncodingException("Invalid multipart/form-data. Expected \n");
                            }
                            report(mimeEncodingException);
                        } else if (bArr[i] == 13) {
                            this.state = -4;
                            int i6 = i - i2;
                            ByteBuffer put2 = ByteBufferList.obtain((i6 - this.boundary.length) - 2).put(bArr, i2, (i6 - this.boundary.length) - 2);
                            put2.flip();
                            ByteBufferList byteBufferList3 = new ByteBufferList();
                            byteBufferList3.add(put2);
                            super.onDataAvailable(this, byteBufferList3);
                            onBoundaryEnd();
                        } else {
                            mimeEncodingException2 = new MimeEncodingException("Invalid multipart/form-data. Expected \r");
                        }
                        i++;
                    } else if (bArr[i] != 45) {
                        mimeEncodingException2 = new MimeEncodingException("Invalid multipart/form-data. Expected -");
                    }
                }
                report(mimeEncodingException2);
                return;
            }
            this.state = i4;
            i++;
        }
        if (i2 < remaining) {
            int max = (remaining - i2) - Math.max(this.state, 0);
            ByteBuffer put3 = ByteBufferList.obtain(max).put(bArr, i2, max);
            put3.flip();
            ByteBufferList byteBufferList4 = new ByteBufferList();
            byteBufferList4.add(put3);
            super.onDataAvailable(this, byteBufferList4);
        }
    }

    public void setBoundary(String str) {
        this.boundary = ("\r\n--" + str).getBytes();
    }
}
