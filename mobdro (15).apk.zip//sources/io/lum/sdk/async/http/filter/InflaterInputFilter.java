package io.lum.sdk.async.http.filter;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.Util;
import java.nio.ByteBuffer;
import java.util.zip.Inflater;

public class InflaterInputFilter extends FilteredDataEmitter {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public Inflater mInflater;
    public ByteBufferList transformed;

    public InflaterInputFilter() {
        this(new Inflater());
    }

    public InflaterInputFilter(Inflater inflater) {
        this.transformed = new ByteBufferList();
        this.mInflater = inflater;
    }

    public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        try {
            ByteBuffer obtain = ByteBufferList.obtain(byteBufferList.remaining() * 2);
            while (byteBufferList.size() > 0) {
                ByteBuffer remove = byteBufferList.remove();
                if (remove.hasRemaining()) {
                    remove.remaining();
                    this.mInflater.setInput(remove.array(), remove.arrayOffset() + remove.position(), remove.remaining());
                    do {
                        obtain.position(obtain.position() + this.mInflater.inflate(obtain.array(), obtain.arrayOffset() + obtain.position(), obtain.remaining()));
                        if (!obtain.hasRemaining()) {
                            obtain.flip();
                            this.transformed.add(obtain);
                            obtain = ByteBufferList.obtain(obtain.capacity() * 2);
                        }
                        if (this.mInflater.needsInput()) {
                            break;
                        }
                    } while (this.mInflater.finished());
                }
                ByteBufferList.reclaim(remove);
            }
            obtain.flip();
            this.transformed.add(obtain);
            Util.emitAllData(this, this.transformed);
        } catch (Exception e2) {
            report(e2);
        }
    }

    public void report(Exception exc) {
        this.mInflater.end();
        if (exc != null && this.mInflater.getRemaining() > 0) {
            exc = new DataRemainingException("data still remaining in inflater", exc);
        }
        super.report(exc);
    }
}
