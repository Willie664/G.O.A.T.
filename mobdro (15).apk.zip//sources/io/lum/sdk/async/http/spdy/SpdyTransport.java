package io.lum.sdk.async.http.spdy;

import io.lum.sdk.async.http.Protocol;
import java.util.List;
import java.util.Locale;

public final class SpdyTransport {
    public static final List<String> HTTP_2_PROHIBITED_HEADERS = Util.immutableList((T[]) new String[]{"connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade"});
    public static final List<String> SPDY_3_PROHIBITED_HEADERS = Util.immutableList((T[]) new String[]{"connection", "host", "keep-alive", "proxy-connection", "transfer-encoding"});

    public static boolean isProhibitedHeader(Protocol protocol, String str) {
        List<String> list;
        if (protocol == Protocol.SPDY_3) {
            list = SPDY_3_PROHIBITED_HEADERS;
        } else if (protocol == Protocol.HTTP_2) {
            list = HTTP_2_PROHIBITED_HEADERS;
        } else {
            throw new AssertionError(protocol);
        }
        return list.contains(str.toLowerCase(Locale.US));
    }
}
