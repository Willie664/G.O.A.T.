package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.parser.JSONObjectParser;
import org.json.JSONObject;

public class JSONObjectBody implements AsyncHttpRequestBody<JSONObject> {
    public static final String CONTENT_TYPE = "application/json";
    public JSONObject json;
    public byte[] mBodyBytes;

    public JSONObjectBody() {
    }

    public JSONObjectBody(JSONObject jSONObject) {
        this();
        this.json = jSONObject;
    }

    public JSONObject get() {
        return this.json;
    }

    public String getContentType() {
        return "application/json";
    }

    public int length() {
        byte[] bytes = this.json.toString().getBytes();
        this.mBodyBytes = bytes;
        return bytes.length;
    }

    public void parse(DataEmitter dataEmitter, final CompletedCallback completedCallback) {
        new JSONObjectParser().parse(dataEmitter).setCallback(new FutureCallback<JSONObject>() {
            public void onCompleted(Exception exc, JSONObject jSONObject) {
                JSONObjectBody.this.json = jSONObject;
                completedCallback.onCompleted(exc);
            }
        });
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        Util.writeAll(dataSink, this.mBodyBytes, completedCallback);
    }
}
