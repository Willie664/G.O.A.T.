package io.lum.sdk.async.http;

import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import io.lum.sdk.async.http.body.JSONObjectBody;
import io.lum.sdk.async.http.body.MultipartFormDataBody;
import io.lum.sdk.async.http.body.StringBody;
import io.lum.sdk.async.http.body.UrlEncodedFormBody;

public class HttpUtil {

    public static class EndEmitter extends FilteredDataEmitter {
        public static EndEmitter create(AsyncServer asyncServer, final Exception exc) {
            EndEmitter endEmitter = new EndEmitter();
            asyncServer.post(new Runnable(endEmitter) {
                public final /* synthetic */ EndEmitter val$ret;

                {
                    this.val$ret = r1;
                }

                public void run() {
                    this.val$ret.report(exc);
                }
            });
            return endEmitter;
        }
    }

    public static long contentLength(Headers headers) {
        String str = headers.get("Content-Length");
        if (str == null) {
            return -1;
        }
        try {
            return Long.parseLong(str);
        } catch (NumberFormatException unused) {
            return -1;
        }
    }

    public static AsyncHttpRequestBody getBody(DataEmitter dataEmitter, CompletedCallback completedCallback, Headers headers) {
        String str = headers.get("Content-Type");
        if (str == null) {
            return null;
        }
        String[] split = str.split(";");
        for (int i = 0; i < split.length; i++) {
            split[i] = split[i].trim();
        }
        for (String str2 : split) {
            if (UrlEncodedFormBody.CONTENT_TYPE.equals(str2)) {
                return new UrlEncodedFormBody();
            }
            if ("application/json".equals(str2)) {
                return new JSONObjectBody();
            }
            if (StringBody.CONTENT_TYPE.equals(str2)) {
                return new StringBody();
            }
            if (str2 != null && str2.startsWith(MultipartFormDataBody.PRIMARY_TYPE)) {
                return new MultipartFormDataBody(str);
            }
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0059, code lost:
        if (r8 != false) goto L_0x0032;
     */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x006a  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0015  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static io.lum.sdk.async.DataEmitter getBodyDecoder(io.lum.sdk.async.DataEmitter r5, io.lum.sdk.async.http.Protocol r6, io.lum.sdk.async.http.Headers r7, boolean r8) {
        /*
            r0 = -1
            java.lang.String r6 = "Content-Length"
            java.lang.String r6 = r7.get(r6)     // Catch:{ NumberFormatException -> 0x000f }
            if (r6 == 0) goto L_0x000f
            long r2 = java.lang.Long.parseLong(r6)     // Catch:{ NumberFormatException -> 0x000f }
            goto L_0x0010
        L_0x000f:
            r2 = r0
        L_0x0010:
            r6 = 0
            int r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r4 == 0) goto L_0x0041
            r0 = 0
            int r8 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r8 >= 0) goto L_0x002e
            io.lum.sdk.async.AsyncServer r6 = r5.getServer()
            io.lum.sdk.async.http.BodyDecoderException r7 = new io.lum.sdk.async.http.BodyDecoderException
            java.lang.String r8 = "not using chunked encoding, and no content-length found."
            r7.<init>(r8)
            io.lum.sdk.async.http.HttpUtil$EndEmitter r6 = io.lum.sdk.async.http.HttpUtil.EndEmitter.create(r6, r7)
        L_0x002a:
            r6.setDataEmitter(r5)
            return r6
        L_0x002e:
            int r8 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r8 != 0) goto L_0x003b
        L_0x0032:
            io.lum.sdk.async.AsyncServer r7 = r5.getServer()
            io.lum.sdk.async.http.HttpUtil$EndEmitter r6 = io.lum.sdk.async.http.HttpUtil.EndEmitter.create(r7, r6)
            goto L_0x002a
        L_0x003b:
            io.lum.sdk.async.http.filter.ContentLengthFilter r6 = new io.lum.sdk.async.http.filter.ContentLengthFilter
            r6.<init>(r2)
            goto L_0x0054
        L_0x0041:
            java.lang.String r0 = "Transfer-Encoding"
            java.lang.String r0 = r7.get(r0)
            java.lang.String r1 = "chunked"
            boolean r0 = r1.equalsIgnoreCase(r0)
            if (r0 == 0) goto L_0x0059
            io.lum.sdk.async.http.filter.ChunkedInputFilter r6 = new io.lum.sdk.async.http.filter.ChunkedInputFilter
            r6.<init>()
        L_0x0054:
            r6.setDataEmitter(r5)
            r5 = r6
            goto L_0x005c
        L_0x0059:
            if (r8 == 0) goto L_0x005c
            goto L_0x0032
        L_0x005c:
            java.lang.String r6 = "Content-Encoding"
            java.lang.String r8 = r7.get(r6)
            java.lang.String r0 = "gzip"
            boolean r8 = r0.equals(r8)
            if (r8 == 0) goto L_0x0074
            io.lum.sdk.async.http.filter.GZIPInputFilter r6 = new io.lum.sdk.async.http.filter.GZIPInputFilter
            r6.<init>()
        L_0x006f:
            r6.setDataEmitter(r5)
            r5 = r6
            goto L_0x0086
        L_0x0074:
            java.lang.String r6 = r7.get(r6)
            java.lang.String r7 = "deflate"
            boolean r6 = r7.equals(r6)
            if (r6 == 0) goto L_0x0086
            io.lum.sdk.async.http.filter.InflaterInputFilter r6 = new io.lum.sdk.async.http.filter.InflaterInputFilter
            r6.<init>()
            goto L_0x006f
        L_0x0086:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.HttpUtil.getBodyDecoder(io.lum.sdk.async.DataEmitter, io.lum.sdk.async.http.Protocol, io.lum.sdk.async.http.Headers, boolean):io.lum.sdk.async.DataEmitter");
    }

    public static boolean isKeepAlive(Protocol protocol, Headers headers) {
        String str = headers.get("Connection");
        return str == null ? protocol == Protocol.HTTP_1_1 : "keep-alive".equalsIgnoreCase(str);
    }

    public static boolean isKeepAlive(String str, Headers headers) {
        String str2 = headers.get("Connection");
        return str2 == null ? Protocol.get(str) == Protocol.HTTP_1_1 : "keep-alive".equalsIgnoreCase(str2);
    }
}
