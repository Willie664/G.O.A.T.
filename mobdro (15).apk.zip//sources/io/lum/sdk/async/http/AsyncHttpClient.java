package io.lum.sdk.async.http;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import b.a.a.a.a;
import d.a.a.b2.v.d;
import d.a.a.b2.v.e;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.SimpleFuture;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.http.callback.HttpConnectCallback;
import io.lum.sdk.async.http.callback.RequestCallback;
import io.lum.sdk.async.parser.AsyncParser;
import io.lum.sdk.async.parser.ByteBufferListParser;
import io.lum.sdk.async.parser.JSONArrayParser;
import io.lum.sdk.async.parser.JSONObjectParser;
import io.lum.sdk.async.parser.StringParser;
import io.lum.sdk.async.stream.OutputStreamDataCallback;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeoutException;
import org.json.JSONArray;
import org.json.JSONObject;

public class AsyncHttpClient {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final String LOGTAG = "AsyncHttp";
    public static AsyncHttpClient mDefaultInstance;
    public HttpTransportMiddleware httpTransportMiddleware;
    public final List<AsyncHttpClientMiddleware> mMiddleware = new CopyOnWriteArrayList();
    public AsyncServer mServer;
    public AsyncSocketMiddleware socketMiddleware;
    public AsyncSSLSocketMiddleware sslSocketMiddleware;

    public static abstract class DownloadCallback extends RequestCallbackBase<ByteBufferList> {
    }

    public static abstract class FileCallback extends RequestCallbackBase<File> {
    }

    public class FutureAsyncHttpResponse extends SimpleFuture<AsyncHttpResponse> {
        public Cancellable scheduled;
        public AsyncSocket socket;
        public Runnable timeoutRunnable;

        public FutureAsyncHttpResponse() {
        }

        public boolean cancel() {
            if (!super.cancel()) {
                return false;
            }
            AsyncSocket asyncSocket = this.socket;
            if (asyncSocket != null) {
                asyncSocket.setDataCallback(new DataCallback.NullDataCallback());
                this.socket.close();
            }
            Cancellable cancellable = this.scheduled;
            if (cancellable == null) {
                return true;
            }
            cancellable.cancel();
            return true;
        }
    }

    public static abstract class JSONArrayCallback extends RequestCallbackBase<JSONArray> {
    }

    public static abstract class JSONObjectCallback extends RequestCallbackBase<JSONObject> {
    }

    public static abstract class RequestCallbackBase<T> implements RequestCallback<T> {
        public void onConnect(AsyncHttpResponse asyncHttpResponse) {
        }

        public void onProgress(AsyncHttpResponse asyncHttpResponse, long j, long j2) {
        }
    }

    public static abstract class StringCallback extends RequestCallbackBase<String> {
    }

    public interface WebSocketConnectCallback {
        void onCompleted(Exception exc, WebSocket webSocket);
    }

    public AsyncHttpClient(AsyncServer asyncServer) {
        this.mServer = asyncServer;
        AsyncSocketMiddleware asyncSocketMiddleware = new AsyncSocketMiddleware(this);
        this.socketMiddleware = asyncSocketMiddleware;
        insertMiddleware(asyncSocketMiddleware);
        AsyncSSLSocketMiddleware asyncSSLSocketMiddleware = new AsyncSSLSocketMiddleware(this);
        this.sslSocketMiddleware = asyncSSLSocketMiddleware;
        insertMiddleware(asyncSSLSocketMiddleware);
        HttpTransportMiddleware httpTransportMiddleware2 = new HttpTransportMiddleware();
        this.httpTransportMiddleware = httpTransportMiddleware2;
        insertMiddleware(httpTransportMiddleware2);
        this.sslSocketMiddleware.addEngineConfigurator(new SSLEngineSNIConfigurator());
    }

    public static /* synthetic */ void a(SimpleFuture simpleFuture, WebSocketConnectCallback webSocketConnectCallback, AsyncHttpRequest asyncHttpRequest, Exception exc, AsyncHttpResponse asyncHttpResponse) {
        if (exc == null) {
            WebSocket finishHandshake = WebSocketImpl.finishHandshake(asyncHttpRequest.getHeaders(), asyncHttpResponse);
            if (finishHandshake == null) {
                exc = new WebSocketHandshakeException("Unable to complete websocket handshake");
                asyncHttpResponse.close();
                if (!simpleFuture.setComplete(exc)) {
                    return;
                }
            } else if (!simpleFuture.setComplete(finishHandshake)) {
                return;
            }
            if (webSocketConnectCallback != null) {
                webSocketConnectCallback.onCompleted(exc, finishHandshake);
            }
        } else if (simpleFuture.setComplete(exc) && webSocketConnectCallback != null) {
            webSocketConnectCallback.onCompleted(exc, (WebSocket) null);
        }
    }

    public static void copyHeader(AsyncHttpRequest asyncHttpRequest, AsyncHttpRequest asyncHttpRequest2, String str) {
        String str2 = asyncHttpRequest.getHeaders().get(str);
        if (!TextUtils.isEmpty(str2)) {
            asyncHttpRequest2.getHeaders().set(str, str2);
        }
    }

    /* access modifiers changed from: private */
    public void execute(AsyncHttpRequest asyncHttpRequest, int i, FutureAsyncHttpResponse futureAsyncHttpResponse, HttpConnectCallback httpConnectCallback) {
        if (this.mServer.isAffinityThread()) {
            executeAffinity(asyncHttpRequest, i, futureAsyncHttpResponse, httpConnectCallback);
            return;
        }
        final AsyncHttpRequest asyncHttpRequest2 = asyncHttpRequest;
        final int i2 = i;
        final FutureAsyncHttpResponse futureAsyncHttpResponse2 = futureAsyncHttpResponse;
        final HttpConnectCallback httpConnectCallback2 = httpConnectCallback;
        this.mServer.post(new Runnable() {
            public void run() {
                AsyncHttpClient.this.executeAffinity(asyncHttpRequest2, i2, futureAsyncHttpResponse2, httpConnectCallback2);
            }
        });
    }

    /* access modifiers changed from: private */
    public void executeAffinity(AsyncHttpRequest asyncHttpRequest, int i, FutureAsyncHttpResponse futureAsyncHttpResponse, HttpConnectCallback httpConnectCallback) {
        AsyncHttpRequest asyncHttpRequest2 = asyncHttpRequest;
        FutureAsyncHttpResponse futureAsyncHttpResponse2 = futureAsyncHttpResponse;
        if (i > 15) {
            reportConnectedCompleted(futureAsyncHttpResponse, new RedirectLimitExceededException("too many redirects"), (AsyncHttpResponseImpl) null, asyncHttpRequest, httpConnectCallback);
            return;
        }
        asyncHttpRequest.getUri();
        AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData = new AsyncHttpClientMiddleware.OnResponseCompleteData();
        asyncHttpRequest2.executionTime = System.currentTimeMillis();
        onResponseCompleteData.request = asyncHttpRequest2;
        asyncHttpRequest.logd("Executing request.");
        for (AsyncHttpClientMiddleware onRequest : this.mMiddleware) {
            onRequest.onRequest(onResponseCompleteData);
        }
        if (asyncHttpRequest.getTimeout() > 0) {
            final AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData2 = onResponseCompleteData;
            final FutureAsyncHttpResponse futureAsyncHttpResponse3 = futureAsyncHttpResponse;
            final AsyncHttpRequest asyncHttpRequest3 = asyncHttpRequest;
            final HttpConnectCallback httpConnectCallback2 = httpConnectCallback;
            AnonymousClass2 r0 = new Runnable() {
                public void run() {
                    Cancellable cancellable = onResponseCompleteData2.socketCancellable;
                    if (cancellable != null) {
                        cancellable.cancel();
                        AsyncSocket asyncSocket = onResponseCompleteData2.socket;
                        if (asyncSocket != null) {
                            asyncSocket.close();
                        }
                    }
                    AsyncHttpClient.this.reportConnectedCompleted(futureAsyncHttpResponse3, new TimeoutException(), (AsyncHttpResponseImpl) null, asyncHttpRequest3, httpConnectCallback2);
                }
            };
            futureAsyncHttpResponse2.timeoutRunnable = r0;
            futureAsyncHttpResponse2.scheduled = this.mServer.postDelayed(r0, getTimeoutRemaining(asyncHttpRequest));
        }
        final AsyncHttpRequest asyncHttpRequest4 = asyncHttpRequest;
        final FutureAsyncHttpResponse futureAsyncHttpResponse4 = futureAsyncHttpResponse;
        final HttpConnectCallback httpConnectCallback3 = httpConnectCallback;
        final AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData3 = onResponseCompleteData;
        final int i2 = i;
        onResponseCompleteData.connectCallback = new ConnectCallback() {
            public boolean reported;

            public void onConnectCompleted(Exception exc, AsyncSocket asyncSocket) {
                if (!this.reported || asyncSocket == null) {
                    this.reported = true;
                    asyncHttpRequest4.logv("socket connected");
                    if (!futureAsyncHttpResponse4.isCancelled()) {
                        FutureAsyncHttpResponse futureAsyncHttpResponse = futureAsyncHttpResponse4;
                        if (futureAsyncHttpResponse.timeoutRunnable != null) {
                            futureAsyncHttpResponse.scheduled.cancel();
                        }
                        if (exc != null) {
                            AsyncHttpClient.this.reportConnectedCompleted(futureAsyncHttpResponse4, exc, (AsyncHttpResponseImpl) null, asyncHttpRequest4, httpConnectCallback3);
                            return;
                        }
                        AsyncHttpClientMiddleware.OnResponseCompleteData onResponseCompleteData = onResponseCompleteData3;
                        onResponseCompleteData.socket = asyncSocket;
                        FutureAsyncHttpResponse futureAsyncHttpResponse2 = futureAsyncHttpResponse4;
                        futureAsyncHttpResponse2.socket = asyncSocket;
                        AsyncHttpClient.this.executeSocket(asyncHttpRequest4, i2, futureAsyncHttpResponse2, httpConnectCallback3, onResponseCompleteData);
                    } else if (asyncSocket != null) {
                        asyncSocket.close();
                    }
                } else {
                    asyncSocket.setDataCallback(new DataCallback.NullDataCallback());
                    asyncSocket.setEndCallback(new CompletedCallback.NullCompletedCallback());
                    asyncSocket.close();
                    throw new AssertionError("double connect callback");
                }
            }
        };
        setupAndroidProxy(asyncHttpRequest);
        if (asyncHttpRequest.getBody() != null && asyncHttpRequest.getHeaders().get("Content-Type") == null) {
            asyncHttpRequest.getHeaders().set("Content-Type", asyncHttpRequest.getBody().getContentType());
        }
        for (AsyncHttpClientMiddleware socket : this.mMiddleware) {
            Cancellable socket2 = socket.getSocket(onResponseCompleteData);
            if (socket2 != null) {
                onResponseCompleteData.socketCancellable = socket2;
                futureAsyncHttpResponse.setParent(socket2);
                return;
            }
        }
        StringBuilder a2 = a.a("invalid uri=");
        a2.append(asyncHttpRequest.getUri());
        a2.append(" middlewares=");
        a2.append(this.mMiddleware);
        reportConnectedCompleted(futureAsyncHttpResponse, new IllegalArgumentException(a2.toString()), (AsyncHttpResponseImpl) null, asyncHttpRequest, httpConnectCallback);
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:1:0x0028 A[LOOP:0: B:1:0x0028->B:4:0x0038, LOOP_START] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void executeSocket(io.lum.sdk.async.http.AsyncHttpRequest r10, int r11, io.lum.sdk.async.http.AsyncHttpClient.FutureAsyncHttpResponse r12, io.lum.sdk.async.http.callback.HttpConnectCallback r13, io.lum.sdk.async.http.AsyncHttpClientMiddleware.OnResponseCompleteData r14) {
        /*
            r9 = this;
            io.lum.sdk.async.http.AsyncHttpClient$4 r8 = new io.lum.sdk.async.http.AsyncHttpClient$4
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r12
            r4 = r10
            r5 = r13
            r6 = r14
            r7 = r11
            r0.<init>(r2, r3, r4, r5, r6, r7)
            io.lum.sdk.async.http.AsyncHttpClient$5 r10 = new io.lum.sdk.async.http.AsyncHttpClient$5
            r10.<init>(r8)
            r14.sendHeadersCallback = r10
            io.lum.sdk.async.http.AsyncHttpClient$6 r10 = new io.lum.sdk.async.http.AsyncHttpClient$6
            r10.<init>(r8)
            r14.receiveHeadersCallback = r10
            r14.response = r8
            io.lum.sdk.async.AsyncSocket r10 = r14.socket
            r8.setSocket(r10)
            java.util.List<io.lum.sdk.async.http.AsyncHttpClientMiddleware> r10 = r9.mMiddleware
            java.util.Iterator r10 = r10.iterator()
        L_0x0028:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x003a
            java.lang.Object r11 = r10.next()
            io.lum.sdk.async.http.AsyncHttpClientMiddleware r11 = (io.lum.sdk.async.http.AsyncHttpClientMiddleware) r11
            boolean r11 = r11.exchangeHeaders(r14)
            if (r11 == 0) goto L_0x0028
        L_0x003a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.AsyncHttpClient.executeSocket(io.lum.sdk.async.http.AsyncHttpRequest, int, io.lum.sdk.async.http.AsyncHttpClient$FutureAsyncHttpResponse, io.lum.sdk.async.http.callback.HttpConnectCallback, io.lum.sdk.async.http.AsyncHttpClientMiddleware$OnResponseCompleteData):void");
    }

    public static AsyncHttpClient getDefaultInstance() {
        if (mDefaultInstance == null) {
            mDefaultInstance = new AsyncHttpClient(AsyncServer.getDefault());
        }
        return mDefaultInstance;
    }

    public static long getTimeoutRemaining(AsyncHttpRequest asyncHttpRequest) {
        return (long) asyncHttpRequest.getTimeout();
    }

    /* access modifiers changed from: private */
    /* renamed from: invoke */
    public <T> void a(RequestCallback<T> requestCallback, SimpleFuture<T> simpleFuture, AsyncHttpResponse asyncHttpResponse, Exception exc, T t) {
        final RequestCallback<T> requestCallback2 = requestCallback;
        final SimpleFuture<T> simpleFuture2 = simpleFuture;
        final AsyncHttpResponse asyncHttpResponse2 = asyncHttpResponse;
        final Exception exc2 = exc;
        final T t2 = t;
        this.mServer.post(new Runnable() {
            public void run() {
                AsyncHttpClient.this.invokeWithAffinity(requestCallback2, simpleFuture2, asyncHttpResponse2, exc2, t2);
            }
        });
    }

    /* access modifiers changed from: private */
    public void invokeConnect(RequestCallback requestCallback, AsyncHttpResponse asyncHttpResponse) {
        if (requestCallback != null) {
            requestCallback.onConnect(asyncHttpResponse);
        }
    }

    /* access modifiers changed from: private */
    public void invokeProgress(RequestCallback requestCallback, AsyncHttpResponse asyncHttpResponse, long j, long j2) {
        if (requestCallback != null) {
            requestCallback.onProgress(asyncHttpResponse, j, j2);
        }
    }

    /* access modifiers changed from: private */
    public <T> void invokeWithAffinity(RequestCallback<T> requestCallback, SimpleFuture<T> simpleFuture, AsyncHttpResponse asyncHttpResponse, Exception exc, T t) {
        if ((exc != null ? simpleFuture.setComplete(exc) : simpleFuture.setComplete(t)) && requestCallback != null) {
            requestCallback.onCompleted(exc, asyncHttpResponse, t);
        }
    }

    /* access modifiers changed from: private */
    public void reportConnectedCompleted(FutureAsyncHttpResponse futureAsyncHttpResponse, Exception exc, AsyncHttpResponseImpl asyncHttpResponseImpl, AsyncHttpRequest asyncHttpRequest, HttpConnectCallback httpConnectCallback) {
        boolean z;
        futureAsyncHttpResponse.scheduled.cancel();
        if (exc != null) {
            asyncHttpRequest.loge("Connection error", exc);
            z = futureAsyncHttpResponse.setComplete(exc);
        } else {
            asyncHttpRequest.logd("Connection successful");
            z = futureAsyncHttpResponse.setComplete(asyncHttpResponseImpl);
        }
        if (z) {
            httpConnectCallback.onConnectCompleted(exc, asyncHttpResponseImpl);
        } else if (asyncHttpResponseImpl != null) {
            asyncHttpResponseImpl.setDataCallback(new DataCallback.NullDataCallback());
            asyncHttpResponseImpl.close();
        }
    }

    @SuppressLint({"NewApi"})
    public static void setupAndroidProxy(AsyncHttpRequest asyncHttpRequest) {
        if (asyncHttpRequest.proxyHost == null) {
            try {
                List<Proxy> select = ProxySelector.getDefault().select(URI.create(asyncHttpRequest.getUri().toString()));
                if (!select.isEmpty()) {
                    Proxy proxy = select.get(0);
                    if (proxy.type() == Proxy.Type.HTTP && (proxy.address() instanceof InetSocketAddress)) {
                        InetSocketAddress inetSocketAddress = (InetSocketAddress) proxy.address();
                        asyncHttpRequest.enableProxy(inetSocketAddress.getHostString(), inetSocketAddress.getPort());
                    }
                }
            } catch (Exception unused) {
            }
        }
    }

    public /* synthetic */ void a(RequestCallback requestCallback, SimpleFuture simpleFuture, AsyncParser asyncParser, Exception exc, AsyncHttpResponse asyncHttpResponse) {
        if (exc != null) {
            a(requestCallback, simpleFuture, asyncHttpResponse, exc, (Object) null);
            return;
        }
        invokeConnect(requestCallback, asyncHttpResponse);
        Future parse = asyncParser.parse(asyncHttpResponse);
        parse.setCallback(new d(this, requestCallback, simpleFuture, asyncHttpResponse));
        simpleFuture.setParent(parse);
    }

    public Future<AsyncHttpResponse> execute(AsyncHttpRequest asyncHttpRequest, HttpConnectCallback httpConnectCallback) {
        FutureAsyncHttpResponse futureAsyncHttpResponse = new FutureAsyncHttpResponse();
        execute(asyncHttpRequest, 0, futureAsyncHttpResponse, httpConnectCallback);
        return futureAsyncHttpResponse;
    }

    public Future<AsyncHttpResponse> execute(String str, HttpConnectCallback httpConnectCallback) {
        return execute((AsyncHttpRequest) new AsyncHttpGet(str), httpConnectCallback);
    }

    public <T> SimpleFuture<T> execute(AsyncHttpRequest asyncHttpRequest, AsyncParser<T> asyncParser, RequestCallback<T> requestCallback) {
        FutureAsyncHttpResponse futureAsyncHttpResponse = new FutureAsyncHttpResponse();
        SimpleFuture<T> simpleFuture = new SimpleFuture<>();
        execute(asyncHttpRequest, 0, futureAsyncHttpResponse, new d.a.a.b2.v.a(this, requestCallback, simpleFuture, asyncParser));
        simpleFuture.setParent(futureAsyncHttpResponse);
        return simpleFuture;
    }

    public Future<ByteBufferList> executeByteBufferList(AsyncHttpRequest asyncHttpRequest, DownloadCallback downloadCallback) {
        return execute(asyncHttpRequest, new ByteBufferListParser(), downloadCallback);
    }

    public Future<File> executeFile(AsyncHttpRequest asyncHttpRequest, String str, FileCallback fileCallback) {
        final File file = new File(str);
        file.getParentFile().mkdirs();
        try {
            final BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file), 8192);
            final FutureAsyncHttpResponse futureAsyncHttpResponse = new FutureAsyncHttpResponse();
            AnonymousClass8 r6 = new SimpleFuture<File>() {
                /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
                /* JADX WARNING: Failed to process nested try/catch */
                /* JADX WARNING: Missing exception handler attribute for start block: B:2:0x001b */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public void cancelCleanup() {
                    /*
                        r2 = this;
                        io.lum.sdk.async.http.AsyncHttpClient$FutureAsyncHttpResponse r0 = r11     // Catch:{ Exception -> 0x001b }
                        java.lang.Object r0 = r0.get()     // Catch:{ Exception -> 0x001b }
                        io.lum.sdk.async.http.AsyncHttpResponse r0 = (io.lum.sdk.async.http.AsyncHttpResponse) r0     // Catch:{ Exception -> 0x001b }
                        io.lum.sdk.async.callback.DataCallback$NullDataCallback r1 = new io.lum.sdk.async.callback.DataCallback$NullDataCallback     // Catch:{ Exception -> 0x001b }
                        r1.<init>()     // Catch:{ Exception -> 0x001b }
                        r0.setDataCallback(r1)     // Catch:{ Exception -> 0x001b }
                        io.lum.sdk.async.http.AsyncHttpClient$FutureAsyncHttpResponse r0 = r11     // Catch:{ Exception -> 0x001b }
                        java.lang.Object r0 = r0.get()     // Catch:{ Exception -> 0x001b }
                        io.lum.sdk.async.http.AsyncHttpResponse r0 = (io.lum.sdk.async.http.AsyncHttpResponse) r0     // Catch:{ Exception -> 0x001b }
                        r0.close()     // Catch:{ Exception -> 0x001b }
                    L_0x001b:
                        java.io.OutputStream r0 = r2     // Catch:{ Exception -> 0x0020 }
                        r0.close()     // Catch:{ Exception -> 0x0020 }
                    L_0x0020:
                        java.io.File r0 = r3
                        r0.delete()
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.AsyncHttpClient.AnonymousClass8.cancelCleanup():void");
                }
            };
            r6.setParent(futureAsyncHttpResponse);
            final FileCallback fileCallback2 = fileCallback;
            final AnonymousClass8 r5 = r6;
            execute(asyncHttpRequest, 0, futureAsyncHttpResponse, new HttpConnectCallback() {
                public long mDownloaded = 0;

                public void onConnectCompleted(Exception exc, final AsyncHttpResponse asyncHttpResponse) {
                    if (exc != null) {
                        try {
                            bufferedOutputStream.close();
                        } catch (IOException unused) {
                        }
                        file.delete();
                        AsyncHttpClient.this.a(fileCallback2, r5, asyncHttpResponse, exc, null);
                        return;
                    }
                    AsyncHttpClient.this.invokeConnect(fileCallback2, asyncHttpResponse);
                    final long contentLength = HttpUtil.contentLength(asyncHttpResponse.headers());
                    final AsyncHttpResponse asyncHttpResponse2 = asyncHttpResponse;
                    asyncHttpResponse.setDataCallback(new OutputStreamDataCallback(bufferedOutputStream) {
                        public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                            AnonymousClass9.this.mDownloaded += (long) byteBufferList.remaining();
                            super.onDataAvailable(dataEmitter, byteBufferList);
                            AnonymousClass9 r8 = AnonymousClass9.this;
                            AsyncHttpClient.this.invokeProgress(fileCallback2, asyncHttpResponse2, r8.mDownloaded, contentLength);
                        }
                    });
                    asyncHttpResponse.setEndCallback(new CompletedCallback() {
                        public void onCompleted(Exception e2) {
                            File file;
                            AsyncHttpResponse asyncHttpResponse;
                            SimpleFuture simpleFuture;
                            FileCallback fileCallback;
                            AsyncHttpClient asyncHttpClient;
                            try {
                                bufferedOutputStream.close();
                            } catch (IOException e3) {
                                e2 = e3;
                            }
                            Exception exc = e2;
                            AnonymousClass9 r7 = AnonymousClass9.this;
                            if (exc != null) {
                                file.delete();
                                AnonymousClass9 r72 = AnonymousClass9.this;
                                asyncHttpClient = AsyncHttpClient.this;
                                fileCallback = fileCallback2;
                                simpleFuture = r5;
                                asyncHttpResponse = asyncHttpResponse;
                                file = null;
                            } else {
                                asyncHttpClient = AsyncHttpClient.this;
                                fileCallback = fileCallback2;
                                simpleFuture = r5;
                                asyncHttpResponse = asyncHttpResponse;
                                exc = null;
                                file = file;
                            }
                            asyncHttpClient.a(fileCallback, simpleFuture, asyncHttpResponse, exc, file);
                        }
                    });
                }
            });
            return r6;
        } catch (FileNotFoundException e2) {
            SimpleFuture simpleFuture = new SimpleFuture();
            simpleFuture.setComplete((Exception) e2);
            return simpleFuture;
        }
    }

    public Future<JSONArray> executeJSONArray(AsyncHttpRequest asyncHttpRequest, JSONArrayCallback jSONArrayCallback) {
        return execute(asyncHttpRequest, new JSONArrayParser(), jSONArrayCallback);
    }

    public Future<JSONObject> executeJSONObject(AsyncHttpRequest asyncHttpRequest, JSONObjectCallback jSONObjectCallback) {
        return execute(asyncHttpRequest, new JSONObjectParser(), jSONObjectCallback);
    }

    public Future<String> executeString(AsyncHttpRequest asyncHttpRequest, StringCallback stringCallback) {
        return execute(asyncHttpRequest, new StringParser(), stringCallback);
    }

    public Collection<AsyncHttpClientMiddleware> getMiddleware() {
        return this.mMiddleware;
    }

    public AsyncSSLSocketMiddleware getSSLSocketMiddleware() {
        return this.sslSocketMiddleware;
    }

    public AsyncServer getServer() {
        return this.mServer;
    }

    public AsyncSocketMiddleware getSocketMiddleware() {
        return this.socketMiddleware;
    }

    public void insertMiddleware(AsyncHttpClientMiddleware asyncHttpClientMiddleware) {
        this.mMiddleware.add(0, asyncHttpClientMiddleware);
    }

    public Future<WebSocket> websocket(AsyncHttpRequest asyncHttpRequest, String str, WebSocketConnectCallback webSocketConnectCallback) {
        return websocket(asyncHttpRequest, str != null ? new String[]{str} : null, webSocketConnectCallback);
    }

    public Future<WebSocket> websocket(AsyncHttpRequest asyncHttpRequest, String[] strArr, WebSocketConnectCallback webSocketConnectCallback) {
        WebSocketImpl.addWebSocketUpgradeHeaders(asyncHttpRequest, strArr);
        SimpleFuture simpleFuture = new SimpleFuture();
        simpleFuture.setParent(execute(asyncHttpRequest, (HttpConnectCallback) new e(simpleFuture, webSocketConnectCallback, asyncHttpRequest)));
        return simpleFuture;
    }

    public Future<WebSocket> websocket(String str, String str2, WebSocketConnectCallback webSocketConnectCallback) {
        return websocket((AsyncHttpRequest) new AsyncHttpGet(str.replace("ws://", "http://").replace("wss://", "https://")), str2, webSocketConnectCallback);
    }

    public Future<WebSocket> websocket(String str, String[] strArr, WebSocketConnectCallback webSocketConnectCallback) {
        return websocket((AsyncHttpRequest) new AsyncHttpGet(str.replace("ws://", "http://").replace("wss://", "https://")), strArr, webSocketConnectCallback);
    }
}
