package io.lum.sdk.async.http;

public class WebSocketHandshakeException extends Exception {
    public WebSocketHandshakeException(String str) {
        super(str);
    }
}
