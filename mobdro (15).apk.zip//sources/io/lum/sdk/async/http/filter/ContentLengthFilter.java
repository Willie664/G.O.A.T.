package io.lum.sdk.async.http.filter;

import b.a.a.a.a;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.FilteredDataEmitter;

public class ContentLengthFilter extends FilteredDataEmitter {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public long contentLength;
    public long totalRead;
    public ByteBufferList transformed = new ByteBufferList();

    public ContentLengthFilter(long j) {
        this.contentLength = j;
    }

    public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        byteBufferList.get(this.transformed, (int) Math.min(this.contentLength - this.totalRead, (long) byteBufferList.remaining()));
        int remaining = this.transformed.remaining();
        super.onDataAvailable(dataEmitter, this.transformed);
        this.totalRead += (long) (remaining - this.transformed.remaining());
        this.transformed.get(byteBufferList);
        if (this.totalRead == this.contentLength) {
            report((Exception) null);
        }
    }

    public void report(Exception exc) {
        if (exc == null && this.totalRead != this.contentLength) {
            StringBuilder a2 = a.a("End of data reached before content length was read: ");
            a2.append(this.totalRead);
            a2.append("/");
            a2.append(this.contentLength);
            a2.append(" Paused: ");
            a2.append(isPaused());
            exc = new PrematureDataEndException(a2.toString());
        }
        super.report(exc);
    }
}
