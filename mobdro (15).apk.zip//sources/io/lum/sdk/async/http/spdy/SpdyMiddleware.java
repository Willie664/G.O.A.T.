package io.lum.sdk.async.http.spdy;

import android.net.Uri;
import android.text.TextUtils;
import b.a.a.a.a;
import d.a.a.b2.v.s.b;
import io.lum.sdk.async.AsyncSSLSocket;
import io.lum.sdk.async.AsyncSSLSocketWrapper;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.future.MultiFuture;
import io.lum.sdk.async.future.SimpleCancellable;
import io.lum.sdk.async.http.AsyncHttpClient;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.AsyncSSLEngineConfigurator;
import io.lum.sdk.async.http.AsyncSSLSocketMiddleware;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.HttpUtil;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import io.lum.sdk.async.http.spdy.AsyncSpdyConnection;
import io.lum.sdk.async.util.Charsets;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;

public class SpdyMiddleware extends AsyncSSLSocketMiddleware {
    public static final NoSpdyException NO_SPDY = new NoSpdyException();
    public Field alpnProtocols;
    public Hashtable<String, SpdyConnectionWaiter> connections = new Hashtable<>();
    public boolean initialized;
    public Method nativeGetAlpnNegotiatedProtocol;
    public Method nativeGetNpnNegotiatedProtocol;
    public Field npnProtocols;
    public Field peerHost;
    public Field peerPort;
    public boolean spdyEnabled;
    public Field sslNativePointer;
    public Field sslParameters;
    public Field useSni;

    public static class NoSpdyException extends Exception {
        public NoSpdyException() {
        }
    }

    public static class SpdyConnectionWaiter extends MultiFuture<AsyncSpdyConnection> {
        public SimpleCancellable originalCancellable;

        public SpdyConnectionWaiter() {
            this.originalCancellable = new SimpleCancellable();
        }
    }

    public SpdyMiddleware(AsyncHttpClient asyncHttpClient) {
        super(asyncHttpClient);
        addEngineConfigurator(new AsyncSSLEngineConfigurator() {
            public void configureEngine(SSLEngine sSLEngine, AsyncHttpClientMiddleware.GetSocketData getSocketData, String str, int i) {
                SpdyMiddleware.this.configure(sSLEngine, getSocketData, str, i);
            }

            public SSLEngine createEngine(SSLContext sSLContext, String str, int i) {
                return null;
            }
        });
    }

    public static /* synthetic */ Headers a(AsyncHttpClientMiddleware.OnExchangeHeaderData onExchangeHeaderData, List list) {
        Headers headers = new Headers();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Header header = (Header) it.next();
            headers.add(header.name.utf8(), header.value.utf8());
        }
        String[] split = headers.remove(Header.RESPONSE_STATUS.utf8()).split(" ", 2);
        onExchangeHeaderData.response.code(Integer.parseInt(split[0]));
        if (split.length == 2) {
            onExchangeHeaderData.response.message(split[1]);
        }
        onExchangeHeaderData.response.protocol(headers.remove(Header.VERSION.utf8()));
        onExchangeHeaderData.response.headers(headers);
        return headers;
    }

    public static /* synthetic */ void a(AsyncHttpClientMiddleware.OnExchangeHeaderData onExchangeHeaderData, AsyncSpdyConnection.SpdySocket spdySocket, Exception exc, Headers headers) {
        onExchangeHeaderData.receiveHeadersCallback.onCompleted(exc);
        onExchangeHeaderData.response.emitter(HttpUtil.getBodyDecoder(spdySocket, spdySocket.getConnection().protocol, headers, false));
    }

    private boolean canSpdyRequest(AsyncHttpClientMiddleware.GetSocketData getSocketData) {
        return getSocketData.request.getBody() == null;
    }

    public static byte[] concatLengthPrefixed(Protocol... protocolArr) {
        ByteBuffer allocate = ByteBuffer.allocate(8192);
        for (Protocol protocol : protocolArr) {
            if (protocol != Protocol.HTTP_1_0) {
                allocate.put((byte) protocol.toString().length());
                allocate.put(protocol.toString().getBytes(Charsets.UTF_8));
            }
        }
        allocate.flip();
        return new ByteBufferList(allocate).getAllByteArray();
    }

    /* access modifiers changed from: private */
    public void configure(SSLEngine sSLEngine, AsyncHttpClientMiddleware.GetSocketData getSocketData, String str, int i) {
        if (!this.initialized && this.spdyEnabled) {
            this.initialized = true;
            try {
                this.peerHost = sSLEngine.getClass().getSuperclass().getDeclaredField("peerHost");
                this.peerPort = sSLEngine.getClass().getSuperclass().getDeclaredField("peerPort");
                Field declaredField = sSLEngine.getClass().getDeclaredField("sslParameters");
                this.sslParameters = declaredField;
                this.npnProtocols = declaredField.getType().getDeclaredField("npnProtocols");
                this.alpnProtocols = this.sslParameters.getType().getDeclaredField("alpnProtocols");
                this.useSni = this.sslParameters.getType().getDeclaredField("useSni");
                this.sslNativePointer = sSLEngine.getClass().getDeclaredField("sslNativePointer");
                String str2 = this.sslParameters.getType().getPackage().getName() + ".NativeCrypto";
                this.nativeGetNpnNegotiatedProtocol = Class.forName(str2, true, this.sslParameters.getType().getClassLoader()).getDeclaredMethod("SSL_get_npn_negotiated_protocol", new Class[]{Long.TYPE});
                this.nativeGetAlpnNegotiatedProtocol = Class.forName(str2, true, this.sslParameters.getType().getClassLoader()).getDeclaredMethod("SSL_get0_alpn_selected", new Class[]{Long.TYPE});
                this.peerHost.setAccessible(true);
                this.peerPort.setAccessible(true);
                this.sslParameters.setAccessible(true);
                this.npnProtocols.setAccessible(true);
                this.alpnProtocols.setAccessible(true);
                this.useSni.setAccessible(true);
                this.sslNativePointer.setAccessible(true);
                this.nativeGetNpnNegotiatedProtocol.setAccessible(true);
                this.nativeGetAlpnNegotiatedProtocol.setAccessible(true);
            } catch (Exception unused) {
                this.sslParameters = null;
                this.npnProtocols = null;
                this.alpnProtocols = null;
                this.useSni = null;
                this.sslNativePointer = null;
                this.nativeGetNpnNegotiatedProtocol = null;
                this.nativeGetAlpnNegotiatedProtocol = null;
            }
        }
        if (canSpdyRequest(getSocketData) && this.sslParameters != null) {
            try {
                byte[] concatLengthPrefixed = concatLengthPrefixed(Protocol.SPDY_3);
                this.peerHost.set(sSLEngine, str);
                this.peerPort.set(sSLEngine, Integer.valueOf(i));
                Object obj = this.sslParameters.get(sSLEngine);
                this.alpnProtocols.set(obj, concatLengthPrefixed);
                this.useSni.set(obj, true);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: private */
    public void invokeConnect(String str, ConnectCallback connectCallback, Exception exc, AsyncSSLSocket asyncSSLSocket) {
        SpdyConnectionWaiter spdyConnectionWaiter = this.connections.get(str);
        if (spdyConnectionWaiter == null || spdyConnectionWaiter.originalCancellable.setComplete()) {
            connectCallback.onConnectCompleted(exc, asyncSSLSocket);
        }
    }

    /* access modifiers changed from: private */
    public void newSocket(AsyncHttpClientMiddleware.GetSocketData getSocketData, AsyncSpdyConnection asyncSpdyConnection, ConnectCallback connectCallback) {
        Header header;
        AsyncHttpRequest asyncHttpRequest = getSocketData.request;
        getSocketData.protocol = asyncSpdyConnection.protocol.toString();
        AsyncHttpRequestBody body = getSocketData.request.getBody();
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Header(Header.TARGET_METHOD, asyncHttpRequest.getMethod()));
        arrayList.add(new Header(Header.TARGET_PATH, requestPath(asyncHttpRequest.getUri())));
        String str = asyncHttpRequest.getHeaders().get("Host");
        Protocol protocol = Protocol.SPDY_3;
        Protocol protocol2 = asyncSpdyConnection.protocol;
        if (protocol == protocol2) {
            arrayList.add(new Header(Header.VERSION, "HTTP/1.1"));
            header = new Header(Header.TARGET_HOST, str);
        } else if (Protocol.HTTP_2 == protocol2) {
            header = new Header(Header.TARGET_AUTHORITY, str);
        } else {
            throw new AssertionError();
        }
        arrayList.add(header);
        arrayList.add(new Header(Header.TARGET_SCHEME, asyncHttpRequest.getUri().getScheme()));
        Multimap multiMap = asyncHttpRequest.getHeaders().getMultiMap();
        for (String str2 : multiMap.keySet()) {
            if (!SpdyTransport.isProhibitedHeader(asyncSpdyConnection.protocol, str2)) {
                for (String header2 : (List) multiMap.get(str2)) {
                    arrayList.add(new Header(str2.toLowerCase(Locale.US), header2));
                }
            }
        }
        asyncHttpRequest.logv("\n" + asyncHttpRequest);
        connectCallback.onConnectCompleted((Exception) null, asyncSpdyConnection.newStream(arrayList, body != null, true));
    }

    /* access modifiers changed from: private */
    public void noSpdy(String str) {
        SpdyConnectionWaiter remove = this.connections.remove(str);
        if (remove != null) {
            remove.setComplete((Exception) NO_SPDY);
        }
    }

    public static String requestPath(Uri uri) {
        String encodedPath = uri.getEncodedPath();
        if (encodedPath == null) {
            encodedPath = "/";
        } else if (!encodedPath.startsWith("/")) {
            encodedPath = a.a("/", encodedPath);
        }
        if (TextUtils.isEmpty(uri.getEncodedQuery())) {
            return encodedPath;
        }
        StringBuilder b2 = a.b(encodedPath, "?");
        b2.append(uri.getEncodedQuery());
        return b2.toString();
    }

    public AsyncSSLSocketWrapper.HandshakeCallback createHandshakeCallback(final AsyncHttpClientMiddleware.GetSocketData getSocketData, final ConnectCallback connectCallback) {
        final String str = (String) getSocketData.state.get("spdykey");
        return str == null ? super.createHandshakeCallback(getSocketData, connectCallback) : new AsyncSSLSocketWrapper.HandshakeCallback() {
            public void onHandshakeCompleted(Exception exc, AsyncSSLSocket asyncSSLSocket) {
                getSocketData.request.logv("checking spdy handshake");
                if (exc == null) {
                    SpdyMiddleware spdyMiddleware = SpdyMiddleware.this;
                    if (spdyMiddleware.nativeGetAlpnNegotiatedProtocol != null) {
                        try {
                            long longValue = ((Long) spdyMiddleware.sslNativePointer.get(asyncSSLSocket.getSSLEngine())).longValue();
                            byte[] bArr = (byte[]) SpdyMiddleware.this.nativeGetAlpnNegotiatedProtocol.invoke((Object) null, new Object[]{Long.valueOf(longValue)});
                            if (bArr == null) {
                                SpdyMiddleware.this.invokeConnect(str, connectCallback, (Exception) null, asyncSSLSocket);
                                SpdyMiddleware.this.noSpdy(str);
                                return;
                            }
                            String str = new String(bArr);
                            Protocol protocol = Protocol.get(str);
                            if (protocol == null || !protocol.needsSpdyConnection()) {
                                SpdyMiddleware.this.invokeConnect(str, connectCallback, (Exception) null, asyncSSLSocket);
                                SpdyMiddleware.this.noSpdy(str);
                                return;
                            }
                            try {
                                new AsyncSpdyConnection(asyncSSLSocket, Protocol.get(str)) {
                                    public boolean hasReceivedSettings;

                                    public void settings(boolean z, Settings settings) {
                                        super.settings(z, settings);
                                        if (!this.hasReceivedSettings) {
                                            this.hasReceivedSettings = true;
                                            AnonymousClass2 r3 = AnonymousClass2.this;
                                            SpdyConnectionWaiter spdyConnectionWaiter = SpdyMiddleware.this.connections.get(str);
                                            if (spdyConnectionWaiter.originalCancellable.setComplete()) {
                                                AsyncHttpRequest asyncHttpRequest = getSocketData.request;
                                                StringBuilder a2 = a.a("using new spdy connection for host: ");
                                                a2.append(getSocketData.request.getUri().getHost());
                                                asyncHttpRequest.logv(a2.toString());
                                                AnonymousClass2 r4 = AnonymousClass2.this;
                                                SpdyMiddleware.this.newSocket(getSocketData, this, connectCallback);
                                            }
                                            spdyConnectionWaiter.setComplete(this);
                                        }
                                    }
                                }.sendConnectionPreface();
                                return;
                            } catch (IOException e2) {
                                e2.printStackTrace();
                                return;
                            }
                        } catch (Exception e3) {
                            throw new AssertionError(e3);
                        }
                    }
                }
                SpdyMiddleware.this.invokeConnect(str, connectCallback, exc, asyncSSLSocket);
                SpdyMiddleware.this.noSpdy(str);
            }
        };
    }

    public boolean exchangeHeaders(AsyncHttpClientMiddleware.OnExchangeHeaderData onExchangeHeaderData) {
        if (!(onExchangeHeaderData.socket instanceof AsyncSpdyConnection.SpdySocket)) {
            return super.exchangeHeaders(onExchangeHeaderData);
        }
        if (onExchangeHeaderData.request.getBody() != null) {
            onExchangeHeaderData.response.sink(onExchangeHeaderData.socket);
        }
        onExchangeHeaderData.sendHeadersCallback.onCompleted((Exception) null);
        AsyncSpdyConnection.SpdySocket spdySocket = (AsyncSpdyConnection.SpdySocket) onExchangeHeaderData.socket;
        spdySocket.headers().thenConvert(new d.a.a.b2.v.s.a(onExchangeHeaderData)).setCallback(new b(onExchangeHeaderData, spdySocket));
        return true;
    }

    public Cancellable getSocket(final AsyncHttpClientMiddleware.GetSocketData getSocketData) {
        Uri uri = getSocketData.request.getUri();
        int schemePort = getSchemePort(getSocketData.request.getUri());
        if (schemePort == -1) {
            return null;
        }
        if (!this.spdyEnabled) {
            return super.getSocket(getSocketData);
        }
        if (!canSpdyRequest(getSocketData)) {
            return super.getSocket(getSocketData);
        }
        String str = uri.getHost() + schemePort;
        SpdyConnectionWaiter spdyConnectionWaiter = this.connections.get(str);
        if (spdyConnectionWaiter != null) {
            if (spdyConnectionWaiter.tryGetException() instanceof NoSpdyException) {
                return super.getSocket(getSocketData);
            }
            if (spdyConnectionWaiter.tryGet() != null && !((AsyncSpdyConnection) spdyConnectionWaiter.tryGet()).socket.isOpen()) {
                this.connections.remove(str);
                spdyConnectionWaiter = null;
            }
        }
        if (spdyConnectionWaiter == null) {
            getSocketData.state.put("spdykey", str);
            Cancellable socket = super.getSocket(getSocketData);
            if (socket.isDone() || socket.isCancelled()) {
                return socket;
            }
            SpdyConnectionWaiter spdyConnectionWaiter2 = new SpdyConnectionWaiter();
            this.connections.put(str, spdyConnectionWaiter2);
            return spdyConnectionWaiter2.originalCancellable;
        }
        AsyncHttpRequest asyncHttpRequest = getSocketData.request;
        StringBuilder a2 = a.a("waiting for potential spdy connection for host: ");
        a2.append(getSocketData.request.getUri().getHost());
        asyncHttpRequest.logv(a2.toString());
        final SimpleCancellable simpleCancellable = new SimpleCancellable();
        spdyConnectionWaiter.setCallback(new FutureCallback<AsyncSpdyConnection>() {
            public void onCompleted(Exception exc, AsyncSpdyConnection asyncSpdyConnection) {
                if (exc instanceof NoSpdyException) {
                    getSocketData.request.logv("spdy not available");
                    simpleCancellable.setParent(SpdyMiddleware.super.getSocket(getSocketData));
                } else if (exc == null) {
                    AsyncHttpRequest asyncHttpRequest = getSocketData.request;
                    StringBuilder a2 = a.a("using existing spdy connection for host: ");
                    a2.append(getSocketData.request.getUri().getHost());
                    asyncHttpRequest.logv(a2.toString());
                    if (simpleCancellable.setComplete()) {
                        SpdyMiddleware spdyMiddleware = SpdyMiddleware.this;
                        AsyncHttpClientMiddleware.GetSocketData getSocketData = getSocketData;
                        spdyMiddleware.newSocket(getSocketData, asyncSpdyConnection, getSocketData.connectCallback);
                    }
                } else if (simpleCancellable.setComplete()) {
                    getSocketData.connectCallback.onConnectCompleted(exc, (AsyncSocket) null);
                }
            }
        });
        return simpleCancellable;
    }

    public boolean getSpdyEnabled() {
        return this.spdyEnabled;
    }

    public void onRequestSent(AsyncHttpClientMiddleware.OnRequestSentData onRequestSentData) {
        if ((onRequestSentData.socket instanceof AsyncSpdyConnection.SpdySocket) && onRequestSentData.request.getBody() != null) {
            onRequestSentData.response.sink().end();
        }
    }

    public void setSSLContext(SSLContext sSLContext) {
        super.setSSLContext(sSLContext);
        this.initialized = false;
    }

    public void setSpdyEnabled(boolean z) {
        this.spdyEnabled = z;
    }

    public ConnectCallback wrapCallback(AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, boolean z, ConnectCallback connectCallback) {
        final ConnectCallback wrapCallback = super.wrapCallback(getSocketData, uri, i, z, connectCallback);
        final String str = (String) getSocketData.state.get("spdykey");
        return str == null ? wrapCallback : new ConnectCallback() {
            public void onConnectCompleted(Exception exc, AsyncSocket asyncSocket) {
                SpdyConnectionWaiter remove;
                if (!(exc == null || (remove = SpdyMiddleware.this.connections.remove(str)) == null)) {
                    remove.setComplete(exc);
                }
                wrapCallback.onConnectCompleted(exc, asyncSocket);
            }
        };
    }
}
