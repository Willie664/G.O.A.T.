package io.lum.sdk.async.http.server;

import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;
import java.util.Map;
import java.util.regex.Matcher;

public interface AsyncHttpServerRequest extends DataEmitter {
    String get(String str);

    <T extends AsyncHttpRequestBody> T getBody();

    Headers getHeaders();

    Matcher getMatcher();

    String getMethod();

    String getPath();

    Multimap getQuery();

    AsyncSocket getSocket();

    Map<String, Object> getState();

    String getUrl();

    void setMatcher(Matcher matcher);
}
