package io.lum.sdk.async.http.server;

import io.lum.sdk.async.http.server.AsyncHttpServerRouter;

public interface RouteMatcher {
    AsyncHttpServerRouter.RouteMatch route(String str, String str2);
}
