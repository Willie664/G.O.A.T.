package io.lum.sdk.async.http.body;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.Multimap;
import io.lum.sdk.async.http.NameValuePair;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;

public class UrlEncodedFormBody implements AsyncHttpRequestBody<Multimap> {
    public static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
    public byte[] mBodyBytes;
    public Multimap mParameters;

    public UrlEncodedFormBody() {
    }

    public UrlEncodedFormBody(Multimap multimap) {
        this.mParameters = multimap;
    }

    public UrlEncodedFormBody(List<NameValuePair> list) {
        this.mParameters = new Multimap(list);
    }

    private void buildData() {
        StringBuilder sb = new StringBuilder();
        try {
            Iterator<NameValuePair> it = this.mParameters.iterator();
            boolean z = true;
            while (it.hasNext()) {
                NameValuePair next = it.next();
                if (next.getValue() != null) {
                    if (!z) {
                        sb.append('&');
                    }
                    z = false;
                    sb.append(URLEncoder.encode(next.getName(), "UTF-8"));
                    sb.append('=');
                    sb.append(URLEncoder.encode(next.getValue(), "UTF-8"));
                }
            }
            this.mBodyBytes = sb.toString().getBytes("UTF-8");
        } catch (UnsupportedEncodingException e2) {
            throw new AssertionError(e2);
        }
    }

    public Multimap get() {
        return this.mParameters;
    }

    public String getContentType() {
        return "application/x-www-form-urlencoded; charset=utf-8";
    }

    public int length() {
        if (this.mBodyBytes == null) {
            buildData();
        }
        return this.mBodyBytes.length;
    }

    public void parse(DataEmitter dataEmitter, final CompletedCallback completedCallback) {
        final ByteBufferList byteBufferList = new ByteBufferList();
        dataEmitter.setDataCallback(new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                byteBufferList.get(byteBufferList);
            }
        });
        dataEmitter.setEndCallback(new CompletedCallback() {
            public void onCompleted(Exception exc) {
                if (exc == null) {
                    try {
                        Multimap unused = UrlEncodedFormBody.this.mParameters = Multimap.parseUrlEncoded(byteBufferList.readString());
                        completedCallback.onCompleted((Exception) null);
                    } catch (Exception e2) {
                        completedCallback.onCompleted(e2);
                    }
                } else {
                    throw exc;
                }
            }
        });
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        if (this.mBodyBytes == null) {
            buildData();
        }
        Util.writeAll(dataSink, this.mBodyBytes, completedCallback);
    }
}
