package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import java.io.File;

public class FileBody implements AsyncHttpRequestBody<File> {
    public static final String CONTENT_TYPE = "application/binary";
    public String contentType = "application/binary";
    public File file;

    public FileBody(File file2) {
        this.file = file2;
    }

    public FileBody(File file2, String str) {
        this.file = file2;
        this.contentType = str;
    }

    public File get() {
        return this.file;
    }

    public String getContentType() {
        return this.contentType;
    }

    public int length() {
        return (int) this.file.length();
    }

    public void parse(DataEmitter dataEmitter, CompletedCallback completedCallback) {
        throw new AssertionError("not implemented");
    }

    public boolean readFullyOnRequest() {
        throw new AssertionError("not implemented");
    }

    public void setContentType(String str) {
        this.contentType = str;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        Util.pump(this.file, dataSink, completedCallback);
    }
}
