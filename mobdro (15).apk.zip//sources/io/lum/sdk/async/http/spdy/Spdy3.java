package io.lum.sdk.async.http.spdy;

import androidx.core.internal.view.SupportMenu;
import androidx.core.view.ViewCompat;
import b.a.a.a.a;
import io.lum.sdk.async.BufferedDataSink;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataEmitterReader;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.spdy.FrameReader;
import io.lum.sdk.async.util.Charsets;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ProtocolException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Locale;
import java.util.zip.Deflater;

public final class Spdy3 implements Variant {
    public static final byte[] DICTIONARY;
    public static final int FLAG_FIN = 1;
    public static final int FLAG_UNIDIRECTIONAL = 2;
    public static final int TYPE_DATA = 0;
    public static final int TYPE_GOAWAY = 7;
    public static final int TYPE_HEADERS = 8;
    public static final int TYPE_PING = 6;
    public static final int TYPE_RST_STREAM = 3;
    public static final int TYPE_SETTINGS = 4;
    public static final int TYPE_SYN_REPLY = 2;
    public static final int TYPE_SYN_STREAM = 1;
    public static final int TYPE_WINDOW_UPDATE = 9;
    public static final int VERSION = 3;

    public static final class Reader implements FrameReader {
        public final boolean client;
        public final DataEmitter emitter;
        public final ByteBufferList emptyList = new ByteBufferList();
        public int flags;
        public final FrameReader.Handler handler;
        public final HeaderReader headerReader = new HeaderReader();
        public boolean inFinished;
        public int length;
        public final DataCallback onDataFrame = new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                int min = Math.min(byteBufferList.remaining(), Reader.this.length);
                if (min < byteBufferList.remaining()) {
                    byteBufferList.get(Reader.this.partial, min);
                    byteBufferList = Reader.this.partial;
                }
                Reader reader = Reader.this;
                reader.length -= min;
                FrameReader.Handler access$400 = reader.handler;
                Reader reader2 = Reader.this;
                access$400.data(reader2.length == 0 && reader2.inFinished, Reader.this.streamId, byteBufferList);
                Reader reader3 = Reader.this;
                if (reader3.length == 0) {
                    reader3.parseFrameHeader();
                }
            }
        };
        public final DataCallback onFrame = new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                byteBufferList.order(ByteOrder.BIG_ENDIAN);
                Reader.this.w1 = byteBufferList.getInt();
                Reader.this.w2 = byteBufferList.getInt();
                boolean z = false;
                boolean z2 = (Reader.this.w1 & Integer.MIN_VALUE) != 0;
                Reader reader = Reader.this;
                int i = reader.w2;
                int i2 = (-16777216 & i) >>> 24;
                reader.flags = i2;
                reader.length = i & ViewCompat.MEASURED_SIZE_MASK;
                if (!z2) {
                    reader.streamId = reader.w1 & Integer.MAX_VALUE;
                    if ((i2 & 1) != 0) {
                        z = true;
                    }
                    reader.inFinished = z;
                    dataEmitter.setDataCallback(Reader.this.onDataFrame);
                    Reader reader2 = Reader.this;
                    if (reader2.length == 0) {
                        reader2.onDataFrame.onDataAvailable(dataEmitter, Reader.this.emptyList);
                        return;
                    }
                    return;
                }
                DataEmitterReader access$300 = reader.reader;
                Reader reader3 = Reader.this;
                access$300.read(reader3.length, reader3.onFullFrame);
            }
        };
        public final DataCallback onFullFrame = new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                byteBufferList.order(ByteOrder.BIG_ENDIAN);
                Reader reader = Reader.this;
                int i = reader.w1;
                int i2 = (2147418112 & i) >>> 16;
                int i3 = i & SupportMenu.USER_MASK;
                if (i2 == 3) {
                    switch (i3) {
                        case 1:
                            reader.readSynStream(byteBufferList, reader.flags, reader.length);
                            break;
                        case 2:
                            reader.readSynReply(byteBufferList, reader.flags, reader.length);
                            break;
                        case 3:
                            reader.readRstStream(byteBufferList, reader.flags, reader.length);
                            break;
                        case 4:
                            reader.readSettings(byteBufferList, reader.flags, reader.length);
                            break;
                        case 6:
                            reader.readPing(byteBufferList, reader.flags, reader.length);
                            break;
                        case 7:
                            reader.readGoAway(byteBufferList, reader.flags, reader.length);
                            break;
                        case 8:
                            reader.readHeaders(byteBufferList, reader.flags, reader.length);
                            break;
                        case 9:
                            reader.readWindowUpdate(byteBufferList, reader.flags, reader.length);
                            break;
                        default:
                            try {
                                byteBufferList.recycle();
                                break;
                            } catch (IOException e2) {
                                Reader.this.handler.error(e2);
                                return;
                            }
                    }
                    Reader.this.parseFrameHeader();
                    return;
                }
                throw new ProtocolException("version != 3: " + i2);
            }
        };
        public ByteBufferList partial = new ByteBufferList();
        public final DataEmitterReader reader;
        public int streamId;
        public int w1;
        public int w2;

        public Reader(DataEmitter dataEmitter, FrameReader.Handler handler2, boolean z) {
            this.emitter = dataEmitter;
            this.handler = handler2;
            this.client = z;
            dataEmitter.setEndCallback(new CompletedCallback() {
                public void onCompleted(Exception exc) {
                }
            });
            this.reader = new DataEmitterReader();
            parseFrameHeader();
        }

        public static IOException ioException(String str, Object... objArr) {
            throw new IOException(String.format(Locale.ENGLISH, str, objArr));
        }

        /* access modifiers changed from: private */
        public void parseFrameHeader() {
            this.emitter.setDataCallback(this.reader);
            this.reader.read(8, this.onFrame);
        }

        /* access modifiers changed from: private */
        public void readGoAway(ByteBufferList byteBufferList, int i, int i2) {
            if (i2 == 8) {
                int i3 = byteBufferList.getInt() & Integer.MAX_VALUE;
                int i4 = byteBufferList.getInt();
                ErrorCode fromSpdyGoAway = ErrorCode.fromSpdyGoAway(i4);
                if (fromSpdyGoAway != null) {
                    this.handler.goAway(i3, fromSpdyGoAway, ByteString.EMPTY);
                } else {
                    throw ioException("TYPE_GOAWAY unexpected error code: %d", Integer.valueOf(i4));
                }
            } else {
                throw ioException("TYPE_GOAWAY length: %d != 8", Integer.valueOf(i2));
            }
        }

        /* access modifiers changed from: private */
        public void readHeaders(ByteBufferList byteBufferList, int i, int i2) {
            this.handler.headers(false, false, byteBufferList.getInt() & Integer.MAX_VALUE, -1, this.headerReader.readHeader(byteBufferList, i2 - 4), HeadersMode.SPDY_HEADERS);
        }

        /* access modifiers changed from: private */
        public void readPing(ByteBufferList byteBufferList, int i, int i2) {
            boolean z = true;
            if (i2 == 4) {
                int i3 = byteBufferList.getInt();
                if (this.client != ((i3 & 1) == 1)) {
                    z = false;
                }
                this.handler.ping(z, i3, 0);
                return;
            }
            throw ioException("TYPE_PING length: %d != 4", Integer.valueOf(i2));
        }

        /* access modifiers changed from: private */
        public void readRstStream(ByteBufferList byteBufferList, int i, int i2) {
            if (i2 == 8) {
                int i3 = byteBufferList.getInt() & Integer.MAX_VALUE;
                int i4 = byteBufferList.getInt();
                ErrorCode fromSpdy3Rst = ErrorCode.fromSpdy3Rst(i4);
                if (fromSpdy3Rst != null) {
                    this.handler.rstStream(i3, fromSpdy3Rst);
                } else {
                    throw ioException("TYPE_RST_STREAM unexpected error code: %d", Integer.valueOf(i4));
                }
            } else {
                throw ioException("TYPE_RST_STREAM length: %d != 8", Integer.valueOf(i2));
            }
        }

        /* access modifiers changed from: private */
        public void readSettings(ByteBufferList byteBufferList, int i, int i2) {
            int i3 = byteBufferList.getInt();
            boolean z = false;
            if (i2 == (i3 * 8) + 4) {
                Settings settings = new Settings();
                for (int i4 = 0; i4 < i3; i4++) {
                    int i5 = byteBufferList.getInt();
                    int i6 = byteBufferList.getInt();
                    settings.set(i5 & ViewCompat.MEASURED_SIZE_MASK, (-16777216 & i5) >>> 24, i6);
                }
                if ((i & 1) != 0) {
                    z = true;
                }
                this.handler.settings(z, settings);
                return;
            }
            throw ioException("TYPE_SETTINGS length: %d != 4 + 8 * %d", Integer.valueOf(i2), Integer.valueOf(i3));
        }

        /* access modifiers changed from: private */
        public void readSynReply(ByteBufferList byteBufferList, int i, int i2) {
            this.handler.headers(false, (i & 1) != 0, byteBufferList.getInt() & Integer.MAX_VALUE, -1, this.headerReader.readHeader(byteBufferList, i2 - 4), HeadersMode.SPDY_REPLY);
        }

        /* access modifiers changed from: private */
        public void readSynStream(ByteBufferList byteBufferList, int i, int i2) {
            int i3 = byteBufferList.getInt() & Integer.MAX_VALUE;
            int i4 = byteBufferList.getInt() & Integer.MAX_VALUE;
            byteBufferList.getShort();
            List<Header> readHeader = this.headerReader.readHeader(byteBufferList, i2 - 10);
            this.handler.headers((i & 2) != 0, (i & 1) != 0, i3, i4, readHeader, HeadersMode.SPDY_SYN_STREAM);
        }

        /* access modifiers changed from: private */
        public void readWindowUpdate(ByteBufferList byteBufferList, int i, int i2) {
            if (i2 == 8) {
                int i3 = byteBufferList.getInt() & Integer.MAX_VALUE;
                long j = (long) (byteBufferList.getInt() & Integer.MAX_VALUE);
                if (j != 0) {
                    this.handler.windowUpdate(i3, j);
                } else {
                    throw ioException("windowSizeIncrement was 0", Long.valueOf(j));
                }
            } else {
                throw ioException("TYPE_WINDOW_UPDATE length: %d != 8", Integer.valueOf(i2));
            }
        }
    }

    public static final class Writer implements FrameWriter {
        public final boolean client;
        public boolean closed;
        public ByteBufferList dataList = new ByteBufferList();
        public final Deflater deflater = new Deflater();
        public ByteBufferList frameHeader = new ByteBufferList();
        public ByteBufferList headerBlockList = new ByteBufferList();
        public final BufferedDataSink sink;

        public Writer(BufferedDataSink bufferedDataSink, boolean z) {
            this.sink = bufferedDataSink;
            this.client = z;
            this.deflater.setDictionary(Spdy3.DICTIONARY);
        }

        private ByteBufferList writeNameValueBlockToBuffer(List<Header> list) {
            if (!this.headerBlockList.hasRemaining()) {
                ByteBuffer order = ByteBufferList.obtain(8192).order(ByteOrder.BIG_ENDIAN);
                order.putInt(list.size());
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ByteString byteString = list.get(i).name;
                    order.putInt(byteString.size());
                    order.put(byteString.toByteArray());
                    ByteString byteString2 = list.get(i).value;
                    order.putInt(byteString2.size());
                    order.put(byteString2.toByteArray());
                    if (order.remaining() < order.capacity() / 2) {
                        ByteBuffer order2 = ByteBufferList.obtain(order.capacity() * 2).order(ByteOrder.BIG_ENDIAN);
                        order.flip();
                        order2.put(order);
                        ByteBufferList.reclaim(order);
                        order = order2;
                    }
                }
                order.flip();
                this.deflater.setInput(order.array(), 0, order.remaining());
                while (!this.deflater.needsInput()) {
                    ByteBuffer order3 = ByteBufferList.obtain(order.capacity()).order(ByteOrder.BIG_ENDIAN);
                    order3.limit(this.deflater.deflate(order3.array(), 0, order3.capacity(), 2));
                    this.headerBlockList.add(order3);
                }
                ByteBufferList.reclaim(order);
                return this.headerBlockList;
            }
            throw new IllegalStateException();
        }

        public void ackSettings() {
        }

        public synchronized void close() {
            this.closed = true;
        }

        public synchronized void connectionPreface() {
        }

        public synchronized void data(boolean z, int i, ByteBufferList byteBufferList) {
            sendDataFrame(i, z ? 1 : 0, byteBufferList);
        }

        public synchronized void goAway(int i, ErrorCode errorCode, byte[] bArr) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.spdyGoAwayCode != -1) {
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287033);
                order.putInt(8);
                order.putInt(i);
                order.putInt(errorCode.spdyGoAwayCode);
                order.flip();
                this.sink.write(this.frameHeader.addAll(order));
            } else {
                throw new IllegalArgumentException("errorCode.spdyGoAwayCode == -1");
            }
        }

        public synchronized void headers(int i, List<Header> list) {
            if (!this.closed) {
                ByteBufferList writeNameValueBlockToBuffer = writeNameValueBlockToBuffer(list);
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287032);
                order.putInt(((writeNameValueBlockToBuffer.remaining() + 4) & ViewCompat.MEASURED_SIZE_MASK) | 0);
                order.putInt(i & Integer.MAX_VALUE);
                order.flip();
                this.sink.write(this.frameHeader.add(order).add(writeNameValueBlockToBuffer));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void ping(boolean z, int i, int i2) {
            if (!this.closed) {
                if (z == (this.client != ((i & 1) == 1))) {
                    ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                    order.putInt(-2147287034);
                    order.putInt(4);
                    order.putInt(i);
                    order.flip();
                    this.sink.write(this.frameHeader.addAll(order));
                } else {
                    throw new IllegalArgumentException("payload != reply");
                }
            } else {
                throw new IOException("closed");
            }
        }

        public void pushPromise(int i, int i2, List<Header> list) {
        }

        public synchronized void rstStream(int i, ErrorCode errorCode) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (errorCode.spdyRstCode != -1) {
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287037);
                order.putInt(8);
                order.putInt(i & Integer.MAX_VALUE);
                order.putInt(errorCode.spdyRstCode);
                order.flip();
                this.sink.write(this.frameHeader.addAll(order));
            } else {
                throw new IllegalArgumentException();
            }
        }

        public void sendDataFrame(int i, int i2, ByteBufferList byteBufferList) {
            if (!this.closed) {
                int remaining = byteBufferList.remaining();
                if (((long) remaining) <= 16777215) {
                    ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                    order.putInt(i & Integer.MAX_VALUE);
                    order.putInt(((i2 & 255) << 24) | (16777215 & remaining));
                    order.flip();
                    this.dataList.add(order).add(byteBufferList);
                    this.sink.write(this.dataList);
                    return;
                }
                throw new IllegalArgumentException(a.b("FRAME_TOO_LARGE max size is 16Mib: ", remaining));
            }
            throw new IOException("closed");
        }

        public synchronized void settings(Settings settings) {
            if (!this.closed) {
                int size = settings.size();
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287036);
                order.putInt((((size * 8) + 4) & ViewCompat.MEASURED_SIZE_MASK) | 0);
                order.putInt(size);
                for (int i = 0; i <= 10; i++) {
                    if (settings.isSet(i)) {
                        order.putInt(((settings.flags(i) & 255) << 24) | (i & ViewCompat.MEASURED_SIZE_MASK));
                        order.putInt(settings.get(i));
                    }
                }
                order.flip();
                this.sink.write(this.frameHeader.addAll(order));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synReply(boolean z, int i, List<Header> list) {
            if (!this.closed) {
                ByteBufferList writeNameValueBlockToBuffer = writeNameValueBlockToBuffer(list);
                int i2 = z ? 1 : 0;
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287038);
                order.putInt(((i2 & 255) << 24) | ((writeNameValueBlockToBuffer.remaining() + 4) & ViewCompat.MEASURED_SIZE_MASK));
                order.putInt(Integer.MAX_VALUE & i);
                order.flip();
                this.sink.write(this.frameHeader.add(order).add(writeNameValueBlockToBuffer));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void synStream(boolean z, boolean z2, int i, int i2, List<Header> list) {
            if (!this.closed) {
                ByteBufferList writeNameValueBlockToBuffer = writeNameValueBlockToBuffer(list);
                int remaining = writeNameValueBlockToBuffer.remaining() + 10;
                boolean z3 = z | (z2 ? (char) 2 : 0);
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287039);
                order.putInt(((z3 & true ? 1 : 0) << true) | (remaining & ViewCompat.MEASURED_SIZE_MASK));
                order.putInt(i & Integer.MAX_VALUE);
                order.putInt(Integer.MAX_VALUE & i2);
                order.putShort((short) 0);
                order.flip();
                this.sink.write(this.frameHeader.add(order).add(writeNameValueBlockToBuffer));
            } else {
                throw new IOException("closed");
            }
        }

        public synchronized void windowUpdate(int i, long j) {
            if (this.closed) {
                throw new IOException("closed");
            } else if (j == 0 || j > 2147483647L) {
                throw new IllegalArgumentException("windowSizeIncrement must be between 1 and 0x7fffffff: " + j);
            } else {
                ByteBuffer order = ByteBufferList.obtain(256).order(ByteOrder.BIG_ENDIAN);
                order.putInt(-2147287031);
                order.putInt(8);
                order.putInt(i);
                order.putInt((int) j);
                order.flip();
                this.sink.write(this.frameHeader.addAll(order));
            }
        }
    }

    static {
        try {
            DICTIONARY = "\u0000\u0000\u0000\u0007options\u0000\u0000\u0000\u0004head\u0000\u0000\u0000\u0004post\u0000\u0000\u0000\u0003put\u0000\u0000\u0000\u0006delete\u0000\u0000\u0000\u0005trace\u0000\u0000\u0000\u0006accept\u0000\u0000\u0000\u000eaccept-charset\u0000\u0000\u0000\u000faccept-encoding\u0000\u0000\u0000\u000faccept-language\u0000\u0000\u0000\raccept-ranges\u0000\u0000\u0000\u0003age\u0000\u0000\u0000\u0005allow\u0000\u0000\u0000\rauthorization\u0000\u0000\u0000\rcache-control\u0000\u0000\u0000\nconnection\u0000\u0000\u0000\fcontent-base\u0000\u0000\u0000\u0010content-encoding\u0000\u0000\u0000\u0010content-language\u0000\u0000\u0000\u000econtent-length\u0000\u0000\u0000\u0010content-location\u0000\u0000\u0000\u000bcontent-md5\u0000\u0000\u0000\rcontent-range\u0000\u0000\u0000\fcontent-type\u0000\u0000\u0000\u0004date\u0000\u0000\u0000\u0004etag\u0000\u0000\u0000\u0006expect\u0000\u0000\u0000\u0007expires\u0000\u0000\u0000\u0004from\u0000\u0000\u0000\u0004host\u0000\u0000\u0000\bif-match\u0000\u0000\u0000\u0011if-modified-since\u0000\u0000\u0000\rif-none-match\u0000\u0000\u0000\bif-range\u0000\u0000\u0000\u0013if-unmodified-since\u0000\u0000\u0000\rlast-modified\u0000\u0000\u0000\blocation\u0000\u0000\u0000\fmax-forwards\u0000\u0000\u0000\u0006pragma\u0000\u0000\u0000\u0012proxy-authenticate\u0000\u0000\u0000\u0013proxy-authorization\u0000\u0000\u0000\u0005range\u0000\u0000\u0000\u0007referer\u0000\u0000\u0000\u000bretry-after\u0000\u0000\u0000\u0006server\u0000\u0000\u0000\u0002te\u0000\u0000\u0000\u0007trailer\u0000\u0000\u0000\u0011transfer-encoding\u0000\u0000\u0000\u0007upgrade\u0000\u0000\u0000\nuser-agent\u0000\u0000\u0000\u0004vary\u0000\u0000\u0000\u0003via\u0000\u0000\u0000\u0007warning\u0000\u0000\u0000\u0010www-authenticate\u0000\u0000\u0000\u0006method\u0000\u0000\u0000\u0003get\u0000\u0000\u0000\u0006status\u0000\u0000\u0000\u0006200 OK\u0000\u0000\u0000\u0007version\u0000\u0000\u0000\bHTTP/1.1\u0000\u0000\u0000\u0003url\u0000\u0000\u0000\u0006public\u0000\u0000\u0000\nset-cookie\u0000\u0000\u0000\nkeep-alive\u0000\u0000\u0000\u0006origin100101201202205206300302303304305306307402405406407408409410411412413414415416417502504505203 Non-Authoritative Information204 No Content301 Moved Permanently400 Bad Request401 Unauthorized403 Forbidden404 Not Found500 Internal Server Error501 Not Implemented503 Service UnavailableJan Feb Mar Apr May Jun Jul Aug Sept Oct Nov Dec 00:00:00 Mon, Tue, Wed, Thu, Fri, Sat, Sun, GMTchunked,text/html,image/png,image/jpg,image/gif,application/xml,application/xhtml+xml,text/plain,text/javascript,publicprivatemax-age=gzip,deflate,sdchcharset=utf-8charset=iso-8859-1,utf-,*,enq=0.".getBytes(Charsets.UTF_8.name());
        } catch (UnsupportedEncodingException unused) {
            throw new AssertionError();
        }
    }

    public Protocol getProtocol() {
        return Protocol.SPDY_3;
    }

    public int maxFrameSize() {
        return Http20Draft13.MAX_FRAME_SIZE;
    }

    public FrameReader newReader(DataEmitter dataEmitter, FrameReader.Handler handler, boolean z) {
        return new Reader(dataEmitter, handler, z);
    }

    public FrameWriter newWriter(BufferedDataSink bufferedDataSink, boolean z) {
        return new Writer(bufferedDataSink, z);
    }
}
