package io.lum.sdk.async.http.body;

import io.lum.sdk.async.http.NameValuePair;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;

public class StringPart extends StreamPart {
    public String value;

    public StringPart(String str, String str2) {
        super(str, (long) str2.getBytes().length, (List<NameValuePair>) null);
        this.value = str2;
    }

    public InputStream getInputStream() {
        return new ByteArrayInputStream(this.value.getBytes());
    }

    public String getValue() {
        return this.value;
    }

    public String toString() {
        return this.value;
    }
}
