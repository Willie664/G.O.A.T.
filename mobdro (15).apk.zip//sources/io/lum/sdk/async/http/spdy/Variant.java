package io.lum.sdk.async.http.spdy;

import io.lum.sdk.async.BufferedDataSink;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.http.Protocol;
import io.lum.sdk.async.http.spdy.FrameReader;

public interface Variant {
    Protocol getProtocol();

    int maxFrameSize();

    FrameReader newReader(DataEmitter dataEmitter, FrameReader.Handler handler, boolean z);

    FrameWriter newWriter(BufferedDataSink bufferedDataSink, boolean z);
}
