package io.lum.sdk.async.http.server;

import io.lum.sdk.async.http.Headers;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;

public interface AsyncHttpRequestBodyProvider {
    AsyncHttpRequestBody getBody(Headers headers);
}
