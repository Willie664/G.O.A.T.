package io.lum.sdk.async.http.body;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.parser.JSONArrayParser;
import org.json.JSONArray;

public class JSONArrayBody implements AsyncHttpRequestBody<JSONArray> {
    public static final String CONTENT_TYPE = "application/json";
    public JSONArray json;
    public byte[] mBodyBytes;

    public JSONArrayBody() {
    }

    public JSONArrayBody(JSONArray jSONArray) {
        this();
        this.json = jSONArray;
    }

    public JSONArray get() {
        return this.json;
    }

    public String getContentType() {
        return "application/json";
    }

    public int length() {
        byte[] bytes = this.json.toString().getBytes();
        this.mBodyBytes = bytes;
        return bytes.length;
    }

    public void parse(DataEmitter dataEmitter, final CompletedCallback completedCallback) {
        new JSONArrayParser().parse(dataEmitter).setCallback(new FutureCallback<JSONArray>() {
            public void onCompleted(Exception exc, JSONArray jSONArray) {
                JSONArrayBody.this.json = jSONArray;
                completedCallback.onCompleted(exc);
            }
        });
    }

    public boolean readFullyOnRequest() {
        return true;
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        Util.writeAll(dataSink, this.mBodyBytes, completedCallback);
    }
}
