package io.lum.sdk.async.http;

import android.net.Uri;
import android.text.TextUtils;
import b.a.a.a.a;
import d.a.a.b2.v.f;
import io.lum.sdk.async.AsyncSSLSocket;
import io.lum.sdk.async.AsyncSSLSocketWrapper;
import io.lum.sdk.async.AsyncSocket;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.LineEmitter;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.ConnectCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.AsyncHttpClientMiddleware;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

public class AsyncSSLSocketMiddleware extends AsyncSocketMiddleware {
    public List<AsyncSSLEngineConfigurator> engineConfigurators = new ArrayList();
    public HostnameVerifier hostnameVerifier;
    public SSLContext sslContext;
    public TrustManager[] trustManagers;

    public AsyncSSLSocketMiddleware(AsyncHttpClient asyncHttpClient) {
        super(asyncHttpClient, "https", 443);
    }

    public void addEngineConfigurator(AsyncSSLEngineConfigurator asyncSSLEngineConfigurator) {
        this.engineConfigurators.add(asyncSSLEngineConfigurator);
    }

    public void clearEngineConfigurators() {
        this.engineConfigurators.clear();
    }

    /* JADX WARNING: Removed duplicated region for block: B:1:0x000b A[LOOP:0: B:1:0x000b->B:4:0x001b, LOOP_START, PHI: r2 
      PHI: (r2v1 javax.net.ssl.SSLEngine) = (r2v0 javax.net.ssl.SSLEngine), (r2v5 javax.net.ssl.SSLEngine) binds: [B:0:0x0000, B:4:0x001b] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public javax.net.ssl.SSLEngine createConfiguredSSLEngine(io.lum.sdk.async.http.AsyncHttpClientMiddleware.GetSocketData r5, java.lang.String r6, int r7) {
        /*
            r4 = this;
            javax.net.ssl.SSLContext r0 = r4.getSSLContext()
            java.util.List<io.lum.sdk.async.http.AsyncSSLEngineConfigurator> r1 = r4.engineConfigurators
            java.util.Iterator r1 = r1.iterator()
            r2 = 0
        L_0x000b:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x001d
            java.lang.Object r2 = r1.next()
            io.lum.sdk.async.http.AsyncSSLEngineConfigurator r2 = (io.lum.sdk.async.http.AsyncSSLEngineConfigurator) r2
            javax.net.ssl.SSLEngine r2 = r2.createEngine(r0, r6, r7)
            if (r2 == 0) goto L_0x000b
        L_0x001d:
            java.util.List<io.lum.sdk.async.http.AsyncSSLEngineConfigurator> r0 = r4.engineConfigurators
            java.util.Iterator r0 = r0.iterator()
        L_0x0023:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0033
            java.lang.Object r1 = r0.next()
            io.lum.sdk.async.http.AsyncSSLEngineConfigurator r1 = (io.lum.sdk.async.http.AsyncSSLEngineConfigurator) r1
            r1.configureEngine(r2, r5, r6, r7)
            goto L_0x0023
        L_0x0033:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.async.http.AsyncSSLSocketMiddleware.createConfiguredSSLEngine(io.lum.sdk.async.http.AsyncHttpClientMiddleware$GetSocketData, java.lang.String, int):javax.net.ssl.SSLEngine");
    }

    public AsyncSSLSocketWrapper.HandshakeCallback createHandshakeCallback(AsyncHttpClientMiddleware.GetSocketData getSocketData, final ConnectCallback connectCallback) {
        return new AsyncSSLSocketWrapper.HandshakeCallback() {
            public void onHandshakeCompleted(Exception exc, AsyncSSLSocket asyncSSLSocket) {
                connectCallback.onConnectCompleted(exc, asyncSSLSocket);
            }
        };
    }

    public SSLContext getSSLContext() {
        SSLContext sSLContext = this.sslContext;
        return sSLContext != null ? sSLContext : AsyncSSLSocketWrapper.getDefaultSSLContext();
    }

    public void setHostnameVerifier(HostnameVerifier hostnameVerifier2) {
        this.hostnameVerifier = hostnameVerifier2;
    }

    public void setSSLContext(SSLContext sSLContext) {
        this.sslContext = sSLContext;
    }

    public void setTrustManagers(TrustManager[] trustManagerArr) {
        this.trustManagers = trustManagerArr;
    }

    public void tryHandshake(AsyncSocket asyncSocket, AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, ConnectCallback connectCallback) {
        AsyncSSLSocketWrapper.handshake(asyncSocket, uri.getHost(), i, createConfiguredSSLEngine(getSocketData, uri.getHost(), i), this.trustManagers, this.hostnameVerifier, true, createHandshakeCallback(getSocketData, connectCallback));
    }

    public ConnectCallback wrapCallback(AsyncHttpClientMiddleware.GetSocketData getSocketData, Uri uri, int i, boolean z, ConnectCallback connectCallback) {
        final ConnectCallback connectCallback2 = connectCallback;
        final boolean z2 = z;
        final AsyncHttpClientMiddleware.GetSocketData getSocketData2 = getSocketData;
        final Uri uri2 = uri;
        final int i2 = i;
        return new ConnectCallback() {
            public /* synthetic */ void a(AsyncHttpClientMiddleware.GetSocketData getSocketData, Exception exc, AsyncSocket asyncSocket) {
                if (exc == null) {
                    getSocketData.request.logi("Proxy handshake complete");
                    getSocketData.request.set_proxy_connected();
                }
                onConnectCompleted(exc, asyncSocket);
            }

            public void onConnectCompleted(Exception exc, final AsyncSocket asyncSocket) {
                if (exc != null) {
                    connectCallback2.onConnectCompleted(exc, asyncSocket);
                } else if (!z2) {
                    AsyncSSLSocketMiddleware.this.tryHandshake(asyncSocket, getSocketData2, uri2, i2, connectCallback2);
                } else if (!getSocketData2.request.get_proxy_connected()) {
                    Uri uri = getSocketData2.request.get_proxy_domain_uri();
                    int proxyPort = getSocketData2.request.getProxyPort();
                    AsyncSSLSocketMiddleware asyncSSLSocketMiddleware = AsyncSSLSocketMiddleware.this;
                    AsyncHttpClientMiddleware.GetSocketData getSocketData = getSocketData2;
                    asyncSSLSocketMiddleware.tryHandshake(asyncSocket, getSocketData, uri, proxyPort, new f(this, getSocketData));
                } else {
                    Headers headers = new Headers();
                    headers.addAll(getSocketData2.request.get_connect_headers());
                    if (headers.get("Host") == null) {
                        headers.set("Host", uri2.getHost());
                    }
                    String format = String.format(Locale.ENGLISH, "CONNECT %s:%s HTTP/1.1\r\n%s", new Object[]{getSocketData2.request.getUri().getHost(), Integer.valueOf(i2), headers.toStringBuilder().toString()});
                    AsyncHttpRequest asyncHttpRequest = getSocketData2.request;
                    asyncHttpRequest.logv("Proxying: " + format);
                    Util.writeAll((DataSink) asyncSocket, format.getBytes(), (CompletedCallback) new CompletedCallback() {
                        public void onCompleted(Exception exc) {
                            if (exc != null) {
                                connectCallback2.onConnectCompleted(exc, asyncSocket);
                                return;
                            }
                            LineEmitter lineEmitter = new LineEmitter();
                            lineEmitter.setLineCallback(new LineEmitter.StringCallback() {
                                public String statusLine;

                                public void onStringAvailable(String str) {
                                    getSocketData2.request.logv(str);
                                    String str2 = this.statusLine;
                                    String trim = str.trim();
                                    if (str2 == null) {
                                        this.statusLine = trim;
                                        if (!trim.matches("HTTP/1.\\d 2\\d\\d .*")) {
                                            asyncSocket.setDataCallback((DataCallback) null);
                                            asyncSocket.setEndCallback((CompletedCallback) null);
                                            ConnectCallback connectCallback = connectCallback2;
                                            StringBuilder a2 = a.a("non 2xx status line: ");
                                            a2.append(this.statusLine);
                                            connectCallback.onConnectCompleted(new IOException(a2.toString()), asyncSocket);
                                        }
                                    } else if (TextUtils.isEmpty(trim)) {
                                        asyncSocket.setDataCallback((DataCallback) null);
                                        asyncSocket.setEndCallback((CompletedCallback) null);
                                        AnonymousClass1 r8 = AnonymousClass1.this;
                                        AnonymousClass2 r0 = AnonymousClass2.this;
                                        AsyncSSLSocketMiddleware.this.tryHandshake(asyncSocket, getSocketData2, uri2, i2, connectCallback2);
                                    }
                                }
                            });
                            asyncSocket.setDataCallback(lineEmitter);
                            asyncSocket.setEndCallback(new CompletedCallback() {
                                public void onCompleted(Exception exc) {
                                    if (!asyncSocket.isOpen() && exc == null) {
                                        exc = new IOException("socket closed before proxy connect response");
                                    }
                                    AnonymousClass1 r0 = AnonymousClass1.this;
                                    connectCallback2.onConnectCompleted(exc, asyncSocket);
                                }
                            });
                        }
                    });
                }
            }
        };
    }
}
