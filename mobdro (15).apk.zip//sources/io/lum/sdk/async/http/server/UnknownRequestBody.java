package io.lum.sdk.async.http.server;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.body.AsyncHttpRequestBody;

public class UnknownRequestBody implements AsyncHttpRequestBody<Void> {
    public DataEmitter emitter;
    public int length = -1;
    public String mContentType;

    public UnknownRequestBody(DataEmitter dataEmitter, String str, int i) {
        this.mContentType = str;
        this.emitter = dataEmitter;
        this.length = i;
    }

    public UnknownRequestBody(String str) {
        this.mContentType = str;
    }

    public Void get() {
        return null;
    }

    public String getContentType() {
        return this.mContentType;
    }

    public DataEmitter getEmitter() {
        return this.emitter;
    }

    public int length() {
        return this.length;
    }

    public void parse(DataEmitter dataEmitter, CompletedCallback completedCallback) {
        this.emitter = dataEmitter;
        dataEmitter.setEndCallback(completedCallback);
        dataEmitter.setDataCallback(new DataCallback.NullDataCallback());
    }

    public boolean readFullyOnRequest() {
        return false;
    }

    @Deprecated
    public void setCallbacks(DataCallback dataCallback, CompletedCallback completedCallback) {
        this.emitter.setEndCallback(completedCallback);
        this.emitter.setDataCallback(dataCallback);
    }

    public void write(AsyncHttpRequest asyncHttpRequest, DataSink dataSink, CompletedCallback completedCallback) {
        Util.pump(this.emitter, dataSink, completedCallback);
        if (this.emitter.isPaused()) {
            this.emitter.resume();
        }
    }
}
