package io.lum.sdk.async.callback;

import io.lum.sdk.async.AsyncServerSocket;
import io.lum.sdk.async.AsyncSocket;

public interface ListenCallback extends CompletedCallback {
    void onAccepted(AsyncSocket asyncSocket);

    void onListening(AsyncServerSocket asyncServerSocket);
}
