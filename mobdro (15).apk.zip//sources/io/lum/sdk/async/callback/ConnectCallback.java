package io.lum.sdk.async.callback;

import io.lum.sdk.async.AsyncSocket;

public interface ConnectCallback {
    void onConnectCompleted(Exception exc, AsyncSocket asyncSocket);
}
