package io.lum.sdk.async.callback;

public interface WritableCallback {
    void onWriteable();
}
