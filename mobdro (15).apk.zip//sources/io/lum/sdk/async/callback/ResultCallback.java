package io.lum.sdk.async.callback;

public interface ResultCallback<S, T> {
    void onCompleted(Exception exc, S s, T t);
}
