package io.lum.sdk.async.callback;

import io.lum.sdk.async.future.Continuation;

public interface ContinuationCallback {
    void onContinue(Continuation continuation, CompletedCallback completedCallback);
}
