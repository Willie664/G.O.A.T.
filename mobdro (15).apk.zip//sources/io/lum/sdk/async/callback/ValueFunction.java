package io.lum.sdk.async.callback;

public interface ValueFunction<T> {
    T getValue();
}
