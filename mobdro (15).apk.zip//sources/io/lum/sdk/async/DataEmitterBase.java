package io.lum.sdk.async;

import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;

public abstract class DataEmitterBase implements DataEmitter {
    public CompletedCallback endCallback;
    public boolean ended;
    public DataCallback mDataCallback;

    public String charset() {
        return null;
    }

    public DataCallback getDataCallback() {
        return this.mDataCallback;
    }

    public final CompletedCallback getEndCallback() {
        return this.endCallback;
    }

    public void report(Exception exc) {
        if (!this.ended) {
            this.ended = true;
            if (getEndCallback() != null) {
                getEndCallback().onCompleted(exc);
            }
        }
    }

    public void setDataCallback(DataCallback dataCallback) {
        this.mDataCallback = dataCallback;
    }

    public final void setEndCallback(CompletedCallback completedCallback) {
        this.endCallback = completedCallback;
    }
}
