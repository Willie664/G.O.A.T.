package io.lum.sdk.async.parser;

import d.a.a.b2.w.b;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

public class StringParser implements AsyncParser<String> {
    public Charset forcedCharset;

    public StringParser() {
    }

    public StringParser(Charset charset) {
        this.forcedCharset = charset;
    }

    public /* synthetic */ String a(String str, ByteBufferList byteBufferList) {
        Charset charset = this.forcedCharset;
        if (charset == null && str != null) {
            charset = Charset.forName(str);
        }
        return byteBufferList.readString(charset);
    }

    public String getMime() {
        return null;
    }

    public Type getType() {
        return String.class;
    }

    public Future<String> parse(DataEmitter dataEmitter) {
        return new ByteBufferListParser().parse(dataEmitter).thenConvert(new b(this, dataEmitter.charset()));
    }

    public void write(DataSink dataSink, String str, CompletedCallback completedCallback) {
        new ByteBufferListParser().write(dataSink, new ByteBufferList(str.getBytes()), completedCallback);
    }
}
