package io.lum.sdk.async.parser;

import d.a.a.b2.w.c;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import java.lang.reflect.Type;
import org.json.JSONObject;

public class JSONObjectParser implements AsyncParser<JSONObject> {
    public String getMime() {
        return "application/json";
    }

    public Type getType() {
        return JSONObject.class;
    }

    public Future<JSONObject> parse(DataEmitter dataEmitter) {
        return new StringParser().parse(dataEmitter).thenConvert(c.f7225a);
    }

    public void write(DataSink dataSink, JSONObject jSONObject, CompletedCallback completedCallback) {
        new StringParser().write(dataSink, jSONObject.toString(), completedCallback);
    }
}
