package io.lum.sdk.async.parser;

import d.a.a.b2.w.d;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import java.lang.reflect.Type;
import org.json.JSONArray;

public class JSONArrayParser implements AsyncParser<JSONArray> {
    public String getMime() {
        return "application/json";
    }

    public Type getType() {
        return JSONArray.class;
    }

    public Future<JSONArray> parse(DataEmitter dataEmitter) {
        return new StringParser().parse(dataEmitter).thenConvert(d.f7226a);
    }

    public void write(DataSink dataSink, JSONArray jSONArray, CompletedCallback completedCallback) {
        new StringParser().write(dataSink, jSONArray.toString(), completedCallback);
    }
}
