package io.lum.sdk.async.parser;

import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import java.lang.reflect.Type;

public interface AsyncParser<T> {
    String getMime();

    Type getType();

    Future<T> parse(DataEmitter dataEmitter);

    void write(DataSink dataSink, T t, CompletedCallback completedCallback);
}
