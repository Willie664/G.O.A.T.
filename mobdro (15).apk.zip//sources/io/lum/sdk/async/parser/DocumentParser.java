package io.lum.sdk.async.parser;

import d.a.a.b2.w.a;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.http.AsyncHttpRequest;
import io.lum.sdk.async.http.body.DocumentBody;
import java.lang.reflect.Type;
import org.w3c.dom.Document;

public class DocumentParser implements AsyncParser<Document> {
    public String getMime() {
        return "text/xml";
    }

    public Type getType() {
        return Document.class;
    }

    public Future<Document> parse(DataEmitter dataEmitter) {
        return new ByteBufferListParser().parse(dataEmitter).thenConvert(a.f7222a);
    }

    public void write(DataSink dataSink, Document document, CompletedCallback completedCallback) {
        new DocumentBody(document).write((AsyncHttpRequest) null, dataSink, completedCallback);
    }
}
