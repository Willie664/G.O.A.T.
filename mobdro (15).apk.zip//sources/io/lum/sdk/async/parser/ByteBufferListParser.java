package io.lum.sdk.async.parser;

import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.DataSink;
import io.lum.sdk.async.Util;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.SimpleFuture;
import java.lang.reflect.Type;

public class ByteBufferListParser implements AsyncParser<ByteBufferList> {
    public String getMime() {
        return null;
    }

    public Type getType() {
        return ByteBufferList.class;
    }

    public Future<ByteBufferList> parse(final DataEmitter dataEmitter) {
        final ByteBufferList byteBufferList = new ByteBufferList();
        final AnonymousClass1 r1 = new SimpleFuture<ByteBufferList>() {
            public void cancelCleanup() {
                dataEmitter.close();
            }
        };
        dataEmitter.setDataCallback(new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                byteBufferList.get(byteBufferList);
            }
        });
        dataEmitter.setEndCallback(new CompletedCallback() {
            public void onCompleted(Exception exc) {
                if (exc != null) {
                    r1.setComplete(exc);
                    return;
                }
                try {
                    r1.setComplete(byteBufferList);
                } catch (Exception e2) {
                    r1.setComplete(e2);
                }
            }
        });
        return r1;
    }

    public void write(DataSink dataSink, ByteBufferList byteBufferList, CompletedCallback completedCallback) {
        Util.writeAll(dataSink, byteBufferList, completedCallback);
    }
}
