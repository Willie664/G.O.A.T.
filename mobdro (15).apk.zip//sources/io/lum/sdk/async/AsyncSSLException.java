package io.lum.sdk.async;

public class AsyncSSLException extends Exception {
    public boolean mIgnore = false;

    public AsyncSSLException(Throwable th) {
        super("Peer not trusted by any of the system trust managers.", th);
    }

    public boolean getIgnore() {
        return this.mIgnore;
    }

    public void setIgnore(boolean z) {
        this.mIgnore = z;
    }
}
