package io.lum.sdk.async;

import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;

public interface DataEmitter {
    String charset();

    void close();

    DataCallback getDataCallback();

    CompletedCallback getEndCallback();

    AsyncServer getServer();

    boolean isChunked();

    boolean isPaused();

    void pause();

    void resume();

    void setDataCallback(DataCallback dataCallback);

    void setEndCallback(CompletedCallback completedCallback);
}
