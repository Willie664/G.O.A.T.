package io.lum.sdk.async;

import io.lum.sdk.async.DataTrackingEmitter;
import io.lum.sdk.async.callback.CompletedCallback;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.wrapper.DataEmitterWrapper;

public class FilteredDataEmitter extends DataEmitterBase implements DataEmitter, DataTrackingEmitter, DataCallback, DataEmitterWrapper {
    public boolean closed;
    public DataEmitter mEmitter;
    public int totalRead;
    public DataTrackingEmitter.DataTracker tracker;

    public String charset() {
        DataEmitter dataEmitter = this.mEmitter;
        if (dataEmitter == null) {
            return null;
        }
        return dataEmitter.charset();
    }

    public void close() {
        this.closed = true;
        DataEmitter dataEmitter = this.mEmitter;
        if (dataEmitter != null) {
            dataEmitter.close();
        }
    }

    public int getBytesRead() {
        return this.totalRead;
    }

    public DataEmitter getDataEmitter() {
        return this.mEmitter;
    }

    public DataTrackingEmitter.DataTracker getDataTracker() {
        return this.tracker;
    }

    public AsyncServer getServer() {
        return this.mEmitter.getServer();
    }

    public boolean isChunked() {
        return this.mEmitter.isChunked();
    }

    public boolean isPaused() {
        return this.mEmitter.isPaused();
    }

    public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
        if (this.closed) {
            byteBufferList.recycle();
            return;
        }
        if (byteBufferList != null) {
            this.totalRead = byteBufferList.remaining() + this.totalRead;
        }
        Util.emitAllData(this, byteBufferList);
        if (byteBufferList != null) {
            this.totalRead -= byteBufferList.remaining();
        }
        DataTrackingEmitter.DataTracker dataTracker = this.tracker;
        if (dataTracker != null && byteBufferList != null) {
            dataTracker.onData(this.totalRead);
        }
    }

    public void pause() {
        this.mEmitter.pause();
    }

    public void resume() {
        this.mEmitter.resume();
    }

    public void setDataEmitter(DataEmitter dataEmitter) {
        DataEmitter dataEmitter2 = this.mEmitter;
        if (dataEmitter2 != null) {
            dataEmitter2.setDataCallback((DataCallback) null);
        }
        this.mEmitter = dataEmitter;
        dataEmitter.setDataCallback(this);
        this.mEmitter.setEndCallback(new CompletedCallback() {
            public void onCompleted(Exception exc) {
                FilteredDataEmitter.this.report(exc);
            }
        });
    }

    public void setDataTracker(DataTrackingEmitter.DataTracker dataTracker) {
        this.tracker = dataTracker;
    }
}
