package io.lum.sdk.async;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

public class ServerSocketChannelWrapper extends ChannelWrapper {
    public static final /* synthetic */ boolean $assertionsDisabled = false;
    public ServerSocketChannel mChannel;

    static {
        Class<ServerSocketChannelWrapper> cls = ServerSocketChannelWrapper.class;
    }

    public ServerSocketChannelWrapper(ServerSocketChannel serverSocketChannel) {
        super(serverSocketChannel);
        this.mChannel = serverSocketChannel;
    }

    public InetAddress getLocalAddress() {
        return this.mChannel.socket().getInetAddress();
    }

    public int getLocalPort() {
        return this.mChannel.socket().getLocalPort();
    }

    public Object getSocket() {
        return this.mChannel.socket();
    }

    public boolean isConnected() {
        return false;
    }

    public int read(ByteBuffer byteBuffer) {
        throw new IOException("Can't read ServerSocketChannel");
    }

    public long read(ByteBuffer[] byteBufferArr) {
        throw new IOException("Can't read ServerSocketChannel");
    }

    public long read(ByteBuffer[] byteBufferArr, int i, int i2) {
        throw new IOException("Can't read ServerSocketChannel");
    }

    public SelectionKey register(Selector selector) {
        return this.mChannel.register(selector, 16);
    }

    public void shutdownInput() {
    }

    public void shutdownOutput() {
    }

    public int write(ByteBuffer byteBuffer) {
        throw new IOException("Can't write ServerSocketChannel");
    }

    public int write(ByteBuffer[] byteBufferArr) {
        throw new IOException("Can't write ServerSocketChannel");
    }
}
