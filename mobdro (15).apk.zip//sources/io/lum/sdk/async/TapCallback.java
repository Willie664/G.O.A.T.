package io.lum.sdk.async;

public interface TapCallback {
}
