package io.lum.sdk.async.dns;

import io.lum.sdk.async.AsyncDatagramSocket;
import io.lum.sdk.async.AsyncServer;
import io.lum.sdk.async.ByteBufferList;
import io.lum.sdk.async.DataEmitter;
import io.lum.sdk.async.callback.DataCallback;
import io.lum.sdk.async.future.Cancellable;
import io.lum.sdk.async.future.Future;
import io.lum.sdk.async.future.FutureCallback;
import io.lum.sdk.async.future.SimpleFuture;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

public class Dns {
    public static void addName(ByteBuffer byteBuffer, String str) {
        for (String str2 : str.split("\\.")) {
            byteBuffer.put((byte) str2.length());
            byteBuffer.put(str2.getBytes());
        }
        byteBuffer.put((byte) 0);
    }

    public static Future<DnsResponse> lookup(AsyncServer asyncServer, String str) {
        return lookup(asyncServer, str, false, (FutureCallback<DnsResponse>) null);
    }

    public static Future<DnsResponse> lookup(AsyncServer asyncServer, String str, final boolean z, final FutureCallback<DnsResponse> futureCallback) {
        final AsyncDatagramSocket asyncDatagramSocket;
        ByteBuffer order = ByteBufferList.obtain(1024).order(ByteOrder.BIG_ENDIAN);
        short nextInt = (short) new Random().nextInt();
        short query = (short) setQuery(0);
        if (!z) {
            query = (short) setRecursion(query);
        }
        order.putShort(nextInt);
        order.putShort(query);
        order.putShort(z ? (short) 1 : 2);
        order.putShort(0);
        order.putShort(0);
        order.putShort(0);
        addName(order, str);
        order.putShort(z ? (short) 12 : 1);
        order.putShort(1);
        if (!z) {
            addName(order, str);
            order.putShort(28);
            order.putShort(1);
        }
        order.flip();
        if (!z) {
            try {
                asyncDatagramSocket = asyncServer.connectDatagram(new InetSocketAddress("8.8.8.8", 53));
            } catch (Exception e2) {
                SimpleFuture simpleFuture = new SimpleFuture();
                simpleFuture.setComplete(e2);
                if (z) {
                    futureCallback.onCompleted(e2, null);
                }
                return simpleFuture;
            }
        } else {
            asyncDatagramSocket = AsyncServer.getDefault().openDatagram((InetAddress) null, 0, true);
            Field declaredField = DatagramSocket.class.getDeclaredField("impl");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(asyncDatagramSocket.getSocket());
            Method declaredMethod = obj.getClass().getDeclaredMethod("join", new Class[]{InetAddress.class});
            declaredMethod.setAccessible(true);
            declaredMethod.invoke(obj, new Object[]{InetAddress.getByName("224.0.0.251")});
            ((DatagramSocket) asyncDatagramSocket.getSocket()).setBroadcast(true);
        }
        final AnonymousClass1 r4 = new SimpleFuture<DnsResponse>() {
            public void cleanup() {
                super.cleanup();
                asyncDatagramSocket.close();
            }
        };
        asyncDatagramSocket.setDataCallback(new DataCallback() {
            public void onDataAvailable(DataEmitter dataEmitter, ByteBufferList byteBufferList) {
                try {
                    DnsResponse parse = DnsResponse.parse(byteBufferList);
                    parse.source = asyncDatagramSocket.getRemoteAddress();
                    if (!z) {
                        asyncDatagramSocket.close();
                        r4.setComplete(parse);
                    } else {
                        futureCallback.onCompleted((Exception) null, parse);
                    }
                } catch (Exception unused) {
                }
                byteBufferList.recycle();
            }
        });
        if (!z) {
            asyncDatagramSocket.write(new ByteBufferList(order));
        } else {
            asyncDatagramSocket.send(new InetSocketAddress("224.0.0.251", 5353), order);
        }
        return r4;
    }

    public static Future<DnsResponse> lookup(String str) {
        return lookup(AsyncServer.getDefault(), str, false, (FutureCallback<DnsResponse>) null);
    }

    public static Cancellable multicastLookup(AsyncServer asyncServer, String str, FutureCallback<DnsResponse> futureCallback) {
        return lookup(asyncServer, str, true, futureCallback);
    }

    public static Cancellable multicastLookup(String str, FutureCallback<DnsResponse> futureCallback) {
        return multicastLookup(AsyncServer.getDefault(), str, futureCallback);
    }

    public static int setFlag(int i, int i2, int i3) {
        return i | (i2 << i3);
    }

    public static int setQuery(int i) {
        return setFlag(i, 0, 0);
    }

    public static int setRecursion(int i) {
        return setFlag(i, 1, 8);
    }
}
