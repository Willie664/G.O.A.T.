package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Message;
import android.provider.BaseColumns;
import b.a.a.a.a;
import d.a.a.p0;
import d.a.a.q0;
import io.lum.sdk.util;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class perr {
    public String m_app_name;
    public final Pattern m_errid_rx = Pattern.compile("(?:lum_sdk_android|vpn_api)_(\\S+)");
    public flow m_flow;
    public final Object m_running_lock = new Object();

    public static class columns implements BaseColumns {
        public static final String BODY = "body";
        public static final String DATE = "date";
        public static final String EXTRA_1 = "extra_1";
        public static final String EXTRA_2 = "extra_2";
        public static final String EXTRA_3 = "extra_3";
        public static final String LEVEL = "level";
        public static final String LOGS = "logs";
        public static final String MSG = "msg";
        public static final String PERR_ID = "perr_id";
        public static final String PROCESS = "process";
        public static final String SENDING_TS = "sending_ts";
        public static final String SENT_TS = "sent_ts";
        public static final String SQL_CREATE = "CREATE TABLE perr (_id INTEGER PRIMARY KEY,perr_id INTEGER,date DATE,level INTEGER,process TEXT,version TEXT,msg TEXT,body TEXT,logs TEXT,sending_ts INTEGER,sent_ts INTEGER,extra_1 TEXT,extra_2 TEXT,extra_3 TEXT)";
        public static final String TABLE_NAME = "perr";
        public static final String VER = "version";
    }

    public static class db_helper extends SQLiteOpenHelper {
        public static final int DATABASE_VERSION = 2;
        public static final int DATABASE_VERSION_LEVEL = 2;

        public db_helper(Context context) {
            super(context, "lum_sdk_perr.db", (SQLiteDatabase.CursorFactory) null, 2);
        }

        private void add_column(SQLiteDatabase sQLiteDatabase, String str, String str2) {
            sQLiteDatabase.execSQL(String.format("ALTER TABLE %s ADD COLUMN %s %s", new Object[]{columns.TABLE_NAME, str, str2}));
        }

        private void rm_column(SQLiteDatabase sQLiteDatabase, String str) {
            sQLiteDatabase.execSQL(String.format("ALTER TABLE %s DROP COLUMN %s", new Object[]{columns.TABLE_NAME, str}));
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(columns.SQL_CREATE);
        }

        public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            if (i2 < 2) {
                rm_column(sQLiteDatabase, "level");
            }
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            if (i < 2) {
                add_column(sQLiteDatabase, "level", "INTEGER");
            }
        }
    }

    public class flow {
        public static final int m_ex_count_max = 5;
        public static final String m_ids_def = "{'register_client': {'disabled': true}}";
        public static final String m_ids_def_test = "{'register_client': {'max_freq': 0}}";
        public static final String m_kv_int = "%s=%s";
        public static final String m_kv_str = "%s=\"%s\"";
        public SQLiteDatabase m_db;
        public boolean m_enabled;
        public int m_ex_count = 0;
        public JSONObject m_ids;
        public String m_min_ver;
        public Long m_process_pending_ts = 0L;

        public flow(Context context) {
            boolean is_test_app = util.is_test_app(context.getPackageName());
            boolean z = util.m_conf.get_bool(conf.PERR_DB_ENABLED, true);
            this.m_enabled = z;
            if (z) {
                try {
                    this.m_ids = new JSONObject(is_test_app ? m_ids_def_test : m_ids_def);
                    JSONObject jSONObject = util.m_conf.get_json(conf.PERR_IDS);
                    Iterator<String> keys = jSONObject.keys();
                    while (keys.hasNext()) {
                        String next = keys.next();
                        this.m_ids.put(next, jSONObject.get(next));
                    }
                    this.m_min_ver = util.m_conf.get_str(conf.PERR_MIN_VER, "1.177.86");
                    this.m_db = new db_helper(context).getWritableDatabase();
                } catch (Exception e2) {
                    handle_exception(e2, true);
                }
            }
        }

        private int get_int(Cursor cursor, String str) {
            return cursor.getInt(cursor.getColumnIndexOrThrow(str));
        }

        private JSONObject get_perr_id_conf(msg msg) {
            JSONObject jSONObject = new JSONObject();
            String[] strArr = {"*", msg.m_errid_base, msg.m_errid};
            for (int i = 0; i < 3; i++) {
                String str = strArr[i];
                if (str != null && this.m_ids.has(str)) {
                    try {
                        JSONObject jSONObject2 = this.m_ids.getJSONObject(str);
                        Iterator<String> keys = jSONObject2.keys();
                        while (keys.hasNext()) {
                            String next = keys.next();
                            jSONObject.put(next, jSONObject2.get(next));
                        }
                    } catch (JSONException e2) {
                        perr perr = perr.this;
                        StringBuilder a2 = a.a("fetch id config failed: ");
                        a2.append(util.e2s(e2));
                        perr.zerr(5, a2.toString());
                    }
                }
            }
            return jSONObject;
        }

        private String get_str(Cursor cursor, String str) {
            return cursor.getString(cursor.getColumnIndexOrThrow(str));
        }

        private void handle_exception(Exception exc, boolean z) {
            perr.this.zerr(4, util.e2s(exc));
            int i = this.m_ex_count + 1;
            this.m_ex_count = i;
            if (z || i > 5) {
                destroy();
                util.perr(3, "perr_db_disabled", exc.getMessage(), util.e2s(exc), true);
            }
        }

        private msg load(Cursor cursor) {
            return perr.this.create_msg(get_int(cursor, "_id"), get_int(cursor, "level"), get_str(cursor, columns.PERR_ID), get_str(cursor, "msg"), get_str(cursor, columns.BODY), (util.perr_once) null, get_str(cursor, columns.LOGS), get_str(cursor, columns.LOGS), get_str(cursor, columns.VER), false);
        }

        public void destroy() {
            this.m_enabled = false;
            try {
                this.m_db.close();
            } catch (Exception unused) {
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x00a0 A[Catch:{ Exception -> 0x00a7 }] */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x00a2 A[Catch:{ Exception -> 0x00a7 }] */
        @android.annotation.SuppressLint({"DefaultLocale"})
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean exists(io.lum.sdk.perr.msg r14) {
            /*
                r13 = this;
                java.lang.String r0 = "%s=\"%s\""
                boolean r1 = r13.m_enabled
                r2 = 0
                if (r1 != 0) goto L_0x0008
                return r2
            L_0x0008:
                r1 = 0
                r3 = 1
                org.json.JSONObject r4 = r13.get_perr_id_conf(r14)     // Catch:{ Exception -> 0x00a7 }
                java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x00a7 }
                r5.<init>()     // Catch:{ Exception -> 0x00a7 }
                r6 = 2
                java.lang.Object[] r7 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r8 = "perr_id"
                r7[r2] = r8     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r8 = r14.m_errid     // Catch:{ Exception -> 0x00a7 }
                r7[r3] = r8     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r7 = java.lang.String.format(r0, r7)     // Catch:{ Exception -> 0x00a7 }
                r5.append(r7)     // Catch:{ Exception -> 0x00a7 }
                io.lum.sdk.util$perr_once r7 = r14.m_once     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r8 = "once"
                boolean r8 = r4.optBoolean(r8)     // Catch:{ Exception -> 0x00a7 }
                if (r8 == 0) goto L_0x0031
                io.lum.sdk.util$perr_once r7 = io.lum.sdk.util.perr_once.INSTALL     // Catch:{ Exception -> 0x00a7 }
            L_0x0031:
                io.lum.sdk.util$perr_once r8 = io.lum.sdk.util.perr_once.NONE     // Catch:{ Exception -> 0x00a7 }
                if (r7 != r8) goto L_0x006a
                long r7 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r9 = "max_freq"
                r10 = 300000(0x493e0, double:1.482197E-318)
                long r9 = r4.optLong(r9, r10)     // Catch:{ Exception -> 0x00a7 }
                long r7 = r7 - r9
                java.lang.String r4 = "AND (%s OR %s>%s)"
                r9 = 3
                java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ Exception -> 0x00a7 }
                java.lang.Object[] r10 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r11 = "date"
                r10[r2] = r11     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = r14.m_date     // Catch:{ Exception -> 0x00a7 }
                r10[r3] = r14     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = java.lang.String.format(r0, r10)     // Catch:{ Exception -> 0x00a7 }
                r9[r2] = r14     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = "sent_ts"
                r9[r3] = r14     // Catch:{ Exception -> 0x00a7 }
                java.lang.Long r14 = java.lang.Long.valueOf(r7)     // Catch:{ Exception -> 0x00a7 }
                r9[r6] = r14     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = java.lang.String.format(r4, r9)     // Catch:{ Exception -> 0x00a7 }
            L_0x0066:
                r5.append(r14)     // Catch:{ Exception -> 0x00a7 }
                goto L_0x0082
            L_0x006a:
                io.lum.sdk.util$perr_once r14 = io.lum.sdk.util.perr_once.VER     // Catch:{ Exception -> 0x00a7 }
                if (r7 != r14) goto L_0x0082
                java.lang.String r14 = " AND "
                r5.append(r14)     // Catch:{ Exception -> 0x00a7 }
                java.lang.Object[] r14 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r4 = "version"
                r14[r2] = r4     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r4 = "1.177.86"
                r14[r3] = r4     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = java.lang.String.format(r0, r14)     // Catch:{ Exception -> 0x00a7 }
                goto L_0x0066
            L_0x0082:
                android.database.sqlite.SQLiteDatabase r4 = r13.m_db     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r14 = "perr"
                java.lang.String r0 = "_id"
                java.lang.String[] r6 = new java.lang.String[]{r0}     // Catch:{ Exception -> 0x00a7 }
                java.lang.String r7 = r5.toString()     // Catch:{ Exception -> 0x00a7 }
                r8 = 0
                r9 = 0
                r10 = 0
                r11 = 0
                r12 = 0
                r5 = r14
                android.database.Cursor r1 = r4.query(r5, r6, r7, r8, r9, r10, r11, r12)     // Catch:{ Exception -> 0x00a7 }
                int r14 = r1.getCount()     // Catch:{ Exception -> 0x00a7 }
                if (r14 <= 0) goto L_0x00a2
                r14 = 1
                goto L_0x00a3
            L_0x00a2:
                r14 = 0
            L_0x00a3:
                r1.close()     // Catch:{ Exception -> 0x00a7 }
                return r14
            L_0x00a7:
                r14 = move-exception
                r13.handle_exception(r14, r3)
                r1.close()     // Catch:{ Exception -> 0x00ae }
            L_0x00ae:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.perr.flow.exists(io.lum.sdk.perr$msg):boolean");
        }

        public boolean finish(msg msg, boolean z) {
            if (this.m_enabled && msg.m_id >= 1) {
                ContentValues contentValues = new ContentValues(2);
                contentValues.put(columns.SENT_TS, z ? Long.valueOf(System.currentTimeMillis()) : null);
                contentValues.put(columns.SENDING_TS, (Integer) null);
                try {
                    this.m_db.update(columns.TABLE_NAME, contentValues, String.format(m_kv_int, new Object[]{"_id", Long.valueOf(msg.m_id)}), (String[]) null);
                    return true;
                } catch (Exception e2) {
                    handle_exception(e2, true);
                }
            }
            return false;
        }

        public String get_db_ver(String str) {
            if (!this.m_enabled) {
                return str;
            }
            try {
                return "" + this.m_db.getVersion();
            } catch (Exception unused) {
                return str;
            }
        }

        public boolean prepare(msg msg) {
            if (!this.m_enabled) {
                return true;
            }
            JSONObject jSONObject = get_perr_id_conf(msg);
            if (jSONObject.optBoolean("disabled") || util.version_cmp(msg.m_ver, this.m_min_ver) < 0) {
                return false;
            }
            if (!jSONObject.optBoolean(columns.LOGS, true)) {
                msg.m_logs = null;
            }
            return true;
        }

        @SuppressLint({"DefaultLocale"})
        public void process_pending() {
            Throwable th;
            msg load;
            if (!this.m_enabled) {
                perr.this.zerr(4, "skip process_pending: not enabled");
                return;
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (this.m_process_pending_ts.longValue() + ((long) 300000) <= currentTimeMillis) {
                this.m_process_pending_ts = Long.valueOf(currentTimeMillis);
                String format = String.format("%s IS NULL AND (%s IS NULL || %s<%s)", new Object[]{columns.SENT_TS, columns.SENDING_TS, columns.SENDING_TS, Long.valueOf(currentTimeMillis - 300000)});
                perr perr = perr.this;
                perr.zerr(7, "pending select: " + format);
                long queryNumEntries = DatabaseUtils.queryNumEntries(this.m_db, columns.TABLE_NAME, format);
                perr perr2 = perr.this;
                perr2.zerr(5, "found pending: " + queryNumEntries);
                try {
                    Cursor query = this.m_db.query(columns.TABLE_NAME, new String[]{"_id", "level", columns.PERR_ID, "msg", columns.BODY, columns.LOGS, "date", columns.VER}, format, (String[]) null, (String) null, (String) null, (String) null, (String) null);
                    while (query.moveToNext()) {
                        try {
                            load = load(query);
                            perr perr3 = perr.this;
                            perr3.zerr(5, "deliver pending: " + load.m_errid);
                            util.perr_send_msg(load);
                        } catch (Exception e2) {
                            load.zerr(4, "send pending failed: " + util.e2s(e2));
                        } catch (Throwable th2) {
                            th = th2;
                            try {
                                throw th;
                            } catch (Throwable th3) {
                                Throwable th4 = th3;
                                if (query != null) {
                                    query.close();
                                }
                                throw th4;
                            }
                        }
                    }
                    query.close();
                } catch (Exception e3) {
                    handle_exception(e3, false);
                } catch (Throwable th5) {
                    th.addSuppressed(th5);
                }
            }
        }

        public boolean save(msg msg) {
            if (!this.m_enabled) {
                return false;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(columns.PERR_ID, msg.m_errid);
            contentValues.put("level", Integer.valueOf(msg.m_level));
            contentValues.put("date", msg.m_date);
            contentValues.put(columns.VER, msg.m_ver);
            contentValues.put("msg", msg.m_msg);
            contentValues.put(columns.PROCESS, msg.m_process);
            try {
                msg.m_id = this.m_db.insertOrThrow(columns.TABLE_NAME, (String) null, contentValues);
                return true;
            } catch (Exception e2) {
                handle_exception(e2, true);
                return false;
            }
        }

        public boolean start(msg msg) {
            if (this.m_enabled && msg.m_id >= 1) {
                ContentValues contentValues = new ContentValues(1);
                contentValues.put(columns.SENDING_TS, Long.valueOf(System.currentTimeMillis()));
                try {
                    this.m_db.update(columns.TABLE_NAME, contentValues, String.format(m_kv_int, new Object[]{"_id", Long.valueOf(msg.m_id)}), (String[]) null);
                    return true;
                } catch (Exception e2) {
                    handle_exception(e2, false);
                }
            }
            return false;
        }
    }

    public static class msg {
        public String m_body;
        public String m_date;
        public boolean m_dry = false;
        public String m_errid;
        public String m_errid_base;
        public long m_id;
        public int m_level = 6;
        public String m_logs;
        public String m_msg;
        public util.perr_once m_once = util.perr_once.NONE;
        public String m_process;
        public String m_ver;

        public void zerr(int i, String str) {
            StringBuilder a2 = a.a("lumsdk/perr/");
            a2.append(this.m_errid);
            util._zerr(a2.toString(), i, str);
        }
    }

    public interface on_finish {
        void run(boolean z);
    }

    public static /* synthetic */ void a(on_finish on_finish2, msg msg2, Runnable runnable, boolean z) {
        on_finish2.run(z);
        if (!z) {
            msg2.zerr(4, "failed");
        } else {
            runnable.run();
        }
    }

    private void create_flow(Context context) {
        synchronized (this.m_running_lock) {
            if (this.m_flow == null) {
                this.m_flow = new flow(context);
            }
        }
    }

    /* access modifiers changed from: private */
    public msg create_msg(int i, int i2, String str, String str2, String str3, util.perr_once perr_once, String str4, String str5, String str6, boolean z) {
        msg msg2 = new msg();
        msg2.m_id = (long) i;
        msg2.m_msg = str2;
        msg2.m_body = str3;
        msg2.m_date = str5;
        msg2.m_once = perr_once;
        msg2.m_errid = str;
        msg2.m_level = i2;
        msg2.m_logs = str4;
        msg2.m_ver = str6;
        msg2.m_dry = z;
        msg2.m_process = this.m_app_name;
        Matcher matcher = this.m_errid_rx.matcher(str);
        if (matcher.matches()) {
            msg2.m_errid_base = matcher.group(1);
        }
        return msg2;
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x000e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void destroy_flow() {
        /*
            r2 = this;
            java.lang.Object r0 = r2.m_running_lock
            monitor-enter(r0)
            io.lum.sdk.perr$flow r1 = r2.m_flow     // Catch:{ NullPointerException -> 0x000e }
            r1.destroy()     // Catch:{ NullPointerException -> 0x000e }
            r1 = 0
            r2.m_flow = r1     // Catch:{ NullPointerException -> 0x000e }
            goto L_0x000e
        L_0x000c:
            r1 = move-exception
            goto L_0x0010
        L_0x000e:
            monitor-exit(r0)     // Catch:{ all -> 0x000c }
            return
        L_0x0010:
            monitor-exit(r0)     // Catch:{ all -> 0x000c }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.perr.destroy_flow():void");
    }

    public /* synthetic */ void a(msg msg2, boolean z) {
        synchronized (this.m_running_lock) {
            if (is_enabled() && this.m_flow.finish(msg2, z)) {
                msg2.zerr(7, "finished");
            }
        }
    }

    public msg create_msg(int i, String str, String str2, String str3, util.perr_once perr_once, String str4, String str5, String str6, boolean z) {
        return create_msg(0, i, str, str2, str3, perr_once, str4, str5, str6, z);
    }

    public String get_db_ver() {
        String str;
        synchronized (this.m_running_lock) {
            str = "N\\A";
            if (this.m_flow != null) {
                str = this.m_flow.get_db_ver(str);
            }
        }
        return str;
    }

    public void handle_message(Message message, Runnable runnable) {
        if (message.what == 1) {
            msg msg2 = (msg) message.obj;
            p0 p0Var = new p0(this, msg2);
            synchronized (this.m_running_lock) {
                msg2.zerr(7, "create_flow");
                if (msg2.m_id < 1 && is_enabled()) {
                    if (this.m_flow.exists(msg2)) {
                        msg2.zerr(7, "skipped");
                        return;
                    }
                    this.m_flow.save(msg2);
                }
                if (!util.m_is_online.booleanValue()) {
                    msg2.zerr(7, "offline");
                    return;
                }
                if (is_enabled()) {
                    if (this.m_flow.start(msg2)) {
                        msg2.zerr(7, "started");
                    }
                    if (!this.m_flow.prepare(msg2)) {
                        msg2.zerr(5, evaluation.ERRID_RESTRICTED);
                        p0Var.run(true);
                        return;
                    }
                }
                msg2.zerr(7, "sending");
                util.perr_send(msg2, new q0(p0Var, msg2, runnable));
            }
        }
    }

    public void init(Context context, String str) {
        this.m_app_name = str;
        create_flow(context);
    }

    public boolean is_enabled() {
        flow flow2 = this.m_flow;
        if (flow2 != null) {
            return flow2.m_enabled;
        }
        zerr(4, "is_enabled flow null");
        return false;
    }

    public void process_pending() {
        synchronized (this.m_running_lock) {
            if (this.m_flow != null) {
                this.m_flow.process_pending();
            } else {
                zerr(4, "skipping pending perrs: flow null");
            }
        }
    }

    public void reset(Context context) {
        destroy_flow();
        create_flow(context);
    }

    public void uninit() {
        destroy_flow();
        this.m_app_name = null;
    }

    public void zerr(int i, String str) {
        util._zerr("lumsdk/perr", i, str);
    }
}
