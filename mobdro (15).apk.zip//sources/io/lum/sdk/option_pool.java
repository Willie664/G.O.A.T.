package io.lum.sdk;

import android.text.TextUtils;
import b.a.a.a.a;
import io.lum.sdk.conf;
import io.lum.sdk.util;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class option_pool {
    public ArrayList<String> m_names = new ArrayList<>();
    public Map<String, options> m_options = Collections.synchronizedMap(new HashMap());
    public util.zerr m_zerr;

    public static abstract class options<V> {
        public static Random m_rand = new Random();
        public boolean m_dirty;
        public int m_index;
        public ArrayList<V> m_items;
        public conf.key m_key;
        public String m_name;
        public int m_offset = 0;
        public long m_ts;
        public conf.key m_ts_key;
        public long m_ttl;
        public V m_value;
        public util.zerr m_zerr;

        public options(String str, ArrayList<V> arrayList, conf.key key, conf.key key2, conf.key key3, int i, boolean z) {
            this.m_name = str;
            StringBuilder a2 = a.a("options/");
            a2.append(this.m_name);
            this.m_zerr = new util.zerr(a2.toString());
            this.m_items = arrayList;
            this.m_key = key;
            this.m_ts_key = key2;
            if (util.m_conf != null) {
                this.m_value = load_value();
                this.m_ts = util.m_conf.get_long(this.m_ts_key);
                this.m_ttl = util.m_conf.get_long(key3, (long) i);
            } else {
                this.m_zerr.err("init conf null");
            }
            if (is_empty()) {
                if (z) {
                    this.m_offset = m_rand.nextInt(this.m_items.size());
                }
                next();
                return;
            }
            util.zerr zerr = this.m_zerr;
            StringBuilder a3 = a.a("loaded: ");
            a3.append(this.m_value);
            zerr.notice(a3.toString());
            this.m_offset = Math.max(0, this.m_items.indexOf(this.m_value));
        }

        private boolean has_expired() {
            return this.m_ttl > 0 && now() - this.m_ts > this.m_ttl;
        }

        public static long now() {
            return System.currentTimeMillis();
        }

        public V get() {
            if (has_expired()) {
                next();
            }
            return get_current();
        }

        public V get_current() {
            return this.m_value;
        }

        public abstract boolean is_empty();

        public abstract V load_value();

        public boolean next() {
            this.m_dirty = true;
            int size = this.m_items.size();
            if (size < 1) {
                return false;
            }
            this.m_value = this.m_items.get((this.m_index + this.m_offset) % size);
            this.m_ts = now();
            util.zerr zerr = this.m_zerr;
            StringBuilder a2 = a.a("next: ");
            a2.append(this.m_value);
            zerr.notice(a2.toString());
            int i = this.m_index + 1;
            this.m_index = i;
            return i + this.m_offset < size;
        }

        public boolean remove() {
            this.m_items.remove(this.m_value);
            this.m_index--;
            return next();
        }

        public void reset() {
            this.m_index = 0;
        }

        public boolean save() {
            if (!this.m_dirty) {
                return false;
            }
            if (util.m_conf == null) {
                this.m_zerr.err("save conf null");
                return false;
            }
            util.zerr zerr = this.m_zerr;
            StringBuilder a2 = a.a("saving: ");
            a2.append(this.m_value);
            zerr.notice(a2.toString());
            save_value();
            util.m_conf.set(this.m_ts_key, this.m_ts);
            this.m_dirty = false;
            return true;
        }

        public abstract void save_value();
    }

    public option_pool(String str) {
        this.m_zerr = new util.zerr(a.a("option_pool/", str));
    }

    public static options<Integer> numbers(String str, ArrayList<Integer> arrayList, conf.key key, conf.key key2, conf.key key3, int i, boolean z) {
        return new options<Integer>(str, arrayList, key, key2, key3, i, z) {
            public boolean is_empty() {
                V v = this.m_value;
                return v == null || ((Integer) v).intValue() < 1;
            }

            public Integer load_value() {
                return Integer.valueOf(util.m_conf.get_int(this.m_key));
            }

            public void save_value() {
                util.m_conf.set(this.m_key, ((Integer) this.m_value).intValue());
            }
        };
    }

    public static options<String> strings(String str, ArrayList<String> arrayList, conf.key key, conf.key key2, conf.key key3, int i, boolean z) {
        return new options<String>(str, arrayList, key, key2, key3, i, z) {
            public boolean is_empty() {
                return ((String) this.m_value).isEmpty();
            }

            public String load_value() {
                return util.m_conf.get_str(this.m_key);
            }

            public void save_value() {
                util.m_conf.set(this.m_key, (String) this.m_value);
            }
        };
    }

    public synchronized option_pool add(options options2) {
        this.m_options.put(options2.m_name, options2);
        this.m_names.add(options2.m_name);
        return this;
    }

    public synchronized Object get(String str) {
        try {
        } catch (Exception e2) {
            this.m_zerr.err(util.e2s(e2));
            return null;
        }
        return this.m_options.get(str).get();
    }

    public synchronized Object get_current(String str) {
        try {
        } catch (Exception e2) {
            this.m_zerr.err(util.e2s(e2));
            return null;
        }
        return this.m_options.get(str).get_current();
    }

    public synchronized String get_details() {
        if (this.m_options == null) {
            return "";
        }
        ArrayList arrayList = new ArrayList();
        Iterator<String> it = this.m_names.iterator();
        while (it.hasNext()) {
            arrayList.add(get_current(it.next()).toString());
        }
        return TextUtils.join(":", arrayList);
    }

    public synchronized boolean next() {
        if (this.m_options == null) {
            return false;
        }
        Iterator<String> it = this.m_names.iterator();
        while (it.hasNext()) {
            options options2 = this.m_options.get(it.next());
            try {
                if (options2.next()) {
                    return true;
                }
                options2.reset();
            } catch (Exception e2) {
                this.m_zerr.err(util.e2s(e2));
            }
        }
        return false;
    }

    public synchronized boolean remove(String str) {
        try {
        } catch (Exception e2) {
            this.m_zerr.err(util.e2s(e2));
            return false;
        }
        return this.m_options.get(str).remove();
    }

    public synchronized void reset() {
        if (this.m_options != null) {
            Iterator<String> it = this.m_names.iterator();
            while (it.hasNext()) {
                try {
                    this.m_options.get(it.next()).reset();
                } catch (Exception e2) {
                    this.m_zerr.err(util.e2s(e2));
                }
            }
        }
    }

    public synchronized boolean save() {
        if (this.m_options == null) {
            return false;
        }
        Iterator<options> it = this.m_options.values().iterator();
        while (true) {
            boolean z = false;
            while (true) {
                if (!it.hasNext()) {
                    return z;
                }
                if (it.next().save() || z) {
                    z = true;
                }
            }
        }
    }
}
