package io.lum.sdk;

import android.content.Context;
import android.os.Bundle;
import io.lum.sdk.bcast;
import java.util.HashMap;

public class bcast_handler {
    public static String THREAD_NAME = "bcast_handler";
    public bcast.server m_server;

    public class set_handler {
        public final String BOOL = "Boolean";
        public final String FLOAT = "Float";
        public final String INT = "Integer";
        public final String LONG = "Long";
        public HashMap<String, set_strict> m_set;

        public set_handler(Context context) {
            HashMap<String, set_strict> hashMap = new HashMap<>();
            this.m_set = hashMap;
            hashMap.put("conf", new conf(context));
            this.m_set.put("state", new state(context));
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* JADX WARNING: Code restructure failed: missing block: B:64:0x00fe, code lost:
            if (r7.equals("Boolean") != false) goto L_0x0120;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean run(android.os.Bundle r14) {
            /*
                r13 = this;
                java.lang.String r0 = "action"
                java.lang.String r0 = r14.getString(r0)
                java.lang.String r1 = ""
                r2 = 0
                r3 = 3
                r4 = 1
                if (r0 != 0) goto L_0x0017
                java.lang.String r14 = r14.toString()
                java.lang.String r0 = "set_handler_action_null"
                io.lum.sdk.util.perr((int) r3, (java.lang.String) r0, (java.lang.String) r14, (java.lang.String) r1, (boolean) r4)
                return r2
            L_0x0017:
                java.lang.String r5 = "after"
                java.lang.String r5 = r14.getString(r5)
                int r6 = r0.hashCode()
                java.lang.String r7 = "clear"
                java.lang.String r8 = "del"
                r9 = 5
                r10 = 4
                r11 = -1
                r12 = 2
                switch(r6) {
                    case -2128957181: goto L_0x005b;
                    case -1633941255: goto L_0x0051;
                    case 99339: goto L_0x0049;
                    case 113762: goto L_0x003f;
                    case 94746189: goto L_0x0037;
                    case 1715152035: goto L_0x002d;
                    default: goto L_0x002c;
                }
            L_0x002c:
                goto L_0x0065
            L_0x002d:
                java.lang.String r6 = "stop_svc"
                boolean r6 = r0.equals(r6)
                if (r6 == 0) goto L_0x0065
                r6 = 4
                goto L_0x0066
            L_0x0037:
                boolean r6 = r0.equals(r7)
                if (r6 == 0) goto L_0x0065
                r6 = 2
                goto L_0x0066
            L_0x003f:
                java.lang.String r6 = "set"
                boolean r6 = r0.equals(r6)
                if (r6 == 0) goto L_0x0065
                r6 = 0
                goto L_0x0066
            L_0x0049:
                boolean r6 = r0.equals(r8)
                if (r6 == 0) goto L_0x0065
                r6 = 1
                goto L_0x0066
            L_0x0051:
                java.lang.String r6 = "restart_svc_thread"
                boolean r6 = r0.equals(r6)
                if (r6 == 0) goto L_0x0065
                r6 = 5
                goto L_0x0066
            L_0x005b:
                java.lang.String r6 = "start_svc"
                boolean r6 = r0.equals(r6)
                if (r6 == 0) goto L_0x0065
                r6 = 3
                goto L_0x0066
            L_0x0065:
                r6 = -1
            L_0x0066:
                if (r6 == 0) goto L_0x007f
                if (r6 == r4) goto L_0x007f
                if (r6 == r12) goto L_0x007f
                if (r6 == r3) goto L_0x007b
                if (r6 == r10) goto L_0x0077
                if (r6 == r9) goto L_0x0073
                return r4
            L_0x0073:
                io.lum.sdk.util.restart_svc_thread(r5)
                return r4
            L_0x0077:
                io.lum.sdk.util.stop_svc_thread(r5)
                return r4
            L_0x007b:
                io.lum.sdk.util.start_svc_thread(r5)
                return r4
            L_0x007f:
                java.lang.String r5 = "name"
                java.lang.String r5 = r14.getString(r5)
                java.util.HashMap<java.lang.String, io.lum.sdk.set_strict> r6 = r13.m_set
                boolean r6 = r6.containsKey(r5)
                if (r6 != 0) goto L_0x00a7
                java.lang.StringBuilder r14 = new java.lang.StringBuilder
                r14.<init>()
                java.lang.String r0 = "Invalid set: "
                r14.append(r0)
                r14.append(r5)
                java.lang.String r14 = r14.toString()
                int unused = io.lum.sdk.bcast_handler.zerr_s(r3, r14)
                java.lang.String r14 = "invalid_set"
                io.lum.sdk.util.perr((java.lang.String) r14, (java.lang.String) r5)
                return r2
            L_0x00a7:
                java.lang.String r6 = "key"
                java.lang.String r6 = r14.getString(r6)
                java.util.HashMap<java.lang.String, io.lum.sdk.set_strict> r9 = r13.m_set
                java.lang.Object r5 = r9.get(r5)
                io.lum.sdk.set_strict r5 = (io.lum.sdk.set_strict) r5
                if (r5 != 0) goto L_0x00b8
                return r2
            L_0x00b8:
                boolean r7 = r0.equals(r7)
                if (r7 == 0) goto L_0x00c2
                r5.clear()
                return r4
            L_0x00c2:
                boolean r0 = r0.equals(r8)
                if (r0 == 0) goto L_0x00cc
                r5.del(r6)
                return r4
            L_0x00cc:
                java.lang.String r0 = "value"
                java.lang.String r0 = r14.getString(r0)
                if (r0 != 0) goto L_0x00de
                java.lang.String r14 = r14.toString()
                java.lang.String r0 = "set_handler_value_null"
                io.lum.sdk.util.perr((int) r3, (java.lang.String) r0, (java.lang.String) r14, (java.lang.String) r1, (boolean) r4)
                return r2
            L_0x00de:
                java.lang.String r7 = "type"
                java.lang.String r7 = r14.getString(r7)
                if (r7 != 0) goto L_0x00f0
                java.lang.String r14 = r14.toString()
                java.lang.String r0 = "set_handler_type_null"
                io.lum.sdk.util.perr((int) r3, (java.lang.String) r0, (java.lang.String) r14, (java.lang.String) r1, (boolean) r4)
                return r2
            L_0x00f0:
                int r14 = r7.hashCode()
                switch(r14) {
                    case -672261858: goto L_0x0115;
                    case 2374300: goto L_0x010b;
                    case 67973692: goto L_0x0101;
                    case 1729365000: goto L_0x00f8;
                    default: goto L_0x00f7;
                }
            L_0x00f7:
                goto L_0x011f
            L_0x00f8:
                java.lang.String r14 = "Boolean"
                boolean r14 = r7.equals(r14)
                if (r14 == 0) goto L_0x011f
                goto L_0x0120
            L_0x0101:
                java.lang.String r14 = "Float"
                boolean r14 = r7.equals(r14)
                if (r14 == 0) goto L_0x011f
                r2 = 3
                goto L_0x0120
            L_0x010b:
                java.lang.String r14 = "Long"
                boolean r14 = r7.equals(r14)
                if (r14 == 0) goto L_0x011f
                r2 = 2
                goto L_0x0120
            L_0x0115:
                java.lang.String r14 = "Integer"
                boolean r14 = r7.equals(r14)
                if (r14 == 0) goto L_0x011f
                r2 = 1
                goto L_0x0120
            L_0x011f:
                r2 = -1
            L_0x0120:
                if (r2 == 0) goto L_0x0144
                if (r2 == r4) goto L_0x013c
                if (r2 == r12) goto L_0x0134
                if (r2 == r3) goto L_0x012c
                r5.set((java.lang.String) r6, (java.lang.String) r0)
                goto L_0x014b
            L_0x012c:
                java.lang.Float r14 = java.lang.Float.valueOf(r0)
                r5.set((java.lang.String) r6, (java.lang.Float) r14)
                goto L_0x014b
            L_0x0134:
                java.lang.Long r14 = java.lang.Long.valueOf(r0)
                r5.set((java.lang.String) r6, (java.lang.Long) r14)
                goto L_0x014b
            L_0x013c:
                java.lang.Integer r14 = java.lang.Integer.valueOf(r0)
                r5.set((java.lang.String) r6, (java.lang.Integer) r14)
                goto L_0x014b
            L_0x0144:
                java.lang.Boolean r14 = java.lang.Boolean.valueOf(r0)
                r5.set((java.lang.String) r6, (java.lang.Boolean) r14)
            L_0x014b:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.bcast_handler.set_handler.run(android.os.Bundle):boolean");
        }
    }

    public bcast_handler(Context context, String str) {
        Thread.currentThread().setName(THREAD_NAME);
        final set_handler set_handler2 = new set_handler(context);
        this.m_server = new bcast.server(context, str) {
            public final Boolean m_receive_lock = true;

            public boolean on_receive(Bundle bundle) {
                boolean run;
                synchronized (this.m_receive_lock) {
                    run = set_handler2.run(bundle);
                }
                return run;
            }
        };
    }

    public static int zerr_s(int i, String str) {
        return util._zerr("lumsdk/bcast_handler", i, str);
    }

    public synchronized void destroy() {
        if (this.m_server != null) {
            this.m_server.destroy();
            this.m_server = null;
        }
    }

    public void send_bw_notification(Bundle bundle) {
        this.m_server.send_notification(bundle, bcast.SERVER_NOTIFY_BW);
    }

    public void send_notification(Bundle bundle) {
        this.m_server.send_notification(bundle);
    }
}
