package io.lum.sdk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimeZone;
import org.json.JSONArray;

public class country_to_tzs {
    public static boolean m_inited = false;
    public static final HashMap<String, String[]> m_tzs = new HashMap<>();

    public static HashMap<String, String[]> get_all() {
        HashMap<String, String[]> hashMap;
        synchronized (m_tzs) {
            if (!m_inited) {
                init();
            }
            hashMap = m_tzs;
        }
        return hashMap;
    }

    public static ArrayList get_timezones(ArrayList<String> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        HashMap<String, String[]> hashMap = get_all();
        Iterator<String> it = arrayList.iterator();
        while (it.hasNext()) {
            String[] strArr = hashMap.get(it.next());
            if (strArr != null) {
                arrayList2.addAll(Arrays.asList(strArr));
            }
        }
        return arrayList2;
    }

    public static ArrayList get_timezones(JSONArray jSONArray) {
        String[] strArr;
        ArrayList arrayList = new ArrayList();
        HashMap<String, String[]> hashMap = get_all();
        for (int i = 0; i < jSONArray.length(); i++) {
            String optString = jSONArray.optString(i, "");
            if (!optString.isEmpty() && (strArr = hashMap.get(optString)) != null) {
                arrayList.addAll(Arrays.asList(strArr));
            }
        }
        return arrayList;
    }

    public static void init() {
        m_tzs.put("AF", new String[]{"Asia/Kabul"});
        m_tzs.put("AX", new String[]{"Europe/Mariehamn"});
        m_tzs.put("AL", new String[]{"Europe/Tirane"});
        m_tzs.put("DZ", new String[]{"Africa/Algiers"});
        m_tzs.put("AS", new String[]{"Pacific/Pago_Pago", "Pacific/Samoa", "US/Samoa"});
        m_tzs.put("AD", new String[]{"Europe/Andorra"});
        m_tzs.put("AO", new String[]{"Africa/Luanda"});
        m_tzs.put("AI", new String[]{"America/Anguilla"});
        m_tzs.put("AQ", new String[]{"Antarctica/Casey", "Antarctica/Davis", "Antarctica/DumontDUrville", "Antarctica/Mawson", "Antarctica/McMurdo", "Antarctica/Palmer", "Antarctica/Rothera", "Antarctica/Syowa", "Antarctica/Troll", "Antarctica/Vostok"});
        m_tzs.put("AG", new String[]{"America/Antigua"});
        m_tzs.put("AR", new String[]{"AGT", "America/Argentina/Buenos_Aires", "America/Argentina/Catamarca", "America/Argentina/ComodRivadavia", "America/Argentina/Cordoba", "America/Argentina/Jujuy", "America/Argentina/La_Rioja", "America/Argentina/Mendoza", "America/Argentina/Rio_Gallegos", "America/Argentina/Salta", "America/Argentina/San_Juan", "America/Argentina/San_Luis", "America/Argentina/Tucuman", "America/Argentina/Ushuaia", "America/Buenos_Aires", "America/Catamarca", "America/Cordoba", "America/Jujuy", "America/Mendoza", "America/Rosario"});
        m_tzs.put("AM", new String[]{"Asia/Yerevan", "NET"});
        m_tzs.put("AW", new String[]{"America/Aruba"});
        m_tzs.put("AU", new String[]{"ACT", "AET", "Antarctica/Macquarie", "Australia/ACT", "Australia/Adelaide", "Australia/Brisbane", "Australia/Broken_Hill", "Australia/Canberra", "Australia/Currie", "Australia/Darwin", "Australia/Eucla", "Australia/Hobart", "Australia/LHI", "Australia/Lindeman", "Australia/Lord_Howe", "Australia/Melbourne", "Australia/NSW", "Australia/North", "Australia/Perth", "Australia/Queensland", "Australia/South", "Australia/Sydney", "Australia/Tasmania", "Australia/Victoria", "Australia/West", "Australia/Yancowinna"});
        m_tzs.put("AT", new String[]{"Europe/Vienna"});
        m_tzs.put("AZ", new String[]{"Asia/Baku"});
        m_tzs.put("BS", new String[]{"America/Nassau"});
        m_tzs.put("BH", new String[]{"Asia/Bahrain"});
        m_tzs.put("BD", new String[]{"Asia/Dacca", "Asia/Dhaka", "BST"});
        m_tzs.put("BB", new String[]{"America/Barbados"});
        m_tzs.put("BY", new String[]{"Europe/Minsk"});
        m_tzs.put("BE", new String[]{"Europe/Brussels"});
        m_tzs.put("BZ", new String[]{"America/Belize"});
        m_tzs.put("BJ", new String[]{"Africa/Porto-Novo"});
        m_tzs.put("BM", new String[]{"Atlantic/Bermuda"});
        m_tzs.put("BT", new String[]{"Asia/Thimbu", "Asia/Thimphu"});
        m_tzs.put("BO", new String[]{"America/La_Paz"});
        m_tzs.put("BQ", new String[]{"America/Kralendijk"});
        m_tzs.put("BA", new String[]{"Europe/Sarajevo"});
        m_tzs.put("BW", new String[]{"Africa/Gaborone"});
        m_tzs.put("BR", new String[]{"America/Araguaina", "America/Bahia", "America/Belem", "America/Boa_Vista", "America/Campo_Grande", "America/Cuiaba", "America/Eirunepe", "America/Fortaleza", "America/Maceio", "America/Manaus", "America/Noronha", "America/Porto_Acre", "America/Porto_Velho", "America/Recife", "America/Rio_Branco", "America/Santarem", "America/Sao_Paulo", "BET", "Brazil/Acre", "Brazil/DeNoronha", "Brazil/East", "Brazil/West"});
        m_tzs.put("IO", new String[]{"Indian/Chagos"});
        m_tzs.put("BN", new String[]{"Asia/Brunei"});
        m_tzs.put("BG", new String[]{"Europe/Sofia"});
        m_tzs.put("BF", new String[]{"Africa/Ouagadougou"});
        m_tzs.put("BI", new String[]{"Africa/Bujumbura"});
        m_tzs.put("CV", new String[]{"Atlantic/Cape_Verde"});
        m_tzs.put("KH", new String[]{"Asia/Phnom_Penh"});
        m_tzs.put("CM", new String[]{"Africa/Douala"});
        m_tzs.put("CA", new String[]{"America/Atikokan", "America/Blanc-Sablon", "America/Cambridge_Bay", "America/Coral_Harbour", "America/Creston", "America/Dawson", "America/Dawson_Creek", "America/Edmonton", "America/Fort_Nelson", "America/Glace_Bay", "America/Goose_Bay", "America/Halifax", "America/Inuvik", "America/Iqaluit", "America/Moncton", "America/Montreal", "America/Nipigon", "America/Pangnirtung", "America/Rainy_River", "America/Rankin_Inlet", "America/Regina", "America/Resolute", "America/St_Johns", "America/Swift_Current", "America/Thunder_Bay", "America/Toronto", "America/Vancouver", "America/Whitehorse", "America/Winnipeg", "America/Yellowknife", "CNT", "Canada/Atlantic", "Canada/Central", "Canada/East-Saskatchewan", "Canada/Eastern", "Canada/Mountain", "Canada/Newfoundland", "Canada/Pacific", "Canada/Saskatchewan", "Canada/Yukon"});
        m_tzs.put("KY", new String[]{"America/Cayman"});
        m_tzs.put("CF", new String[]{"Africa/Bangui"});
        m_tzs.put("TD", new String[]{"Africa/Ndjamena"});
        m_tzs.put("CL", new String[]{"America/Punta_Arenas", "America/Santiago", "Chile/Continental", "Chile/EasterIsland", "Pacific/Easter"});
        m_tzs.put("CN", new String[]{"Asia/Chongqing", "Asia/Chungking", "Asia/Harbin", "Asia/Kashgar", "Asia/Shanghai", "Asia/Urumqi", "CTT", "PRC"});
        m_tzs.put("CX", new String[]{"Indian/Christmas"});
        m_tzs.put("CC", new String[]{"Indian/Cocos"});
        m_tzs.put("CO", new String[]{"America/Bogota"});
        m_tzs.put("KM", new String[]{"Indian/Comoro"});
        m_tzs.put("CG", new String[]{"Africa/Brazzaville"});
        m_tzs.put("CD", new String[]{"Africa/Kinshasa", "Africa/Lubumbashi"});
        m_tzs.put("CK", new String[]{"Pacific/Rarotonga"});
        m_tzs.put("CR", new String[]{"America/Costa_Rica"});
        m_tzs.put("CI", new String[]{"Africa/Abidjan", "Africa/Timbuktu"});
        m_tzs.put("HR", new String[]{"Europe/Zagreb"});
        m_tzs.put("CU", new String[]{"America/Havana", "Cuba"});
        m_tzs.put("CW", new String[]{"America/Curacao"});
        m_tzs.put("CY", new String[]{"Asia/Famagusta", "Asia/Nicosia", "Europe/Nicosia"});
        m_tzs.put("CZ", new String[]{"Europe/Prague"});
        m_tzs.put("DK", new String[]{"Europe/Copenhagen"});
        m_tzs.put("DJ", new String[]{"Africa/Djibouti"});
        m_tzs.put("DM", new String[]{"America/Dominica"});
        m_tzs.put("DO", new String[]{"America/Santo_Domingo"});
        m_tzs.put("EC", new String[]{"America/Guayaquil", "Pacific/Galapagos"});
        m_tzs.put("EG", new String[]{"ART", "Africa/Cairo", "Egypt"});
        m_tzs.put("SV", new String[]{"America/El_Salvador"});
        m_tzs.put("GQ", new String[]{"Africa/Malabo"});
        m_tzs.put("ER", new String[]{"Africa/Asmara", "Africa/Asmera"});
        m_tzs.put("EE", new String[]{"Europe/Tallinn"});
        m_tzs.put("SZ", new String[]{"Africa/Mbabane"});
        m_tzs.put("ET", new String[]{"Africa/Addis_Ababa"});
        m_tzs.put("FK", new String[]{"Atlantic/Stanley"});
        m_tzs.put("FO", new String[]{"Atlantic/Faeroe", "Atlantic/Faroe"});
        m_tzs.put("FJ", new String[]{"Pacific/Fiji"});
        m_tzs.put("FI", new String[]{"Europe/Helsinki"});
        m_tzs.put("FR", new String[]{"ECT", "Europe/Paris"});
        m_tzs.put("GF", new String[]{"America/Cayenne"});
        m_tzs.put("PF", new String[]{"Pacific/Gambier", "Pacific/Marquesas", "Pacific/Tahiti"});
        m_tzs.put("TF", new String[]{"Indian/Kerguelen"});
        m_tzs.put("GA", new String[]{"Africa/Libreville"});
        m_tzs.put("GM", new String[]{"Africa/Banjul"});
        m_tzs.put("GE", new String[]{"Asia/Tbilisi"});
        m_tzs.put("DE", new String[]{"Europe/Berlin", "Europe/Busingen"});
        m_tzs.put("GH", new String[]{"Africa/Accra"});
        m_tzs.put("GI", new String[]{"Europe/Gibraltar"});
        m_tzs.put("GR", new String[]{"Europe/Athens"});
        m_tzs.put("GL", new String[]{"America/Danmarkshavn", "America/Godthab", "America/Scoresbysund", "America/Thule"});
        m_tzs.put("GD", new String[]{"America/Grenada"});
        m_tzs.put("GP", new String[]{"America/Guadeloupe"});
        m_tzs.put("GU", new String[]{"Pacific/Guam"});
        m_tzs.put("GT", new String[]{"America/Guatemala"});
        m_tzs.put("GG", new String[]{"Europe/Guernsey"});
        m_tzs.put("GN", new String[]{"Africa/Conakry"});
        m_tzs.put("GW", new String[]{"Africa/Bissau"});
        m_tzs.put("GY", new String[]{"America/Guyana"});
        m_tzs.put("HT", new String[]{"America/Port-au-Prince"});
        m_tzs.put("VA", new String[]{"Europe/Vatican"});
        m_tzs.put("HN", new String[]{"America/Tegucigalpa"});
        m_tzs.put("HK", new String[]{"Asia/Hong_Kong", "Hongkong"});
        m_tzs.put("HU", new String[]{"Europe/Budapest"});
        m_tzs.put("IS", new String[]{"Atlantic/Reykjavik", "Iceland"});
        m_tzs.put("IN", new String[]{"Asia/Calcutta", "Asia/Kolkata", "IST"});
        m_tzs.put("ID", new String[]{"Asia/Jakarta", "Asia/Jayapura", "Asia/Makassar", "Asia/Pontianak", "Asia/Ujung_Pandang"});
        m_tzs.put("IR", new String[]{"Asia/Tehran", "Iran"});
        m_tzs.put("IQ", new String[]{"Asia/Baghdad"});
        m_tzs.put("IE", new String[]{"Eire", "Europe/Dublin"});
        m_tzs.put("IM", new String[]{"Europe/Isle_of_Man"});
        m_tzs.put("IL", new String[]{"Asia/Jerusalem", "Asia/Tel_Aviv", "Israel"});
        m_tzs.put("IT", new String[]{"Europe/Rome"});
        m_tzs.put("JM", new String[]{"America/Jamaica", "Jamaica"});
        m_tzs.put("JP", new String[]{"Asia/Tokyo", "JST", "Japan"});
        m_tzs.put("JE", new String[]{"Europe/Jersey"});
        m_tzs.put("JO", new String[]{"Asia/Amman"});
        m_tzs.put("KZ", new String[]{"Asia/Almaty", "Asia/Aqtau", "Asia/Aqtobe", "Asia/Atyrau", "Asia/Oral", "Asia/Qyzylorda"});
        m_tzs.put("KE", new String[]{"Africa/Nairobi", "EAT"});
        m_tzs.put("KI", new String[]{"Pacific/Enderbury", "Pacific/Kiritimati", "Pacific/Tarawa"});
        m_tzs.put("KP", new String[]{"Asia/Pyongyang"});
        m_tzs.put("KR", new String[]{"Asia/Seoul", "ROK"});
        m_tzs.put("KW", new String[]{"Asia/Kuwait"});
        m_tzs.put("KG", new String[]{"Asia/Bishkek"});
        m_tzs.put("LA", new String[]{"Asia/Vientiane"});
        m_tzs.put("LV", new String[]{"Europe/Riga"});
        m_tzs.put("LB", new String[]{"Asia/Beirut"});
        m_tzs.put("LS", new String[]{"Africa/Maseru"});
        m_tzs.put("LR", new String[]{"Africa/Monrovia"});
        m_tzs.put("LY", new String[]{"Africa/Tripoli", "Libya"});
        m_tzs.put("LI", new String[]{"Europe/Vaduz"});
        m_tzs.put("LT", new String[]{"Europe/Vilnius"});
        m_tzs.put("LU", new String[]{"Europe/Luxembourg"});
        m_tzs.put("MO", new String[]{"Asia/Macao", "Asia/Macau"});
        m_tzs.put("MG", new String[]{"Indian/Antananarivo"});
        m_tzs.put("MW", new String[]{"Africa/Blantyre"});
        m_tzs.put("MY", new String[]{"Asia/Kuala_Lumpur", "Asia/Kuching"});
        m_tzs.put("MV", new String[]{"Indian/Maldives"});
        m_tzs.put("ML", new String[]{"Africa/Bamako"});
        m_tzs.put("MT", new String[]{"Europe/Malta"});
        m_tzs.put("MH", new String[]{"Kwajalein", "Pacific/Kwajalein", "Pacific/Majuro"});
        m_tzs.put("MQ", new String[]{"America/Martinique"});
        m_tzs.put("MR", new String[]{"Africa/Nouakchott"});
        m_tzs.put("MU", new String[]{"Indian/Mauritius"});
        m_tzs.put("YT", new String[]{"Indian/Mayotte"});
        m_tzs.put("MX", new String[]{"America/Bahia_Banderas", "America/Cancun", "America/Chihuahua", "America/Ensenada", "America/Hermosillo", "America/Matamoros", "America/Mazatlan", "America/Merida", "America/Mexico_City", "America/Monterrey", "America/Ojinaga", "America/Santa_Isabel", "America/Tijuana", "Mexico/BajaNorte", "Mexico/BajaSur", "Mexico/General"});
        m_tzs.put("FM", new String[]{"Pacific/Chuuk", "Pacific/Kosrae", "Pacific/Pohnpei", "Pacific/Ponape", "Pacific/Truk", "Pacific/Yap"});
        m_tzs.put("MD", new String[]{"Europe/Chisinau", "Europe/Tiraspol"});
        m_tzs.put("MC", new String[]{"Europe/Monaco"});
        m_tzs.put("MN", new String[]{"Asia/Choibalsan", "Asia/Hovd", "Asia/Ulaanbaatar", "Asia/Ulan_Bator"});
        m_tzs.put("ME", new String[]{"Europe/Podgorica"});
        m_tzs.put("MS", new String[]{"America/Montserrat"});
        m_tzs.put("MA", new String[]{"Africa/Casablanca"});
        m_tzs.put("MZ", new String[]{"Africa/Maputo", "CAT"});
        m_tzs.put("MM", new String[]{"Asia/Rangoon", "Asia/Yangon"});
        m_tzs.put("NA", new String[]{"Africa/Windhoek"});
        m_tzs.put("NR", new String[]{"Pacific/Nauru"});
        m_tzs.put("NP", new String[]{"Asia/Kathmandu", "Asia/Katmandu"});
        m_tzs.put("NL", new String[]{"Europe/Amsterdam"});
        m_tzs.put("NC", new String[]{"Pacific/Noumea"});
        m_tzs.put("NZ", new String[]{"Antarctica/South_Pole", "NST", "NZ", "NZ-CHAT", "Pacific/Auckland", "Pacific/Chatham"});
        m_tzs.put("NI", new String[]{"America/Managua"});
        m_tzs.put("NE", new String[]{"Africa/Niamey"});
        m_tzs.put("NG", new String[]{"Africa/Lagos"});
        m_tzs.put("NU", new String[]{"Pacific/Niue"});
        m_tzs.put("NF", new String[]{"Pacific/Norfolk"});
        m_tzs.put("MK", new String[]{"Europe/Skopje"});
        m_tzs.put("MP", new String[]{"Pacific/Saipan"});
        m_tzs.put("NO", new String[]{"Atlantic/Jan_Mayen", "Europe/Oslo"});
        m_tzs.put("OM", new String[]{"Asia/Muscat"});
        m_tzs.put("PK", new String[]{"Asia/Karachi", "PLT"});
        m_tzs.put("PW", new String[]{"Pacific/Palau"});
        m_tzs.put("PS", new String[]{"Asia/Gaza", "Asia/Hebron"});
        m_tzs.put("PA", new String[]{"America/Panama"});
        m_tzs.put("PG", new String[]{"Pacific/Bougainville", "Pacific/Port_Moresby"});
        m_tzs.put("PY", new String[]{"America/Asuncion"});
        m_tzs.put("PE", new String[]{"America/Lima"});
        m_tzs.put("PH", new String[]{"Asia/Manila"});
        m_tzs.put("PN", new String[]{"Pacific/Pitcairn"});
        m_tzs.put("PL", new String[]{"Europe/Warsaw", "Poland"});
        m_tzs.put("PT", new String[]{"Atlantic/Azores", "Atlantic/Madeira", "Europe/Lisbon", "Portugal"});
        m_tzs.put("PR", new String[]{"America/Puerto_Rico", "PRT"});
        m_tzs.put("QA", new String[]{"Asia/Qatar"});
        m_tzs.put("RE", new String[]{"Indian/Reunion"});
        m_tzs.put("RO", new String[]{"Europe/Bucharest"});
        m_tzs.put("RU", new String[]{"Asia/Anadyr", "Asia/Barnaul", "Asia/Chita", "Asia/Irkutsk", "Asia/Kamchatka", "Asia/Khandyga", "Asia/Krasnoyarsk", "Asia/Magadan", "Asia/Novokuznetsk", "Asia/Novosibirsk", "Asia/Omsk", "Asia/Sakhalin", "Asia/Srednekolymsk", "Asia/Tomsk", "Asia/Ust-Nera", "Asia/Vladivostok", "Asia/Yakutsk", "Asia/Yekaterinburg", "Europe/Astrakhan", "Europe/Kaliningrad", "Europe/Kirov", "Europe/Moscow", "Europe/Samara", "Europe/Saratov", "Europe/Ulyanovsk", "Europe/Volgograd", "W-SU"});
        m_tzs.put("RW", new String[]{"Africa/Kigali"});
        m_tzs.put("BL", new String[]{"America/St_Barthelemy"});
        m_tzs.put("SH", new String[]{"Atlantic/St_Helena"});
        m_tzs.put("KN", new String[]{"America/St_Kitts"});
        m_tzs.put("LC", new String[]{"America/St_Lucia"});
        m_tzs.put("MF", new String[]{"America/Marigot"});
        m_tzs.put("PM", new String[]{"America/Miquelon"});
        m_tzs.put("VC", new String[]{"America/St_Vincent"});
        m_tzs.put("WS", new String[]{"MIT", "Pacific/Apia"});
        m_tzs.put("SM", new String[]{"Europe/San_Marino"});
        m_tzs.put("ST", new String[]{"Africa/Sao_Tome"});
        m_tzs.put("SA", new String[]{"Asia/Riyadh"});
        m_tzs.put("SN", new String[]{"Africa/Dakar"});
        m_tzs.put("RS", new String[]{"Europe/Belgrade"});
        m_tzs.put("SC", new String[]{"Indian/Mahe"});
        m_tzs.put("SL", new String[]{"Africa/Freetown"});
        m_tzs.put("SG", new String[]{"Asia/Singapore", "Singapore"});
        m_tzs.put("SX", new String[]{"America/Lower_Princes"});
        m_tzs.put("SK", new String[]{"Europe/Bratislava"});
        m_tzs.put("SI", new String[]{"Europe/Ljubljana"});
        m_tzs.put("SB", new String[]{"Pacific/Guadalcanal", "SST"});
        m_tzs.put("SO", new String[]{"Africa/Mogadishu"});
        m_tzs.put("ZA", new String[]{"Africa/Johannesburg"});
        m_tzs.put("GS", new String[]{"Atlantic/South_Georgia"});
        m_tzs.put("SS", new String[]{"Africa/Juba"});
        m_tzs.put("ES", new String[]{"Africa/Ceuta", "Atlantic/Canary", "Europe/Madrid"});
        m_tzs.put("LK", new String[]{"Asia/Colombo"});
        m_tzs.put("SD", new String[]{"Africa/Khartoum"});
        m_tzs.put("SR", new String[]{"America/Paramaribo"});
        m_tzs.put("SJ", new String[]{"Arctic/Longyearbyen"});
        m_tzs.put("SE", new String[]{"Europe/Stockholm"});
        m_tzs.put("CH", new String[]{"Europe/Zurich"});
        m_tzs.put("SY", new String[]{"Asia/Damascus"});
        m_tzs.put("TW", new String[]{"Asia/Taipei", "ROC"});
        m_tzs.put("TJ", new String[]{"Asia/Dushanbe"});
        m_tzs.put("TZ", new String[]{"Africa/Dar_es_Salaam"});
        m_tzs.put("TH", new String[]{"Asia/Bangkok"});
        m_tzs.put("TL", new String[]{"Asia/Dili"});
        m_tzs.put("TG", new String[]{"Africa/Lome"});
        m_tzs.put("TK", new String[]{"Pacific/Fakaofo"});
        m_tzs.put("TO", new String[]{"Pacific/Tongatapu"});
        m_tzs.put("TT", new String[]{"America/Port_of_Spain", "America/Virgin"});
        m_tzs.put("TN", new String[]{"Africa/Tunis"});
        m_tzs.put("TR", new String[]{"Asia/Istanbul", "Europe/Istanbul", "Turkey"});
        m_tzs.put("TM", new String[]{"Asia/Ashgabat", "Asia/Ashkhabad"});
        m_tzs.put("TC", new String[]{"America/Grand_Turk"});
        m_tzs.put("TV", new String[]{"Pacific/Funafuti"});
        m_tzs.put("UG", new String[]{"Africa/Kampala"});
        m_tzs.put("UA", new String[]{"Europe/Kiev", "Europe/Simferopol", "Europe/Uzhgorod", "Europe/Zaporozhye"});
        m_tzs.put("AE", new String[]{"Asia/Dubai"});
        m_tzs.put("GB", new String[]{"Europe/Belfast", "Europe/London", "GB", "GB-Eire"});
        m_tzs.put("US", new String[]{"AST", "America/Adak", "America/Anchorage", "America/Atka", "America/Boise", "America/Chicago", "America/Denver", "America/Detroit", "America/Fort_Wayne", "America/Indiana/Indianapolis", "America/Indiana/Knox", "America/Indiana/Marengo", "America/Indiana/Petersburg", "America/Indiana/Tell_City", "America/Indiana/Vevay", "America/Indiana/Vincennes", "America/Indiana/Winamac", "America/Indianapolis", "America/Juneau", "America/Kentucky/Louisville", "America/Kentucky/Monticello", "America/Knox_IN", "America/Los_Angeles", "America/Louisville", "America/Menominee", "America/Metlakatla", "America/New_York", "America/Nome", "America/North_Dakota/Beulah", "America/North_Dakota/Center", "America/North_Dakota/New_Salem", "America/Phoenix", "America/Shiprock", "America/Sitka", "America/Yakutat", "CST", "IET", "Navajo", "PNT", "PST", "Pacific/Honolulu", "US/Alaska", "US/Aleutian", "US/Arizona", "US/Central", "US/East-Indiana", "US/Eastern", "US/Hawaii", "US/Indiana-Starke", "US/Michigan", "US/Mountain", "US/Pacific", "US/Pacific-New"});
        m_tzs.put("UM", new String[]{"Pacific/Johnston", "Pacific/Midway", "Pacific/Wake"});
        m_tzs.put("UY", new String[]{"America/Montevideo"});
        m_tzs.put("UZ", new String[]{"Asia/Samarkand", "Asia/Tashkent"});
        m_tzs.put("VU", new String[]{"Pacific/Efate"});
        m_tzs.put("VE", new String[]{"America/Caracas"});
        m_tzs.put("VN", new String[]{"Asia/Ho_Chi_Minh", "Asia/Saigon", "VST"});
        m_tzs.put("VG", new String[]{"America/Tortola"});
        m_tzs.put("VI", new String[]{"America/St_Thomas"});
        m_tzs.put("WF", new String[]{"Pacific/Wallis"});
        m_tzs.put("EH", new String[]{"Africa/El_Aaiun"});
        m_tzs.put("YE", new String[]{"Asia/Aden"});
        m_tzs.put("ZM", new String[]{"Africa/Lusaka"});
        m_tzs.put("ZW", new String[]{"Africa/Harare"});
        m_inited = true;
    }

    public static boolean is_country(String str) {
        return is_country((ArrayList<String>) new ArrayList(Collections.singletonList(str)));
    }

    public static boolean is_country(ArrayList<String> arrayList) {
        return get_timezones(arrayList).contains(TimeZone.getDefault().getID());
    }

    public static boolean is_country(JSONArray jSONArray) {
        return get_timezones(jSONArray).contains(TimeZone.getDefault().getID());
    }
}
