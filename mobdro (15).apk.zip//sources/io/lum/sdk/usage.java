package io.lum.sdk;

import android.content.Context;
import b.a.a.a.a;
import io.lum.sdk.util;
import java.util.Timer;
import java.util.TimerTask;

public class usage {
    public static conf m_conf;
    public static Timer m_next_t;
    public static stats m_prev;
    public static util.zerr m_zerr;

    public static class stats {
        public long m_bytes;
        public int m_quality;
        public long m_ts;

        public stats() {
            this(util.get_mobile_total_bytes(), System.currentTimeMillis(), 0);
        }

        public stats(long j, long j2, int i) {
            this.m_bytes = j;
            this.m_ts = j2;
            this.m_quality = i;
        }

        public static stats load() {
            return new stats(usage.m_conf.get_long(conf.USAGE_STATS_BYTES), usage.m_conf.get_long(conf.USAGE_STATS_TS), usage.m_conf.get_int(conf.USAGE_STATS_QUALITY));
        }

        public stats save() {
            usage.m_conf.set(conf.USAGE_STATS_BYTES, this.m_bytes);
            usage.m_conf.set(conf.USAGE_STATS_TS, this.m_ts);
            usage.m_conf.set(conf.USAGE_STATS_QUALITY, this.m_quality);
            return this;
        }

        public void update_quality(int i) {
            this.m_quality = i;
            usage.m_conf.set(conf.USAGE_STATS_QUALITY, i);
        }
    }

    public static void init(Context context) {
        conf conf = new conf(context);
        m_conf = conf;
        if (conf.get_bool(conf.USAGE_STATS)) {
            m_prev = stats.load();
            m_zerr = new util.zerr("usage");
            run(util.MS_HOUR);
        }
    }

    public static void run(final int i) {
        if (update()) {
            Timer timer = new Timer();
            m_next_t = timer;
            timer.schedule(new TimerTask() {
                public void run() {
                    usage.run(i * 2);
                }
            }, (long) i);
        }
    }

    public static void uninit() {
        Timer timer = m_next_t;
        if (timer != null) {
            timer.cancel();
            m_next_t = null;
        }
    }

    public static boolean update() {
        stats stats2 = new stats();
        stats stats3 = m_prev;
        long j = stats3.m_bytes;
        if (j < 0) {
            m_zerr.err("not supported");
            util.perr(3, "usage_stats_not_supported", true);
            return false;
        }
        long j2 = stats3.m_ts;
        if (j2 == 0) {
            m_prev = stats2.save();
            return true;
        }
        long j3 = stats2.m_bytes - j;
        if (j3 < 0) {
            m_prev = stats2.save();
            return true;
        }
        long j4 = stats2.m_ts - j2;
        int round = Math.round((float) (j4 / 3600000));
        long j5 = (j3 / j4) * 3600000;
        String format = String.format("bytes: %s, duration: %s, quality: %s", new Object[]{Long.valueOf(j3), Long.valueOf(j4), Integer.valueOf(round)});
        if (round > m_prev.m_quality) {
            if (round == 1 || (round <= 512 && ((round - 1) & round) == 0)) {
                StringBuilder a2 = a.a("usage_stats_");
                a2.append(util.pad_number(round, 3));
                String sb = a2.toString();
                util.perr(sb, "" + j5, format);
            }
            m_prev.update_quality(round);
        }
        m_zerr.notice(format);
        return true;
    }
}
