package io.lum.sdk;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import b.a.a.a.a;
import io.lum.sdk.util;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.security.InvalidParameterException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

public class dev_util {
    public static final String TYPE_ETH = "eth";
    public static final String TYPE_MOBILE = "3g";
    public static final String TYPE_OTHER = "other";
    public static final String TYPE_VPN = "vpn";
    public static final String TYPE_WIFI = "wl";
    public static final String m_cid_kv_delim = "::";
    public static Random m_rand = new Random();
    public static util.zerr m_zerr = new util.zerr("dev_util");
    public static Pattern p = Pattern.compile("\\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\\.|$)){4}\\b");

    public static String SHA1(File file) {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        FileInputStream fileInputStream = new FileInputStream(file);
        byte[] bArr = new byte[8192];
        int i = 0;
        while (i != -1) {
            i = fileInputStream.read(bArr);
            if (i > 0) {
                instance.update(bArr, 0, i);
            }
        }
        return convertToHex(instance.digest());
    }

    public static String build_cid_kv(String str, String str2) {
        return a.a(str, m_cid_kv_delim, str2);
    }

    public static String convertToHex(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b2 : bArr) {
            byte b3 = (b2 >>> 4) & 15;
            int i = 0;
            while (true) {
                sb.append((char) (b3 <= 9 ? b3 + 48 : (b3 + 97) - 10));
                b3 = b2 & 15;
                int i2 = i + 1;
                if (i >= 1) {
                    break;
                }
                i = i2;
            }
        }
        return sb.toString();
    }

    public static String get_arch() {
        String property = System.getProperty("os.arch");
        return property != null ? property.contains("arch") ? "arm" : property.contains("x86") ? "x86" : property.contains("mips") ? "mips" : "" : "";
    }

    public static String get_cid_filename(String str, String str2) {
        return str + "/" + str2 + ".cid";
    }

    public static Calendar get_day_start() {
        Calendar instance = Calendar.getInstance();
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        instance.set(14, 0);
        return instance;
    }

    public static String[] get_dns_servers(Context context) {
        return util.has_network_callback() ? get_dns_servers_from_cm(context) : get_dns_servers_from_sysprops();
    }

    @TargetApi(21)
    public static String[] get_dns_servers_from_cm(Context context) {
        ConnectivityManager connectivityManager = util.get_connectivity_manager(context);
        Network[] allNetworks = connectivityManager.getAllNetworks();
        int length = allNetworks.length;
        int i = 0;
        while (i < length) {
            Network network = allNetworks[i];
            if (connectivityManager.getNetworkInfo(network).isConnected()) {
                try {
                    List<InetAddress> dnsServers = connectivityManager.getLinkProperties(network).getDnsServers();
                    util.zerr zerr = m_zerr;
                    zerr.notice("dns_servers = " + dnsServers);
                    if (dnsServers == null) {
                        return null;
                    }
                    ArrayList arrayList = new ArrayList();
                    for (InetAddress hostAddress : dnsServers) {
                        arrayList.add(hostAddress.getHostAddress());
                    }
                    return (String[]) arrayList.toArray(new String[0]);
                } catch (Exception unused) {
                    return null;
                }
            } else {
                i++;
            }
        }
        return null;
    }

    @SuppressLint({"PrivateApi"})
    public static String[] get_dns_servers_from_sysprops() {
        String[] strArr = {"net.dns1", "net.dns2", "net.dns3", "net.dns4"};
        ArrayList arrayList = new ArrayList();
        try {
            Method method = Class.forName("android.os.SystemProperties").getMethod("get", new Class[]{String.class});
            for (int i = 0; i < 4; i++) {
                String str = (String) method.invoke((Object) null, new Object[]{strArr[i]});
                if (str != null && ((str.matches("^\\d+(\\.\\d+){3}$") || str.matches("^[0-9a-f]+(:[0-9a-f]*)+:[0-9a-f]+$")) && !arrayList.contains(str))) {
                    arrayList.add(str);
                }
            }
            util.zerr zerr = m_zerr;
            zerr.notice("dns_servers = " + arrayList);
            if (arrayList.size() > 0) {
                return (String[]) arrayList.toArray(new String[0]);
            }
        } catch (Exception e2) {
            util.perr(3, "get_dns_servers_fail", util.e2s(e2), "", true);
        }
        return null;
    }

    public static HashSet<InetAddress> get_ips(NetworkInterface networkInterface) {
        HashSet<InetAddress> hashSet = new HashSet<>();
        Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
        while (inetAddresses.hasMoreElements()) {
            InetAddress nextElement = inetAddresses.nextElement();
            if (nextElement instanceof Inet4Address) {
                hashSet.add(nextElement);
            }
        }
        return hashSet;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: java.net.InetAddress} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v0, resolved type: java.net.Inet6Address} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.net.Inet6Address get_ipv6(java.net.NetworkInterface r14) {
        /*
            java.util.Enumeration r0 = r14.getInetAddresses()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r2 = 0
            r3 = 0
            r4 = 0
        L_0x000c:
            boolean r5 = r0.hasMoreElements()
            r6 = 5
            r7 = 2
            r8 = 1
            if (r5 == 0) goto L_0x0084
            java.lang.Object r5 = r0.nextElement()
            java.net.InetAddress r5 = (java.net.InetAddress) r5
            boolean r9 = r5 instanceof java.net.Inet4Address
            if (r9 == 0) goto L_0x002a
            java.lang.Object[] r6 = new java.lang.Object[r8]
            r6[r2] = r5
            java.lang.String r5 = "address: %s, type: v4"
            java.lang.String r5 = java.lang.String.format(r5, r6)
            goto L_0x0075
        L_0x002a:
            boolean r9 = r5 instanceof java.net.Inet6Address
            if (r9 == 0) goto L_0x0073
            boolean r9 = r5.isLinkLocalAddress()
            boolean r10 = r5.isSiteLocalAddress()
            boolean r11 = r5.isAnyLocalAddress()
            r12 = r5
            java.net.Inet6Address r12 = (java.net.Inet6Address) r12
            boolean r13 = r12.isIPv4CompatibleAddress()
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r6[r2] = r5
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r9)
            r6[r8] = r5
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r10)
            r6[r7] = r5
            r5 = 3
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r11)
            r6[r5] = r7
            r5 = 4
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r13)
            r6[r5] = r7
            java.lang.String r5 = "address: %s, type: v6, link_local: %s, site_local: %s, any_local: %s, v4_compatible: %s"
            java.lang.String r5 = java.lang.String.format(r5, r6)
            if (r10 != 0) goto L_0x000c
            if (r11 == 0) goto L_0x006a
            goto L_0x000c
        L_0x006a:
            if (r3 == 0) goto L_0x0070
            if (r4 == 0) goto L_0x0075
            if (r9 != 0) goto L_0x0075
        L_0x0070:
            r4 = r9
            r3 = r12
            goto L_0x0075
        L_0x0073:
            java.lang.String r5 = ""
        L_0x0075:
            boolean r6 = r5.isEmpty()
            if (r6 != 0) goto L_0x000c
            r1.append(r5)
            java.lang.String r5 = "\n"
            r1.append(r5)
            goto L_0x000c
        L_0x0084:
            io.lum.sdk.util$zerr r0 = m_zerr
            java.lang.Object[] r4 = new java.lang.Object[r7]
            r4[r2] = r14
            r4[r8] = r1
            java.lang.String r2 = "interface: %s, ips:\n%s"
            java.lang.String r2 = java.lang.String.format(r2, r4)
            r0.notice(r2)
            java.lang.String r0 = "ips"
            io.lum.sdk.util.perr((int) r6, (java.lang.String) r0, (java.lang.Object) r14, (java.lang.Object) r1, (boolean) r8)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_util.get_ipv6(java.net.NetworkInterface):java.net.Inet6Address");
    }

    @SuppressLint({"NewApi"})
    public static String get_type(NetworkCapabilities networkCapabilities, Context context) {
        if (networkCapabilities == null) {
            return null;
        }
        return new conf(context).get_bool(conf.DBG_MOBILE) ? TYPE_MOBILE : networkCapabilities.hasTransport(1) ? TYPE_WIFI : networkCapabilities.hasTransport(0) ? TYPE_MOBILE : networkCapabilities.hasTransport(3) ? TYPE_ETH : networkCapabilities.hasTransport(4) ? TYPE_VPN : TYPE_OTHER;
    }

    public static String get_type(NetworkInfo networkInfo, Context context) {
        if (networkInfo == null) {
            return null;
        }
        if (new conf(context).get_bool(conf.DBG_MOBILE)) {
            return TYPE_MOBILE;
        }
        int type = networkInfo.getType();
        return type == 1 ? TYPE_WIFI : type == 0 ? TYPE_MOBILE : type == 9 ? TYPE_ETH : type == 17 ? TYPE_VPN : TYPE_OTHER;
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String[] get_user_proxy(android.content.Context r5) {
        /*
            r0 = 0
            java.lang.Class<android.net.ConnectivityManager> r1 = android.net.ConnectivityManager.class
            java.lang.String r2 = "getProxy"
            r3 = 0
            java.lang.Class[] r4 = new java.lang.Class[r3]     // Catch:{ Exception -> 0x001e }
            java.lang.reflect.Method r1 = r1.getMethod(r2, r4)     // Catch:{ Exception -> 0x001e }
            android.net.ConnectivityManager r5 = io.lum.sdk.util.get_connectivity_manager(r5)     // Catch:{  }
            java.lang.Object[] r2 = new java.lang.Object[r3]     // Catch:{  }
            java.lang.Object r5 = r1.invoke(r5, r2)     // Catch:{  }
            if (r5 != 0) goto L_0x0019
            return r0
        L_0x0019:
            java.lang.String[] r5 = get_user_proxy((java.lang.Object) r5)     // Catch:{  }
            return r5
        L_0x001e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.dev_util.get_user_proxy(android.content.Context):java.lang.String[]");
    }

    @SuppressLint({"PrivateApi"})
    public static String[] get_user_proxy(Object obj) {
        Class<?> cls = Class.forName("android.net.ProxyProperties");
        String[] strArr = {(String) cls.getMethod("getHost", new Class[0]).invoke(obj, new Object[0]), String.valueOf((Integer) cls.getMethod("getPort", new Class[0]).invoke(obj, new Object[0])), (String) cls.getMethod("getExclusionList", new Class[0]).invoke(obj, new Object[0])};
        if (strArr[0] != null) {
            return strArr;
        }
        return null;
    }

    public static String[] parse_cid_kv(String str) {
        return str.split(m_cid_kv_delim);
    }

    public static String perr_id(String str) {
        return a.a("lum_sdk_android_dev_", str);
    }

    public static List<Inet4Address> resolve_domain(String str) {
        InetAddress[] inetAddressArr;
        InetAddress[] inetAddressArr2;
        ArrayList arrayList = new ArrayList();
        try {
            if (!valid_ip(str)) {
                inetAddressArr = InetAddress.getAllByName(str);
            } else {
                inetAddressArr = new InetAddress[1];
                try {
                    inetAddressArr[0] = InetAddress.getByName(str);
                } catch (UnknownHostException unused) {
                } catch (Exception e2) {
                    Exception exc = e2;
                    inetAddressArr2 = inetAddressArr;
                    e = exc;
                    m_zerr.err((Throwable) e);
                    inetAddressArr = inetAddressArr2;
                }
            }
        } catch (UnknownHostException unused2) {
            inetAddressArr = null;
        } catch (Exception e3) {
            e = e3;
            inetAddressArr2 = null;
            m_zerr.err((Throwable) e);
            inetAddressArr = inetAddressArr2;
        }
        if (inetAddressArr == null) {
            return null;
        }
        for (InetAddress inetAddress : inetAddressArr) {
            if (inetAddress instanceof Inet4Address) {
                arrayList.add((Inet4Address) inetAddress);
            }
        }
        m_zerr.debug(String.format("domain resolve: %s -> %s", new Object[]{str, arrayList}));
        if (arrayList.size() > 0) {
            return arrayList;
        }
        return null;
    }

    public static Inet4Address resolve_domain_random(String str) {
        return resolve_domain_random(str, (ArrayList) null);
    }

    public static Inet4Address resolve_domain_random(String str, ArrayList arrayList) {
        if (arrayList == null || arrayList.size() >= 1) {
            List<Inet4Address> resolve_domain = resolve_domain(str);
            if (resolve_domain == null) {
                return null;
            }
            Collections.shuffle(resolve_domain);
            Iterator<Inet4Address> it = resolve_domain.iterator();
            while (it.hasNext()) {
                Inet4Address next = it.next();
                if (arrayList == null || arrayList.contains(next.getHostAddress())) {
                    return next;
                }
                String format = String.format("resolved: %s, allowed: %s, failed: %s", new Object[]{resolve_domain, arrayList, next});
                util.zerr zerr = m_zerr;
                zerr.err("restricted_domain: " + str + " " + format);
                if (resolve_domain.size() < arrayList.size()) {
                    util.perr(3, "restricted_domain", str, format, true);
                }
            }
            return null;
        }
        throw new InvalidParameterException("allowed can't be empty");
    }

    public static void timeline_push(JSONArray jSONArray, String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("ev", str);
        jSONObject.put("ts", System.currentTimeMillis());
        jSONArray.put(jSONObject);
    }

    public static void unshift_json_array(JSONArray jSONArray, JSONObject jSONObject) {
        for (int length = jSONArray.length() - 1; length >= 0; length--) {
            jSONArray.put(length + 1, jSONArray.get(length));
        }
        jSONArray.put(0, jSONObject);
    }

    public static boolean valid_ip(String str) {
        return p.matcher(str).matches();
    }
}
