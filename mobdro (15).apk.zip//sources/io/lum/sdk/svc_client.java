package io.lum.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import b.a.a.a.a;
import d.a.a.t0;
import d.a.a.u0;
import d.a.a.v0;
import d.a.a.w0;
import io.lum.sdk.conf;
import io.lum.sdk.state;
import io.lum.sdk.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;

public class svc_client {
    public bcast_recv_svc m_bcast_recv;
    public Context m_ctx;
    public etask m_etask_destroy = null;
    public etask m_etask_start = null;
    @SuppressLint({"UseSparseArrays"})
    public HashMap<Integer, conf.key> m_hb_milestones = new HashMap<>();
    public int m_hb_period = 300000;
    public util.keepalive m_keepalive;
    public Runnable m_mobile_usage_report_r = new Runnable() {
        public void run() {
            util.log_mobile_usage(svc_client.this.m_ctx);
            if (util.m_conf != null && (svc_client.this.m_state == null || !svc_client.this.m_state.get_bool(state.MOBILE_CONNECTED) || svc_client.this.m_state.get_bool(state.WIFI_CONNECTED))) {
                util.m_conf.set(conf.LAST_ON_MOBILE, false);
            } else if (svc_client.this.m_running && util.m_conf != null && svc_client.this.m_state != null) {
                svc_client.this.mobile_usage_handler.postDelayed(this, 600000);
            }
        }
    };
    public dev_monitor m_monitor;
    public Timer m_monitor_timer;
    public long m_monitor_timer_interval = 3600000;
    public final Object m_monitor_timer_lock = new Object();
    public boolean m_running = false;
    public final Object m_running_lock = new Object();
    public state m_state;
    public state.listener m_state_listener = new state.listener() {
        public void on_changed(state.key key) {
            if (key == state.MOBILE_CONNECTED && svc_client.this.m_state.get_bool(state.MOBILE_CONNECTED) && !svc_client.this.m_state.get_bool(state.WIFI_CONNECTED)) {
                svc_client.this.report_mobile_usage();
            }
        }
    };
    public Handler mobile_usage_handler = new Handler();

    public svc_client(Context context) {
        zerr(7, "creating");
        this.m_ctx = context;
        new apk_config();
        if (!init()) {
            final ArrayList arrayList = new ArrayList();
            arrayList.add(conf.SDK_DISABLED);
            arrayList.add(conf.DISABLE_TLS1);
            util.m_conf.register_listener(new conf.listener() {
                public void on_changed(conf.key key) {
                    if (arrayList.contains(key) && svc_client.this.init()) {
                        util.m_conf.unregister_listener(this);
                    }
                }
            });
        }
    }

    private void create_dev_monitor() {
        if (this.m_monitor == null) {
            this.m_monitor = new dev_monitor(this.m_ctx);
        }
    }

    /* access modifiers changed from: private */
    public boolean init() {
        if (util.sdk_disabled(true) || util.sdk_unsupported()) {
            return false;
        }
        zerr(7, "initing");
        int load_choice = util.load_choice(util.m_conf);
        zerr(5, a.b("choice: ", load_choice));
        if (load_choice == 1) {
            zerr(5, "autostart");
            start("auto");
        }
        Thread.setDefaultUncaughtExceptionHandler(new util.exception_handler("svc_client", new w0(this)));
        int i = 300000 / this.m_hb_period;
        this.m_hb_milestones.put(Integer.valueOf(i), conf.FUNNEL_30_SVC_UP_5MIN);
        this.m_hb_milestones.put(Integer.valueOf(i * 6), conf.FUNNEL_32_SVC_UP_30MIN);
        this.m_hb_milestones.put(Integer.valueOf(i * 12), conf.FUNNEL_34_SVC_UP_1H);
        this.m_hb_milestones.put(Integer.valueOf(i * 24), conf.FUNNEL_36_SVC_UP_2H);
        this.m_hb_milestones.put(Integer.valueOf(i * 72), conf.FUNNEL_38_SVC_UP_6H);
        this.m_hb_milestones.put(Integer.valueOf(i * 144), conf.FUNNEL_40_SVC_UP_12H);
        return true;
    }

    private void init_bcast_recv() {
        if (this.m_bcast_recv == null) {
            this.m_bcast_recv = new bcast_recv_svc(this.m_ctx);
        }
    }

    /* access modifiers changed from: private */
    public void report_mobile_usage() {
        this.mobile_usage_handler.removeCallbacks(this.m_mobile_usage_report_r);
        this.mobile_usage_handler.post(this.m_mobile_usage_report_r);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:7|8|9|10|11|12) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0024 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void start_dev_monitor() {
        /*
            r8 = this;
            java.lang.Object r0 = r8.m_monitor_timer_lock
            monitor-enter(r0)
            r8.create_dev_monitor()     // Catch:{ all -> 0x0026 }
            io.lum.sdk.dev_monitor r1 = r8.m_monitor     // Catch:{ all -> 0x0026 }
            r1.start()     // Catch:{ all -> 0x0026 }
            java.util.Timer r1 = r8.m_monitor_timer     // Catch:{ all -> 0x0026 }
            if (r1 == 0) goto L_0x0011
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            return
        L_0x0011:
            java.util.Timer r2 = new java.util.Timer     // Catch:{ all -> 0x0026 }
            r2.<init>()     // Catch:{ all -> 0x0026 }
            r8.m_monitor_timer = r2     // Catch:{ all -> 0x0026 }
            io.lum.sdk.svc_client$5 r3 = new io.lum.sdk.svc_client$5     // Catch:{ IllegalStateException -> 0x0024 }
            r3.<init>()     // Catch:{ IllegalStateException -> 0x0024 }
            r4 = 0
            long r6 = r8.m_monitor_timer_interval     // Catch:{ IllegalStateException -> 0x0024 }
            r2.schedule(r3, r4, r6)     // Catch:{ IllegalStateException -> 0x0024 }
        L_0x0024:
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            return
        L_0x0026:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.svc_client.start_dev_monitor():void");
    }

    private void stop_dev_monitor() {
        synchronized (this.m_monitor_timer_lock) {
            if (this.m_monitor != null) {
                this.m_monitor.stop();
                if (this.m_monitor_timer != null) {
                    try {
                        this.m_monitor_timer.cancel();
                    } catch (IllegalStateException e2) {
                        util.perr(3, "dev_mon_timer_stop_err", e2.getMessage(), util.e2s(e2), true);
                    }
                    this.m_monitor_timer = null;
                }
            }
        }
    }

    private void terminate_bcast_recv() {
        bcast_recv_svc bcast_recv_svc = this.m_bcast_recv;
        if (bcast_recv_svc != null) {
            try {
                bcast_recv_svc.destroy();
            } catch (IllegalArgumentException unused) {
            }
        }
    }

    /* access modifiers changed from: private */
    public void zerr(int i, String str) {
        util._zerr("lumsdk/svc_client", i, str);
    }

    public /* synthetic */ void a() {
        try {
            this.m_etask_destroy.yield();
        } catch (Exception unused) {
        }
        this.m_etask_destroy = null;
    }

    public /* synthetic */ void a(String str) {
        zerr(5, a.a("svc_client destroy: ", str));
        util.perr(3, "svc_client_destroy_after_" + str, true);
        zerr(5, "destroying");
        try {
            util.thread_run(new v0(this));
            this.m_keepalive.stop();
            stop_dev_monitor();
            this.m_state.unregister_listener(this.m_state_listener);
            this.m_state.detach();
            terminate_bcast_recv();
            zerr(5, "destroyed");
        } catch (Exception e2) {
            zerr(5, "destroy exception: " + util.e2s(e2));
        } catch (Throwable th) {
            this.m_running = false;
            throw th;
        }
        this.m_running = false;
    }

    public /* synthetic */ void b() {
        util.m_conf.set(conf.SVC_THREAD_JAVA_CRASHES, util.m_conf.get_int(conf.SVC_THREAD_JAVA_CRASHES) + 1);
        restart("crash");
    }

    public /* synthetic */ void b(String str) {
        try {
            util.perr_funnel_main_send("21_svc_client_start", str);
            util.perr_funnel(conf.FUNNEL_06_SERVICE_START);
            state state = new state(this.m_ctx);
            this.m_state = state;
            state.register_listener(this.m_state_listener);
            report_mobile_usage();
            init_bcast_recv();
            if (!util.m_conf.get_bool(conf.NON_FIRST_RUN)) {
                util.m_conf.set(conf.NON_FIRST_RUN, true);
                util.perr("first_run", "");
            }
            start_dev_monitor();
            AnonymousClass3 r1 = new util.keepalive(config.NET_SVC_EXE, util.ACTION_NET_SVC_KEEPALIVE, bcast_recv.REQUEST_CODE_NET_SVC_KEEPALIVE, conf.LAST_NET_SVC_HEARTBEAT) {
                public void handle_heartbeat(Context context) {
                    super.handle_heartbeat(context);
                    if (this.m_count >= 1) {
                        Integer valueOf = Integer.valueOf(util.m_conf.get_int(conf.NET_SVC_HEARTBEAT_COUNT) + 1);
                        svc_client svc_client = svc_client.this;
                        svc_client.zerr(5, "heartbeat count: " + valueOf);
                        if (svc_client.this.m_hb_milestones.containsKey(valueOf)) {
                            util.perr_funnel((conf.key) svc_client.this.m_hb_milestones.get(valueOf));
                        }
                        util.m_conf.set(conf.NET_SVC_HEARTBEAT_COUNT, valueOf.intValue());
                    }
                }
            };
            this.m_keepalive = r1;
            r1.start(this.m_ctx, this.m_hb_period, 300000, false);
            util.perr_funnel_main_send("27_svc_client_start_success");
        } catch (Exception e2) {
            zerr(4, "start exception: " + util.e2s(e2));
        } catch (Throwable th) {
            this.m_running = true;
            throw th;
        }
        this.m_running = true;
    }

    public /* synthetic */ void c() {
        util.log_mobile_usage(this.m_ctx);
    }

    public /* synthetic */ void d() {
        try {
            this.m_etask_start.yield();
        } catch (Exception unused) {
        }
        this.m_etask_start = null;
    }

    public void destroy(String str) {
        synchronized (this.m_running_lock) {
            zerr(5, "destroying after " + str);
            if (this.m_etask_start != null) {
                zerr(5, "interrupting start");
                try {
                    this.m_etask_start.cancel();
                    this.m_etask_start = null;
                } catch (Exception unused) {
                    this.m_etask_start = null;
                } catch (Throwable th) {
                    this.m_etask_start = null;
                    this.m_running = false;
                    throw th;
                }
                this.m_running = false;
            }
            if (this.m_etask_destroy != null) {
                zerr(5, "already destroying");
            } else if (!this.m_running) {
                zerr(5, "already destroyed");
            } else {
                this.m_etask_destroy = etask.run((Runnable) new u0(this, str));
                util.thread_run(new t0(this), "svc_client_destroy");
            }
        }
    }

    public void restart(String str) {
        destroy(str);
        start(str);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:2|3|(3:5|6|7)|8|9|(3:11|12|13)(2:14|(3:16|17|18)(2:19|(3:21|22|23)(3:24|25|26)))) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0027 */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002b  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0032  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void start(java.lang.String r5) {
        /*
            r4 = this;
            java.lang.Object r0 = r4.m_running_lock
            monitor-enter(r0)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x006a }
            r1.<init>()     // Catch:{ all -> 0x006a }
            java.lang.String r2 = "starting after "
            r1.append(r2)     // Catch:{ all -> 0x006a }
            r1.append(r5)     // Catch:{ all -> 0x006a }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x006a }
            r2 = 7
            r4.zerr(r2, r1)     // Catch:{ all -> 0x006a }
            io.lum.sdk.etask r1 = r4.m_etask_destroy     // Catch:{ all -> 0x006a }
            r3 = 5
            if (r1 == 0) goto L_0x0027
            java.lang.String r1 = "waiting for destroy"
            r4.zerr(r3, r1)     // Catch:{ all -> 0x006a }
            io.lum.sdk.etask r1 = r4.m_etask_destroy     // Catch:{ Exception -> 0x0027 }
            r1.yield()     // Catch:{ Exception -> 0x0027 }
        L_0x0027:
            io.lum.sdk.etask r1 = r4.m_etask_start     // Catch:{ all -> 0x006a }
            if (r1 == 0) goto L_0x0032
            java.lang.String r5 = "already starting"
            r4.zerr(r3, r5)     // Catch:{ all -> 0x006a }
            monitor-exit(r0)     // Catch:{ all -> 0x006a }
            return
        L_0x0032:
            boolean r1 = r4.m_running     // Catch:{ all -> 0x006a }
            if (r1 == 0) goto L_0x003d
            java.lang.String r5 = "already running"
            r4.zerr(r2, r5)     // Catch:{ all -> 0x006a }
            monitor-exit(r0)     // Catch:{ all -> 0x006a }
            return
        L_0x003d:
            io.lum.sdk.conf r1 = io.lum.sdk.util.m_conf     // Catch:{ all -> 0x006a }
            int r1 = io.lum.sdk.util.load_choice(r1)     // Catch:{ all -> 0x006a }
            r2 = 1
            if (r1 == r2) goto L_0x004e
            r5 = 4
            java.lang.String r1 = "svc_client_start_not_free"
            io.lum.sdk.util.perr((int) r5, (java.lang.String) r1, (boolean) r2)     // Catch:{ all -> 0x006a }
            monitor-exit(r0)     // Catch:{ all -> 0x006a }
            return
        L_0x004e:
            java.lang.String r1 = "starting"
            r4.zerr(r3, r1)     // Catch:{ all -> 0x006a }
            d.a.a.x0 r1 = new d.a.a.x0     // Catch:{ all -> 0x006a }
            r1.<init>(r4, r5)     // Catch:{ all -> 0x006a }
            io.lum.sdk.etask r5 = io.lum.sdk.etask.run((java.lang.Runnable) r1)     // Catch:{ all -> 0x006a }
            r4.m_etask_start = r5     // Catch:{ all -> 0x006a }
            d.a.a.y0 r5 = new d.a.a.y0     // Catch:{ all -> 0x006a }
            r5.<init>(r4)     // Catch:{ all -> 0x006a }
            java.lang.String r1 = "svc_client_start"
            io.lum.sdk.util.thread_run(r5, r1)     // Catch:{ all -> 0x006a }
            monitor-exit(r0)     // Catch:{ all -> 0x006a }
            return
        L_0x006a:
            r5 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x006a }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.lum.sdk.svc_client.start(java.lang.String):void");
    }
}
