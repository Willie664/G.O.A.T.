package io.lum.sdk;

public class config {
    public static final String ANDROID_ZERR = "";
    public static final String ARCH_CPU = "ARM7A";
    public static final boolean BUILDTYPE_DEBUG = false;
    public static final boolean BUILDTYPE_DEV = false;
    public static final boolean BUILDTYPE_RELEASE = true;
    public static final boolean CONFIG_AMAZON = false;
    public static final boolean CONFIG_ANDROID_LUM_SDK_ONLY = true;
    public static final String CONFIG_BUILD_DATE = "29-Mar-20 13:57:13";
    public static final String CONFIG_CVS_TAG = "Ntag-1_177_86";
    public static final String CONFIG_DOMAIN = "luminati.io";
    public static final String CONFIG_HOSTNAME = "batandroid";
    public static final String CONFIG_HOSTNAME_FULL = "batandroid";
    public static final String CONFIG_MAKEFLAGS = "DIST=APP ARCH=ANDROID RELEASE=y AUTO_SIGN=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_LUM_SDK_COMPILE=y CONFIG_ANDROID_LUM_SDK_ONLY=y CONFIG_BATREQ_FROM=lum_android_sdk CONFIG_BATREQ=y CONFIG_BAT_CYCLE=y CONFIG_BAT_PLATFORM=app_androidr";
    public static final boolean CONFIG_NODE = false;
    public static final boolean CONFIG_NO_TRANSCODING = false;
    public static final boolean CONFIG_PKG_ANDROID = true;
    public static final boolean CONFIG_PKG_BEXT = true;
    public static final boolean CONFIG_PKG_INSTALL = true;
    public static final boolean CONFIG_PKG_PROTOCOL = true;
    public static final boolean CONFIG_PKG_SVC = true;
    public static final boolean CONFIG_PKG_UTIL = true;
    public static final String CONFIG_PRODUCT = "lum";
    public static final boolean CONFIG_PRODUCT_LUM = true;
    public static final boolean HAVE_MYSQL = false;
    public static final String HOSTARCH = "Linux";
    public static final boolean HOSTARCH_LINUX = true;
    public static final String NET_SVC_EXE = "net_svc";
    public static final String NET_SVC_ZIP = "net_svc-1.177.86.zip";
    public static final String NET_SVC_ZIP_PDB = "net_svc-1.177.86-pdb.zip";
    public static final String ZON_COPYRIGHT_YEAR = "2020";
    public static final String ZON_VERSION = "1.177.86";
    public static final int ZON_VERSION_1 = 1;
    public static final int ZON_VERSION_2 = 177;
    public static final int ZON_VERSION_3 = 86;
    public static final boolean _RELEASE = true;
}
