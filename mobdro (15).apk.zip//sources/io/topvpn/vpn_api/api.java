package io.topvpn.vpn_api;

import android.app.Activity;
import android.content.Context;

public class api extends io.lum.sdk.api {
    public static void deprecation_warning() {
    }

    public static void init(Activity activity) {
        deprecation_warning();
        io.lum.sdk.api.init(activity);
    }

    public static void init(Context context) {
        deprecation_warning();
        io.lum.sdk.api.init(context);
    }
}
