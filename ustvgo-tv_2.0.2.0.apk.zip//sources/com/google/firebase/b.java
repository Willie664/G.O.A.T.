package com.google.firebase;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.ah;
import com.google.android.gms.common.util.r;
import java.util.Arrays;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final String f2644a;
    public final String b;
    private final String c;
    private final String d;
    private final String e;
    private final String f;
    private final String g;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public String f2645a;
        public String b;
        public String c;
        public String d;
        public String e;
        public String f;
        public String g;
    }

    private b(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        ab.a(!r.b(str), (Object) "ApplicationId must be set.");
        this.f2644a = str;
        this.c = str2;
        this.d = str3;
        this.e = str4;
        this.b = str5;
        this.f = str6;
        this.g = str7;
    }

    public /* synthetic */ b(String str, String str2, String str3, String str4, String str5, String str6, String str7, byte b2) {
        this(str, str2, str3, str4, str5, str6, str7);
    }

    public static b a(Context context) {
        ah ahVar = new ah(context);
        String a2 = ahVar.a("google_app_id");
        if (TextUtils.isEmpty(a2)) {
            return null;
        }
        return new b(a2, ahVar.a("google_api_key"), ahVar.a("firebase_database_url"), ahVar.a("ga_trackingId"), ahVar.a("gcm_defaultSenderId"), ahVar.a("google_storage_bucket"), ahVar.a("project_id"));
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return aa.a(this.f2644a, bVar.f2644a) && aa.a(this.c, bVar.c) && aa.a(this.d, bVar.d) && aa.a(this.e, bVar.e) && aa.a(this.b, bVar.b) && aa.a(this.f, bVar.f) && aa.a(this.g, bVar.g);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f2644a, this.c, this.d, this.e, this.b, this.f, this.g});
    }

    public final String toString() {
        return aa.a(this).a("applicationId", this.f2644a).a("apiKey", this.c).a("databaseUrl", this.d).a("gcmSenderId", this.b).a("storageBucket", this.f).a("projectId", this.g).toString();
    }
}
