package com.google.firebase.a;

public final class a<T> {

    /* renamed from: a  reason: collision with root package name */
    public final Class<T> f2638a;
    private final T b;

    public final String toString() {
        return String.format("Event{type: %s, payload: %s}", new Object[]{this.f2638a, this.b});
    }
}
