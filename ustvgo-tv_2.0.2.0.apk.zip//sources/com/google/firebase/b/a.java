package com.google.firebase.b;

public interface a<T> {
    T a();
}
