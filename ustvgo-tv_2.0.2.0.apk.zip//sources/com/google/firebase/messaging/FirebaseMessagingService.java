package com.google.firebase.messaging;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.measurement.AppMeasurement;
import com.google.firebase.analytics.connector.a;
import com.google.firebase.iid.q;
import com.google.firebase.iid.zzb;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Queue;

public class FirebaseMessagingService extends zzb {
    private static final Queue<String> b = new ArrayDeque(10);

    static void a(Bundle bundle) {
        Iterator it = bundle.keySet().iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            if (str != null && str.startsWith("google.c.")) {
                it.remove();
            }
        }
    }

    static boolean b(Bundle bundle) {
        if (bundle == null) {
            return false;
        }
        return "1".equals(bundle.getString("google.c.a.e"));
    }

    public final Intent a(Intent intent) {
        return q.a().b.poll();
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0046  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0056  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ca  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(android.content.Intent r9) {
        /*
            r8 = this;
            java.lang.String r0 = r9.getAction()
            if (r0 != 0) goto L_0x0008
            java.lang.String r0 = ""
        L_0x0008:
            int r1 = r0.hashCode()
            r2 = 75300319(0x47cfddf, float:2.973903E-36)
            r3 = -1
            r4 = 1
            r5 = 0
            if (r1 == r2) goto L_0x0024
            r2 = 366519424(0x15d8a480, float:8.750124E-26)
            if (r1 == r2) goto L_0x001a
            goto L_0x002e
        L_0x001a:
            java.lang.String r1 = "com.google.android.c2dm.intent.RECEIVE"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x002e
            r0 = 0
            goto L_0x002f
        L_0x0024:
            java.lang.String r1 = "com.google.firebase.messaging.NOTIFICATION_DISMISS"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x002e
            r0 = 1
            goto L_0x002f
        L_0x002e:
            r0 = -1
        L_0x002f:
            switch(r0) {
                case 0: goto L_0x0056;
                case 1: goto L_0x0046;
                default: goto L_0x0032;
            }
        L_0x0032:
            java.lang.String r0 = "Unknown intent action: "
            java.lang.String r9 = r9.getAction()
            java.lang.String r9 = java.lang.String.valueOf(r9)
            int r1 = r9.length()
            if (r1 == 0) goto L_0x01d4
            r0.concat(r9)
            return
        L_0x0046:
            android.os.Bundle r0 = r9.getExtras()
            boolean r0 = b((android.os.Bundle) r0)
            if (r0 == 0) goto L_0x01d9
            java.lang.String r0 = "_nd"
            com.google.firebase.messaging.e.a(r0, r9)
            return
        L_0x0056:
            java.lang.String r0 = "google.message_id"
            java.lang.String r0 = r9.getStringExtra(r0)
            boolean r1 = android.text.TextUtils.isEmpty(r0)
            if (r1 == 0) goto L_0x0068
            r1 = 0
            com.google.android.gms.c.g r1 = com.google.android.gms.c.j.a(r1)
            goto L_0x0083
        L_0x0068:
            android.os.Bundle r1 = new android.os.Bundle
            r1.<init>()
            java.lang.String r2 = "google.message_id"
            r1.putString(r2, r0)
            com.google.firebase.iid.ao r2 = com.google.firebase.iid.ao.a((android.content.Context) r8)
            com.google.firebase.iid.e r6 = new com.google.firebase.iid.e
            int r7 = r2.a()
            r6.<init>(r7, r1)
            com.google.android.gms.c.g r1 = r2.a(r6)
        L_0x0083:
            boolean r2 = android.text.TextUtils.isEmpty(r0)
            r6 = 3
            if (r2 == 0) goto L_0x008c
        L_0x008a:
            r0 = 0
            goto L_0x00c8
        L_0x008c:
            java.util.Queue<java.lang.String> r2 = b
            boolean r2 = r2.contains(r0)
            if (r2 == 0) goto L_0x00b3
            java.lang.String r2 = "FirebaseMessaging"
            boolean r2 = android.util.Log.isLoggable(r2, r6)
            if (r2 == 0) goto L_0x00b1
            java.lang.String r2 = "Received duplicate message: "
            java.lang.String r0 = java.lang.String.valueOf(r0)
            int r7 = r0.length()
            if (r7 == 0) goto L_0x00ac
            r2.concat(r0)
            goto L_0x00b1
        L_0x00ac:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
        L_0x00b1:
            r0 = 1
            goto L_0x00c8
        L_0x00b3:
            java.util.Queue<java.lang.String> r2 = b
            int r2 = r2.size()
            r7 = 10
            if (r2 < r7) goto L_0x00c2
            java.util.Queue<java.lang.String> r2 = b
            r2.remove()
        L_0x00c2:
            java.util.Queue<java.lang.String> r2 = b
            r2.add(r0)
            goto L_0x008a
        L_0x00c8:
            if (r0 != 0) goto L_0x01a6
            java.lang.String r0 = "message_type"
            java.lang.String r0 = r9.getStringExtra(r0)
            if (r0 != 0) goto L_0x00d4
            java.lang.String r0 = "gcm"
        L_0x00d4:
            int r2 = r0.hashCode()
            r7 = -2062414158(0xffffffff85120eb2, float:-6.867586E-36)
            if (r2 == r7) goto L_0x010b
            r7 = 102161(0x18f11, float:1.43158E-40)
            if (r2 == r7) goto L_0x0101
            r7 = 814694033(0x308f3e91, float:1.0422402E-9)
            if (r2 == r7) goto L_0x00f7
            r6 = 814800675(0x3090df23, float:1.0540798E-9)
            if (r2 == r6) goto L_0x00ed
            goto L_0x0114
        L_0x00ed:
            java.lang.String r2 = "send_event"
            boolean r2 = r0.equals(r2)
            if (r2 == 0) goto L_0x0114
            r3 = 2
            goto L_0x0114
        L_0x00f7:
            java.lang.String r2 = "send_error"
            boolean r2 = r0.equals(r2)
            if (r2 == 0) goto L_0x0114
            r3 = 3
            goto L_0x0114
        L_0x0101:
            java.lang.String r2 = "gcm"
            boolean r2 = r0.equals(r2)
            if (r2 == 0) goto L_0x0114
            r3 = 0
            goto L_0x0114
        L_0x010b:
            java.lang.String r2 = "deleted_messages"
            boolean r2 = r0.equals(r2)
            if (r2 == 0) goto L_0x0114
            r3 = 1
        L_0x0114:
            switch(r3) {
                case 0: goto L_0x014a;
                case 1: goto L_0x01a6;
                case 2: goto L_0x0144;
                case 3: goto L_0x012b;
                default: goto L_0x0117;
            }
        L_0x0117:
            java.lang.String r9 = "FirebaseMessaging"
            java.lang.String r2 = "Received message with unknown type: "
            java.lang.String r0 = java.lang.String.valueOf(r0)
            int r3 = r0.length()
            if (r3 == 0) goto L_0x019e
            java.lang.String r0 = r2.concat(r0)
            goto L_0x01a3
        L_0x012b:
            java.lang.String r0 = "google.message_id"
            java.lang.String r0 = r9.getStringExtra(r0)
            if (r0 != 0) goto L_0x0138
            java.lang.String r0 = "message_id"
            r9.getStringExtra(r0)
        L_0x0138:
            com.google.firebase.messaging.c r0 = new com.google.firebase.messaging.c
            java.lang.String r2 = "error"
            java.lang.String r9 = r9.getStringExtra(r2)
            r0.<init>(r9)
            goto L_0x01a6
        L_0x0144:
            java.lang.String r0 = "google.message_id"
            r9.getStringExtra(r0)
            goto L_0x01a6
        L_0x014a:
            android.os.Bundle r0 = r9.getExtras()
            boolean r0 = b((android.os.Bundle) r0)
            if (r0 == 0) goto L_0x0159
            java.lang.String r0 = "_nr"
            com.google.firebase.messaging.e.a(r0, r9)
        L_0x0159:
            android.os.Bundle r0 = r9.getExtras()
            if (r0 != 0) goto L_0x0164
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
        L_0x0164:
            java.lang.String r2 = "android.support.content.wakelockid"
            r0.remove(r2)
            java.lang.String r2 = "1"
            java.lang.String r3 = "gcm.n.e"
            java.lang.String r3 = com.google.firebase.messaging.d.a((android.os.Bundle) r0, (java.lang.String) r3)
            boolean r2 = r2.equals(r3)
            if (r2 != 0) goto L_0x0181
            java.lang.String r2 = "gcm.n.icon"
            java.lang.String r2 = com.google.firebase.messaging.d.a((android.os.Bundle) r0, (java.lang.String) r2)
            if (r2 == 0) goto L_0x0180
            goto L_0x0181
        L_0x0180:
            r4 = 0
        L_0x0181:
            if (r4 == 0) goto L_0x0198
            com.google.firebase.messaging.d r2 = com.google.firebase.messaging.d.a((android.content.Context) r8)
            boolean r2 = r2.a((android.os.Bundle) r0)
            if (r2 != 0) goto L_0x01a6
            boolean r2 = b((android.os.Bundle) r0)
            if (r2 == 0) goto L_0x0198
            java.lang.String r2 = "_nf"
            com.google.firebase.messaging.e.a(r2, r9)
        L_0x0198:
            com.google.firebase.messaging.RemoteMessage r9 = new com.google.firebase.messaging.RemoteMessage
            r9.<init>(r0)
            goto L_0x01a6
        L_0x019e:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
        L_0x01a3:
            android.util.Log.w(r9, r0)
        L_0x01a6:
            r2 = 1
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ InterruptedException | ExecutionException | TimeoutException -> 0x01ae }
            com.google.android.gms.c.j.a(r1, r2, r9)     // Catch:{ InterruptedException | ExecutionException | TimeoutException -> 0x01ae }
            return
        L_0x01ae:
            r9 = move-exception
            java.lang.String r0 = "FirebaseMessaging"
            java.lang.String r9 = java.lang.String.valueOf(r9)
            java.lang.String r1 = java.lang.String.valueOf(r9)
            int r1 = r1.length()
            int r1 = r1 + 20
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r1)
            java.lang.String r1 = "Message ack failed: "
            r2.append(r1)
            r2.append(r9)
            java.lang.String r9 = r2.toString()
            android.util.Log.w(r0, r9)
            return
        L_0x01d4:
            java.lang.String r9 = new java.lang.String
            r9.<init>(r0)
        L_0x01d9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.messaging.FirebaseMessagingService.b(android.content.Intent):void");
    }

    public final boolean c(Intent intent) {
        if (!"com.google.firebase.messaging.NOTIFICATION_OPEN".equals(intent.getAction())) {
            return false;
        }
        PendingIntent pendingIntent = (PendingIntent) intent.getParcelableExtra("pending_intent");
        if (pendingIntent != null) {
            try {
                pendingIntent.send();
            } catch (PendingIntent.CanceledException unused) {
                Log.e("FirebaseMessaging", "Notification pending intent canceled");
            }
        }
        if (!b(intent.getExtras())) {
            return true;
        }
        if (intent != null) {
            if ("1".equals(intent.getStringExtra("google.c.a.tc"))) {
                a aVar = (a) com.google.firebase.a.c().a(a.class);
                Log.isLoggable("FirebaseMessaging", 3);
                if (aVar != null) {
                    String stringExtra = intent.getStringExtra("google.c.a.c_id");
                    aVar.a(AppMeasurement.FCM_ORIGIN, "_ln", (Object) stringExtra);
                    Bundle bundle = new Bundle();
                    bundle.putString("source", "Firebase");
                    bundle.putString("medium", "notification");
                    bundle.putString("campaign", stringExtra);
                    aVar.a(AppMeasurement.FCM_ORIGIN, "_cmp", bundle);
                } else {
                    Log.w("FirebaseMessaging", "Unable to set user property for conversion tracking:  analytics library is missing");
                }
            } else {
                Log.isLoggable("FirebaseMessaging", 3);
            }
        }
        e.a("_no", intent);
        return true;
    }
}
