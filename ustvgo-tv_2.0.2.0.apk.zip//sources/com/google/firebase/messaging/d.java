package com.google.firebase.messaging;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.content.a;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.util.o;
import com.google.firebase.messaging.b;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.MissingFormatArgumentException;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import org.json.JSONException;

final class d {

    /* renamed from: a  reason: collision with root package name */
    private static d f2704a;
    private final Context b;
    private Bundle c;
    private Method d;
    private Method e;
    private final AtomicInteger f = new AtomicInteger((int) SystemClock.elapsedRealtime());

    private d(Context context) {
        this.b = context.getApplicationContext();
    }

    @TargetApi(26)
    private final Notification a(CharSequence charSequence, String str, int i, Integer num, Uri uri, PendingIntent pendingIntent, PendingIntent pendingIntent2, String str2) {
        Notification.Builder smallIcon = new Notification.Builder(this.b).setAutoCancel(true).setSmallIcon(i);
        if (!TextUtils.isEmpty(charSequence)) {
            smallIcon.setContentTitle(charSequence);
        }
        if (!TextUtils.isEmpty(str)) {
            smallIcon.setContentText(str);
            smallIcon.setStyle(new Notification.BigTextStyle().bigText(str));
        }
        if (num != null) {
            smallIcon.setColor(num.intValue());
        }
        if (uri != null) {
            smallIcon.setSound(uri);
        }
        if (pendingIntent != null) {
            smallIcon.setContentIntent(pendingIntent);
        }
        if (pendingIntent2 != null) {
            smallIcon.setDeleteIntent(pendingIntent2);
        }
        if (str2 != null) {
            if (this.d == null) {
                this.d = a("setChannelId");
            }
            if (this.d == null) {
                this.d = a("setChannel");
            }
            if (this.d == null) {
                Log.e("FirebaseMessaging", "Error while setting the notification channel");
            } else {
                try {
                    this.d.invoke(smallIcon, new Object[]{str2});
                } catch (IllegalAccessException | IllegalArgumentException | SecurityException | InvocationTargetException e2) {
                    Log.e("FirebaseMessaging", "Error while setting the notification channel", e2);
                }
            }
        }
        return smallIcon.build();
    }

    private final Bundle a() {
        if (this.c != null) {
            return this.c;
        }
        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = this.b.getPackageManager().getApplicationInfo(this.b.getPackageName(), 128);
        } catch (PackageManager.NameNotFoundException unused) {
        }
        if (applicationInfo == null || applicationInfo.metaData == null) {
            return Bundle.EMPTY;
        }
        this.c = applicationInfo.metaData;
        return this.c;
    }

    static synchronized d a(Context context) {
        d dVar;
        synchronized (d.class) {
            if (f2704a == null) {
                f2704a = new d(context);
            }
            dVar = f2704a;
        }
        return dVar;
    }

    static String a(Bundle bundle, String str) {
        String string = bundle.getString(str);
        return string == null ? bundle.getString(str.replace("gcm.n.", "gcm.notification.")) : string;
    }

    @TargetApi(26)
    private static Method a(String str) {
        try {
            return Notification.Builder.class.getMethod(str, new Class[]{String.class});
        } catch (NoSuchMethodException | SecurityException unused) {
            return null;
        }
    }

    private static void a(Intent intent, Bundle bundle) {
        for (String str : bundle.keySet()) {
            if (str.startsWith("google.c.a.") || str.equals("from")) {
                intent.putExtra(str, bundle.getString(str));
            }
        }
    }

    @TargetApi(26)
    private final boolean a(int i) {
        if (Build.VERSION.SDK_INT != 26) {
            return true;
        }
        try {
            if (!(this.b.getResources().getDrawable(i, (Resources.Theme) null) instanceof AdaptiveIconDrawable)) {
                return true;
            }
            StringBuilder sb = new StringBuilder(77);
            sb.append("Adaptive icons cannot be used in notifications. Ignoring icon id: ");
            sb.append(i);
            Log.e("FirebaseMessaging", sb.toString());
            return false;
        } catch (Resources.NotFoundException unused) {
            return false;
        }
    }

    private final Integer b(String str) {
        if (Build.VERSION.SDK_INT < 21) {
            return null;
        }
        if (!TextUtils.isEmpty(str)) {
            try {
                return Integer.valueOf(Color.parseColor(str));
            } catch (IllegalArgumentException unused) {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 54);
                sb.append("Color ");
                sb.append(str);
                sb.append(" not valid. Notification will use default color.");
                Log.w("FirebaseMessaging", sb.toString());
            }
        }
        int i = a().getInt("com.google.firebase.messaging.default_notification_color", 0);
        if (i != 0) {
            try {
                return Integer.valueOf(a.getColor(this.b, i));
            } catch (Resources.NotFoundException unused2) {
                Log.w("FirebaseMessaging", "Cannot find the color resource referenced in AndroidManifest.");
            }
        }
        return null;
    }

    private static Object[] b(Bundle bundle, String str) {
        String valueOf = String.valueOf(str);
        String valueOf2 = String.valueOf("_loc_args");
        String a2 = a(bundle, valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
        if (TextUtils.isEmpty(a2)) {
            return null;
        }
        try {
            JSONArray jSONArray = new JSONArray(a2);
            Object[] objArr = new String[jSONArray.length()];
            for (int i = 0; i < objArr.length; i++) {
                objArr[i] = jSONArray.opt(i);
            }
            return objArr;
        } catch (JSONException unused) {
            String valueOf3 = String.valueOf(str);
            String valueOf4 = String.valueOf("_loc_args");
            String substring = (valueOf4.length() != 0 ? valueOf3.concat(valueOf4) : new String(valueOf3)).substring(6);
            StringBuilder sb = new StringBuilder(String.valueOf(substring).length() + 41 + String.valueOf(a2).length());
            sb.append("Malformed ");
            sb.append(substring);
            sb.append(": ");
            sb.append(a2);
            sb.append("  Default value will be used.");
            Log.w("FirebaseMessaging", sb.toString());
            return null;
        }
    }

    private final String c(Bundle bundle, String str) {
        String a2 = a(bundle, str);
        if (!TextUtils.isEmpty(a2)) {
            return a2;
        }
        String valueOf = String.valueOf(str);
        String valueOf2 = String.valueOf("_loc_key");
        String a3 = a(bundle, valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
        if (TextUtils.isEmpty(a3)) {
            return null;
        }
        Resources resources = this.b.getResources();
        int identifier = resources.getIdentifier(a3, "string", this.b.getPackageName());
        if (identifier == 0) {
            String valueOf3 = String.valueOf(str);
            String valueOf4 = String.valueOf("_loc_key");
            String substring = (valueOf4.length() != 0 ? valueOf3.concat(valueOf4) : new String(valueOf3)).substring(6);
            StringBuilder sb = new StringBuilder(String.valueOf(substring).length() + 49 + String.valueOf(a3).length());
            sb.append(substring);
            sb.append(" resource not found: ");
            sb.append(a3);
            sb.append(" Default value will be used.");
            Log.w("FirebaseMessaging", sb.toString());
            return null;
        }
        Object[] b2 = b(bundle, str);
        if (b2 == null) {
            return resources.getString(identifier);
        }
        try {
            return resources.getString(identifier, b2);
        } catch (MissingFormatArgumentException e2) {
            String arrays = Arrays.toString(b2);
            StringBuilder sb2 = new StringBuilder(String.valueOf(a3).length() + 58 + String.valueOf(arrays).length());
            sb2.append("Missing format argument for ");
            sb2.append(a3);
            sb2.append(": ");
            sb2.append(arrays);
            sb2.append(" Default value will be used.");
            Log.w("FirebaseMessaging", sb2.toString(), e2);
            return null;
        }
    }

    @TargetApi(26)
    private final String c(String str) {
        String str2;
        String str3;
        if (!o.i()) {
            return null;
        }
        NotificationManager notificationManager = (NotificationManager) this.b.getSystemService(NotificationManager.class);
        try {
            if (this.e == null) {
                this.e = notificationManager.getClass().getMethod("getNotificationChannel", new Class[]{String.class});
            }
            if (!TextUtils.isEmpty(str)) {
                if (this.e.invoke(notificationManager, new Object[]{str}) != null) {
                    return str;
                }
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 122);
                sb.append("Notification Channel requested (");
                sb.append(str);
                sb.append(") has not been created by the app. Manifest configuration, or default, value will be used.");
                Log.w("FirebaseMessaging", sb.toString());
            }
            String string = a().getString("com.google.firebase.messaging.default_notification_channel_id");
            if (!TextUtils.isEmpty(string)) {
                if (this.e.invoke(notificationManager, new Object[]{string}) != null) {
                    return string;
                }
                str2 = "FirebaseMessaging";
                str3 = "Notification Channel set in AndroidManifest.xml has not been created by the app. Default value will be used.";
            } else {
                str2 = "FirebaseMessaging";
                str3 = "Missing Default Notification Channel metadata in AndroidManifest. Default value will be used.";
            }
            Log.w(str2, str3);
            if (this.e.invoke(notificationManager, new Object[]{"fcm_fallback_notification_channel"}) != null) {
                return "fcm_fallback_notification_channel";
            }
            Class<?> cls = Class.forName("android.app.NotificationChannel");
            Object newInstance = cls.getConstructor(new Class[]{String.class, CharSequence.class, Integer.TYPE}).newInstance(new Object[]{"fcm_fallback_notification_channel", this.b.getString(b.a.fcm_fallback_notification_channel_label), 3});
            notificationManager.getClass().getMethod("createNotificationChannel", new Class[]{cls}).invoke(notificationManager, new Object[]{newInstance});
            return "fcm_fallback_notification_channel";
        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | InstantiationException | LinkageError | NoSuchMethodException | SecurityException | InvocationTargetException e2) {
            Log.e("FirebaseMessaging", "Error while setting the notification channel", e2);
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0300  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0121  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0130  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0194  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x01a8  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01f7  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x01f9  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0245  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x028a  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x029b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(android.os.Bundle r13) {
        /*
            r12 = this;
            java.lang.String r0 = "1"
            java.lang.String r1 = "gcm.n.noui"
            java.lang.String r1 = a((android.os.Bundle) r13, (java.lang.String) r1)
            boolean r0 = r0.equals(r1)
            r1 = 1
            if (r0 == 0) goto L_0x0010
            return r1
        L_0x0010:
            android.content.Context r0 = r12.b
            java.lang.String r2 = "keyguard"
            java.lang.Object r0 = r0.getSystemService(r2)
            android.app.KeyguardManager r0 = (android.app.KeyguardManager) r0
            boolean r0 = r0.inKeyguardRestrictedInputMode()
            r2 = 0
            if (r0 != 0) goto L_0x005c
            boolean r0 = com.google.android.gms.common.util.o.g()
            if (r0 != 0) goto L_0x002c
            r3 = 10
            android.os.SystemClock.sleep(r3)
        L_0x002c:
            int r0 = android.os.Process.myPid()
            android.content.Context r3 = r12.b
            java.lang.String r4 = "activity"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.app.ActivityManager r3 = (android.app.ActivityManager) r3
            java.util.List r3 = r3.getRunningAppProcesses()
            if (r3 == 0) goto L_0x005c
            java.util.Iterator r3 = r3.iterator()
        L_0x0044:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x005c
            java.lang.Object r4 = r3.next()
            android.app.ActivityManager$RunningAppProcessInfo r4 = (android.app.ActivityManager.RunningAppProcessInfo) r4
            int r5 = r4.pid
            if (r5 != r0) goto L_0x0044
            int r0 = r4.importance
            r3 = 100
            if (r0 != r3) goto L_0x005c
            r0 = 1
            goto L_0x005d
        L_0x005c:
            r0 = 0
        L_0x005d:
            if (r0 == 0) goto L_0x0060
            return r2
        L_0x0060:
            java.lang.String r0 = "gcm.n.title"
            java.lang.String r0 = r12.c(r13, r0)
            boolean r3 = android.text.TextUtils.isEmpty(r0)
            if (r3 == 0) goto L_0x007c
            android.content.Context r0 = r12.b
            android.content.pm.ApplicationInfo r0 = r0.getApplicationInfo()
            android.content.Context r3 = r12.b
            android.content.pm.PackageManager r3 = r3.getPackageManager()
            java.lang.CharSequence r0 = r0.loadLabel(r3)
        L_0x007c:
            r4 = r0
            java.lang.String r0 = "gcm.n.body"
            java.lang.String r5 = r12.c(r13, r0)
            java.lang.String r0 = "gcm.n.icon"
            java.lang.String r0 = a((android.os.Bundle) r13, (java.lang.String) r0)
            boolean r3 = android.text.TextUtils.isEmpty(r0)
            if (r3 != 0) goto L_0x00e5
            android.content.Context r3 = r12.b
            android.content.res.Resources r3 = r3.getResources()
            java.lang.String r6 = "drawable"
            android.content.Context r7 = r12.b
            java.lang.String r7 = r7.getPackageName()
            int r6 = r3.getIdentifier(r0, r6, r7)
            if (r6 == 0) goto L_0x00aa
            boolean r7 = r12.a((int) r6)
            if (r7 == 0) goto L_0x00aa
            goto L_0x010b
        L_0x00aa:
            java.lang.String r6 = "mipmap"
            android.content.Context r7 = r12.b
            java.lang.String r7 = r7.getPackageName()
            int r3 = r3.getIdentifier(r0, r6, r7)
            if (r3 == 0) goto L_0x00c0
            boolean r6 = r12.a((int) r3)
            if (r6 == 0) goto L_0x00c0
            r6 = r3
            goto L_0x010b
        L_0x00c0:
            java.lang.String r3 = "FirebaseMessaging"
            java.lang.String r6 = java.lang.String.valueOf(r0)
            int r6 = r6.length()
            int r6 = r6 + 61
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>(r6)
            java.lang.String r6 = "Icon resource "
            r7.append(r6)
            r7.append(r0)
            java.lang.String r0 = " not found. Notification will use default icon."
            r7.append(r0)
            java.lang.String r0 = r7.toString()
            android.util.Log.w(r3, r0)
        L_0x00e5:
            android.os.Bundle r0 = r12.a()
            java.lang.String r3 = "com.google.firebase.messaging.default_notification_icon"
            int r0 = r0.getInt(r3, r2)
            if (r0 == 0) goto L_0x00f7
            boolean r3 = r12.a((int) r0)
            if (r3 != 0) goto L_0x00ff
        L_0x00f7:
            android.content.Context r0 = r12.b
            android.content.pm.ApplicationInfo r0 = r0.getApplicationInfo()
            int r0 = r0.icon
        L_0x00ff:
            if (r0 == 0) goto L_0x0107
            boolean r3 = r12.a((int) r0)
            if (r3 != 0) goto L_0x010a
        L_0x0107:
            r0 = 17301651(0x1080093, float:2.4979667E-38)
        L_0x010a:
            r6 = r0
        L_0x010b:
            java.lang.String r0 = "gcm.n.color"
            java.lang.String r0 = a((android.os.Bundle) r13, (java.lang.String) r0)
            java.lang.Integer r7 = r12.b(r0)
            java.lang.String r0 = "gcm.n.sound2"
            java.lang.String r0 = a((android.os.Bundle) r13, (java.lang.String) r0)
            boolean r3 = android.text.TextUtils.isEmpty(r0)
            if (r3 == 0) goto L_0x0127
            java.lang.String r0 = "gcm.n.sound"
            java.lang.String r0 = a((android.os.Bundle) r13, (java.lang.String) r0)
        L_0x0127:
            boolean r3 = android.text.TextUtils.isEmpty(r0)
            r8 = 0
            if (r3 == 0) goto L_0x0130
            r0 = r8
            goto L_0x0188
        L_0x0130:
            java.lang.String r3 = "default"
            boolean r3 = r3.equals(r0)
            if (r3 != 0) goto L_0x0183
            android.content.Context r3 = r12.b
            android.content.res.Resources r3 = r3.getResources()
            java.lang.String r9 = "raw"
            android.content.Context r10 = r12.b
            java.lang.String r10 = r10.getPackageName()
            int r3 = r3.getIdentifier(r0, r9, r10)
            if (r3 == 0) goto L_0x0183
            android.content.Context r3 = r12.b
            java.lang.String r3 = r3.getPackageName()
            java.lang.String r9 = java.lang.String.valueOf(r3)
            int r9 = r9.length()
            int r9 = r9 + 24
            java.lang.String r10 = java.lang.String.valueOf(r0)
            int r10 = r10.length()
            int r9 = r9 + r10
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>(r9)
            java.lang.String r9 = "android.resource://"
            r10.append(r9)
            r10.append(r3)
            java.lang.String r3 = "/raw/"
            r10.append(r3)
            r10.append(r0)
            java.lang.String r0 = r10.toString()
            android.net.Uri r0 = android.net.Uri.parse(r0)
            goto L_0x0188
        L_0x0183:
            r0 = 2
            android.net.Uri r0 = android.media.RingtoneManager.getDefaultUri(r0)
        L_0x0188:
            java.lang.String r3 = "gcm.n.click_action"
            java.lang.String r3 = a((android.os.Bundle) r13, (java.lang.String) r3)
            boolean r9 = android.text.TextUtils.isEmpty(r3)
            if (r9 != 0) goto L_0x01a8
            android.content.Intent r9 = new android.content.Intent
            r9.<init>(r3)
            android.content.Context r3 = r12.b
            java.lang.String r3 = r3.getPackageName()
            r9.setPackage(r3)
            r3 = 268435456(0x10000000, float:2.5243549E-29)
            r9.setFlags(r3)
            goto L_0x01f5
        L_0x01a8:
            java.lang.String r3 = "gcm.n.link_android"
            java.lang.String r3 = a((android.os.Bundle) r13, (java.lang.String) r3)
            boolean r9 = android.text.TextUtils.isEmpty(r3)
            if (r9 == 0) goto L_0x01ba
            java.lang.String r3 = "gcm.n.link"
            java.lang.String r3 = a((android.os.Bundle) r13, (java.lang.String) r3)
        L_0x01ba:
            boolean r9 = android.text.TextUtils.isEmpty(r3)
            if (r9 != 0) goto L_0x01c5
            android.net.Uri r3 = android.net.Uri.parse(r3)
            goto L_0x01c6
        L_0x01c5:
            r3 = r8
        L_0x01c6:
            if (r3 == 0) goto L_0x01dc
            android.content.Intent r9 = new android.content.Intent
            java.lang.String r10 = "android.intent.action.VIEW"
            r9.<init>(r10)
            android.content.Context r10 = r12.b
            java.lang.String r10 = r10.getPackageName()
            r9.setPackage(r10)
            r9.setData(r3)
            goto L_0x01f5
        L_0x01dc:
            android.content.Context r3 = r12.b
            android.content.pm.PackageManager r3 = r3.getPackageManager()
            android.content.Context r9 = r12.b
            java.lang.String r9 = r9.getPackageName()
            android.content.Intent r9 = r3.getLaunchIntentForPackage(r9)
            if (r9 != 0) goto L_0x01f5
            java.lang.String r3 = "FirebaseMessaging"
            java.lang.String r10 = "No activity found to launch app"
            android.util.Log.w(r3, r10)
        L_0x01f5:
            if (r9 != 0) goto L_0x01f9
            r3 = r8
            goto L_0x023f
        L_0x01f9:
            r3 = 67108864(0x4000000, float:1.5046328E-36)
            r9.addFlags(r3)
            android.os.Bundle r3 = new android.os.Bundle
            r3.<init>(r13)
            com.google.firebase.messaging.FirebaseMessagingService.a((android.os.Bundle) r3)
            r9.putExtras(r3)
            java.util.Set r3 = r3.keySet()
            java.util.Iterator r3 = r3.iterator()
        L_0x0211:
            boolean r10 = r3.hasNext()
            if (r10 == 0) goto L_0x0231
            java.lang.Object r10 = r3.next()
            java.lang.String r10 = (java.lang.String) r10
            java.lang.String r11 = "gcm.n."
            boolean r11 = r10.startsWith(r11)
            if (r11 != 0) goto L_0x022d
            java.lang.String r11 = "gcm.notification."
            boolean r11 = r10.startsWith(r11)
            if (r11 == 0) goto L_0x0211
        L_0x022d:
            r9.removeExtra(r10)
            goto L_0x0211
        L_0x0231:
            android.content.Context r3 = r12.b
            java.util.concurrent.atomic.AtomicInteger r10 = r12.f
            int r10 = r10.incrementAndGet()
            r11 = 1073741824(0x40000000, float:2.0)
            android.app.PendingIntent r3 = android.app.PendingIntent.getActivity(r3, r10, r9, r11)
        L_0x023f:
            boolean r9 = com.google.firebase.messaging.FirebaseMessagingService.b((android.os.Bundle) r13)
            if (r9 == 0) goto L_0x0276
            android.content.Intent r8 = new android.content.Intent
            java.lang.String r9 = "com.google.firebase.messaging.NOTIFICATION_OPEN"
            r8.<init>(r9)
            a((android.content.Intent) r8, (android.os.Bundle) r13)
            java.lang.String r9 = "pending_intent"
            r8.putExtra(r9, r3)
            android.content.Context r3 = r12.b
            java.util.concurrent.atomic.AtomicInteger r9 = r12.f
            int r9 = r9.incrementAndGet()
            android.app.PendingIntent r3 = com.google.firebase.iid.q.a((android.content.Context) r3, (int) r9, (android.content.Intent) r8)
            android.content.Intent r8 = new android.content.Intent
            java.lang.String r9 = "com.google.firebase.messaging.NOTIFICATION_DISMISS"
            r8.<init>(r9)
            a((android.content.Intent) r8, (android.os.Bundle) r13)
            android.content.Context r9 = r12.b
            java.util.concurrent.atomic.AtomicInteger r10 = r12.f
            int r10 = r10.incrementAndGet()
            android.app.PendingIntent r8 = com.google.firebase.iid.q.a((android.content.Context) r9, (int) r10, (android.content.Intent) r8)
        L_0x0276:
            r9 = r3
            r10 = r8
            boolean r3 = com.google.android.gms.common.util.o.i()
            if (r3 == 0) goto L_0x029b
            android.content.Context r3 = r12.b
            android.content.pm.ApplicationInfo r3 = r3.getApplicationInfo()
            int r3 = r3.targetSdkVersion
            r8 = 25
            if (r3 <= r8) goto L_0x029b
            java.lang.String r3 = "gcm.n.android_channel_id"
            java.lang.String r3 = a((android.os.Bundle) r13, (java.lang.String) r3)
            java.lang.String r11 = r12.c(r3)
            r3 = r12
            r8 = r0
            android.app.Notification r0 = r3.a(r4, r5, r6, r7, r8, r9, r10, r11)
            goto L_0x02e4
        L_0x029b:
            android.support.v4.app.NotificationCompat$Builder r3 = new android.support.v4.app.NotificationCompat$Builder
            android.content.Context r8 = r12.b
            r3.<init>(r8)
            android.support.v4.app.NotificationCompat$Builder r3 = r3.setAutoCancel(r1)
            android.support.v4.app.NotificationCompat$Builder r3 = r3.setSmallIcon(r6)
            boolean r6 = android.text.TextUtils.isEmpty(r4)
            if (r6 != 0) goto L_0x02b3
            r3.setContentTitle(r4)
        L_0x02b3:
            boolean r4 = android.text.TextUtils.isEmpty(r5)
            if (r4 != 0) goto L_0x02c8
            r3.setContentText(r5)
            android.support.v4.app.NotificationCompat$BigTextStyle r4 = new android.support.v4.app.NotificationCompat$BigTextStyle
            r4.<init>()
            android.support.v4.app.NotificationCompat$BigTextStyle r4 = r4.bigText(r5)
            r3.setStyle(r4)
        L_0x02c8:
            if (r7 == 0) goto L_0x02d1
            int r4 = r7.intValue()
            r3.setColor(r4)
        L_0x02d1:
            if (r0 == 0) goto L_0x02d6
            r3.setSound(r0)
        L_0x02d6:
            if (r9 == 0) goto L_0x02db
            r3.setContentIntent(r9)
        L_0x02db:
            if (r10 == 0) goto L_0x02e0
            r3.setDeleteIntent(r10)
        L_0x02e0:
            android.app.Notification r0 = r3.build()
        L_0x02e4:
            java.lang.String r3 = "gcm.n.tag"
            java.lang.String r13 = a((android.os.Bundle) r13, (java.lang.String) r3)
            java.lang.String r3 = "FirebaseMessaging"
            r4 = 3
            android.util.Log.isLoggable(r3, r4)
            android.content.Context r3 = r12.b
            java.lang.String r4 = "notification"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.app.NotificationManager r3 = (android.app.NotificationManager) r3
            boolean r4 = android.text.TextUtils.isEmpty(r13)
            if (r4 == 0) goto L_0x0317
            long r4 = android.os.SystemClock.uptimeMillis()
            r13 = 37
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>(r13)
            java.lang.String r13 = "FCM-Notification:"
            r6.append(r13)
            r6.append(r4)
            java.lang.String r13 = r6.toString()
        L_0x0317:
            r3.notify(r13, r2, r0)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.messaging.d.a(android.os.Bundle):boolean");
    }
}
