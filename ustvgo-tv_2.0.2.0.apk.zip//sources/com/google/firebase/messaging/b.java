package com.google.firebase.messaging;

public final class b {

    public static final class a {
        public static final int fcm_fallback_notification_channel_label = 2131624190;
    }
}
