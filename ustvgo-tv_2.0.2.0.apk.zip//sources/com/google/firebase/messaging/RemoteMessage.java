package com.google.firebase.messaging;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;

public final class RemoteMessage extends AbstractSafeParcelable {
    public static final Parcelable.Creator<RemoteMessage> CREATOR = new f();

    /* renamed from: a  reason: collision with root package name */
    Bundle f2701a;

    public RemoteMessage(Bundle bundle) {
        this.f2701a = bundle;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.a(parcel, 2, this.f2701a);
        b.b(parcel, a2);
    }
}
