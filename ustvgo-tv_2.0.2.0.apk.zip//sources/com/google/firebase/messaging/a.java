package com.google.firebase.messaging;

import java.util.regex.Pattern;

public class a {

    /* renamed from: a  reason: collision with root package name */
    private static final Pattern f2702a = Pattern.compile("[a-zA-Z0-9-_.~%]{1,900}");
}
