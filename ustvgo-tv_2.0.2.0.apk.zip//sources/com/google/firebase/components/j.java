package com.google.firebase.components;

final /* synthetic */ class j implements d {

    /* renamed from: a  reason: collision with root package name */
    private final Object f2650a;

    j(Object obj) {
        this.f2650a = obj;
    }

    public final Object a(b bVar) {
        return this.f2650a;
    }
}
