package com.google.firebase.components;

import com.google.firebase.b.a;

public interface b {
    <T> T a(Class<T> cls);

    <T> a<T> b(Class<T> cls);
}
