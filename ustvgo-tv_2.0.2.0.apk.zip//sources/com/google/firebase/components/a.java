package com.google.firebase.components;

import com.google.android.gms.common.internal.ab;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class a<T> {

    /* renamed from: a  reason: collision with root package name */
    final Set<Class<? super T>> f2646a;
    final Set<f> b;
    final d<T> c;
    final Set<Class<?>> d;
    private final int e;

    /* renamed from: com.google.firebase.components.a$a  reason: collision with other inner class name */
    public static class C0085a<T> {

        /* renamed from: a  reason: collision with root package name */
        public int f2647a;
        private final Set<Class<? super T>> b;
        private final Set<f> c;
        private d<T> d;
        private Set<Class<?>> e;

        private C0085a(Class<T> cls, Class<? super T>... clsArr) {
            this.b = new HashSet();
            this.c = new HashSet();
            this.f2647a = 0;
            this.e = new HashSet();
            ab.a(cls, (Object) "Null interface");
            this.b.add(cls);
            for (Class<? super T> a2 : clsArr) {
                ab.a(a2, (Object) "Null interface");
            }
            Collections.addAll(this.b, clsArr);
        }

        /* synthetic */ C0085a(Class cls, Class[] clsArr, byte b2) {
            this(cls, clsArr);
        }

        public final C0085a<T> a(d<T> dVar) {
            this.d = (d) ab.a(dVar, (Object) "Null factory");
            return this;
        }

        public final C0085a<T> a(f fVar) {
            ab.a(fVar, (Object) "Null dependency");
            ab.b(!this.b.contains(fVar.f2648a), "Components are not allowed to depend on interfaces they themselves provide.");
            this.c.add(fVar);
            return this;
        }

        public final a<T> a() {
            ab.a(this.d != null, (Object) "Missing required property: factory.");
            return new a(new HashSet(this.b), new HashSet(this.c), this.f2647a, this.d, this.e, (byte) 0);
        }
    }

    private a(Set<Class<? super T>> set, Set<f> set2, int i, d<T> dVar, Set<Class<?>> set3) {
        this.f2646a = Collections.unmodifiableSet(set);
        this.b = Collections.unmodifiableSet(set2);
        this.e = i;
        this.c = dVar;
        this.d = Collections.unmodifiableSet(set3);
    }

    /* synthetic */ a(Set set, Set set2, int i, d dVar, Set set3, byte b2) {
        this(set, set2, i, dVar, set3);
    }

    public static <T> C0085a<T> a(Class<T> cls) {
        return new C0085a<>(cls, new Class[0], (byte) 0);
    }

    private static <T> C0085a<T> a(Class<T> cls, Class<? super T>... clsArr) {
        return new C0085a<>(cls, clsArr, (byte) 0);
    }

    @SafeVarargs
    public static <T> a<T> a(T t, Class<T> cls, Class<? super T>... clsArr) {
        return a(cls, clsArr).a(new j(t)).a();
    }

    public final boolean a() {
        return this.e == 1;
    }

    public final boolean b() {
        return this.e == 2;
    }

    public final String toString() {
        return "Component<" + Arrays.toString(this.f2646a.toArray()) + ">{" + this.e + ", deps=" + Arrays.toString(this.b.toArray()) + "}";
    }
}
