package com.google.firebase.components;

public class h extends RuntimeException {
    public h(String str) {
        super(str);
    }
}
