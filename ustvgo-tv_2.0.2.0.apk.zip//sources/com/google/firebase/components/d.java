package com.google.firebase.components;

public interface d<T> {
    T a(b bVar);
}
