package com.google.firebase.components;

import java.util.List;

public interface e {
    List<a<?>> getComponents();
}
