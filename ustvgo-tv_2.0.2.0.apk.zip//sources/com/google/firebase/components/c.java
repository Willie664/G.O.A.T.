package com.google.firebase.components;

import com.google.firebase.b.a;

public abstract /* synthetic */ class c {
    public static Object a(b bVar, Class cls) {
        a b = bVar.b(cls);
        if (b == null) {
            return null;
        }
        return b.a();
    }
}
