package com.google.firebase.components;

import com.google.firebase.a.a;
import java.util.Map;

final /* synthetic */ class o implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final Map.Entry f2655a;
    private final a b;

    o(Map.Entry entry, a aVar) {
        this.f2655a = entry;
        this.b = aVar;
    }

    public final void run() {
        this.f2655a.getKey();
    }
}
