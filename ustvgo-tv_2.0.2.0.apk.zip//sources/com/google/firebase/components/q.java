package com.google.firebase.components;

import com.google.firebase.b.a;

final /* synthetic */ class q implements a {

    /* renamed from: a  reason: collision with root package name */
    private final d f2657a;
    private final b b;

    q(d dVar, b bVar) {
        this.f2657a = dVar;
        this.b = bVar;
    }

    public final Object a() {
        return this.f2657a.a(this.b);
    }
}
