package com.google.firebase.components;

import com.google.firebase.b.a;

final class p<T> implements a<T> {

    /* renamed from: a  reason: collision with root package name */
    private static final Object f2656a = new Object();
    private volatile Object b = f2656a;
    private volatile a<T> c;

    p(d<T> dVar, b bVar) {
        this.c = new q(dVar, bVar);
    }

    public final T a() {
        T t = this.b;
        if (t == f2656a) {
            synchronized (this) {
                t = this.b;
                if (t == f2656a) {
                    t = this.c.a();
                    this.b = t;
                    this.c = null;
                }
            }
        }
        return t;
    }
}
