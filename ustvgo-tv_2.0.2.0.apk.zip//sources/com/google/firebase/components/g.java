package com.google.firebase.components;

import java.util.Arrays;
import java.util.List;

public final class g extends h {

    /* renamed from: a  reason: collision with root package name */
    private final List<a<?>> f2649a;

    public g(List<a<?>> list) {
        super("Dependency cycle detected: " + Arrays.toString(list.toArray()));
        this.f2649a = list;
    }
}
