package com.google.firebase.components;

public final class i extends h {
    public i(String str) {
        super(str);
    }
}
