package com.google.firebase.components;

import com.google.android.gms.common.internal.ab;
import com.google.firebase.a.b;
import com.google.firebase.a.c;
import com.google.firebase.b.a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

public final class l implements b {

    /* renamed from: a  reason: collision with root package name */
    private final List<a<?>> f2652a;
    private final Map<Class<?>, p<?>> b = new HashMap();
    private final n c;

    public l(Executor executor, Iterable<e> iterable, a<?>... aVarArr) {
        this.c = new n(executor);
        ArrayList arrayList = new ArrayList();
        arrayList.add(a.a(this.c, n.class, c.class, b.class));
        for (e components : iterable) {
            arrayList.addAll(components.getComponents());
        }
        Collections.addAll(arrayList, aVarArr);
        this.f2652a = Collections.unmodifiableList(m.a((List<a<?>>) arrayList));
        for (a<?> a2 : this.f2652a) {
            a(a2);
        }
        a();
    }

    private void a() {
        for (a next : this.f2652a) {
            Iterator<f> it = next.b.iterator();
            while (true) {
                if (it.hasNext()) {
                    f next2 = it.next();
                    if ((next2.b == 1) && !this.b.containsKey(next2.f2648a)) {
                        throw new i(String.format("Unsatisfied dependency for component %s: %s", new Object[]{next, next2.f2648a}));
                    }
                }
            }
        }
    }

    private <T> void a(a<T> aVar) {
        p pVar = new p(aVar.c, new r(aVar, this));
        for (Class<? super T> put : aVar.f2646a) {
            this.b.put(put, pVar);
        }
    }

    public final Object a(Class cls) {
        return c.a(this, cls);
    }

    public final void a(boolean z) {
        for (a next : this.f2652a) {
            if (next.a() || (next.b() && z)) {
                c.a(this, next.f2646a.iterator().next());
            }
        }
        this.c.a();
    }

    public final <T> a<T> b(Class<T> cls) {
        ab.a(cls, (Object) "Null interface requested.");
        return this.b.get(cls);
    }
}
