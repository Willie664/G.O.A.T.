package com.google.firebase.components;

import com.google.android.gms.common.internal.ab;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    final Class<?> f2648a;
    final int b = 1;
    private final int c = 0;

    private f(Class<?> cls) {
        this.f2648a = (Class) ab.a(cls, (Object) "Null dependency anInterface.");
    }

    public static f a(Class<?> cls) {
        return new f(cls);
    }

    public final boolean a() {
        return this.c == 0;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof f) {
            f fVar = (f) obj;
            return this.f2648a == fVar.f2648a && this.b == fVar.b && this.c == fVar.c;
        }
    }

    public final int hashCode() {
        return ((((this.f2648a.hashCode() ^ 1000003) * 1000003) ^ this.b) * 1000003) ^ this.c;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Dependency{anInterface=");
        sb.append(this.f2648a);
        sb.append(", required=");
        boolean z = false;
        sb.append(this.b == 1);
        sb.append(", direct=");
        if (this.c == 0) {
            z = true;
        }
        sb.append(z);
        sb.append("}");
        return sb.toString();
    }
}
