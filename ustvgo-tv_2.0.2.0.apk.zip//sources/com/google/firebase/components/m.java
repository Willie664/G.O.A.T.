package com.google.firebase.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

final class m {

    static class a {

        /* renamed from: a  reason: collision with root package name */
        final a<?> f2653a;
        final Set<a> b = new HashSet();
        final Set<a> c = new HashSet();

        a(a<?> aVar) {
            this.f2653a = aVar;
        }

        /* access modifiers changed from: package-private */
        public final boolean a() {
            return this.c.isEmpty();
        }
    }

    static List<a<?>> a(List<a<?>> list) {
        a aVar;
        HashMap hashMap = new HashMap(list.size());
        for (a next : list) {
            a aVar2 = new a(next);
            Iterator<Class<? super T>> it = next.f2646a.iterator();
            while (true) {
                if (it.hasNext()) {
                    Class next2 = it.next();
                    if (hashMap.put(next2, aVar2) != null) {
                        throw new IllegalArgumentException(String.format("Multiple components provide %s.", new Object[]{next2}));
                    }
                }
            }
        }
        for (a aVar3 : hashMap.values()) {
            for (f next3 : aVar3.f2653a.b) {
                if (next3.a() && (aVar = (a) hashMap.get(next3.f2648a)) != null) {
                    aVar3.b.add(aVar);
                    aVar.c.add(aVar3);
                }
            }
        }
        HashSet<a> hashSet = new HashSet<>(hashMap.values());
        Set<a> a2 = a((Set<a>) hashSet);
        ArrayList arrayList = new ArrayList();
        while (!a2.isEmpty()) {
            a next4 = a2.iterator().next();
            a2.remove(next4);
            arrayList.add(next4.f2653a);
            for (a next5 : next4.b) {
                next5.c.remove(next4);
                if (next5.a()) {
                    a2.add(next5);
                }
            }
        }
        if (arrayList.size() == list.size()) {
            Collections.reverse(arrayList);
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        for (a aVar4 : hashSet) {
            if (!aVar4.a() && !aVar4.b.isEmpty()) {
                arrayList2.add(aVar4.f2653a);
            }
        }
        throw new g(arrayList2);
    }

    private static Set<a> a(Set<a> set) {
        HashSet hashSet = new HashSet();
        for (a next : set) {
            if (next.a()) {
                hashSet.add(next);
            }
        }
        return hashSet;
    }
}
