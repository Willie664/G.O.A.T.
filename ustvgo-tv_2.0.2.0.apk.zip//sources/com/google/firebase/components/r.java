package com.google.firebase.components;

import com.google.firebase.a.b;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

final class r implements b {

    /* renamed from: a  reason: collision with root package name */
    private final Set<Class<?>> f2658a;
    private final Set<Class<?>> b;
    private final Set<Class<?>> c;
    private final b d;

    static class a implements b {

        /* renamed from: a  reason: collision with root package name */
        private final Set<Class<?>> f2659a;
        private final b b;

        public a(Set<Class<?>> set, b bVar) {
            this.f2659a = set;
            this.b = bVar;
        }
    }

    r(a<?> aVar, b bVar) {
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        for (f next : aVar.b) {
            if (next.a()) {
                hashSet.add(next.f2648a);
            } else {
                hashSet2.add(next.f2648a);
            }
        }
        if (!aVar.d.isEmpty()) {
            hashSet.add(b.class);
        }
        this.f2658a = Collections.unmodifiableSet(hashSet);
        this.b = Collections.unmodifiableSet(hashSet2);
        this.c = aVar.d;
        this.d = bVar;
    }

    public final <T> T a(Class<T> cls) {
        if (this.f2658a.contains(cls)) {
            T a2 = this.d.a(cls);
            return !cls.equals(b.class) ? a2 : new a(this.c, (b) a2);
        }
        throw new IllegalArgumentException(String.format("Requesting %s is not allowed.", new Object[]{cls}));
    }

    public final <T> com.google.firebase.b.a<T> b(Class<T> cls) {
        if (this.b.contains(cls)) {
            return this.d.b(cls);
        }
        throw new IllegalArgumentException(String.format("Requesting Provider<%s> is not allowed.", new Object[]{cls}));
    }
}
