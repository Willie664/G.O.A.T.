package com.google.firebase;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.api.internal.b;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.util.q;
import com.google.firebase.a.b;
import com.google.firebase.components.e;
import com.google.firebase.components.k;
import com.google.firebase.components.l;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.concurrent.GuardedBy;

public class a {
    @GuardedBy("LOCK")

    /* renamed from: a  reason: collision with root package name */
    static final Map<String, a> f2637a = new android.support.v4.f.a();
    private static final List<String> b = Arrays.asList(new String[]{"com.google.firebase.auth.FirebaseAuth", "com.google.firebase.iid.FirebaseInstanceId"});
    private static final List<String> c = Collections.singletonList("com.google.firebase.crash.FirebaseCrash");
    private static final List<String> d = Arrays.asList(new String[]{"com.google.android.gms.measurement.AppMeasurement"});
    private static final List<String> e = Arrays.asList(new String[0]);
    private static final Set<String> f = Collections.emptySet();
    /* access modifiers changed from: private */
    public static final Object g = new Object();
    private static final Executor h = new b((byte) 0);
    private final Context i;
    private final String j;
    private final b k;
    private final l l;
    private final SharedPreferences m;
    private final b n;
    private final AtomicBoolean o = new AtomicBoolean(false);
    private final AtomicBoolean p = new AtomicBoolean();
    private final AtomicBoolean q;
    private final List<Object> r = new CopyOnWriteArrayList();
    private final List<Object> s = new CopyOnWriteArrayList();
    private final List<Object> t = new CopyOnWriteArrayList();
    private C0084a u;

    /* renamed from: com.google.firebase.a$a  reason: collision with other inner class name */
    public interface C0084a {
    }

    static class b implements Executor {

        /* renamed from: a  reason: collision with root package name */
        private static final Handler f2639a = new Handler(Looper.getMainLooper());

        private b() {
        }

        /* synthetic */ b(byte b) {
            this();
        }

        public final void execute(Runnable runnable) {
            f2639a.post(runnable);
        }
    }

    @TargetApi(24)
    static class c extends BroadcastReceiver {

        /* renamed from: a  reason: collision with root package name */
        private static AtomicReference<c> f2640a = new AtomicReference<>();
        private final Context b;

        private c(Context context) {
            this.b = context;
        }

        static /* synthetic */ void a(Context context) {
            if (f2640a.get() == null) {
                c cVar = new c(context);
                if (f2640a.compareAndSet((Object) null, cVar)) {
                    context.registerReceiver(cVar, new IntentFilter("android.intent.action.USER_UNLOCKED"));
                }
            }
        }

        public final void onReceive(Context context, Intent intent) {
            synchronized (a.g) {
                for (a a2 : a.f2637a.values()) {
                    a2.k();
                }
            }
            this.b.unregisterReceiver(this);
        }
    }

    private a(Context context, String str, b bVar) {
        this.i = (Context) ab.a(context);
        this.j = ab.a(str);
        this.k = (b) ab.a(bVar);
        this.u = new com.google.firebase.c.a();
        this.m = context.getSharedPreferences("com.google.firebase.common.prefs", 0);
        this.q = new AtomicBoolean(g());
        k kVar = new k(context);
        List<e> a2 = k.a(kVar.b.a(kVar.f2651a));
        this.l = new l(h, a2, com.google.firebase.components.a.a(context, Context.class, new Class[0]), com.google.firebase.components.a.a(this, a.class, new Class[0]), com.google.firebase.components.a.a(bVar, b.class, new Class[0]));
        this.n = (b) com.google.firebase.components.c.a(this.l, b.class);
    }

    public static a a(Context context) {
        synchronized (g) {
            if (f2637a.containsKey("[DEFAULT]")) {
                a c2 = c();
                return c2;
            }
            b a2 = b.a(context);
            if (a2 == null) {
                return null;
            }
            a a3 = a(context, a2, "[DEFAULT]");
            return a3;
        }
    }

    public static a a(Context context, b bVar, String str) {
        a aVar;
        if (context.getApplicationContext() instanceof Application) {
            com.google.android.gms.common.api.internal.b.a((Application) context.getApplicationContext());
            com.google.android.gms.common.api.internal.b.a().a((b.a) new b.a() {
                public final void a(boolean z) {
                    a.d();
                }
            });
        }
        String trim = str.trim();
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        synchronized (g) {
            ab.a(!f2637a.containsKey(trim), (Object) "FirebaseApp name " + trim + " already exists!");
            ab.a(context, (Object) "Application context cannot be null.");
            aVar = new a(context, trim, bVar);
            f2637a.put(trim, aVar);
        }
        aVar.k();
        return aVar;
    }

    private static <T> void a(Class<T> cls, T t2, Iterable<String> iterable, boolean z) {
        for (String next : iterable) {
            if (z) {
                try {
                    if (e.contains(next)) {
                    }
                } catch (ClassNotFoundException unused) {
                    if (!f.contains(next)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(next);
                        sb.append(" is not linked. Skipping initialization.");
                    } else {
                        throw new IllegalStateException(next + " is missing, but is required. Check if it has been removed by Proguard.");
                    }
                } catch (NoSuchMethodException unused2) {
                    throw new IllegalStateException(next + "#getInstance has been removed by Proguard. Add keep rule to prevent it.");
                } catch (InvocationTargetException e2) {
                    Log.wtf("FirebaseApp", "Firebase API initialization failure.", e2);
                } catch (IllegalAccessException e3) {
                    Log.wtf("FirebaseApp", "Failed to initialize ".concat(String.valueOf(next)), e3);
                }
            }
            Method method = Class.forName(next).getMethod("getInstance", new Class[]{cls});
            int modifiers = method.getModifiers();
            if (Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers)) {
                method.invoke((Object) null, new Object[]{t2});
            }
        }
    }

    public static a c() {
        a aVar;
        synchronized (g) {
            aVar = f2637a.get("[DEFAULT]");
            if (aVar == null) {
                throw new IllegalStateException("Default FirebaseApp is not initialized in this process " + q.a() + ". Make sure to call FirebaseApp.initializeApp(Context) first.");
            }
        }
        return aVar;
    }

    public static void d() {
        synchronized (g) {
            Iterator it = new ArrayList(f2637a.values()).iterator();
            while (it.hasNext()) {
                a aVar = (a) it.next();
                if (aVar.o.get()) {
                    aVar.j();
                }
            }
        }
    }

    private String f() {
        h();
        return this.j;
    }

    private boolean g() {
        ApplicationInfo applicationInfo;
        if (this.m.contains("firebase_automatic_data_collection_enabled")) {
            return this.m.getBoolean("firebase_automatic_data_collection_enabled", true);
        }
        try {
            PackageManager packageManager = this.i.getPackageManager();
            if (!(packageManager == null || (applicationInfo = packageManager.getApplicationInfo(this.i.getPackageName(), 128)) == null || applicationInfo.metaData == null || !applicationInfo.metaData.containsKey("firebase_automatic_data_collection_enabled"))) {
                return applicationInfo.metaData.getBoolean("firebase_automatic_data_collection_enabled");
            }
        } catch (PackageManager.NameNotFoundException unused) {
        }
        return true;
    }

    private void h() {
        ab.a(!this.p.get(), (Object) "FirebaseApp was deleted");
    }

    private boolean i() {
        return "[DEFAULT]".equals(f());
    }

    private void j() {
        Iterator<Object> it = this.s.iterator();
        while (it.hasNext()) {
            it.next();
        }
    }

    /* access modifiers changed from: private */
    public void k() {
        boolean isDeviceProtectedStorage = android.support.v4.content.a.isDeviceProtectedStorage(this.i);
        if (isDeviceProtectedStorage) {
            c.a(this.i);
        } else {
            this.l.a(i());
        }
        a(a.class, this, b, isDeviceProtectedStorage);
        if (i()) {
            a(a.class, this, c, isDeviceProtectedStorage);
            a(Context.class, this.i, d, isDeviceProtectedStorage);
        }
    }

    public final Context a() {
        h();
        return this.i;
    }

    public final <T> T a(Class<T> cls) {
        h();
        return com.google.firebase.components.c.a(this.l, cls);
    }

    public final b b() {
        h();
        return this.k;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        return this.j.equals(((a) obj).f());
    }

    public int hashCode() {
        return this.j.hashCode();
    }

    public String toString() {
        return aa.a(this).a("name", this.j).a("options", this.k).toString();
    }
}
