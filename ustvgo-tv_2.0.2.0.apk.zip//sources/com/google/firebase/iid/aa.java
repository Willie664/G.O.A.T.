package com.google.firebase.iid;

import android.util.Log;

final class aa implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ x f2663a;
    private final /* synthetic */ z b;

    aa(z zVar, x xVar) {
        this.b = zVar;
        this.f2663a = xVar;
    }

    public final void run() {
        Log.isLoggable("EnhancedIntentService", 3);
        this.b.f2698a.b(this.f2663a.f2696a);
        this.f2663a.a();
    }
}
