package com.google.firebase.iid;

import android.os.Binder;

public final class z extends Binder {
    /* access modifiers changed from: package-private */

    /* renamed from: a  reason: collision with root package name */
    public final zzb f2698a;

    z(zzb zzb) {
        this.f2698a = zzb;
    }
}
