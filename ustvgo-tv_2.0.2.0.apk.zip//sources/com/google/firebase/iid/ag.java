package com.google.firebase.iid;

import java.util.concurrent.Executor;

final /* synthetic */ class ag implements Executor {

    /* renamed from: a  reason: collision with root package name */
    static final Executor f2668a = new ag();

    private ag() {
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
