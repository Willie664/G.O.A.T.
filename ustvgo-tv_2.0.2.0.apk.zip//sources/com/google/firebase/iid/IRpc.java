package com.google.firebase.iid;

import android.support.annotation.Keep;
import com.google.android.gms.c.g;

@Keep
interface IRpc {
    @Keep
    g<Void> ackMessage(String str);

    @Keep
    g<String> buildChannel(String str);

    @Keep
    g<Void> deleteInstanceId(String str);

    @Keep
    g<Void> deleteToken(String str, String str2, String str3);

    @Keep
    g<String> getToken(String str, String str2, String str3);

    @Keep
    g<Void> subscribeToTopic(String str, String str2, String str3);

    @Keep
    g<Void> unsubscribeFromTopic(String str, String str2, String str3);
}
