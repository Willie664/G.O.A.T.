package com.google.firebase.iid;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import javax.annotation.Nullable;

final class u extends BroadcastReceiver {
    @Nullable

    /* renamed from: a  reason: collision with root package name */
    t f2693a;

    public u(t tVar) {
        this.f2693a = tVar;
    }

    public final void onReceive(Context context, Intent intent) {
        if (this.f2693a != null && this.f2693a.b()) {
            FirebaseInstanceId.f();
            FirebaseInstanceId.a((Runnable) this.f2693a, 0);
            this.f2693a.a().unregisterReceiver(this);
            this.f2693a = null;
        }
    }
}
