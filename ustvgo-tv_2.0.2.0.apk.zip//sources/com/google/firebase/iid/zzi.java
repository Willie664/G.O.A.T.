package com.google.firebase.iid;

import android.os.Build;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.b.e;
import com.google.android.gms.internal.b.f;

public class zzi implements Parcelable {
    public static final Parcelable.Creator<zzi> CREATOR = new ac();

    /* renamed from: a  reason: collision with root package name */
    private Messenger f2700a;
    private e b;

    public static final class a extends ClassLoader {
        /* access modifiers changed from: protected */
        public final Class<?> loadClass(String str, boolean z) {
            if (!"com.google.android.gms.iid.MessengerCompat".equals(str)) {
                return super.loadClass(str, z);
            }
            FirebaseInstanceId.f();
            return zzi.class;
        }
    }

    public zzi(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.f2700a = new Messenger(iBinder);
        } else {
            this.b = f.a(iBinder);
        }
    }

    private final IBinder a() {
        return this.f2700a != null ? this.f2700a.getBinder() : this.b.asBinder();
    }

    public final void a(Message message) {
        if (this.f2700a != null) {
            this.f2700a.send(message);
        } else {
            this.b.a(message);
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        try {
            return a().equals(((zzi) obj).a());
        } catch (ClassCastException unused) {
            return false;
        }
    }

    public int hashCode() {
        return a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.f2700a != null ? this.f2700a.getBinder() : this.b.asBinder());
    }
}
