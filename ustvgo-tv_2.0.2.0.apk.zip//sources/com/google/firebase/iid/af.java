package com.google.firebase.iid;

import com.google.android.gms.c.c;
import com.google.android.gms.c.g;
import com.google.android.gms.c.h;

final /* synthetic */ class af implements c {

    /* renamed from: a  reason: collision with root package name */
    private final FirebaseInstanceId f2667a;
    private final String b;
    private final String c;
    private final h d;

    af(FirebaseInstanceId firebaseInstanceId, String str, String str2, h hVar) {
        this.f2667a = firebaseInstanceId;
        this.b = str;
        this.c = str2;
        this.d = hVar;
    }

    public final void a(g gVar) {
        FirebaseInstanceId firebaseInstanceId = this.f2667a;
        String str = this.b;
        String str2 = this.c;
        h hVar = this.d;
        if (gVar.b()) {
            String str3 = (String) gVar.d();
            FirebaseInstanceId.b.a("", str, str2, str3, firebaseInstanceId.e.b());
            hVar.a(str3);
            return;
        }
        hVar.a(gVar.e());
    }
}
