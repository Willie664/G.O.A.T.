package com.google.firebase.iid;

import com.google.firebase.a;
import com.google.firebase.components.b;
import com.google.firebase.components.d;

final /* synthetic */ class j implements d {

    /* renamed from: a  reason: collision with root package name */
    static final d f2683a = new j();

    private j() {
    }

    public final Object a(b bVar) {
        return new FirebaseInstanceId((a) bVar.a(a.class));
    }
}
