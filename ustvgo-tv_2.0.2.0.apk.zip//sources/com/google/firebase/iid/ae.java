package com.google.firebase.iid;

import com.google.android.gms.c.g;

final /* synthetic */ class ae implements n {

    /* renamed from: a  reason: collision with root package name */
    private final FirebaseInstanceId f2666a;
    private final String b;
    private final String c;
    private final String d;

    ae(FirebaseInstanceId firebaseInstanceId, String str, String str2, String str3) {
        this.f2666a = firebaseInstanceId;
        this.b = str;
        this.c = str2;
        this.d = str3;
    }

    public final g a() {
        FirebaseInstanceId firebaseInstanceId = this.f2666a;
        return firebaseInstanceId.f.getToken(this.b, this.c, this.d);
    }
}
