package com.google.firebase.iid;

import com.google.android.gms.c.a;
import com.google.android.gms.c.g;

final class aj implements a<T, Void> {
    aj() {
    }

    public final /* bridge */ /* synthetic */ Object a(g gVar) {
        return null;
    }
}
