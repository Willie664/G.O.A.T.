package com.google.firebase.iid;

import android.content.Intent;

final class w implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ Intent f2695a;
    private final /* synthetic */ Intent b;
    private final /* synthetic */ zzb c;

    w(zzb zzb, Intent intent, Intent intent2) {
        this.c = zzb;
        this.f2695a = intent;
        this.b = intent2;
    }

    public final void run() {
        this.c.b(this.f2695a);
        this.c.d(this.b);
    }
}
