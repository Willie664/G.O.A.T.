package com.google.firebase.iid.a;

public interface a {
}
