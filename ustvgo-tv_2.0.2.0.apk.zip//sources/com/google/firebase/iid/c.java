package com.google.firebase.iid;

final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final ap f2678a;
    private final f b;

    c(ap apVar, f fVar) {
        this.f2678a = apVar;
        this.b = fVar;
    }

    public final void run() {
        this.f2678a.a(this.b.f2680a);
    }
}
