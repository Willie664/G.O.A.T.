package com.google.firebase.iid;

import android.content.Intent;
import android.util.Log;

final class y implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ Intent f2697a;
    private final /* synthetic */ x b;

    y(x xVar, Intent intent) {
        this.b = xVar;
        this.f2697a = intent;
    }

    public final void run() {
        String action = this.f2697a.getAction();
        StringBuilder sb = new StringBuilder(String.valueOf(action).length() + 61);
        sb.append("Service took too long to process intent: ");
        sb.append(action);
        sb.append(" App may get closed.");
        Log.w("EnhancedIntentService", sb.toString());
        this.b.a();
    }
}
