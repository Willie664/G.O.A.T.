package com.google.firebase.iid;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.c.g;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import javax.annotation.concurrent.GuardedBy;

public final class ao {
    @GuardedBy("MessengerIpcClient.class")
    private static ao c;

    /* renamed from: a  reason: collision with root package name */
    final Context f2673a;
    final ScheduledExecutorService b;
    @GuardedBy("this")
    private ap d = new ap(this, (byte) 0);
    @GuardedBy("this")
    private int e = 1;

    private ao(Context context, ScheduledExecutorService scheduledExecutorService) {
        this.b = scheduledExecutorService;
        this.f2673a = context.getApplicationContext();
    }

    public static synchronized ao a(Context context) {
        ao aoVar;
        synchronized (ao.class) {
            if (c == null) {
                c = new ao(context, Executors.newSingleThreadScheduledExecutor());
            }
            aoVar = c;
        }
        return aoVar;
    }

    public final synchronized int a() {
        int i;
        i = this.e;
        this.e = i + 1;
        return i;
    }

    public final synchronized <T> g<T> a(f<T> fVar) {
        if (Log.isLoggable("MessengerIpcClient", 3)) {
            String valueOf = String.valueOf(fVar);
            StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 9);
            sb.append("Queueing ");
            sb.append(valueOf);
        }
        if (!this.d.a((f) fVar)) {
            this.d = new ap(this, (byte) 0);
            this.d.a((f) fVar);
        }
        return fVar.b.f1319a;
    }
}
