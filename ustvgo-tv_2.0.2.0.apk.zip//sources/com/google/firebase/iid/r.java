package com.google.firebase.iid;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v4.f.a;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.Map;

final class r {

    /* renamed from: a  reason: collision with root package name */
    private final SharedPreferences f2690a;
    private final Context b;
    private final al c;
    private final Map<String, am> d;

    public r(Context context) {
        this(context, new al());
    }

    private r(Context context, al alVar) {
        this.d = new a();
        this.b = context;
        this.f2690a = context.getSharedPreferences("com.google.android.gms.appid", 0);
        this.c = alVar;
        File file = new File(android.support.v4.content.a.getNoBackupFilesDir(this.b), "com.google.android.gms.appid-no-backup");
        if (!file.exists()) {
            try {
                if (file.createNewFile() && !c()) {
                    b();
                    FirebaseInstanceId.a().g();
                }
            } catch (IOException e) {
                if (Log.isLoggable("FirebaseInstanceId", 3)) {
                    String valueOf = String.valueOf(e.getMessage());
                    if (valueOf.length() != 0) {
                        "Error creating file in no backup dir: ".concat(valueOf);
                    } else {
                        new String("Error creating file in no backup dir: ");
                    }
                }
            }
        }
    }

    static String a(String str, String str2) {
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 3 + String.valueOf(str2).length());
        sb.append(str);
        sb.append("|S|");
        sb.append(str2);
        return sb.toString();
    }

    private static String b(String str, String str2, String str3) {
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 4 + String.valueOf(str2).length() + String.valueOf(str3).length());
        sb.append(str);
        sb.append("|T|");
        sb.append(str2);
        sb.append("|");
        sb.append(str3);
        return sb.toString();
    }

    private final synchronized boolean c() {
        return this.f2690a.getAll().isEmpty();
    }

    public final synchronized s a(String str, String str2, String str3) {
        return s.a(this.f2690a.getString(b(str, str2, str3), (String) null));
    }

    public final synchronized String a() {
        return this.f2690a.getString("topic_operaion_queue", "");
    }

    public final synchronized void a(String str) {
        this.f2690a.edit().putString("topic_operaion_queue", str).apply();
    }

    public final synchronized void a(String str, String str2, String str3, String str4, String str5) {
        String a2 = s.a(str4, str5, System.currentTimeMillis());
        if (a2 != null) {
            SharedPreferences.Editor edit = this.f2690a.edit();
            edit.putString(b(str, str2, str3), a2);
            edit.commit();
        }
    }

    public final synchronized am b(String str) {
        am amVar;
        am amVar2 = this.d.get(str);
        if (amVar2 != null) {
            return amVar2;
        }
        try {
            Context context = this.b;
            amVar = al.b(context, str);
            if (amVar == null) {
                amVar = al.a(context, str);
            }
        } catch (an unused) {
            Log.w("FirebaseInstanceId", "Stored data is corrupt, generating new identity");
            FirebaseInstanceId.a().g();
            amVar = al.a(this.b, str);
        }
        this.d.put(str, amVar);
        return amVar;
    }

    public final synchronized void b() {
        this.d.clear();
        for (File file : al.a(this.b).listFiles()) {
            if (file.getName().startsWith("com.google.InstanceId")) {
                file.delete();
            }
        }
        this.f2690a.edit().clear().commit();
    }

    public final synchronized void c(String str) {
        String concat = String.valueOf(str).concat("|T|");
        SharedPreferences.Editor edit = this.f2690a.edit();
        for (String next : this.f2690a.getAll().keySet()) {
            if (next.startsWith(concat)) {
                edit.remove(next);
            }
        }
        edit.commit();
    }
}
