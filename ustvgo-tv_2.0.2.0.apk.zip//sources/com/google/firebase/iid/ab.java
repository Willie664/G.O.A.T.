package com.google.firebase.iid;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public final class ab implements ServiceConnection {

    /* renamed from: a  reason: collision with root package name */
    private final Context f2664a;
    private final Intent b;
    private final ScheduledExecutorService c;
    private final Queue<x> d;
    private z e;
    private boolean f;

    public ab(Context context, String str) {
        this(context, str, new ScheduledThreadPoolExecutor(0));
    }

    private ab(Context context, String str, ScheduledExecutorService scheduledExecutorService) {
        this.d = new ArrayDeque();
        this.f = false;
        this.f2664a = context.getApplicationContext();
        this.b = new Intent(str).setPackage(this.f2664a.getPackageName());
        this.c = scheduledExecutorService;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00bd, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final synchronized void a() {
        /*
            r5 = this;
            monitor-enter(r5)
            java.lang.String r0 = "EnhancedIntentService"
            r1 = 3
            android.util.Log.isLoggable(r0, r1)     // Catch:{ all -> 0x00c0 }
        L_0x0007:
            java.util.Queue<com.google.firebase.iid.x> r0 = r5.d     // Catch:{ all -> 0x00c0 }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x00c0 }
            if (r0 != 0) goto L_0x00be
            java.lang.String r0 = "EnhancedIntentService"
            android.util.Log.isLoggable(r0, r1)     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.z r0 = r5.e     // Catch:{ all -> 0x00c0 }
            if (r0 == 0) goto L_0x0066
            com.google.firebase.iid.z r0 = r5.e     // Catch:{ all -> 0x00c0 }
            boolean r0 = r0.isBinderAlive()     // Catch:{ all -> 0x00c0 }
            if (r0 == 0) goto L_0x0066
            java.lang.String r0 = "EnhancedIntentService"
            android.util.Log.isLoggable(r0, r1)     // Catch:{ all -> 0x00c0 }
            java.util.Queue<com.google.firebase.iid.x> r0 = r5.d     // Catch:{ all -> 0x00c0 }
            java.lang.Object r0 = r0.poll()     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.x r0 = (com.google.firebase.iid.x) r0     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.z r2 = r5.e     // Catch:{ all -> 0x00c0 }
            int r3 = android.os.Binder.getCallingUid()     // Catch:{ all -> 0x00c0 }
            int r4 = android.os.Process.myUid()     // Catch:{ all -> 0x00c0 }
            if (r3 != r4) goto L_0x005e
            java.lang.String r3 = "EnhancedIntentService"
            android.util.Log.isLoggable(r3, r1)     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.zzb r3 = r2.f2698a     // Catch:{ all -> 0x00c0 }
            android.content.Intent r4 = r0.f2696a     // Catch:{ all -> 0x00c0 }
            boolean r3 = r3.c(r4)     // Catch:{ all -> 0x00c0 }
            if (r3 == 0) goto L_0x004c
            r0.a()     // Catch:{ all -> 0x00c0 }
            goto L_0x0007
        L_0x004c:
            java.lang.String r3 = "EnhancedIntentService"
            android.util.Log.isLoggable(r3, r1)     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.zzb r3 = r2.f2698a     // Catch:{ all -> 0x00c0 }
            java.util.concurrent.ExecutorService r3 = r3.f2699a     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.aa r4 = new com.google.firebase.iid.aa     // Catch:{ all -> 0x00c0 }
            r4.<init>(r2, r0)     // Catch:{ all -> 0x00c0 }
            r3.execute(r4)     // Catch:{ all -> 0x00c0 }
            goto L_0x0007
        L_0x005e:
            java.lang.SecurityException r0 = new java.lang.SecurityException     // Catch:{ all -> 0x00c0 }
            java.lang.String r1 = "Binding only allowed within app"
            r0.<init>(r1)     // Catch:{ all -> 0x00c0 }
            throw r0     // Catch:{ all -> 0x00c0 }
        L_0x0066:
            java.lang.String r0 = "EnhancedIntentService"
            boolean r0 = android.util.Log.isLoggable(r0, r1)     // Catch:{ all -> 0x00c0 }
            r1 = 1
            if (r0 == 0) goto L_0x0081
            boolean r0 = r5.f     // Catch:{ all -> 0x00c0 }
            r0 = r0 ^ r1
            r2 = 39
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x00c0 }
            r3.<init>(r2)     // Catch:{ all -> 0x00c0 }
            java.lang.String r2 = "binder is dead. start connection? "
            r3.append(r2)     // Catch:{ all -> 0x00c0 }
            r3.append(r0)     // Catch:{ all -> 0x00c0 }
        L_0x0081:
            boolean r0 = r5.f     // Catch:{ all -> 0x00c0 }
            if (r0 != 0) goto L_0x00bc
            r5.f = r1     // Catch:{ all -> 0x00c0 }
            com.google.android.gms.common.stats.b.a()     // Catch:{ SecurityException -> 0x00a0 }
            android.content.Context r0 = r5.f2664a     // Catch:{ SecurityException -> 0x00a0 }
            android.content.Intent r1 = r5.b     // Catch:{ SecurityException -> 0x00a0 }
            r2 = 65
            boolean r0 = com.google.android.gms.common.stats.b.b(r0, r1, r5, r2)     // Catch:{ SecurityException -> 0x00a0 }
            if (r0 == 0) goto L_0x0098
            monitor-exit(r5)
            return
        L_0x0098:
            java.lang.String r0 = "EnhancedIntentService"
            java.lang.String r1 = "binding to the service failed"
            android.util.Log.e(r0, r1)     // Catch:{ SecurityException -> 0x00a0 }
            goto L_0x00a8
        L_0x00a0:
            r0 = move-exception
            java.lang.String r1 = "EnhancedIntentService"
            java.lang.String r2 = "Exception while binding the service"
            android.util.Log.e(r1, r2, r0)     // Catch:{ all -> 0x00c0 }
        L_0x00a8:
            java.util.Queue<com.google.firebase.iid.x> r0 = r5.d     // Catch:{ all -> 0x00c0 }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x00c0 }
            if (r0 != 0) goto L_0x00bc
            java.util.Queue<com.google.firebase.iid.x> r0 = r5.d     // Catch:{ all -> 0x00c0 }
            java.lang.Object r0 = r0.poll()     // Catch:{ all -> 0x00c0 }
            com.google.firebase.iid.x r0 = (com.google.firebase.iid.x) r0     // Catch:{ all -> 0x00c0 }
            r0.a()     // Catch:{ all -> 0x00c0 }
            goto L_0x00a8
        L_0x00bc:
            monitor-exit(r5)
            return
        L_0x00be:
            monitor-exit(r5)
            return
        L_0x00c0:
            r0 = move-exception
            monitor-exit(r5)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.ab.a():void");
    }

    public final synchronized void a(Intent intent, BroadcastReceiver.PendingResult pendingResult) {
        Log.isLoggable("EnhancedIntentService", 3);
        this.d.add(new x(intent, pendingResult, this.c));
        a();
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this) {
            this.f = false;
            this.e = (z) iBinder;
            if (Log.isLoggable("EnhancedIntentService", 3)) {
                String valueOf = String.valueOf(componentName);
                StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 20);
                sb.append("onServiceConnected: ");
                sb.append(valueOf);
            }
            a();
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        if (Log.isLoggable("EnhancedIntentService", 3)) {
            String valueOf = String.valueOf(componentName);
            StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 23);
            sb.append("onServiceDisconnected: ");
            sb.append(valueOf);
        }
        a();
    }
}
