package com.google.firebase.iid;

import android.util.Base64;
import java.security.KeyPair;
import java.util.Arrays;

final class am {

    /* renamed from: a  reason: collision with root package name */
    final KeyPair f2672a;
    final long b;

    am(KeyPair keyPair, long j) {
        this.f2672a = keyPair;
        this.b = j;
    }

    /* access modifiers changed from: package-private */
    public final String a() {
        return Base64.encodeToString(this.f2672a.getPublic().getEncoded(), 11);
    }

    /* access modifiers changed from: package-private */
    public final String b() {
        return Base64.encodeToString(this.f2672a.getPrivate().getEncoded(), 11);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof am)) {
            return false;
        }
        am amVar = (am) obj;
        return this.b == amVar.b && this.f2672a.getPublic().equals(amVar.f2672a.getPublic()) && this.f2672a.getPrivate().equals(amVar.f2672a.getPrivate());
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f2672a.getPublic(), this.f2672a.getPrivate(), Long.valueOf(this.b)});
    }
}
