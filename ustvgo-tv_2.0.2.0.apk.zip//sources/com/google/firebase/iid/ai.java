package com.google.firebase.iid;

import android.os.Bundle;
import com.google.android.gms.c.h;
import java.io.IOException;

final /* synthetic */ class ai implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final ah f2670a;
    private final Bundle b;
    private final h c;

    ai(ah ahVar, Bundle bundle, h hVar) {
        this.f2670a = ahVar;
        this.b = bundle;
        this.c = hVar;
    }

    public final void run() {
        ah ahVar = this.f2670a;
        Bundle bundle = this.b;
        h hVar = this.c;
        try {
            hVar.a(ahVar.f2669a.a(bundle));
        } catch (IOException e) {
            hVar.a((Exception) e);
        }
    }
}
