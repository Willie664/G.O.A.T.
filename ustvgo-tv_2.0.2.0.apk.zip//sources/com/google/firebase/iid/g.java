package com.google.firebase.iid;

public final class g extends Exception {

    /* renamed from: a  reason: collision with root package name */
    final int f2681a;

    public g(int i, String str) {
        super(str);
        this.f2681a = i;
    }
}
