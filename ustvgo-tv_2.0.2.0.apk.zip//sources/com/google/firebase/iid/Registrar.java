package com.google.firebase.iid;

import android.support.annotation.Keep;
import com.google.android.gms.common.internal.ab;
import com.google.firebase.components.a;
import com.google.firebase.components.e;
import com.google.firebase.components.f;
import java.util.Arrays;
import java.util.List;

@Keep
public final class Registrar implements e {

    static class a implements com.google.firebase.iid.a.a {

        /* renamed from: a  reason: collision with root package name */
        private final FirebaseInstanceId f2662a;

        public a(FirebaseInstanceId firebaseInstanceId) {
            this.f2662a = firebaseInstanceId;
        }
    }

    @Keep
    public final List<com.google.firebase.components.a<?>> getComponents() {
        a.C0085a<FirebaseInstanceId> a2 = com.google.firebase.components.a.a(FirebaseInstanceId.class).a(f.a(com.google.firebase.a.class)).a(j.f2683a);
        ab.a(a2.f2647a == 0, (Object) "Instantiation type has already been set.");
        a2.f2647a = 1;
        return Arrays.asList(new com.google.firebase.components.a[]{a2.a(), com.google.firebase.components.a.a(com.google.firebase.iid.a.a.class).a(f.a(FirebaseInstanceId.class)).a(k.f2684a).a()});
    }
}
