package com.google.firebase.iid;

import android.util.Pair;
import com.google.android.gms.c.a;
import com.google.android.gms.c.g;

final /* synthetic */ class m implements a {

    /* renamed from: a  reason: collision with root package name */
    private final l f2686a;
    private final Pair b;

    m(l lVar, Pair pair) {
        this.f2686a = lVar;
        this.b = pair;
    }

    public final Object a(g gVar) {
        return this.f2686a.a(this.b, gVar);
    }
}
