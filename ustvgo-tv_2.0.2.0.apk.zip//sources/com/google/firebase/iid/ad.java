package com.google.firebase.iid;

import com.google.android.gms.c.h;

final /* synthetic */ class ad implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final FirebaseInstanceId f2665a;
    private final String b;
    private final String c;
    private final h d;
    private final String e;

    ad(FirebaseInstanceId firebaseInstanceId, String str, String str2, h hVar, String str3) {
        this.f2665a = firebaseInstanceId;
        this.b = str;
        this.c = str2;
        this.d = hVar;
        this.e = str3;
    }

    public final void run() {
        FirebaseInstanceId firebaseInstanceId = this.f2665a;
        String str = this.b;
        String str2 = this.c;
        h hVar = this.d;
        String str3 = this.e;
        s a2 = FirebaseInstanceId.b.a("", str, str2);
        if (a2 == null || a2.b(firebaseInstanceId.e.b())) {
            firebaseInstanceId.g.a(str, str3, new ae(firebaseInstanceId, FirebaseInstanceId.d(), str, str3)).a(FirebaseInstanceId.c, new af(firebaseInstanceId, str, str3, hVar));
            return;
        }
        hVar.a(a2.f2691a);
    }
}
