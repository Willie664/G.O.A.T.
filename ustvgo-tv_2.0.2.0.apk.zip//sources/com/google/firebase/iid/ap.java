package com.google.firebase.iid;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.stats.b;
import java.util.ArrayDeque;
import java.util.Queue;
import javax.annotation.concurrent.GuardedBy;

final class ap implements ServiceConnection {
    @GuardedBy("this")

    /* renamed from: a  reason: collision with root package name */
    int f2674a;
    final Messenger b;
    d c;
    @GuardedBy("this")
    final Queue<f<?>> d;
    @GuardedBy("this")
    final SparseArray<f<?>> e;
    final /* synthetic */ ao f;

    private ap(ao aoVar) {
        this.f = aoVar;
        this.f2674a = 0;
        this.b = new Messenger(new Handler(Looper.getMainLooper(), new aq(this)));
        this.d = new ArrayDeque();
        this.e = new SparseArray<>();
    }

    /* synthetic */ ap(ao aoVar, byte b2) {
        this(aoVar);
    }

    private final void c() {
        this.f.b.execute(new b(this));
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a() {
        if (this.f2674a == 2 && this.d.isEmpty() && this.e.size() == 0) {
            Log.isLoggable("MessengerIpcClient", 2);
            this.f2674a = 3;
            b.a();
            b.a(this.f.f2673a, this);
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(int i) {
        f fVar = this.e.get(i);
        if (fVar != null) {
            StringBuilder sb = new StringBuilder(31);
            sb.append("Timing out request: ");
            sb.append(i);
            Log.w("MessengerIpcClient", sb.toString());
            this.e.remove(i);
            fVar.a(new g(3, "Timed out waiting for response"));
            a();
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(int i, String str) {
        if (Log.isLoggable("MessengerIpcClient", 3)) {
            String valueOf = String.valueOf(str);
            if (valueOf.length() != 0) {
                "Disconnected: ".concat(valueOf);
            } else {
                new String("Disconnected: ");
            }
        }
        switch (this.f2674a) {
            case 0:
                throw new IllegalStateException();
            case 1:
            case 2:
                Log.isLoggable("MessengerIpcClient", 2);
                this.f2674a = 4;
                b.a();
                b.a(this.f.f2673a, this);
                g gVar = new g(i, str);
                for (f a2 : this.d) {
                    a2.a(gVar);
                }
                this.d.clear();
                for (int i2 = 0; i2 < this.e.size(); i2++) {
                    this.e.valueAt(i2).a(gVar);
                }
                this.e.clear();
                return;
            case 3:
                this.f2674a = 4;
                return;
            case 4:
                return;
            default:
                int i3 = this.f2674a;
                StringBuilder sb = new StringBuilder(26);
                sb.append("Unknown state: ");
                sb.append(i3);
                throw new IllegalStateException(sb.toString());
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0049, code lost:
        r5 = r5.getData();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0054, code lost:
        if (r5.getBoolean("unsupported", false) == false) goto L_0x0062;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0056, code lost:
        r1.a(new com.google.firebase.iid.g(4, "Not supported by GmsCore"));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0062, code lost:
        r1.a(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0065, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(android.os.Message r5) {
        /*
            r4 = this;
            int r0 = r5.arg1
            java.lang.String r1 = "MessengerIpcClient"
            r2 = 3
            boolean r1 = android.util.Log.isLoggable(r1, r2)
            if (r1 == 0) goto L_0x001a
            r1 = 41
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r1)
            java.lang.String r1 = "Received response to request: "
            r2.append(r1)
            r2.append(r0)
        L_0x001a:
            monitor-enter(r4)
            android.util.SparseArray<com.google.firebase.iid.f<?>> r1 = r4.e     // Catch:{ all -> 0x0066 }
            java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x0066 }
            com.google.firebase.iid.f r1 = (com.google.firebase.iid.f) r1     // Catch:{ all -> 0x0066 }
            r2 = 1
            if (r1 != 0) goto L_0x0040
            java.lang.String r5 = "MessengerIpcClient"
            r1 = 50
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0066 }
            r3.<init>(r1)     // Catch:{ all -> 0x0066 }
            java.lang.String r1 = "Received response for unknown request: "
            r3.append(r1)     // Catch:{ all -> 0x0066 }
            r3.append(r0)     // Catch:{ all -> 0x0066 }
            java.lang.String r0 = r3.toString()     // Catch:{ all -> 0x0066 }
            android.util.Log.w(r5, r0)     // Catch:{ all -> 0x0066 }
            monitor-exit(r4)     // Catch:{ all -> 0x0066 }
            return r2
        L_0x0040:
            android.util.SparseArray<com.google.firebase.iid.f<?>> r3 = r4.e     // Catch:{ all -> 0x0066 }
            r3.remove(r0)     // Catch:{ all -> 0x0066 }
            r4.a()     // Catch:{ all -> 0x0066 }
            monitor-exit(r4)     // Catch:{ all -> 0x0066 }
            android.os.Bundle r5 = r5.getData()
            java.lang.String r0 = "unsupported"
            r3 = 0
            boolean r0 = r5.getBoolean(r0, r3)
            if (r0 == 0) goto L_0x0062
            com.google.firebase.iid.g r5 = new com.google.firebase.iid.g
            r0 = 4
            java.lang.String r3 = "Not supported by GmsCore"
            r5.<init>(r0, r3)
            r1.a((com.google.firebase.iid.g) r5)
            goto L_0x0065
        L_0x0062:
            r1.a((android.os.Bundle) r5)
        L_0x0065:
            return r2
        L_0x0066:
            r5 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0066 }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.ap.a(android.os.Message):boolean");
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0065, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized boolean a(com.google.firebase.iid.f r6) {
        /*
            r5 = this;
            monitor-enter(r5)
            int r0 = r5.f2674a     // Catch:{ all -> 0x007f }
            r1 = 0
            r2 = 1
            switch(r0) {
                case 0: goto L_0x001e;
                case 1: goto L_0x0017;
                case 2: goto L_0x000d;
                case 3: goto L_0x000b;
                case 4: goto L_0x000b;
                default: goto L_0x0008;
            }     // Catch:{ all -> 0x007f }
        L_0x0008:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException     // Catch:{ all -> 0x007f }
            goto L_0x0066
        L_0x000b:
            monitor-exit(r5)
            return r1
        L_0x000d:
            java.util.Queue<com.google.firebase.iid.f<?>> r0 = r5.d     // Catch:{ all -> 0x007f }
            r0.add(r6)     // Catch:{ all -> 0x007f }
            r5.c()     // Catch:{ all -> 0x007f }
            monitor-exit(r5)
            return r2
        L_0x0017:
            java.util.Queue<com.google.firebase.iid.f<?>> r0 = r5.d     // Catch:{ all -> 0x007f }
            r0.add(r6)     // Catch:{ all -> 0x007f }
            monitor-exit(r5)
            return r2
        L_0x001e:
            java.util.Queue<com.google.firebase.iid.f<?>> r0 = r5.d     // Catch:{ all -> 0x007f }
            r0.add(r6)     // Catch:{ all -> 0x007f }
            int r6 = r5.f2674a     // Catch:{ all -> 0x007f }
            if (r6 != 0) goto L_0x0029
            r6 = 1
            goto L_0x002a
        L_0x0029:
            r6 = 0
        L_0x002a:
            com.google.android.gms.common.internal.ab.a((boolean) r6)     // Catch:{ all -> 0x007f }
            java.lang.String r6 = "MessengerIpcClient"
            r0 = 2
            android.util.Log.isLoggable(r6, r0)     // Catch:{ all -> 0x007f }
            r5.f2674a = r2     // Catch:{ all -> 0x007f }
            android.content.Intent r6 = new android.content.Intent     // Catch:{ all -> 0x007f }
            java.lang.String r0 = "com.google.android.c2dm.intent.REGISTER"
            r6.<init>(r0)     // Catch:{ all -> 0x007f }
            java.lang.String r0 = "com.google.android.gms"
            r6.setPackage(r0)     // Catch:{ all -> 0x007f }
            com.google.android.gms.common.stats.b.a()     // Catch:{ all -> 0x007f }
            com.google.firebase.iid.ao r0 = r5.f     // Catch:{ all -> 0x007f }
            android.content.Context r0 = r0.f2673a     // Catch:{ all -> 0x007f }
            boolean r6 = com.google.android.gms.common.stats.b.b(r0, r6, r5, r2)     // Catch:{ all -> 0x007f }
            if (r6 != 0) goto L_0x0054
            java.lang.String r6 = "Unable to bind to service"
            r5.a(r1, r6)     // Catch:{ all -> 0x007f }
            goto L_0x0064
        L_0x0054:
            com.google.firebase.iid.ao r6 = r5.f     // Catch:{ all -> 0x007f }
            java.util.concurrent.ScheduledExecutorService r6 = r6.b     // Catch:{ all -> 0x007f }
            com.google.firebase.iid.ar r0 = new com.google.firebase.iid.ar     // Catch:{ all -> 0x007f }
            r0.<init>(r5)     // Catch:{ all -> 0x007f }
            r3 = 30
            java.util.concurrent.TimeUnit r1 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ all -> 0x007f }
            r6.schedule(r0, r3, r1)     // Catch:{ all -> 0x007f }
        L_0x0064:
            monitor-exit(r5)
            return r2
        L_0x0066:
            int r0 = r5.f2674a     // Catch:{ all -> 0x007f }
            r1 = 26
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x007f }
            r2.<init>(r1)     // Catch:{ all -> 0x007f }
            java.lang.String r1 = "Unknown state: "
            r2.append(r1)     // Catch:{ all -> 0x007f }
            r2.append(r0)     // Catch:{ all -> 0x007f }
            java.lang.String r0 = r2.toString()     // Catch:{ all -> 0x007f }
            r6.<init>(r0)     // Catch:{ all -> 0x007f }
            throw r6     // Catch:{ all -> 0x007f }
        L_0x007f:
            r6 = move-exception
            monitor-exit(r5)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.ap.a(com.google.firebase.iid.f):boolean");
    }

    /* access modifiers changed from: package-private */
    public final synchronized void b() {
        if (this.f2674a == 1) {
            a(1, "Timed out while binding");
        }
    }

    public final synchronized void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        Log.isLoggable("MessengerIpcClient", 2);
        if (iBinder == null) {
            a(0, "Null service connection");
            return;
        }
        try {
            this.c = new d(iBinder);
            this.f2674a = 2;
            c();
        } catch (RemoteException e2) {
            a(0, e2.getMessage());
        }
    }

    public final synchronized void onServiceDisconnected(ComponentName componentName) {
        Log.isLoggable("MessengerIpcClient", 2);
        a(2, "Service disconnected");
    }
}
