package com.google.firebase.iid;

import android.os.Handler;
import android.os.Message;

final /* synthetic */ class aq implements Handler.Callback {

    /* renamed from: a  reason: collision with root package name */
    private final ap f2675a;

    aq(ap apVar) {
        this.f2675a = apVar;
    }

    public final boolean handleMessage(Message message) {
        return this.f2675a.a(message);
    }
}
