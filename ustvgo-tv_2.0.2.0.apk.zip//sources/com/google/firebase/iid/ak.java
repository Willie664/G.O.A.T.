package com.google.firebase.iid;

import android.os.Bundle;
import com.google.android.gms.c.a;
import com.google.android.gms.c.g;
import java.io.IOException;

final class ak implements a<Bundle, String> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ah f2671a;

    ak(ah ahVar) {
        this.f2671a = ahVar;
    }

    public final /* synthetic */ Object a(g gVar) {
        return ah.a((Bundle) gVar.a(IOException.class));
    }
}
