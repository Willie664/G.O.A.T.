package com.google.firebase.iid;

final class an extends Exception {
    an(Exception exc) {
        super(exc);
    }
}
