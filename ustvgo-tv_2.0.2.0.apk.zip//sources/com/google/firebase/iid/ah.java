package com.google.firebase.iid;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.c.g;
import com.google.android.gms.c.h;
import com.google.android.gms.c.j;
import com.google.firebase.a;
import java.io.IOException;
import java.util.concurrent.Executor;

final class ah implements IRpc {

    /* renamed from: a  reason: collision with root package name */
    final o f2669a;
    private final a b;
    private final i c;
    private final Executor d;

    ah(a aVar, i iVar, Executor executor) {
        this(aVar, iVar, executor, new o(aVar.a(), iVar));
    }

    private ah(a aVar, i iVar, Executor executor, o oVar) {
        this.b = aVar;
        this.c = iVar;
        this.f2669a = oVar;
        this.d = executor;
    }

    private final <T> g<Void> a(g<T> gVar) {
        return gVar.a(this.d, (com.google.android.gms.c.a<T, TContinuationResult>) new aj());
    }

    private final g<Bundle> a(String str, String str2, String str3, Bundle bundle) {
        bundle.putString("scope", str3);
        bundle.putString("sender", str2);
        bundle.putString("subtype", str2);
        bundle.putString("appid", str);
        bundle.putString("gmp_app_id", this.b.b().f2644a);
        bundle.putString("gmsv", Integer.toString(this.c.d()));
        bundle.putString("osv", Integer.toString(Build.VERSION.SDK_INT));
        bundle.putString("app_ver", this.c.b());
        bundle.putString("app_ver_name", this.c.c());
        bundle.putString("cliv", "fiid-12451000");
        h hVar = new h();
        this.d.execute(new ai(this, bundle, hVar));
        return hVar.f1319a;
    }

    static /* synthetic */ String a(Bundle bundle) {
        if (bundle != null) {
            String string = bundle.getString("registration_id");
            if (string != null) {
                return string;
            }
            String string2 = bundle.getString("unregistered");
            if (string2 != null) {
                return string2;
            }
            String string3 = bundle.getString("error");
            if ("RST".equals(string3)) {
                throw new IOException("INSTANCE_ID_RESET");
            } else if (string3 != null) {
                throw new IOException(string3);
            } else {
                String valueOf = String.valueOf(bundle);
                StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 21);
                sb.append("Unexpected response: ");
                sb.append(valueOf);
                Log.w("FirebaseInstanceId", sb.toString(), new Throwable());
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
        } else {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
    }

    private final g<String> b(g<Bundle> gVar) {
        return gVar.a(this.d, (com.google.android.gms.c.a<Bundle, TContinuationResult>) new ak(this));
    }

    public final g<Void> ackMessage(String str) {
        return null;
    }

    public final g<String> buildChannel(String str) {
        return j.a("");
    }

    public final g<Void> deleteInstanceId(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("iid-operation", "delete");
        bundle.putString("delete", "1");
        return a(b(a(str, "*", "*", bundle)));
    }

    public final g<Void> deleteToken(String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        bundle.putString("delete", "1");
        return a(b(a(str, str2, str3, bundle)));
    }

    public final g<String> getToken(String str, String str2, String str3) {
        return b(a(str, str2, str3, new Bundle()));
    }

    public final g<Void> subscribeToTopic(String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        String valueOf = String.valueOf("/topics/");
        String valueOf2 = String.valueOf(str3);
        bundle.putString("gcm.topic", valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
        String valueOf3 = String.valueOf("/topics/");
        String valueOf4 = String.valueOf(str3);
        return a(b(a(str, str2, valueOf4.length() != 0 ? valueOf3.concat(valueOf4) : new String(valueOf3), bundle)));
    }

    public final g<Void> unsubscribeFromTopic(String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        String valueOf = String.valueOf("/topics/");
        String valueOf2 = String.valueOf(str3);
        bundle.putString("gcm.topic", valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
        bundle.putString("delete", "1");
        String valueOf3 = String.valueOf("/topics/");
        String valueOf4 = String.valueOf(str3);
        return a(b(a(str, str2, valueOf4.length() != 0 ? valueOf3.concat(valueOf4) : new String(valueOf3), bundle)));
    }
}
