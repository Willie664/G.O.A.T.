package com.google.firebase.iid;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

final class p extends Handler {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ o f2688a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    p(o oVar, Looper looper) {
        super(looper);
        this.f2688a = oVar;
    }

    public final void handleMessage(Message message) {
        o.a(this.f2688a, message);
    }
}
