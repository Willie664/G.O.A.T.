package com.google.firebase.iid;

import com.google.firebase.components.b;
import com.google.firebase.components.d;
import com.google.firebase.iid.Registrar;

final /* synthetic */ class k implements d {

    /* renamed from: a  reason: collision with root package name */
    static final d f2684a = new k();

    private k() {
    }

    public final Object a(b bVar) {
        return new Registrar.a((FirebaseInstanceId) bVar.a(FirebaseInstanceId.class));
    }
}
