package com.google.firebase.iid;

import com.google.android.gms.c.g;

interface n {
    g<String> a();
}
