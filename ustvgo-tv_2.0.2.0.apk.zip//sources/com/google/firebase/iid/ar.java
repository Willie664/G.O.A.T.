package com.google.firebase.iid;

final /* synthetic */ class ar implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final ap f2676a;

    ar(ap apVar) {
        this.f2676a = apVar;
    }

    public final void run() {
        this.f2676a.b();
    }
}
