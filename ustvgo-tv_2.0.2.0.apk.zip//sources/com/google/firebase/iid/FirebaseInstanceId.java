package com.google.firebase.iid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Looper;
import android.support.annotation.Keep;
import android.util.Log;
import com.google.android.gms.c.g;
import com.google.android.gms.c.h;
import com.google.android.gms.c.j;
import com.google.android.gms.measurement.AppMeasurement;
import com.google.firebase.a;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.concurrent.GuardedBy;

public class FirebaseInstanceId {

    /* renamed from: a  reason: collision with root package name */
    static final Executor f2660a = ag.f2668a;
    static r b;
    static final Executor c = Executors.newCachedThreadPool();
    private static final long h = TimeUnit.HOURS.toSeconds(8);
    @GuardedBy("FirebaseInstanceId.class")
    private static ScheduledThreadPoolExecutor i;
    private static final Executor j = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue());
    final a d;
    final i e;
    IRpc f;
    final l g;
    private final v k;
    @GuardedBy("this")
    private boolean l;
    @GuardedBy("this")
    private boolean m;

    FirebaseInstanceId(a aVar) {
        this(aVar, new i(aVar.a()));
    }

    private FirebaseInstanceId(a aVar, i iVar) {
        this.g = new l();
        this.l = false;
        if (i.a(aVar) != null) {
            synchronized (FirebaseInstanceId.class) {
                if (b == null) {
                    b = new r(aVar.a());
                }
            }
            this.d = aVar;
            this.e = iVar;
            if (this.f == null) {
                IRpc iRpc = (IRpc) aVar.a(IRpc.class);
                this.f = iRpc == null ? new ah(aVar, iVar, j) : iRpc;
            }
            this.f = this.f;
            this.k = new v(b);
            this.m = h();
            if (j()) {
                b();
                return;
            }
            return;
        }
        throw new IllegalStateException("FirebaseInstanceId failed to initialize, FirebaseApp is missing project ID");
    }

    public static FirebaseInstanceId a() {
        return getInstance(a.c());
    }

    static void a(Runnable runnable, long j2) {
        synchronized (FirebaseInstanceId.class) {
            if (i == null) {
                i = new ScheduledThreadPoolExecutor(1);
            }
            i.schedule(runnable, j2, TimeUnit.SECONDS);
        }
    }

    public static String d() {
        return i.a(b.b("").f2672a);
    }

    static boolean f() {
        if (!Log.isLoggable("FirebaseInstanceId", 3)) {
            return Build.VERSION.SDK_INT == 23 && Log.isLoggable("FirebaseInstanceId", 3);
        }
        return true;
    }

    @Keep
    public static synchronized FirebaseInstanceId getInstance(a aVar) {
        FirebaseInstanceId firebaseInstanceId;
        synchronized (FirebaseInstanceId.class) {
            firebaseInstanceId = (FirebaseInstanceId) aVar.a(FirebaseInstanceId.class);
        }
        return firebaseInstanceId;
    }

    private final boolean h() {
        ApplicationInfo applicationInfo;
        Context a2 = this.d.a();
        SharedPreferences sharedPreferences = a2.getSharedPreferences("com.google.firebase.messaging", 0);
        if (sharedPreferences.contains("auto_init")) {
            return sharedPreferences.getBoolean("auto_init", true);
        }
        try {
            PackageManager packageManager = a2.getPackageManager();
            if (!(packageManager == null || (applicationInfo = packageManager.getApplicationInfo(a2.getPackageName(), 128)) == null || applicationInfo.metaData == null || !applicationInfo.metaData.containsKey("firebase_messaging_auto_init_enabled"))) {
                return applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled");
            }
        } catch (PackageManager.NameNotFoundException unused) {
        }
        return i();
    }

    private final boolean i() {
        try {
            Class.forName("com.google.firebase.messaging.a");
            return true;
        } catch (ClassNotFoundException unused) {
            Context a2 = this.d.a();
            Intent intent = new Intent("com.google.firebase.MESSAGING_EVENT");
            intent.setPackage(a2.getPackageName());
            ResolveInfo resolveService = a2.getPackageManager().resolveService(intent, 0);
            return (resolveService == null || resolveService.serviceInfo == null) ? false : true;
        }
    }

    private synchronized boolean j() {
        return this.m;
    }

    /* access modifiers changed from: package-private */
    public final <T> T a(g<T> gVar) {
        try {
            return j.a(gVar, 30000, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e2) {
            Throwable cause = e2.getCause();
            if (cause instanceof IOException) {
                if ("INSTANCE_ID_RESET".equals(cause.getMessage())) {
                    g();
                }
                throw ((IOException) cause);
            } else if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else {
                throw new IOException(e2);
            }
        } catch (InterruptedException | TimeoutException unused) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
    }

    public final String a(String str, String str2) {
        if (Looper.getMainLooper() != Looper.myLooper()) {
            String str3 = (str2.isEmpty() || str2.equalsIgnoreCase(AppMeasurement.FCM_ORIGIN) || str2.equalsIgnoreCase("gcm")) ? "*" : str2;
            h hVar = new h();
            c.execute(new ad(this, str, str2, hVar, str3));
            return (String) a(hVar.f1319a);
        }
        throw new IOException("MAIN_THREAD");
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(long j2) {
        a((Runnable) new t(this, this.e, this.k, Math.min(Math.max(30, j2 << 1), h)), j2);
        this.l = true;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(boolean z) {
        this.l = z;
    }

    public final void b() {
        s e2 = e();
        if (e2 == null || e2.b(this.e.b()) || this.k.a()) {
            c();
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void c() {
        if (!this.l) {
            a(0);
        }
    }

    /* access modifiers changed from: package-private */
    public final s e() {
        return b.a("", i.a(this.d), "*");
    }

    /* access modifiers changed from: package-private */
    public final synchronized void g() {
        b.b();
        if (j()) {
            c();
        }
    }
}
