package com.google.firebase.analytics.connector;

import android.os.Bundle;

public interface a {
    void a(String str, String str2, Bundle bundle);

    void a(String str, String str2, Object obj);
}
