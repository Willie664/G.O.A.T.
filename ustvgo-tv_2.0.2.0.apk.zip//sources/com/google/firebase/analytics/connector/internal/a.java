package com.google.firebase.analytics.connector.internal;

import android.content.Context;
import com.google.firebase.components.b;
import com.google.firebase.components.d;

final /* synthetic */ class a implements d {

    /* renamed from: a  reason: collision with root package name */
    static final d f2642a = new a();

    private a() {
    }

    public final Object a(b bVar) {
        return com.google.firebase.analytics.connector.b.a((Context) bVar.a(Context.class));
    }
}
