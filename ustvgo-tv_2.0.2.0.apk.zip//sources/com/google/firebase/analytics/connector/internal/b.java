package com.google.firebase.analytics.connector.internal;

import android.os.Bundle;
import com.google.android.gms.measurement.AppMeasurement;
import java.util.Arrays;
import java.util.List;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    private static final List<String> f2643a = Arrays.asList(new String[]{"_e", "_f", "_iap", "_s", "_au", "_ui", "_cd", "app_open"});
    private static final List<String> b = Arrays.asList(new String[]{"auto", "app", "am"});
    private static final List<String> c = Arrays.asList(new String[]{"_r", "_dbg"});
    private static final List<String> d;
    private static final List<String> e = Arrays.asList(new String[]{"^_ltv_[A-Z]{3}$", "^_cc[1-5]{1}$"});

    static {
        String[][] strArr = {AppMeasurement.e.f2622a, AppMeasurement.e.b};
        int i = 0;
        for (int i2 = 0; i2 < 2; i2++) {
            i += strArr[i2].length;
        }
        Object[] copyOf = Arrays.copyOf(strArr[0], i);
        int length = strArr[0].length;
        for (int i3 = 1; i3 < 2; i3++) {
            String[] strArr2 = strArr[1];
            System.arraycopy(strArr2, 0, copyOf, length, strArr2.length);
        }
        d = Arrays.asList((String[]) copyOf);
    }

    public static boolean a(String str) {
        return !b.contains(str);
    }

    public static boolean a(String str, Bundle bundle) {
        if (f2643a.contains(str)) {
            return false;
        }
        if (bundle == null) {
            return true;
        }
        for (String containsKey : c) {
            if (bundle.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    public static boolean a(String str, String str2, Bundle bundle) {
        String str3;
        String str4;
        if (!"_cmp".equals(str2)) {
            return true;
        }
        if (!a(str) || bundle == null) {
            return false;
        }
        for (String containsKey : c) {
            if (bundle.containsKey(containsKey)) {
                return false;
            }
        }
        char c2 = 65535;
        int hashCode = str.hashCode();
        if (hashCode != 101200) {
            if (hashCode == 101230 && str.equals("fdl")) {
                c2 = 1;
            }
        } else if (str.equals(AppMeasurement.FCM_ORIGIN)) {
            c2 = 0;
        }
        switch (c2) {
            case 0:
                str3 = "_cis";
                str4 = "fcm_integration";
                break;
            case 1:
                str3 = "_cis";
                str4 = "fdl_integration";
                break;
            default:
                return false;
        }
        bundle.putString(str3, str4);
        return true;
    }

    public static boolean b(String str) {
        if (d.contains(str)) {
            return false;
        }
        for (String matches : e) {
            if (str.matches(matches)) {
                return false;
            }
        }
        return true;
    }
}
