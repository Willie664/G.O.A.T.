package com.google.firebase.analytics.connector;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.measurement.AppMeasurement;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class b implements a {
    private static volatile a b;

    /* renamed from: a  reason: collision with root package name */
    private final AppMeasurement f2641a;
    private final Map<String, Object> c = new ConcurrentHashMap();

    private b(AppMeasurement appMeasurement) {
        ab.a(appMeasurement);
        this.f2641a = appMeasurement;
    }

    public static a a(Context context) {
        ab.a(context);
        ab.a(context.getApplicationContext());
        if (b == null) {
            synchronized (a.class) {
                if (b == null) {
                    b = new b(AppMeasurement.getInstance(context));
                }
            }
        }
        return b;
    }

    public final void a(String str, String str2, Bundle bundle) {
        if (com.google.firebase.analytics.connector.internal.b.a(str) && com.google.firebase.analytics.connector.internal.b.a(str2, bundle) && com.google.firebase.analytics.connector.internal.b.a(str, str2, bundle)) {
            this.f2641a.logEventInternal(str, str2, bundle);
        }
    }

    public final void a(String str, String str2, Object obj) {
        if (!com.google.firebase.analytics.connector.internal.b.a(str) || !com.google.firebase.analytics.connector.internal.b.b(str2)) {
            return;
        }
        if ((!str2.equals("_ce1") && !str2.equals("_ce2")) || str.equals(AppMeasurement.FCM_ORIGIN) || str.equals("frc")) {
            this.f2641a.setUserPropertyInternal(str, str2, obj);
        }
    }
}
