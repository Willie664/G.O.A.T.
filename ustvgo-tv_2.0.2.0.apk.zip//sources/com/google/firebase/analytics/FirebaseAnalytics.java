package com.google.firebase.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Keep;
import com.google.android.gms.c.g;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.measurement.by;
import com.google.android.gms.internal.measurement.cx;
import com.google.android.gms.internal.measurement.dd;
import com.google.android.gms.internal.measurement.dr;
import com.google.android.gms.internal.measurement.ds;
import com.google.android.gms.internal.measurement.fn;
import com.google.android.gms.internal.measurement.u;

@Keep
public final class FirebaseAnalytics {
    private final by zzacw;

    public static class a {
    }

    public static class b {
    }

    public static class c {
    }

    public FirebaseAnalytics(by byVar) {
        ab.a(byVar);
        this.zzacw = byVar;
    }

    @Keep
    public static FirebaseAnalytics getInstance(Context context) {
        return by.a(context).g;
    }

    public final g<String> getAppInstanceId() {
        return this.zzacw.c().v();
    }

    public final void logEvent(String str, Bundle bundle) {
        this.zzacw.f.logEvent(str, bundle);
    }

    public final void resetAnalyticsData() {
        cx c2 = this.zzacw.c();
        c2.p().a((Runnable) new dd(c2, c2.j().a()));
    }

    public final void setAnalyticsCollectionEnabled(boolean z) {
        this.zzacw.f.setMeasurementEnabled(z);
    }

    @Keep
    public final void setCurrentScreen(Activity activity, String str, String str2) {
        ds f = this.zzacw.f();
        if (!u.a()) {
            f.q().f.a("setCurrentScreen must be called from the main thread");
        } else if (f.b == null) {
            f.q().f.a("setCurrentScreen cannot be called while no activity active");
        } else if (f.d.get(activity) == null) {
            f.q().f.a("setCurrentScreen must be called with an activity in the activity lifecycle");
        } else {
            if (str2 == null) {
                str2 = ds.a(activity.getClass().getCanonicalName());
            }
            boolean equals = f.b.b.equals(str2);
            boolean b2 = fn.b(f.b.f2523a, str);
            if (equals && b2) {
                f.q().g.a("setCurrentScreen cannot be called with the same class and name");
            } else if (str != null && (str.length() <= 0 || str.length() > 100)) {
                f.q().f.a("Invalid screen name length in setCurrentScreen. Length", Integer.valueOf(str.length()));
            } else if (str2 == null || (str2.length() > 0 && str2.length() <= 100)) {
                f.q().j.a("Setting current screen to name, class", str == null ? "null" : str, str2);
                dr drVar = new dr(str, str2, f.n().v());
                f.d.put(activity, drVar);
                f.a(activity, drVar, true);
            } else {
                f.q().f.a("Invalid class name length in setCurrentScreen. Length", Integer.valueOf(str2.length()));
            }
        }
    }

    public final void setMinimumSessionDuration(long j) {
        this.zzacw.f.setMinimumSessionDuration(j);
    }

    public final void setSessionTimeoutDuration(long j) {
        this.zzacw.f.setSessionTimeoutDuration(j);
    }

    public final void setUserId(String str) {
        this.zzacw.f.setUserPropertyInternal("app", "_id", str);
    }

    public final void setUserProperty(String str, String str2) {
        this.zzacw.f.setUserProperty(str, str2);
    }
}
