package com.google.ads;

@Deprecated
public final class a {

    /* renamed from: com.google.ads.a$a  reason: collision with other inner class name */
    public enum C0057a {
        INVALID_REQUEST("Invalid Ad request."),
        NO_FILL("Ad request successful, but no ad returned due to lack of ad inventory."),
        NETWORK_ERROR("A network error occurred."),
        INTERNAL_ERROR("There was an internal error.");
        
        private final String e;

        private C0057a(String str) {
            this.e = str;
        }

        public final String toString() {
            return this.e;
        }
    }

    public enum b {
        ;
        

        /* renamed from: a  reason: collision with root package name */
        public static final int f1172a = 1;
        public static final int b = 2;
        public static final int c = 3;

        static {
            d = new int[]{f1172a, b, c};
        }

        public static int[] a() {
            return (int[]) d.clone();
        }
    }
}
