package com.google.ads;

import android.support.v7.widget.helper.ItemTouchHelper;
import com.google.android.gms.ads.d;

@Deprecated
public final class b {
    public static final b b = new b(-1, -2);
    public static final b c = new b(320, 50);
    public static final b d = new b(300, ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION);
    public static final b e = new b(468, 60);
    public static final b f = new b(728, 90);
    public static final b g = new b(160, 600);

    /* renamed from: a  reason: collision with root package name */
    public final d f1173a;

    private b(int i, int i2) {
        this(new d(i, i2));
    }

    public b(d dVar) {
        this.f1173a = dVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        return this.f1173a.equals(((b) obj).f1173a);
    }

    public final int hashCode() {
        return this.f1173a.hashCode();
    }

    public final String toString() {
        return this.f1173a.toString();
    }
}
