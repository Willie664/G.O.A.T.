package com.google.ads.mediation;

@Deprecated
public interface f {
}
