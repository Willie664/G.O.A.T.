package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.a;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.d;
import com.google.android.gms.ads.mediation.customevent.c;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.internal.ads.ma;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter<c, c>, MediationInterstitialAdapter<c, c> {

    /* renamed from: a  reason: collision with root package name */
    private View f1178a;
    private a b;
    private b c;

    static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final CustomEventAdapter f1179a;
        private final com.google.ads.mediation.c b;

        public a(CustomEventAdapter customEventAdapter, com.google.ads.mediation.c cVar) {
            this.f1179a = customEventAdapter;
            this.b = cVar;
        }
    }

    class b {

        /* renamed from: a  reason: collision with root package name */
        private final CustomEventAdapter f1180a;
        private final d b;

        public b(CustomEventAdapter customEventAdapter, d dVar) {
            this.f1180a = customEventAdapter;
            this.b = dVar;
        }
    }

    private static <T> T a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String message = th.getMessage();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 46 + String.valueOf(message).length());
            sb.append("Could not instantiate custom event adapter: ");
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            ma.b(sb.toString());
            return null;
        }
    }

    public final void destroy() {
    }

    public final Class<c> getAdditionalParametersType() {
        return c.class;
    }

    public final View getBannerView() {
        return this.f1178a;
    }

    public final Class<c> getServerParametersType() {
        return c.class;
    }

    public final void requestBannerAd(com.google.ads.mediation.c cVar, Activity activity, c cVar2, com.google.ads.b bVar, com.google.ads.mediation.a aVar, c cVar3) {
        this.b = (a) a(cVar2.b);
        if (this.b == null) {
            cVar.a(a.C0057a.INTERNAL_ERROR);
            return;
        }
        if (cVar3 != null) {
            cVar3.a(cVar2.f1181a);
        }
        new a(this, cVar);
    }

    public final void requestInterstitialAd(d dVar, Activity activity, c cVar, com.google.ads.mediation.a aVar, c cVar2) {
        this.c = (b) a(cVar.b);
        if (this.c == null) {
            dVar.b(a.C0057a.INTERNAL_ERROR);
            return;
        }
        if (cVar2 != null) {
            cVar2.a(cVar.f1181a);
        }
        new b(this, dVar);
    }

    public final void showInterstitial() {
    }
}
