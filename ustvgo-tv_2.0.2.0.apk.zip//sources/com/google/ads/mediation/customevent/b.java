package com.google.ads.mediation.customevent;

@Deprecated
public interface b {
}
