package com.google.ads.mediation.customevent;

import com.google.ads.mediation.e;

public final class c extends e {
    @e.b(a = "label", b = true)

    /* renamed from: a  reason: collision with root package name */
    public String f1181a;
    @e.b(a = "class_name", b = true)
    public String b;
    @e.b(a = "parameter", b = false)
    public String c = null;
}
