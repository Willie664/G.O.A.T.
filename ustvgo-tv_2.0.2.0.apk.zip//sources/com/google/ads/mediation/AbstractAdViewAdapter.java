package com.google.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.b;
import com.google.android.gms.ads.c;
import com.google.android.gms.ads.formats.NativeAdView;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.formats.d;
import com.google.android.gms.ads.formats.e;
import com.google.android.gms.ads.formats.f;
import com.google.android.gms.ads.formats.g;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.b;
import com.google.android.gms.ads.mediation.g;
import com.google.android.gms.ads.mediation.h;
import com.google.android.gms.ads.mediation.i;
import com.google.android.gms.ads.mediation.j;
import com.google.android.gms.ads.mediation.k;
import com.google.android.gms.ads.mediation.l;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.internal.ads.amz;
import com.google.android.gms.internal.ads.ana;
import com.google.android.gms.internal.ads.anb;
import com.google.android.gms.internal.ads.ane;
import com.google.android.gms.internal.ads.anh;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.anv;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aoo;
import com.google.android.gms.internal.ads.apg;
import com.google.android.gms.internal.ads.aps;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.gd;
import com.google.android.gms.internal.ads.gi;
import com.google.android.gms.internal.ads.lp;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.zzatm;
import java.util.Date;
import java.util.Set;

@cj
public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationNativeAdapter, j, l, MediationRewardedVideoAdAdapter, zzatm {
    public static final String AD_UNIT_ID_PARAMETER = "pubid";
    private AdView zzgw;
    private com.google.android.gms.ads.f zzgx;
    private com.google.android.gms.ads.b zzgy;
    private Context zzgz;
    /* access modifiers changed from: private */
    public com.google.android.gms.ads.f zzha;
    /* access modifiers changed from: private */
    public com.google.android.gms.ads.reward.mediation.a zzhb;
    private final com.google.android.gms.ads.reward.b zzhc = new g(this);

    static class a extends g {
        private final com.google.android.gms.ads.formats.d p;

        public a(com.google.android.gms.ads.formats.d dVar) {
            this.p = dVar;
            this.h = dVar.b().toString();
            this.i = dVar.c();
            this.j = dVar.d().toString();
            this.k = dVar.e();
            this.l = dVar.f().toString();
            if (dVar.g() != null) {
                this.m = dVar.g().doubleValue();
            }
            if (dVar.h() != null) {
                this.n = dVar.h().toString();
            }
            if (dVar.i() != null) {
                this.o = dVar.i().toString();
            }
            a();
            b();
            this.f = dVar.j();
        }

        public final void a(View view) {
            if (view instanceof NativeAdView) {
                ((NativeAdView) view).setNativeAd(this.p);
            }
            com.google.android.gms.ads.formats.c cVar = com.google.android.gms.ads.formats.c.f1199a.get(view);
            if (cVar != null) {
                cVar.a((com.google.android.gms.ads.formats.a) this.p);
            }
        }
    }

    static class b extends h {
        private final com.google.android.gms.ads.formats.e n;

        public b(com.google.android.gms.ads.formats.e eVar) {
            this.n = eVar;
            this.h = eVar.b().toString();
            this.i = eVar.c();
            this.j = eVar.d().toString();
            if (eVar.e() != null) {
                this.k = eVar.e();
            }
            this.l = eVar.f().toString();
            this.m = eVar.g().toString();
            a();
            b();
            this.f = eVar.h();
        }

        public final void a(View view) {
            if (view instanceof NativeAdView) {
                ((NativeAdView) view).setNativeAd(this.n);
            }
            com.google.android.gms.ads.formats.c cVar = com.google.android.gms.ads.formats.c.f1199a.get(view);
            if (cVar != null) {
                cVar.a((com.google.android.gms.ads.formats.a) this.n);
            }
        }
    }

    static class c extends k {
        private final com.google.android.gms.ads.formats.g r;

        public c(com.google.android.gms.ads.formats.g gVar) {
            this.r = gVar;
            this.f1307a = gVar.a();
            this.b = gVar.b();
            this.c = gVar.c();
            this.d = gVar.d();
            this.e = gVar.e();
            this.f = gVar.f();
            this.g = gVar.g();
            this.h = gVar.h();
            this.i = gVar.i();
            this.n = gVar.l();
            this.p = true;
            this.q = true;
            this.j = gVar.j();
        }

        public final void a(View view) {
            if (view instanceof UnifiedNativeAdView) {
                ((UnifiedNativeAdView) view).setNativeAd(this.r);
                return;
            }
            com.google.android.gms.ads.formats.c cVar = com.google.android.gms.ads.formats.c.f1199a.get(view);
            if (cVar != null) {
                cVar.a(this.r);
            }
        }
    }

    static final class d extends com.google.android.gms.ads.a implements com.google.android.gms.ads.doubleclick.a, amz {

        /* renamed from: a  reason: collision with root package name */
        private final AbstractAdViewAdapter f1174a;
        private final com.google.android.gms.ads.mediation.c b;

        public d(AbstractAdViewAdapter abstractAdViewAdapter, com.google.android.gms.ads.mediation.c cVar) {
            this.f1174a = abstractAdViewAdapter;
            this.b = cVar;
        }

        public final void a() {
            this.b.a();
        }

        public final void a(int i) {
            this.b.a(i);
        }

        public final void a(String str, String str2) {
            this.b.a(str, str2);
        }

        public final void b() {
            this.b.b();
        }

        public final void c() {
            this.b.c();
        }

        public final void d() {
            this.b.d();
        }

        public final void e() {
            this.b.e();
        }
    }

    static final class e extends com.google.android.gms.ads.a implements amz {

        /* renamed from: a  reason: collision with root package name */
        private final AbstractAdViewAdapter f1175a;
        private final com.google.android.gms.ads.mediation.d b;

        public e(AbstractAdViewAdapter abstractAdViewAdapter, com.google.android.gms.ads.mediation.d dVar) {
            this.f1175a = abstractAdViewAdapter;
            this.b = dVar;
        }

        public final void a() {
            this.b.f();
        }

        public final void a(int i) {
            this.b.b(i);
        }

        public final void b() {
            this.b.g();
        }

        public final void c() {
            this.b.h();
        }

        public final void d() {
            this.b.i();
        }

        public final void e() {
            this.b.j();
        }
    }

    static final class f extends com.google.android.gms.ads.a implements d.a, e.a, f.a, f.b, g.a {

        /* renamed from: a  reason: collision with root package name */
        private final AbstractAdViewAdapter f1176a;
        private final com.google.android.gms.ads.mediation.e b;

        public f(AbstractAdViewAdapter abstractAdViewAdapter, com.google.android.gms.ads.mediation.e eVar) {
            this.f1176a = abstractAdViewAdapter;
            this.b = eVar;
        }

        public final void a() {
        }

        public final void a(int i) {
            this.b.c(i);
        }

        public final void a(com.google.android.gms.ads.formats.d dVar) {
            this.b.a((MediationNativeAdapter) this.f1176a, (com.google.android.gms.ads.mediation.f) new a(dVar));
        }

        public final void a(com.google.android.gms.ads.formats.e eVar) {
            this.b.a((MediationNativeAdapter) this.f1176a, (com.google.android.gms.ads.mediation.f) new b(eVar));
        }

        public final void a(com.google.android.gms.ads.formats.f fVar) {
            this.b.a(fVar);
        }

        public final void a(com.google.android.gms.ads.formats.f fVar, String str) {
            this.b.a(fVar, str);
        }

        public final void a(com.google.android.gms.ads.formats.g gVar) {
            this.b.a((MediationNativeAdapter) this.f1176a, (k) new c(gVar));
        }

        public final void b() {
            this.b.k();
        }

        public final void c() {
            this.b.l();
        }

        public final void d() {
            this.b.m();
        }

        public final void e() {
            this.b.n();
        }

        public final void f() {
            this.b.o();
        }
    }

    private final com.google.android.gms.ads.c zza(Context context, com.google.android.gms.ads.mediation.a aVar, Bundle bundle, Bundle bundle2) {
        c.a aVar2 = new c.a();
        Date a2 = aVar.a();
        if (a2 != null) {
            aVar2.f1189a.g = a2;
        }
        int b2 = aVar.b();
        if (b2 != 0) {
            aVar2.f1189a.i = b2;
        }
        Set<String> c2 = aVar.c();
        if (c2 != null) {
            for (String add : c2) {
                aVar2.f1189a.f1795a.add(add);
            }
        }
        Location d2 = aVar.d();
        if (d2 != null) {
            aVar2.f1189a.j = d2;
        }
        if (aVar.f()) {
            ans.a();
            aVar2.f1189a.a(lp.a(context));
        }
        if (aVar.e() != -1) {
            int i = 1;
            if (aVar.e() != 1) {
                i = 0;
            }
            aVar2.f1189a.n = i;
        }
        aVar2.f1189a.o = aVar.g();
        Bundle zza = zza(bundle, bundle2);
        Class<AdMobAdapter> cls = AdMobAdapter.class;
        aVar2.f1189a.b.putBundle(cls.getName(), zza);
        if (cls.equals(AdMobAdapter.class) && zza.getBoolean("_emulatorLiveAds")) {
            aVar2.f1189a.d.remove("B3EEABB8EE11C2BE770B684D95219ECB");
        }
        return new com.google.android.gms.ads.c(aVar2, (byte) 0);
    }

    public String getAdUnitId(Bundle bundle) {
        return bundle.getString(AD_UNIT_ID_PARAMETER);
    }

    public View getBannerView() {
        return this.zzgw;
    }

    public Bundle getInterstitialAdapterInfo() {
        b.a aVar = new b.a();
        aVar.f1300a = 1;
        Bundle bundle = new Bundle();
        bundle.putInt("capabilities", aVar.f1300a);
        return bundle;
    }

    public apg getVideoController() {
        com.google.android.gms.ads.h videoController;
        if (this.zzgw == null || (videoController = this.zzgw.getVideoController()) == null) {
            return null;
        }
        return videoController.a();
    }

    public void initialize(Context context, com.google.android.gms.ads.mediation.a aVar, String str, com.google.android.gms.ads.reward.mediation.a aVar2, Bundle bundle, Bundle bundle2) {
        this.zzgz = context.getApplicationContext();
        this.zzhb = aVar2;
        this.zzhb.a((MediationRewardedVideoAdAdapter) this);
    }

    public boolean isInitialized() {
        return this.zzhb != null;
    }

    public void loadAd(com.google.android.gms.ads.mediation.a aVar, Bundle bundle, Bundle bundle2) {
        if (this.zzgz == null || this.zzhb == null) {
            ma.a("AdMobAdapter.loadAd called before initialize.");
            return;
        }
        this.zzha = new com.google.android.gms.ads.f(this.zzgz);
        this.zzha.f1193a.f = true;
        this.zzha.a(getAdUnitId(bundle));
        com.google.android.gms.ads.f fVar = this.zzha;
        com.google.android.gms.ads.reward.b bVar = this.zzhc;
        aps aps = fVar.f1193a;
        try {
            aps.e = bVar;
            if (aps.c != null) {
                aps.c.a((gd) bVar != null ? new gi(bVar) : null);
            }
        } catch (RemoteException e2) {
            ma.c("#008 Must be called on the main UI thread.", e2);
        }
        com.google.android.gms.ads.f fVar2 = this.zzha;
        h hVar = new h(this);
        aps aps2 = fVar2.f1193a;
        try {
            aps2.d = hVar;
            if (aps2.c != null) {
                aps2.c.a((aoo) new ane(hVar));
            }
        } catch (RemoteException e3) {
            ma.c("#008 Must be called on the main UI thread.", e3);
        }
        this.zzha.a(zza(this.zzgz, aVar, bundle2, bundle));
    }

    public void onDestroy() {
        if (this.zzgw != null) {
            this.zzgw.c();
            this.zzgw = null;
        }
        if (this.zzgx != null) {
            this.zzgx = null;
        }
        if (this.zzgy != null) {
            this.zzgy = null;
        }
        if (this.zzha != null) {
            this.zzha = null;
        }
    }

    public void onImmersiveModeUpdated(boolean z) {
        if (this.zzgx != null) {
            this.zzgx.a(z);
        }
        if (this.zzha != null) {
            this.zzha.a(z);
        }
    }

    public void onPause() {
        if (this.zzgw != null) {
            this.zzgw.b();
        }
    }

    public void onResume() {
        if (this.zzgw != null) {
            this.zzgw.a();
        }
    }

    public void requestBannerAd(Context context, com.google.android.gms.ads.mediation.c cVar, Bundle bundle, com.google.android.gms.ads.d dVar, com.google.android.gms.ads.mediation.a aVar, Bundle bundle2) {
        this.zzgw = new AdView(context);
        this.zzgw.setAdSize(new com.google.android.gms.ads.d(dVar.k, dVar.l));
        this.zzgw.setAdUnitId(getAdUnitId(bundle));
        this.zzgw.setAdListener(new d(this, cVar));
        this.zzgw.a(zza(context, aVar, bundle2, bundle));
    }

    public void requestInterstitialAd(Context context, com.google.android.gms.ads.mediation.d dVar, Bundle bundle, com.google.android.gms.ads.mediation.a aVar, Bundle bundle2) {
        this.zzgx = new com.google.android.gms.ads.f(context);
        this.zzgx.a(getAdUnitId(bundle));
        com.google.android.gms.ads.f fVar = this.zzgx;
        e eVar = new e(this, dVar);
        aps aps = fVar.f1193a;
        try {
            aps.f1798a = eVar;
            if (aps.c != null) {
                aps.c.a((any) new anb(eVar));
            }
        } catch (RemoteException e2) {
            ma.c("#008 Must be called on the main UI thread.", e2);
        }
        aps aps2 = fVar.f1193a;
        amz amz = eVar;
        try {
            aps2.b = amz;
            if (aps2.c != null) {
                aps2.c.a((anv) new ana(amz));
            }
        } catch (RemoteException e3) {
            ma.c("#008 Must be called on the main UI thread.", e3);
        }
        this.zzgx.a(zza(context, aVar, bundle2, bundle));
    }

    public void requestNativeAd(Context context, com.google.android.gms.ads.mediation.e eVar, Bundle bundle, i iVar, Bundle bundle2) {
        f fVar = new f(this, eVar);
        b.a a2 = new b.a(context, bundle.getString(AD_UNIT_ID_PARAMETER)).a((com.google.android.gms.ads.a) fVar);
        com.google.android.gms.ads.formats.b h = iVar.h();
        if (h != null) {
            a2.a(h);
        }
        if (iVar.j()) {
            a2.a((g.a) fVar);
        }
        if (iVar.i()) {
            a2.a((d.a) fVar);
        }
        if (iVar.k()) {
            a2.a((e.a) fVar);
        }
        if (iVar.l()) {
            for (String next : iVar.m().keySet()) {
                a2.a(next, fVar, iVar.m().get(next).booleanValue() ? fVar : null);
            }
        }
        this.zzgy = a2.a();
        com.google.android.gms.ads.b bVar = this.zzgy;
        try {
            bVar.b.a(anh.a(bVar.f1186a, zza(context, iVar, bundle2, bundle).f1188a));
        } catch (RemoteException e2) {
            ma.a("Failed to load ad.", e2);
        }
    }

    public void showInterstitial() {
        this.zzgx.f1193a.b();
    }

    public void showVideo() {
        this.zzha.f1193a.b();
    }

    /* access modifiers changed from: protected */
    public abstract Bundle zza(Bundle bundle, Bundle bundle2);
}
