package com.google.ads.mediation;

import android.location.Location;
import java.util.Date;
import java.util.Set;

@Deprecated
public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final Date f1177a;
    private final int b;
    private final Set<String> c;
    private final boolean d;
    private final Location e;

    public a(Date date, int i, Set<String> set, boolean z, Location location) {
        this.f1177a = date;
        this.b = i;
        this.c = set;
        this.d = z;
        this.e = location;
    }
}
