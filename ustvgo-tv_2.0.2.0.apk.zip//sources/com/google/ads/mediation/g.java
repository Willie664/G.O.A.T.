package com.google.ads.mediation;

import com.google.android.gms.ads.f;
import com.google.android.gms.ads.reward.a;
import com.google.android.gms.ads.reward.b;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;

final class g implements b {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ AbstractAdViewAdapter f1182a;

    g(AbstractAdViewAdapter abstractAdViewAdapter) {
        this.f1182a = abstractAdViewAdapter;
    }

    public final void a() {
        this.f1182a.zzhb.b(this.f1182a);
    }

    public final void a(int i) {
        this.f1182a.zzhb.a((MediationRewardedVideoAdAdapter) this.f1182a, i);
    }

    public final void a(a aVar) {
        this.f1182a.zzhb.a((MediationRewardedVideoAdAdapter) this.f1182a, aVar);
    }

    public final void b() {
        this.f1182a.zzhb.c(this.f1182a);
    }

    public final void c() {
        this.f1182a.zzhb.d(this.f1182a);
    }

    public final void d() {
        this.f1182a.zzhb.e(this.f1182a);
        f unused = this.f1182a.zzha = null;
    }

    public final void e() {
        this.f1182a.zzhb.f(this.f1182a);
    }

    public final void f() {
        this.f1182a.zzhb.g(this.f1182a);
    }
}
