package com.google.ads.mediation;

import com.google.ads.a;

@Deprecated
public interface d {
    void b(a.C0057a aVar);
}
