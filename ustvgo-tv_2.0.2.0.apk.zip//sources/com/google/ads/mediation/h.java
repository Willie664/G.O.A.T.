package com.google.ads.mediation;

import com.google.android.gms.ads.reward.c;

final class h extends c {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ AbstractAdViewAdapter f1183a;

    h(AbstractAdViewAdapter abstractAdViewAdapter) {
        this.f1183a = abstractAdViewAdapter;
    }

    public final void a() {
        if (this.f1183a.zzha != null && this.f1183a.zzhb != null) {
            this.f1183a.zzhb.a(this.f1183a.zzha.f1193a.a());
        }
    }
}
