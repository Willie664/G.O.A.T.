package com.google.ads.mediation;

import com.google.ads.a;

@Deprecated
public interface c {
    void a(a.C0057a aVar);
}
