package com.google.android.gms.auth.api.signin.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.ab;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;
import org.json.JSONException;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    private static final Lock f1315a = new ReentrantLock();
    @GuardedBy("sLk")
    private static c b;
    private final Lock c = new ReentrantLock();
    @GuardedBy("mLk")
    private final SharedPreferences d;

    private c(Context context) {
        this.d = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    public static c a(Context context) {
        ab.a(context);
        f1315a.lock();
        try {
            if (b == null) {
                b = new c(context.getApplicationContext());
            }
            return b;
        } finally {
            f1315a.unlock();
        }
    }

    @Nullable
    public final GoogleSignInAccount a(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        StringBuilder sb = new StringBuilder(String.valueOf("googleSignInAccount").length() + 1 + String.valueOf(str).length());
        sb.append("googleSignInAccount");
        sb.append(":");
        sb.append(str);
        String b2 = b(sb.toString());
        if (b2 != null) {
            try {
                return GoogleSignInAccount.a(b2);
            } catch (JSONException unused) {
            }
        }
        return null;
    }

    @Nullable
    public final String b(String str) {
        this.c.lock();
        try {
            return this.d.getString(str, (String) null);
        } finally {
            this.c.unlock();
        }
    }
}
