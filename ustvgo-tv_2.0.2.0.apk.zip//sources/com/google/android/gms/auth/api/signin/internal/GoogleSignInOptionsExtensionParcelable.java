package com.google.android.gms.auth.api.signin.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;

public class GoogleSignInOptionsExtensionParcelable extends AbstractSafeParcelable {
    public static final Parcelable.Creator<GoogleSignInOptionsExtensionParcelable> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public int f1313a;
    private final int b;
    private Bundle c;

    GoogleSignInOptionsExtensionParcelable(int i, int i2, Bundle bundle) {
        this.b = i;
        this.f1313a = i2;
        this.c = bundle;
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.b);
        b.b(parcel, 2, this.f1313a);
        b.a(parcel, 3, this.c);
        b.b(parcel, a2);
    }
}
