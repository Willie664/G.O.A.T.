package com.google.android.gms.auth.api.signin.internal;

public final class b {
    private static int b = 31;

    /* renamed from: a  reason: collision with root package name */
    public int f1314a = 1;

    public final b a(Object obj) {
        this.f1314a = (b * this.f1314a) + (obj == null ? 0 : obj.hashCode());
        return this;
    }

    public final b a(boolean z) {
        this.f1314a = (b * this.f1314a) + (z ? 1 : 0);
        return this;
    }
}
