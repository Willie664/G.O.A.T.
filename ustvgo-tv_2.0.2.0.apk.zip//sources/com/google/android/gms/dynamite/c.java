package com.google.android.gms.dynamite;

import android.content.Context;
import com.google.android.gms.dynamite.DynamiteModule;

final class c implements DynamiteModule.b.a {
    c() {
    }

    public final int a(Context context, String str) {
        return DynamiteModule.a(context, str);
    }

    public final int a(Context context, String str, boolean z) {
        return DynamiteModule.a(context, str, z);
    }
}
