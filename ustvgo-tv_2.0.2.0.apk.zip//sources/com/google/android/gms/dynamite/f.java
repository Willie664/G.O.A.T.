package com.google.android.gms.dynamite;

import android.content.Context;
import com.google.android.gms.dynamite.DynamiteModule;

final class f implements DynamiteModule.b {
    f() {
    }

    public final DynamiteModule.b.C0076b a(Context context, String str, DynamiteModule.b.a aVar) {
        int i;
        DynamiteModule.b.C0076b bVar = new DynamiteModule.b.C0076b();
        bVar.f1535a = aVar.a(context, str);
        bVar.b = aVar.a(context, str, true);
        if (bVar.f1535a == 0 && bVar.b == 0) {
            i = 0;
        } else if (bVar.f1535a >= bVar.b) {
            i = -1;
        } else {
            bVar.c = 1;
            return bVar;
        }
        bVar.c = i;
        return bVar;
    }
}
