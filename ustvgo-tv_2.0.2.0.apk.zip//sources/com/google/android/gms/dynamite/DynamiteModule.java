package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.e;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.dynamite.a;
import com.google.android.gms.dynamite.b;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import javax.annotation.concurrent.GuardedBy;

public final class DynamiteModule {

    /* renamed from: a  reason: collision with root package name */
    public static final b f1534a = new d();
    public static final b b = new e();
    public static final b c = new f();
    public static final b d = new g();
    public static final b e = new h();
    public static final b f = new i();
    @GuardedBy("DynamiteModule.class")
    private static Boolean h;
    @GuardedBy("DynamiteModule.class")
    private static a i;
    @GuardedBy("DynamiteModule.class")
    private static b j;
    @GuardedBy("DynamiteModule.class")
    private static String k;
    private static final ThreadLocal<c> l = new ThreadLocal<>();
    private static final b.a m = new c();
    public final Context g;

    @DynamiteApi
    public static class DynamiteLoaderClassLoader {
        @GuardedBy("DynamiteLoaderClassLoader.class")
        public static ClassLoader sClassLoader;
    }

    public static class a extends Exception {
        private a(String str) {
            super(str);
        }

        /* synthetic */ a(String str, byte b) {
            this(str);
        }

        private a(String str, Throwable th) {
            super(str, th);
        }

        /* synthetic */ a(String str, Throwable th, byte b) {
            this(str, th);
        }
    }

    public interface b {

        public interface a {
            int a(Context context, String str);

            int a(Context context, String str, boolean z);
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b  reason: collision with other inner class name */
        public static class C0076b {

            /* renamed from: a  reason: collision with root package name */
            public int f1535a = 0;
            public int b = 0;
            public int c = 0;
        }

        C0076b a(Context context, String str, a aVar);
    }

    static class c {

        /* renamed from: a  reason: collision with root package name */
        public Cursor f1536a;

        private c() {
        }

        /* synthetic */ c(byte b) {
            this();
        }
    }

    static class d implements b.a {

        /* renamed from: a  reason: collision with root package name */
        private final int f1537a;
        private final int b = 0;

        public d(int i) {
            this.f1537a = i;
        }

        public final int a(Context context, String str) {
            return this.f1537a;
        }

        public final int a(Context context, String str, boolean z) {
            return 0;
        }
    }

    private DynamiteModule(Context context) {
        this.g = (Context) ab.a(context);
    }

    public static int a(Context context, String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (declaredField.get((Object) null).equals(str)) {
                return declaredField2.getInt((Object) null);
            }
            String valueOf = String.valueOf(declaredField.get((Object) null));
            StringBuilder sb2 = new StringBuilder(String.valueOf(valueOf).length() + 51 + String.valueOf(str).length());
            sb2.append("Module descriptor id '");
            sb2.append(valueOf);
            sb2.append("' didn't match expected id '");
            sb2.append(str);
            sb2.append("'");
            Log.e("DynamiteModule", sb2.toString());
            return 0;
        } catch (ClassNotFoundException unused) {
            StringBuilder sb3 = new StringBuilder(String.valueOf(str).length() + 45);
            sb3.append("Local module descriptor class for ");
            sb3.append(str);
            sb3.append(" not found.");
            Log.w("DynamiteModule", sb3.toString());
            return 0;
        } catch (Exception e2) {
            String valueOf2 = String.valueOf(e2.getMessage());
            Log.e("DynamiteModule", valueOf2.length() != 0 ? "Failed to load module descriptor class: ".concat(valueOf2) : new String("Failed to load module descriptor class: "));
            return 0;
        }
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:657)
        	at java.util.ArrayList.get(ArrayList.java:433)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:22:0x0050=Splitter:B:22:0x0050, B:17:0x0035=Splitter:B:17:0x0035, B:34:0x0079=Splitter:B:34:0x0079} */
    public static int a(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)
            java.lang.Boolean r1 = h     // Catch:{ all -> 0x00e6 }
            if (r1 != 0) goto L_0x00b3
            android.content.Context r1 = r8.getApplicationContext()     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule$DynamiteLoaderClassLoader> r2 = com.google.android.gms.dynamite.DynamiteModule.DynamiteLoaderClassLoader.class
            java.lang.String r2 = r2.getName()     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            java.lang.String r2 = "sClassLoader"
            java.lang.reflect.Field r2 = r1.getDeclaredField(r2)     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            monitor-enter(r1)     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
            r3 = 0
            java.lang.Object r4 = r2.get(r3)     // Catch:{ all -> 0x0087 }
            java.lang.ClassLoader r4 = (java.lang.ClassLoader) r4     // Catch:{ all -> 0x0087 }
            if (r4 == 0) goto L_0x0038
            java.lang.ClassLoader r2 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            if (r4 != r2) goto L_0x0032
        L_0x002f:
            java.lang.Boolean r2 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x0087 }
            goto L_0x0084
        L_0x0032:
            a((java.lang.ClassLoader) r4)     // Catch:{ a -> 0x0035 }
        L_0x0035:
            java.lang.Boolean r2 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x0087 }
            goto L_0x0084
        L_0x0038:
            java.lang.String r4 = "com.google.android.gms"
            android.content.Context r5 = r8.getApplicationContext()     // Catch:{ all -> 0x0087 }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ all -> 0x0087 }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x0087 }
            if (r4 == 0) goto L_0x0050
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0087 }
            goto L_0x002f
        L_0x0050:
            int r4 = c((android.content.Context) r8, (java.lang.String) r9, (boolean) r10)     // Catch:{ a -> 0x007c }
            java.lang.String r5 = k     // Catch:{ a -> 0x007c }
            if (r5 == 0) goto L_0x0079
            java.lang.String r5 = k     // Catch:{ a -> 0x007c }
            boolean r5 = r5.isEmpty()     // Catch:{ a -> 0x007c }
            if (r5 == 0) goto L_0x0061
            goto L_0x0079
        L_0x0061:
            com.google.android.gms.dynamite.j r5 = new com.google.android.gms.dynamite.j     // Catch:{ a -> 0x007c }
            java.lang.String r6 = k     // Catch:{ a -> 0x007c }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x007c }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x007c }
            a((java.lang.ClassLoader) r5)     // Catch:{ a -> 0x007c }
            r2.set(r3, r5)     // Catch:{ a -> 0x007c }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ a -> 0x007c }
            h = r5     // Catch:{ a -> 0x007c }
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            return r4
        L_0x0079:
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            return r4
        L_0x007c:
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0087 }
            goto L_0x002f
        L_0x0084:
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            r1 = r2
            goto L_0x00b1
        L_0x0087:
            r2 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            throw r2     // Catch:{ ClassNotFoundException | IllegalAccessException | NoSuchFieldException -> 0x008a }
        L_0x008a:
            r1 = move-exception
            java.lang.String r2 = "DynamiteModule"
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00e6 }
            java.lang.String r3 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00e6 }
            int r3 = r3.length()     // Catch:{ all -> 0x00e6 }
            int r3 = r3 + 30
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00e6 }
            r4.<init>(r3)     // Catch:{ all -> 0x00e6 }
            java.lang.String r3 = "Failed to load module via V2: "
            r4.append(r3)     // Catch:{ all -> 0x00e6 }
            r4.append(r1)     // Catch:{ all -> 0x00e6 }
            java.lang.String r1 = r4.toString()     // Catch:{ all -> 0x00e6 }
            android.util.Log.w(r2, r1)     // Catch:{ all -> 0x00e6 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00e6 }
        L_0x00b1:
            h = r1     // Catch:{ all -> 0x00e6 }
        L_0x00b3:
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            boolean r0 = r1.booleanValue()
            if (r0 == 0) goto L_0x00e1
            int r8 = c((android.content.Context) r8, (java.lang.String) r9, (boolean) r10)     // Catch:{ a -> 0x00bf }
            return r8
        L_0x00bf:
            r8 = move-exception
            java.lang.String r9 = "DynamiteModule"
            java.lang.String r10 = "Failed to retrieve remote module version: "
            java.lang.String r8 = r8.getMessage()
            java.lang.String r8 = java.lang.String.valueOf(r8)
            int r0 = r8.length()
            if (r0 == 0) goto L_0x00d7
            java.lang.String r8 = r10.concat(r8)
            goto L_0x00dc
        L_0x00d7:
            java.lang.String r8 = new java.lang.String
            r8.<init>(r10)
        L_0x00dc:
            android.util.Log.w(r9, r8)
            r8 = 0
            return r8
        L_0x00e1:
            int r8 = b((android.content.Context) r8, (java.lang.String) r9, (boolean) r10)
            return r8
        L_0x00e6:
            r8 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.a(android.content.Context, java.lang.String, boolean):int");
    }

    private static Context a(Context context, String str, int i2, Cursor cursor, b bVar) {
        try {
            return (Context) com.google.android.gms.b.b.a(bVar.a(com.google.android.gms.b.b.a(context), str, i2, com.google.android.gms.b.b.a(cursor)));
        } catch (Exception e2) {
            String valueOf = String.valueOf(e2.toString());
            Log.e("DynamiteModule", valueOf.length() != 0 ? "Failed to load DynamiteLoader: ".concat(valueOf) : new String("Failed to load DynamiteLoader: "));
            return null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0075, code lost:
        if (r1.f1536a != null) goto L_0x0077;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00d5, code lost:
        if (r1.f1536a != null) goto L_0x0077;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.dynamite.DynamiteModule a(android.content.Context r10, com.google.android.gms.dynamite.DynamiteModule.b r11, java.lang.String r12) {
        /*
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r0 = l
            java.lang.Object r0 = r0.get()
            com.google.android.gms.dynamite.DynamiteModule$c r0 = (com.google.android.gms.dynamite.DynamiteModule.c) r0
            com.google.android.gms.dynamite.DynamiteModule$c r1 = new com.google.android.gms.dynamite.DynamiteModule$c
            r2 = 0
            r1.<init>(r2)
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r3 = l
            r3.set(r1)
            com.google.android.gms.dynamite.DynamiteModule$b$a r3 = m     // Catch:{ all -> 0x0125 }
            com.google.android.gms.dynamite.DynamiteModule$b$b r3 = r11.a(r10, r12, r3)     // Catch:{ all -> 0x0125 }
            int r4 = r3.f1535a     // Catch:{ all -> 0x0125 }
            int r5 = r3.b     // Catch:{ all -> 0x0125 }
            java.lang.String r6 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x0125 }
            int r6 = r6.length()     // Catch:{ all -> 0x0125 }
            int r6 = r6 + 68
            java.lang.String r7 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x0125 }
            int r7 = r7.length()     // Catch:{ all -> 0x0125 }
            int r6 = r6 + r7
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x0125 }
            r7.<init>(r6)     // Catch:{ all -> 0x0125 }
            java.lang.String r6 = "Considering local module "
            r7.append(r6)     // Catch:{ all -> 0x0125 }
            r7.append(r12)     // Catch:{ all -> 0x0125 }
            java.lang.String r6 = ":"
            r7.append(r6)     // Catch:{ all -> 0x0125 }
            r7.append(r4)     // Catch:{ all -> 0x0125 }
            java.lang.String r4 = " and remote module "
            r7.append(r4)     // Catch:{ all -> 0x0125 }
            r7.append(r12)     // Catch:{ all -> 0x0125 }
            java.lang.String r4 = ":"
            r7.append(r4)     // Catch:{ all -> 0x0125 }
            r7.append(r5)     // Catch:{ all -> 0x0125 }
            int r4 = r3.c     // Catch:{ all -> 0x0125 }
            if (r4 == 0) goto L_0x00fb
            int r4 = r3.c     // Catch:{ all -> 0x0125 }
            r5 = -1
            if (r4 != r5) goto L_0x0062
            int r4 = r3.f1535a     // Catch:{ all -> 0x0125 }
            if (r4 == 0) goto L_0x00fb
        L_0x0062:
            int r4 = r3.c     // Catch:{ all -> 0x0125 }
            r6 = 1
            if (r4 != r6) goto L_0x006b
            int r4 = r3.b     // Catch:{ all -> 0x0125 }
            if (r4 == 0) goto L_0x00fb
        L_0x006b:
            int r4 = r3.c     // Catch:{ all -> 0x0125 }
            if (r4 != r5) goto L_0x0082
            com.google.android.gms.dynamite.DynamiteModule r10 = c(r10, r12)     // Catch:{ all -> 0x0125 }
            android.database.Cursor r11 = r1.f1536a
            if (r11 == 0) goto L_0x007c
        L_0x0077:
            android.database.Cursor r11 = r1.f1536a
            r11.close()
        L_0x007c:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = l
            r11.set(r0)
            return r10
        L_0x0082:
            int r4 = r3.c     // Catch:{ all -> 0x0125 }
            if (r4 != r6) goto L_0x00e0
            int r4 = r3.b     // Catch:{ a -> 0x009b }
            com.google.android.gms.dynamite.DynamiteModule r4 = a((android.content.Context) r10, (java.lang.String) r12, (int) r4)     // Catch:{ a -> 0x009b }
            android.database.Cursor r10 = r1.f1536a
            if (r10 == 0) goto L_0x0095
            android.database.Cursor r10 = r1.f1536a
            r10.close()
        L_0x0095:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = l
            r10.set(r0)
            return r4
        L_0x009b:
            r4 = move-exception
            java.lang.String r6 = "DynamiteModule"
            java.lang.String r7 = "Failed to load remote module: "
            java.lang.String r8 = r4.getMessage()     // Catch:{ all -> 0x0125 }
            java.lang.String r8 = java.lang.String.valueOf(r8)     // Catch:{ all -> 0x0125 }
            int r9 = r8.length()     // Catch:{ all -> 0x0125 }
            if (r9 == 0) goto L_0x00b3
            java.lang.String r7 = r7.concat(r8)     // Catch:{ all -> 0x0125 }
            goto L_0x00b9
        L_0x00b3:
            java.lang.String r8 = new java.lang.String     // Catch:{ all -> 0x0125 }
            r8.<init>(r7)     // Catch:{ all -> 0x0125 }
            r7 = r8
        L_0x00b9:
            android.util.Log.w(r6, r7)     // Catch:{ all -> 0x0125 }
            int r6 = r3.f1535a     // Catch:{ all -> 0x0125 }
            if (r6 == 0) goto L_0x00d8
            com.google.android.gms.dynamite.DynamiteModule$d r6 = new com.google.android.gms.dynamite.DynamiteModule$d     // Catch:{ all -> 0x0125 }
            int r3 = r3.f1535a     // Catch:{ all -> 0x0125 }
            r6.<init>(r3)     // Catch:{ all -> 0x0125 }
            com.google.android.gms.dynamite.DynamiteModule$b$b r11 = r11.a(r10, r12, r6)     // Catch:{ all -> 0x0125 }
            int r11 = r11.c     // Catch:{ all -> 0x0125 }
            if (r11 != r5) goto L_0x00d8
            com.google.android.gms.dynamite.DynamiteModule r10 = c(r10, r12)     // Catch:{ all -> 0x0125 }
            android.database.Cursor r11 = r1.f1536a
            if (r11 == 0) goto L_0x007c
            goto L_0x0077
        L_0x00d8:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0125 }
            java.lang.String r11 = "Remote load failed. No local fallback found."
            r10.<init>(r11, r4, r2)     // Catch:{ all -> 0x0125 }
            throw r10     // Catch:{ all -> 0x0125 }
        L_0x00e0:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0125 }
            int r11 = r3.c     // Catch:{ all -> 0x0125 }
            r12 = 47
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0125 }
            r3.<init>(r12)     // Catch:{ all -> 0x0125 }
            java.lang.String r12 = "VersionPolicy returned invalid code:"
            r3.append(r12)     // Catch:{ all -> 0x0125 }
            r3.append(r11)     // Catch:{ all -> 0x0125 }
            java.lang.String r11 = r3.toString()     // Catch:{ all -> 0x0125 }
            r10.<init>((java.lang.String) r11, (byte) r2)     // Catch:{ all -> 0x0125 }
            throw r10     // Catch:{ all -> 0x0125 }
        L_0x00fb:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0125 }
            int r11 = r3.f1535a     // Catch:{ all -> 0x0125 }
            int r12 = r3.b     // Catch:{ all -> 0x0125 }
            r3 = 91
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0125 }
            r4.<init>(r3)     // Catch:{ all -> 0x0125 }
            java.lang.String r3 = "No acceptable module found. Local version is "
            r4.append(r3)     // Catch:{ all -> 0x0125 }
            r4.append(r11)     // Catch:{ all -> 0x0125 }
            java.lang.String r11 = " and remote version is "
            r4.append(r11)     // Catch:{ all -> 0x0125 }
            r4.append(r12)     // Catch:{ all -> 0x0125 }
            java.lang.String r11 = "."
            r4.append(r11)     // Catch:{ all -> 0x0125 }
            java.lang.String r11 = r4.toString()     // Catch:{ all -> 0x0125 }
            r10.<init>((java.lang.String) r11, (byte) r2)     // Catch:{ all -> 0x0125 }
            throw r10     // Catch:{ all -> 0x0125 }
        L_0x0125:
            r10 = move-exception
            android.database.Cursor r11 = r1.f1536a
            if (r11 == 0) goto L_0x012f
            android.database.Cursor r11 = r1.f1536a
            r11.close()
        L_0x012f:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = l
            r11.set(r0)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.a(android.content.Context, com.google.android.gms.dynamite.DynamiteModule$b, java.lang.String):com.google.android.gms.dynamite.DynamiteModule");
    }

    private static DynamiteModule a(Context context, String str, int i2) {
        Boolean bool;
        synchronized (DynamiteModule.class) {
            bool = h;
        }
        if (bool != null) {
            return bool.booleanValue() ? c(context, str, i2) : b(context, str, i2);
        }
        throw new a("Failed to determine which loading route to use.", (byte) 0);
    }

    private static a a(Context context) {
        synchronized (DynamiteModule.class) {
            if (i != null) {
                a aVar = i;
                return aVar;
            } else if (e.getInstance().isGooglePlayServicesAvailable(context) != 0) {
                return null;
            } else {
                try {
                    a a2 = a.C0077a.a((IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance());
                    if (a2 != null) {
                        i = a2;
                        return a2;
                    }
                } catch (Exception e2) {
                    String valueOf = String.valueOf(e2.getMessage());
                    Log.e("DynamiteModule", valueOf.length() != 0 ? "Failed to load IDynamiteLoader from GmsCore: ".concat(valueOf) : new String("Failed to load IDynamiteLoader from GmsCore: "));
                }
            }
        }
        return null;
    }

    @GuardedBy("DynamiteModule.class")
    private static void a(ClassLoader classLoader) {
        try {
            j = b.a.a((IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]));
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
            throw new a("Failed to instantiate dynamite loader", e2, (byte) 0);
        }
    }

    public static int b(Context context, String str) {
        return a(context, str, false);
    }

    private static int b(Context context, String str, boolean z) {
        a a2 = a(context);
        if (a2 == null) {
            return 0;
        }
        try {
            return a2.a(com.google.android.gms.b.b.a(context), str, z);
        } catch (RemoteException e2) {
            String valueOf = String.valueOf(e2.getMessage());
            Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to retrieve remote module version: ".concat(valueOf) : new String("Failed to retrieve remote module version: "));
            return 0;
        }
    }

    private static DynamiteModule b(Context context, String str, int i2) {
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i2);
        a a2 = a(context);
        if (a2 != null) {
            try {
                com.google.android.gms.b.a a3 = a2.a(com.google.android.gms.b.b.a(context), str, i2);
                if (com.google.android.gms.b.b.a(a3) != null) {
                    return new DynamiteModule((Context) com.google.android.gms.b.b.a(a3));
                }
                throw new a("Failed to load remote module.", (byte) 0);
            } catch (RemoteException e2) {
                throw new a("Failed to load remote module.", e2, (byte) 0);
            }
        } else {
            throw new a("Failed to create IDynamiteLoader.", (byte) 0);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:51:0x00a2  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static int c(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            r0 = 0
            r1 = 0
            android.content.ContentResolver r2 = r8.getContentResolver()     // Catch:{ Exception -> 0x0092 }
            if (r10 == 0) goto L_0x000b
            java.lang.String r8 = "api_force_staging"
            goto L_0x000d
        L_0x000b:
            java.lang.String r8 = "api"
        L_0x000d:
            java.lang.String r10 = java.lang.String.valueOf(r8)     // Catch:{ Exception -> 0x0092 }
            int r10 = r10.length()     // Catch:{ Exception -> 0x0092 }
            int r10 = r10 + 42
            java.lang.String r3 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x0092 }
            int r3 = r3.length()     // Catch:{ Exception -> 0x0092 }
            int r10 = r10 + r3
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0092 }
            r3.<init>(r10)     // Catch:{ Exception -> 0x0092 }
            java.lang.String r10 = "content://com.google.android.gms.chimera/"
            r3.append(r10)     // Catch:{ Exception -> 0x0092 }
            r3.append(r8)     // Catch:{ Exception -> 0x0092 }
            java.lang.String r8 = "/"
            r3.append(r8)     // Catch:{ Exception -> 0x0092 }
            r3.append(r9)     // Catch:{ Exception -> 0x0092 }
            java.lang.String r8 = r3.toString()     // Catch:{ Exception -> 0x0092 }
            android.net.Uri r3 = android.net.Uri.parse(r8)     // Catch:{ Exception -> 0x0092 }
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            android.database.Cursor r8 = r2.query(r3, r4, r5, r6, r7)     // Catch:{ Exception -> 0x0092 }
            if (r8 == 0) goto L_0x0081
            boolean r9 = r8.moveToFirst()     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            if (r9 == 0) goto L_0x0081
            int r9 = r8.getInt(r1)     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            if (r9 <= 0) goto L_0x0073
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r10 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r10)     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            r2 = 2
            java.lang.String r2 = r8.getString(r2)     // Catch:{ all -> 0x0070 }
            k = r2     // Catch:{ all -> 0x0070 }
            monitor-exit(r10)     // Catch:{ all -> 0x0070 }
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = l     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            java.lang.Object r10 = r10.get()     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            com.google.android.gms.dynamite.DynamiteModule$c r10 = (com.google.android.gms.dynamite.DynamiteModule.c) r10     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            if (r10 == 0) goto L_0x0073
            android.database.Cursor r2 = r10.f1536a     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            if (r2 != 0) goto L_0x0073
            r10.f1536a = r8     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            r8 = r0
            goto L_0x0073
        L_0x0070:
            r9 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0070 }
            throw r9     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
        L_0x0073:
            if (r8 == 0) goto L_0x0078
            r8.close()
        L_0x0078:
            return r9
        L_0x0079:
            r9 = move-exception
            r0 = r8
            r8 = r9
            goto L_0x00a0
        L_0x007d:
            r9 = move-exception
            r0 = r8
            r8 = r9
            goto L_0x0093
        L_0x0081:
            java.lang.String r9 = "DynamiteModule"
            java.lang.String r10 = "Failed to retrieve remote module version."
            android.util.Log.w(r9, r10)     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            java.lang.String r10 = "Failed to connect to dynamite module ContentResolver."
            r9.<init>((java.lang.String) r10, (byte) r1)     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
            throw r9     // Catch:{ Exception -> 0x007d, all -> 0x0079 }
        L_0x0090:
            r8 = move-exception
            goto L_0x00a0
        L_0x0092:
            r8 = move-exception
        L_0x0093:
            boolean r9 = r8 instanceof com.google.android.gms.dynamite.DynamiteModule.a     // Catch:{ all -> 0x0090 }
            if (r9 == 0) goto L_0x0098
            throw r8     // Catch:{ all -> 0x0090 }
        L_0x0098:
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0090 }
            java.lang.String r10 = "V2 version check failed"
            r9.<init>(r10, r8, r1)     // Catch:{ all -> 0x0090 }
            throw r9     // Catch:{ all -> 0x0090 }
        L_0x00a0:
            if (r0 == 0) goto L_0x00a5
            r0.close()
        L_0x00a5:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.c(android.content.Context, java.lang.String, boolean):int");
    }

    private static DynamiteModule c(Context context, String str) {
        String valueOf = String.valueOf(str);
        if (valueOf.length() != 0) {
            "Selected local version of ".concat(valueOf);
        } else {
            new String("Selected local version of ");
        }
        return new DynamiteModule(context.getApplicationContext());
    }

    private static DynamiteModule c(Context context, String str, int i2) {
        b bVar;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i2);
        synchronized (DynamiteModule.class) {
            bVar = j;
        }
        if (bVar != null) {
            c cVar = l.get();
            if (cVar == null || cVar.f1536a == null) {
                throw new a("No result cursor", (byte) 0);
            }
            Context a2 = a(context.getApplicationContext(), str, i2, cVar.f1536a, bVar);
            if (a2 != null) {
                return new DynamiteModule(a2);
            }
            throw new a("Failed to get module context", (byte) 0);
        }
        throw new a("DynamiteLoaderV2 was not cached.", (byte) 0);
    }

    public final IBinder a(String str) {
        try {
            return (IBinder) this.g.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e2) {
            String valueOf = String.valueOf(str);
            throw new a(valueOf.length() != 0 ? "Failed to instantiate module class: ".concat(valueOf) : new String("Failed to instantiate module class: "), e2, (byte) 0);
        }
    }
}
