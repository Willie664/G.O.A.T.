package com.google.android.gms.dynamite;

import android.content.Context;
import com.google.android.gms.dynamite.DynamiteModule;

final class e implements DynamiteModule.b {
    e() {
    }

    public final DynamiteModule.b.C0076b a(Context context, String str, DynamiteModule.b.a aVar) {
        DynamiteModule.b.C0076b bVar = new DynamiteModule.b.C0076b();
        bVar.f1535a = aVar.a(context, str);
        if (bVar.f1535a != 0) {
            bVar.c = -1;
        } else {
            bVar.b = aVar.a(context, str, true);
            if (bVar.b != 0) {
                bVar.c = 1;
            }
        }
        return bVar;
    }
}
