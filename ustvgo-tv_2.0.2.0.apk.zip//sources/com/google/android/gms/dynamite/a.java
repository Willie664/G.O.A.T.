package com.google.android.gms.dynamite;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.b.a;
import com.google.android.gms.internal.c.b;
import com.google.android.gms.internal.c.c;

public interface a extends IInterface {

    /* renamed from: com.google.android.gms.dynamite.a$a  reason: collision with other inner class name */
    public static abstract class C0077a extends b implements a {

        /* renamed from: com.google.android.gms.dynamite.a$a$a  reason: collision with other inner class name */
        public static class C0078a extends com.google.android.gms.internal.c.a implements a {
            C0078a(IBinder iBinder) {
                super(iBinder, "com.google.android.gms.dynamite.IDynamiteLoader");
            }

            public final int a(com.google.android.gms.b.a aVar, String str) {
                Parcel d = d();
                c.a(d, (IInterface) aVar);
                d.writeString(str);
                Parcel a2 = a(1, d);
                int readInt = a2.readInt();
                a2.recycle();
                return readInt;
            }

            public final int a(com.google.android.gms.b.a aVar, String str, boolean z) {
                Parcel d = d();
                c.a(d, (IInterface) aVar);
                d.writeString(str);
                c.a(d, z);
                Parcel a2 = a(3, d);
                int readInt = a2.readInt();
                a2.recycle();
                return readInt;
            }

            public final com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, int i) {
                Parcel d = d();
                c.a(d, (IInterface) aVar);
                d.writeString(str);
                d.writeInt(i);
                Parcel a2 = a(2, d);
                com.google.android.gms.b.a a3 = a.C0061a.a(a2.readStrongBinder());
                a2.recycle();
                return a3;
            }
        }

        public static a a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
            return queryLocalInterface instanceof a ? (a) queryLocalInterface : new C0078a(iBinder);
        }

        public final boolean a(int i, Parcel parcel, Parcel parcel2) {
            int i2;
            switch (i) {
                case 1:
                    i2 = a(a.C0061a.a(parcel.readStrongBinder()), parcel.readString());
                    break;
                case 2:
                    com.google.android.gms.b.a a2 = a(a.C0061a.a(parcel.readStrongBinder()), parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    c.a(parcel2, (IInterface) a2);
                    return true;
                case 3:
                    i2 = a(a.C0061a.a(parcel.readStrongBinder()), parcel.readString(), c.a(parcel));
                    break;
                default:
                    return false;
            }
            parcel2.writeNoException();
            parcel2.writeInt(i2);
            return true;
        }
    }

    int a(com.google.android.gms.b.a aVar, String str);

    int a(com.google.android.gms.b.a aVar, String str, boolean z);

    com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, int i);
}
