package com.google.android.gms.dynamite;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.b.a;
import com.google.android.gms.internal.c.c;

public interface b extends IInterface {

    public static abstract class a extends com.google.android.gms.internal.c.b implements b {

        /* renamed from: com.google.android.gms.dynamite.b$a$a  reason: collision with other inner class name */
        public static class C0079a extends com.google.android.gms.internal.c.a implements b {
            C0079a(IBinder iBinder) {
                super(iBinder, "com.google.android.gms.dynamite.IDynamiteLoaderV2");
            }

            public final com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, int i, com.google.android.gms.b.a aVar2) {
                Parcel d = d();
                c.a(d, (IInterface) aVar);
                d.writeString(str);
                d.writeInt(i);
                c.a(d, (IInterface) aVar2);
                Parcel a2 = a(2, d);
                com.google.android.gms.b.a a3 = a.C0061a.a(a2.readStrongBinder());
                a2.recycle();
                return a3;
            }

            public final com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, byte[] bArr) {
                Parcel d = d();
                c.a(d, (IInterface) aVar);
                d.writeString(str);
                d.writeByteArray(bArr);
                Parcel a2 = a(1, d);
                com.google.android.gms.b.a a3 = a.C0061a.a(a2.readStrongBinder());
                a2.recycle();
                return a3;
            }
        }

        public static b a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
            return queryLocalInterface instanceof b ? (b) queryLocalInterface : new C0079a(iBinder);
        }

        public final boolean a(int i, Parcel parcel, Parcel parcel2) {
            com.google.android.gms.b.a aVar;
            switch (i) {
                case 1:
                    aVar = a(a.C0061a.a(parcel.readStrongBinder()), parcel.readString(), parcel.createByteArray());
                    break;
                case 2:
                    aVar = a(a.C0061a.a(parcel.readStrongBinder()), parcel.readString(), parcel.readInt(), a.C0061a.a(parcel.readStrongBinder()));
                    break;
                default:
                    return false;
            }
            parcel2.writeNoException();
            c.a(parcel2, (IInterface) aVar);
            return true;
        }
    }

    com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, int i, com.google.android.gms.b.a aVar2);

    com.google.android.gms.b.a a(com.google.android.gms.b.a aVar, String str, byte[] bArr);
}
