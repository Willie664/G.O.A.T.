package com.google.android.gms.location;

import android.location.Location;
import android.os.IInterface;

public interface af extends IInterface {
    void a(Location location);
}
