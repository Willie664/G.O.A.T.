package com.google.android.gms.location.places;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Arrays;

public class PlaceReport extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<PlaceReport> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    private final int f2615a;
    private final String b;
    private final String c;
    private final String d;

    PlaceReport(int i, String str, String str2, String str3) {
        this.f2615a = i;
        this.b = str;
        this.c = str2;
        this.d = str3;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof PlaceReport)) {
            return false;
        }
        PlaceReport placeReport = (PlaceReport) obj;
        return aa.a(this.b, placeReport.b) && aa.a(this.c, placeReport.c) && aa.a(this.d, placeReport.d);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.b, this.c, this.d});
    }

    public String toString() {
        aa.a a2 = aa.a(this);
        a2.a("placeId", this.b);
        a2.a("tag", this.c);
        if (!"unknown".equals(this.d)) {
            a2.a("source", this.d);
        }
        return a2.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.f2615a);
        b.a(parcel, 2, this.b);
        b.a(parcel, 3, this.c);
        b.a(parcel, 4, this.d);
        b.b(parcel, a2);
    }
}
