package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

public final class j implements Parcelable.Creator<zzae> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a2 = a.a(parcel);
        String str = "";
        String str2 = "";
        String str3 = "";
        while (parcel.dataPosition() < a2) {
            int readInt = parcel.readInt();
            int i = 65535 & readInt;
            if (i != 5) {
                switch (i) {
                    case 1:
                        str2 = a.k(parcel, readInt);
                        break;
                    case 2:
                        str3 = a.k(parcel, readInt);
                        break;
                    default:
                        a.b(parcel, readInt);
                        break;
                }
            } else {
                str = a.k(parcel, readInt);
            }
        }
        a.u(parcel, a2);
        return new zzae(str, str2, str3);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzae[i];
    }
}
