package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Arrays;
import java.util.Comparator;

public class DetectedActivity extends AbstractSafeParcelable {
    public static final Parcelable.Creator<DetectedActivity> CREATOR = new w();
    private static final Comparator<DetectedActivity> b = new v();
    private static final int[] c = {9, 10};
    private static final int[] d = {0, 1, 2, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 16, 17, 18, 19};
    private static final int[] e = {0, 1, 2, 3, 7, 8, 16, 17};

    /* renamed from: a  reason: collision with root package name */
    int f2606a;
    private int f;

    public DetectedActivity(int i, int i2) {
        this.f = i;
        this.f2606a = i2;
    }

    public static void a(int i) {
        boolean z = false;
        for (int i2 : e) {
            if (i2 == i) {
                z = true;
            }
        }
        if (!z) {
            StringBuilder sb = new StringBuilder(81);
            sb.append(i);
            sb.append(" is not a valid DetectedActivity supported by Activity Transition API.");
            Log.w("DetectedActivity", sb.toString());
        }
    }

    public final int a() {
        int i = this.f;
        if (i > 19 || i < 0) {
            return 4;
        }
        return i;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            DetectedActivity detectedActivity = (DetectedActivity) obj;
            return this.f == detectedActivity.f && this.f2606a == detectedActivity.f2606a;
        }
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f), Integer.valueOf(this.f2606a)});
    }

    public String toString() {
        String str;
        int a2 = a();
        switch (a2) {
            case 0:
                str = "IN_VEHICLE";
                break;
            case 1:
                str = "ON_BICYCLE";
                break;
            case 2:
                str = "ON_FOOT";
                break;
            case 3:
                str = "STILL";
                break;
            case 4:
                str = "UNKNOWN";
                break;
            case 5:
                str = "TILTING";
                break;
            default:
                switch (a2) {
                    case 7:
                        str = "WALKING";
                        break;
                    case 8:
                        str = "RUNNING";
                        break;
                    default:
                        switch (a2) {
                            case 16:
                                str = "IN_ROAD_VEHICLE";
                                break;
                            case 17:
                                str = "IN_RAIL_VEHICLE";
                                break;
                            case 18:
                                str = "IN_TWO_WHEELER_VEHICLE";
                                break;
                            case 19:
                                str = "IN_FOUR_WHEELER_VEHICLE";
                                break;
                            default:
                                str = Integer.toString(a2);
                                break;
                        }
                }
        }
        int i = this.f2606a;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 48);
        sb.append("DetectedActivity [type=");
        sb.append(str);
        sb.append(", confidence=");
        sb.append(i);
        sb.append("]");
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.f);
        b.b(parcel, 2, this.f2606a);
        b.b(parcel, a2);
    }
}
