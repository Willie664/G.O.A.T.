package com.google.android.gms.location;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.internal.g;
import com.google.android.gms.internal.location.r;

final class i extends a.C0063a<r, Object> {
    i() {
    }

    public final /* synthetic */ a.f a(Context context, Looper looper, g gVar, Object obj, GoogleApiClient.b bVar, GoogleApiClient.c cVar) {
        return new r(context, looper, bVar, cVar, "locationServices", gVar);
    }
}
