package com.google.android.gms.location;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.internal.location.s;

public class aa extends s implements z {
    public static z a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.IDeviceOrientationListener");
        return queryLocalInterface instanceof z ? (z) queryLocalInterface : new ab(iBinder);
    }

    public final boolean a(int i, Parcel parcel) {
        throw new NoSuchMethodError();
    }
}
