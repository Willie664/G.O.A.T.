package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Collections;
import java.util.List;

public class ActivityTransitionResult extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ActivityTransitionResult> CREATOR = new u();

    /* renamed from: a  reason: collision with root package name */
    private final List<ActivityTransitionEvent> f2605a;

    public ActivityTransitionResult(List<ActivityTransitionEvent> list) {
        ab.a(list, (Object) "transitionEvents list can't be null.");
        if (!list.isEmpty()) {
            for (int i = 1; i < list.size(); i++) {
                ab.b(list.get(i).f2603a >= list.get(i + -1).f2603a);
            }
        }
        this.f2605a = Collections.unmodifiableList(list);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.f2605a.equals(((ActivityTransitionResult) obj).f2605a);
    }

    public int hashCode() {
        return this.f2605a.hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.f2605a);
        b.b(parcel, a2);
    }
}
