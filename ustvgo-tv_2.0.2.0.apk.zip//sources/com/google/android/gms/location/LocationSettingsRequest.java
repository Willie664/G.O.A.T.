package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Collections;
import java.util.List;

public final class LocationSettingsRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<LocationSettingsRequest> CREATOR = new k();

    /* renamed from: a  reason: collision with root package name */
    private final List<LocationRequest> f2611a;
    private final boolean b;
    private final boolean c;
    private zzae d;

    LocationSettingsRequest(List<LocationRequest> list, boolean z, boolean z2, zzae zzae) {
        this.f2611a = list;
        this.b = z;
        this.c = z2;
        this.d = zzae;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, Collections.unmodifiableList(this.f2611a));
        b.a(parcel, 2, this.b);
        b.a(parcel, 3, this.c);
        b.a(parcel, 5, (Parcelable) this.d, i);
        b.b(parcel, a2);
    }
}
