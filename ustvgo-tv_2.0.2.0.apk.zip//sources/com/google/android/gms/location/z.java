package com.google.android.gms.location;

import android.os.IInterface;

public interface z extends IInterface {
}
