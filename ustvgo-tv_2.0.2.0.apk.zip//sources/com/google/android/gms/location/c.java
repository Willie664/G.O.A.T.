package com.google.android.gms.location;

import android.location.Location;

public interface c {
    void a(Location location);
}
