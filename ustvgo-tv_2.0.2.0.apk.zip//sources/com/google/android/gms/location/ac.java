package com.google.android.gms.location;

import android.os.IInterface;

public interface ac extends IInterface {
    void a(LocationAvailability locationAvailability);

    void a(LocationResult locationResult);
}
