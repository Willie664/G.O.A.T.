package com.google.android.gms.location;

import android.location.Location;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.location.a;
import com.google.android.gms.internal.location.y;

public final class ah extends a implements af {
    ah(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.location.ILocationListener");
    }

    public final void a(Location location) {
        Parcel a2 = a();
        y.a(a2, (Parcelable) location);
        b(1, a2);
    }
}
