package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;

public final class LocationSettingsResult extends AbstractSafeParcelable implements i {
    public static final Parcelable.Creator<LocationSettingsResult> CREATOR = new l();

    /* renamed from: a  reason: collision with root package name */
    private final Status f2612a;
    private final LocationSettingsStates b;

    public LocationSettingsResult(Status status, LocationSettingsStates locationSettingsStates) {
        this.f2612a = status;
        this.b = locationSettingsStates;
    }

    public final Status a() {
        return this.f2612a;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.a(parcel, 1, (Parcelable) this.f2612a, i);
        b.a(parcel, 2, (Parcelable) this.b, i);
        b.b(parcel, a2);
    }
}
