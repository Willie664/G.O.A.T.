package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Arrays;

public final class LocationAvailability extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<LocationAvailability> CREATOR = new f();
    @Deprecated

    /* renamed from: a  reason: collision with root package name */
    private int f2608a;
    @Deprecated
    private int b;
    private long c;
    private int d;
    private zzaj[] e;

    LocationAvailability(int i, int i2, int i3, long j, zzaj[] zzajArr) {
        this.d = i;
        this.f2608a = i2;
        this.b = i3;
        this.c = j;
        this.e = zzajArr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            LocationAvailability locationAvailability = (LocationAvailability) obj;
            return this.f2608a == locationAvailability.f2608a && this.b == locationAvailability.b && this.c == locationAvailability.c && this.d == locationAvailability.d && Arrays.equals(this.e, locationAvailability.e);
        }
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.d), Integer.valueOf(this.f2608a), Integer.valueOf(this.b), Long.valueOf(this.c), this.e});
    }

    public final String toString() {
        boolean z = this.d < 1000;
        StringBuilder sb = new StringBuilder(48);
        sb.append("LocationAvailability[isLocationAvailable: ");
        sb.append(z);
        sb.append("]");
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.f2608a);
        b.b(parcel, 2, this.b);
        b.a(parcel, 3, this.c);
        b.b(parcel, 4, this.d);
        b.a(parcel, 5, (T[]) this.e, i);
        b.b(parcel, a2);
    }
}
