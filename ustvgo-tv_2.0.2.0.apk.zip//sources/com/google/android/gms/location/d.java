package com.google.android.gms.location;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.api.internal.c;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.location.ae;
import com.google.android.gms.internal.location.e;
import com.google.android.gms.internal.location.r;
import com.google.android.gms.internal.location.x;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final com.google.android.gms.common.api.a<Object> f2614a = new com.google.android.gms.common.api.a<>("LocationServices.API", f, e);
    @Deprecated
    public static final a b = new ae();
    @Deprecated
    public static final b c = new e();
    @Deprecated
    public static final e d = new x();
    private static final a.g<r> e = new a.g<>();
    private static final a.C0063a<r, Object> f = new i();

    public static abstract class a<R extends i> extends c.a<R, r> {
        public a(GoogleApiClient googleApiClient) {
            super(d.f2614a, googleApiClient);
        }
    }

    public static r a(GoogleApiClient googleApiClient) {
        boolean z = false;
        ab.b(googleApiClient != null, "GoogleApiClient parameter is required.");
        r rVar = (r) googleApiClient.a(e);
        if (rVar != null) {
            z = true;
        }
        ab.a(z, (Object) "GoogleApiClient is not configured to use the LocationServices.API Api. Pass thisinto GoogleApiClient.Builder#addApi() to use this feature.");
        return rVar;
    }
}
