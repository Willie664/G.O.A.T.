package com.google.android.gms.location;

@Deprecated
public interface e {
}
