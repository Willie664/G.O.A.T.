package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ClientIdentity;
import com.google.android.gms.common.internal.aa;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class ActivityTransitionRequest extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ActivityTransitionRequest> CREATOR = new t();

    /* renamed from: a  reason: collision with root package name */
    public static final Comparator<ActivityTransition> f2604a = new s();
    private final List<ActivityTransition> b;
    private final String c;
    private final List<ClientIdentity> d;

    public ActivityTransitionRequest(List<ActivityTransition> list, String str, List<ClientIdentity> list2) {
        ab.a(list, (Object) "transitions can't be null");
        ab.b(list.size() > 0, "transitions can't be empty.");
        TreeSet treeSet = new TreeSet(f2604a);
        for (ActivityTransition next : list) {
            ab.b(treeSet.add(next), String.format("Found duplicated transition: %s.", new Object[]{next}));
        }
        this.b = Collections.unmodifiableList(list);
        this.c = str;
        this.d = list2 == null ? Collections.emptyList() : Collections.unmodifiableList(list2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            ActivityTransitionRequest activityTransitionRequest = (ActivityTransitionRequest) obj;
            return aa.a(this.b, activityTransitionRequest.b) && aa.a(this.c, activityTransitionRequest.c) && aa.a(this.d, activityTransitionRequest.d);
        }
    }

    public int hashCode() {
        int i = 0;
        int hashCode = ((this.b.hashCode() * 31) + (this.c != null ? this.c.hashCode() : 0)) * 31;
        if (this.d != null) {
            i = this.d.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        String valueOf = String.valueOf(this.b);
        String str = this.c;
        String valueOf2 = String.valueOf(this.d);
        StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 61 + String.valueOf(str).length() + String.valueOf(valueOf2).length());
        sb.append("ActivityTransitionRequest [mTransitions=");
        sb.append(valueOf);
        sb.append(", mTag='");
        sb.append(str);
        sb.append('\'');
        sb.append(", mClients=");
        sb.append(valueOf2);
        sb.append(']');
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.b);
        b.a(parcel, 2, this.c);
        b.b(parcel, 3, this.d);
        b.b(parcel, a2);
    }
}
