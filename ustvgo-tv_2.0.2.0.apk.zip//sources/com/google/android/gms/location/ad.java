package com.google.android.gms.location;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.internal.location.s;
import com.google.android.gms.internal.location.y;

public abstract class ad extends s implements ac {
    public static ac a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.ILocationCallback");
        return queryLocalInterface instanceof ac ? (ac) queryLocalInterface : new ae(iBinder);
    }

    public final boolean a(int i, Parcel parcel) {
        switch (i) {
            case 1:
                a((LocationResult) y.a(parcel, LocationResult.CREATOR));
                return true;
            case 2:
                a((LocationAvailability) y.a(parcel, LocationAvailability.CREATOR));
                return true;
            default:
                return false;
        }
    }
}
