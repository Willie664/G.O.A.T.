package com.google.android.gms.location;

import android.os.IBinder;
import com.google.android.gms.internal.location.a;

public final class ab extends a implements z {
    ab(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.location.IDeviceOrientationListener");
    }
}
