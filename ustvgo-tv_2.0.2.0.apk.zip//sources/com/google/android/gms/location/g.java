package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.ActivityChooserView;
import com.google.android.gms.common.internal.safeparcel.a;

public final class g implements Parcelable.Creator<LocationRequest> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Parcel parcel2 = parcel;
        int a2 = a.a(parcel);
        long j = 3600000;
        long j2 = 600000;
        long j3 = Long.MAX_VALUE;
        long j4 = 0;
        int i = 102;
        boolean z = false;
        int i2 = ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        float f = 0.0f;
        while (parcel.dataPosition() < a2) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = a.d(parcel2, readInt);
                    break;
                case 2:
                    j = a.f(parcel2, readInt);
                    break;
                case 3:
                    j2 = a.f(parcel2, readInt);
                    break;
                case 4:
                    z = a.c(parcel2, readInt);
                    break;
                case 5:
                    j3 = a.f(parcel2, readInt);
                    break;
                case 6:
                    i2 = a.d(parcel2, readInt);
                    break;
                case 7:
                    f = a.h(parcel2, readInt);
                    break;
                case 8:
                    j4 = a.f(parcel2, readInt);
                    break;
                default:
                    a.b(parcel2, readInt);
                    break;
            }
        }
        a.u(parcel2, a2);
        return new LocationRequest(i, j, j2, z, j3, i2, f, j4);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new LocationRequest[i];
    }
}
