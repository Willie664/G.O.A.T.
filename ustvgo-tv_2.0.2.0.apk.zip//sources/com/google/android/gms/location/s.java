package com.google.android.gms.location;

import java.util.Comparator;

final class s implements Comparator<ActivityTransition> {
    s() {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        ActivityTransition activityTransition = (ActivityTransition) obj;
        ActivityTransition activityTransition2 = (ActivityTransition) obj2;
        int i = activityTransition.f2602a;
        int i2 = activityTransition2.f2602a;
        if (i != i2) {
            return i < i2 ? -1 : 1;
        }
        int i3 = activityTransition.b;
        int i4 = activityTransition2.b;
        if (i3 == i4) {
            return 0;
        }
        return i3 < i4 ? -1 : 1;
    }
}
