package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v7.widget.ActivityChooserView;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Arrays;

public final class LocationRequest extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<LocationRequest> CREATOR = new g();

    /* renamed from: a  reason: collision with root package name */
    public int f2609a;
    public long b;
    public long c;
    public boolean d;
    public long e;
    private long f;
    private int g;
    private float h;

    public LocationRequest() {
        this.f2609a = 102;
        this.b = 3600000;
        this.c = 600000;
        this.d = false;
        this.f = Long.MAX_VALUE;
        this.g = ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        this.h = 0.0f;
        this.e = 0;
    }

    LocationRequest(int i, long j, long j2, boolean z, long j3, int i2, float f2, long j4) {
        this.f2609a = i;
        this.b = j;
        this.c = j2;
        this.d = z;
        this.f = j3;
        this.g = i2;
        this.h = f2;
        this.e = j4;
    }

    public static LocationRequest a() {
        return new LocationRequest();
    }

    public static void a(long j) {
        if (j < 0) {
            StringBuilder sb = new StringBuilder(38);
            sb.append("invalid interval: ");
            sb.append(j);
            throw new IllegalArgumentException(sb.toString());
        }
    }

    private long b() {
        long j = this.e;
        return j < this.b ? this.b : j;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LocationRequest)) {
            return false;
        }
        LocationRequest locationRequest = (LocationRequest) obj;
        return this.f2609a == locationRequest.f2609a && this.b == locationRequest.b && this.c == locationRequest.c && this.d == locationRequest.d && this.f == locationRequest.f && this.g == locationRequest.g && this.h == locationRequest.h && b() == locationRequest.b();
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f2609a), Long.valueOf(this.b), Float.valueOf(this.h), Long.valueOf(this.e)});
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append("Request[");
        switch (this.f2609a) {
            case 100:
                str = "PRIORITY_HIGH_ACCURACY";
                break;
            case 102:
                str = "PRIORITY_BALANCED_POWER_ACCURACY";
                break;
            case 104:
                str = "PRIORITY_LOW_POWER";
                break;
            case 105:
                str = "PRIORITY_NO_POWER";
                break;
            default:
                str = "???";
                break;
        }
        sb.append(str);
        if (this.f2609a != 105) {
            sb.append(" requested=");
            sb.append(this.b);
            sb.append("ms");
        }
        sb.append(" fastest=");
        sb.append(this.c);
        sb.append("ms");
        if (this.e > this.b) {
            sb.append(" maxWait=");
            sb.append(this.e);
            sb.append("ms");
        }
        if (this.h > 0.0f) {
            sb.append(" smallestDisplacement=");
            sb.append(this.h);
            sb.append("m");
        }
        if (this.f != Long.MAX_VALUE) {
            sb.append(" expireIn=");
            sb.append(this.f - SystemClock.elapsedRealtime());
            sb.append("ms");
        }
        if (this.g != Integer.MAX_VALUE) {
            sb.append(" num=");
            sb.append(this.g);
        }
        sb.append(']');
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.f2609a);
        b.a(parcel, 2, this.b);
        b.a(parcel, 3, this.c);
        b.a(parcel, 4, this.d);
        b.a(parcel, 5, this.f);
        b.b(parcel, 6, this.g);
        b.a(parcel, 7, this.h);
        b.a(parcel, 8, this.e);
        b.b(parcel, a2);
    }
}
