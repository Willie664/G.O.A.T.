package com.google.android.gms.location;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Collections;
import java.util.List;

public final class zzal extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzal> CREATOR = new o();

    /* renamed from: a  reason: collision with root package name */
    private final List<String> f2618a;
    private final PendingIntent b;
    private final String c;

    zzal(List<String> list, PendingIntent pendingIntent, String str) {
        this.f2618a = list == null ? Collections.emptyList() : Collections.unmodifiableList(list);
        this.b = pendingIntent;
        this.c = str;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.a(parcel, 1, this.f2618a);
        b.a(parcel, 2, (Parcelable) this.b, i);
        b.a(parcel, 3, this.c);
        b.b(parcel, a2);
    }
}
