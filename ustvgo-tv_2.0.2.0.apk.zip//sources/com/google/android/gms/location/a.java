package com.google.android.gms.location;

import android.location.Location;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.f;

@Deprecated
public interface a {
    Location a(GoogleApiClient googleApiClient);

    f<Status> a(GoogleApiClient googleApiClient, LocationRequest locationRequest, c cVar);

    f<Status> a(GoogleApiClient googleApiClient, c cVar);
}
