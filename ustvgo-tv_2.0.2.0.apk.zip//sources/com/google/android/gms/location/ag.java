package com.google.android.gms.location;

import android.location.Location;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.internal.location.s;
import com.google.android.gms.internal.location.y;

public abstract class ag extends s implements af {
    public ag() {
        super("com.google.android.gms.location.ILocationListener");
    }

    public static af a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.ILocationListener");
        return queryLocalInterface instanceof af ? (af) queryLocalInterface : new ah(iBinder);
    }

    public final boolean a(int i, Parcel parcel) {
        if (i != 1) {
            return false;
        }
        a((Location) y.a(parcel, Location.CREATOR));
        return true;
    }
}
