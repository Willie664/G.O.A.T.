package com.google.android.gms.location;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.location.a;
import com.google.android.gms.internal.location.y;

public final class ae extends a implements ac {
    ae(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.location.ILocationCallback");
    }

    public final void a(LocationAvailability locationAvailability) {
        Parcel a2 = a();
        y.a(a2, (Parcelable) locationAvailability);
        b(2, a2);
    }

    public final void a(LocationResult locationResult) {
        Parcel a2 = a();
        y.a(a2, (Parcelable) locationResult);
        b(1, a2);
    }
}
