package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import java.util.ArrayList;

public final class k implements Parcelable.Creator<LocationSettingsRequest> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a2 = a.a(parcel);
        boolean z = false;
        ArrayList<LocationRequest> arrayList = null;
        zzae zzae = null;
        boolean z2 = false;
        while (parcel.dataPosition() < a2) {
            int readInt = parcel.readInt();
            int i = 65535 & readInt;
            if (i != 5) {
                switch (i) {
                    case 1:
                        arrayList = a.c(parcel, readInt, LocationRequest.CREATOR);
                        break;
                    case 2:
                        z = a.c(parcel, readInt);
                        break;
                    case 3:
                        z2 = a.c(parcel, readInt);
                        break;
                    default:
                        a.b(parcel, readInt);
                        break;
                }
            } else {
                zzae = (zzae) a.a(parcel, readInt, zzae.CREATOR);
            }
        }
        a.u(parcel, a2);
        return new LocationSettingsRequest(arrayList, z, z2, zzae);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new LocationSettingsRequest[i];
    }
}
