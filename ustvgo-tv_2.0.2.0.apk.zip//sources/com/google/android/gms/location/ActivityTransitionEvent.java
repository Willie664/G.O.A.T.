package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.Arrays;

public class ActivityTransitionEvent extends AbstractSafeParcelable {
    public static final Parcelable.Creator<ActivityTransitionEvent> CREATOR = new r();

    /* renamed from: a  reason: collision with root package name */
    final long f2603a;
    private final int b;
    private final int c;

    public ActivityTransitionEvent(int i, int i2, long j) {
        DetectedActivity.a(i);
        ActivityTransition.a(i2);
        this.b = i;
        this.c = i2;
        this.f2603a = j;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ActivityTransitionEvent)) {
            return false;
        }
        ActivityTransitionEvent activityTransitionEvent = (ActivityTransitionEvent) obj;
        return this.b == activityTransitionEvent.b && this.c == activityTransitionEvent.c && this.f2603a == activityTransitionEvent.f2603a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.b), Integer.valueOf(this.c), Long.valueOf(this.f2603a)});
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        int i = this.b;
        StringBuilder sb2 = new StringBuilder(24);
        sb2.append("ActivityType ");
        sb2.append(i);
        sb.append(sb2.toString());
        sb.append(" ");
        int i2 = this.c;
        StringBuilder sb3 = new StringBuilder(26);
        sb3.append("TransitionType ");
        sb3.append(i2);
        sb.append(sb3.toString());
        sb.append(" ");
        long j = this.f2603a;
        StringBuilder sb4 = new StringBuilder(41);
        sb4.append("ElapsedRealTimeNanos ");
        sb4.append(j);
        sb.append(sb4.toString());
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.b(parcel, 1, this.b);
        b.b(parcel, 2, this.c);
        b.a(parcel, 3, this.f2603a);
        b.b(parcel, a2);
    }
}
