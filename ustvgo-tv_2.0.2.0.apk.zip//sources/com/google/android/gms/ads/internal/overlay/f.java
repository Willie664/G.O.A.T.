package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.internal.ads.cj;

@cj
final class f extends Exception {
    public f(String str) {
        super(str);
    }
}
