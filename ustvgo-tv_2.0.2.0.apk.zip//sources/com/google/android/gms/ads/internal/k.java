package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.zzjj;

final class k implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ zzjj f1274a;
    private final /* synthetic */ int b;
    private final /* synthetic */ i c;

    k(i iVar, zzjj zzjj, int i) {
        this.c = iVar;
        this.f1274a = zzjj;
        this.b = i;
    }

    public final void run() {
        synchronized (this.c.s) {
            i.a(this.c, this.f1274a, this.b);
        }
    }
}
