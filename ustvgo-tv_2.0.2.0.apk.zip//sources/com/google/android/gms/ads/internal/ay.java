package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ViewSwitcher;
import com.google.android.gms.internal.ads.jz;
import com.google.android.gms.internal.ads.lo;
import com.google.android.gms.internal.ads.pu;
import java.util.ArrayList;

public final class ay extends ViewSwitcher {

    /* renamed from: a  reason: collision with root package name */
    final jz f1224a;
    final lo b;
    boolean c = true;

    public ay(Context context, String str, String str2, ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener, ViewTreeObserver.OnScrollChangedListener onScrollChangedListener) {
        super(context);
        this.f1224a = new jz(context);
        this.f1224a.c = str;
        this.f1224a.d = str2;
        if (context instanceof Activity) {
            this.b = new lo((Activity) context, this, onGlobalLayoutListener, onScrollChangedListener);
        } else {
            this.b = new lo((Activity) null, this, onGlobalLayoutListener, onScrollChangedListener);
        }
        this.b.a();
    }

    /* access modifiers changed from: protected */
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.b != null) {
            this.b.c();
        }
    }

    /* access modifiers changed from: protected */
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.b != null) {
            this.b.d();
        }
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (!this.c) {
            return false;
        }
        this.f1224a.a(motionEvent);
        return false;
    }

    public final void removeAllViews() {
        ArrayList arrayList = new ArrayList();
        int i = 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt != null && (childAt instanceof pu)) {
                arrayList.add((pu) childAt);
            }
        }
        super.removeAllViews();
        ArrayList arrayList2 = arrayList;
        int size = arrayList2.size();
        while (i < size) {
            Object obj = arrayList2.get(i);
            i++;
            ((pu) obj).destroy();
        }
    }
}
