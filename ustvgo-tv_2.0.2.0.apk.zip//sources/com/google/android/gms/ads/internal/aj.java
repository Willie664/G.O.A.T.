package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.arz;
import com.google.android.gms.internal.ads.iy;

final class aj implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ arz f1210a;
    private final /* synthetic */ ad b;

    aj(ad adVar, arz arz) {
        this.b = adVar;
        this.f1210a = arz;
    }

    public final void run() {
        try {
            if (this.b.e.s != null) {
                this.b.e.s.a(this.f1210a);
                this.b.a(this.f1210a.j());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
