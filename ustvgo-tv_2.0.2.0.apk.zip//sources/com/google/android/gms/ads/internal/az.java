package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.alo;
import com.google.android.gms.internal.ads.amd;
import com.google.android.gms.internal.ads.ie;

final class az implements alo {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ie f1225a;

    az(ie ieVar) {
        this.f1225a = ieVar;
    }

    public final void a(amd amd) {
        amd.f1751a = this.f1225a.f2106a.v;
    }
}
