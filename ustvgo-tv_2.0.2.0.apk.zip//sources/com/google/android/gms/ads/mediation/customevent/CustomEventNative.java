package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.i;

public interface CustomEventNative extends a {
    void requestNativeAd(Context context, e eVar, String str, i iVar, Bundle bundle);
}
