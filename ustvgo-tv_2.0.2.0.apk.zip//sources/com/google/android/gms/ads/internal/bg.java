package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class bg implements ae<pu> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bf f1231a;

    bg(bf bfVar) {
        this.f1231a = bfVar;
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        this.f1231a.b((pu) obj);
    }
}
