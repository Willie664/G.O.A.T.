package com.google.android.gms.ads.internal.overlay;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;

@cj
public final class a {
    private static boolean a(Context context, Intent intent, s sVar) {
        try {
            String valueOf = String.valueOf(intent.toURI());
            if (valueOf.length() != 0) {
                "Launching an intent: ".concat(valueOf);
            } else {
                new String("Launching an intent: ");
            }
            iy.a();
            aw.e();
            jh.a(context, intent);
            if (sVar == null) {
                return true;
            }
            sVar.h();
            return true;
        } catch (ActivityNotFoundException e) {
            iy.b(e.getMessage());
            return false;
        }
    }

    public static boolean a(Context context, zzc zzc, s sVar) {
        int i;
        String str;
        if (zzc == null) {
            str = "No intent data for launcher overlay.";
        } else {
            aqs.a(context);
            if (zzc.f != null) {
                return a(context, zzc.f, sVar);
            }
            Intent intent = new Intent();
            if (TextUtils.isEmpty(zzc.f1289a)) {
                str = "Open GMSG did not contain a URL.";
            } else {
                if (!TextUtils.isEmpty(zzc.b)) {
                    intent.setDataAndType(Uri.parse(zzc.f1289a), zzc.b);
                } else {
                    intent.setData(Uri.parse(zzc.f1289a));
                }
                intent.setAction("android.intent.action.VIEW");
                if (!TextUtils.isEmpty(zzc.c)) {
                    intent.setPackage(zzc.c);
                }
                if (!TextUtils.isEmpty(zzc.d)) {
                    String[] split = zzc.d.split("/", 2);
                    if (split.length < 2) {
                        String valueOf = String.valueOf(zzc.d);
                        iy.b(valueOf.length() != 0 ? "Could not parse component name from open GMSG: ".concat(valueOf) : new String("Could not parse component name from open GMSG: "));
                        return false;
                    }
                    intent.setClassName(split[0], split[1]);
                }
                String str2 = zzc.e;
                if (!TextUtils.isEmpty(str2)) {
                    try {
                        i = Integer.parseInt(str2);
                    } catch (NumberFormatException unused) {
                        iy.b("Could not parse intent flags.");
                        i = 0;
                    }
                    intent.addFlags(i);
                }
                if (((Boolean) ans.f().a(aqs.cN)).booleanValue()) {
                    intent.addFlags(268435456);
                    intent.putExtra("android.support.customtabs.extra.user_opt_out", true);
                } else {
                    if (((Boolean) ans.f().a(aqs.cM)).booleanValue()) {
                        aw.e();
                        jh.b(context, intent);
                    }
                }
                return a(context, intent, sVar);
            }
        }
        iy.b(str);
        return false;
    }
}
