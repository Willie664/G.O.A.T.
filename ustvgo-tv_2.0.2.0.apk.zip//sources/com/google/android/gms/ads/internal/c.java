package com.google.android.gms.ads.internal;

final class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bv f1245a;

    c(bv bvVar) {
        this.f1245a = bvVar;
    }

    public final void run() {
        this.f1245a.d(this.f1245a.e.j);
    }
}
