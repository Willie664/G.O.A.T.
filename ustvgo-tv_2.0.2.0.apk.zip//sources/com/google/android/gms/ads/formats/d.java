package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.formats.a;
import com.google.android.gms.ads.h;
import java.util.List;

public abstract class d extends a {

    public interface a {
        void a(d dVar);
    }

    public abstract CharSequence b();

    public abstract List<a.b> c();

    public abstract CharSequence d();

    public abstract a.b e();

    public abstract CharSequence f();

    public abstract Double g();

    public abstract CharSequence h();

    public abstract CharSequence i();

    public abstract h j();
}
