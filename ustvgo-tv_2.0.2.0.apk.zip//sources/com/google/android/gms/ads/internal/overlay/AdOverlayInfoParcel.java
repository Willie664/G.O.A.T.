package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.gmsg.k;
import com.google.android.gms.ads.internal.gmsg.m;
import com.google.android.gms.ads.internal.zzaq;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.ads.amz;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.zzang;

@cj
public final class AdOverlayInfoParcel extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = new l();

    /* renamed from: a  reason: collision with root package name */
    public final zzc f1278a;
    public final amz b;
    public final m c;
    public final pu d;
    public final m e;
    public final String f;
    public final boolean g;
    public final String h;
    public final s i;
    public final int j;
    public final int k;
    public final String l;
    public final zzang m;
    public final String n;
    public final zzaq o;
    public final k p;

    AdOverlayInfoParcel(zzc zzc, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i2, int i3, String str3, zzang zzang, String str4, zzaq zzaq, IBinder iBinder6) {
        this.f1278a = zzc;
        this.b = (amz) b.a(a.C0061a.a(iBinder));
        this.c = (m) b.a(a.C0061a.a(iBinder2));
        this.d = (pu) b.a(a.C0061a.a(iBinder3));
        this.p = (k) b.a(a.C0061a.a(iBinder6));
        this.e = (m) b.a(a.C0061a.a(iBinder4));
        this.f = str;
        this.g = z;
        this.h = str2;
        this.i = (s) b.a(a.C0061a.a(iBinder5));
        this.j = i2;
        this.k = i3;
        this.l = str3;
        this.m = zzang;
        this.n = str4;
        this.o = zzaq;
    }

    public AdOverlayInfoParcel(zzc zzc, amz amz, m mVar, s sVar, zzang zzang) {
        this.f1278a = zzc;
        this.b = amz;
        this.c = mVar;
        this.d = null;
        this.p = null;
        this.e = null;
        this.f = null;
        this.g = false;
        this.h = null;
        this.i = sVar;
        this.j = -1;
        this.k = 4;
        this.l = null;
        this.m = zzang;
        this.n = null;
        this.o = null;
    }

    public AdOverlayInfoParcel(amz amz, m mVar, k kVar, m mVar2, s sVar, pu puVar, boolean z, int i2, String str, zzang zzang) {
        this.f1278a = null;
        this.b = amz;
        this.c = mVar;
        this.d = puVar;
        this.p = kVar;
        this.e = mVar2;
        this.f = null;
        this.g = z;
        this.h = null;
        this.i = sVar;
        this.j = i2;
        this.k = 3;
        this.l = str;
        this.m = zzang;
        this.n = null;
        this.o = null;
    }

    public AdOverlayInfoParcel(amz amz, m mVar, k kVar, m mVar2, s sVar, pu puVar, boolean z, int i2, String str, String str2, zzang zzang) {
        this.f1278a = null;
        this.b = amz;
        this.c = mVar;
        this.d = puVar;
        this.p = kVar;
        this.e = mVar2;
        this.f = str2;
        this.g = z;
        this.h = str;
        this.i = sVar;
        this.j = i2;
        this.k = 3;
        this.l = null;
        this.m = zzang;
        this.n = null;
        this.o = null;
    }

    public AdOverlayInfoParcel(amz amz, m mVar, s sVar, pu puVar, int i2, zzang zzang, String str, zzaq zzaq) {
        this.f1278a = null;
        this.b = amz;
        this.c = mVar;
        this.d = puVar;
        this.p = null;
        this.e = null;
        this.f = null;
        this.g = false;
        this.h = null;
        this.i = sVar;
        this.j = i2;
        this.k = 1;
        this.l = null;
        this.m = zzang;
        this.n = str;
        this.o = zzaq;
    }

    public AdOverlayInfoParcel(amz amz, m mVar, s sVar, pu puVar, boolean z, int i2, zzang zzang) {
        this.f1278a = null;
        this.b = amz;
        this.c = mVar;
        this.d = puVar;
        this.p = null;
        this.e = null;
        this.f = null;
        this.g = z;
        this.h = null;
        this.i = sVar;
        this.j = i2;
        this.k = 2;
        this.l = null;
        this.m = zzang;
        this.n = null;
        this.o = null;
    }

    public static AdOverlayInfoParcel a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
            return (AdOverlayInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception unused) {
            return null;
        }
    }

    public static void a(Intent intent, AdOverlayInfoParcel adOverlayInfoParcel) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", adOverlayInfoParcel);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int a2 = com.google.android.gms.common.internal.safeparcel.b.a(parcel, 20293);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, (Parcelable) this.f1278a, i2);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, b.a(this.b).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 4, b.a(this.c).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, b.a(this.d).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 6, b.a(this.e).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, this.f);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 8, this.g);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 9, this.h);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 10, b.a(this.i).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, 11, this.j);
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, 12, this.k);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 13, this.l);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 14, (Parcelable) this.m, i2);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 16, this.n);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 17, (Parcelable) this.o, i2);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 18, b.a(this.p).asBinder());
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, a2);
    }
}
