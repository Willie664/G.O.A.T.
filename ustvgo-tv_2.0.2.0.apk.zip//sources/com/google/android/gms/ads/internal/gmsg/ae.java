package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.cj;
import java.util.Map;

@cj
public interface ae<ContextT> {
    void zza(ContextT contextt, Map<String, String> map);
}
