package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.internal.ads.rd;

final /* synthetic */ class d implements rd {

    /* renamed from: a  reason: collision with root package name */
    private final c f1280a;

    d(c cVar) {
        this.f1280a = cVar;
    }

    public final void a(boolean z) {
        this.f1280a.c.o();
    }
}
