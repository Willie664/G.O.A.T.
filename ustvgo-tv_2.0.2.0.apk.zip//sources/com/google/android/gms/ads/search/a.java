package com.google.android.gms.ads.search;

@Deprecated
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final String f1309a;
}
