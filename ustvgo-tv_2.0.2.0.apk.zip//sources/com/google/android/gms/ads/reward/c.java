package com.google.android.gms.ads.reward;

public class c {
    public void a() {
    }
}
