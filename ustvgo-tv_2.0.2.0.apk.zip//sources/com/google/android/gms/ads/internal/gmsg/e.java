package com.google.android.gms.ads.internal.gmsg;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.view.View;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.ads.internal.bu;
import com.google.android.gms.ads.internal.overlay.m;
import com.google.android.gms.ads.internal.overlay.s;
import com.google.android.gms.internal.ads.agb;
import com.google.android.gms.internal.ads.agc;
import com.google.android.gms.internal.ads.amz;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.d;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.qq;
import com.google.android.gms.internal.ads.qr;
import com.google.android.gms.internal.ads.qv;
import com.google.android.gms.internal.ads.qy;
import com.google.android.gms.internal.ads.rb;
import com.google.android.gms.internal.ads.zzang;
import java.util.Map;

@cj
public final class e<T extends qq & qr & qv & qy & rb> implements ae<T> {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1260a;
    private final agb b;
    private final zzang c;
    private final s d;
    private final amz e;
    private final m f;
    private final k g;
    private final m h;
    private final bu i;
    private final d j;
    private final pu k = null;

    public e(Context context, zzang zzang, agb agb, s sVar, amz amz, k kVar, m mVar, m mVar2, bu buVar, d dVar) {
        this.f1260a = context;
        this.c = zzang;
        this.b = agb;
        this.d = sVar;
        this.e = amz;
        this.g = kVar;
        this.h = mVar;
        this.i = buVar;
        this.j = dVar;
        this.f = mVar2;
    }

    private static String a(Context context, agb agb, String str, View view, Activity activity) {
        if (agb == null) {
            return str;
        }
        try {
            Uri parse = Uri.parse(str);
            boolean z = false;
            if (agb.a(parse)) {
                String[] strArr = agb.f1642a;
                int length = strArr.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        break;
                    }
                    if (parse.getPath().endsWith(strArr[i2])) {
                        z = true;
                        break;
                    }
                    i2++;
                }
            }
            if (z) {
                parse = agb.a(parse, context, view, activity);
            }
            return parse.toString();
        } catch (agc unused) {
            return str;
        } catch (Exception e2) {
            aw.i().a((Throwable) e2, "OpenGmsgHandler.maybeAddClickSignalsToUrl");
            return str;
        }
    }

    private final void a(boolean z) {
        if (this.j != null) {
            this.j.a(z);
        }
    }

    private static boolean a(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int b(Map<String, String> map) {
        String str = map.get("o");
        if (str == null) {
            return -1;
        }
        if ("p".equalsIgnoreCase(str)) {
            return aw.g().b();
        }
        if ("l".equalsIgnoreCase(str)) {
            return aw.g().a();
        }
        if ("c".equalsIgnoreCase(str)) {
            return aw.g().c();
        }
        return -1;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v15, resolved type: android.net.Uri} */
    /* JADX WARNING: type inference failed for: r2v6 */
    /* JADX WARNING: type inference failed for: r2v7, types: [android.content.Intent] */
    /* JADX WARNING: type inference failed for: r2v13 */
    /* JADX WARNING: type inference failed for: r2v14, types: [android.content.Intent] */
    /* JADX WARNING: type inference failed for: r2v17 */
    /* JADX WARNING: type inference failed for: r2v33 */
    /* JADX WARNING: type inference failed for: r2v34 */
    /* JADX WARNING: type inference failed for: r2v35 */
    /* JADX WARNING: type inference failed for: r2v36 */
    /* JADX WARNING: type inference failed for: r2v37 */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x01a3, code lost:
        if (r0 != null) goto L_0x01f7;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0178  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x018e  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0193 A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ void zza(java.lang.Object r12, java.util.Map r13) {
        /*
            r11 = this;
            com.google.android.gms.internal.ads.qq r12 = (com.google.android.gms.internal.ads.qq) r12
            java.lang.String r0 = "u"
            java.lang.Object r0 = r13.get(r0)
            java.lang.String r0 = (java.lang.String) r0
            android.content.Context r1 = r12.getContext()
            java.lang.String r0 = com.google.android.gms.internal.ads.hx.a(r0, r1)
            java.lang.String r1 = "a"
            java.lang.Object r1 = r13.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            if (r1 != 0) goto L_0x0022
            java.lang.String r12 = "Action missing from an open GMSG."
            com.google.android.gms.internal.ads.iy.b(r12)
            return
        L_0x0022:
            com.google.android.gms.ads.internal.bu r2 = r11.i
            if (r2 == 0) goto L_0x0034
            com.google.android.gms.ads.internal.bu r2 = r11.i
            boolean r2 = r2.a()
            if (r2 != 0) goto L_0x0034
            com.google.android.gms.ads.internal.bu r12 = r11.i
            r12.a(r0)
            return
        L_0x0034:
            java.lang.String r2 = "expand"
            boolean r2 = r2.equalsIgnoreCase(r1)
            r3 = 0
            if (r2 == 0) goto L_0x005d
            r0 = r12
            com.google.android.gms.internal.ads.qr r0 = (com.google.android.gms.internal.ads.qr) r0
            boolean r0 = r0.z()
            if (r0 == 0) goto L_0x004c
            java.lang.String r12 = "Cannot expand WebView that is already expanded."
            com.google.android.gms.internal.ads.iy.b(r12)
            return
        L_0x004c:
            r11.a((boolean) r3)
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12
            boolean r0 = a((java.util.Map<java.lang.String, java.lang.String>) r13)
            int r13 = b(r13)
            r12.a(r0, r13)
            return
        L_0x005d:
            java.lang.String r2 = "webapp"
            boolean r2 = r2.equalsIgnoreCase(r1)
            if (r2 == 0) goto L_0x0096
            r11.a((boolean) r3)
            if (r0 == 0) goto L_0x0078
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12
            boolean r1 = a((java.util.Map<java.lang.String, java.lang.String>) r13)
            int r13 = b(r13)
            r12.a(r1, r13, r0)
            return
        L_0x0078:
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12
            boolean r0 = a((java.util.Map<java.lang.String, java.lang.String>) r13)
            int r1 = b(r13)
            java.lang.String r2 = "html"
            java.lang.Object r2 = r13.get(r2)
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r3 = "baseurl"
            java.lang.Object r13 = r13.get(r3)
            java.lang.String r13 = (java.lang.String) r13
            r12.a(r0, r1, r2, r13)
            return
        L_0x0096:
            java.lang.String r2 = "app"
            boolean r1 = r2.equalsIgnoreCase(r1)
            r2 = 0
            r4 = 1
            if (r1 == 0) goto L_0x020b
            java.lang.String r1 = "true"
            java.lang.String r5 = "system_browser"
            java.lang.Object r5 = r13.get(r5)
            java.lang.String r5 = (java.lang.String) r5
            boolean r1 = r1.equalsIgnoreCase(r5)
            if (r1 == 0) goto L_0x020b
            r11.a((boolean) r4)
            r12.getContext()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto L_0x00c2
            java.lang.String r12 = "Destination url cannot be empty."
            com.google.android.gms.internal.ads.iy.b(r12)
            return
        L_0x00c2:
            com.google.android.gms.ads.internal.gmsg.f r0 = new com.google.android.gms.ads.internal.gmsg.f
            android.content.Context r1 = r12.getContext()
            r5 = r12
            com.google.android.gms.internal.ads.qy r5 = (com.google.android.gms.internal.ads.qy) r5
            com.google.android.gms.internal.ads.agb r5 = r5.y()
            r6 = r12
            com.google.android.gms.internal.ads.rb r6 = (com.google.android.gms.internal.ads.rb) r6
            android.view.View r6 = r6.getView()
            r0.<init>(r1, r5, r6)
            android.content.Context r1 = r0.f1261a
            java.lang.String r5 = "activity"
            java.lang.Object r1 = r1.getSystemService(r5)
            android.app.ActivityManager r1 = (android.app.ActivityManager) r1
            java.lang.String r5 = "u"
            java.lang.Object r5 = r13.get(r5)
            java.lang.String r5 = (java.lang.String) r5
            boolean r6 = android.text.TextUtils.isEmpty(r5)
            if (r6 == 0) goto L_0x00f3
            goto L_0x01f7
        L_0x00f3:
            android.content.Context r6 = r0.f1261a
            com.google.android.gms.internal.ads.agb r7 = r0.b
            android.view.View r8 = r0.c
            java.lang.String r5 = a(r6, r7, r5, r8, r2)
            android.net.Uri r5 = android.net.Uri.parse(r5)
            java.lang.String r6 = "use_first_package"
            java.lang.Object r6 = r13.get(r6)
            java.lang.String r6 = (java.lang.String) r6
            boolean r6 = java.lang.Boolean.parseBoolean(r6)
            java.lang.String r7 = "use_running_process"
            java.lang.Object r7 = r13.get(r7)
            java.lang.String r7 = (java.lang.String) r7
            boolean r7 = java.lang.Boolean.parseBoolean(r7)
            java.lang.String r8 = "use_custom_tabs"
            java.lang.Object r13 = r13.get(r8)
            java.lang.String r13 = (java.lang.String) r13
            boolean r13 = java.lang.Boolean.parseBoolean(r13)
            if (r13 != 0) goto L_0x013b
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r13 = com.google.android.gms.internal.ads.aqs.cM
            com.google.android.gms.internal.ads.aqq r8 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r13 = r8.a(r13)
            java.lang.Boolean r13 = (java.lang.Boolean) r13
            boolean r13 = r13.booleanValue()
            if (r13 == 0) goto L_0x013a
            goto L_0x013b
        L_0x013a:
            r4 = 0
        L_0x013b:
            java.lang.String r13 = "http"
            java.lang.String r8 = r5.getScheme()
            boolean r13 = r13.equalsIgnoreCase(r8)
            if (r13 == 0) goto L_0x0156
            android.net.Uri$Builder r13 = r5.buildUpon()
            java.lang.String r2 = "https"
        L_0x014d:
            android.net.Uri$Builder r13 = r13.scheme(r2)
            android.net.Uri r2 = r13.build()
            goto L_0x0169
        L_0x0156:
            java.lang.String r13 = "https"
            java.lang.String r8 = r5.getScheme()
            boolean r13 = r13.equalsIgnoreCase(r8)
            if (r13 == 0) goto L_0x0169
            android.net.Uri$Builder r13 = r5.buildUpon()
            java.lang.String r2 = "http"
            goto L_0x014d
        L_0x0169:
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            android.content.Intent r5 = com.google.android.gms.ads.internal.gmsg.f.a((android.net.Uri) r5)
            android.content.Intent r2 = com.google.android.gms.ads.internal.gmsg.f.a((android.net.Uri) r2)
            if (r4 == 0) goto L_0x0188
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r4 = r0.f1261a
            com.google.android.gms.internal.ads.jh.b((android.content.Context) r4, (android.content.Intent) r5)
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r4 = r0.f1261a
            com.google.android.gms.internal.ads.jh.b((android.content.Context) r4, (android.content.Intent) r2)
        L_0x0188:
            android.content.pm.ResolveInfo r4 = r0.a((android.content.Intent) r5, (java.util.ArrayList<android.content.pm.ResolveInfo>) r13)
            if (r4 == 0) goto L_0x0193
            android.content.Intent r2 = com.google.android.gms.ads.internal.gmsg.f.a((android.content.Intent) r5, (android.content.pm.ResolveInfo) r4)
            goto L_0x01f7
        L_0x0193:
            if (r2 == 0) goto L_0x01a6
            android.content.pm.ResolveInfo r2 = r0.a((android.content.Intent) r2)
            if (r2 == 0) goto L_0x01a6
            android.content.Intent r2 = com.google.android.gms.ads.internal.gmsg.f.a((android.content.Intent) r5, (android.content.pm.ResolveInfo) r2)
            android.content.pm.ResolveInfo r0 = r0.a((android.content.Intent) r2)
            if (r0 == 0) goto L_0x01a6
            goto L_0x01f7
        L_0x01a6:
            int r0 = r13.size()
            if (r0 == 0) goto L_0x01f6
            if (r7 == 0) goto L_0x01e9
            if (r1 == 0) goto L_0x01e9
            java.util.List r0 = r1.getRunningAppProcesses()
            if (r0 == 0) goto L_0x01e9
            r1 = r13
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            int r2 = r1.size()
            r4 = 0
        L_0x01be:
            if (r4 >= r2) goto L_0x01e9
            java.lang.Object r7 = r1.get(r4)
            int r4 = r4 + 1
            android.content.pm.ResolveInfo r7 = (android.content.pm.ResolveInfo) r7
            java.util.Iterator r8 = r0.iterator()
        L_0x01cc:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x01be
            java.lang.Object r9 = r8.next()
            android.app.ActivityManager$RunningAppProcessInfo r9 = (android.app.ActivityManager.RunningAppProcessInfo) r9
            java.lang.String r9 = r9.processName
            android.content.pm.ActivityInfo r10 = r7.activityInfo
            java.lang.String r10 = r10.packageName
            boolean r9 = r9.equals(r10)
            if (r9 == 0) goto L_0x01cc
            android.content.Intent r2 = com.google.android.gms.ads.internal.gmsg.f.a((android.content.Intent) r5, (android.content.pm.ResolveInfo) r7)
            goto L_0x01f7
        L_0x01e9:
            if (r6 == 0) goto L_0x01f6
            java.lang.Object r13 = r13.get(r3)
            android.content.pm.ResolveInfo r13 = (android.content.pm.ResolveInfo) r13
            android.content.Intent r2 = com.google.android.gms.ads.internal.gmsg.f.a((android.content.Intent) r5, (android.content.pm.ResolveInfo) r13)
            goto L_0x01f7
        L_0x01f6:
            r2 = r5
        L_0x01f7:
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12     // Catch:{ ActivityNotFoundException -> 0x0202 }
            com.google.android.gms.ads.internal.overlay.zzc r13 = new com.google.android.gms.ads.internal.overlay.zzc     // Catch:{ ActivityNotFoundException -> 0x0202 }
            r13.<init>(r2)     // Catch:{ ActivityNotFoundException -> 0x0202 }
            r12.a(r13)     // Catch:{ ActivityNotFoundException -> 0x0202 }
            return
        L_0x0202:
            r12 = move-exception
            java.lang.String r12 = r12.getMessage()
            com.google.android.gms.internal.ads.iy.b(r12)
            return
        L_0x020b:
            r11.a((boolean) r4)
            java.lang.String r1 = "intent_url"
            java.lang.Object r1 = r13.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            boolean r4 = android.text.TextUtils.isEmpty(r1)
            if (r4 != 0) goto L_0x023c
            android.content.Intent r3 = android.content.Intent.parseUri(r1, r3)     // Catch:{ URISyntaxException -> 0x0222 }
            r2 = r3
            goto L_0x023c
        L_0x0222:
            r3 = move-exception
            java.lang.String r4 = "Error parsing the url: "
            java.lang.String r1 = java.lang.String.valueOf(r1)
            int r5 = r1.length()
            if (r5 == 0) goto L_0x0234
            java.lang.String r1 = r4.concat(r1)
            goto L_0x0239
        L_0x0234:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r4)
        L_0x0239:
            com.google.android.gms.internal.ads.iy.a(r1, r3)
        L_0x023c:
            if (r2 == 0) goto L_0x02a9
            android.net.Uri r1 = r2.getData()
            if (r1 == 0) goto L_0x02a9
            android.net.Uri r1 = r2.getData()
            java.lang.String r3 = r1.toString()
            boolean r4 = android.text.TextUtils.isEmpty(r3)
            if (r4 != 0) goto L_0x02a6
            android.content.Context r4 = r12.getContext()     // Catch:{ Exception -> 0x026e }
            r5 = r12
            com.google.android.gms.internal.ads.qy r5 = (com.google.android.gms.internal.ads.qy) r5     // Catch:{ Exception -> 0x026e }
            com.google.android.gms.internal.ads.agb r5 = r5.y()     // Catch:{ Exception -> 0x026e }
            r6 = r12
            com.google.android.gms.internal.ads.rb r6 = (com.google.android.gms.internal.ads.rb) r6     // Catch:{ Exception -> 0x026e }
            android.view.View r6 = r6.getView()     // Catch:{ Exception -> 0x026e }
            android.app.Activity r7 = r12.d()     // Catch:{ Exception -> 0x026e }
            java.lang.String r4 = a(r4, r5, r3, r6, r7)     // Catch:{ Exception -> 0x026e }
            r3 = r4
            goto L_0x027d
        L_0x026e:
            r4 = move-exception
            java.lang.String r5 = "Error occurred while adding signals."
            com.google.android.gms.internal.ads.iy.a(r5, r4)
            com.google.android.gms.internal.ads.ii r5 = com.google.android.gms.ads.internal.aw.i()
            java.lang.String r6 = "OpenGmsgHandler.onGmsg"
            r5.a((java.lang.Throwable) r4, (java.lang.String) r6)
        L_0x027d:
            android.net.Uri r4 = android.net.Uri.parse(r3)     // Catch:{ Exception -> 0x0283 }
            r1 = r4
            goto L_0x02a6
        L_0x0283:
            r4 = move-exception
            java.lang.String r5 = "Error parsing the uri: "
            java.lang.String r3 = java.lang.String.valueOf(r3)
            int r6 = r3.length()
            if (r6 == 0) goto L_0x0295
            java.lang.String r3 = r5.concat(r3)
            goto L_0x029a
        L_0x0295:
            java.lang.String r3 = new java.lang.String
            r3.<init>(r5)
        L_0x029a:
            com.google.android.gms.internal.ads.iy.a(r3, r4)
            com.google.android.gms.internal.ads.ii r3 = com.google.android.gms.ads.internal.aw.i()
            java.lang.String r5 = "OpenGmsgHandler.onGmsg"
            r3.a((java.lang.Throwable) r4, (java.lang.String) r5)
        L_0x02a6:
            r2.setData(r1)
        L_0x02a9:
            if (r2 == 0) goto L_0x02b6
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12
            com.google.android.gms.ads.internal.overlay.zzc r13 = new com.google.android.gms.ads.internal.overlay.zzc
            r13.<init>(r2)
            r12.a(r13)
            return
        L_0x02b6:
            boolean r1 = android.text.TextUtils.isEmpty(r0)
            if (r1 != 0) goto L_0x02d6
            android.content.Context r1 = r12.getContext()
            r2 = r12
            com.google.android.gms.internal.ads.qy r2 = (com.google.android.gms.internal.ads.qy) r2
            com.google.android.gms.internal.ads.agb r2 = r2.y()
            r3 = r12
            com.google.android.gms.internal.ads.rb r3 = (com.google.android.gms.internal.ads.rb) r3
            android.view.View r3 = r3.getView()
            android.app.Activity r4 = r12.d()
            java.lang.String r0 = a(r1, r2, r0, r3, r4)
        L_0x02d6:
            r3 = r0
            com.google.android.gms.internal.ads.qv r12 = (com.google.android.gms.internal.ads.qv) r12
            com.google.android.gms.ads.internal.overlay.zzc r0 = new com.google.android.gms.ads.internal.overlay.zzc
            java.lang.String r1 = "i"
            java.lang.Object r1 = r13.get(r1)
            r2 = r1
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r1 = "m"
            java.lang.Object r1 = r13.get(r1)
            r4 = r1
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r1 = "p"
            java.lang.Object r1 = r13.get(r1)
            r5 = r1
            java.lang.String r5 = (java.lang.String) r5
            java.lang.String r1 = "c"
            java.lang.Object r1 = r13.get(r1)
            r6 = r1
            java.lang.String r6 = (java.lang.String) r6
            java.lang.String r1 = "f"
            java.lang.Object r1 = r13.get(r1)
            r7 = r1
            java.lang.String r7 = (java.lang.String) r7
            java.lang.String r1 = "e"
            java.lang.Object r13 = r13.get(r1)
            r8 = r13
            java.lang.String r8 = (java.lang.String) r8
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6, r7, r8)
            r12.a(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.gmsg.e.zza(java.lang.Object, java.util.Map):void");
    }
}
