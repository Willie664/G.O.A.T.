package com.google.android.gms.ads;

import com.google.android.gms.internal.ads.apn;
import com.google.android.gms.internal.ads.apo;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final apn f1188a;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final apo f1189a = new apo();

        public a() {
            this.f1189a.a("B3EEABB8EE11C2BE770B684D95219ECB");
        }
    }

    private c(a aVar) {
        this.f1188a = new apn(aVar.f1189a);
    }

    public /* synthetic */ c(a aVar, byte b) {
        this(aVar);
    }
}
