package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.zzaig;

public interface j {
    void a(zzaig zzaig);

    void f_();

    void g_();
}
