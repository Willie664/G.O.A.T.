package com.google.android.gms.ads.internal;

import android.content.Context;
import android.graphics.Rect;
import android.os.RemoteException;
import android.support.v4.f.m;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewTreeObserver;
import com.google.android.gms.internal.ads.Cif;
import com.google.android.gms.internal.ads.afx;
import com.google.android.gms.internal.ads.agb;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.anv;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aoo;
import com.google.android.gms.internal.ads.aos;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.aqv;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.aug;
import com.google.android.gms.internal.ads.auj;
import com.google.android.gms.internal.ads.aun;
import com.google.android.gms.internal.ads.auq;
import com.google.android.gms.internal.ads.aut;
import com.google.android.gms.internal.ads.auv;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.fv;
import com.google.android.gms.internal.ads.gd;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.iq;
import com.google.android.gms.internal.ads.it;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jy;
import com.google.android.gms.internal.ads.lf;
import com.google.android.gms.internal.ads.lp;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzlu;
import com.google.android.gms.internal.ads.zzmu;
import com.google.android.gms.internal.ads.zzpl;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class ax implements ViewTreeObserver.OnGlobalLayoutListener, ViewTreeObserver.OnScrollChangedListener {
    List<Integer> A;
    arm B;
    gd C;
    fv D;
    public String E;
    List<String> F;
    public iq G;
    View H;
    public int I;
    boolean J;
    HashSet<Cif> K;
    boolean L;
    boolean M;
    boolean N;
    private int O;
    private int P;
    private lf Q;

    /* renamed from: a  reason: collision with root package name */
    final String f1223a;
    public String b;
    public final Context c;
    final agb d;
    public final zzang e;
    ay f;
    public it g;
    public jy h;
    public zzjn i;
    public id j;
    public ie k;
    public Cif l;
    anv m;
    any n;
    aos o;
    aoo p;
    aoy q;
    aug r;
    auj s;
    auv t;
    m<String, aun> u;
    m<String, auq> v;
    zzpl w;
    zzmu x;
    zzlu y;
    aut z;

    public ax(Context context, zzjn zzjn, String str, zzang zzang) {
        this(context, zzjn, str, zzang, (byte) 0);
    }

    private ax(Context context, zzjn zzjn, String str, zzang zzang, byte b2) {
        this.G = null;
        this.H = null;
        this.I = 0;
        this.J = false;
        this.K = null;
        this.O = -1;
        this.P = -1;
        this.L = true;
        this.M = true;
        this.N = false;
        aqs.a(context);
        if (aw.i().a() != null) {
            List<String> b3 = aqs.b();
            if (zzang.b != 0) {
                b3.add(Integer.toString(zzang.b));
            }
            aqv a2 = aw.i().a();
            if (b3 != null && !b3.isEmpty()) {
                a2.b.put("e", TextUtils.join(",", b3));
            }
        }
        this.f1223a = UUID.randomUUID().toString();
        if (zzjn.d || zzjn.h) {
            this.f = null;
        } else {
            this.f = new ay(context, str, zzang.f2393a, this, this);
            this.f.setMinimumWidth(zzjn.f);
            this.f.setMinimumHeight(zzjn.c);
            this.f.setVisibility(4);
        }
        this.i = zzjn;
        this.b = str;
        this.c = context;
        this.e = zzang;
        this.d = new agb(new h(this));
        this.Q = new lf(200);
        this.v = new m<>();
    }

    private final void b(boolean z2) {
        View findViewById;
        if (this.f != null && this.j != null && this.j.b != null && this.j.b.v() != null) {
            if (!z2 || this.Q.a()) {
                if (this.j.b.v().b()) {
                    int[] iArr = new int[2];
                    this.f.getLocationOnScreen(iArr);
                    ans.a();
                    int b2 = lp.b(this.c, iArr[0]);
                    ans.a();
                    int b3 = lp.b(this.c, iArr[1]);
                    if (!(b2 == this.O && b3 == this.P)) {
                        this.O = b2;
                        this.P = b3;
                        this.j.b.v().a(this.O, this.P, !z2);
                    }
                }
                if (this.f != null && (findViewById = this.f.getRootView().findViewById(16908290)) != null) {
                    Rect rect = new Rect();
                    Rect rect2 = new Rect();
                    this.f.getGlobalVisibleRect(rect);
                    findViewById.getGlobalVisibleRect(rect2);
                    if (rect.top != rect2.top) {
                        this.L = false;
                    }
                    if (rect.bottom != rect2.bottom) {
                        this.M = false;
                    }
                }
            }
        }
    }

    public final void a() {
        if (this.j != null && this.j.b != null) {
            this.j.b.destroy();
        }
    }

    /* access modifiers changed from: package-private */
    public final void a(View view) {
        afx afx;
        if (((Boolean) ans.f().a(aqs.bG)).booleanValue() && (afx = this.d.b) != null) {
            afx.a(view);
        }
    }

    public final void a(boolean z2) {
        if (!(this.I != 0 || this.j == null || this.j.b == null)) {
            this.j.b.stopLoading();
        }
        if (this.g != null) {
            this.g.b();
        }
        if (this.h != null) {
            this.h.b();
        }
        if (z2) {
            this.j = null;
        }
    }

    public final void b() {
        if (this.j != null && this.j.p != null) {
            try {
                this.j.p.c();
            } catch (RemoteException unused) {
                iy.b("Could not destroy mediation adapter.");
            }
        }
    }

    public final boolean c() {
        return this.I == 0;
    }

    public final boolean d() {
        return this.I == 1;
    }

    public final void onGlobalLayout() {
        b(false);
    }

    public final void onScrollChanged() {
        b(true);
        this.N = true;
    }
}
