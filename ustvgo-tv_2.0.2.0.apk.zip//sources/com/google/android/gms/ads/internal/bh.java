package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;

final class bh implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ie f1232a;
    private final /* synthetic */ bf b;

    bh(bf bfVar, ie ieVar) {
        this.b = bfVar;
        this.f1232a = ieVar;
    }

    public final void run() {
        this.b.b(new id(this.f1232a));
    }
}
