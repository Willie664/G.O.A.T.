package com.google.android.gms.ads.internal.gmsg;

import android.content.Context;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.internal.ads.cj;
import java.util.Map;

@cj
public final class c implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1258a;

    public c(Context context) {
        this.f1258a = context;
    }

    public final void zza(Object obj, Map<String, String> map) {
        if (aw.B().a(this.f1258a)) {
            aw.B().a(this.f1258a, map.get("eventName"), map.get("eventId"));
        }
    }
}
