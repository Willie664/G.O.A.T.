package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.pu;

@cj
public final class h {

    /* renamed from: a  reason: collision with root package name */
    public final int f1283a;
    public final ViewGroup.LayoutParams b;
    public final ViewGroup c;
    public final Context d;

    public h(pu puVar) {
        this.b = puVar.getLayoutParams();
        ViewParent parent = puVar.getParent();
        this.d = puVar.q();
        if (parent == null || !(parent instanceof ViewGroup)) {
            throw new f("Could not get the parent of the WebView for an overlay.");
        }
        this.c = (ViewGroup) parent;
        this.f1283a = this.c.indexOfChild(puVar.getView());
        this.c.removeView(puVar.getView());
        puVar.b(true);
    }
}
