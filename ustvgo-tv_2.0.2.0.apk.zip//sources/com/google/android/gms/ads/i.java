package com.google.android.gms.ads;

import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.zzmu;

@cj
public final class i {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1201a;
    public final boolean b;
    public final boolean c;

    public i(zzmu zzmu) {
        this.f1201a = zzmu.f2403a;
        this.b = zzmu.b;
        this.c = zzmu.c;
    }
}
