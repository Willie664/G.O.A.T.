package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

public interface MediationNativeAdapter extends b {
    void requestNativeAd(Context context, e eVar, Bundle bundle, i iVar, Bundle bundle2);
}
