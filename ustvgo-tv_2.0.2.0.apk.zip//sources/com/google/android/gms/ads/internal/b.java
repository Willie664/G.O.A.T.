package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.ajk;
import com.google.android.gms.internal.ads.ajo;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.rf;

final /* synthetic */ class b implements rf {

    /* renamed from: a  reason: collision with root package name */
    private final ajk f1226a;
    private final id b;

    b(ajk ajk, id idVar) {
        this.f1226a = ajk;
        this.b = idVar;
    }

    public final void a() {
        this.f1226a.a((ajo) this.b.b);
    }
}
