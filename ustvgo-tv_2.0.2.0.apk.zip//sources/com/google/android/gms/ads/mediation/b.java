package com.google.android.gms.ads.mediation;

public interface b {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public int f1300a;
    }

    void onDestroy();

    void onPause();

    void onResume();
}
