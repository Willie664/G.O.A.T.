package com.google.android.gms.ads.internal.overlay;

import android.graphics.drawable.Drawable;

final class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ Drawable f1285a;
    private final /* synthetic */ i b;

    j(i iVar, Drawable drawable) {
        this.b = iVar;
        this.f1285a = drawable;
    }

    public final void run() {
        this.b.f1284a.f1279a.getWindow().setBackgroundDrawable(this.f1285a);
    }
}
