package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.i;
import com.google.android.gms.internal.ads.cj;

@cj
public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1197a;
    public final int b;
    public final boolean c;
    public final int d;
    public final i e;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public boolean f1198a = false;
        public int b = -1;
        public boolean c = false;
        public i d;
        public int e = 1;

        public final b a() {
            return new b(this, (byte) 0);
        }
    }

    private b(a aVar) {
        this.f1197a = aVar.f1198a;
        this.b = aVar.b;
        this.c = aVar.c;
        this.d = aVar.e;
        this.e = aVar.d;
    }

    /* synthetic */ b(a aVar, byte b2) {
        this(aVar);
    }
}
