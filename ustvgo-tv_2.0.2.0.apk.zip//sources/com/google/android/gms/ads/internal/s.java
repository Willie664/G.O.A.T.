package com.google.android.gms.ads.internal;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.atf;
import com.google.android.gms.internal.ads.atg;
import com.google.android.gms.internal.ads.bbh;
import com.google.android.gms.internal.ads.bbl;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public final class s {
    public static View a(id idVar) {
        if (idVar == null) {
            iy.a("AdState is null");
            return null;
        } else if (b(idVar) && idVar.b != null) {
            return idVar.b.getView();
        } else {
            try {
                a a2 = idVar.p != null ? idVar.p.a() : null;
                if (a2 != null) {
                    return (View) b.a(a2);
                }
                iy.b("View in mediation adapter is null.");
                return null;
            } catch (RemoteException e) {
                iy.b("Could not get View from mediation adapter.", e);
                return null;
            }
        }
    }

    static ae<pu> a(bbh bbh, bbl bbl, d dVar) {
        return new x(bbh, dVar, bbl);
    }

    static atf a(Object obj) {
        if (obj instanceof IBinder) {
            return atg.a((IBinder) obj);
        }
        return null;
    }

    private static String a(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (bitmap == null) {
            iy.b("Bitmap is null. Returning empty string");
            return "";
        }
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
        String valueOf = String.valueOf("data:image/png;base64,");
        String valueOf2 = String.valueOf(encodeToString);
        return valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
    }

    static String a(atf atf) {
        if (atf == null) {
            iy.b("Image is null. Returning empty string");
            return "";
        }
        try {
            Uri b = atf.b();
            if (b != null) {
                return b.toString();
            }
        } catch (RemoteException unused) {
            iy.b("Unable to get image uri. Trying data uri next");
        }
        return b(atf);
    }

    static JSONObject a(Bundle bundle, String str) {
        String valueOf;
        String str2;
        JSONObject jSONObject = new JSONObject();
        if (bundle != null && !TextUtils.isEmpty(str)) {
            JSONObject jSONObject2 = new JSONObject(str);
            Iterator<String> keys = jSONObject2.keys();
            while (keys.hasNext()) {
                String next = keys.next();
                if (bundle.containsKey(next)) {
                    if ("image".equals(jSONObject2.getString(next))) {
                        Object obj = bundle.get(next);
                        if (obj instanceof Bitmap) {
                            valueOf = a((Bitmap) obj);
                        } else {
                            str2 = "Invalid type. An image type extra should return a bitmap";
                            iy.b(str2);
                        }
                    } else if (bundle.get(next) instanceof Bitmap) {
                        str2 = "Invalid asset type. Bitmap should be returned only for image type";
                        iy.b(str2);
                    } else {
                        valueOf = String.valueOf(bundle.get(next));
                    }
                    jSONObject.put(next, valueOf);
                }
            }
        }
        return jSONObject;
    }

    static /* synthetic */ void a(pu puVar) {
        View.OnClickListener onClickListener = puVar.getOnClickListener();
        if (onClickListener != null) {
            onClickListener.onClick(puVar.getView());
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v11, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v2, resolved type: android.view.View} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v10, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v6, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0134  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean a(com.google.android.gms.internal.ads.pu r25, com.google.android.gms.internal.ads.bam r26, java.util.concurrent.CountDownLatch r27) {
        /*
            r0 = r25
            r1 = r26
            r7 = r27
            r8 = 0
            android.view.View r2 = r25.getView()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r2 != 0) goto L_0x0014
            java.lang.String r0 = "AdWebView is null"
        L_0x000f:
            com.google.android.gms.internal.ads.iy.b(r0)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            goto L_0x0132
        L_0x0014:
            r3 = 4
            r2.setVisibility(r3)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bae r2 = r1.b     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.util.List<java.lang.String> r2 = r2.r     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r2 == 0) goto L_0x0123
            boolean r3 = r2.isEmpty()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r3 == 0) goto L_0x0026
            goto L_0x0123
        L_0x0026:
            java.lang.String r3 = "/nativeExpressAssetsLoaded"
            com.google.android.gms.ads.internal.v r4 = new com.google.android.gms.ads.internal.v     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r4.<init>(r7)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r0.a((java.lang.String) r3, (com.google.android.gms.ads.internal.gmsg.ae<? super com.google.android.gms.internal.ads.pu>) r4)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r3 = "/nativeExpressAssetsLoadingFailed"
            com.google.android.gms.ads.internal.w r4 = new com.google.android.gms.ads.internal.w     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r4.<init>(r7)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r0.a((java.lang.String) r3, (com.google.android.gms.ads.internal.gmsg.ae<? super com.google.android.gms.internal.ads.pu>) r4)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bay r3 = r1.c     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bbh r3 = r3.h()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bay r4 = r1.c     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bbl r4 = r4.i()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r5 = "2"
            boolean r5 = r2.contains(r5)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r6 = 0
            if (r5 == 0) goto L_0x00a9
            if (r3 == 0) goto L_0x00a9
            com.google.android.gms.internal.ads.arx r2 = new com.google.android.gms.internal.ads.arx     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r10 = r3.a()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.util.List r11 = r3.b()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r12 = r3.c()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.atf r13 = r3.d()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r14 = r3.e()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            double r15 = r3.f()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r17 = r3.g()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r18 = r3.h()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r19 = 0
            android.os.Bundle r20 = r3.l()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r21 = 0
            com.google.android.gms.b.a r4 = r3.p()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r4 == 0) goto L_0x008c
            com.google.android.gms.b.a r4 = r3.p()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.Object r4 = com.google.android.gms.b.b.a((com.google.android.gms.b.a) r4)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r6 = r4
            android.view.View r6 = (android.view.View) r6     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
        L_0x008c:
            r22 = r6
            com.google.android.gms.b.a r23 = r3.q()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r24 = 0
            r9 = r2
            r9.<init>(r10, r11, r12, r13, r14, r15, r17, r18, r19, r20, r21, r22, r23, r24)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bae r3 = r1.b     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r3 = r3.q     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.rc r4 = r25.v()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.ads.internal.t r5 = new com.google.android.gms.ads.internal.t     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r5.<init>(r2, r3, r0)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
        L_0x00a5:
            r4.a((com.google.android.gms.internal.ads.rd) r5)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            goto L_0x0100
        L_0x00a9:
            java.lang.String r3 = "1"
            boolean r2 = r2.contains(r3)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r2 == 0) goto L_0x011f
            if (r4 == 0) goto L_0x011f
            com.google.android.gms.internal.ads.arz r2 = new com.google.android.gms.internal.ads.arz     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r10 = r4.a()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.util.List r11 = r4.b()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r12 = r4.c()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.atf r13 = r4.d()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r14 = r4.e()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r15 = r4.f()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r16 = 0
            android.os.Bundle r17 = r4.j()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r18 = 0
            com.google.android.gms.b.a r3 = r4.n()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r3 == 0) goto L_0x00e6
            com.google.android.gms.b.a r3 = r4.n()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.Object r3 = com.google.android.gms.b.b.a((com.google.android.gms.b.a) r3)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r6 = r3
            android.view.View r6 = (android.view.View) r6     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
        L_0x00e6:
            r19 = r6
            com.google.android.gms.b.a r20 = r4.o()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r21 = 0
            r9 = r2
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bae r3 = r1.b     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r3 = r3.q     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.rc r4 = r25.v()     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.ads.internal.u r5 = new com.google.android.gms.ads.internal.u     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            r5.<init>(r2, r3, r0)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            goto L_0x00a5
        L_0x0100:
            com.google.android.gms.internal.ads.bae r2 = r1.b     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r3 = r2.o     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            com.google.android.gms.internal.ads.bae r1 = r1.b     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            java.lang.String r2 = r1.p     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            if (r2 == 0) goto L_0x0115
            java.lang.String r4 = "text/html"
            java.lang.String r5 = "UTF-8"
            r6 = 0
            r1 = r25
            r1.loadDataWithBaseURL(r2, r3, r4, r5, r6)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
            goto L_0x011c
        L_0x0115:
            java.lang.String r1 = "text/html"
            java.lang.String r2 = "UTF-8"
            r0.loadData(r3, r1, r2)     // Catch:{ RemoteException -> 0x012c, RuntimeException -> 0x0127 }
        L_0x011c:
            r0 = 1
            r8 = 1
            goto L_0x0132
        L_0x011f:
            java.lang.String r0 = "No matching template id and mapper"
            goto L_0x000f
        L_0x0123:
            java.lang.String r0 = "No template ids present in mediation response"
            goto L_0x000f
        L_0x0127:
            r0 = move-exception
            r27.countDown()
            throw r0
        L_0x012c:
            r0 = move-exception
            java.lang.String r1 = "Unable to invoke load assets"
            com.google.android.gms.internal.ads.iy.b(r1, r0)
        L_0x0132:
            if (r8 != 0) goto L_0x0137
            r27.countDown()
        L_0x0137:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.s.a(com.google.android.gms.internal.ads.pu, com.google.android.gms.internal.ads.bam, java.util.concurrent.CountDownLatch):boolean");
    }

    private static String b(atf atf) {
        try {
            a a2 = atf.a();
            if (a2 == null) {
                iy.b("Drawable is null. Returning empty string");
                return "";
            }
            Drawable drawable = (Drawable) b.a(a2);
            if (drawable instanceof BitmapDrawable) {
                return a(((BitmapDrawable) drawable).getBitmap());
            }
            iy.b("Drawable is not an instance of BitmapDrawable. Returning empty string");
            return "";
        } catch (RemoteException unused) {
            iy.b("Unable to get drawable. Returning empty string");
            return "";
        }
    }

    public static boolean b(id idVar) {
        return (idVar == null || !idVar.n || idVar.o == null || idVar.o.o == null) ? false : true;
    }
}
