package com.google.android.gms.ads.internal.overlay;

final class o {

    /* renamed from: a  reason: collision with root package name */
    public int f1287a = 0;
    public int b = 0;
    public int c = 0;
    public int d = 0;
    public int e = 32;

    o() {
    }
}
