package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.RelativeLayout;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.jz;

@cj
final class g extends RelativeLayout {

    /* renamed from: a  reason: collision with root package name */
    boolean f1282a;
    private jz b;

    public g(Context context, String str, String str2) {
        super(context);
        this.b = new jz(context, str);
        this.b.d = str2;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.f1282a) {
            return false;
        }
        this.b.a(motionEvent);
        return false;
    }
}
