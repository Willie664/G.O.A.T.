package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import com.google.android.gms.internal.ads.cj;

@cj
public final class p extends c {
    public p(Activity activity) {
        super(activity);
    }
}
