package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class ac implements ae<pu> {
    ac() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        if (map.keySet().contains("start")) {
            puVar.v().h();
        } else if (map.keySet().contains("stop")) {
            puVar.v().i();
        } else if (map.keySet().contains("cancel")) {
            puVar.v().j();
        }
    }
}
