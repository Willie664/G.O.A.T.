package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.ma;
import org.json.JSONObject;

final class ag implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ JSONObject f1255a;
    private final /* synthetic */ af b;

    ag(af afVar, JSONObject jSONObject) {
        this.b = afVar;
        this.f1255a = jSONObject;
    }

    public final void run() {
        this.b.f1254a.a("fetchHttpRequestCompleted", this.f1255a);
        ma.a(3);
    }
}
