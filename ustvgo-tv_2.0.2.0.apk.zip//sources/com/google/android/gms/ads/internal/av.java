package com.google.android.gms.ads.internal;

import java.util.Map;
import java.util.TreeMap;

final class av {

    /* renamed from: a  reason: collision with root package name */
    final String f1221a;
    final Map<String, String> b = new TreeMap();
    String c;
    String d;

    public av(String str) {
        this.f1221a = str;
    }
}
