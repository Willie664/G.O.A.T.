package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewParent;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.internal.gmsg.k;
import com.google.android.gms.ads.internal.gmsg.m;
import com.google.android.gms.ads.internal.overlay.s;
import com.google.android.gms.b.b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.util.i;
import com.google.android.gms.internal.ads.Cif;
import com.google.android.gms.internal.ads.ad;
import com.google.android.gms.internal.ads.aim;
import com.google.android.gms.internal.ads.ain;
import com.google.android.gms.internal.ads.akc;
import com.google.android.gms.internal.ads.akd;
import com.google.android.gms.internal.ads.ala;
import com.google.android.gms.internal.ads.aln;
import com.google.android.gms.internal.ads.alo;
import com.google.android.gms.internal.ads.alp;
import com.google.android.gms.internal.ads.am;
import com.google.android.gms.internal.ads.amz;
import com.google.android.gms.internal.ads.anf;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.anv;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aok;
import com.google.android.gms.internal.ads.aoo;
import com.google.android.gms.internal.ads.aos;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.apg;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.ard;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.cl;
import com.google.android.gms.internal.ads.fn;
import com.google.android.gms.internal.ads.fs;
import com.google.android.gms.internal.ads.fv;
import com.google.android.gms.internal.ads.gd;
import com.google.android.gms.internal.ads.hx;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.ig;
import com.google.android.gms.internal.ads.in;
import com.google.android.gms.internal.ads.io;
import com.google.android.gms.internal.ads.iq;
import com.google.android.gms.internal.ads.ir;
import com.google.android.gms.internal.ads.iv;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.lp;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.o;
import com.google.android.gms.internal.ads.ri;
import com.google.android.gms.internal.ads.x;
import com.google.android.gms.internal.ads.zzaig;
import com.google.android.gms.internal.ads.zzakp;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzlu;
import com.google.android.gms.internal.ads.zzms;
import com.google.android.gms.internal.ads.zzmu;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Timer;
import java.util.concurrent.CountDownLatch;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONException;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public abstract class a extends aok implements k, m, s, am, amz, cl, io {

    /* renamed from: a  reason: collision with root package name */
    protected arf f1202a;
    protected ard b;
    protected boolean c = false;
    protected final am d;
    protected final ax e;
    protected transient zzjj f;
    protected final aim g;
    protected com.google.android.gms.b.a h;
    protected final bt i;
    private ard j;
    private final Bundle k = new Bundle();
    private boolean l = false;

    a(ax axVar, bt btVar) {
        this.e = axVar;
        this.d = new am(this);
        this.i = btVar;
        jh e2 = aw.e();
        Context context = this.e.c;
        if (!e2.b) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.USER_PRESENT");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            context.getApplicationContext().registerReceiver(new zzakp(e2, (byte) 0), intentFilter);
            e2.b = true;
        }
        aw.e().b(this.e.c);
        iv.a(this.e.c);
        aw.C().a(this.e.c);
        aw.i().a(this.e.c, this.e.e);
        aw.k().a(this.e.c);
        this.g = aw.i().b;
        akc h2 = aw.h();
        Context context2 = this.e.c;
        synchronized (h2.f1717a) {
            if (!h2.c) {
                if (((Boolean) ans.f().a(aqs.aG)).booleanValue()) {
                    Application application = null;
                    Context applicationContext = context2.getApplicationContext();
                    applicationContext = applicationContext == null ? context2 : applicationContext;
                    application = applicationContext instanceof Application ? (Application) applicationContext : application;
                    if (application == null) {
                        iy.b("Can not cast Context to Application");
                    } else {
                        if (h2.b == null) {
                            h2.b = new akd();
                        }
                        akd akd = h2.b;
                        if (!akd.c) {
                            application.registerActivityLifecycleCallbacks(akd);
                            if (context2 instanceof Activity) {
                                akd.a((Activity) context2);
                            }
                            akd.b = application;
                            akd.d = ((Long) ans.f().a(aqs.aH)).longValue();
                            akd.c = true;
                        }
                        h2.c = true;
                    }
                }
            }
        }
        aw.E().a(this.e.c);
        if (((Boolean) ans.f().a(aqs.cn)).booleanValue()) {
            Timer timer = new Timer();
            timer.schedule(new aa(this, new CountDownLatch(((Integer) ans.f().a(aqs.cp)).intValue()), timer), 0, ((Long) ans.f().a(aqs.co)).longValue());
        }
    }

    protected static boolean a(zzjj zzjj) {
        Bundle bundle = zzjj.m.getBundle("com.google.ads.mediation.admob.AdMobAdapter");
        return bundle == null || !bundle.containsKey("gw");
    }

    private static long b(String str) {
        int indexOf = str.indexOf("ufe");
        int indexOf2 = str.indexOf(44, indexOf);
        if (indexOf2 == -1) {
            indexOf2 = str.length();
        }
        try {
            return Long.parseLong(str.substring(indexOf + 4, indexOf2));
        } catch (IndexOutOfBoundsException | NumberFormatException e2) {
            ma.a("", e2);
            return -1;
        }
    }

    /* access modifiers changed from: protected */
    public final void A() {
        if (this.e.C != null) {
            try {
                this.e.C.c();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void B() {
        if (this.e.C != null) {
            try {
                this.e.C.f();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    public final void C() {
        id idVar = this.e.j;
        if (idVar != null && !TextUtils.isEmpty(idVar.B) && !idVar.I && aw.o().b()) {
            ma.a(3);
            aw.o().a(this.e.c, this.e.e.f2393a, idVar.B, this.e.b);
            idVar.I = true;
        }
    }

    public String D() {
        return this.e.b;
    }

    public final aos E() {
        return this.e.o;
    }

    public final any F() {
        return this.e.n;
    }

    /* access modifiers changed from: protected */
    public final void G() {
        if (this.h != null) {
            o u = aw.u();
            com.google.android.gms.b.a aVar = this.h;
            synchronized (o.f2213a) {
                if (((Boolean) ans.f().a(aqs.dg)).booleanValue()) {
                    if (o.b) {
                        try {
                            u.c.c(aVar);
                        } catch (RemoteException | NullPointerException e2) {
                            ma.c("#007 Could not call remote method.", e2);
                        }
                    }
                }
            }
            this.h = null;
        }
    }

    /* access modifiers changed from: protected */
    public final String H() {
        ie ieVar = this.e.k;
        if (ieVar == null || ieVar.b == null) {
            return "javascript";
        }
        String str = ieVar.b.T;
        if (TextUtils.isEmpty(str)) {
            return "javascript";
        }
        try {
            if (new JSONObject(str).optInt("media_type", -1) == 0) {
                return null;
            }
            return "javascript";
        } catch (JSONException e2) {
            ma.b("", e2);
            return "javascript";
        }
    }

    /* access modifiers changed from: protected */
    public final List<String> a(List<String> list) {
        String i2;
        ArrayList arrayList = new ArrayList(list.size());
        for (String next : list) {
            Context context = this.e.c;
            if (aw.B().a(context) && !TextUtils.isEmpty(next) && (i2 = aw.B().i(context)) != null && aw.e().e(next)) {
                if (((Boolean) ans.f().a(aqs.at)).booleanValue()) {
                    String str = (String) ans.f().a(aqs.au);
                    if (next.contains(str)) {
                        next = next.replace(str, i2);
                    }
                } else if (!next.contains("fbs_aeid")) {
                    next = hx.a(next, "fbs_aeid", i2).toString();
                }
            }
            arrayList.add(next);
        }
        return arrayList;
    }

    public void a(int i2) {
        a(i2, false);
    }

    /* access modifiers changed from: protected */
    public void a(int i2, boolean z) {
        StringBuilder sb = new StringBuilder(30);
        sb.append("Failed to load ad: ");
        sb.append(i2);
        iy.b(sb.toString());
        this.c = z;
        if (this.e.n != null) {
            try {
                this.e.n.a(i2);
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
        if (this.e.C != null) {
            try {
                this.e.C.a(i2);
            } catch (RemoteException e3) {
                iy.c("#007 Could not call remote method.", e3);
            }
        }
    }

    public final void a(Bundle bundle) {
        this.k.putAll(bundle);
        if (this.l && this.e.p != null) {
            try {
                this.e.p.a();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void a(View view) {
        ay ayVar = this.e.f;
        if (ayVar != null) {
            ayVar.addView(view, aw.g().d());
        }
    }

    public final void a(ad adVar, String str) {
        iy.b("#006 Unexpected call to a deprecated method.");
    }

    public final void a(anv anv) {
        ab.b("#008 Must be called on the main UI thread.: setAdClickListener");
        this.e.m = anv;
    }

    public final void a(any any) {
        ab.b("#008 Must be called on the main UI thread.: setAdListener");
        this.e.n = any;
    }

    public final void a(aoo aoo) {
        this.e.p = aoo;
    }

    public final void a(aos aos) {
        ab.b("#008 Must be called on the main UI thread.: setAppEventListener");
        this.e.o = aos;
    }

    public final void a(aoy aoy) {
        ab.b("#008 Must be called on the main UI thread.: setCorrelationIdProvider");
        this.e.q = aoy;
    }

    public final void a(ard ard) {
        this.f1202a = new arf(((Boolean) ans.f().a(aqs.N)).booleanValue(), "load_ad", this.e.i.f2399a);
        this.j = new ard(-1, (String) null, (ard) null);
        if (ard == null) {
            this.b = new ard(-1, (String) null, (ard) null);
        } else {
            this.b = new ard(ard.f1817a, ard.b, ard.c);
        }
    }

    public void a(arm arm) {
        throw new IllegalStateException("#005 Unexpected call to an abstract (unimplemented) method.");
    }

    public final void a(fv fvVar) {
        ab.b("#008 Must be called on the main UI thread.: setRewardedAdSkuListener");
        this.e.D = fvVar;
    }

    public final void a(gd gdVar) {
        ab.b("#008 Must be called on the main UI thread.: setRewardedVideoAdListener");
        this.e.C = gdVar;
    }

    public final void a(ie ieVar) {
        if (ieVar.b.m != -1 && !TextUtils.isEmpty(ieVar.b.w)) {
            long b2 = b(ieVar.b.w);
            if (b2 != -1) {
                ard a2 = this.f1202a.a(ieVar.b.m + b2);
                this.f1202a.a(a2, "stc");
            }
        }
        arf arf = this.f1202a;
        String str = ieVar.b.w;
        if (arf.f1819a) {
            synchronized (arf.b) {
                arf.c = str;
            }
        }
        this.f1202a.a(this.b, "arf");
        this.j = this.f1202a.a();
        this.f1202a.a("gqi", ieVar.b.x);
        this.e.g = null;
        this.e.k = ieVar;
        ieVar.i.a((alo) new az(ieVar));
        ieVar.i.a(alp.a.b.AD_LOADED);
        a(ieVar, this.f1202a);
    }

    /* access modifiers changed from: protected */
    public abstract void a(ie ieVar, arf arf);

    public void a(x xVar) {
        iy.b("#006 Unexpected call to a deprecated method.");
    }

    public final void a(zzjn zzjn) {
        ab.b("#008 Must be called on the main UI thread.: setAdSize");
        this.e.i = zzjn;
        if (!(this.e.j == null || this.e.j.b == null || this.e.I != 0)) {
            this.e.j.b.a(ri.a(zzjn));
        }
        if (this.e.f != null) {
            if (this.e.f.getChildCount() > 1) {
                this.e.f.removeView(this.e.f.getNextView());
            }
            this.e.f.setMinimumWidth(zzjn.f);
            this.e.f.setMinimumHeight(zzjn.c);
            this.e.f.requestLayout();
        }
    }

    public final void a(zzlu zzlu) {
        ab.b("#008 Must be called on the main UI thread.: setIconAdOptions");
        this.e.y = zzlu;
    }

    public final void a(zzmu zzmu) {
        ab.b("#008 Must be called on the main UI thread.: setVideoOptions");
        this.e.x = zzmu;
    }

    public final void a(String str) {
        ab.b("#008 Must be called on the main UI thread.: setUserId");
        this.e.E = str;
    }

    public final void a(String str, String str2) {
        if (this.e.o != null) {
            try {
                this.e.o.a(str, str2);
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    public final void a(HashSet<Cif> hashSet) {
        this.e.K = hashSet;
    }

    /* access modifiers changed from: package-private */
    public boolean a(id idVar) {
        return false;
    }

    /* access modifiers changed from: protected */
    public abstract boolean a(id idVar, id idVar2);

    /* access modifiers changed from: protected */
    public abstract boolean a(zzjj zzjj, arf arf);

    /* access modifiers changed from: protected */
    public final List<String> b(List<String> list) {
        ArrayList arrayList = new ArrayList(list.size());
        for (String a2 : list) {
            arrayList.add(hx.a(a2, this.e.c));
        }
        return arrayList;
    }

    public void b(id idVar) {
        aln aln;
        alp.a.b bVar;
        this.f1202a.a(this.j, "awr");
        this.e.h = null;
        if (!(idVar.d == -2 || idVar.d == 3 || this.e.K == null)) {
            ir j2 = aw.j();
            HashSet<Cif> hashSet = this.e.K;
            synchronized (j2.f2118a) {
                j2.c.addAll(hashSet);
            }
        }
        if (idVar.d == -1) {
            this.c = false;
            return;
        }
        if (a(idVar)) {
            ma.a(3);
        }
        if (idVar.d != -2) {
            if (idVar.d == 3) {
                aln = idVar.K;
                bVar = alp.a.b.AD_FAILED_TO_LOAD_NO_FILL;
            } else {
                aln = idVar.K;
                bVar = alp.a.b.AD_FAILED_TO_LOAD;
            }
            aln.a(bVar);
            a(idVar.d);
            return;
        }
        if (this.e.G == null) {
            this.e.G = new iq(this.e.b);
        }
        if (this.e.f != null) {
            this.e.f.f1224a.e = idVar.B;
        }
        this.g.a(this.e.j);
        if (a(this.e.j, idVar)) {
            this.e.j = idVar;
            ax axVar = this.e;
            if (axVar.l != null) {
                if (axVar.j != null) {
                    Cif ifVar = axVar.l;
                    long j3 = axVar.j.y;
                    synchronized (ifVar.c) {
                        ifVar.j = j3;
                        if (ifVar.j != -1) {
                            ifVar.f2107a.a(ifVar);
                        }
                    }
                    Cif ifVar2 = axVar.l;
                    long j4 = axVar.j.z;
                    synchronized (ifVar2.c) {
                        if (ifVar2.j != -1) {
                            ifVar2.d = j4;
                            ifVar2.f2107a.a(ifVar2);
                        }
                    }
                    Cif ifVar3 = axVar.l;
                    boolean z = axVar.j.n;
                    synchronized (ifVar3.c) {
                        if (ifVar3.j != -1) {
                            ifVar3.f = z;
                            ifVar3.f2107a.a(ifVar3);
                        }
                    }
                }
                Cif ifVar4 = axVar.l;
                boolean z2 = axVar.i.d;
                synchronized (ifVar4.c) {
                    if (ifVar4.j != -1) {
                        ifVar4.g = SystemClock.elapsedRealtime();
                        if (!z2) {
                            ifVar4.e = ifVar4.g;
                            ifVar4.f2107a.a(ifVar4);
                        }
                    }
                }
            }
            this.f1202a.a("is_mraid", this.e.j.a() ? "1" : "0");
            this.f1202a.a("is_mediation", this.e.j.n ? "1" : "0");
            if (!(this.e.j.b == null || this.e.j.b.v() == null)) {
                this.f1202a.a("is_delay_pl", this.e.j.b.v().f() ? "1" : "0");
            }
            this.f1202a.a(this.b, "ttc");
            if (aw.i().a() != null) {
                aw.i().a().a(this.f1202a);
            }
            C();
            if (this.e.c()) {
                x();
            }
        }
        if (idVar.J != null) {
            aw.e();
            jh.a(this.e.c, idVar.J);
        }
    }

    /* access modifiers changed from: protected */
    public final void b(zzaig zzaig) {
        if (this.e.C != null) {
            String str = "";
            int i2 = 1;
            if (zzaig != null) {
                try {
                    str = zzaig.f2390a;
                    i2 = zzaig.b;
                } catch (RemoteException e2) {
                    iy.c("#007 Could not call remote method.", e2);
                    return;
                }
            }
            fn fnVar = new fn(str, i2);
            this.e.C.a((fs) fnVar);
            if (this.e.D != null) {
                this.e.D.a(fnVar, this.e.k.f2106a.v);
            }
        }
    }

    public void b(boolean z) {
        iy.b("Attempt to call setManualImpressionsEnabled for an unsupported ad type.");
    }

    public boolean b(zzjj zzjj) {
        zzjj zzjj2;
        ab.b("#008 Must be called on the main UI thread.: loadAd");
        ala k2 = aw.k();
        if (((Boolean) ans.f().a(aqs.cF)).booleanValue()) {
            synchronized (k2.b) {
                k2.a();
                aw.e();
                jh.f2130a.removeCallbacks(k2.f1733a);
                aw.e();
                jh.f2130a.postDelayed(k2.f1733a, ((Long) ans.f().a(aqs.cG)).longValue());
            }
        }
        this.k.clear();
        this.l = false;
        if (((Boolean) ans.f().a(aqs.aN)).booleanValue()) {
            zzjj2 = zzjj.a();
            if (((Boolean) ans.f().a(aqs.aO)).booleanValue()) {
                zzjj2.c.putBoolean(AdMobAdapter.NEW_BUNDLE, true);
            }
        } else {
            zzjj2 = zzjj;
        }
        if (i.c(this.e.c) && zzjj2.k != null) {
            anf anf = new anf(zzjj2);
            anf.j = null;
            zzjj2 = new zzjj(7, anf.f1776a, anf.b, anf.c, anf.d, anf.e, anf.f, anf.g, anf.h, anf.i, anf.j, anf.k, anf.l, anf.m, anf.n, anf.o, anf.p, false);
        }
        if (this.e.g == null && this.e.h == null) {
            ma.a(4);
            a((ard) null);
            this.b = this.f1202a.a();
            if (!zzjj2.f) {
                ans.a();
                String a2 = lp.a(this.e.c);
                StringBuilder sb = new StringBuilder(String.valueOf(a2).length() + 71);
                sb.append("Use AdRequest.Builder.addTestDevice(\"");
                sb.append(a2);
                sb.append("\") to get test ads on this device.");
            }
            ma.a(4);
            this.d.f1213a = zzjj2;
            this.c = a(zzjj2, this.f1202a);
            return this.c;
        }
        iy.b(this.f != null ? "Aborting last ad request since another ad request is already in progress. The current request object will still be cached for future refreshes." : "Loading already in progress, saving this object for future refreshes.");
        this.f = zzjj2;
        return false;
    }

    public void c(boolean z) {
        throw new IllegalStateException("#005 Unexpected call to an abstract (unimplemented) method.");
    }

    /* access modifiers changed from: protected */
    public boolean c(zzjj zzjj) {
        if (this.e.f == null) {
            return false;
        }
        ViewParent parent = this.e.f.getParent();
        if (!(parent instanceof View)) {
            return false;
        }
        View view = (View) parent;
        aw.e();
        return jh.a(view, view.getContext());
    }

    /* access modifiers changed from: protected */
    public void d(boolean z) {
        iy.a();
        this.c = z;
        this.l = true;
        if (this.e.n != null) {
            try {
                this.e.n.c();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
        if (this.e.C != null) {
            try {
                this.e.C.a();
            } catch (RemoteException e3) {
                iy.c("#007 Could not call remote method.", e3);
            }
        }
        if (this.e.p != null) {
            try {
                this.e.p.a();
            } catch (RemoteException e4) {
                iy.c("#007 Could not call remote method.", e4);
            }
        }
    }

    public void e() {
        if (this.e.j == null) {
            iy.b("Ad state was null when trying to ping click URLs.");
            return;
        }
        ma.a(3);
        if (this.e.l != null) {
            Cif ifVar = this.e.l;
            synchronized (ifVar.c) {
                if (ifVar.j != -1) {
                    ig igVar = new ig();
                    igVar.f2108a = SystemClock.elapsedRealtime();
                    ifVar.b.add(igVar);
                    ifVar.h++;
                    ir irVar = ifVar.f2107a;
                    synchronized (irVar.f2118a) {
                        in inVar = irVar.b;
                        synchronized (inVar.f) {
                            inVar.g++;
                        }
                    }
                    ifVar.f2107a.a(ifVar);
                }
            }
        }
        if (this.e.j.c != null) {
            aw.e();
            jh.a(this.e.c, this.e.e.f2393a, b(this.e.j.c));
        }
        if (this.e.m != null) {
            try {
                this.e.m.a();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    public final void h() {
        v();
    }

    public final bt i() {
        return this.i;
    }

    public void j() {
        ab.b("#008 Must be called on the main UI thread.: destroy");
        this.d.a();
        aim aim = this.g;
        id idVar = this.e.j;
        synchronized (aim.f1679a) {
            ain ain = aim.b.get(idVar);
            if (ain != null) {
                ain.e();
            }
        }
        ax axVar = this.e;
        if (axVar.f != null) {
            ay ayVar = axVar.f;
            iy.a();
            if (ayVar.b != null) {
                ayVar.b.b();
            }
        }
        axVar.n = null;
        axVar.p = null;
        axVar.o = null;
        axVar.B = null;
        axVar.q = null;
        axVar.a(false);
        if (axVar.f != null) {
            axVar.f.removeAllViews();
        }
        axVar.a();
        axVar.b();
        axVar.j = null;
    }

    public final com.google.android.gms.b.a k() {
        ab.b("#008 Must be called on the main UI thread.: getAdFrame");
        return b.a(this.e.f);
    }

    public final zzjn l() {
        ab.b("#008 Must be called on the main UI thread.: getAdSize");
        if (this.e.i == null) {
            return null;
        }
        return new zzms(this.e.i);
    }

    public final boolean m() {
        ab.b("#008 Must be called on the main UI thread.: isLoaded");
        return this.e.g == null && this.e.h == null && this.e.j != null;
    }

    public final void n() {
        ab.b("#008 Must be called on the main UI thread.: recordManualImpression");
        if (this.e.j == null) {
            iy.b("Ad state was null when trying to ping manual tracking URLs.");
            return;
        }
        ma.a(3);
        if (!this.e.j.H) {
            ArrayList arrayList = new ArrayList();
            if (this.e.j.g != null) {
                arrayList.addAll(this.e.j.g);
            }
            if (!(this.e.j.o == null || this.e.j.o.i == null)) {
                arrayList.addAll(this.e.j.o.i);
            }
            if (!arrayList.isEmpty()) {
                aw.e();
                jh.a(this.e.c, this.e.e.f2393a, (List<String>) arrayList);
                this.e.j.H = true;
            }
        }
    }

    public void o() {
        ab.b("#008 Must be called on the main UI thread.: pause");
    }

    public void p() {
        ab.b("#008 Must be called on the main UI thread.: resume");
    }

    public final Bundle q() {
        return this.l ? this.k : new Bundle();
    }

    public final void r() {
        ab.b("#008 Must be called on the main UI thread.: stopLoading");
        this.c = false;
        this.e.a(true);
    }

    public final boolean s() {
        return this.c;
    }

    public apg t() {
        return null;
    }

    /* access modifiers changed from: protected */
    public void u() {
        iy.a();
        if (this.e.n != null) {
            try {
                this.e.n.a();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
        if (this.e.C != null) {
            try {
                this.e.C.d();
            } catch (RemoteException e3) {
                iy.c("#007 Could not call remote method.", e3);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void v() {
        iy.a();
        if (this.e.n != null) {
            try {
                this.e.n.b();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
        if (this.e.C != null) {
            try {
                this.e.C.e();
            } catch (RemoteException e3) {
                iy.c("#007 Could not call remote method.", e3);
            }
        }
    }

    /* access modifiers changed from: protected */
    public final void w() {
        iy.a();
        if (this.e.n != null) {
            try {
                this.e.n.d();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
        if (this.e.C != null) {
            try {
                this.e.C.b();
            } catch (RemoteException e3) {
                iy.c("#007 Could not call remote method.", e3);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void x() {
        d(false);
    }

    public final void y() {
        ma.a(4);
        if (this.e.n != null) {
            try {
                this.e.n.f();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }

    public final void z() {
        ma.a(4);
        if (this.e.n != null) {
            try {
                this.e.n.e();
            } catch (RemoteException e2) {
                iy.c("#007 Could not call remote method.", e2);
            }
        }
    }
}
