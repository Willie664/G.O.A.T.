package com.google.android.gms.ads.internal.gmsg;

import android.os.Bundle;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public interface k {
    void a(Bundle bundle);
}
