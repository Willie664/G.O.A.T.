package com.google.android.gms.ads.mediation;

public interface c {
    void a();

    void a(int i);

    void a(String str, String str2);

    void b();

    void c();

    void d();

    void e();
}
