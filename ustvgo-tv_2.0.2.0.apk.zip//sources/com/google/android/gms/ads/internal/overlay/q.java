package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.os.Bundle;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;

@cj
public final class q extends c {
    public q(Activity activity) {
        super(activity);
    }

    public final void a(Bundle bundle) {
        iy.a();
        this.d = 3;
        this.f1279a.finish();
    }
}
