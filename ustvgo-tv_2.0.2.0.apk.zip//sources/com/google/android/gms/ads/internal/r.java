package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

public final class r implements Parcelable.Creator<zzaq> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a2 = a.a(parcel);
        String str = null;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        float f = 0.0f;
        int i = 0;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        while (parcel.dataPosition() < a2) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 2:
                    z = a.c(parcel, readInt);
                    break;
                case 3:
                    z2 = a.c(parcel, readInt);
                    break;
                case 4:
                    str = a.k(parcel, readInt);
                    break;
                case 5:
                    z3 = a.c(parcel, readInt);
                    break;
                case 6:
                    f = a.h(parcel, readInt);
                    break;
                case 7:
                    i = a.d(parcel, readInt);
                    break;
                case 8:
                    z4 = a.c(parcel, readInt);
                    break;
                case 9:
                    z5 = a.c(parcel, readInt);
                    break;
                case 10:
                    z6 = a.c(parcel, readInt);
                    break;
                default:
                    a.b(parcel, readInt);
                    break;
            }
        }
        a.u(parcel, a2);
        return new zzaq(z, z2, str, z3, f, i, z4, z5, z6);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzaq[i];
    }
}
