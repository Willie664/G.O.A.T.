package com.google.android.gms.ads.internal;

import java.util.concurrent.Callable;

final class be implements Callable<String> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ba f1230a;

    be(ba baVar) {
        this.f1230a = baVar;
    }

    public final /* synthetic */ Object call() {
        return this.f1230a.e.d.b.a(this.f1230a.e.c);
    }
}
