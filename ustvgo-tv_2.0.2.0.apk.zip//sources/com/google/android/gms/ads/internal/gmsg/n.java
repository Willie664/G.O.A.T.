package com.google.android.gms.ads.internal.gmsg;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.internal.ads.ard;
import com.google.android.gms.internal.ads.are;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

@cj
public final class n implements ae<pu> {
    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        String str = (String) map.get("action");
        if ("tick".equals(str)) {
            String str2 = (String) map.get("label");
            String str3 = (String) map.get("start_label");
            String str4 = (String) map.get("timestamp");
            if (TextUtils.isEmpty(str2)) {
                iy.b("No label given for CSI tick.");
            } else if (TextUtils.isEmpty(str4)) {
                iy.b("No timestamp given for CSI tick.");
            } else {
                try {
                    long b = aw.l().b() + (Long.parseLong(str4) - aw.l().a());
                    if (TextUtils.isEmpty(str3)) {
                        str3 = "native:view_load";
                    }
                    are j = puVar.j();
                    arf arf = j.b;
                    ard ard = j.f1818a.get(str3);
                    String[] strArr = {str2};
                    if (!(arf == null || ard == null)) {
                        arf.a(ard, b, strArr);
                    }
                    Map<String, ard> map2 = j.f1818a;
                    arf arf2 = j.b;
                    map2.put(str2, arf2 == null ? null : arf2.a(b));
                } catch (NumberFormatException e) {
                    iy.b("Malformed timestamp for CSI tick.", e);
                }
            }
        } else if ("experiment".equals(str)) {
            String str5 = (String) map.get("value");
            if (TextUtils.isEmpty(str5)) {
                iy.b("No value given for CSI experiment.");
                return;
            }
            arf arf3 = puVar.j().b;
            if (arf3 == null) {
                iy.b("No ticker for WebView, dropping experiment ID.");
            } else {
                arf3.a("e", str5);
            }
        } else if ("extra".equals(str)) {
            String str6 = (String) map.get("name");
            String str7 = (String) map.get("value");
            if (TextUtils.isEmpty(str7)) {
                iy.b("No value given for CSI extra.");
            } else if (TextUtils.isEmpty(str6)) {
                iy.b("No name given for CSI extra.");
            } else {
                arf arf4 = puVar.j().b;
                if (arf4 == null) {
                    iy.b("No ticker for WebView, dropping extra parameter.");
                } else {
                    arf4.a(str6, str7);
                }
            }
        }
    }
}
