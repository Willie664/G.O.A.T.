package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.ad;
import com.google.android.gms.internal.ads.agb;
import com.google.android.gms.internal.ads.agc;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.anv;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aok;
import com.google.android.gms.internal.ads.aoo;
import com.google.android.gms.internal.ads.aos;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.apg;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.gd;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jf;
import com.google.android.gms.internal.ads.lp;
import com.google.android.gms.internal.ads.x;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzlu;
import com.google.android.gms.internal.ads.zzmu;
import java.util.Map;
import java.util.concurrent.Future;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class aq extends aok {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final zzang f1216a;
    private final zzjn b;
    /* access modifiers changed from: private */
    public final Future<agb> c = jf.a(new at(this));
    /* access modifiers changed from: private */
    public final Context d;
    private final av e;
    /* access modifiers changed from: private */
    public WebView f = new WebView(this.d);
    /* access modifiers changed from: private */
    public any g;
    /* access modifiers changed from: private */
    public agb h;
    private AsyncTask<Void, Void, String> i;

    public aq(Context context, zzjn zzjn, String str, zzang zzang) {
        this.d = context;
        this.f1216a = zzang;
        this.b = zzjn;
        this.e = new av(str);
        a(0);
        this.f.setVerticalScrollBarEnabled(false);
        this.f.getSettings().setJavaScriptEnabled(true);
        this.f.setWebViewClient(new ar(this));
        this.f.setOnTouchListener(new as(this));
    }

    static /* synthetic */ void b(aq aqVar, String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(str));
        aqVar.d.startActivity(intent);
    }

    /* access modifiers changed from: private */
    public final String c(String str) {
        if (this.h == null) {
            return str;
        }
        Uri parse = Uri.parse(str);
        try {
            parse = this.h.a(parse, this.d, (View) null, (Activity) null);
        } catch (agc e2) {
            iy.b("Unable to process ad data", e2);
        }
        return parse.toString();
    }

    public final String D() {
        throw new IllegalStateException("getAdUnitId not implemented");
    }

    public final aos E() {
        throw new IllegalStateException("getIAppEventListener not implemented");
    }

    public final any F() {
        throw new IllegalStateException("getIAdListener not implemented");
    }

    public final void I() {
        throw new IllegalStateException("Unused method");
    }

    public final String a() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public final void a(int i2) {
        if (this.f != null) {
            this.f.setLayoutParams(new ViewGroup.LayoutParams(-1, i2));
        }
    }

    public final void a(ad adVar, String str) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(anv anv) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(any any) {
        this.g = any;
    }

    public final void a(aoo aoo) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(aos aos) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(aoy aoy) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(arm arm) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(gd gdVar) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(x xVar) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(zzjn zzjn) {
        throw new IllegalStateException("AdSize must be set before initialization");
    }

    public final void a(zzlu zzlu) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(zzmu zzmu) {
        throw new IllegalStateException("Unused method");
    }

    public final void a(String str) {
        throw new IllegalStateException("Unused method");
    }

    /* access modifiers changed from: package-private */
    public final int b(String str) {
        String queryParameter = Uri.parse(str).getQueryParameter("height");
        if (TextUtils.isEmpty(queryParameter)) {
            return 0;
        }
        try {
            ans.a();
            return lp.a(this.d, Integer.parseInt(queryParameter));
        } catch (NumberFormatException unused) {
            return 0;
        }
    }

    public final void b(boolean z) {
    }

    public final boolean b(zzjj zzjj) {
        ab.a(this.f, (Object) "This Search Ad has already been torn down");
        av avVar = this.e;
        zzang zzang = this.f1216a;
        avVar.c = zzjj.j.f2402a;
        Bundle bundle = zzjj.m != null ? zzjj.m.getBundle(AdMobAdapter.class.getName()) : null;
        if (bundle != null) {
            String str = (String) ans.f().a(aqs.cy);
            for (String str2 : bundle.keySet()) {
                if (str.equals(str2)) {
                    avVar.d = bundle.getString(str2);
                } else if (str2.startsWith("csa_")) {
                    avVar.b.put(str2.substring(4), bundle.getString(str2));
                }
            }
            avVar.b.put("SDKVersion", zzang.f2393a);
        }
        this.i = new au(this, (byte) 0).execute(new Void[0]);
        return true;
    }

    /* access modifiers changed from: package-private */
    public final String c() {
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("https://").appendEncodedPath((String) ans.f().a(aqs.cx));
        builder.appendQueryParameter("query", this.e.c);
        builder.appendQueryParameter("pubId", this.e.f1221a);
        Map<String, String> map = this.e.b;
        for (String next : map.keySet()) {
            builder.appendQueryParameter(next, map.get(next));
        }
        Uri build = builder.build();
        if (this.h != null) {
            try {
                build = this.h.a(build, this.d, (String) null, false, (View) null, (Activity) null);
            } catch (agc e2) {
                iy.b("Unable to process ad data", e2);
            }
        }
        String d2 = d();
        String encodedQuery = build.getEncodedQuery();
        StringBuilder sb = new StringBuilder(String.valueOf(d2).length() + 1 + String.valueOf(encodedQuery).length());
        sb.append(d2);
        sb.append("#");
        sb.append(encodedQuery);
        return sb.toString();
    }

    public final void c(boolean z) {
        throw new IllegalStateException("Unused method");
    }

    /* access modifiers changed from: package-private */
    public final String d() {
        String str = this.e.d;
        if (TextUtils.isEmpty(str)) {
            str = "www.google.com";
        }
        String str2 = (String) ans.f().a(aqs.cx);
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 8 + String.valueOf(str2).length());
        sb.append("https://");
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    public final void j() {
        ab.b("destroy must be called on the main UI thread.");
        this.i.cancel(true);
        this.c.cancel(true);
        this.f.destroy();
        this.f = null;
    }

    public final a k() {
        ab.b("getAdFrame must be called on the main UI thread.");
        return b.a(this.f);
    }

    public final zzjn l() {
        return this.b;
    }

    public final boolean m() {
        return false;
    }

    public final void n() {
        throw new IllegalStateException("Unused method");
    }

    public final void o() {
        ab.b("pause must be called on the main UI thread.");
    }

    public final void p() {
        ab.b("resume must be called on the main UI thread.");
    }

    public final Bundle q() {
        throw new IllegalStateException("Unused method");
    }

    public final void r() {
    }

    public final boolean s() {
        return false;
    }

    public final String s_() {
        return null;
    }

    public final apg t() {
        return null;
    }
}
