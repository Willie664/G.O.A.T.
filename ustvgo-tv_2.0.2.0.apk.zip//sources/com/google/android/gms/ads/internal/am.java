package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.zzjj;
import java.lang.ref.WeakReference;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class am {

    /* renamed from: a  reason: collision with root package name */
    zzjj f1213a;
    boolean b;
    boolean c;
    private final ao d;
    private final Runnable e;
    private long f;

    public am(a aVar) {
        this(aVar, new ao(jh.f2130a));
    }

    private am(a aVar, ao aoVar) {
        this.b = false;
        this.c = false;
        this.f = 0;
        this.d = aoVar;
        this.e = new an(this, new WeakReference(aVar));
    }

    public final void a() {
        this.b = false;
        this.d.a(this.e);
    }

    public final void a(zzjj zzjj) {
        a(zzjj, 60000);
    }

    public final void a(zzjj zzjj, long j) {
        if (this.b) {
            iy.b("An ad refresh is already scheduled.");
            return;
        }
        this.f1213a = zzjj;
        this.b = true;
        this.f = j;
        if (!this.c) {
            StringBuilder sb = new StringBuilder(65);
            sb.append("Scheduling ad refresh ");
            sb.append(j);
            sb.append(" milliseconds from now.");
            ma.a(4);
            this.d.a(this.e, j);
        }
    }

    public final void b() {
        this.c = true;
        if (this.b) {
            this.d.a(this.e);
        }
    }

    public final void c() {
        this.c = false;
        if (this.b) {
            this.b = false;
            a(this.f1213a, this.f);
        }
    }
}
