package com.google.android.gms.ads.internal;

import android.content.Context;
import android.view.View;
import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.ads.internal.gmsg.ai;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.al;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ho;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.n;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.qb;
import com.google.android.gms.internal.ads.ri;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjn;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public abstract class bf extends ba implements g, n {
    private boolean j;

    public bf(Context context, zzjn zzjn, String str, bav bav, zzang zzang, bt btVar) {
        super(context, zzjn, str, bav, zzang, btVar);
    }

    /* access modifiers changed from: protected */
    public final boolean M() {
        return (this.e.k == null || this.e.k.b == null || !this.e.k.b.Q) ? false : true;
    }

    public final void N() {
        w();
    }

    public final void O() {
        u();
    }

    /* access modifiers changed from: protected */
    public pu a(ie ieVar, bu buVar, ho hoVar) {
        ie ieVar2 = ieVar;
        View nextView = this.e.f.getNextView();
        if (nextView instanceof pu) {
            ((pu) nextView).destroy();
        }
        if (nextView != null) {
            this.e.f.removeView(nextView);
        }
        aw.f();
        pu a2 = qb.a(this.e.c, ri.a(this.e.i), this.e.i.f2399a, false, false, this.e.d, this.e.e, this.f1202a, this, this.i, ieVar2.i);
        if (this.e.i.g == null) {
            a(a2.getView());
        }
        a2.v().a(this, this, this, this, this, false, (ai) null, buVar, this, hoVar);
        a(a2);
        a2.a(ieVar2.f2106a.v);
        return a2;
    }

    public final void a(arm arm) {
        ab.b("setOnCustomRenderedAdLoadedListener must be called on the main UI thread.");
        this.e.B = arm;
    }

    /* access modifiers changed from: protected */
    public void a(ie ieVar, arf arf) {
        if (ieVar.e != -2) {
            jh.f2130a.post(new bh(this, ieVar));
            return;
        }
        if (ieVar.d != null) {
            this.e.i = ieVar.d;
        }
        if (!ieVar.b.g || ieVar.b.z) {
            jh.f2130a.post(new bi(this, ieVar, this.i.c.a(this.e.c, this.e.e, ieVar.b), arf));
            return;
        }
        this.e.I = 0;
        ax axVar = this.e;
        aw.d();
        axVar.h = al.a(this.e.c, this, ieVar, this.e.d, (pu) null, this.o, this, arf);
    }

    /* access modifiers changed from: protected */
    public final void a(pu puVar) {
        puVar.a("/trackActiveViewUnit", (ae<? super pu>) new bg(this));
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x0048 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean a(com.google.android.gms.internal.ads.id r3, com.google.android.gms.internal.ads.id r4) {
        /*
            r2 = this;
            com.google.android.gms.ads.internal.ax r0 = r2.e
            boolean r0 = r0.c()
            if (r0 == 0) goto L_0x0018
            com.google.android.gms.ads.internal.ax r0 = r2.e
            com.google.android.gms.ads.internal.ay r0 = r0.f
            if (r0 == 0) goto L_0x0018
            com.google.android.gms.ads.internal.ax r0 = r2.e
            com.google.android.gms.ads.internal.ay r0 = r0.f
            com.google.android.gms.internal.ads.jz r0 = r0.f1224a
            java.lang.String r1 = r4.A
            r0.b = r1
        L_0x0018:
            com.google.android.gms.internal.ads.pu r0 = r4.b     // Catch:{ RuntimeException -> 0x004c }
            if (r0 == 0) goto L_0x004f
            boolean r0 = r4.n     // Catch:{ RuntimeException -> 0x004c }
            if (r0 != 0) goto L_0x004f
            boolean r0 = r4.M     // Catch:{ RuntimeException -> 0x004c }
            if (r0 == 0) goto L_0x004f
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r0 = com.google.android.gms.internal.ads.aqs.dl     // Catch:{ RuntimeException -> 0x004c }
            com.google.android.gms.internal.ads.aqq r1 = com.google.android.gms.internal.ads.ans.f()     // Catch:{ RuntimeException -> 0x004c }
            java.lang.Object r0 = r1.a(r0)     // Catch:{ RuntimeException -> 0x004c }
            java.lang.Boolean r0 = (java.lang.Boolean) r0     // Catch:{ RuntimeException -> 0x004c }
            boolean r0 = r0.booleanValue()     // Catch:{ RuntimeException -> 0x004c }
            if (r0 == 0) goto L_0x004f
            com.google.android.gms.internal.ads.zzjj r0 = r4.f2105a     // Catch:{ RuntimeException -> 0x004c }
            android.os.Bundle r0 = r0.c     // Catch:{ RuntimeException -> 0x004c }
            java.lang.String r1 = "sdk_less_server_data"
            boolean r0 = r0.containsKey(r1)     // Catch:{ RuntimeException -> 0x004c }
            if (r0 != 0) goto L_0x004f
            com.google.android.gms.internal.ads.pu r0 = r4.b     // Catch:{ Throwable -> 0x0048 }
            r0.J()     // Catch:{ Throwable -> 0x0048 }
            goto L_0x004f
        L_0x0048:
            com.google.android.gms.internal.ads.iy.a()     // Catch:{ RuntimeException -> 0x004c }
            goto L_0x004f
        L_0x004c:
            com.google.android.gms.internal.ads.iy.a()
        L_0x004f:
            boolean r3 = super.a((com.google.android.gms.internal.ads.id) r3, (com.google.android.gms.internal.ads.id) r4)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.bf.a(com.google.android.gms.internal.ads.id, com.google.android.gms.internal.ads.id):boolean");
    }

    /* access modifiers changed from: package-private */
    public final void b(pu puVar) {
        if (this.e.j != null) {
            this.g.a(this.e.i, this.e.j, puVar.getView(), puVar);
            this.j = false;
            return;
        }
        this.j = true;
        iy.b("Request to enable ActiveView before adState is available.");
    }

    public final void b_(View view) {
        this.e.H = view;
        b(new id(this.e.k));
    }

    public final void h_() {
        e();
    }

    public final void i_() {
        aa();
        n();
    }

    /* access modifiers changed from: protected */
    public void x() {
        super.x();
        if (this.j) {
            if (((Boolean) ans.f().a(aqs.cg)).booleanValue()) {
                b(this.e.j.b);
            }
        }
    }
}
