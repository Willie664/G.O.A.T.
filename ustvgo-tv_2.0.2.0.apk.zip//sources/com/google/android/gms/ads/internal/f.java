package com.google.android.gms.ads.internal;

import android.os.Bundle;
import com.google.android.gms.internal.ads.ja;
import com.google.android.gms.internal.ads.me;
import com.google.android.gms.internal.ads.mj;
import com.google.android.gms.internal.ads.mu;
import org.json.JSONObject;

final /* synthetic */ class f implements me {

    /* renamed from: a  reason: collision with root package name */
    static final me f1248a = new f();

    private f() {
    }

    public final mu a(Object obj) {
        JSONObject jSONObject = (JSONObject) obj;
        if (jSONObject.optBoolean("isSuccessful", false)) {
            String string = jSONObject.getString("appSettingsJson");
            ja f = aw.i().f();
            f.a();
            synchronized (f.f2125a) {
                long a2 = aw.l().a();
                f.k = a2;
                if (string != null) {
                    if (!string.equals(f.j)) {
                        f.j = string;
                        if (f.d != null) {
                            f.d.putString("app_settings_json", string);
                            f.d.putLong("app_settings_last_update_ms", a2);
                            f.d.apply();
                        }
                        Bundle bundle = new Bundle();
                        bundle.putString("app_settings_json", string);
                        bundle.putLong("app_settings_last_update_ms", a2);
                        f.a(bundle);
                    }
                }
            }
        }
        return mj.a(null);
    }
}
