package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.formats.d;
import com.google.android.gms.ads.formats.e;
import com.google.android.gms.ads.formats.f;
import com.google.android.gms.ads.formats.g;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.anb;
import com.google.android.gms.internal.ads.anh;
import com.google.android.gms.internal.ads.ank;
import com.google.android.gms.internal.ads.ano;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aob;
import com.google.android.gms.internal.ads.aoe;
import com.google.android.gms.internal.ads.aug;
import com.google.android.gms.internal.ads.auj;
import com.google.android.gms.internal.ads.auv;
import com.google.android.gms.internal.ads.avg;
import com.google.android.gms.internal.ads.avh;
import com.google.android.gms.internal.ads.avi;
import com.google.android.gms.internal.ads.avk;
import com.google.android.gms.internal.ads.avl;
import com.google.android.gms.internal.ads.bau;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.zzpl;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1186a;
    public final aob b;
    private final anh c;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final Context f1187a;
        private final aoe b;

        private a(Context context, aoe aoe) {
            this.f1187a = context;
            this.b = aoe;
        }

        public a(Context context, String str) {
            this((Context) ab.a(context, (Object) "context cannot be null"), (aoe) ank.a(context, false, new ano(ans.b(), context, str, new bau())));
        }

        public final a a(a aVar) {
            try {
                this.b.a((any) new anb(aVar));
            } catch (RemoteException e) {
                ma.b("Failed to set AdListener.", e);
            }
            return this;
        }

        public final a a(com.google.android.gms.ads.formats.b bVar) {
            try {
                this.b.a(new zzpl(bVar));
            } catch (RemoteException e) {
                ma.b("Failed to specify native ad options", e);
            }
            return this;
        }

        public final a a(d.a aVar) {
            try {
                this.b.a((aug) new avg(aVar));
            } catch (RemoteException e) {
                ma.b("Failed to add app install ad listener", e);
            }
            return this;
        }

        public final a a(e.a aVar) {
            try {
                this.b.a((auj) new avh(aVar));
            } catch (RemoteException e) {
                ma.b("Failed to add content ad listener", e);
            }
            return this;
        }

        public final a a(g.a aVar) {
            try {
                this.b.a((auv) new avl(aVar));
            } catch (RemoteException e) {
                ma.b("Failed to add google native ad listener", e);
            }
            return this;
        }

        public final a a(String str, f.b bVar, f.a aVar) {
            try {
                this.b.a(str, new avk(bVar), aVar == null ? null : new avi(aVar));
            } catch (RemoteException e) {
                ma.b("Failed to add custom template ad listener", e);
            }
            return this;
        }

        public final b a() {
            try {
                return new b(this.f1187a, this.b.a());
            } catch (RemoteException e) {
                ma.a("Failed to build AdLoader.", e);
                return null;
            }
        }
    }

    b(Context context, aob aob) {
        this(context, aob, anh.f1777a);
    }

    private b(Context context, aob aob, anh anh) {
        this.f1186a = context;
        this.b = aob;
        this.c = anh;
    }
}
