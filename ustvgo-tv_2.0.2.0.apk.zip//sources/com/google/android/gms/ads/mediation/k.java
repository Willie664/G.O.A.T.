package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.formats.a;
import com.google.android.gms.ads.h;
import com.google.android.gms.internal.ads.cj;
import java.util.List;

@cj
public class k {

    /* renamed from: a  reason: collision with root package name */
    public String f1307a;
    public List<a.b> b;
    public String c;
    public a.b d;
    public String e;
    public String f;
    public Double g;
    public String h;
    public String i;
    public h j;
    public boolean k;
    public View l;
    public View m;
    public Object n;
    public Bundle o = new Bundle();
    public boolean p;
    public boolean q;

    public void a(View view) {
    }
}
