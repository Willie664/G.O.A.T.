package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.amz;
import com.google.android.gms.internal.ads.ana;
import com.google.android.gms.internal.ads.anb;
import com.google.android.gms.internal.ads.anh;
import com.google.android.gms.internal.ads.anj;
import com.google.android.gms.internal.ads.ank;
import com.google.android.gms.internal.ads.anl;
import com.google.android.gms.internal.ads.anm;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.anv;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aoj;
import com.google.android.gms.internal.ads.aos;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.apn;
import com.google.android.gms.internal.ads.app;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.arp;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzmu;

class BaseAdView extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    protected final app f1185a;

    public BaseAdView(Context context) {
        super(context);
        this.f1185a = new app(this);
    }

    public BaseAdView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        this.f1185a = new app((ViewGroup) this, attributeSet, i);
    }

    public BaseAdView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i);
        this.f1185a = new app((ViewGroup) this, attributeSet, i2);
    }

    public void a() {
        app app = this.f1185a;
        try {
            if (app.i != null) {
                app.i.p();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
    }

    public void a(c cVar) {
        Object a2;
        app app = this.f1185a;
        apn apn = cVar.f1188a;
        try {
            if (app.i == null) {
                if ((app.f == null || app.l == null) && app.i == null) {
                    throw new IllegalStateException("The ad size and ad unit ID must be set before loadAd is called.");
                }
                Context context = app.m.getContext();
                zzjn a3 = app.a(context, app.f, app.n);
                if ("search_v2".equals(a3.f2399a)) {
                    a2 = ank.a(context, false, new anm(ans.b(), context, a3, app.l));
                } else {
                    a2 = ank.a(context, false, new anl(ans.b(), context, a3, app.l, app.f1796a));
                }
                app.i = (aoj) a2;
                app.i.a((any) new anb(app.c));
                if (app.d != null) {
                    app.i.a((anv) new ana(app.d));
                }
                if (app.g != null) {
                    app.i.a((aos) new anj(app.g));
                }
                if (app.j != null) {
                    app.i.a((arm) new arp(app.j));
                }
                if (app.h != null) {
                    app.i.a((aoy) app.h.f1192a);
                }
                if (app.k != null) {
                    app.i.a(new zzmu(app.k));
                }
                app.i.b(app.o);
                try {
                    a k = app.i.k();
                    if (k != null) {
                        app.m.addView((View) b.a(k));
                    }
                } catch (RemoteException e) {
                    ma.c("#007 Could not call remote method.", e);
                }
            }
            if (app.i.b(anh.a(app.m.getContext(), apn))) {
                app.f1796a.f1964a = apn.h;
            }
        } catch (RemoteException e2) {
            ma.c("#007 Could not call remote method.", e2);
        }
    }

    public void b() {
        app app = this.f1185a;
        try {
            if (app.i != null) {
                app.i.o();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
    }

    public void c() {
        app app = this.f1185a;
        try {
            if (app.i != null) {
                app.i.j();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
    }

    public a getAdListener() {
        return this.f1185a.e;
    }

    public d getAdSize() {
        return this.f1185a.a();
    }

    public String getAdUnitId() {
        return this.f1185a.b();
    }

    public String getMediationAdapterClassName() {
        return this.f1185a.c();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View childAt = getChildAt(0);
        if (childAt != null && childAt.getVisibility() != 8) {
            int measuredWidth = childAt.getMeasuredWidth();
            int measuredHeight = childAt.getMeasuredHeight();
            int i5 = ((i3 - i) - measuredWidth) / 2;
            int i6 = ((i4 - i2) - measuredHeight) / 2;
            childAt.layout(i5, i6, measuredWidth + i5, measuredHeight + i6);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        int i4 = 0;
        View childAt = getChildAt(0);
        if (childAt == null || childAt.getVisibility() == 8) {
            d dVar = null;
            try {
                dVar = getAdSize();
            } catch (NullPointerException e) {
                ma.a("Unable to retrieve ad size.", e);
            }
            if (dVar != null) {
                Context context = getContext();
                int b = dVar.b(context);
                i3 = dVar.a(context);
                i4 = b;
            } else {
                i3 = 0;
            }
        } else {
            measureChild(childAt, i, i2);
            i4 = childAt.getMeasuredWidth();
            i3 = childAt.getMeasuredHeight();
        }
        setMeasuredDimension(View.resolveSize(Math.max(i4, getSuggestedMinimumWidth()), i), View.resolveSize(Math.max(i3, getSuggestedMinimumHeight()), i2));
    }

    public void setAdListener(a aVar) {
        this.f1185a.a(aVar);
        if (aVar == null) {
            this.f1185a.a((amz) null);
            this.f1185a.a((com.google.android.gms.ads.doubleclick.a) null);
            return;
        }
        if (aVar instanceof amz) {
            this.f1185a.a((amz) aVar);
        }
        if (aVar instanceof com.google.android.gms.ads.doubleclick.a) {
            this.f1185a.a((com.google.android.gms.ads.doubleclick.a) aVar);
        }
    }

    public void setAdSize(d dVar) {
        this.f1185a.a(dVar);
    }

    public void setAdUnitId(String str) {
        this.f1185a.a(str);
    }
}
