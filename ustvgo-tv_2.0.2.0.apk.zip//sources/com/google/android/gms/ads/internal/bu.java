package com.google.android.gms.ads.internal;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ho;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.zzael;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class bu {

    /* renamed from: a  reason: collision with root package name */
    boolean f1243a;
    private final Context b;
    private ho c;
    private zzael d;

    public bu(Context context, ho hoVar, zzael zzael) {
        this.b = context;
        this.c = hoVar;
        this.d = zzael;
        if (this.d == null) {
            this.d = new zzael();
        }
    }

    private final boolean b() {
        return (this.c != null && this.c.a().f) || this.d.f2385a;
    }

    public final void a(String str) {
        if (b()) {
            if (str == null) {
                str = "";
            }
            if (this.c != null) {
                this.c.a(str, (Map<String, String>) null, 3);
            } else if (this.d.f2385a && this.d.b != null) {
                for (String next : this.d.b) {
                    if (!TextUtils.isEmpty(next)) {
                        String replace = next.replace("{NAVIGATION_URL}", Uri.encode(str));
                        aw.e();
                        jh.a(this.b, "", replace);
                    }
                }
            }
        }
    }

    public final boolean a() {
        return !b() || this.f1243a;
    }
}
