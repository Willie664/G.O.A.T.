package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.ma;
import java.util.Map;

final class y implements ae<Object> {
    y() {
    }

    public final void zza(Object obj, Map<String, String> map) {
        String valueOf = String.valueOf(map.get("string"));
        if (valueOf.length() != 0) {
            "Received log message: ".concat(valueOf);
        } else {
            new String("Received log message: ");
        }
        ma.a(4);
    }
}
