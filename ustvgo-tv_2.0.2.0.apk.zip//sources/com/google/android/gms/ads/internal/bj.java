package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.id;

final class bj implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bi f1234a;

    bj(bi biVar) {
        this.f1234a = biVar;
    }

    public final void run() {
        this.f1234a.c.b(new id(this.f1234a.f1233a));
    }
}
