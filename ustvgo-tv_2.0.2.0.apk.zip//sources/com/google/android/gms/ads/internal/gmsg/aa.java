package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class aa implements ae<pu> {
    aa() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        if (((Boolean) ans.f().a(aqs.bt)).booleanValue()) {
            puVar.d(!Boolean.parseBoolean((String) map.get("disabled")));
        }
    }
}
