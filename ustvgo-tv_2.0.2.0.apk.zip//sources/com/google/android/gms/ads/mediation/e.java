package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.formats.f;

public interface e {
    void a(f fVar);

    void a(f fVar, String str);

    void a(MediationNativeAdapter mediationNativeAdapter, f fVar);

    void a(MediationNativeAdapter mediationNativeAdapter, k kVar);

    void c(int i);

    void k();

    void l();

    void m();

    void n();

    void o();
}
