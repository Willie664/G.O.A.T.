package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.it;
import com.google.android.gms.internal.ads.jh;

@cj
final class p extends it {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ m f1290a;
    private final int b;

    public p(m mVar, int i) {
        this.f1290a = mVar;
        this.b = i;
    }

    public final void a() {
        zzaq zzaq = new zzaq(this.f1290a.e.J, this.f1290a.J(), this.f1290a.l, this.f1290a.m, this.f1290a.e.J ? this.b : -1, this.f1290a.n, this.f1290a.e.j.L, this.f1290a.e.j.O);
        int requestedOrientation = this.f1290a.e.j.b.getRequestedOrientation();
        if (requestedOrientation == -1) {
            requestedOrientation = this.f1290a.e.j.h;
        }
        jh.f2130a.post(new q(this, new AdOverlayInfoParcel(this.f1290a, this.f1290a, this.f1290a, this.f1290a.e.j.b, requestedOrientation, this.f1290a.e.e, this.f1290a.e.j.A, zzaq)));
    }

    public final void e_() {
    }
}
