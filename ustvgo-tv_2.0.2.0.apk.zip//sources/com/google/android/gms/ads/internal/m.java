package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import android.view.Window;
import com.google.ads.mediation.AbstractAdViewAdapter;
import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.ads.internal.gmsg.ai;
import com.google.android.gms.ads.internal.gmsg.i;
import com.google.android.gms.ads.internal.gmsg.j;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.c;
import com.google.android.gms.ads.internal.overlay.k;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.ajk;
import com.google.android.gms.internal.ads.ajo;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.bae;
import com.google.android.gms.internal.ads.baf;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ep;
import com.google.android.gms.internal.ads.fm;
import com.google.android.gms.internal.ads.ho;
import com.google.android.gms.internal.ads.hs;
import com.google.android.gms.internal.ads.ht;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.jm;
import com.google.android.gms.internal.ads.ld;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.qb;
import com.google.android.gms.internal.ads.rc;
import com.google.android.gms.internal.ads.rf;
import com.google.android.gms.internal.ads.ri;
import com.google.android.gms.internal.ads.zzaej;
import com.google.android.gms.internal.ads.zzaig;
import com.google.android.gms.internal.ads.zzaiq;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONException;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public final class m extends bf implements ai, j {
    private transient boolean j;
    private int k = -1;
    /* access modifiers changed from: private */
    public boolean l;
    /* access modifiers changed from: private */
    public float m;
    /* access modifiers changed from: private */
    public boolean n;
    private hs p;
    private String q;
    private final String r;
    private final fm s;

    public m(Context context, zzjn zzjn, String str, bav bav, zzang zzang, bt btVar) {
        super(context, zzjn, str, bav, zzang, btVar);
        boolean z = false;
        this.j = false;
        if (zzjn != null && "reward_mb".equals(zzjn.f2399a)) {
            z = true;
        }
        this.r = z ? "/Rewarded" : "/Interstitial";
        this.s = z ? new fm(this.e, this.o, new o(this), this, this) : null;
    }

    private static ie b(ie ieVar) {
        ie ieVar2 = ieVar;
        try {
            String jSONObject = ep.a(ieVar2.b).toString();
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put(AbstractAdViewAdapter.AD_UNIT_ID_PARAMETER, ieVar2.f2106a.e);
            bae bae = new bae(jSONObject, Collections.singletonList("com.google.ads.mediation.admob.AdMobAdapter"), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), jSONObject2.toString(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
            zzaej zzaej = ieVar2.b;
            baf baf = new baf(Collections.singletonList(bae), ((Long) ans.f().a(aqs.bB)).longValue(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), zzaej.H, zzaej.I, "");
            return new ie(ieVar2.f2106a, new zzaej(ieVar2.f2106a, zzaej.f2384a, zzaej.b, Collections.emptyList(), Collections.emptyList(), zzaej.f, true, zzaej.h, Collections.emptyList(), zzaej.j, zzaej.k, zzaej.l, zzaej.m, zzaej.n, zzaej.o, zzaej.p, (String) null, zzaej.r, zzaej.s, zzaej.t, zzaej.u, zzaej.v, zzaej.x, zzaej.y, zzaej.z, (zzaig) null, Collections.emptyList(), Collections.emptyList(), zzaej.D, zzaej.E, zzaej.F, zzaej.G, zzaej.H, zzaej.I, zzaej.J, (zzaiq) null, zzaej.L, zzaej.M, zzaej.N, zzaej.O, zzaej.Q, Collections.emptyList(), zzaej.S, zzaej.T), baf, ieVar2.d, ieVar2.e, ieVar2.f, ieVar2.g, (JSONObject) null, ieVar2.i, (Boolean) null);
        } catch (JSONException e) {
            iy.a("Unable to generate ad state for an interstitial ad with pooling.", e);
            return ieVar2;
        }
    }

    private final void b(Bundle bundle) {
        aw.e();
        jh.b(this.e.c, this.e.e.f2393a, "gmob-apps", bundle, false);
    }

    private final boolean e(boolean z) {
        return this.s != null && z;
    }

    public final void I() {
        Bitmap bitmap;
        int i;
        ab.b("showInterstitial must be called on the main UI thread.");
        if (e(this.e.j != null && this.e.j.n)) {
            this.s.a(this.n);
            return;
        }
        if (aw.B().d(this.e.c)) {
            this.q = aw.B().f(this.e.c);
            String valueOf = String.valueOf(this.q);
            String valueOf2 = String.valueOf(this.r);
            this.q = valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
        }
        if (this.e.j == null) {
            iy.b("The interstitial has not loaded.");
            return;
        }
        if (((Boolean) ans.f().a(aqs.br)).booleanValue()) {
            String packageName = (this.e.c.getApplicationContext() != null ? this.e.c.getApplicationContext() : this.e.c).getPackageName();
            if (!this.j) {
                iy.b("It is not recommended to show an interstitial before onAdLoaded completes.");
                Bundle bundle = new Bundle();
                bundle.putString("appid", packageName);
                bundle.putString("action", "show_interstitial_before_load_finish");
                b(bundle);
            }
            aw.e();
            if (!jh.f(this.e.c)) {
                iy.b("It is not recommended to show an interstitial when app is not in foreground.");
                Bundle bundle2 = new Bundle();
                bundle2.putString("appid", packageName);
                bundle2.putString("action", "show_interstitial_app_not_in_foreground");
                b(bundle2);
            }
        }
        if (!this.e.d()) {
            if (this.e.j.n && this.e.j.p != null) {
                try {
                    if (((Boolean) ans.f().a(aqs.aQ)).booleanValue()) {
                        this.e.j.p.a(this.n);
                    }
                    this.e.j.p.b();
                } catch (RemoteException e) {
                    iy.b("Could not show interstitial.", e);
                    K();
                }
            } else if (this.e.j.b == null) {
                iy.b("The interstitial failed to load.");
            } else if (this.e.j.b.z()) {
                iy.b("The interstitial is already showing.");
            } else {
                this.e.j.b.b(true);
                this.e.a(this.e.j.b.getView());
                if (this.e.j.k != null) {
                    this.g.a(this.e.i, this.e.j);
                }
                id idVar = this.e.j;
                if (idVar.a()) {
                    new ajk(this.e.c, idVar.b.getView()).a((ajo) idVar.b);
                } else {
                    idVar.b.v().a((rf) new n(this, idVar));
                }
                if (this.e.J) {
                    aw.e();
                    bitmap = jh.g(this.e.c);
                } else {
                    bitmap = null;
                }
                ld y = aw.y();
                if (bitmap == null) {
                    ma.a(3);
                    i = -1;
                } else {
                    i = y.b.getAndIncrement();
                    y.f2160a.put(Integer.valueOf(i), bitmap);
                }
                this.k = i;
                if (!((Boolean) ans.f().a(aqs.bR)).booleanValue() || bitmap == null) {
                    zzaq zzaq = new zzaq(this.e.J, J(), false, 0.0f, -1, this.n, this.e.j.L, this.e.j.O);
                    int requestedOrientation = this.e.j.b.getRequestedOrientation();
                    if (requestedOrientation == -1) {
                        requestedOrientation = this.e.j.h;
                    }
                    AdOverlayInfoParcel adOverlayInfoParcel = new AdOverlayInfoParcel(this, this, this, this.e.j.b, requestedOrientation, this.e.e, this.e.j.A, zzaq);
                    aw.c();
                    k.a(this.e.c, adOverlayInfoParcel, true);
                    return;
                }
                new p(this, this.k).h();
            }
        }
    }

    /* access modifiers changed from: protected */
    public final boolean J() {
        Window window;
        if (!(!(this.e.c instanceof Activity) || (window = ((Activity) this.e.c).getWindow()) == null || window.getDecorView() == null)) {
            Rect rect = new Rect();
            Rect rect2 = new Rect();
            window.getDecorView().getGlobalVisibleRect(rect, (Point) null);
            window.getDecorView().getWindowVisibleDisplayFrame(rect2);
            return (rect.bottom == 0 || rect2.bottom == 0 || rect.top != rect2.top) ? false : true;
        }
    }

    public final void K() {
        aw.y().a(Integer.valueOf(this.k));
        if (this.e.c()) {
            this.e.a();
            this.e.j = null;
            this.e.J = false;
            this.j = false;
        }
    }

    public final void L() {
        c r2 = this.e.j.b.r();
        if (r2 != null) {
            r2.a();
        }
    }

    /* access modifiers changed from: protected */
    public final pu a(ie ieVar, bu buVar, ho hoVar) {
        aw.f();
        pu a2 = qb.a(this.e.c, ri.a(this.e.i), this.e.i.f2399a, false, false, this.e.d, this.e.e, this.f1202a, this, this.i, ieVar.i);
        a2.v().a(this, this, (com.google.android.gms.ads.internal.overlay.m) null, this, this, ((Boolean) ans.f().a(aqs.ai)).booleanValue(), this, buVar, this, hoVar);
        a(a2);
        a2.a(ieVar.f2106a.v);
        a2.a("/reward", (ae<? super pu>) new i(this));
        return a2;
    }

    public final void a(ie ieVar, arf arf) {
        if (ieVar.e != -2) {
            super.a(ieVar, arf);
            return;
        }
        if (e(ieVar.c != null)) {
            this.s.a();
            return;
        }
        if (!((Boolean) ans.f().a(aqs.aT)).booleanValue()) {
            super.a(ieVar, arf);
            return;
        }
        boolean z = !ieVar.b.g;
        if (a(ieVar.f2106a.c) && z) {
            this.e.k = b(ieVar);
        }
        super.a(this.e.k, arf);
    }

    public final void a(zzaig zzaig) {
        if (e(this.e.j != null && this.e.j.n)) {
            b(this.s.a(zzaig));
            return;
        }
        if (this.e.j != null) {
            if (this.e.j.x != null) {
                aw.e();
                jh.a(this.e.c, this.e.e.f2393a, this.e.j.x);
            }
            if (this.e.j.v != null) {
                zzaig = this.e.j.v;
            }
        }
        b(zzaig);
    }

    public final void a(boolean z) {
        this.e.J = z;
    }

    public final void a(boolean z, float f) {
        this.l = z;
        this.m = f;
    }

    public final boolean a(id idVar, id idVar2) {
        if (e(idVar2.n)) {
            return fm.b();
        }
        if (!super.a(idVar, idVar2)) {
            return false;
        }
        if (!(this.e.c() || this.e.H == null || idVar2.k == null)) {
            this.g.a(this.e.i, idVar2, this.e.H);
        }
        b(idVar2, false);
        return true;
    }

    public final boolean a(zzjj zzjj, arf arf) {
        if (this.e.j != null) {
            iy.b("An interstitial is already loading. Aborting.");
            return false;
        }
        if (this.p == null && a(zzjj) && aw.B().d(this.e.c) && !TextUtils.isEmpty(this.e.b)) {
            this.p = new hs(this.e.c, this.e.b);
        }
        return super.a(zzjj, arf);
    }

    /* access modifiers changed from: protected */
    public final boolean a(zzjj zzjj, id idVar, boolean z) {
        if (this.e.c() && idVar.b != null) {
            aw.g();
            jm.a(idVar.b);
        }
        return this.d.b;
    }

    public final void c(boolean z) {
        ab.b("setImmersiveMode must be called on the main UI thread.");
        this.n = z;
    }

    public final void f_() {
        if (e(this.e.j != null && this.e.j.n)) {
            this.s.c();
            A();
            return;
        }
        if (!(this.e.j == null || this.e.j.w == null)) {
            aw.e();
            jh.a(this.e.c, this.e.e.f2393a, this.e.j.w);
        }
        A();
    }

    public final void g() {
        rc v;
        aa();
        super.g();
        if (!(this.e.j == null || this.e.j.b == null || (v = this.e.j.b.v()) == null)) {
            v.g();
        }
        if (!(!aw.B().d(this.e.c) || this.e.j == null || this.e.j.b == null)) {
            ht B = aw.B();
            Context context = this.e.j.b.getContext();
            String str = this.q;
            if (B.a(context) && (context instanceof Activity) && B.a(context, "com.google.firebase.analytics.FirebaseAnalytics", B.f2099a, false)) {
                Method f = B.f(context, "setCurrentScreen");
                try {
                    f.invoke(B.f2099a.get(), new Object[]{(Activity) context, str, context.getPackageName()});
                } catch (Exception unused) {
                    B.b("setCurrentScreen", false);
                }
            }
        }
        if (this.p != null) {
            this.p.a(true);
        }
        if (this.h != null && this.e.j != null && this.e.j.b != null) {
            this.e.j.b.a("onSdkImpression", (Map<String, ?>) new HashMap());
        }
    }

    public final void g_() {
        if (e(this.e.j != null && this.e.j.n)) {
            this.s.d();
        }
        B();
    }

    public final void r_() {
        super.r_();
        this.g.a(this.e.j);
        if (this.p != null) {
            this.p.a(false);
        }
        G();
    }

    /* access modifiers changed from: protected */
    public final void u() {
        K();
        super.u();
    }

    /* access modifiers changed from: protected */
    public final void x() {
        pu puVar = this.e.j != null ? this.e.j.b : null;
        ie ieVar = this.e.k;
        if (!(ieVar == null || ieVar.b == null || !ieVar.b.Q || puVar == null || !aw.u().a(this.e.c))) {
            int i = this.e.e.b;
            int i2 = this.e.e.c;
            StringBuilder sb = new StringBuilder(23);
            sb.append(i);
            sb.append(".");
            sb.append(i2);
            this.h = aw.u().a(sb.toString(), puVar.getWebView(), "", "javascript", H());
            if (!(this.h == null || puVar.getView() == null)) {
                aw.u().a(this.h, puVar.getView());
                aw.u().a(this.h);
            }
        }
        super.x();
        this.j = true;
    }
}
