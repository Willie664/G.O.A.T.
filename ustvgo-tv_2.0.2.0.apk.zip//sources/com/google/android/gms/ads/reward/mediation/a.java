package com.google.android.gms.ads.reward.mediation;

import android.os.Bundle;

public interface a {
    void a(Bundle bundle);

    void a(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void a(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter, int i);

    void a(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter, com.google.android.gms.ads.reward.a aVar);

    void b(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void c(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void d(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void e(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void f(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);

    void g(MediationRewardedVideoAdAdapter mediationRewardedVideoAdAdapter);
}
