package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.auc;
import com.google.android.gms.internal.ads.iy;

final class al implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ auc f1212a;
    private final /* synthetic */ ad b;

    al(ad adVar, auc auc) {
        this.b = adVar;
        this.f1212a = auc;
    }

    public final void run() {
        try {
            this.b.e.v.get(this.f1212a.l()).a(this.f1212a);
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
