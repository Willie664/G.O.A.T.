package com.google.android.gms.ads;

import com.google.android.gms.internal.ads.ant;
import com.google.android.gms.internal.ads.cj;

@cj
public final class e {

    /* renamed from: a  reason: collision with root package name */
    public ant f1192a;
}
