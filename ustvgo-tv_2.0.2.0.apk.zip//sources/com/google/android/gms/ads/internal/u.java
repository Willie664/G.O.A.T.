package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.arz;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.rd;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final /* synthetic */ class u implements rd {

    /* renamed from: a  reason: collision with root package name */
    private final arz f1293a;
    private final String b;
    private final pu c;

    u(arz arz, String str, pu puVar) {
        this.f1293a = arz;
        this.b = str;
        this.c = puVar;
    }

    public final void a(boolean z) {
        arz arz = this.f1293a;
        String str = this.b;
        pu puVar = this.c;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("headline", arz.a());
            jSONObject.put("body", arz.e());
            jSONObject.put("call_to_action", arz.g());
            jSONObject.put("advertiser", arz.h());
            jSONObject.put("logo", s.a(arz.f()));
            JSONArray jSONArray = new JSONArray();
            List<Object> b2 = arz.b();
            if (b2 != null) {
                for (Object a2 : b2) {
                    jSONArray.put(s.a(s.a(a2)));
                }
            }
            jSONObject.put("images", jSONArray);
            jSONObject.put("extras", s.a(arz.n(), str));
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("assets", jSONObject);
            jSONObject2.put("template_id", "1");
            puVar.b("google.afma.nativeExpressAds.loadAssets", jSONObject2);
        } catch (JSONException e) {
            iy.b("Exception occurred when loading assets", e);
        }
    }
}
