package com.google.android.gms.ads.internal.gmsg;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public interface m {
    void a(String str, String str2);
}
