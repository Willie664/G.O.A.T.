package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.gq;
import com.google.android.gms.internal.ads.zzaig;

final class o implements gq {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ m f1277a;

    o(m mVar) {
        this.f1277a = mVar;
    }

    public final void a(zzaig zzaig) {
        this.f1277a.a(zzaig);
    }

    public final void b() {
        this.f1277a.f_();
    }

    public final void c() {
        this.f1277a.r_();
    }

    public final void n_() {
        this.f1277a.g();
    }

    public final void o_() {
        this.f1277a.g_();
    }

    public final void p_() {
        this.f1277a.e();
    }

    public final void q_() {
        this.f1277a.v();
    }
}
