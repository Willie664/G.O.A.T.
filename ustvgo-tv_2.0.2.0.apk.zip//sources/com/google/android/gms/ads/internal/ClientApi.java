package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.Keep;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.p;
import com.google.android.gms.ads.internal.overlay.r;
import com.google.android.gms.ads.internal.overlay.w;
import com.google.android.gms.ads.internal.overlay.x;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.internal.ads.aoe;
import com.google.android.gms.internal.ads.aoj;
import com.google.android.gms.internal.ads.aow;
import com.google.android.gms.internal.ads.apb;
import com.google.android.gms.internal.ads.asw;
import com.google.android.gms.internal.ads.asy;
import com.google.android.gms.internal.ads.atk;
import com.google.android.gms.internal.ads.atp;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.fo;
import com.google.android.gms.internal.ads.fx;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.q;
import com.google.android.gms.internal.ads.z;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjn;
import java.util.HashMap;
import javax.annotation.ParametersAreNonnullByDefault;

@Keep
@cj
@DynamiteApi
@ParametersAreNonnullByDefault
public class ClientApi extends aow {
    public aoe createAdLoaderBuilder(a aVar, String str, bav bav, int i) {
        Context context = (Context) b.a(aVar);
        aw.e();
        return new l(context, str, bav, new zzang(i, jh.j(context)), bt.a(context));
    }

    public q createAdOverlay(a aVar) {
        Activity activity = (Activity) b.a(aVar);
        AdOverlayInfoParcel a2 = AdOverlayInfoParcel.a(activity.getIntent());
        if (a2 == null) {
            return new com.google.android.gms.ads.internal.overlay.q(activity);
        }
        switch (a2.k) {
            case 1:
                return new p(activity);
            case 2:
                return new w(activity);
            case 3:
                return new x(activity);
            case 4:
                return new r(activity, a2);
            default:
                return new com.google.android.gms.ads.internal.overlay.q(activity);
        }
    }

    public aoj createBannerAdManager(a aVar, zzjn zzjn, String str, bav bav, int i) {
        Context context = (Context) b.a(aVar);
        aw.e();
        return new bv(context, zzjn, str, bav, new zzang(i, jh.j(context)), bt.a(context));
    }

    public z createInAppPurchaseManager(a aVar) {
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0030, code lost:
        if (((java.lang.Boolean) com.google.android.gms.internal.ads.ans.f().a(com.google.android.gms.internal.ads.aqs.aT)).booleanValue() == false) goto L_0x0032;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0044, code lost:
        if (((java.lang.Boolean) com.google.android.gms.internal.ads.ans.f().a(com.google.android.gms.internal.ads.aqs.aU)).booleanValue() != false) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0046, code lost:
        r8 = true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.ads.aoj createInterstitialAdManager(com.google.android.gms.b.a r8, com.google.android.gms.internal.ads.zzjn r9, java.lang.String r10, com.google.android.gms.internal.ads.bav r11, int r12) {
        /*
            r7 = this;
            java.lang.Object r8 = com.google.android.gms.b.b.a((com.google.android.gms.b.a) r8)
            r1 = r8
            android.content.Context r1 = (android.content.Context) r1
            com.google.android.gms.internal.ads.aqs.a(r1)
            com.google.android.gms.internal.ads.zzang r5 = new com.google.android.gms.internal.ads.zzang
            com.google.android.gms.ads.internal.aw.e()
            boolean r8 = com.google.android.gms.internal.ads.jh.j(r1)
            r5.<init>(r12, r8)
            java.lang.String r8 = "reward_mb"
            java.lang.String r12 = r9.f2399a
            boolean r8 = r8.equals(r12)
            if (r8 != 0) goto L_0x0032
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r12 = com.google.android.gms.internal.ads.aqs.aT
            com.google.android.gms.internal.ads.aqq r0 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r12 = r0.a(r12)
            java.lang.Boolean r12 = (java.lang.Boolean) r12
            boolean r12 = r12.booleanValue()
            if (r12 != 0) goto L_0x0046
        L_0x0032:
            if (r8 == 0) goto L_0x0048
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r8 = com.google.android.gms.internal.ads.aqs.aU
            com.google.android.gms.internal.ads.aqq r12 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r8 = r12.a(r8)
            java.lang.Boolean r8 = (java.lang.Boolean) r8
            boolean r8 = r8.booleanValue()
            if (r8 == 0) goto L_0x0048
        L_0x0046:
            r8 = 1
            goto L_0x0049
        L_0x0048:
            r8 = 0
        L_0x0049:
            if (r8 == 0) goto L_0x005a
            com.google.android.gms.internal.ads.axi r8 = new com.google.android.gms.internal.ads.axi
            com.google.android.gms.ads.internal.bt r9 = com.google.android.gms.ads.internal.bt.a(r1)
            r0 = r8
            r2 = r10
            r3 = r11
            r4 = r5
            r5 = r9
            r0.<init>(r1, r2, r3, r4, r5)
            return r8
        L_0x005a:
            com.google.android.gms.ads.internal.m r8 = new com.google.android.gms.ads.internal.m
            com.google.android.gms.ads.internal.bt r6 = com.google.android.gms.ads.internal.bt.a(r1)
            r0 = r8
            r2 = r9
            r3 = r10
            r4 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.ClientApi.createInterstitialAdManager(com.google.android.gms.b.a, com.google.android.gms.internal.ads.zzjn, java.lang.String, com.google.android.gms.internal.ads.bav, int):com.google.android.gms.internal.ads.aoj");
    }

    public atk createNativeAdViewDelegate(a aVar, a aVar2) {
        return new asw((FrameLayout) b.a(aVar), (FrameLayout) b.a(aVar2));
    }

    public atp createNativeAdViewHolderDelegate(a aVar, a aVar2, a aVar3) {
        return new asy((View) b.a(aVar), (HashMap) b.a(aVar2), (HashMap) b.a(aVar3));
    }

    public fx createRewardedVideoAd(a aVar, bav bav, int i) {
        Context context = (Context) b.a(aVar);
        aw.e();
        return new fo(context, bt.a(context), bav, new zzang(i, jh.j(context)));
    }

    public aoj createSearchAdManager(a aVar, zzjn zzjn, String str, int i) {
        Context context = (Context) b.a(aVar);
        aw.e();
        return new aq(context, zzjn, str, new zzang(i, jh.j(context)));
    }

    public apb getMobileAdsSettingsManager(a aVar) {
        return null;
    }

    public apb getMobileAdsSettingsManagerWithClientJarVersion(a aVar, int i) {
        Context context = (Context) b.a(aVar);
        aw.e();
        return y.a(context, new zzang(i, jh.j(context)));
    }
}
