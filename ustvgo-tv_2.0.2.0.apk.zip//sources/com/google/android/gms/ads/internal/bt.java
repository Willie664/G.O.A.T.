package com.google.android.gms.ads.internal;

import android.content.Context;
import com.google.android.gms.internal.ads.als;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.hk;
import com.google.android.gms.internal.ads.hl;
import com.google.android.gms.internal.ads.hp;
import com.google.android.gms.internal.ads.oe;
import com.google.android.gms.internal.ads.ol;
import com.google.android.gms.internal.ads.oz;
import com.google.android.gms.internal.ads.pk;

@cj
public final class bt {

    /* renamed from: a  reason: collision with root package name */
    public final pk f1242a;
    public final oe b;
    public final hp c;
    public final als d;

    private bt(pk pkVar, oe oeVar, hp hpVar, als als) {
        this.f1242a = pkVar;
        this.b = oeVar;
        this.c = hpVar;
        this.d = als;
    }

    public static bt a(Context context) {
        return new bt(new oz(), new ol(), new hk(new hl()), new als(context));
    }
}
