package com.google.android.gms.ads.doubleclick;

public interface a {
    void a(String str, String str2);
}
