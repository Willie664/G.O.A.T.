package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.arx;
import com.google.android.gms.internal.ads.arz;
import com.google.android.gms.internal.ads.ase;
import com.google.android.gms.internal.ads.asl;
import com.google.android.gms.internal.ads.iy;
import java.util.List;

final class ag implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ asl f1207a;
    private final /* synthetic */ int b;
    private final /* synthetic */ List c;
    private final /* synthetic */ ad d;

    ag(ad adVar, asl asl, int i, List list) {
        this.d = adVar;
        this.f1207a = asl;
        this.b = i;
        this.c = list;
    }

    public final void run() {
        try {
            boolean z = false;
            if ((this.f1207a instanceof arz) && this.d.e.t != null) {
                ad adVar = this.d;
                if (this.b != this.c.size() - 1) {
                    z = true;
                }
                adVar.c = z;
                ase a2 = ad.b(this.f1207a);
                this.d.e.t.a(a2);
                this.d.a(a2.n());
            } else if ((this.f1207a instanceof arz) && this.d.e.s != null) {
                ad adVar2 = this.d;
                if (this.b != this.c.size() - 1) {
                    z = true;
                }
                adVar2.c = z;
                arz arz = (arz) this.f1207a;
                this.d.e.s.a(arz);
                this.d.a(arz.j());
            } else if ((this.f1207a instanceof arx) && this.d.e.t != null) {
                ad adVar3 = this.d;
                if (this.b != this.c.size() - 1) {
                    z = true;
                }
                adVar3.c = z;
                ase a3 = ad.b(this.f1207a);
                this.d.e.t.a(a3);
                this.d.a(a3.n());
            } else if (!(this.f1207a instanceof arx) || this.d.e.r == null) {
                ad adVar4 = this.d;
                if (this.b != this.c.size() - 1) {
                    z = true;
                }
                adVar4.a(3, z);
            } else {
                ad adVar5 = this.d;
                if (this.b != this.c.size() - 1) {
                    z = true;
                }
                adVar5.c = z;
                arx arx = (arx) this.f1207a;
                this.d.e.r.a(arx);
                this.d.a(arx.j());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
