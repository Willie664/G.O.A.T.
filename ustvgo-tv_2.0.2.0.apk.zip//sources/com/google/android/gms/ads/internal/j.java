package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.zzjj;

final class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ zzjj f1273a;
    private final /* synthetic */ i b;

    j(i iVar, zzjj zzjj) {
        this.b = iVar;
        this.f1273a = zzjj;
    }

    public final void run() {
        synchronized (this.b.s) {
            if (i.b(this.b)) {
                i.a(this.b, this.f1273a);
            } else {
                i.a(this.b, this.f1273a, 1);
            }
        }
    }
}
