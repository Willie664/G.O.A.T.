package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.al;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.arg;
import com.google.android.gms.internal.ads.ho;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.qf;

final class bi implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ ie f1233a;
    final /* synthetic */ ho b;
    final /* synthetic */ bf c;
    private final /* synthetic */ arf d;

    bi(bf bfVar, ie ieVar, ho hoVar, arf arf) {
        this.c = bfVar;
        this.f1233a = ieVar;
        this.b = hoVar;
        this.d = arf;
    }

    public final void run() {
        if (this.f1233a.b.r && this.c.e.B != null) {
            String str = null;
            if (this.f1233a.b.f2384a != null) {
                aw.e();
                str = jh.a(this.f1233a.b.f2384a);
            }
            arg arg = new arg(this.c, str, this.f1233a.b.b);
            this.c.e.I = 1;
            try {
                this.c.c = false;
                this.c.e.B.a(arg);
                return;
            } catch (RemoteException e) {
                iy.c("#007 Could not call remote method.", e);
                this.c.c = true;
            }
        }
        bu buVar = new bu(this.c.e.c, this.b, this.f1233a.b.E);
        try {
            pu a2 = this.c.a(this.f1233a, buVar, this.b);
            a2.setOnTouchListener(new bk(this, buVar));
            a2.setOnClickListener(new bl(this, buVar));
            this.c.e.I = 0;
            ax axVar = this.c.e;
            aw.d();
            axVar.h = al.a(this.c.e.c, this.c, this.f1233a, this.c.e.d, a2, this.c.o, this.c, this.d);
        } catch (qf e2) {
            iy.a("Could not obtain webview.", e2);
            jh.f2130a.post(new bj(this));
        }
    }
}
