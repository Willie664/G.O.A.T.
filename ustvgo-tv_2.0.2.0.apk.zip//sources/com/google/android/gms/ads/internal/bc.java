package com.google.android.gms.ads.internal;

final /* synthetic */ class bc implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final am f1228a;

    private bc(am amVar) {
        this.f1228a = amVar;
    }

    static Runnable a(am amVar) {
        return new bc(amVar);
    }

    public final void run() {
        this.f1228a.c();
    }
}
