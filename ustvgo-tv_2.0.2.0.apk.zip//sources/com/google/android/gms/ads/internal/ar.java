package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.iy;

final class ar extends WebViewClient {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ aq f1217a;

    ar(aq aqVar) {
        this.f1217a = aqVar;
    }

    public final void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
        if (this.f1217a.g != null) {
            try {
                this.f1217a.g.a(0);
            } catch (RemoteException e) {
                iy.c("#007 Could not call remote method.", e);
            }
        }
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        if (str.startsWith(this.f1217a.d())) {
            return false;
        }
        if (str.startsWith((String) ans.f().a(aqs.cu))) {
            if (this.f1217a.g != null) {
                try {
                    this.f1217a.g.a(3);
                } catch (RemoteException e) {
                    iy.c("#007 Could not call remote method.", e);
                }
            }
            this.f1217a.a(0);
            return true;
        }
        if (str.startsWith((String) ans.f().a(aqs.cv))) {
            if (this.f1217a.g != null) {
                try {
                    this.f1217a.g.a(0);
                } catch (RemoteException e2) {
                    iy.c("#007 Could not call remote method.", e2);
                }
            }
            this.f1217a.a(0);
            return true;
        }
        if (str.startsWith((String) ans.f().a(aqs.cw))) {
            if (this.f1217a.g != null) {
                try {
                    this.f1217a.g.c();
                } catch (RemoteException e3) {
                    iy.c("#007 Could not call remote method.", e3);
                }
            }
            this.f1217a.a(this.f1217a.b(str));
            return true;
        } else if (str.startsWith("gmsg://")) {
            return true;
        } else {
            if (this.f1217a.g != null) {
                try {
                    this.f1217a.g.b();
                } catch (RemoteException e4) {
                    iy.c("#007 Could not call remote method.", e4);
                }
            }
            aq.b(this.f1217a, this.f1217a.c(str));
            return true;
        }
    }
}
