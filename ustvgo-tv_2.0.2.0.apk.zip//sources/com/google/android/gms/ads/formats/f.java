package com.google.android.gms.ads.formats;

public interface f {

    public interface a {
        void a(f fVar, String str);
    }

    public interface b {
        void a(f fVar);
    }

    String a();
}
