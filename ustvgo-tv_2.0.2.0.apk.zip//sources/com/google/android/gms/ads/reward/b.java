package com.google.android.gms.ads.reward;

public interface b {
    void a();

    void a(int i);

    void a(a aVar);

    void b();

    void c();

    void d();

    void e();

    void f();
}
