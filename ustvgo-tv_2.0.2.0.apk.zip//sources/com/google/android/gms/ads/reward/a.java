package com.google.android.gms.ads.reward;

public interface a {
    String a();

    int b();
}
