package com.google.android.gms.ads.internal;

public interface ap {
    void j_();

    void k_();
}
