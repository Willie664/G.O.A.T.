package com.google.android.gms.ads.mediation;

public interface j {
    void onImmersiveModeUpdated(boolean z);
}
