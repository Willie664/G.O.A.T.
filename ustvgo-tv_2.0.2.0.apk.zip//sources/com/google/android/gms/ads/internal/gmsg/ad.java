package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class ad implements ae<pu> {
    ad() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        if (map.keySet().contains("start")) {
            puVar.e(true);
        }
        if (map.keySet().contains("stop")) {
            puVar.e(false);
        }
    }
}
