package com.google.android.gms.ads.internal.gmsg;

public interface ai {
    void a(boolean z);

    void a(boolean z, float f);
}
