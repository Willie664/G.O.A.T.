package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.ads.internal.overlay.c;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class w implements ae<pu> {
    w() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        c r = puVar.r();
        if (r != null) {
            r.a();
            return;
        }
        c s = puVar.s();
        if (s != null) {
            s.a();
        } else {
            iy.b("A GMSG tried to close something that wasn't an overlay.");
        }
    }
}
