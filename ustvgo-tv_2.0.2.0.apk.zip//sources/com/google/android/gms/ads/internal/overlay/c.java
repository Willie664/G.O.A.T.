package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.util.o;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.jm;
import com.google.android.gms.internal.ads.m;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.r;
import java.util.Collections;
import java.util.Map;

@cj
public class c extends r implements v {
    private static final int e = Color.argb(0, 0, 0, 0);

    /* renamed from: a  reason: collision with root package name */
    protected final Activity f1279a;
    AdOverlayInfoParcel b;
    pu c;
    int d = 0;
    private h f;
    private n g;
    private boolean h = false;
    private FrameLayout i;
    private WebChromeClient.CustomViewCallback j;
    private boolean k = false;
    private boolean l = false;
    private g m;
    private boolean n = false;
    private final Object o = new Object();
    private Runnable p;
    private boolean q;
    private boolean r;
    private boolean s = false;
    private boolean t = false;
    private boolean u = true;

    public c(Activity activity) {
        this.f1279a = activity;
    }

    private final void a(boolean z) {
        int intValue = ((Integer) ans.f().a(aqs.da)).intValue();
        o oVar = new o();
        oVar.e = 50;
        oVar.f1287a = z ? intValue : 0;
        oVar.b = z ? 0 : intValue;
        oVar.c = 0;
        oVar.d = intValue;
        this.g = new n(this.f1279a, oVar, this);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(10);
        layoutParams.addRule(z ? 11 : 9);
        a(z, this.b.g);
        this.m.addView(this.g, layoutParams);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00c6, code lost:
        if (r1.f1279a.getResources().getConfiguration().orientation == 1) goto L_0x00c8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00e7, code lost:
        if (r1.f1279a.getResources().getConfiguration().orientation == 2) goto L_0x00c8;
     */
    /* JADX WARNING: Removed duplicated region for block: B:106:0x0258  */
    /* JADX WARNING: Removed duplicated region for block: B:110:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0052  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x009f  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00a2  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00a7  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00ac  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0117  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x011f  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x012f A[SYNTHETIC, Splitter:B:59:0x012f] */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0206  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x0233  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void b(boolean r19) {
        /*
            r18 = this;
            r1 = r18
            boolean r2 = r1.r
            r3 = 1
            if (r2 != 0) goto L_0x000c
            android.app.Activity r2 = r1.f1279a
            r2.requestWindowFeature(r3)
        L_0x000c:
            android.app.Activity r2 = r1.f1279a
            android.view.Window r2 = r2.getWindow()
            if (r2 == 0) goto L_0x025c
            boolean r4 = com.google.android.gms.common.util.o.h()
            if (r4 == 0) goto L_0x0040
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r4 = com.google.android.gms.internal.ads.aqs.cY
            com.google.android.gms.internal.ads.aqq r5 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r4 = r5.a(r4)
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            if (r4 == 0) goto L_0x0040
            com.google.android.gms.ads.internal.aw.e()
            android.app.Activity r4 = r1.f1279a
            android.app.Activity r5 = r1.f1279a
            android.content.res.Resources r5 = r5.getResources()
            android.content.res.Configuration r5 = r5.getConfiguration()
            boolean r4 = com.google.android.gms.internal.ads.jh.a((android.app.Activity) r4, (android.content.res.Configuration) r5)
            goto L_0x0041
        L_0x0040:
            r4 = 1
        L_0x0041:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r5 = r1.b
            com.google.android.gms.ads.internal.zzaq r5 = r5.o
            r6 = 0
            if (r5 == 0) goto L_0x0052
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r5 = r1.b
            com.google.android.gms.ads.internal.zzaq r5 = r5.o
            boolean r5 = r5.b
            if (r5 == 0) goto L_0x0052
            r5 = 1
            goto L_0x0053
        L_0x0052:
            r5 = 0
        L_0x0053:
            boolean r7 = r1.l
            if (r7 == 0) goto L_0x0059
            if (r5 == 0) goto L_0x008f
        L_0x0059:
            if (r4 == 0) goto L_0x008f
            r4 = 1024(0x400, float:1.435E-42)
            r2.setFlags(r4, r4)
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r4 = com.google.android.gms.internal.ads.aqs.aQ
            com.google.android.gms.internal.ads.aqq r5 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r4 = r5.a(r4)
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            if (r4 == 0) goto L_0x008f
            boolean r4 = com.google.android.gms.common.util.o.e()
            if (r4 == 0) goto L_0x008f
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r4 = r1.b
            com.google.android.gms.ads.internal.zzaq r4 = r4.o
            if (r4 == 0) goto L_0x008f
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r4 = r1.b
            com.google.android.gms.ads.internal.zzaq r4 = r4.o
            boolean r4 = r4.f
            if (r4 == 0) goto L_0x008f
            android.view.View r4 = r2.getDecorView()
            r5 = 4098(0x1002, float:5.743E-42)
            r4.setSystemUiVisibility(r5)
        L_0x008f:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r4 = r1.b
            com.google.android.gms.internal.ads.pu r4 = r4.d
            r5 = 0
            if (r4 == 0) goto L_0x009f
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r4 = r1.b
            com.google.android.gms.internal.ads.pu r4 = r4.d
            com.google.android.gms.internal.ads.rc r4 = r4.v()
            goto L_0x00a0
        L_0x009f:
            r4 = r5
        L_0x00a0:
            if (r4 == 0) goto L_0x00a7
            boolean r4 = r4.b()
            goto L_0x00a8
        L_0x00a7:
            r4 = 0
        L_0x00a8:
            r1.n = r6
            if (r4 == 0) goto L_0x00ea
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r7 = r1.b
            int r7 = r7.j
            com.google.android.gms.internal.ads.jm r8 = com.google.android.gms.ads.internal.aw.g()
            int r8 = r8.a()
            if (r7 != r8) goto L_0x00cc
            android.app.Activity r7 = r1.f1279a
            android.content.res.Resources r7 = r7.getResources()
            android.content.res.Configuration r7 = r7.getConfiguration()
            int r7 = r7.orientation
            if (r7 != r3) goto L_0x00c9
        L_0x00c8:
            r6 = 1
        L_0x00c9:
            r1.n = r6
            goto L_0x00ea
        L_0x00cc:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r7 = r1.b
            int r7 = r7.j
            com.google.android.gms.internal.ads.jm r8 = com.google.android.gms.ads.internal.aw.g()
            int r8 = r8.b()
            if (r7 != r8) goto L_0x00ea
            android.app.Activity r7 = r1.f1279a
            android.content.res.Resources r7 = r7.getResources()
            android.content.res.Configuration r7 = r7.getConfiguration()
            int r7 = r7.orientation
            r8 = 2
            if (r7 != r8) goto L_0x00c9
            goto L_0x00c8
        L_0x00ea:
            boolean r6 = r1.n
            r7 = 46
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>(r7)
            java.lang.String r7 = "Delay onShow to next orientation change: "
            r8.append(r7)
            r8.append(r6)
            r6 = 3
            com.google.android.gms.internal.ads.ma.a((int) r6)
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r7 = r1.b
            int r7 = r7.j
            r1.a((int) r7)
            com.google.android.gms.internal.ads.jm r7 = com.google.android.gms.ads.internal.aw.g()
            boolean r2 = r7.a((android.view.Window) r2)
            if (r2 == 0) goto L_0x0113
            com.google.android.gms.internal.ads.ma.a((int) r6)
        L_0x0113:
            boolean r2 = r1.l
            if (r2 != 0) goto L_0x011f
            com.google.android.gms.ads.internal.overlay.g r2 = r1.m
            r6 = -16777216(0xffffffffff000000, float:-1.7014118E38)
        L_0x011b:
            r2.setBackgroundColor(r6)
            goto L_0x0124
        L_0x011f:
            com.google.android.gms.ads.internal.overlay.g r2 = r1.m
            int r6 = e
            goto L_0x011b
        L_0x0124:
            android.app.Activity r2 = r1.f1279a
            com.google.android.gms.ads.internal.overlay.g r6 = r1.m
            r2.setContentView(r6)
            r1.r = r3
            if (r19 == 0) goto L_0x0206
            com.google.android.gms.ads.internal.aw.f()     // Catch:{ Exception -> 0x01f8 }
            android.app.Activity r7 = r1.f1279a     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            if (r2 == 0) goto L_0x0144
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.ri r2 = r2.t()     // Catch:{ Exception -> 0x01f8 }
            r8 = r2
            goto L_0x0145
        L_0x0144:
            r8 = r5
        L_0x0145:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            if (r2 == 0) goto L_0x0155
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            java.lang.String r2 = r2.u()     // Catch:{ Exception -> 0x01f8 }
            r9 = r2
            goto L_0x0156
        L_0x0155:
            r9 = r5
        L_0x0156:
            r10 = 1
            r12 = 0
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.zzang r13 = r2.m     // Catch:{ Exception -> 0x01f8 }
            r14 = 0
            r15 = 0
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            if (r2 == 0) goto L_0x016f
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r2.d     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.ads.internal.bt r2 = r2.e()     // Catch:{ Exception -> 0x01f8 }
            r16 = r2
            goto L_0x0171
        L_0x016f:
            r16 = r5
        L_0x0171:
            com.google.android.gms.internal.ads.aln r17 = new com.google.android.gms.internal.ads.aln     // Catch:{ Exception -> 0x01f8 }
            r17.<init>()     // Catch:{ Exception -> 0x01f8 }
            r11 = r4
            com.google.android.gms.internal.ads.pu r2 = com.google.android.gms.internal.ads.qb.a(r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17)     // Catch:{ Exception -> 0x01f8 }
            r1.c = r2     // Catch:{ Exception -> 0x01f8 }
            com.google.android.gms.internal.ads.pu r2 = r1.c
            com.google.android.gms.internal.ads.rc r6 = r2.v()
            r7 = 0
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.ads.internal.gmsg.k r8 = r2.p
            r9 = 0
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.ads.internal.gmsg.m r10 = r2.e
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.ads.internal.overlay.s r11 = r2.i
            r12 = 1
            r13 = 0
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.internal.ads.pu r2 = r2.d
            if (r2 == 0) goto L_0x01a5
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.internal.ads.pu r2 = r2.d
            com.google.android.gms.internal.ads.rc r2 = r2.v()
            com.google.android.gms.ads.internal.bu r5 = r2.a()
        L_0x01a5:
            r14 = r5
            r15 = 0
            r16 = 0
            r6.a(r7, r8, r9, r10, r11, r12, r13, r14, r15, r16)
            com.google.android.gms.internal.ads.pu r2 = r1.c
            com.google.android.gms.internal.ads.rc r2 = r2.v()
            com.google.android.gms.ads.internal.overlay.d r5 = new com.google.android.gms.ads.internal.overlay.d
            r5.<init>(r1)
            r2.a((com.google.android.gms.internal.ads.rd) r5)
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            java.lang.String r2 = r2.l
            if (r2 == 0) goto L_0x01ca
            com.google.android.gms.internal.ads.pu r2 = r1.c
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r5 = r1.b
            java.lang.String r5 = r5.l
            r2.loadUrl(r5)
            goto L_0x01e2
        L_0x01ca:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            java.lang.String r2 = r2.h
            if (r2 == 0) goto L_0x01f0
            com.google.android.gms.internal.ads.pu r5 = r1.c
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            java.lang.String r6 = r2.f
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            java.lang.String r7 = r2.h
            java.lang.String r8 = "text/html"
            java.lang.String r9 = "UTF-8"
            r10 = 0
            r5.loadDataWithBaseURL(r6, r7, r8, r9, r10)
        L_0x01e2:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.internal.ads.pu r2 = r2.d
            if (r2 == 0) goto L_0x0213
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.internal.ads.pu r2 = r2.d
            r2.b((com.google.android.gms.ads.internal.overlay.c) r1)
            goto L_0x0213
        L_0x01f0:
            com.google.android.gms.ads.internal.overlay.f r0 = new com.google.android.gms.ads.internal.overlay.f
            java.lang.String r2 = "No URL or HTML to display in ad overlay."
            r0.<init>(r2)
            throw r0
        L_0x01f8:
            r0 = move-exception
            java.lang.String r2 = "Error obtaining webview."
            com.google.android.gms.internal.ads.iy.a(r2, r0)
            com.google.android.gms.ads.internal.overlay.f r0 = new com.google.android.gms.ads.internal.overlay.f
            java.lang.String r2 = "Could not obtain webview for the overlay."
            r0.<init>(r2)
            throw r0
        L_0x0206:
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r2 = r1.b
            com.google.android.gms.internal.ads.pu r2 = r2.d
            r1.c = r2
            com.google.android.gms.internal.ads.pu r2 = r1.c
            android.app.Activity r5 = r1.f1279a
            r2.a((android.content.Context) r5)
        L_0x0213:
            com.google.android.gms.internal.ads.pu r2 = r1.c
            r2.a((com.google.android.gms.ads.internal.overlay.c) r1)
            com.google.android.gms.internal.ads.pu r2 = r1.c
            android.view.ViewParent r2 = r2.getParent()
            if (r2 == 0) goto L_0x022f
            boolean r5 = r2 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x022f
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            com.google.android.gms.internal.ads.pu r5 = r1.c
            android.view.View r5 = r5.getView()
            r2.removeView(r5)
        L_0x022f:
            boolean r2 = r1.l
            if (r2 == 0) goto L_0x0238
            com.google.android.gms.internal.ads.pu r2 = r1.c
            r2.I()
        L_0x0238:
            com.google.android.gms.ads.internal.overlay.g r2 = r1.m
            com.google.android.gms.internal.ads.pu r5 = r1.c
            android.view.View r5 = r5.getView()
            r6 = -1
            r2.addView(r5, r6, r6)
            if (r19 != 0) goto L_0x024d
            boolean r0 = r1.n
            if (r0 != 0) goto L_0x024d
            r18.s()
        L_0x024d:
            r1.a((boolean) r4)
            com.google.android.gms.internal.ads.pu r0 = r1.c
            boolean r0 = r0.x()
            if (r0 == 0) goto L_0x025b
            r1.a((boolean) r4, (boolean) r3)
        L_0x025b:
            return
        L_0x025c:
            com.google.android.gms.ads.internal.overlay.f r0 = new com.google.android.gms.ads.internal.overlay.f
            java.lang.String r2 = "Invalid activity, no window available."
            r0.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.overlay.c.b(boolean):void");
    }

    private final void r() {
        if (this.f1279a.isFinishing() && !this.s) {
            this.s = true;
            if (this.c != null) {
                this.c.a(this.d);
                synchronized (this.o) {
                    if (!this.q && this.c.E()) {
                        this.p = new e(this);
                        jh.f2130a.postDelayed(this.p, ((Long) ans.f().a(aqs.aP)).longValue());
                        return;
                    }
                }
            }
            n();
        }
    }

    private final void s() {
        this.c.o();
    }

    public final void a() {
        this.d = 2;
        this.f1279a.finish();
    }

    public final void a(int i2) {
        if (this.f1279a.getApplicationInfo().targetSdkVersion >= ((Integer) ans.f().a(aqs.dn)).intValue()) {
            if (this.f1279a.getApplicationInfo().targetSdkVersion <= ((Integer) ans.f().a(aqs.f0do)).intValue()) {
                if (Build.VERSION.SDK_INT >= ((Integer) ans.f().a(aqs.dp)).intValue()) {
                    if (Build.VERSION.SDK_INT <= ((Integer) ans.f().a(aqs.dq)).intValue()) {
                        return;
                    }
                }
            }
        }
        this.f1279a.setRequestedOrientation(i2);
    }

    public final void a(int i2, int i3, Intent intent) {
    }

    public void a(Bundle bundle) {
        this.f1279a.requestWindowFeature(1);
        this.k = bundle != null ? bundle.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false) : false;
        try {
            this.b = AdOverlayInfoParcel.a(this.f1279a.getIntent());
            if (this.b != null) {
                if (this.b.m.c > 7500000) {
                    this.d = 3;
                }
                if (this.f1279a.getIntent() != null) {
                    this.u = this.f1279a.getIntent().getBooleanExtra("shouldCallOnOverlayOpened", true);
                }
                if (this.b.o != null) {
                    this.l = this.b.o.f1299a;
                } else {
                    this.l = false;
                }
                if (((Boolean) ans.f().a(aqs.bR)).booleanValue() && this.l && this.b.o.e != -1) {
                    new i(this, (byte) 0).h();
                }
                if (bundle == null) {
                    if (this.b.c != null && this.u) {
                        this.b.c.g();
                    }
                    if (!(this.b.k == 1 || this.b.b == null)) {
                        this.b.b.e();
                    }
                }
                this.m = new g(this.f1279a, this.b.n, this.b.m.f2393a);
                this.m.setId(AdError.NETWORK_ERROR_CODE);
                switch (this.b.k) {
                    case 1:
                        b(false);
                        return;
                    case 2:
                        this.f = new h(this.b.d);
                        b(false);
                        return;
                    case 3:
                        b(true);
                        return;
                    default:
                        throw new f("Could not determine ad overlay type.");
                }
            } else {
                throw new f("Could not get info for ad overlay.");
            }
        } catch (f e2) {
            iy.b(e2.getMessage());
            this.d = 3;
            this.f1279a.finish();
        }
    }

    public final void a(View view, WebChromeClient.CustomViewCallback customViewCallback) {
        this.i = new FrameLayout(this.f1279a);
        this.i.setBackgroundColor(-16777216);
        this.i.addView(view, -1, -1);
        this.f1279a.setContentView(this.i);
        this.r = true;
        this.j = customViewCallback;
        this.h = true;
    }

    public final void a(a aVar) {
        if (((Boolean) ans.f().a(aqs.cY)).booleanValue() && o.h()) {
            aw.e();
            if (jh.a(this.f1279a, (Configuration) b.a(aVar))) {
                this.f1279a.getWindow().addFlags(1024);
                this.f1279a.getWindow().clearFlags(RecyclerView.ItemAnimator.FLAG_MOVED);
                return;
            }
            this.f1279a.getWindow().addFlags(RecyclerView.ItemAnimator.FLAG_MOVED);
            this.f1279a.getWindow().clearFlags(1024);
        }
    }

    public final void a(boolean z, boolean z2) {
        boolean z3 = true;
        boolean z4 = ((Boolean) ans.f().a(aqs.aR)).booleanValue() && this.b != null && this.b.o != null && this.b.o.g;
        boolean z5 = ((Boolean) ans.f().a(aqs.aS)).booleanValue() && this.b != null && this.b.o != null && this.b.o.h;
        if (z && z2 && z4 && !z5) {
            new m(this.c, "useCustomClose").a("Custom close has been disabled for interstitial ads in this ad slot.");
        }
        if (this.g != null) {
            n nVar = this.g;
            if (!z5 && (!z2 || z4)) {
                z3 = false;
            }
            nVar.a(z3);
        }
    }

    public final void b() {
        if (this.b != null && this.h) {
            a(this.b.j);
        }
        if (this.i != null) {
            this.f1279a.setContentView(this.m);
            this.r = true;
            this.i.removeAllViews();
            this.i = null;
        }
        if (this.j != null) {
            this.j.onCustomViewHidden();
            this.j = null;
        }
        this.h = false;
    }

    public final void b(Bundle bundle) {
        bundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.k);
    }

    public final void c() {
        this.d = 1;
        this.f1279a.finish();
    }

    public final void d() {
        this.d = 0;
    }

    public final boolean e() {
        this.d = 0;
        if (this.c == null) {
            return true;
        }
        boolean C = this.c.C();
        if (!C) {
            this.c.a("onbackblocked", (Map<String, ?>) Collections.emptyMap());
        }
        return C;
    }

    public final void f() {
    }

    public final void g() {
        if (!((Boolean) ans.f().a(aqs.cZ)).booleanValue()) {
            return;
        }
        if (this.c == null || this.c.A()) {
            iy.b("The webview does not exist. Ignoring action.");
            return;
        }
        aw.g();
        jm.b(this.c);
    }

    public final void h() {
        if (this.b.c != null) {
            this.b.c.f();
        }
        if (((Boolean) ans.f().a(aqs.cZ)).booleanValue()) {
            return;
        }
        if (this.c == null || this.c.A()) {
            iy.b("The webview does not exist. Ignoring action.");
            return;
        }
        aw.g();
        jm.b(this.c);
    }

    public final void i() {
        b();
        if (this.b.c != null) {
            this.b.c.d();
        }
        if (!((Boolean) ans.f().a(aqs.cZ)).booleanValue() && this.c != null && (!this.f1279a.isFinishing() || this.f == null)) {
            aw.g();
            jm.a(this.c);
        }
        r();
    }

    public final void j() {
        if (((Boolean) ans.f().a(aqs.cZ)).booleanValue() && this.c != null && (!this.f1279a.isFinishing() || this.f == null)) {
            aw.g();
            jm.a(this.c);
        }
        r();
    }

    public final void k() {
        if (this.c != null) {
            this.m.removeView(this.c.getView());
        }
        r();
    }

    public final void l() {
        this.r = true;
    }

    public final void m() {
        this.m.removeView(this.g);
        a(true);
    }

    /* access modifiers changed from: package-private */
    public final void n() {
        if (!this.t) {
            this.t = true;
            if (this.c != null) {
                this.m.removeView(this.c.getView());
                if (this.f != null) {
                    this.c.a(this.f.d);
                    this.c.b(false);
                    this.f.c.addView(this.c.getView(), this.f.f1283a, this.f.b);
                    this.f = null;
                } else if (this.f1279a.getApplicationContext() != null) {
                    this.c.a(this.f1279a.getApplicationContext());
                }
                this.c = null;
            }
            if (this.b != null && this.b.c != null) {
                this.b.c.r_();
            }
        }
    }

    public final void o() {
        if (this.n) {
            this.n = false;
            s();
        }
    }

    public final void p() {
        this.m.f1282a = true;
    }

    public final void q() {
        synchronized (this.o) {
            this.q = true;
            if (this.p != null) {
                jh.f2130a.removeCallbacks(this.p);
                jh.f2130a.post(this.p);
            }
        }
    }
}
