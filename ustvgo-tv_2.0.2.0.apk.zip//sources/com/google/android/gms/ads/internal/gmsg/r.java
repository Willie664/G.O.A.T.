package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.axl;
import java.util.Map;

final /* synthetic */ class r implements ae {

    /* renamed from: a  reason: collision with root package name */
    static final ae f1268a = new r();

    private r() {
    }

    public final void zza(Object obj, Map map) {
        o.a((axl) obj, map);
    }
}
