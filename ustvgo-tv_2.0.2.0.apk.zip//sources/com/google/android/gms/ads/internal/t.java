package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.arx;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.rd;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final /* synthetic */ class t implements rd {

    /* renamed from: a  reason: collision with root package name */
    private final arx f1292a;
    private final String b;
    private final pu c;

    t(arx arx, String str, pu puVar) {
        this.f1292a = arx;
        this.b = str;
        this.c = puVar;
    }

    public final void a(boolean z) {
        arx arx = this.f1292a;
        String str = this.b;
        pu puVar = this.c;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("headline", arx.a());
            jSONObject.put("body", arx.c());
            jSONObject.put("call_to_action", arx.e());
            jSONObject.put("price", arx.h());
            jSONObject.put("star_rating", String.valueOf(arx.f()));
            jSONObject.put("store", arx.g());
            jSONObject.put("icon", s.a(arx.d()));
            JSONArray jSONArray = new JSONArray();
            List<Object> b2 = arx.b();
            if (b2 != null) {
                for (Object a2 : b2) {
                    jSONArray.put(s.a(s.a(a2)));
                }
            }
            jSONObject.put("images", jSONArray);
            jSONObject.put("extras", s.a(arx.n(), str));
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("assets", jSONObject);
            jSONObject2.put("template_id", "2");
            puVar.b("google.afma.nativeExpressAds.loadAssets", jSONObject2);
        } catch (JSONException e) {
            iy.b("Exception occurred when loading assets", e);
        }
    }
}
