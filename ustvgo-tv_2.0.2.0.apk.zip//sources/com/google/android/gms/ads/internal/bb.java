package com.google.android.gms.ads.internal;

final /* synthetic */ class bb implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final am f1227a;

    private bb(am amVar) {
        this.f1227a = amVar;
    }

    static Runnable a(am amVar) {
        return new bb(amVar);
    }

    public final void run() {
        this.f1227a.b();
    }
}
