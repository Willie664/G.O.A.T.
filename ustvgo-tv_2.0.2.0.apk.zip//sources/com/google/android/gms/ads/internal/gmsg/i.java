package com.google.android.gms.ads.internal.gmsg;

import android.text.TextUtils;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.zzaig;
import java.util.Map;

@cj
public final class i implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    private final j f1263a;

    public i(j jVar) {
        this.f1263a = jVar;
    }

    public final void zza(Object obj, Map<String, String> map) {
        String str = map.get("action");
        if ("grant".equals(str)) {
            zzaig zzaig = null;
            try {
                int parseInt = Integer.parseInt(map.get("amount"));
                String str2 = map.get("type");
                if (!TextUtils.isEmpty(str2)) {
                    zzaig = new zzaig(str2, parseInt);
                }
            } catch (NumberFormatException e) {
                iy.b("Unable to parse reward amount.", e);
            }
            this.f1263a.a(zzaig);
        } else if ("video_start".equals(str)) {
            this.f1263a.f_();
        } else if ("video_complete".equals(str)) {
            if (((Boolean) ans.f().a(aqs.ax)).booleanValue()) {
                if (((Boolean) ans.f().a(aqs.ax)).booleanValue()) {
                    this.f1263a.g_();
                }
            }
        }
    }
}
