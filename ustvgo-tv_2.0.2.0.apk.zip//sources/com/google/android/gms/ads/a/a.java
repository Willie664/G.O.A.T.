package com.google.android.gms.ads.a;

public final class a {

    /* renamed from: com.google.android.gms.ads.a.a$a  reason: collision with other inner class name */
    public static final class C0059a {
        public static final int s1 = 2131624267;
        public static final int s2 = 2131624268;
        public static final int s3 = 2131624269;
        public static final int s4 = 2131624270;
        public static final int s5 = 2131624271;
        public static final int s6 = 2131624272;
        public static final int s7 = 2131624273;
    }
}
