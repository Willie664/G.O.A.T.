package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.nf;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@cj
public final class b implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap<String, nf<JSONObject>> f1257a = new HashMap<>();

    public final void a(String str) {
        nf nfVar = this.f1257a.get(str);
        if (nfVar == null) {
            iy.a("Could not find the ad request for the corresponding ad response.");
            return;
        }
        if (!nfVar.isDone()) {
            nfVar.cancel(true);
        }
        this.f1257a.remove(str);
    }

    public final void zza(Object obj, Map<String, String> map) {
        String str = map.get("request_id");
        String str2 = map.get("fetched_ad");
        ma.a(3);
        nf nfVar = this.f1257a.get(str);
        if (nfVar == null) {
            iy.a("Could not find the ad request for the corresponding ad response.");
            return;
        }
        try {
            nfVar.b(new JSONObject(str2));
        } catch (JSONException e) {
            iy.a("Failed constructing JSON object from value passed from javascript", e);
            nfVar.b(null);
        } finally {
            this.f1257a.remove(str);
        }
    }
}
