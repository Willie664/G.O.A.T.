package com.google.android.gms.ads.internal.gmsg;

import android.text.TextUtils;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.GuardedBy;
import org.json.JSONException;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public final class g implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    private final Object f1262a = new Object();
    @GuardedBy("mLock")
    private final Map<String, h> b = new HashMap();

    public final void a(String str, h hVar) {
        synchronized (this.f1262a) {
            this.b.put(str, hVar);
        }
    }

    public final void zza(Object obj, Map<String, String> map) {
        String str;
        String str2 = map.get("id");
        String str3 = map.get("fail");
        String str4 = map.get("fail_reason");
        String str5 = map.get("fail_stack");
        String str6 = map.get("result");
        if (TextUtils.isEmpty(str5)) {
            str4 = "Unknown Fail Reason.";
        }
        if (TextUtils.isEmpty(str5)) {
            str = "";
        } else {
            String valueOf = String.valueOf(str5);
            str = valueOf.length() != 0 ? "\n".concat(valueOf) : new String("\n");
        }
        synchronized (this.f1262a) {
            h remove = this.b.remove(str2);
            if (remove == null) {
                String valueOf2 = String.valueOf(str2);
                iy.b(valueOf2.length() != 0 ? "Received result for unexpected method invocation: ".concat(valueOf2) : new String("Received result for unexpected method invocation: "));
            } else if (!TextUtils.isEmpty(str3)) {
                String valueOf3 = String.valueOf(str4);
                String valueOf4 = String.valueOf(str);
                remove.a(valueOf4.length() != 0 ? valueOf3.concat(valueOf4) : new String(valueOf3));
            } else if (str6 == null) {
                remove.a((JSONObject) null);
            } else {
                try {
                    JSONObject jSONObject = new JSONObject(str6);
                    if (iy.a()) {
                        String valueOf5 = String.valueOf(jSONObject.toString(2));
                        if (valueOf5.length() != 0) {
                            "Result GMSG: ".concat(valueOf5);
                        } else {
                            new String("Result GMSG: ");
                        }
                        iy.a();
                    }
                    remove.a(jSONObject);
                } catch (JSONException e) {
                    remove.a(e.getMessage());
                }
            }
        }
    }
}
