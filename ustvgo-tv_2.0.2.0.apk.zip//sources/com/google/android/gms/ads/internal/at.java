package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.aga;
import com.google.android.gms.internal.ads.agb;
import java.util.concurrent.Callable;

final class at implements Callable<agb> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ aq f1219a;

    at(aq aqVar) {
        this.f1219a = aqVar;
    }

    public final /* synthetic */ Object call() {
        return new agb(aga.a(this.f1219a.f1216a.f2393a, this.f1219a.d, false));
    }
}
