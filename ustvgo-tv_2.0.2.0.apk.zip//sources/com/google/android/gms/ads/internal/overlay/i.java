package com.google.android.gms.ads.internal.overlay;

import android.graphics.Bitmap;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.it;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.ld;

@cj
final class i extends it {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ c f1284a;

    private i(c cVar) {
        this.f1284a = cVar;
    }

    /* synthetic */ i(c cVar, byte b) {
        this(cVar);
    }

    public final void a() {
        ld y = aw.y();
        Bitmap bitmap = y.f2160a.get(Integer.valueOf(this.f1284a.b.o.e));
        if (bitmap != null) {
            jh.f2130a.post(new j(this, aw.g().a(this.f1284a.f1279a, bitmap, this.f1284a.b.o.c, this.f1284a.b.o.d)));
        }
    }

    public final void e_() {
    }
}
