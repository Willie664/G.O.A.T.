package com.google.android.gms.ads.internal;

import android.os.Debug;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.ma;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CountDownLatch;

final class aa extends TimerTask {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ CountDownLatch f1203a;
    private final /* synthetic */ Timer b;
    private final /* synthetic */ a c;

    aa(a aVar, CountDownLatch countDownLatch, Timer timer) {
        this.c = aVar;
        this.f1203a = countDownLatch;
        this.b = timer;
    }

    public final void run() {
        if (((long) ((Integer) ans.f().a(aqs.cp)).intValue()) != this.f1203a.getCount()) {
            ma.a(3);
            Debug.stopMethodTracing();
            if (this.f1203a.getCount() == 0) {
                this.b.cancel();
                return;
            }
        }
        String concat = String.valueOf(this.c.e.c.getPackageName()).concat("_adsTrace_");
        try {
            ma.a(3);
            this.f1203a.countDown();
            long a2 = aw.l().a();
            StringBuilder sb = new StringBuilder(String.valueOf(concat).length() + 20);
            sb.append(concat);
            sb.append(a2);
            Debug.startMethodTracing(sb.toString(), ((Integer) ans.f().a(aqs.cq)).intValue());
        } catch (Exception e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
