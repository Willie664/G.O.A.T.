package com.google.android.gms.ads.internal;

import android.os.Build;
import com.google.android.gms.ads.internal.overlay.a;
import com.google.android.gms.ads.internal.overlay.k;
import com.google.android.gms.ads.internal.overlay.t;
import com.google.android.gms.ads.internal.overlay.u;
import com.google.android.gms.common.util.e;
import com.google.android.gms.common.util.h;
import com.google.android.gms.internal.ads.akc;
import com.google.android.gms.internal.ads.akz;
import com.google.android.gms.internal.ads.al;
import com.google.android.gms.internal.ads.ala;
import com.google.android.gms.internal.ads.alm;
import com.google.android.gms.internal.ads.aqx;
import com.google.android.gms.internal.ads.axc;
import com.google.android.gms.internal.ads.axw;
import com.google.android.gms.internal.ads.azn;
import com.google.android.gms.internal.ads.bao;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ck;
import com.google.android.gms.internal.ads.fa;
import com.google.android.gms.internal.ads.ht;
import com.google.android.gms.internal.ads.ii;
import com.google.android.gms.internal.ads.ir;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.jm;
import com.google.android.gms.internal.ads.jq;
import com.google.android.gms.internal.ads.jr;
import com.google.android.gms.internal.ads.js;
import com.google.android.gms.internal.ads.jt;
import com.google.android.gms.internal.ads.ju;
import com.google.android.gms.internal.ads.jw;
import com.google.android.gms.internal.ads.jx;
import com.google.android.gms.internal.ads.kg;
import com.google.android.gms.internal.ads.lc;
import com.google.android.gms.internal.ads.ld;
import com.google.android.gms.internal.ads.ll;
import com.google.android.gms.internal.ads.ng;
import com.google.android.gms.internal.ads.nn;
import com.google.android.gms.internal.ads.o;
import com.google.android.gms.internal.ads.pe;
import com.google.android.gms.internal.ads.qb;

@cj
public final class aw {

    /* renamed from: a  reason: collision with root package name */
    private static final Object f1222a = new Object();
    private static aw b;
    private final ac A;
    private final o B;
    private final alm C;
    private final ht D;
    private final pe E;
    private final nn F;
    private final axw G;
    private final jx H;
    private final ll I;
    private final ir J;
    private final a c = new a();
    private final ck d = new ck();
    private final k e = new k();
    private final al f = new al();
    private final jh g = new jh();
    private final qb h = new qb();
    private final jm i;
    private final akc j;
    private final ii k;
    private final akz l;
    private final ala m;
    private final e n;
    private final e o;
    private final aqx p;
    private final kg q;
    private final fa r;
    private final ng s;
    private final axc t;
    private final azn u;
    private final lc v;
    private final t w;
    private final u x;
    private final bao y;
    private final ld z;

    static {
        aw awVar = new aw();
        synchronized (f1222a) {
            b = awVar;
        }
    }

    protected aw() {
        int i2 = Build.VERSION.SDK_INT;
        this.i = i2 >= 21 ? new jw() : i2 >= 19 ? new ju() : i2 >= 18 ? new js() : i2 >= 17 ? new jr() : i2 >= 16 ? new jt() : new jq();
        this.j = new akc();
        this.k = new ii();
        this.J = new ir();
        this.l = new akz();
        this.m = new ala();
        this.n = h.d();
        this.o = new e();
        this.p = new aqx();
        this.q = new kg();
        this.r = new fa();
        this.G = new axw();
        this.s = new ng();
        this.t = new axc();
        this.u = new azn();
        this.v = new lc();
        this.w = new t();
        this.x = new u();
        this.y = new bao();
        this.z = new ld();
        this.A = new ac();
        this.B = new o();
        this.C = new alm();
        this.D = new ht();
        this.E = new pe();
        this.F = new nn();
        this.H = new jx();
        this.I = new ll();
    }

    public static nn A() {
        return F().F;
    }

    public static ht B() {
        return F().D;
    }

    public static axw C() {
        return F().G;
    }

    public static jx D() {
        return F().H;
    }

    public static ll E() {
        return F().I;
    }

    private static aw F() {
        aw awVar;
        synchronized (f1222a) {
            awVar = b;
        }
        return awVar;
    }

    public static ck a() {
        return F().d;
    }

    public static a b() {
        return F().c;
    }

    public static k c() {
        return F().e;
    }

    public static al d() {
        return F().f;
    }

    public static jh e() {
        return F().g;
    }

    public static qb f() {
        return F().h;
    }

    public static jm g() {
        return F().i;
    }

    public static akc h() {
        return F().j;
    }

    public static ii i() {
        return F().k;
    }

    public static ir j() {
        return F().J;
    }

    public static ala k() {
        return F().m;
    }

    public static e l() {
        return F().n;
    }

    public static e m() {
        return F().o;
    }

    public static aqx n() {
        return F().p;
    }

    public static kg o() {
        return F().q;
    }

    public static fa p() {
        return F().r;
    }

    public static ng q() {
        return F().s;
    }

    public static axc r() {
        return F().t;
    }

    public static azn s() {
        return F().u;
    }

    public static lc t() {
        return F().v;
    }

    public static o u() {
        return F().B;
    }

    public static t v() {
        return F().w;
    }

    public static u w() {
        return F().x;
    }

    public static bao x() {
        return F().y;
    }

    public static ld y() {
        return F().z;
    }

    public static pe z() {
        return F().E;
    }
}
