package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.internal.ads.afx;
import com.google.android.gms.internal.ads.aga;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jf;
import com.google.android.gms.internal.ads.lp;
import com.google.android.gms.internal.ads.zzang;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

@cj
public final class h implements afx, Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final List<Object[]> f1271a;
    private final AtomicReference<afx> b;
    private Context c;
    private zzang d;
    private CountDownLatch e;

    private h(Context context, zzang zzang) {
        this.f1271a = new Vector();
        this.b = new AtomicReference<>();
        this.e = new CountDownLatch(1);
        this.c = context;
        this.d = zzang;
        ans.a();
        if (lp.b()) {
            jf.a((Runnable) this);
        } else {
            run();
        }
    }

    public h(ax axVar) {
        this(axVar.c, axVar.e);
    }

    private final boolean a() {
        try {
            this.e.await();
            return true;
        } catch (InterruptedException e2) {
            iy.b("Interrupted during GADSignals creation.", e2);
            return false;
        }
    }

    private static Context b(Context context) {
        Context applicationContext = context.getApplicationContext();
        return applicationContext == null ? context : applicationContext;
    }

    private final void b() {
        if (!this.f1271a.isEmpty()) {
            for (Object[] next : this.f1271a) {
                if (next.length == 1) {
                    this.b.get().a((MotionEvent) next[0]);
                } else if (next.length == 3) {
                    this.b.get().a(((Integer) next[0]).intValue(), ((Integer) next[1]).intValue(), ((Integer) next[2]).intValue());
                }
            }
            this.f1271a.clear();
        }
    }

    public final String a(Context context) {
        afx afx;
        if (!a() || (afx = this.b.get()) == null) {
            return "";
        }
        b();
        return afx.a(b(context));
    }

    public final String a(Context context, String str, View view) {
        return a(context, str, view, (Activity) null);
    }

    public final String a(Context context, String str, View view, Activity activity) {
        afx afx;
        if (!a() || (afx = this.b.get()) == null) {
            return "";
        }
        b();
        return afx.a(b(context), str, view, activity);
    }

    public final void a(int i, int i2, int i3) {
        afx afx = this.b.get();
        if (afx != null) {
            b();
            afx.a(i, i2, i3);
            return;
        }
        this.f1271a.add(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)});
    }

    public final void a(MotionEvent motionEvent) {
        afx afx = this.b.get();
        if (afx != null) {
            b();
            afx.a(motionEvent);
            return;
        }
        this.f1271a.add(new Object[]{motionEvent});
    }

    public final void a(View view) {
        afx afx = this.b.get();
        if (afx != null) {
            afx.a(view);
        }
    }

    public final void run() {
        boolean z = false;
        try {
            boolean z2 = this.d.d;
            if (!((Boolean) ans.f().a(aqs.aL)).booleanValue() && z2) {
                z = true;
            }
            this.b.set(aga.a(this.d.f2393a, b(this.c), z));
        } finally {
            this.e.countDown();
            this.c = null;
            this.d = null;
        }
    }
}
