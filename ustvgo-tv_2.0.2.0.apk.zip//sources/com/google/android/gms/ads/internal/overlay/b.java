package com.google.android.gms.ads.internal.overlay;

import android.os.Parcelable;

public final class b implements Parcelable.Creator<zzc> {
    /* JADX WARNING: type inference failed for: r1v3, types: [android.os.Parcelable] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ java.lang.Object createFromParcel(android.os.Parcel r12) {
        /*
            r11 = this;
            int r0 = com.google.android.gms.common.internal.safeparcel.a.a(r12)
            r1 = 0
            r3 = r1
            r4 = r3
            r5 = r4
            r6 = r5
            r7 = r6
            r8 = r7
            r9 = r8
            r10 = r9
        L_0x000d:
            int r1 = r12.dataPosition()
            if (r1 >= r0) goto L_0x004f
            int r1 = r12.readInt()
            r2 = 65535(0xffff, float:9.1834E-41)
            r2 = r2 & r1
            switch(r2) {
                case 2: goto L_0x004a;
                case 3: goto L_0x0045;
                case 4: goto L_0x0040;
                case 5: goto L_0x003b;
                case 6: goto L_0x0036;
                case 7: goto L_0x0031;
                case 8: goto L_0x002c;
                case 9: goto L_0x0022;
                default: goto L_0x001e;
            }
        L_0x001e:
            com.google.android.gms.common.internal.safeparcel.a.b(r12, r1)
            goto L_0x000d
        L_0x0022:
            android.os.Parcelable$Creator r2 = android.content.Intent.CREATOR
            android.os.Parcelable r1 = com.google.android.gms.common.internal.safeparcel.a.a((android.os.Parcel) r12, (int) r1, r2)
            r10 = r1
            android.content.Intent r10 = (android.content.Intent) r10
            goto L_0x000d
        L_0x002c:
            java.lang.String r9 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x0031:
            java.lang.String r8 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x0036:
            java.lang.String r7 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x003b:
            java.lang.String r6 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x0040:
            java.lang.String r5 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x0045:
            java.lang.String r4 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x004a:
            java.lang.String r3 = com.google.android.gms.common.internal.safeparcel.a.k(r12, r1)
            goto L_0x000d
        L_0x004f:
            com.google.android.gms.common.internal.safeparcel.a.u(r12, r0)
            com.google.android.gms.ads.internal.overlay.zzc r12 = new com.google.android.gms.ads.internal.overlay.zzc
            r2 = r12
            r2.<init>(r3, r4, r5, r6, r7, r8, r9, r10)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.overlay.b.createFromParcel(android.os.Parcel):java.lang.Object");
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzc[i];
    }
}
