package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.ajk;
import com.google.android.gms.internal.ads.ajo;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.rf;

final /* synthetic */ class n implements rf {

    /* renamed from: a  reason: collision with root package name */
    private final m f1276a;
    private final id b;

    n(m mVar, id idVar) {
        this.f1276a = mVar;
        this.b = idVar;
    }

    public final void a() {
        m mVar = this.f1276a;
        id idVar = this.b;
        new ajk(mVar.e.c, idVar.b.getView()).a((ajo) idVar.b);
    }
}
