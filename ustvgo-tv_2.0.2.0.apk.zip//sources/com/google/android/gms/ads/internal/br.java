package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.arz;
import com.google.android.gms.internal.ads.iy;

final class br implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ arz f1240a;
    private final /* synthetic */ bn b;

    br(bn bnVar, arz arz) {
        this.b = bnVar;
        this.f1240a = arz;
    }

    public final void run() {
        try {
            if (this.b.e.s != null) {
                this.b.e.s.a(this.f1240a);
                this.b.a(this.f1240a.j());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
