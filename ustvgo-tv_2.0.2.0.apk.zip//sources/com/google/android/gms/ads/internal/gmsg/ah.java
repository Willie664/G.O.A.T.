package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import java.util.Map;

@cj
public final class ah implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    private final ai f1256a;

    public ah(ai aiVar) {
        this.f1256a = aiVar;
    }

    public final void zza(Object obj, Map<String, String> map) {
        boolean equals = "1".equals(map.get("transparentBackground"));
        boolean equals2 = "1".equals(map.get("blur"));
        float f = 0.0f;
        try {
            if (map.get("blurRadius") != null) {
                f = Float.parseFloat(map.get("blurRadius"));
            }
        } catch (NumberFormatException e) {
            iy.a("Fail to parse float", e);
        }
        this.f1256a.a(equals);
        this.f1256a.a(equals2, f);
    }
}
