package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.bbh;
import com.google.android.gms.internal.ads.bbl;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class x implements ae<pu> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bbh f1296a;
    private final /* synthetic */ d b;
    private final /* synthetic */ bbl c;

    x(bbh bbh, d dVar, bbl bbl) {
        this.f1296a = bbh;
        this.b = dVar;
        this.c = bbl;
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        View view = puVar.getView();
        if (view != null) {
            try {
                if (this.f1296a != null) {
                    if (!this.f1296a.k()) {
                        this.f1296a.a(b.a(view));
                        this.b.f1246a.e();
                        return;
                    }
                    s.a(puVar);
                } else if (this.c == null) {
                } else {
                    if (!this.c.i()) {
                        this.c.a(b.a(view));
                        this.b.f1246a.e();
                        return;
                    }
                    s.a(puVar);
                }
            } catch (RemoteException e) {
                iy.b("Unable to call handleClick on mapper", e);
            }
        }
    }
}
