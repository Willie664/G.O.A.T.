package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.asb;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.iy;

final class ak implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ String f1211a;
    private final /* synthetic */ id b;
    private final /* synthetic */ ad c;

    ak(ad adVar, String str, id idVar) {
        this.c = adVar;
        this.f1211a = str;
        this.b = idVar;
    }

    public final void run() {
        try {
            this.c.e.v.get(this.f1211a).a((asb) this.b.C);
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
