package com.google.android.gms.ads.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.azm;
import com.google.android.gms.internal.ads.azq;
import com.google.android.gms.internal.ads.azr;
import com.google.android.gms.internal.ads.azu;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ih;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.mh;
import com.google.android.gms.internal.ads.mj;
import com.google.android.gms.internal.ads.mu;
import com.google.android.gms.internal.ads.na;
import com.google.android.gms.internal.ads.zzang;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public final class e {

    /* renamed from: a  reason: collision with root package name */
    private final Object f1247a = new Object();
    private Context b;
    private long c = 0;

    public final void a(Context context, zzang zzang, String str, Runnable runnable) {
        a(context, zzang, true, (ih) null, str, (String) null, runnable);
    }

    /* access modifiers changed from: package-private */
    public final void a(Context context, zzang zzang, boolean z, ih ihVar, String str, String str2, Runnable runnable) {
        if (aw.l().b() - this.c < 5000) {
            iy.b("Not retrying to fetch app settings");
            return;
        }
        this.c = aw.l().b();
        boolean z2 = true;
        if (ihVar != null) {
            if (!(aw.l().a() - ihVar.f2109a > ((Long) ans.f().a(aqs.ct)).longValue()) && ihVar.e) {
                z2 = false;
            }
        }
        if (z2) {
            if (context == null) {
                iy.b("Context not provided to fetch application settings");
            } else if (!TextUtils.isEmpty(str) || !TextUtils.isEmpty(str2)) {
                Context applicationContext = context.getApplicationContext();
                if (applicationContext == null) {
                    applicationContext = context;
                }
                this.b = applicationContext;
                azu a2 = aw.s().a(this.b, zzang);
                azq<JSONObject> azq = azr.f1944a;
                azm<I, O> a3 = a2.a("google.afma.config.fetchAppSettings", azq, azq);
                try {
                    JSONObject jSONObject = new JSONObject();
                    if (!TextUtils.isEmpty(str)) {
                        jSONObject.put("app_id", str);
                    } else if (!TextUtils.isEmpty(str2)) {
                        jSONObject.put("ad_unit_id", str2);
                    }
                    jSONObject.put("is_init", z);
                    jSONObject.put("pn", context.getPackageName());
                    mu<O> b2 = a3.b(jSONObject);
                    mu<B> a4 = mj.a(b2, f.f1248a, na.b);
                    if (runnable != null) {
                        b2.a(runnable, na.b);
                    }
                    mh.a(a4, "ConfigLoader.maybeFetchNewAppSettings");
                } catch (Exception e) {
                    iy.a("Error requesting application settings", e);
                }
            } else {
                iy.b("App settings could not be fetched. Required parameters missing");
            }
        }
    }
}
