package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.rg;

final /* synthetic */ class bw implements rg {

    /* renamed from: a  reason: collision with root package name */
    private final id f1244a;
    private final Runnable b;

    bw(id idVar, Runnable runnable) {
        this.f1244a = idVar;
        this.b = runnable;
    }

    public final void a() {
        id idVar = this.f1244a;
        Runnable runnable = this.b;
        if (!idVar.m) {
            aw.e();
            jh.a(runnable);
        }
    }
}
