package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import com.google.android.gms.internal.ads.cj;

@cj
public final class x extends c {
    public x(Activity activity) {
        super(activity);
    }
}
