package com.google.android.gms.ads.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.apg;
import com.google.android.gms.internal.ads.arm;
import com.google.android.gms.internal.ads.ars;
import com.google.android.gms.internal.ads.arx;
import com.google.android.gms.internal.ads.arz;
import com.google.android.gms.internal.ads.ase;
import com.google.android.gms.internal.ads.asg;
import com.google.android.gms.internal.ads.ash;
import com.google.android.gms.internal.ads.asi;
import com.google.android.gms.internal.ads.ask;
import com.google.android.gms.internal.ads.asl;
import com.google.android.gms.internal.ads.atf;
import com.google.android.gms.internal.ads.auc;
import com.google.android.gms.internal.ads.aun;
import com.google.android.gms.internal.ads.bae;
import com.google.android.gms.internal.ads.baf;
import com.google.android.gms.internal.ads.bai;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.bay;
import com.google.android.gms.internal.ads.bbh;
import com.google.android.gms.internal.ads.bbl;
import com.google.android.gms.internal.ads.bbo;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class bn extends ba implements ask {
    private boolean j;
    /* access modifiers changed from: private */
    public id k;
    private boolean l = false;

    public bn(Context context, bt btVar, zzjn zzjn, String str, bav bav, zzang zzang) {
        super(context, zzjn, str, bav, zzang, btVar);
    }

    private final baf K() {
        if (this.e.j == null || !this.e.j.n) {
            return null;
        }
        return this.e.j.r;
    }

    private static id a(ie ieVar, int i) {
        ie ieVar2 = ieVar;
        return new id(ieVar2.f2106a.c, (pu) null, ieVar2.b.c, i, ieVar2.b.e, ieVar2.b.i, ieVar2.b.k, ieVar2.b.j, ieVar2.f2106a.i, ieVar2.b.g, (bae) null, (bay) null, (String) null, ieVar2.c, (bai) null, ieVar2.b.h, ieVar2.d, ieVar2.b.f, ieVar2.f, ieVar2.g, ieVar2.b.n, ieVar2.h, (asl) null, ieVar2.b.A, ieVar2.b.B, ieVar2.b.B, ieVar2.b.D, ieVar2.b.E, (String) null, ieVar2.b.H, ieVar2.b.L, ieVar2.i, ieVar2.b.O, ieVar2.j, ieVar2.b.Q, ieVar2.b.R, ieVar2.b.S, ieVar2.b.T);
    }

    private final void a(ase ase) {
        jh.f2130a.post(new bp(this, ase));
    }

    private final boolean b(id idVar, id idVar2) {
        Handler handler;
        Runnable brVar;
        ase ase;
        id idVar3 = idVar2;
        View view = null;
        c((List<String>) null);
        if (!this.e.c()) {
            iy.b("Native ad does not have custom rendering mode.");
        } else {
            try {
                bbo p = idVar3.p != null ? idVar3.p.p() : null;
                bbh h = idVar3.p != null ? idVar3.p.h() : null;
                bbl i = idVar3.p != null ? idVar3.p.i() : null;
                auc n = idVar3.p != null ? idVar3.p.n() : null;
                String c = c(idVar2);
                if (p != null && this.e.t != null) {
                    String a2 = p.a();
                    List b = p.b();
                    String c2 = p.c();
                    atf d = p.d() != null ? p.d() : null;
                    String e = p.e();
                    String f = p.f();
                    double g = p.g();
                    String h2 = p.h();
                    String i2 = p.i();
                    apg j2 = p.j();
                    if (p.m() != null) {
                        view = (View) b.a(p.m());
                    }
                    ase = new ase(a2, b, c2, d, e, f, g, h2, i2, (ars) null, j2, view, p.n(), c, p.o());
                    ase.a((asi) new ash(this.e.c, (ask) this, this.e.d, p, (asl) ase));
                } else if (h == null || this.e.t == null) {
                    if (h != null && this.e.r != null) {
                        String a3 = h.a();
                        List b2 = h.b();
                        String c3 = h.c();
                        atf d2 = h.d() != null ? h.d() : null;
                        String e2 = h.e();
                        double f2 = h.f();
                        String g2 = h.g();
                        String h3 = h.h();
                        Bundle l2 = h.l();
                        apg m = h.m();
                        if (h.p() != null) {
                            view = (View) b.a(h.p());
                        }
                        arx arx = new arx(a3, b2, c3, d2, e2, f2, g2, h3, (ars) null, l2, m, view, h.q(), c);
                        arx.a((asi) new ash(this.e.c, (ask) this, this.e.d, h, (asl) arx));
                        handler = jh.f2130a;
                        brVar = new bq(this, arx);
                    } else if (i != null && this.e.t != null) {
                        String a4 = i.a();
                        List b3 = i.b();
                        String c4 = i.c();
                        atf d3 = i.d() != null ? i.d() : null;
                        String e3 = i.e();
                        String f3 = i.f();
                        apg l3 = i.l();
                        if (i.n() != null) {
                            view = (View) b.a(i.n());
                        }
                        ase ase2 = new ase(a4, b3, c4, d3, e3, f3, -1.0d, (String) null, (String) null, (ars) null, l3, view, i.o(), c, i.j());
                        bbl bbl = i;
                        ase = ase2;
                        ase.a((asi) new ash(this.e.c, (ask) this, this.e.d, bbl, (asl) ase2));
                    } else if (i != null && this.e.s != null) {
                        String a5 = i.a();
                        List b4 = i.b();
                        String c5 = i.c();
                        atf d4 = i.d() != null ? i.d() : null;
                        String e4 = i.e();
                        String f4 = i.f();
                        Bundle j3 = i.j();
                        apg l4 = i.l();
                        if (i.n() != null) {
                            view = (View) b.a(i.n());
                        }
                        arz arz = new arz(a5, b4, c5, d4, e4, f4, (ars) null, j3, l4, view, i.o(), c);
                        bbl bbl2 = i;
                        arz arz2 = arz;
                        arz2.a((asi) new ash(this.e.c, (ask) this, this.e.d, bbl2, (asl) arz));
                        handler = jh.f2130a;
                        brVar = new br(this, arz2);
                    } else if (n == null || this.e.v == null || this.e.v.get(n.l()) == null) {
                        iy.b("No matching mapper/listener for retrieved native ad template.");
                        a(0);
                        return false;
                    } else {
                        jh.f2130a.post(new bs(this, n));
                        return super.a(idVar, idVar2);
                    }
                    handler.post(brVar);
                    return super.a(idVar, idVar2);
                } else {
                    String a6 = h.a();
                    List b5 = h.b();
                    String c6 = h.c();
                    atf d5 = h.d() != null ? h.d() : null;
                    String e5 = h.e();
                    double f5 = h.f();
                    String g3 = h.g();
                    String h4 = h.h();
                    apg m2 = h.m();
                    if (h.p() != null) {
                        view = (View) b.a(h.p());
                    }
                    ase = new ase(a6, b5, c6, d5, e5, (String) null, f5, g3, h4, (ars) null, m2, view, h.q(), c, h.l());
                    ase.a((asi) new ash(this.e.c, (ask) this, this.e.d, h, (asl) ase));
                }
                a(ase);
                return super.a(idVar, idVar2);
            } catch (RemoteException e6) {
                iy.c("#007 Could not call remote method.", e6);
            }
        }
        a(0);
        return false;
    }

    private final boolean c(id idVar, id idVar2) {
        View a2 = s.a(idVar2);
        if (a2 == null) {
            return false;
        }
        View nextView = this.e.f.getNextView();
        if (nextView != null) {
            if (nextView instanceof pu) {
                ((pu) nextView).destroy();
            }
            this.e.f.removeView(nextView);
        }
        if (!s.b(idVar2)) {
            try {
                a(a2);
            } catch (Throwable th) {
                aw.i().a(th, "AdLoaderManager.swapBannerViews");
                iy.b("Could not add mediation view to view hierarchy.", th);
                return false;
            }
        }
        if (this.e.f.getChildCount() > 1) {
            this.e.f.showNext();
        }
        if (idVar != null) {
            View nextView2 = this.e.f.getNextView();
            if (nextView2 != null) {
                this.e.f.removeView(nextView2);
            }
            this.e.b();
        }
        this.e.f.setMinimumWidth(l().f);
        this.e.f.setMinimumHeight(l().c);
        this.e.f.requestLayout();
        this.e.f.setVisibility(0);
        return true;
    }

    public final void I() {
        throw new IllegalStateException("Interstitial is not supported by AdLoaderManager.");
    }

    public final void J() {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    public final void N() {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    public final void O() {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    public final boolean Q() {
        if (K() != null) {
            return K().p;
        }
        return false;
    }

    public final boolean R() {
        if (K() != null) {
            return K().q;
        }
        return false;
    }

    public final void S() {
        if (this.e.j == null || !"com.google.ads.mediation.admob.AdMobAdapter".equals(this.e.j.q) || this.e.j.o == null || !this.e.j.o.b()) {
            super.S();
        } else {
            z();
        }
    }

    public final void T() {
        if (this.e.j == null || !"com.google.ads.mediation.admob.AdMobAdapter".equals(this.e.j.q) || this.e.j.o == null || !this.e.j.o.b()) {
            super.T();
        } else {
            y();
        }
    }

    /* access modifiers changed from: protected */
    public final void a(a aVar) {
        Object a2 = aVar != null ? b.a(aVar) : null;
        if (a2 instanceof asi) {
            ((asi) a2).d();
        }
        super.b(this.e.j, false);
    }

    public final void a(arm arm) {
        throw new IllegalStateException("CustomRendering is not supported by AdLoaderManager.");
    }

    public final void a(asg asg) {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    public final void a(asi asi) {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x0031  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0026  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(com.google.android.gms.internal.ads.ie r11, com.google.android.gms.internal.ads.arf r12) {
        /*
            r10 = this;
            r0 = 0
            r10.k = r0
            int r0 = r11.e
            r1 = 0
            r2 = -2
            if (r0 == r2) goto L_0x0012
            int r0 = r11.e
            com.google.android.gms.internal.ads.id r0 = a((com.google.android.gms.internal.ads.ie) r11, (int) r0)
        L_0x000f:
            r10.k = r0
            goto L_0x0022
        L_0x0012:
            com.google.android.gms.internal.ads.zzaej r0 = r11.b
            boolean r0 = r0.g
            if (r0 != 0) goto L_0x0022
            java.lang.String r0 = "partialAdState is not mediation"
            com.google.android.gms.internal.ads.iy.b(r0)
            com.google.android.gms.internal.ads.id r0 = a((com.google.android.gms.internal.ads.ie) r11, (int) r1)
            goto L_0x000f
        L_0x0022:
            com.google.android.gms.internal.ads.id r0 = r10.k
            if (r0 == 0) goto L_0x0031
            android.os.Handler r11 = com.google.android.gms.internal.ads.jh.f2130a
            com.google.android.gms.ads.internal.bo r12 = new com.google.android.gms.ads.internal.bo
            r12.<init>(r10)
            r11.post(r12)
            return
        L_0x0031:
            com.google.android.gms.internal.ads.zzjn r0 = r11.d
            if (r0 == 0) goto L_0x003b
            com.google.android.gms.ads.internal.ax r0 = r10.e
            com.google.android.gms.internal.ads.zzjn r2 = r11.d
            r0.i = r2
        L_0x003b:
            com.google.android.gms.ads.internal.ax r0 = r10.e
            r0.I = r1
            com.google.android.gms.ads.internal.ax r0 = r10.e
            com.google.android.gms.ads.internal.aw.d()
            com.google.android.gms.ads.internal.ax r1 = r10.e
            android.content.Context r2 = r1.c
            com.google.android.gms.ads.internal.ax r1 = r10.e
            com.google.android.gms.internal.ads.agb r5 = r1.d
            r6 = 0
            com.google.android.gms.internal.ads.bav r7 = r10.o
            r3 = r10
            r4 = r11
            r8 = r10
            r9 = r12
            com.google.android.gms.internal.ads.jy r11 = com.google.android.gms.internal.ads.al.a(r2, r3, r4, r5, r6, r7, r8, r9)
            r0.h = r11
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.bn.a(com.google.android.gms.internal.ads.ie, com.google.android.gms.internal.ads.arf):void");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0063 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0064  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(com.google.android.gms.internal.ads.id r5, com.google.android.gms.internal.ads.id r6) {
        /*
            r4 = this;
            com.google.android.gms.ads.internal.ax r0 = r4.e
            boolean r0 = r0.c()
            if (r0 == 0) goto L_0x0097
            boolean r0 = r6.n
            r1 = 0
            if (r0 != 0) goto L_0x0016
            r4.a((int) r1)
            java.lang.String r5 = "newState is not mediation."
        L_0x0012:
            com.google.android.gms.internal.ads.iy.b(r5)
            return r1
        L_0x0016:
            com.google.android.gms.internal.ads.bae r0 = r6.o
            r2 = 1
            if (r0 == 0) goto L_0x0067
            com.google.android.gms.internal.ads.bae r0 = r6.o
            boolean r0 = r0.a()
            if (r0 == 0) goto L_0x0067
            com.google.android.gms.ads.internal.ax r0 = r4.e
            boolean r0 = r0.c()
            if (r0 == 0) goto L_0x003b
            com.google.android.gms.ads.internal.ax r0 = r4.e
            com.google.android.gms.ads.internal.ay r0 = r0.f
            if (r0 == 0) goto L_0x003b
            com.google.android.gms.ads.internal.ax r0 = r4.e
            com.google.android.gms.ads.internal.ay r0 = r0.f
            com.google.android.gms.internal.ads.jz r0 = r0.f1224a
            java.lang.String r3 = r6.A
            r0.b = r3
        L_0x003b:
            boolean r0 = super.a((com.google.android.gms.internal.ads.id) r5, (com.google.android.gms.internal.ads.id) r6)
            if (r0 != 0) goto L_0x0043
        L_0x0041:
            r5 = 0
            goto L_0x0061
        L_0x0043:
            com.google.android.gms.ads.internal.ax r0 = r4.e
            boolean r0 = r0.c()
            if (r0 == 0) goto L_0x0055
            boolean r5 = r4.c(r5, r6)
            if (r5 != 0) goto L_0x0055
            r4.a((int) r1)
            goto L_0x0041
        L_0x0055:
            com.google.android.gms.ads.internal.ax r5 = r4.e
            boolean r5 = r5.d()
            if (r5 != 0) goto L_0x0060
            super.a((com.google.android.gms.internal.ads.id) r6, (boolean) r1)
        L_0x0060:
            r5 = 1
        L_0x0061:
            if (r5 != 0) goto L_0x0064
            return r1
        L_0x0064:
            r4.l = r2
            goto L_0x007a
        L_0x0067:
            com.google.android.gms.internal.ads.bae r0 = r6.o
            if (r0 == 0) goto L_0x0090
            com.google.android.gms.internal.ads.bae r0 = r6.o
            boolean r0 = r0.b()
            if (r0 == 0) goto L_0x0090
            boolean r5 = r4.b(r5, r6)
            if (r5 != 0) goto L_0x007a
            return r1
        L_0x007a:
            java.util.ArrayList r5 = new java.util.ArrayList
            java.lang.Integer[] r6 = new java.lang.Integer[r2]
            r0 = 2
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r6[r1] = r0
            java.util.List r6 = java.util.Arrays.asList(r6)
            r5.<init>(r6)
            r4.d(r5)
            return r2
        L_0x0090:
            r4.a((int) r1)
            java.lang.String r5 = "Response is neither banner nor native."
            goto L_0x0012
        L_0x0097:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "AdLoader API does not support custom rendering."
            r5.<init>(r6)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.bn.a(com.google.android.gms.internal.ads.id, com.google.android.gms.internal.ads.id):boolean");
    }

    /* access modifiers changed from: protected */
    public final boolean a(zzjj zzjj, id idVar, boolean z) {
        return false;
    }

    public final aun b(String str) {
        ab.b("getOnCustomClickListener must be called on the main UI thread.");
        return this.e.u.get(str);
    }

    public final void b(View view) {
        ma.c("#005 Unexpected call to an abstract (unimplemented) method.", (Throwable) null);
    }

    public final void b(boolean z) {
        ab.b("setManualImpressionsEnabled must be called from the main thread.");
        this.j = z;
    }

    public final boolean b(zzjj zzjj) {
        zzjj zzjj2 = zzjj;
        if (this.e.A != null && this.e.A.size() == 1 && this.e.A.get(0).intValue() == 2) {
            iy.a("Requesting only banner Ad from AdLoader or calling loadAd on returned banner is not yet supported");
            a(0);
            return false;
        } else if (this.e.z == null) {
            return super.b(zzjj);
        } else {
            if (zzjj2.h != this.j) {
                zzjj2 = new zzjj(zzjj2.f2398a, zzjj2.b, zzjj2.c, zzjj2.d, zzjj2.e, zzjj2.f, zzjj2.g, zzjj2.h || this.j, zzjj2.i, zzjj2.j, zzjj2.k, zzjj2.l, zzjj2.m, zzjj2.n, zzjj2.o, zzjj2.p, zzjj2.q, zzjj2.r);
            }
            return super.b(zzjj2);
        }
    }

    public final void c(List<String> list) {
        ab.b("setNativeTemplates must be called on the main UI thread.");
        this.e.F = list;
    }

    public final void d(List<Integer> list) {
        ab.b("setAllowedAdTypes must be called on the main UI thread.");
        this.e.A = list;
    }

    public final void o() {
        if (this.l) {
            super.o();
            return;
        }
        throw new IllegalStateException("Native Ad does not support pause().");
    }

    public final void p() {
        if (this.l) {
            super.p();
            return;
        }
        throw new IllegalStateException("Native Ad does not support resume().");
    }

    public final apg t() {
        return null;
    }

    /* access modifiers changed from: protected */
    public final void x() {
        super.x();
        id idVar = this.e.j;
        if (idVar != null && idVar.o != null && idVar.o.a() && this.e.z != null) {
            try {
                this.e.z.a(this, b.a(this.e.c));
                super.b(this.e.j, false);
            } catch (RemoteException e) {
                iy.c("#007 Could not call remote method.", e);
            }
        }
    }
}
