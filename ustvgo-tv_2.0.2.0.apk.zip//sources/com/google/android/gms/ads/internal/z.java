package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.na;

final /* synthetic */ class z implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final y f1298a;
    private final Runnable b;

    z(y yVar, Runnable runnable) {
        this.f1298a = yVar;
        this.b = runnable;
    }

    public final void run() {
        na.f2195a.execute(new ab(this.f1298a, this.b));
    }
}
