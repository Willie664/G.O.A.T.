package com.google.android.gms.ads.internal;

import android.os.Bundle;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.asl;
import com.google.android.gms.internal.ads.dh;
import com.google.android.gms.internal.ads.ie;
import com.google.android.gms.internal.ads.mj;
import com.google.android.gms.internal.ads.zzaef;
import com.google.android.gms.internal.ads.zzjj;
import java.util.concurrent.Callable;
import org.json.JSONArray;
import org.json.JSONObject;

final class af implements Callable<asl> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ int f1206a;
    private final /* synthetic */ JSONArray b;
    private final /* synthetic */ int c;
    private final /* synthetic */ ie d;
    private final /* synthetic */ ad e;

    af(ad adVar, int i, JSONArray jSONArray, int i2, ie ieVar) {
        this.e = adVar;
        this.f1206a = i;
        this.b = jSONArray;
        this.c = i2;
        this.d = ieVar;
    }

    public final /* synthetic */ Object call() {
        if (this.f1206a >= this.b.length()) {
            return null;
        }
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(this.b.get(this.f1206a));
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("ads", jSONArray);
        ad adVar = new ad(this.e.e.c, this.e.i, this.e.e.i, this.e.e.b, this.e.o, this.e.e.e, true);
        ad.a(this.e.e, adVar.e);
        adVar.l_();
        adVar.a(this.e.b);
        arf arf = adVar.f1202a;
        int i = this.f1206a;
        arf.a("num_ads_requested", String.valueOf(this.c));
        arf.a("ad_index", String.valueOf(i));
        zzaef zzaef = this.d.f2106a;
        String jSONObject2 = jSONObject.toString();
        Bundle bundle = zzaef.c.c != null ? new Bundle(zzaef.c.c) : new Bundle();
        bundle.putString("_ad", jSONObject2);
        zzjj zzjj = r5;
        zzjj zzjj2 = new zzjj(zzaef.c.f2398a, zzaef.c.b, bundle, zzaef.c.d, zzaef.c.e, zzaef.c.f, zzaef.c.g, zzaef.c.h, zzaef.c.i, zzaef.c.j, zzaef.c.k, zzaef.c.l, zzaef.c.m, zzaef.c.n, zzaef.c.o, zzaef.c.p, zzaef.c.q, zzaef.c.r);
        adVar.a(new dh(zzaef.b, zzjj, zzaef.d, zzaef.e, zzaef.f, zzaef.g, zzaef.i, zzaef.j, zzaef.k, zzaef.l, zzaef.n, zzaef.z, zzaef.o, zzaef.p, zzaef.q, zzaef.r, zzaef.s, zzaef.t, zzaef.u, zzaef.v, zzaef.w, zzaef.x, zzaef.y, zzaef.B, zzaef.C, zzaef.I, zzaef.D, zzaef.E, zzaef.F, zzaef.G, mj.a(zzaef.H), zzaef.J, zzaef.K, zzaef.L, zzaef.M, zzaef.N, zzaef.O, zzaef.P, zzaef.Q, zzaef.U, mj.a(zzaef.h), zzaef.V, zzaef.W, zzaef.X, 1, zzaef.Z, zzaef.aa, zzaef.ab, zzaef.ac), adVar.f1202a);
        return (asl) adVar.j.get();
    }
}
