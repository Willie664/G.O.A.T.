package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.k;

final class q implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ AdOverlayInfoParcel f1291a;
    private final /* synthetic */ p b;

    q(p pVar, AdOverlayInfoParcel adOverlayInfoParcel) {
        this.b = pVar;
        this.f1291a = adOverlayInfoParcel;
    }

    public final void run() {
        aw.c();
        k.a(this.b.f1290a.e.c, this.f1291a, true);
    }
}
