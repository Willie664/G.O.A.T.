package com.google.android.gms.ads;

public class a {
    public void a() {
    }

    public void a(int i) {
    }

    public void b() {
    }

    public void c() {
    }

    public void d() {
    }

    public void e() {
    }

    public void f() {
    }
}
