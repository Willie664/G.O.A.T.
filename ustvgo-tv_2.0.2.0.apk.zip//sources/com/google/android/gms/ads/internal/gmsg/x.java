package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class x implements ae<pu> {
    x() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        ((pu) obj).c("1".equals(map.get("custom_close")));
    }
}
