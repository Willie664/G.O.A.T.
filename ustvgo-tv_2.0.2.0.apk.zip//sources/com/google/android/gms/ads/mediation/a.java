package com.google.android.gms.ads.mediation;

import android.location.Location;
import java.util.Date;
import java.util.Set;

public interface a {
    Date a();

    int b();

    Set<String> c();

    Location d();

    int e();

    boolean f();

    boolean g();
}
