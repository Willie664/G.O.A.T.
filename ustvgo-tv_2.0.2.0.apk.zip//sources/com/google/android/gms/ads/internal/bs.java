package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.auc;
import com.google.android.gms.internal.ads.iy;

final class bs implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ auc f1241a;
    private final /* synthetic */ bn b;

    bs(bn bnVar, auc auc) {
        this.b = bnVar;
        this.f1241a = auc;
    }

    public final void run() {
        try {
            this.b.e.v.get(this.f1241a.l()).a(this.f1241a);
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
