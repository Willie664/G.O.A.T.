package com.google.android.gms.ads.formats;

import com.google.android.gms.ads.formats.a;
import com.google.android.gms.ads.h;
import java.util.List;

public abstract class g {

    public interface a {
        void a(g gVar);
    }

    public abstract String a();

    public abstract List<a.b> b();

    public abstract String c();

    public abstract a.b d();

    public abstract String e();

    public abstract String f();

    public abstract Double g();

    public abstract String h();

    public abstract String i();

    public abstract h j();

    /* access modifiers changed from: protected */
    public abstract Object k();

    public abstract Object l();
}
