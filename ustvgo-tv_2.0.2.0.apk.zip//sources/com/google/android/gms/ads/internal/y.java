package com.google.android.gms.ads.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.apc;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jz;
import com.google.android.gms.internal.ads.zzang;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.GuardedBy;

@cj
@ParametersAreNonnullByDefault
public final class y extends apc {
    private static final Object b = new Object();
    @GuardedBy("sLock")
    private static y c;

    /* renamed from: a  reason: collision with root package name */
    final Context f1297a;
    private final Object d = new Object();
    private boolean e;
    private zzang f;

    private y(Context context, zzang zzang) {
        this.f1297a = context;
        this.f = zzang;
        this.e = false;
    }

    public static y a(Context context, zzang zzang) {
        y yVar;
        synchronized (b) {
            if (c == null) {
                c = new y(context.getApplicationContext(), zzang);
            }
            yVar = c;
        }
        return yVar;
    }

    public final void a() {
        synchronized (b) {
            if (this.e) {
                iy.b("Mobile ads is initialized already.");
                return;
            }
            this.e = true;
            aqs.a(this.f1297a);
            aw.i().a(this.f1297a, this.f);
            aw.k().a(this.f1297a);
        }
    }

    public final void a(float f2) {
        aw.D().a(f2);
    }

    public final void a(a aVar, String str) {
        if (aVar == null) {
            iy.a("Wrapped context is null. Failed to open debug menu.");
            return;
        }
        Context context = (Context) b.a(aVar);
        if (context == null) {
            iy.a("Context is null. Failed to open debug menu.");
            return;
        }
        jz jzVar = new jz(context);
        jzVar.c = str;
        jzVar.d = this.f.f2393a;
        jzVar.a();
    }

    public final void a(String str) {
        aqs.a(this.f1297a);
        if (!TextUtils.isEmpty(str)) {
            if (((Boolean) ans.f().a(aqs.cs)).booleanValue()) {
                aw.m().a(this.f1297a, this.f, str, (Runnable) null);
            }
        }
    }

    public final void a(String str, a aVar) {
        if (!TextUtils.isEmpty(str)) {
            aqs.a(this.f1297a);
            boolean booleanValue = ((Boolean) ans.f().a(aqs.cs)).booleanValue() | ((Boolean) ans.f().a(aqs.aD)).booleanValue();
            z zVar = null;
            if (((Boolean) ans.f().a(aqs.aD)).booleanValue()) {
                booleanValue = true;
                zVar = new z(this, (Runnable) b.a(aVar));
            }
            if (booleanValue) {
                aw.m().a(this.f1297a, this.f, str, zVar);
            }
        }
    }

    public final void a(boolean z) {
        aw.D().a(z);
    }

    public final float b() {
        return aw.D().a();
    }

    public final boolean c() {
        return aw.D().b();
    }
}
