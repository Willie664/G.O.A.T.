package com.google.android.gms.ads.internal;

import android.view.View;

public interface g {
    void b_(View view);

    void h_();

    void i_();
}
