package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.asg;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class z implements ae<pu> {
    z() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        asg H = ((pu) obj).H();
        if (H != null) {
            H.a();
        }
    }
}
