package com.google.android.gms.ads.internal.overlay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.b.a;
import com.google.android.gms.internal.ads.cj;

@cj
public final class r extends com.google.android.gms.internal.ads.r {

    /* renamed from: a  reason: collision with root package name */
    private AdOverlayInfoParcel f1288a;
    private Activity b;
    private boolean c = false;
    private boolean d = false;

    public r(Activity activity, AdOverlayInfoParcel adOverlayInfoParcel) {
        this.f1288a = adOverlayInfoParcel;
        this.b = activity;
    }

    private final synchronized void a() {
        if (!this.d) {
            if (this.f1288a.c != null) {
                this.f1288a.c.r_();
            }
            this.d = true;
        }
    }

    public final void a(int i, int i2, Intent intent) {
    }

    public final void a(Bundle bundle) {
        boolean z = false;
        if (bundle != null) {
            z = bundle.getBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", false);
        }
        if (this.f1288a != null && !z) {
            if (bundle == null) {
                if (this.f1288a.b != null) {
                    this.f1288a.b.e();
                }
                if (!(this.b.getIntent() == null || !this.b.getIntent().getBooleanExtra("shouldCallOnOverlayOpened", true) || this.f1288a.c == null)) {
                    this.f1288a.c.g();
                }
            }
            aw.b();
            if (!a.a((Context) this.b, this.f1288a.f1278a, this.f1288a.i)) {
                this.b.finish();
                return;
            }
            return;
        }
        this.b.finish();
    }

    public final void a(a aVar) {
    }

    public final void b(Bundle bundle) {
        bundle.putBoolean("com.google.android.gms.ads.internal.overlay.hasResumed", this.c);
    }

    public final void d() {
    }

    public final boolean e() {
        return false;
    }

    public final void f() {
    }

    public final void g() {
    }

    public final void h() {
        if (this.c) {
            this.b.finish();
            return;
        }
        this.c = true;
        if (this.f1288a.c != null) {
            this.f1288a.c.f();
        }
    }

    public final void i() {
        if (this.f1288a.c != null) {
            this.f1288a.c.d();
        }
        if (this.b.isFinishing()) {
            a();
        }
    }

    public final void j() {
        if (this.b.isFinishing()) {
            a();
        }
    }

    public final void k() {
        if (this.b.isFinishing()) {
            a();
        }
    }

    public final void l() {
    }
}
