package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.pu;
import java.util.Map;

final class ab implements ae<pu> {
    ab() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        pu puVar = (pu) obj;
        String str = (String) map.get("action");
        if ("pause".equals(str)) {
            puVar.j_();
        } else if ("resume".equals(str)) {
            puVar.k_();
        }
    }
}
