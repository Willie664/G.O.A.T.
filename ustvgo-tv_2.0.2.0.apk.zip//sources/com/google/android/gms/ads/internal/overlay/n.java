package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.lp;
import javax.annotation.Nullable;

@cj
public final class n extends FrameLayout implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    private final ImageButton f1286a;
    private final v b;

    public n(Context context, o oVar, @Nullable v vVar) {
        super(context);
        this.b = vVar;
        setOnClickListener(this);
        this.f1286a = new ImageButton(context);
        this.f1286a.setImageResource(17301527);
        this.f1286a.setBackgroundColor(0);
        this.f1286a.setOnClickListener(this);
        ImageButton imageButton = this.f1286a;
        ans.a();
        int a2 = lp.a(context, oVar.f1287a);
        ans.a();
        int a3 = lp.a(context, 0);
        ans.a();
        int a4 = lp.a(context, oVar.b);
        ans.a();
        imageButton.setPadding(a2, a3, a4, lp.a(context, oVar.d));
        this.f1286a.setContentDescription("Interstitial close button");
        ans.a();
        lp.a(context, oVar.e);
        ImageButton imageButton2 = this.f1286a;
        ans.a();
        int a5 = lp.a(context, oVar.e + oVar.f1287a + oVar.b);
        ans.a();
        addView(imageButton2, new FrameLayout.LayoutParams(a5, lp.a(context, oVar.e + oVar.d), 17));
    }

    public final void a(boolean z) {
        ImageButton imageButton;
        int i;
        if (z) {
            imageButton = this.f1286a;
            i = 8;
        } else {
            imageButton = this.f1286a;
            i = 0;
        }
        imageButton.setVisibility(i);
    }

    public final void onClick(View view) {
        if (this.b != null) {
            this.b.c();
        }
    }
}
