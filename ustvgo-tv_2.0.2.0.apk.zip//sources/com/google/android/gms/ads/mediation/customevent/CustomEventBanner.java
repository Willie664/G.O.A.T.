package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.d;
import com.google.android.gms.ads.mediation.a;

public interface CustomEventBanner extends a {
    void requestBannerAd(Context context, b bVar, String str, d dVar, a aVar, Bundle bundle);
}
