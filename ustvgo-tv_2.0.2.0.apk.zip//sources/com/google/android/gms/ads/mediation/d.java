package com.google.android.gms.ads.mediation;

public interface d {
    void b(int i);

    void f();

    void g();

    void h();

    void i();

    void j();
}
