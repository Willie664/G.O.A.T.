package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.ads.aos;
import com.google.android.gms.internal.ads.aot;
import com.google.android.gms.internal.ads.cj;

@cj
public final class PublisherAdViewOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<PublisherAdViewOptions> CREATOR = new h();

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1195a;
    public final aos b;

    PublisherAdViewOptions(boolean z, IBinder iBinder) {
        this.f1195a = z;
        this.b = iBinder != null ? aot.a(iBinder) : null;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a2 = b.a(parcel, 20293);
        b.a(parcel, 1, this.f1195a);
        b.a(parcel, 2, this.b == null ? null : this.b.asBinder());
        b.b(parcel, a2);
    }
}
