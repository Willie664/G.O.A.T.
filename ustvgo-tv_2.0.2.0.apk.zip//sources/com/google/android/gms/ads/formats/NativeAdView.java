package com.google.android.gms.ads.formats;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.atk;
import com.google.android.gms.internal.ads.ma;

public class NativeAdView extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    private final FrameLayout f1194a;
    private final atk b = a();

    public NativeAdView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1194a = a(context);
    }

    public NativeAdView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1194a = a(context);
    }

    private final FrameLayout a(Context context) {
        FrameLayout frameLayout = new FrameLayout(context);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        addView(frameLayout);
        return frameLayout;
    }

    private final atk a() {
        ab.a(this.f1194a, (Object) "createDelegate must be called after mOverlayFrame has been created");
        if (isInEditMode()) {
            return null;
        }
        return ans.b().a(this.f1194a.getContext(), (FrameLayout) this, this.f1194a);
    }

    /* access modifiers changed from: protected */
    public final View a(String str) {
        try {
            a a2 = this.b.a(str);
            if (a2 != null) {
                return (View) b.a(a2);
            }
            return null;
        } catch (RemoteException e) {
            ma.a("Unable to call getAssetView on delegate", e);
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public final void a(String str, View view) {
        try {
            this.b.a(str, b.a(view));
        } catch (RemoteException e) {
            ma.a("Unable to call setAssetView on delegate", e);
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        super.bringChildToFront(this.f1194a);
    }

    public void bringChildToFront(View view) {
        super.bringChildToFront(view);
        if (this.f1194a != view) {
            super.bringChildToFront(this.f1194a);
        }
    }

    public AdChoicesView getAdChoicesView() {
        View a2 = a("1098");
        if (a2 instanceof AdChoicesView) {
            return (AdChoicesView) a2;
        }
        return null;
    }

    public void onVisibilityChanged(View view, int i) {
        super.onVisibilityChanged(view, i);
        if (this.b != null) {
            try {
                this.b.a(b.a(view), i);
            } catch (RemoteException e) {
                ma.a("Unable to call onVisibilityChanged on delegate", e);
            }
        }
    }

    public void removeAllViews() {
        super.removeAllViews();
        super.addView(this.f1194a);
    }

    public void removeView(View view) {
        if (this.f1194a != view) {
            super.removeView(view);
        }
    }

    public void setAdChoicesView(AdChoicesView adChoicesView) {
        a("1098", adChoicesView);
    }

    public void setNativeAd(a aVar) {
        try {
            this.b.a((a) aVar.a());
        } catch (RemoteException e) {
            ma.a("Unable to call setNativeAd on delegate", e);
        }
    }
}
