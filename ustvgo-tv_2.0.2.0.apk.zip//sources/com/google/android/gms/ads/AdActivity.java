package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.ank;
import com.google.android.gms.internal.ads.anr;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.q;

public class AdActivity extends Activity {

    /* renamed from: a  reason: collision with root package name */
    private q f1184a;

    private final void a() {
        if (this.f1184a != null) {
            try {
                this.f1184a.l();
            } catch (RemoteException e) {
                ma.c("#007 Could not call remote method.", e);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        try {
            this.f1184a.a(i, i2, intent);
        } catch (Exception e) {
            ma.c("#007 Could not call remote method.", e);
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onBackPressed() {
        boolean z = true;
        try {
            if (this.f1184a != null) {
                z = this.f1184a.e();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
        if (z) {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        try {
            this.f1184a.a(b.a(configuration));
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ank b = ans.b();
        Intent intent = getIntent();
        boolean z = false;
        if (!intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar")) {
            ma.a("useClientJar flag not found in activity intent extras.");
        } else {
            z = intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
        }
        this.f1184a = (q) ank.a((Context) this, z, new anr(b, this));
        if (this.f1184a == null) {
            ma.c("#007 Could not call remote method.", (Throwable) null);
        } else {
            try {
                this.f1184a.a(bundle);
                return;
            } catch (RemoteException e) {
                ma.c("#007 Could not call remote method.", e);
            }
        }
        finish();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        try {
            if (this.f1184a != null) {
                this.f1184a.k();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
        }
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        try {
            if (this.f1184a != null) {
                this.f1184a.i();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
        try {
            if (this.f1184a != null) {
                this.f1184a.f();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        try {
            if (this.f1184a != null) {
                this.f1184a.h();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        try {
            if (this.f1184a != null) {
                this.f1184a.b(bundle);
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        try {
            if (this.f1184a != null) {
                this.f1184a.g();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        try {
            if (this.f1184a != null) {
                this.f1184a.j();
            }
        } catch (RemoteException e) {
            ma.c("#007 Could not call remote method.", e);
            finish();
        }
        super.onStop();
    }

    public void setContentView(int i) {
        super.setContentView(i);
        a();
    }

    public void setContentView(View view) {
        super.setContentView(view);
        a();
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        super.setContentView(view, layoutParams);
        a();
    }
}
