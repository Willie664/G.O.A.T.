package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

public interface MediationInterstitialAdapter extends b {
    void requestInterstitialAd(Context context, d dVar, Bundle bundle, a aVar, Bundle bundle2);

    void showInterstitial();
}
