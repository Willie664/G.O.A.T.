package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.ase;
import com.google.android.gms.internal.ads.iy;

final class bp implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ase f1238a;
    private final /* synthetic */ bn b;

    bp(bn bnVar, ase ase) {
        this.b = bnVar;
        this.f1238a = ase;
    }

    public final void run() {
        try {
            if (this.b.e.t != null) {
                this.b.e.t.a(this.f1238a);
                this.b.a(this.f1238a.n());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
