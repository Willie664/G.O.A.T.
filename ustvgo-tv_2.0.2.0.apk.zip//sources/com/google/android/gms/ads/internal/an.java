package com.google.android.gms.ads.internal;

import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.zzjj;
import java.lang.ref.WeakReference;

final class an implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ WeakReference f1214a;
    private final /* synthetic */ am b;

    an(am amVar, WeakReference weakReference) {
        this.b = amVar;
        this.f1214a = weakReference;
    }

    public final void run() {
        this.b.b = false;
        a aVar = (a) this.f1214a.get();
        if (aVar != null) {
            zzjj zzjj = this.b.f1213a;
            if (aVar.c(zzjj)) {
                aVar.b(zzjj);
                return;
            }
            ma.a(4);
            aVar.d.a(zzjj);
        }
    }
}
