package com.google.android.gms.ads;

public final class j {
    public static d a(int i, int i2, String str) {
        return new d(i, i2, str);
    }
}
