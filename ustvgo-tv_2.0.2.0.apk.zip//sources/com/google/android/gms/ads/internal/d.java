package com.google.android.gms.ads.internal;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ bv f1246a;

    public d(bv bvVar) {
        this.f1246a = bvVar;
    }
}
