package com.google.android.gms.ads.internal;

final class bo implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bn f1237a;

    bo(bn bnVar) {
        this.f1237a = bnVar;
    }

    public final void run() {
        this.f1237a.b(this.f1237a.k);
    }
}
