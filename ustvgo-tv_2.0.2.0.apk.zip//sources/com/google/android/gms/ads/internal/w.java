package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

final class w implements ae<pu> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ CountDownLatch f1295a;

    w(CountDownLatch countDownLatch) {
        this.f1295a = countDownLatch;
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        iy.b("Adapter returned an ad, but assets substitution failed");
        this.f1295a.countDown();
        ((pu) obj).destroy();
    }
}
