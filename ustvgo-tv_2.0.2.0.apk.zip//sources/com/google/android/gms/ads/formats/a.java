package com.google.android.gms.ads.formats;

import android.graphics.drawable.Drawable;
import android.net.Uri;

public abstract class a {

    /* renamed from: com.google.android.gms.ads.formats.a$a  reason: collision with other inner class name */
    public static abstract class C0060a {
    }

    public static abstract class b {
        public abstract Drawable a();

        public abstract Uri b();

        public abstract double c();
    }

    /* access modifiers changed from: protected */
    public abstract Object a();
}
