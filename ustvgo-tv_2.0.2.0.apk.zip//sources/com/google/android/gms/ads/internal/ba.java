package com.google.android.gms.ads.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.overlay.m;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.Cif;
import com.google.android.gms.internal.ads.akg;
import com.google.android.gms.internal.ads.alp;
import com.google.android.gms.internal.ads.als;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.arf;
import com.google.android.gms.internal.ads.auc;
import com.google.android.gms.internal.ads.aun;
import com.google.android.gms.internal.ads.bag;
import com.google.android.gms.internal.ads.bao;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.cm;
import com.google.android.gms.internal.ads.dh;
import com.google.android.gms.internal.ads.dy;
import com.google.android.gms.internal.ads.id;
import com.google.android.gms.internal.ads.ig;
import com.google.android.gms.internal.ads.ih;
import com.google.android.gms.internal.ads.ii;
import com.google.android.gms.internal.ads.in;
import com.google.android.gms.internal.ads.iq;
import com.google.android.gms.internal.ads.ir;
import com.google.android.gms.internal.ads.it;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.jm;
import com.google.android.gms.internal.ads.ma;
import com.google.android.gms.internal.ads.na;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import java.util.concurrent.Executor;
import javax.annotation.ParametersAreNonnullByDefault;
import org.json.JSONException;
import org.json.JSONObject;

@cj
@ParametersAreNonnullByDefault
public abstract class ba extends a implements ap, m, bag {
    private transient boolean j;
    protected final bav o;

    public ba(Context context, zzjn zzjn, String str, bav bav, zzang zzang, bt btVar) {
        this(new ax(context, zzjn, str, zzang), bav, btVar);
    }

    private ba(ax axVar, bav bav, bt btVar) {
        super(axVar, btVar);
        this.o = bav;
        this.j = false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:102:0x0253  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x02c2  */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x032b  */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x0335  */
    /* JADX WARNING: Removed duplicated region for block: B:153:0x0390  */
    /* JADX WARNING: Removed duplicated region for block: B:154:0x0393  */
    /* JADX WARNING: Removed duplicated region for block: B:157:0x041b  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x041e  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x01ed  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x022d  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x0241  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0244  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final com.google.android.gms.internal.ads.dh a(com.google.android.gms.internal.ads.zzjj r68, android.os.Bundle r69, com.google.android.gms.internal.ads.ih r70, int r71) {
        /*
            r67 = this;
            r1 = r67
            r0 = r68
            r2 = r70
            com.google.android.gms.ads.internal.ax r3 = r1.e
            android.content.Context r3 = r3.c
            android.content.pm.ApplicationInfo r7 = r3.getApplicationInfo()
            r4 = 0
            com.google.android.gms.ads.internal.ax r5 = r1.e     // Catch:{ NameNotFoundException -> 0x001f }
            android.content.Context r5 = r5.c     // Catch:{ NameNotFoundException -> 0x001f }
            com.google.android.gms.common.a.b r5 = com.google.android.gms.common.a.c.a(r5)     // Catch:{ NameNotFoundException -> 0x001f }
            java.lang.String r6 = r7.packageName     // Catch:{ NameNotFoundException -> 0x001f }
            android.content.pm.PackageInfo r5 = r5.b(r6, r4)     // Catch:{ NameNotFoundException -> 0x001f }
            r8 = r5
            goto L_0x0020
        L_0x001f:
            r8 = 0
        L_0x0020:
            com.google.android.gms.ads.internal.ax r5 = r1.e
            android.content.Context r5 = r5.c
            android.content.res.Resources r5 = r5.getResources()
            android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
            com.google.android.gms.ads.internal.ax r6 = r1.e
            com.google.android.gms.ads.internal.ay r6 = r6.f
            r9 = 2
            r10 = 1
            if (r6 == 0) goto L_0x0098
            com.google.android.gms.ads.internal.ax r6 = r1.e
            com.google.android.gms.ads.internal.ay r6 = r6.f
            android.view.ViewParent r6 = r6.getParent()
            if (r6 == 0) goto L_0x0098
            int[] r6 = new int[r9]
            com.google.android.gms.ads.internal.ax r11 = r1.e
            com.google.android.gms.ads.internal.ay r11 = r11.f
            r11.getLocationOnScreen(r6)
            r11 = r6[r4]
            r6 = r6[r10]
            com.google.android.gms.ads.internal.ax r12 = r1.e
            com.google.android.gms.ads.internal.ay r12 = r12.f
            int r12 = r12.getWidth()
            com.google.android.gms.ads.internal.ax r13 = r1.e
            com.google.android.gms.ads.internal.ay r13 = r13.f
            int r13 = r13.getHeight()
            com.google.android.gms.ads.internal.ax r14 = r1.e
            com.google.android.gms.ads.internal.ay r14 = r14.f
            boolean r14 = r14.isShown()
            if (r14 == 0) goto L_0x0077
            int r14 = r11 + r12
            if (r14 <= 0) goto L_0x0077
            int r14 = r6 + r13
            if (r14 <= 0) goto L_0x0077
            int r14 = r5.widthPixels
            if (r11 > r14) goto L_0x0077
            int r14 = r5.heightPixels
            if (r6 > r14) goto L_0x0077
            r14 = 1
            goto L_0x0078
        L_0x0077:
            r14 = 0
        L_0x0078:
            android.os.Bundle r15 = new android.os.Bundle
            r4 = 5
            r15.<init>(r4)
            java.lang.String r4 = "x"
            r15.putInt(r4, r11)
            java.lang.String r4 = "y"
            r15.putInt(r4, r6)
            java.lang.String r4 = "width"
            r15.putInt(r4, r12)
            java.lang.String r4 = "height"
            r15.putInt(r4, r13)
            java.lang.String r4 = "visible"
            r15.putInt(r4, r14)
            goto L_0x0099
        L_0x0098:
            r15 = 0
        L_0x0099:
            com.google.android.gms.internal.ads.ii r4 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ip r4 = r4.c
            java.lang.String r11 = r4.a()
            com.google.android.gms.ads.internal.ax r4 = r1.e
            com.google.android.gms.internal.ads.if r6 = new com.google.android.gms.internal.ads.if
            com.google.android.gms.ads.internal.ax r12 = r1.e
            java.lang.String r12 = r12.b
            r6.<init>(r11, r12)
            r4.l = r6
            com.google.android.gms.ads.internal.ax r4 = r1.e
            com.google.android.gms.internal.ads.if r4 = r4.l
            java.lang.Object r6 = r4.c
            monitor-enter(r6)
            long r12 = android.os.SystemClock.elapsedRealtime()     // Catch:{ all -> 0x0474 }
            r4.i = r12     // Catch:{ all -> 0x0474 }
            com.google.android.gms.internal.ads.ir r12 = r4.f2107a     // Catch:{ all -> 0x0474 }
            long r13 = r4.i     // Catch:{ all -> 0x0474 }
            java.lang.Object r4 = r12.f2118a     // Catch:{ all -> 0x0474 }
            monitor-enter(r4)     // Catch:{ all -> 0x0474 }
            com.google.android.gms.internal.ads.in r12 = r12.b     // Catch:{ all -> 0x0471 }
            java.lang.Object r3 = r12.f     // Catch:{ all -> 0x0471 }
            monitor-enter(r3)     // Catch:{ all -> 0x0471 }
            com.google.android.gms.internal.ads.ii r16 = com.google.android.gms.ads.internal.aw.i()     // Catch:{ all -> 0x046e }
            com.google.android.gms.internal.ads.ja r16 = r16.f()     // Catch:{ all -> 0x046e }
            long r16 = r16.k()     // Catch:{ all -> 0x046e }
            com.google.android.gms.common.util.e r18 = com.google.android.gms.ads.internal.aw.l()     // Catch:{ all -> 0x046e }
            r54 = r11
            long r10 = r18.a()     // Catch:{ all -> 0x046e }
            r55 = r10
            long r9 = r12.b     // Catch:{ all -> 0x046e }
            r18 = -1
            int r11 = (r9 > r18 ? 1 : (r9 == r18 ? 0 : -1))
            if (r11 != 0) goto L_0x011a
            long r10 = r55 - r16
            com.google.android.gms.internal.ads.aqi<java.lang.Long> r9 = com.google.android.gms.internal.ads.aqs.aI     // Catch:{ all -> 0x046e }
            r57 = r7
            com.google.android.gms.internal.ads.aqq r7 = com.google.android.gms.internal.ads.ans.f()     // Catch:{ all -> 0x046e }
            java.lang.Object r7 = r7.a(r9)     // Catch:{ all -> 0x046e }
            java.lang.Long r7 = (java.lang.Long) r7     // Catch:{ all -> 0x046e }
            long r16 = r7.longValue()     // Catch:{ all -> 0x046e }
            int r7 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1))
            if (r7 <= 0) goto L_0x0105
            r7 = -1
            r12.d = r7     // Catch:{ all -> 0x046e }
            goto L_0x0113
        L_0x0105:
            com.google.android.gms.internal.ads.ii r7 = com.google.android.gms.ads.internal.aw.i()     // Catch:{ all -> 0x046e }
            com.google.android.gms.internal.ads.ja r7 = r7.f()     // Catch:{ all -> 0x046e }
            int r7 = r7.l()     // Catch:{ all -> 0x046e }
            r12.d = r7     // Catch:{ all -> 0x046e }
        L_0x0113:
            r12.b = r13     // Catch:{ all -> 0x046e }
            long r9 = r12.b     // Catch:{ all -> 0x046e }
            r12.f2115a = r9     // Catch:{ all -> 0x046e }
            goto L_0x011e
        L_0x011a:
            r57 = r7
            r12.f2115a = r13     // Catch:{ all -> 0x046e }
        L_0x011e:
            r9 = 0
            if (r0 == 0) goto L_0x0135
            android.os.Bundle r7 = r0.c     // Catch:{ all -> 0x046e }
            if (r7 == 0) goto L_0x0135
            android.os.Bundle r7 = r0.c     // Catch:{ all -> 0x046e }
            java.lang.String r11 = "gw"
            r13 = 2
            int r7 = r7.getInt(r11, r13)     // Catch:{ all -> 0x046e }
            r11 = 1
            if (r7 != r11) goto L_0x0135
            monitor-exit(r3)     // Catch:{ all -> 0x046e }
            r11 = 1
            goto L_0x0195
        L_0x0135:
            int r7 = r12.c     // Catch:{ all -> 0x046e }
            r11 = 1
            int r7 = r7 + r11
            r12.c = r7     // Catch:{ all -> 0x046e }
            int r7 = r12.d     // Catch:{ all -> 0x046e }
            int r7 = r7 + r11
            r12.d = r7     // Catch:{ all -> 0x046e }
            int r7 = r12.d     // Catch:{ all -> 0x046e }
            if (r7 != 0) goto L_0x0181
            r12.e = r9     // Catch:{ all -> 0x046e }
            com.google.android.gms.internal.ads.ii r7 = com.google.android.gms.ads.internal.aw.i()     // Catch:{ all -> 0x046e }
            com.google.android.gms.internal.ads.ja r7 = r7.f()     // Catch:{ all -> 0x046e }
            r7.a()     // Catch:{ all -> 0x046e }
            java.lang.Object r12 = r7.f2125a     // Catch:{ all -> 0x046e }
            monitor-enter(r12)     // Catch:{ all -> 0x046e }
            long r13 = r7.m     // Catch:{ all -> 0x017e }
            int r16 = (r13 > r55 ? 1 : (r13 == r55 ? 0 : -1))
            if (r16 != 0) goto L_0x015c
        L_0x015a:
            monitor-exit(r12)     // Catch:{ all -> 0x017e }
            goto L_0x0194
        L_0x015c:
            r13 = r55
            r7.m = r13     // Catch:{ all -> 0x017e }
            android.content.SharedPreferences$Editor r9 = r7.d     // Catch:{ all -> 0x017e }
            if (r9 == 0) goto L_0x0170
            android.content.SharedPreferences$Editor r9 = r7.d     // Catch:{ all -> 0x017e }
            java.lang.String r10 = "first_ad_req_time_ms"
            r9.putLong(r10, r13)     // Catch:{ all -> 0x017e }
            android.content.SharedPreferences$Editor r9 = r7.d     // Catch:{ all -> 0x017e }
            r9.apply()     // Catch:{ all -> 0x017e }
        L_0x0170:
            android.os.Bundle r9 = new android.os.Bundle     // Catch:{ all -> 0x017e }
            r9.<init>()     // Catch:{ all -> 0x017e }
            java.lang.String r10 = "first_ad_req_time_ms"
            r9.putLong(r10, r13)     // Catch:{ all -> 0x017e }
            r7.a((android.os.Bundle) r9)     // Catch:{ all -> 0x017e }
            goto L_0x015a
        L_0x017e:
            r0 = move-exception
            monitor-exit(r12)     // Catch:{ all -> 0x017e }
            throw r0     // Catch:{ all -> 0x046e }
        L_0x0181:
            r13 = r55
            com.google.android.gms.internal.ads.ii r7 = com.google.android.gms.ads.internal.aw.i()     // Catch:{ all -> 0x046e }
            com.google.android.gms.internal.ads.ja r7 = r7.f()     // Catch:{ all -> 0x046e }
            long r9 = r7.m()     // Catch:{ all -> 0x046e }
            r7 = 0
            long r9 = r13 - r9
            r12.e = r9     // Catch:{ all -> 0x046e }
        L_0x0194:
            monitor-exit(r3)     // Catch:{ all -> 0x046e }
        L_0x0195:
            monitor-exit(r4)     // Catch:{ all -> 0x0471 }
            monitor-exit(r6)     // Catch:{ all -> 0x0474 }
            com.google.android.gms.ads.internal.aw.e()
            com.google.android.gms.ads.internal.ax r3 = r1.e
            android.content.Context r3 = r3.c
            com.google.android.gms.ads.internal.ax r4 = r1.e
            com.google.android.gms.ads.internal.ay r4 = r4.f
            com.google.android.gms.ads.internal.ax r6 = r1.e
            com.google.android.gms.internal.ads.zzjn r6 = r6.i
            java.lang.String r20 = com.google.android.gms.internal.ads.jh.a((android.content.Context) r3, (android.view.View) r4, (com.google.android.gms.internal.ads.zzjn) r6)
            com.google.android.gms.ads.internal.ax r3 = r1.e
            com.google.android.gms.internal.ads.aoy r3 = r3.q
            if (r3 == 0) goto L_0x01c0
            com.google.android.gms.ads.internal.ax r3 = r1.e     // Catch:{ RemoteException -> 0x01bb }
            com.google.android.gms.internal.ads.aoy r3 = r3.q     // Catch:{ RemoteException -> 0x01bb }
            long r3 = r3.a()     // Catch:{ RemoteException -> 0x01bb }
            r21 = r3
            goto L_0x01c2
        L_0x01bb:
            java.lang.String r3 = "Cannot get correlation id, default to 0."
            com.google.android.gms.internal.ads.iy.b(r3)
        L_0x01c0:
            r21 = 0
        L_0x01c2:
            java.util.UUID r3 = java.util.UUID.randomUUID()
            java.lang.String r23 = r3.toString()
            com.google.android.gms.internal.ads.ir r3 = com.google.android.gms.ads.internal.aw.j()
            com.google.android.gms.ads.internal.ax r4 = r1.e
            android.content.Context r4 = r4.c
            r9 = r54
            android.os.Bundle r12 = r3.a(r4, r1, r9)
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            r3 = 0
        L_0x01e3:
            com.google.android.gms.ads.internal.ax r4 = r1.e
            android.support.v4.f.m<java.lang.String, com.google.android.gms.internal.ads.auq> r4 = r4.v
            int r4 = r4.size()
            if (r3 >= r4) goto L_0x0214
            com.google.android.gms.ads.internal.ax r4 = r1.e
            android.support.v4.f.m<java.lang.String, com.google.android.gms.internal.ads.auq> r4 = r4.v
            java.lang.Object r4 = r4.b((int) r3)
            java.lang.String r4 = (java.lang.String) r4
            r14.add(r4)
            com.google.android.gms.ads.internal.ax r6 = r1.e
            android.support.v4.f.m<java.lang.String, com.google.android.gms.internal.ads.aun> r6 = r6.u
            boolean r6 = r6.containsKey(r4)
            if (r6 == 0) goto L_0x0211
            com.google.android.gms.ads.internal.ax r6 = r1.e
            android.support.v4.f.m<java.lang.String, com.google.android.gms.internal.ads.aun> r6 = r6.u
            java.lang.Object r6 = r6.get(r4)
            if (r6 == 0) goto L_0x0211
            r13.add(r4)
        L_0x0211:
            int r3 = r3 + 1
            goto L_0x01e3
        L_0x0214:
            com.google.android.gms.ads.internal.bd r3 = new com.google.android.gms.ads.internal.bd
            r3.<init>(r1)
            com.google.android.gms.internal.ads.mu r34 = com.google.android.gms.internal.ads.jf.a(r3)
            com.google.android.gms.ads.internal.be r3 = new com.google.android.gms.ads.internal.be
            r3.<init>(r1)
            com.google.android.gms.internal.ads.mu r44 = com.google.android.gms.internal.ads.jf.a(r3)
            if (r2 == 0) goto L_0x022d
            java.lang.String r2 = r2.d
            r35 = r2
            goto L_0x022f
        L_0x022d:
            r35 = 0
        L_0x022f:
            com.google.android.gms.ads.internal.ax r2 = r1.e
            java.util.List<java.lang.String> r2 = r2.F
            if (r2 == 0) goto L_0x02e1
            com.google.android.gms.ads.internal.ax r2 = r1.e
            java.util.List<java.lang.String> r2 = r2.F
            int r2 = r2.size()
            if (r2 <= 0) goto L_0x02e1
            if (r8 == 0) goto L_0x0244
            int r4 = r8.versionCode
            goto L_0x0245
        L_0x0244:
            r4 = 0
        L_0x0245:
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            int r2 = r2.i()
            if (r4 <= r2) goto L_0x02c2
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            r2.a()
            java.lang.Object r3 = r2.f2125a
            monitor-enter(r3)
            org.json.JSONObject r6 = new org.json.JSONObject     // Catch:{ all -> 0x02bf }
            r6.<init>()     // Catch:{ all -> 0x02bf }
            r2.q = r6     // Catch:{ all -> 0x02bf }
            android.content.SharedPreferences$Editor r6 = r2.d     // Catch:{ all -> 0x02bf }
            if (r6 == 0) goto L_0x0278
            android.content.SharedPreferences$Editor r6 = r2.d     // Catch:{ all -> 0x02bf }
            java.lang.String r7 = "native_advanced_settings"
            r6.remove(r7)     // Catch:{ all -> 0x02bf }
            android.content.SharedPreferences$Editor r6 = r2.d     // Catch:{ all -> 0x02bf }
            r6.apply()     // Catch:{ all -> 0x02bf }
        L_0x0278:
            android.os.Bundle r6 = new android.os.Bundle     // Catch:{ all -> 0x02bf }
            r6.<init>()     // Catch:{ all -> 0x02bf }
            java.lang.String r7 = "native_advanced_settings"
            java.lang.String r10 = "{}"
            r6.putString(r7, r10)     // Catch:{ all -> 0x02bf }
            r2.a((android.os.Bundle) r6)     // Catch:{ all -> 0x02bf }
            monitor-exit(r3)     // Catch:{ all -> 0x02bf }
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            r2.a()
            java.lang.Object r6 = r2.f2125a
            monitor-enter(r6)
            int r3 = r2.o     // Catch:{ all -> 0x02bc }
            if (r3 != r4) goto L_0x029c
        L_0x029a:
            monitor-exit(r6)     // Catch:{ all -> 0x02bc }
            goto L_0x02e1
        L_0x029c:
            r2.o = r4     // Catch:{ all -> 0x02bc }
            android.content.SharedPreferences$Editor r3 = r2.d     // Catch:{ all -> 0x02bc }
            if (r3 == 0) goto L_0x02ae
            android.content.SharedPreferences$Editor r3 = r2.d     // Catch:{ all -> 0x02bc }
            java.lang.String r7 = "version_code"
            r3.putInt(r7, r4)     // Catch:{ all -> 0x02bc }
            android.content.SharedPreferences$Editor r3 = r2.d     // Catch:{ all -> 0x02bc }
            r3.apply()     // Catch:{ all -> 0x02bc }
        L_0x02ae:
            android.os.Bundle r3 = new android.os.Bundle     // Catch:{ all -> 0x02bc }
            r3.<init>()     // Catch:{ all -> 0x02bc }
            java.lang.String r7 = "version_code"
            r3.putInt(r7, r4)     // Catch:{ all -> 0x02bc }
            r2.a((android.os.Bundle) r3)     // Catch:{ all -> 0x02bc }
            goto L_0x029a
        L_0x02bc:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x02bc }
            throw r0
        L_0x02bf:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x02bf }
            throw r0
        L_0x02c2:
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            org.json.JSONObject r2 = r2.n()
            if (r2 == 0) goto L_0x02e1
            com.google.android.gms.ads.internal.ax r3 = r1.e
            java.lang.String r3 = r3.b
            org.json.JSONArray r2 = r2.optJSONArray(r3)
            if (r2 == 0) goto L_0x02e1
            java.lang.String r2 = r2.toString()
            r46 = r2
            goto L_0x02e3
        L_0x02e1:
            r46 = 0
        L_0x02e3:
            com.google.android.gms.internal.ads.dh r53 = new com.google.android.gms.internal.ads.dh
            com.google.android.gms.ads.internal.ax r2 = r1.e
            com.google.android.gms.internal.ads.zzjn r6 = r2.i
            com.google.android.gms.ads.internal.ax r2 = r1.e
            java.lang.String r7 = r2.b
            java.lang.String r10 = com.google.android.gms.internal.ads.ans.c()
            com.google.android.gms.ads.internal.ax r2 = r1.e
            com.google.android.gms.internal.ads.zzang r4 = r2.e
            com.google.android.gms.ads.internal.ax r2 = r1.e
            java.util.List<java.lang.String> r3 = r2.F
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            boolean r16 = r2.c()
            int r2 = r5.widthPixels
            int r0 = r5.heightPixels
            float r5 = r5.density
            java.util.List r24 = com.google.android.gms.internal.ads.aqs.a()
            com.google.android.gms.ads.internal.ax r11 = r1.e
            java.lang.String r11 = r11.f1223a
            r58 = r2
            com.google.android.gms.ads.internal.ax r2 = r1.e
            com.google.android.gms.internal.ads.zzpl r2 = r2.w
            r59 = r2
            com.google.android.gms.ads.internal.ax r2 = r1.e
            r60 = r3
            boolean r3 = r2.L
            if (r3 == 0) goto L_0x0327
            boolean r3 = r2.M
            if (r3 != 0) goto L_0x0343
        L_0x0327:
            boolean r3 = r2.L
            if (r3 == 0) goto L_0x0335
            boolean r2 = r2.N
            if (r2 == 0) goto L_0x0332
            java.lang.String r2 = "top-scrollable"
            goto L_0x0345
        L_0x0332:
            java.lang.String r2 = "top-locked"
            goto L_0x0345
        L_0x0335:
            boolean r3 = r2.M
            if (r3 == 0) goto L_0x0343
            boolean r2 = r2.N
            if (r2 == 0) goto L_0x0340
            java.lang.String r2 = "bottom-scrollable"
            goto L_0x0345
        L_0x0340:
            java.lang.String r2 = "bottom-locked"
            goto L_0x0345
        L_0x0343:
            java.lang.String r2 = ""
        L_0x0345:
            r27 = r2
            com.google.android.gms.internal.ads.jx r2 = com.google.android.gms.ads.internal.aw.D()
            float r28 = r2.a()
            com.google.android.gms.internal.ads.jx r2 = com.google.android.gms.ads.internal.aw.D()
            boolean r29 = r2.b()
            com.google.android.gms.ads.internal.aw.e()
            com.google.android.gms.ads.internal.ax r2 = r1.e
            android.content.Context r2 = r2.c
            int r30 = com.google.android.gms.internal.ads.jh.h(r2)
            com.google.android.gms.ads.internal.aw.e()
            com.google.android.gms.ads.internal.ax r2 = r1.e
            com.google.android.gms.ads.internal.ay r2 = r2.f
            int r31 = com.google.android.gms.internal.ads.jh.d((android.view.View) r2)
            com.google.android.gms.ads.internal.ax r2 = r1.e
            android.content.Context r2 = r2.c
            boolean r3 = r2 instanceof android.app.Activity
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            boolean r33 = r2.h()
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.il r2 = r2.i
            r2.a()
            int r2 = r2.f2113a
            r61 = r3
            int r3 = com.google.android.gms.internal.ads.im.b
            if (r2 != r3) goto L_0x0393
            r36 = 1
            goto L_0x0395
        L_0x0393:
            r36 = 0
        L_0x0395:
            com.google.android.gms.internal.ads.pe r2 = com.google.android.gms.ads.internal.aw.z()
            java.util.List<com.google.android.gms.internal.ads.pc> r2 = r2.f2234a
            int r37 = r2.size()
            com.google.android.gms.ads.internal.aw.e()
            android.os.Bundle r38 = com.google.android.gms.internal.ads.jh.c()
            com.google.android.gms.internal.ads.kg r2 = com.google.android.gms.ads.internal.aw.o()
            java.lang.String r39 = r2.a()
            com.google.android.gms.ads.internal.ax r2 = r1.e
            com.google.android.gms.internal.ads.zzlu r3 = r2.y
            com.google.android.gms.internal.ads.kg r2 = com.google.android.gms.ads.internal.aw.o()
            boolean r41 = r2.b()
            com.google.android.gms.internal.ads.axh r2 = com.google.android.gms.internal.ads.axh.a()
            r62 = r0
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            r63 = r3
            java.lang.String r3 = "ipl"
            r64 = r4
            int r4 = r2.f1898a
            r0.putInt(r3, r4)
            java.lang.String r3 = "ipds"
            int r4 = r2.b
            r0.putInt(r3, r4)
            java.lang.String r3 = "ipde"
            int r4 = r2.c
            r0.putInt(r3, r4)
            java.lang.String r3 = "iph"
            int r4 = r2.d
            r0.putInt(r3, r4)
            java.lang.String r3 = "ipm"
            int r2 = r2.e
            r0.putInt(r3, r2)
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.ja r2 = r2.f()
            com.google.android.gms.ads.internal.ax r3 = r1.e
            java.lang.String r3 = r3.b
            boolean r43 = r2.c((java.lang.String) r3)
            com.google.android.gms.ads.internal.ax r2 = r1.e
            java.util.List<java.lang.Integer> r4 = r2.A
            com.google.android.gms.ads.internal.ax r2 = r1.e
            android.content.Context r2 = r2.c
            com.google.android.gms.common.a.b r2 = com.google.android.gms.common.a.c.a(r2)
            boolean r49 = r2.a()
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.il r2 = r2.i
            r2.a()
            int r2 = r2.f2113a
            int r3 = com.google.android.gms.internal.ads.im.c
            if (r2 != r3) goto L_0x041e
            r50 = 1
            goto L_0x0420
        L_0x041e:
            r50 = 0
        L_0x0420:
            com.google.android.gms.ads.internal.aw.g()
            boolean r51 = com.google.android.gms.internal.ads.jm.e()
            com.google.android.gms.internal.ads.ii r2 = com.google.android.gms.ads.internal.aw.i()
            com.google.android.gms.internal.ads.mu r2 = r2.g()
            r65 = r4
            r3 = 1000(0x3e8, double:4.94E-321)
            java.util.concurrent.TimeUnit r1 = java.util.concurrent.TimeUnit.MILLISECONDS
            r66 = r5
            r5 = 0
            java.lang.Object r1 = com.google.android.gms.internal.ads.mj.a(r2, r5, (long) r3, (java.util.concurrent.TimeUnit) r1)
            r52 = r1
            java.util.ArrayList r52 = (java.util.ArrayList) r52
            r1 = r58
            r26 = r59
            r2 = r53
            r17 = r60
            r32 = r61
            r40 = r63
            r3 = r15
            r15 = r64
            r45 = r65
            r4 = r68
            r19 = r66
            r5 = r6
            r6 = r7
            r7 = r57
            r25 = r11
            r11 = r15
            r47 = r13
            r13 = r17
            r15 = r69
            r17 = r1
            r18 = r62
            r42 = r0
            r48 = r71
            r2.<init>(r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40, r41, r42, r43, r44, r45, r46, r47, r48, r49, r50, r51, r52)
            return r53
        L_0x046e:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x046e }
            throw r0     // Catch:{ all -> 0x0471 }
        L_0x0471:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x0471 }
            throw r0     // Catch:{ all -> 0x0474 }
        L_0x0474:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x0474 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.ba.a(com.google.android.gms.internal.ads.zzjj, android.os.Bundle, com.google.android.gms.internal.ads.ih, int):com.google.android.gms.internal.ads.dh");
    }

    static String c(id idVar) {
        if (idVar == null) {
            return null;
        }
        String str = idVar.q;
        if (("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter".equals(str) || "com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) && idVar.o != null) {
            try {
                return new JSONObject(idVar.o.k).getString("class_name");
            } catch (NullPointerException | JSONException unused) {
            }
        }
        return str;
    }

    public void I() {
        iy.b("showInterstitial is not supported for current ad type");
    }

    public void S() {
        e();
    }

    public void T() {
        aa();
    }

    public void U() {
        iy.b("Mediated ad does not support onVideoEnd callback");
    }

    /* access modifiers changed from: protected */
    public boolean V() {
        aw.e();
        if (jh.a(this.e.c, "android.permission.INTERNET")) {
            aw.e();
            return jh.a(this.e.c);
        }
    }

    public final void W() {
        r_();
    }

    public final void X() {
        v();
    }

    public final void Y() {
        g();
    }

    public final void Z() {
        if (this.e.j != null) {
            String str = this.e.j.q;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 74);
            sb.append("Mediation adapter ");
            sb.append(str);
            sb.append(" refreshed, but mediation adapters should never refresh.");
            iy.b(sb.toString());
        }
        a(this.e.j, true);
        b(this.e.j, true);
        x();
    }

    public final String a() {
        if (this.e.j == null) {
            return null;
        }
        return this.e.j.q;
    }

    public final void a(auc auc, String str) {
        String str2;
        aun aun = null;
        if (auc != null) {
            try {
                str2 = auc.l();
            } catch (RemoteException e) {
                iy.b("Unable to call onCustomClick.", e);
                return;
            }
        } else {
            str2 = null;
        }
        if (!(this.e.u == null || str2 == null)) {
            aun = this.e.u.get(str2);
        }
        if (aun == null) {
            iy.b("Mediation adapter invoked onCustomClick but no listeners were set.");
        } else {
            aun.a(auc, str);
        }
    }

    /* access modifiers changed from: protected */
    public void a(id idVar, boolean z) {
        if (idVar == null) {
            iy.b("Ad state was null when trying to ping impression URLs.");
            return;
        }
        if (idVar == null) {
            iy.b("Ad state was null when trying to ping impression URLs.");
        } else {
            ma.a(3);
            if (this.e.l != null) {
                Cif ifVar = this.e.l;
                synchronized (ifVar.c) {
                    if (ifVar.j != -1 && ifVar.e == -1) {
                        ifVar.e = SystemClock.elapsedRealtime();
                        ifVar.f2107a.a(ifVar);
                    }
                    ir irVar = ifVar.f2107a;
                    synchronized (irVar.f2118a) {
                        in inVar = irVar.b;
                        synchronized (inVar.f) {
                            inVar.h++;
                        }
                    }
                }
            }
            idVar.K.a(alp.a.b.AD_IMPRESSION);
            if (idVar.e != null && !idVar.D) {
                aw.e();
                jh.a(this.e.c, this.e.e.f2393a, b(idVar.e));
                idVar.D = true;
            }
        }
        if (!idVar.F || z) {
            if (!(idVar.r == null || idVar.r.d == null)) {
                aw.x();
                bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, z, b(idVar.r.d));
            }
            if (!(idVar.o == null || idVar.o.g == null)) {
                aw.x();
                bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, z, idVar.o.g);
            }
            idVar.F = true;
        }
    }

    public final boolean a(dh dhVar, arf arf) {
        this.f1202a = arf;
        arf.a("seq_num", dhVar.g);
        arf.a("request_id", dhVar.v);
        arf.a("session_id", dhVar.h);
        if (dhVar.f != null) {
            arf.a("app_version", String.valueOf(dhVar.f.versionCode));
        }
        ax axVar = this.e;
        aw.a();
        Context context = this.e.c;
        als als = this.i.d;
        it dyVar = dhVar.b.c.getBundle("sdk_less_server_data") != null ? new dy(context, dhVar, this, als) : new cm(context, dhVar, this, als);
        dyVar.h();
        axVar.g = dyVar;
        return true;
    }

    /* access modifiers changed from: package-private */
    public final boolean a(id idVar) {
        zzjj zzjj;
        boolean z = false;
        if (this.f != null) {
            zzjj = this.f;
            this.f = null;
        } else {
            zzjj = idVar.f2105a;
            if (zzjj.c != null) {
                z = zzjj.c.getBoolean("_noRefresh", false);
            }
        }
        return a(zzjj, idVar, z);
    }

    /* access modifiers changed from: protected */
    public boolean a(id idVar, id idVar2) {
        int i;
        if (!(idVar == null || idVar.s == null)) {
            idVar.s.a((bag) null);
        }
        if (idVar2.s != null) {
            idVar2.s.a((bag) this);
        }
        int i2 = 0;
        if (idVar2.r != null) {
            i2 = idVar2.r.r;
            i = idVar2.r.s;
        } else {
            i = 0;
        }
        iq iqVar = this.e.G;
        synchronized (iqVar.f2117a) {
            iqVar.b = i2;
            iqVar.c = i;
            ir irVar = iqVar.d;
            synchronized (irVar.f2118a) {
                irVar.d.add(iqVar);
            }
        }
        return true;
    }

    public boolean a(zzjj zzjj, arf arf) {
        return a(zzjj, arf, 1);
    }

    public final boolean a(zzjj zzjj, arf arf, int i) {
        ih ihVar;
        if (!V()) {
            return false;
        }
        aw.e();
        Context context = this.e.c;
        ii i2 = aw.i();
        akg a2 = i2.a(context, i2.d.d(), i2.d.f());
        Bundle a3 = a2 == null ? null : jh.a(a2);
        this.d.a();
        this.e.I = 0;
        if (((Boolean) ans.f().a(aqs.cs)).booleanValue()) {
            ihVar = aw.i().f().j();
            aw.m().a(this.e.c, this.e.e, false, ihVar, ihVar.c, this.e.b, (Runnable) null);
        } else {
            ihVar = null;
        }
        return a(a(zzjj, a3, ihVar, i), arf);
    }

    /* access modifiers changed from: protected */
    public boolean a(zzjj zzjj, id idVar, boolean z) {
        am amVar;
        long j2;
        if (!z && this.e.c()) {
            if (idVar.i > 0) {
                amVar = this.d;
                j2 = idVar.i;
            } else if (idVar.r != null && idVar.r.j > 0) {
                amVar = this.d;
                j2 = idVar.r.j;
            } else if (!idVar.n && idVar.d == 2) {
                this.d.a(zzjj);
            }
            amVar.a(zzjj, j2);
        }
        return this.d.b;
    }

    public final void aa() {
        a(this.e.j, false);
    }

    public final void b(id idVar) {
        super.b(idVar);
        if (idVar.o != null) {
            ma.a(3);
            if (this.e.f != null) {
                ay ayVar = this.e.f;
                iy.a();
                ayVar.c = false;
            }
            ma.a(3);
            aw.x();
            bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, false, idVar.o.j);
            if (!(idVar.r == null || idVar.r.g == null || idVar.r.g.size() <= 0)) {
                ma.a(3);
                aw.e();
                jh.a(this.e.c, idVar.r.g);
            }
        } else {
            ma.a(3);
            if (this.e.f != null) {
                ay ayVar2 = this.e.f;
                iy.a();
                ayVar2.c = true;
            }
        }
        if (idVar.d == 3 && idVar.r != null && idVar.r.f != null) {
            ma.a(3);
            aw.x();
            bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, false, idVar.r.f);
        }
    }

    /* access modifiers changed from: protected */
    public final void b(id idVar, boolean z) {
        if (idVar != null) {
            if (!(idVar == null || idVar.f == null || idVar.E)) {
                aw.e();
                jh.a(this.e.c, this.e.e.f2393a, a(idVar.f));
                idVar.E = true;
            }
            if (!idVar.G || z) {
                if (!(idVar.r == null || idVar.r.e == null)) {
                    aw.x();
                    bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, z, a(idVar.r.e));
                }
                if (!(idVar.o == null || idVar.o.h == null)) {
                    aw.x();
                    bao.a(this.e.c, this.e.e.f2393a, idVar, this.e.b, z, idVar.o.h);
                }
                idVar.G = true;
            }
        }
    }

    public final void b(String str, String str2) {
        a(str, str2);
    }

    /* access modifiers changed from: protected */
    public final boolean c(zzjj zzjj) {
        return super.c(zzjj) && !this.j;
    }

    public final void d() {
        this.g.b(this.e.j);
    }

    public final void e() {
        if (this.e.j == null) {
            iy.b("Ad state was null when trying to ping click URLs.");
            return;
        }
        if (!(this.e.j.r == null || this.e.j.r.c == null)) {
            aw.x();
            bao.a(this.e.c, this.e.e.f2393a, this.e.j, this.e.b, false, b(this.e.j.r.c));
        }
        if (!(this.e.j.o == null || this.e.j.o.f == null)) {
            aw.x();
            bao.a(this.e.c, this.e.e.f2393a, this.e.j, this.e.b, false, this.e.j.o.f);
        }
        super.e();
    }

    public final void f() {
        this.g.c(this.e.j);
    }

    public void g() {
        this.j = true;
        w();
    }

    public final void j_() {
        Executor executor = na.f2195a;
        am amVar = this.d;
        amVar.getClass();
        executor.execute(bb.a(amVar));
    }

    public final void k_() {
        Executor executor = na.f2195a;
        am amVar = this.d;
        amVar.getClass();
        executor.execute(bc.a(amVar));
    }

    public void o() {
        ab.b("pause must be called on the main UI thread.");
        if (!(this.e.j == null || this.e.j.b == null || !this.e.c())) {
            aw.g();
            jm.a(this.e.j.b);
        }
        if (!(this.e.j == null || this.e.j.p == null)) {
            try {
                this.e.j.p.d();
            } catch (RemoteException unused) {
                iy.b("Could not pause mediation adapter.");
            }
        }
        this.g.b(this.e.j);
        this.d.b();
    }

    public void p() {
        ab.b("resume must be called on the main UI thread.");
        pu puVar = (this.e.j == null || this.e.j.b == null) ? null : this.e.j.b;
        if (puVar != null && this.e.c()) {
            aw.g();
            jm.b(this.e.j.b);
        }
        if (!(this.e.j == null || this.e.j.p == null)) {
            try {
                this.e.j.p.e();
            } catch (RemoteException unused) {
                iy.b("Could not resume mediation adapter.");
            }
        }
        if (puVar == null || !puVar.D()) {
            this.d.c();
        }
        this.g.c(this.e.j);
    }

    public void r_() {
        this.j = false;
        u();
        Cif ifVar = this.e.l;
        synchronized (ifVar.c) {
            if (ifVar.j != -1 && !ifVar.b.isEmpty()) {
                ig last = ifVar.b.getLast();
                if (last.b == -1) {
                    last.b = SystemClock.elapsedRealtime();
                    ifVar.f2107a.a(ifVar);
                }
            }
        }
    }

    public final String s_() {
        if (this.e.j == null) {
            return null;
        }
        return c(this.e.j);
    }
}
