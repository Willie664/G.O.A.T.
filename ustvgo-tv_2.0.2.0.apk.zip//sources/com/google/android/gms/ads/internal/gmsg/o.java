package com.google.android.gms.ads.internal.gmsg;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.aw;
import com.google.android.gms.internal.ads.agb;
import com.google.android.gms.internal.ads.agc;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.axl;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.hx;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.le;
import com.google.android.gms.internal.ads.ot;
import com.google.android.gms.internal.ads.pa;
import com.google.android.gms.internal.ads.pb;
import com.google.android.gms.internal.ads.pu;
import com.google.android.gms.internal.ads.qq;
import com.google.android.gms.internal.ads.qy;
import com.google.android.gms.internal.ads.ra;
import com.google.android.gms.internal.ads.rb;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@cj
public final class o {

    /* renamed from: a  reason: collision with root package name */
    public static final ae<pu> f1265a = p.f1266a;
    public static final ae<pu> b = q.f1267a;
    public static final ae<pu> c = r.f1268a;
    public static final ae<pu> d = new w();
    public static final ae<pu> e = new x();
    public static final ae<pu> f = s.f1269a;
    public static final ae<Object> g = new y();
    public static final ae<pu> h = new z();
    public static final ae<pu> i = t.f1270a;
    public static final ae<pu> j = new aa();
    public static final ae<pu> k = new ab();
    public static final ae<ot> l = new pa();
    public static final ae<ot> m = new pb();
    public static final ae<pu> n = new n();
    public static final g o = new g();
    public static final ae<pu> p = new ac();
    public static final ae<pu> q = new ad();
    public static final ae<pu> r = new v();
    private static final ae<Object> s = new u();

    static final /* synthetic */ void a(axl axl, Map map) {
        String str = (String) map.get("u");
        if (str == null) {
            iy.b("URL missing from click GMSG.");
            return;
        }
        Uri parse = Uri.parse(str);
        try {
            agb y = ((qy) axl).y();
            if (y != null && y.a(parse)) {
                parse = y.a(parse, ((qq) axl).getContext(), ((rb) axl).getView(), ((qq) axl).d());
            }
        } catch (agc unused) {
            String valueOf = String.valueOf(str);
            iy.b(valueOf.length() != 0 ? "Unable to append parameter to URL: ".concat(valueOf) : new String("Unable to append parameter to URL: "));
        }
        qq qqVar = (qq) axl;
        Context context = qqVar.getContext();
        if ((((Boolean) ans.f().a(aqs.as)).booleanValue() && aw.B().a(context)) && TextUtils.isEmpty(parse.getQueryParameter("fbs_aeid"))) {
            String i2 = aw.B().i(context);
            parse = hx.a(parse.toString(), "fbs_aeid", i2);
            aw.B().c(context, i2);
        }
        new le(qqVar.getContext(), ((ra) axl).k().f2393a, parse.toString()).h();
    }

    static final /* synthetic */ void a(qq qqVar, Map map) {
        String str = (String) map.get("u");
        if (str == null) {
            iy.b("URL missing from httpTrack GMSG.");
        } else {
            new le(qqVar.getContext(), ((ra) qqVar).k().f2393a, str).h();
        }
    }

    static final /* synthetic */ void a(qy qyVar, Map map) {
        String str = (String) map.get("tx");
        String str2 = (String) map.get("ty");
        String str3 = (String) map.get("td");
        try {
            int parseInt = Integer.parseInt(str);
            int parseInt2 = Integer.parseInt(str2);
            int parseInt3 = Integer.parseInt(str3);
            agb y = qyVar.y();
            if (y != null) {
                y.b.a(parseInt, parseInt2, parseInt3);
            }
        } catch (NumberFormatException unused) {
            iy.b("Could not parse touch parameters from gmsg.");
        }
    }

    static final /* synthetic */ void b(qq qqVar, Map map) {
        JSONException jSONException;
        String str;
        PackageManager packageManager = qqVar.getContext().getPackageManager();
        try {
            try {
                JSONArray jSONArray = new JSONObject((String) map.get("data")).getJSONArray("intents");
                JSONObject jSONObject = new JSONObject();
                for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                    try {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                        String optString = jSONObject2.optString("id");
                        String optString2 = jSONObject2.optString("u");
                        String optString3 = jSONObject2.optString("i");
                        String optString4 = jSONObject2.optString("m");
                        String optString5 = jSONObject2.optString("p");
                        String optString6 = jSONObject2.optString("c");
                        jSONObject2.optString("f");
                        jSONObject2.optString("e");
                        String optString7 = jSONObject2.optString("intent_url");
                        Intent intent = null;
                        if (!TextUtils.isEmpty(optString7)) {
                            try {
                                intent = Intent.parseUri(optString7, 0);
                            } catch (URISyntaxException e2) {
                                URISyntaxException uRISyntaxException = e2;
                                String valueOf = String.valueOf(optString7);
                                iy.a(valueOf.length() != 0 ? "Error parsing the url: ".concat(valueOf) : new String("Error parsing the url: "), uRISyntaxException);
                            }
                        }
                        boolean z = true;
                        if (intent == null) {
                            intent = new Intent();
                            if (!TextUtils.isEmpty(optString2)) {
                                intent.setData(Uri.parse(optString2));
                            }
                            if (!TextUtils.isEmpty(optString3)) {
                                intent.setAction(optString3);
                            }
                            if (!TextUtils.isEmpty(optString4)) {
                                intent.setType(optString4);
                            }
                            if (!TextUtils.isEmpty(optString5)) {
                                intent.setPackage(optString5);
                            }
                            if (!TextUtils.isEmpty(optString6)) {
                                String[] split = optString6.split("/", 2);
                                if (split.length == 2) {
                                    intent.setComponent(new ComponentName(split[0], split[1]));
                                }
                            }
                        }
                        if (packageManager.resolveActivity(intent, 65536) == null) {
                            z = false;
                        }
                        try {
                            jSONObject.put(optString, z);
                        } catch (JSONException e3) {
                            jSONException = e3;
                            str = "Error constructing openable urls response.";
                        }
                    } catch (JSONException e4) {
                        jSONException = e4;
                        str = "Error parsing the intent data.";
                        iy.a(str, jSONException);
                    }
                }
                ((axl) qqVar).a("openableIntents", jSONObject);
            } catch (JSONException unused) {
                ((axl) qqVar).a("openableIntents", new JSONObject());
            }
        } catch (JSONException unused2) {
            ((axl) qqVar).a("openableIntents", new JSONObject());
        }
    }

    static final /* synthetic */ void c(qq qqVar, Map map) {
        String str = (String) map.get("urls");
        if (TextUtils.isEmpty(str)) {
            iy.b("URLs missing in canOpenURLs GMSG.");
            return;
        }
        String[] split = str.split(",");
        HashMap hashMap = new HashMap();
        PackageManager packageManager = qqVar.getContext().getPackageManager();
        for (String str2 : split) {
            String[] split2 = str2.split(";", 2);
            boolean z = true;
            if (packageManager.resolveActivity(new Intent(split2.length > 1 ? split2[1].trim() : "android.intent.action.VIEW", Uri.parse(split2[0].trim())), 65536) == null) {
                z = false;
            }
            hashMap.put(str2, Boolean.valueOf(z));
        }
        ((axl) qqVar).a("openableURLs", (Map<String, ?>) hashMap);
    }
}
