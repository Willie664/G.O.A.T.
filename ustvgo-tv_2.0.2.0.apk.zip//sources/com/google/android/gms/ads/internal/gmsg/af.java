package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.axl;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.ma;
import java.util.Map;
import org.json.JSONObject;

final class af implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ axl f1254a;
    private final /* synthetic */ Map b;
    private final /* synthetic */ HttpClient c;

    af(HttpClient httpClient, Map map, axl axl) {
        this.c = httpClient;
        this.b = map;
        this.f1254a = axl;
    }

    public final void run() {
        ma.a(3);
        try {
            JSONObject send = this.c.send(new JSONObject((String) this.b.get("http_request")));
            if (send == null) {
                iy.a("Response should not be null.");
            } else {
                jh.f2130a.post(new ag(this, send));
            }
        } catch (Exception e) {
            iy.a("Error converting request to json.", e);
        }
    }
}
