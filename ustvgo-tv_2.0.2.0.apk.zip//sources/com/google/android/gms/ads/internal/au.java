package com.google.android.gms.ads.internal;

import android.os.AsyncTask;
import com.google.android.gms.internal.ads.agb;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.ma;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

final class au extends AsyncTask<Void, Void, String> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ aq f1220a;

    private au(aq aqVar) {
        this.f1220a = aqVar;
    }

    /* synthetic */ au(aq aqVar, byte b) {
        this(aqVar);
    }

    private final String a() {
        try {
            agb unused = this.f1220a.h = (agb) this.f1220a.c.get(((Long) ans.f().a(aqs.cz)).longValue(), TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            ma.b("", e);
        }
        return this.f1220a.c();
    }

    /* access modifiers changed from: protected */
    public final /* synthetic */ Object doInBackground(Object[] objArr) {
        return a();
    }

    /* access modifiers changed from: protected */
    public final /* synthetic */ void onPostExecute(Object obj) {
        String str = (String) obj;
        if (this.f1220a.f != null && str != null) {
            this.f1220a.f.loadUrl(str);
        }
    }
}
