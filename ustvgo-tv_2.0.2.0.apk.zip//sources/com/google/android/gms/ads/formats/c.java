package com.google.android.gms.ads.formats;

import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.b.a;
import com.google.android.gms.internal.ads.atp;
import com.google.android.gms.internal.ads.ma;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static WeakHashMap<View, c> f1199a = new WeakHashMap<>();
    private atp b;
    private WeakReference<View> c;

    private final void a(a aVar) {
        View view = this.c != null ? (View) this.c.get() : null;
        if (view == null) {
            ma.b("NativeAdViewHolder.setNativeAd containerView doesn't exist, returning");
            return;
        }
        if (!f1199a.containsKey(view)) {
            f1199a.put(view, this);
        }
        if (this.b != null) {
            try {
                this.b.a(aVar);
            } catch (RemoteException e) {
                ma.a("Unable to call setNativeAd on delegate", e);
            }
        }
    }

    public final void a(a aVar) {
        a((a) aVar.a());
    }

    public final void a(g gVar) {
        a((a) gVar.k());
    }
}
