package com.google.android.gms.ads.internal;

import android.content.Context;
import android.os.RemoteException;
import android.support.v4.f.m;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.ans;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aoc;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.aqs;
import com.google.android.gms.internal.ads.aug;
import com.google.android.gms.internal.ads.auj;
import com.google.android.gms.internal.ads.aun;
import com.google.android.gms.internal.ads.auq;
import com.google.android.gms.internal.ads.aut;
import com.google.android.gms.internal.ads.auv;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.jh;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjj;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzpl;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.ParametersAreNonnullByDefault;

@cj
@ParametersAreNonnullByDefault
public final class i extends aoc {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1272a;
    private final any b;
    private final bav c;
    private final aug d;
    private final auv e;
    private final auj f;
    private final aut g;
    private final zzjn h;
    private final PublisherAdViewOptions i;
    private final m<String, auq> j;
    private final m<String, aun> k;
    private final zzpl l;
    private final List<String> m;
    private final aoy n;
    private final String o;
    private final zzang p;
    private WeakReference<ba> q;
    private final bt r;
    /* access modifiers changed from: private */
    public final Object s = new Object();

    i(Context context, String str, bav bav, zzang zzang, any any, aug aug, auv auv, auj auj, m<String, auq> mVar, m<String, aun> mVar2, zzpl zzpl, aoy aoy, bt btVar, aut aut, zzjn zzjn, PublisherAdViewOptions publisherAdViewOptions) {
        this.f1272a = context;
        this.o = str;
        this.c = bav;
        this.p = zzang;
        this.b = any;
        this.f = auj;
        this.d = aug;
        this.e = auv;
        this.j = mVar;
        this.k = mVar2;
        this.l = zzpl;
        this.m = f();
        this.n = aoy;
        this.r = btVar;
        this.g = aut;
        this.h = zzjn;
        this.i = publisherAdViewOptions;
        aqs.a(this.f1272a);
    }

    static /* synthetic */ void a(i iVar, zzjj zzjj) {
        if (((Boolean) ans.f().a(aqs.cl)).booleanValue() || iVar.e == null) {
            bn bnVar = new bn(iVar.f1272a, iVar.r, iVar.h, iVar.o, iVar.c, iVar.p);
            iVar.q = new WeakReference<>(bnVar);
            aut aut = iVar.g;
            ab.b("setOnPublisherAdViewLoadedListener must be called on the main UI thread.");
            bnVar.e.z = aut;
            if (iVar.i != null) {
                if (iVar.i.b != null) {
                    bnVar.a(iVar.i.b);
                }
                bnVar.b(iVar.i.f1195a);
            }
            aug aug = iVar.d;
            ab.b("setOnAppInstallAdLoadedListener must be called on the main UI thread.");
            bnVar.e.r = aug;
            auv auv = iVar.e;
            ab.b("setOnUnifiedNativeAdLoadedListener must be called on the main UI thread.");
            bnVar.e.t = auv;
            auj auj = iVar.f;
            ab.b("setOnContentAdLoadedListener must be called on the main UI thread.");
            bnVar.e.s = auj;
            m<String, auq> mVar = iVar.j;
            ab.b("setOnCustomTemplateAdLoadedListeners must be called on the main UI thread.");
            bnVar.e.v = mVar;
            m<String, aun> mVar2 = iVar.k;
            ab.b("setOnCustomClickListener must be called on the main UI thread.");
            bnVar.e.u = mVar2;
            zzpl zzpl = iVar.l;
            ab.b("setNativeAdOptions must be called on the main UI thread.");
            bnVar.e.w = zzpl;
            bnVar.c(iVar.f());
            bnVar.a(iVar.b);
            bnVar.a(iVar.n);
            ArrayList arrayList = new ArrayList();
            if (iVar.e()) {
                arrayList.add(1);
            }
            if (iVar.g != null) {
                arrayList.add(2);
            }
            bnVar.d(arrayList);
            if (iVar.e()) {
                zzjj.c.putBoolean("ina", true);
            }
            if (iVar.g != null) {
                zzjj.c.putBoolean("iba", true);
            }
            bnVar.b(zzjj);
            return;
        }
        iVar.d();
    }

    static /* synthetic */ void a(i iVar, zzjj zzjj, int i2) {
        if (((Boolean) ans.f().a(aqs.cl)).booleanValue() || iVar.e == null) {
            ad adVar = new ad(iVar.f1272a, iVar.r, zzjn.a(), iVar.o, iVar.c, iVar.p);
            iVar.q = new WeakReference<>(adVar);
            aug aug = iVar.d;
            ab.b("setOnAppInstallAdLoadedListener must be called on the main UI thread.");
            adVar.e.r = aug;
            auv auv = iVar.e;
            ab.b("setOnUnifiedNativeAdLoadedListener must be called on the main UI thread.");
            adVar.e.t = auv;
            auj auj = iVar.f;
            ab.b("setOnContentAdLoadedListener must be called on the main UI thread.");
            adVar.e.s = auj;
            m<String, auq> mVar = iVar.j;
            ab.b("setOnCustomTemplateAdLoadedListeners must be called on the main UI thread.");
            adVar.e.v = mVar;
            adVar.a(iVar.b);
            m<String, aun> mVar2 = iVar.k;
            ab.b("setOnCustomClickListener must be called on the main UI thread.");
            adVar.e.u = mVar2;
            adVar.c(iVar.f());
            zzpl zzpl = iVar.l;
            ab.b("setNativeAdOptions must be called on the main UI thread.");
            adVar.e.w = zzpl;
            adVar.a(iVar.n);
            ab.b("setMaxNumberOfAds must be called on the main UI thread.");
            adVar.m = i2;
            adVar.b(zzjj);
            return;
        }
        iVar.d();
    }

    private static void a(Runnable runnable) {
        jh.f2130a.post(runnable);
    }

    static /* synthetic */ boolean b(i iVar) {
        return ((Boolean) ans.f().a(aqs.aM)).booleanValue() && iVar.g != null;
    }

    private final void d() {
        if (this.b != null) {
            try {
                this.b.a(0);
            } catch (RemoteException e2) {
                iy.b("Failed calling onAdFailedToLoad.", e2);
            }
        }
    }

    private final boolean e() {
        if (this.d == null && this.f == null && this.e == null) {
            return this.j != null && this.j.size() > 0;
        }
        return true;
    }

    private final List<String> f() {
        ArrayList arrayList = new ArrayList();
        if (this.f != null) {
            arrayList.add("1");
        }
        if (this.d != null) {
            arrayList.add("2");
        }
        if (this.e != null) {
            arrayList.add("6");
        }
        if (this.j.size() > 0) {
            arrayList.add("3");
        }
        return arrayList;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0017, code lost:
        return r2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String a() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.s
            monitor-enter(r0)
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            r2 = 0
            if (r1 == 0) goto L_0x0018
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            java.lang.Object r1 = r1.get()     // Catch:{ all -> 0x001a }
            com.google.android.gms.ads.internal.ba r1 = (com.google.android.gms.ads.internal.ba) r1     // Catch:{ all -> 0x001a }
            if (r1 == 0) goto L_0x0016
            java.lang.String r2 = r1.a()     // Catch:{ all -> 0x001a }
        L_0x0016:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x0018:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x001a:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.i.a():java.lang.String");
    }

    public final void a(zzjj zzjj) {
        a((Runnable) new j(this, zzjj));
    }

    public final void a(zzjj zzjj, int i2) {
        if (i2 > 0) {
            a((Runnable) new k(this, zzjj, i2));
            return;
        }
        throw new IllegalArgumentException("Number of ads has to be more than 0");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0017, code lost:
        return r2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String b() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.s
            monitor-enter(r0)
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            r2 = 0
            if (r1 == 0) goto L_0x0018
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            java.lang.Object r1 = r1.get()     // Catch:{ all -> 0x001a }
            com.google.android.gms.ads.internal.ba r1 = (com.google.android.gms.ads.internal.ba) r1     // Catch:{ all -> 0x001a }
            if (r1 == 0) goto L_0x0016
            java.lang.String r2 = r1.s_()     // Catch:{ all -> 0x001a }
        L_0x0016:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x0018:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x001a:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.i.b():java.lang.String");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0017, code lost:
        return r2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean c() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.s
            monitor-enter(r0)
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            r2 = 0
            if (r1 == 0) goto L_0x0018
            java.lang.ref.WeakReference<com.google.android.gms.ads.internal.ba> r1 = r3.q     // Catch:{ all -> 0x001a }
            java.lang.Object r1 = r1.get()     // Catch:{ all -> 0x001a }
            com.google.android.gms.ads.internal.ba r1 = (com.google.android.gms.ads.internal.ba) r1     // Catch:{ all -> 0x001a }
            if (r1 == 0) goto L_0x0016
            boolean r2 = r1.s()     // Catch:{ all -> 0x001a }
        L_0x0016:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x0018:
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            return r2
        L_0x001a:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x001a }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.i.c():boolean");
    }
}
