package com.google.android.gms.ads.mediation;

import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.h;
import com.google.android.gms.internal.ads.cj;

@cj
public class f {

    /* renamed from: a  reason: collision with root package name */
    protected boolean f1306a;
    protected boolean b;
    protected Bundle c = new Bundle();
    protected View d;
    public View e;
    public h f;
    public boolean g;

    public final void a() {
        this.f1306a = true;
    }

    @Deprecated
    public void a(View view) {
    }

    public final void b() {
        this.b = true;
    }

    public final boolean c() {
        return this.f1306a;
    }

    public final boolean d() {
        return this.b;
    }

    public final Bundle e() {
        return this.c;
    }

    public final View f() {
        return this.d;
    }
}
