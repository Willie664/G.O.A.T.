package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.ads.cj;

@cj
public final class zzaq extends AbstractSafeParcelable {
    public static final Parcelable.Creator<zzaq> CREATOR = new r();

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1299a;
    public final boolean b;
    public final boolean c;
    public final float d;
    public final int e;
    public final boolean f;
    public final boolean g;
    public final boolean h;
    private final String i;

    zzaq(boolean z, boolean z2, String str, boolean z3, float f2, int i2, boolean z4, boolean z5, boolean z6) {
        this.f1299a = z;
        this.b = z2;
        this.i = str;
        this.c = z3;
        this.d = f2;
        this.e = i2;
        this.f = z4;
        this.g = z5;
        this.h = z6;
    }

    public zzaq(boolean z, boolean z2, boolean z3, float f2, int i2, boolean z4, boolean z5, boolean z6) {
        this(z, z2, (String) null, z3, f2, i2, z4, z5, z6);
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        int a2 = b.a(parcel, 20293);
        b.a(parcel, 2, this.f1299a);
        b.a(parcel, 3, this.b);
        b.a(parcel, 4, this.i);
        b.a(parcel, 5, this.c);
        b.a(parcel, 6, this.d);
        b.b(parcel, 7, this.e);
        b.a(parcel, 8, this.f);
        b.a(parcel, 9, this.g);
        b.a(parcel, 10, this.h);
        b.b(parcel, a2);
    }
}
