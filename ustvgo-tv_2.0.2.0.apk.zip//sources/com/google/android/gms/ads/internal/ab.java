package com.google.android.gms.ads.internal;

import android.content.Context;
import com.google.android.gms.b.a;
import com.google.android.gms.b.b;
import com.google.android.gms.internal.ads.bae;
import com.google.android.gms.internal.ads.baf;
import com.google.android.gms.internal.ads.bay;
import com.google.android.gms.internal.ads.fp;
import com.google.android.gms.internal.ads.gy;
import com.google.android.gms.internal.ads.gz;
import com.google.android.gms.internal.ads.iy;
import com.google.android.gms.internal.ads.ma;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final /* synthetic */ class ab implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final y f1204a;
    private final Runnable b;

    ab(y yVar, Runnable runnable) {
        this.f1204a = yVar;
        this.b = runnable;
    }

    public final void run() {
        y yVar = this.f1204a;
        Runnable runnable = this.b;
        Context context = yVar.f1297a;
        com.google.android.gms.common.internal.ab.b("Adapters must be initialized on the main thread.");
        Map<String, baf> map = aw.i().f().j().b;
        if (map != null && !map.isEmpty()) {
            if (runnable != null) {
                try {
                    runnable.run();
                } catch (Throwable th) {
                    iy.b("Could not initialize rewarded ads.", th);
                    return;
                }
            }
            fp fpVar = fp.j;
            if (fpVar != null) {
                Collection<baf> values = map.values();
                HashMap hashMap = new HashMap();
                a a2 = b.a(context);
                for (baf baf : values) {
                    for (bae next : baf.f1952a) {
                        String str = next.k;
                        for (String next2 : next.c) {
                            if (!hashMap.containsKey(next2)) {
                                hashMap.put(next2, new ArrayList());
                            }
                            if (str != null) {
                                ((Collection) hashMap.get(next2)).add(str);
                            }
                        }
                    }
                }
                for (Map.Entry entry : hashMap.entrySet()) {
                    String str2 = (String) entry.getKey();
                    try {
                        gy a3 = fpVar.l.a(str2);
                        if (a3 != null) {
                            bay bay = a3.f2088a;
                            if (!bay.g()) {
                                if (bay.m()) {
                                    bay.a(a2, (gz) a3.b, (List<String>) (List) entry.getValue());
                                    String valueOf = String.valueOf(str2);
                                    if (valueOf.length() != 0) {
                                        "Initialized rewarded video mediation adapter ".concat(valueOf);
                                    } else {
                                        new String("Initialized rewarded video mediation adapter ");
                                    }
                                    ma.a(3);
                                }
                            }
                        }
                    } catch (Throwable th2) {
                        StringBuilder sb = new StringBuilder(String.valueOf(str2).length() + 56);
                        sb.append("Failed to initialize rewarded video mediation adapter \"");
                        sb.append(str2);
                        sb.append("\"");
                        iy.b(sb.toString(), th2);
                    }
                }
            }
        }
    }
}
