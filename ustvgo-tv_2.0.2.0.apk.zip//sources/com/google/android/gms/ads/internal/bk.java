package com.google.android.gms.ads.internal;

import android.view.MotionEvent;
import android.view.View;

final class bk implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bu f1235a;
    private final /* synthetic */ bi b;

    bk(bi biVar, bu buVar) {
        this.b = biVar;
        this.f1235a = buVar;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        this.f1235a.f1243a = true;
        if (this.b.b == null) {
            return false;
        }
        this.b.b.c();
        return false;
    }
}
