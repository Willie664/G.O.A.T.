package com.google.android.gms.ads.mediation;

import com.google.android.gms.internal.ads.apg;

public interface l {
    apg getVideoController();
}
