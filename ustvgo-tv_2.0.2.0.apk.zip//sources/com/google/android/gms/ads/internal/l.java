package com.google.android.gms.ads.internal;

import android.content.Context;
import android.support.v4.f.m;
import android.text.TextUtils;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.any;
import com.google.android.gms.internal.ads.aob;
import com.google.android.gms.internal.ads.aof;
import com.google.android.gms.internal.ads.aoy;
import com.google.android.gms.internal.ads.aug;
import com.google.android.gms.internal.ads.auj;
import com.google.android.gms.internal.ads.aun;
import com.google.android.gms.internal.ads.auq;
import com.google.android.gms.internal.ads.aut;
import com.google.android.gms.internal.ads.auv;
import com.google.android.gms.internal.ads.bav;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.zzang;
import com.google.android.gms.internal.ads.zzjn;
import com.google.android.gms.internal.ads.zzpl;

@cj
public final class l extends aof {

    /* renamed from: a  reason: collision with root package name */
    private any f1275a;
    private aug b;
    private auv c;
    private auj d;
    private m<String, aun> e = new m<>();
    private m<String, auq> f = new m<>();
    private aut g;
    private zzjn h;
    private PublisherAdViewOptions i;
    private zzpl j;
    private aoy k;
    private final Context l;
    private final bav m;
    private final String n;
    private final zzang o;
    private final bt p;

    public l(Context context, String str, bav bav, zzang zzang, bt btVar) {
        this.l = context;
        this.n = str;
        this.m = bav;
        this.o = zzang;
        this.p = btVar;
    }

    public final aob a() {
        return new i(this.l, this.n, this.m, this.o, this.f1275a, this.b, this.c, this.d, this.f, this.e, this.j, this.k, this.p, this.g, this.h, this.i);
    }

    public final void a(PublisherAdViewOptions publisherAdViewOptions) {
        this.i = publisherAdViewOptions;
    }

    public final void a(any any) {
        this.f1275a = any;
    }

    public final void a(aoy aoy) {
        this.k = aoy;
    }

    public final void a(aug aug) {
        this.b = aug;
    }

    public final void a(auj auj) {
        this.d = auj;
    }

    public final void a(aut aut, zzjn zzjn) {
        this.g = aut;
        this.h = zzjn;
    }

    public final void a(auv auv) {
        this.c = auv;
    }

    public final void a(zzpl zzpl) {
        this.j = zzpl;
    }

    public final void a(String str, auq auq, aun aun) {
        if (!TextUtils.isEmpty(str)) {
            this.f.put(str, auq);
            this.e.put(str, aun);
            return;
        }
        throw new IllegalArgumentException("Custom template ID for native custom template ad is empty. Please provide a valid template id.");
    }
}
