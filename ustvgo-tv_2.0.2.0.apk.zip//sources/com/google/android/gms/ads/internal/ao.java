package com.google.android.gms.ads.internal;

import android.os.Handler;

public final class ao {

    /* renamed from: a  reason: collision with root package name */
    private final Handler f1215a;

    public ao(Handler handler) {
        this.f1215a = handler;
    }

    public final void a(Runnable runnable) {
        this.f1215a.removeCallbacks(runnable);
    }

    public final boolean a(Runnable runnable, long j) {
        return this.f1215a.postDelayed(runnable, j);
    }
}
