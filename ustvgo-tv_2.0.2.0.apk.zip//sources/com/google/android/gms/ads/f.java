package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.aps;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final aps f1193a;

    public f(Context context) {
        this.f1193a = new aps(context);
        ab.a(context, (Object) "Context cannot be null");
    }

    public final void a(c cVar) {
        this.f1193a.a(cVar.f1188a);
    }

    public final void a(String str) {
        this.f1193a.a(str);
    }

    public final void a(boolean z) {
        this.f1193a.a(z);
    }
}
