package com.google.android.gms.ads.internal.gmsg;

import javax.annotation.Nullable;
import org.json.JSONObject;

public interface h {
    void a(@Nullable String str);

    void a(JSONObject jSONObject);
}
