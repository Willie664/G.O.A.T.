package com.google.android.gms.ads.internal;

import android.view.MotionEvent;
import android.view.View;

final class as implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ aq f1218a;

    as(aq aqVar) {
        this.f1218a = aqVar;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        if (this.f1218a.h == null) {
            return false;
        }
        this.f1218a.h.a(motionEvent);
        return false;
    }
}
