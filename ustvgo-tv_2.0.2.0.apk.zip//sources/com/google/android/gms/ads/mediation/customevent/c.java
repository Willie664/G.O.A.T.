package com.google.android.gms.ads.mediation.customevent;

import com.google.ads.mediation.f;
import java.util.HashMap;

@Deprecated
public final class c implements f {

    /* renamed from: a  reason: collision with root package name */
    private final HashMap<String, Object> f1305a = new HashMap<>();

    public final Object a(String str) {
        return this.f1305a.get(str);
    }
}
