package com.google.android.gms.ads.internal.overlay;

final class e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ c f1281a;

    e(c cVar) {
        this.f1281a = cVar;
    }

    public final void run() {
        this.f1281a.n();
    }
}
