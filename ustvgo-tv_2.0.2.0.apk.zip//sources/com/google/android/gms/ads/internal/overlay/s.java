package com.google.android.gms.ads.internal.overlay;

public interface s {
    void h();
}
