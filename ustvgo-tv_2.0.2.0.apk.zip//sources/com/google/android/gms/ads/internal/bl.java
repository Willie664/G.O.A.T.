package com.google.android.gms.ads.internal;

import android.view.View;

final class bl implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ bu f1236a;
    private final /* synthetic */ bi b;

    bl(bi biVar, bu buVar) {
        this.b = biVar;
        this.f1236a = buVar;
    }

    public final void onClick(View view) {
        this.f1236a.f1243a = true;
        if (this.b.b != null) {
            this.b.b.c();
        }
    }
}
