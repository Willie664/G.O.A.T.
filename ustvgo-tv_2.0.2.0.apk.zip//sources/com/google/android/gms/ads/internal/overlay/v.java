package com.google.android.gms.ads.internal.overlay;

public interface v {
    void c();
}
