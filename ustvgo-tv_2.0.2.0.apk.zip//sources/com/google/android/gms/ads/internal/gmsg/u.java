package com.google.android.gms.ads.internal.gmsg;

import java.util.Map;

final class u implements ae<Object> {
    u() {
    }

    public final void zza(Object obj, Map<String, String> map) {
    }
}
