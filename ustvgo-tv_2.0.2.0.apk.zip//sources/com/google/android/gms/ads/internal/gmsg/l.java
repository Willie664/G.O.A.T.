package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.iy;
import java.util.Map;

@cj
public final class l implements ae<Object> {

    /* renamed from: a  reason: collision with root package name */
    private final m f1264a;

    public l(m mVar) {
        this.f1264a = mVar;
    }

    public final void zza(Object obj, Map<String, String> map) {
        String str = map.get("name");
        if (str == null) {
            iy.b("App event with no name parameter.");
        } else {
            this.f1264a.a(str, map.get("info"));
        }
    }
}
