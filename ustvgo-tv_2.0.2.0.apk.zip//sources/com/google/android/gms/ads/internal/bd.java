package com.google.android.gms.ads.internal;

import java.util.concurrent.Callable;

final class bd implements Callable<String> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ba f1229a;

    bd(ba baVar) {
        this.f1229a = baVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0014, code lost:
        r1 = com.google.android.gms.ads.internal.aw.g().c(r3.f1229a.e.c);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ java.lang.Object call() {
        /*
            r3 = this;
            java.lang.String r0 = ""
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r1 = com.google.android.gms.internal.ads.aqs.cC
            com.google.android.gms.internal.ads.aqq r2 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r1 = r2.a(r1)
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            if (r1 == 0) goto L_0x002a
            com.google.android.gms.internal.ads.jm r1 = com.google.android.gms.ads.internal.aw.g()
            com.google.android.gms.ads.internal.ba r2 = r3.f1229a
            com.google.android.gms.ads.internal.ax r2 = r2.e
            android.content.Context r2 = r2.c
            android.webkit.CookieManager r1 = r1.c((android.content.Context) r2)
            if (r1 == 0) goto L_0x002a
            java.lang.String r0 = "googleads.g.doubleclick.net"
            java.lang.String r0 = r1.getCookie(r0)
        L_0x002a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.bd.call():java.lang.Object");
    }
}
