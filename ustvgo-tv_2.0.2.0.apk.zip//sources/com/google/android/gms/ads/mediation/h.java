package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.formats.a;
import java.util.List;

public class h extends f {
    public String h;
    public List<a.b> i;
    public String j;
    public a.b k;
    public String l;
    public String m;
}
