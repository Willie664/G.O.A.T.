package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.ase;
import com.google.android.gms.internal.ads.iy;

final class ai implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ ase f1209a;
    private final /* synthetic */ ad b;

    ai(ad adVar, ase ase) {
        this.b = adVar;
        this.f1209a = ase;
    }

    public final void run() {
        try {
            if (this.b.e.t != null) {
                this.b.e.t.a(this.f1209a);
                this.b.a(this.f1209a.n());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
