package com.google.android.gms.ads.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.ads.arx;
import com.google.android.gms.internal.ads.iy;

final class ah implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ arx f1208a;
    private final /* synthetic */ ad b;

    ah(ad adVar, arx arx) {
        this.b = adVar;
        this.f1208a = arx;
    }

    public final void run() {
        try {
            if (this.b.e.r != null) {
                this.b.e.r.a(this.f1208a);
                this.b.a(this.f1208a.j());
            }
        } catch (RemoteException e) {
            iy.c("#007 Could not call remote method.", e);
        }
    }
}
