package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.internal.ads.qy;
import java.util.Map;

final /* synthetic */ class t implements ae {

    /* renamed from: a  reason: collision with root package name */
    static final ae f1270a = new t();

    private t() {
    }

    public final void zza(Object obj, Map map) {
        o.a((qy) obj, map);
    }
}
