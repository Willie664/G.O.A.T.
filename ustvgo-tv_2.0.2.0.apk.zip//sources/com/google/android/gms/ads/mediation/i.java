package com.google.android.gms.ads.mediation;

import com.google.android.gms.ads.formats.b;
import java.util.Map;

public interface i extends a {
    b h();

    boolean i();

    boolean j();

    boolean k();

    boolean l();

    Map<String, Boolean> m();
}
