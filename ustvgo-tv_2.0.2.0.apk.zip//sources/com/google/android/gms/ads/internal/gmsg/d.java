package com.google.android.gms.ads.internal.gmsg;

import com.google.android.gms.ads.internal.bu;
import com.google.android.gms.common.util.f;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.n;
import com.google.android.gms.internal.ads.pu;
import java.util.Collections;
import java.util.Map;

@cj
public final class d implements ae<pu> {
    private static final Map<String, Integer> d;

    /* renamed from: a  reason: collision with root package name */
    private final bu f1259a;
    private final com.google.android.gms.internal.ads.d b;
    private final n c;

    static {
        String[] strArr = {"resize", "playVideo", "storePicture", "createCalendarEvent", "setOrientationProperties", "closeResizedAd", "unload"};
        Integer[] numArr = {1, 2, 3, 4, 5, 6, 7};
        Map a2 = f.a(7);
        for (int i = 0; i < 7; i++) {
            a2.put(strArr[i], numArr[i]);
        }
        d = Collections.unmodifiableMap(a2);
    }

    public d(bu buVar, com.google.android.gms.internal.ads.d dVar, n nVar) {
        this.f1259a = buVar;
        this.b = dVar;
        this.c = nVar;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:201:0x0442, code lost:
        r9.addRule(11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:0x0449, code lost:
        r9.addRule(14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:205:0x0450, code lost:
        r9.addRule(9);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:209:0x0462, code lost:
        r14.l.setOnClickListener(new com.google.android.gms.internal.ads.e(r14));
        r14.l.setContentDescription("Close button");
        r14.o.addView(r14.l, r9);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:211:?, code lost:
        r1 = r14.n;
        r15 = r15.getDecorView();
        com.google.android.gms.internal.ads.ans.a();
        r2 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r14.i, r6[0]);
        com.google.android.gms.internal.ads.ans.a();
        r1.showAtLocation(r15, 0, r2, com.google.android.gms.internal.ads.lp.a((android.content.Context) r14.i, r6[1]));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:214:0x049b, code lost:
        if (r14.m == null) goto L_0x04a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:215:0x049d, code lost:
        r14.m.N();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:216:0x04a2, code lost:
        r14.h.a(com.google.android.gms.internal.ads.ri.a(r7, r8));
        r14.a(r6[0], r6[1]);
        r14.b("resized");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:218:0x04b8, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:219:0x04b9, code lost:
        r15 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:220:0x04ba, code lost:
        r15 = java.lang.String.valueOf(r15.getMessage());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:221:0x04c8, code lost:
        if (r15.length() != 0) goto L_0x04ca;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:222:0x04ca, code lost:
        r15 = "Cannot show popup window: ".concat(r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:223:0x04cf, code lost:
        r15 = new java.lang.String("Cannot show popup window: ");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:224:0x04d4, code lost:
        r14.a(r15);
        r14.o.removeView(r14.h.getView());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:225:0x04e4, code lost:
        if (r14.p != null) goto L_0x04e6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:226:0x04e6, code lost:
        r14.p.removeView(r14.k);
        r14.p.addView(r14.h.getView());
        r14.h.a(r14.j);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:228:0x0500, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ void zza(java.lang.Object r14, java.util.Map r15) {
        /*
            r13 = this;
            com.google.android.gms.internal.ads.pu r14 = (com.google.android.gms.internal.ads.pu) r14
            java.lang.String r0 = "a"
            java.lang.Object r0 = r15.get(r0)
            java.lang.String r0 = (java.lang.String) r0
            java.util.Map<java.lang.String, java.lang.Integer> r1 = d
            java.lang.Object r0 = r1.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            r1 = 5
            if (r0 == r1) goto L_0x002f
            r2 = 7
            if (r0 == r2) goto L_0x002f
            com.google.android.gms.ads.internal.bu r2 = r13.f1259a
            if (r2 == 0) goto L_0x002f
            com.google.android.gms.ads.internal.bu r2 = r13.f1259a
            boolean r2 = r2.a()
            if (r2 != 0) goto L_0x002f
            com.google.android.gms.ads.internal.bu r14 = r13.f1259a
            r15 = 0
            r14.a(r15)
            return
        L_0x002f:
            r2 = 4
            r3 = -1
            r4 = 1
            if (r0 == r4) goto L_0x0201
            switch(r0) {
                case 3: goto L_0x0120;
                case 4: goto L_0x00a1;
                case 5: goto L_0x0059;
                case 6: goto L_0x0053;
                case 7: goto L_0x003b;
                default: goto L_0x0037;
            }
        L_0x0037:
            com.google.android.gms.internal.ads.ma.a((int) r2)
            goto L_0x0052
        L_0x003b:
            com.google.android.gms.internal.ads.aqi<java.lang.Boolean> r14 = com.google.android.gms.internal.ads.aqs.M
            com.google.android.gms.internal.ads.aqq r15 = com.google.android.gms.internal.ads.ans.f()
            java.lang.Object r14 = r15.a(r14)
            java.lang.Boolean r14 = (java.lang.Boolean) r14
            boolean r14 = r14.booleanValue()
            if (r14 == 0) goto L_0x0052
            com.google.android.gms.internal.ads.n r14 = r13.c
            r14.L()
        L_0x0052:
            return
        L_0x0053:
            com.google.android.gms.internal.ads.d r14 = r13.b
            r14.a(r4)
            return
        L_0x0059:
            com.google.android.gms.internal.ads.f r0 = new com.google.android.gms.internal.ads.f
            r0.<init>(r14, r15)
            com.google.android.gms.internal.ads.pu r14 = r0.f2062a
            if (r14 != 0) goto L_0x0068
            java.lang.String r14 = "AdWebView is null"
            com.google.android.gms.internal.ads.iy.b(r14)
            return
        L_0x0068:
            java.lang.String r14 = "portrait"
            java.lang.String r15 = r0.c
            boolean r14 = r14.equalsIgnoreCase(r15)
            if (r14 == 0) goto L_0x007b
            com.google.android.gms.internal.ads.jm r14 = com.google.android.gms.ads.internal.aw.g()
            int r3 = r14.b()
            goto L_0x009b
        L_0x007b:
            java.lang.String r14 = "landscape"
            java.lang.String r15 = r0.c
            boolean r14 = r14.equalsIgnoreCase(r15)
            if (r14 == 0) goto L_0x008e
            com.google.android.gms.internal.ads.jm r14 = com.google.android.gms.ads.internal.aw.g()
            int r3 = r14.a()
            goto L_0x009b
        L_0x008e:
            boolean r14 = r0.b
            if (r14 == 0) goto L_0x0093
            goto L_0x009b
        L_0x0093:
            com.google.android.gms.internal.ads.jm r14 = com.google.android.gms.ads.internal.aw.g()
            int r3 = r14.c()
        L_0x009b:
            com.google.android.gms.internal.ads.pu r14 = r0.f2062a
            r14.setRequestedOrientation(r3)
            return
        L_0x00a1:
            com.google.android.gms.internal.ads.bcx r0 = new com.google.android.gms.internal.ads.bcx
            r0.<init>(r14, r15)
            android.content.Context r14 = r0.f1986a
            if (r14 != 0) goto L_0x00b0
            java.lang.String r14 = "Activity context is not available."
            r0.a(r14)
            return
        L_0x00b0:
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r14 = r0.f1986a
            com.google.android.gms.internal.ads.aqd r14 = com.google.android.gms.internal.ads.jh.e((android.content.Context) r14)
            boolean r14 = r14.b()
            if (r14 != 0) goto L_0x00c5
            java.lang.String r14 = "This feature is not available on the device."
            r0.a(r14)
            return
        L_0x00c5:
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r14 = r0.f1986a
            android.app.AlertDialog$Builder r14 = com.google.android.gms.internal.ads.jh.d((android.content.Context) r14)
            com.google.android.gms.internal.ads.ii r15 = com.google.android.gms.ads.internal.aw.i()
            android.content.res.Resources r15 = r15.c()
            if (r15 == 0) goto L_0x00df
            int r1 = com.google.android.gms.ads.a.a.C0059a.s5
            java.lang.String r1 = r15.getString(r1)
            goto L_0x00e1
        L_0x00df:
            java.lang.String r1 = "Create calendar event"
        L_0x00e1:
            r14.setTitle(r1)
            if (r15 == 0) goto L_0x00ed
            int r1 = com.google.android.gms.ads.a.a.C0059a.s6
            java.lang.String r1 = r15.getString(r1)
            goto L_0x00ef
        L_0x00ed:
            java.lang.String r1 = "Allow Ad to create a calendar event?"
        L_0x00ef:
            r14.setMessage(r1)
            if (r15 == 0) goto L_0x00fb
            int r1 = com.google.android.gms.ads.a.a.C0059a.s3
            java.lang.String r1 = r15.getString(r1)
            goto L_0x00fd
        L_0x00fb:
            java.lang.String r1 = "Accept"
        L_0x00fd:
            com.google.android.gms.internal.ads.bcy r2 = new com.google.android.gms.internal.ads.bcy
            r2.<init>(r0)
            r14.setPositiveButton(r1, r2)
            if (r15 == 0) goto L_0x010e
            int r1 = com.google.android.gms.ads.a.a.C0059a.s4
            java.lang.String r15 = r15.getString(r1)
            goto L_0x0110
        L_0x010e:
            java.lang.String r15 = "Decline"
        L_0x0110:
            com.google.android.gms.internal.ads.c r1 = new com.google.android.gms.internal.ads.c
            r1.<init>(r0)
            r14.setNegativeButton(r15, r1)
            android.app.AlertDialog r14 = r14.create()
            r14.show()
            return
        L_0x0120:
            com.google.android.gms.internal.ads.g r0 = new com.google.android.gms.internal.ads.g
            r0.<init>(r14, r15)
            android.content.Context r14 = r0.b
            if (r14 != 0) goto L_0x012f
            java.lang.String r14 = "Activity context is not available"
            r0.a(r14)
            return
        L_0x012f:
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r14 = r0.b
            com.google.android.gms.internal.ads.aqd r14 = com.google.android.gms.internal.ads.jh.e((android.content.Context) r14)
            boolean r14 = r14.a()
            if (r14 != 0) goto L_0x0144
            java.lang.String r14 = "Feature is not supported by the device."
            r0.a(r14)
            return
        L_0x0144:
            java.util.Map<java.lang.String, java.lang.String> r14 = r0.f2076a
            java.lang.String r15 = "iurl"
            java.lang.Object r14 = r14.get(r15)
            java.lang.String r14 = (java.lang.String) r14
            boolean r15 = android.text.TextUtils.isEmpty(r14)
            if (r15 == 0) goto L_0x015a
            java.lang.String r14 = "Image url cannot be empty."
            r0.a(r14)
            return
        L_0x015a:
            boolean r15 = android.webkit.URLUtil.isValidUrl(r14)
            if (r15 != 0) goto L_0x017a
            java.lang.String r15 = "Invalid image url: "
            java.lang.String r14 = java.lang.String.valueOf(r14)
            int r1 = r14.length()
            if (r1 == 0) goto L_0x0171
            java.lang.String r14 = r15.concat(r14)
            goto L_0x0176
        L_0x0171:
            java.lang.String r14 = new java.lang.String
            r14.<init>(r15)
        L_0x0176:
            r0.a(r14)
            return
        L_0x017a:
            android.net.Uri r15 = android.net.Uri.parse(r14)
            java.lang.String r15 = r15.getLastPathSegment()
            com.google.android.gms.ads.internal.aw.e()
            boolean r1 = com.google.android.gms.internal.ads.jh.c((java.lang.String) r15)
            if (r1 != 0) goto L_0x01a6
            java.lang.String r14 = "Image type not recognized: "
            java.lang.String r15 = java.lang.String.valueOf(r15)
            int r1 = r15.length()
            if (r1 == 0) goto L_0x019c
            java.lang.String r14 = r14.concat(r15)
            goto L_0x01a2
        L_0x019c:
            java.lang.String r15 = new java.lang.String
            r15.<init>(r14)
            r14 = r15
        L_0x01a2:
            r0.a(r14)
            return
        L_0x01a6:
            com.google.android.gms.internal.ads.ii r1 = com.google.android.gms.ads.internal.aw.i()
            android.content.res.Resources r1 = r1.c()
            com.google.android.gms.ads.internal.aw.e()
            android.content.Context r2 = r0.b
            android.app.AlertDialog$Builder r2 = com.google.android.gms.internal.ads.jh.d((android.content.Context) r2)
            if (r1 == 0) goto L_0x01c0
            int r3 = com.google.android.gms.ads.a.a.C0059a.s1
            java.lang.String r3 = r1.getString(r3)
            goto L_0x01c2
        L_0x01c0:
            java.lang.String r3 = "Save image"
        L_0x01c2:
            r2.setTitle(r3)
            if (r1 == 0) goto L_0x01ce
            int r3 = com.google.android.gms.ads.a.a.C0059a.s2
            java.lang.String r3 = r1.getString(r3)
            goto L_0x01d0
        L_0x01ce:
            java.lang.String r3 = "Allow Ad to store image in Picture gallery?"
        L_0x01d0:
            r2.setMessage(r3)
            if (r1 == 0) goto L_0x01dc
            int r3 = com.google.android.gms.ads.a.a.C0059a.s3
            java.lang.String r3 = r1.getString(r3)
            goto L_0x01de
        L_0x01dc:
            java.lang.String r3 = "Accept"
        L_0x01de:
            com.google.android.gms.internal.ads.h r4 = new com.google.android.gms.internal.ads.h
            r4.<init>(r0, r14, r15)
            r2.setPositiveButton(r3, r4)
            if (r1 == 0) goto L_0x01ef
            int r14 = com.google.android.gms.ads.a.a.C0059a.s4
            java.lang.String r14 = r1.getString(r14)
            goto L_0x01f1
        L_0x01ef:
            java.lang.String r14 = "Decline"
        L_0x01f1:
            com.google.android.gms.internal.ads.i r15 = new com.google.android.gms.internal.ads.i
            r15.<init>(r0)
            r2.setNegativeButton(r14, r15)
            android.app.AlertDialog r14 = r2.create()
            r14.show()
            return
        L_0x0201:
            com.google.android.gms.internal.ads.d r14 = r13.b
            java.lang.Object r0 = r14.g
            monitor-enter(r0)
            android.app.Activity r5 = r14.i     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x0211
            java.lang.String r15 = "Not an activity context. Cannot resize."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0211:
            com.google.android.gms.internal.ads.pu r5 = r14.h     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ri r5 = r5.t()     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x0220
            java.lang.String r15 = "Webview is not yet available, size is not set."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0220:
            com.google.android.gms.internal.ads.pu r5 = r14.h     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ri r5 = r5.t()     // Catch:{ all -> 0x050f }
            boolean r5 = r5.c()     // Catch:{ all -> 0x050f }
            if (r5 == 0) goto L_0x0233
            java.lang.String r15 = "Is interstitial. Cannot resize an interstitial."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0233:
            com.google.android.gms.internal.ads.pu r5 = r14.h     // Catch:{ all -> 0x050f }
            boolean r5 = r5.z()     // Catch:{ all -> 0x050f }
            if (r5 == 0) goto L_0x0242
            java.lang.String r15 = "Cannot resize an expanded banner."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0242:
            java.lang.String r5 = "width"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x0261
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            java.lang.String r5 = "width"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r5 = (java.lang.String) r5     // Catch:{ all -> 0x050f }
            int r5 = com.google.android.gms.internal.ads.jh.b((java.lang.String) r5)     // Catch:{ all -> 0x050f }
            r14.f = r5     // Catch:{ all -> 0x050f }
        L_0x0261:
            java.lang.String r5 = "height"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x0280
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            java.lang.String r5 = "height"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r5 = (java.lang.String) r5     // Catch:{ all -> 0x050f }
            int r5 = com.google.android.gms.internal.ads.jh.b((java.lang.String) r5)     // Catch:{ all -> 0x050f }
            r14.c = r5     // Catch:{ all -> 0x050f }
        L_0x0280:
            java.lang.String r5 = "offsetX"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x029f
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            java.lang.String r5 = "offsetX"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r5 = (java.lang.String) r5     // Catch:{ all -> 0x050f }
            int r5 = com.google.android.gms.internal.ads.jh.b((java.lang.String) r5)     // Catch:{ all -> 0x050f }
            r14.d = r5     // Catch:{ all -> 0x050f }
        L_0x029f:
            java.lang.String r5 = "offsetY"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x02be
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            java.lang.String r5 = "offsetY"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r5 = (java.lang.String) r5     // Catch:{ all -> 0x050f }
            int r5 = com.google.android.gms.internal.ads.jh.b((java.lang.String) r5)     // Catch:{ all -> 0x050f }
            r14.e = r5     // Catch:{ all -> 0x050f }
        L_0x02be:
            java.lang.String r5 = "allowOffscreen"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r5)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x02da
            java.lang.String r5 = "allowOffscreen"
            java.lang.Object r5 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r5 = (java.lang.String) r5     // Catch:{ all -> 0x050f }
            boolean r5 = java.lang.Boolean.parseBoolean(r5)     // Catch:{ all -> 0x050f }
            r14.b = r5     // Catch:{ all -> 0x050f }
        L_0x02da:
            java.lang.String r5 = "customClosePosition"
            java.lang.Object r15 = r15.get(r5)     // Catch:{ all -> 0x050f }
            java.lang.String r15 = (java.lang.String) r15     // Catch:{ all -> 0x050f }
            boolean r5 = android.text.TextUtils.isEmpty(r15)     // Catch:{ all -> 0x050f }
            if (r5 != 0) goto L_0x02ea
            r14.f2027a = r15     // Catch:{ all -> 0x050f }
        L_0x02ea:
            int r15 = r14.f     // Catch:{ all -> 0x050f }
            r5 = 0
            if (r15 < 0) goto L_0x02f5
            int r15 = r14.c     // Catch:{ all -> 0x050f }
            if (r15 < 0) goto L_0x02f5
            r15 = 1
            goto L_0x02f6
        L_0x02f5:
            r15 = 0
        L_0x02f6:
            if (r15 != 0) goto L_0x02ff
            java.lang.String r15 = "Invalid width and height options. Cannot resize."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x02ff:
            android.app.Activity r15 = r14.i     // Catch:{ all -> 0x050f }
            android.view.Window r15 = r15.getWindow()     // Catch:{ all -> 0x050f }
            if (r15 == 0) goto L_0x0508
            android.view.View r6 = r15.getDecorView()     // Catch:{ all -> 0x050f }
            if (r6 != 0) goto L_0x030f
            goto L_0x0508
        L_0x030f:
            int[] r6 = r14.a()     // Catch:{ all -> 0x050f }
            if (r6 != 0) goto L_0x031c
            java.lang.String r15 = "Resize location out of screen or close button is not visible."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x031c:
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ all -> 0x050f }
            android.app.Activity r7 = r14.i     // Catch:{ all -> 0x050f }
            int r8 = r14.f     // Catch:{ all -> 0x050f }
            int r7 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r7, (int) r8)     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ all -> 0x050f }
            android.app.Activity r8 = r14.i     // Catch:{ all -> 0x050f }
            int r9 = r14.c     // Catch:{ all -> 0x050f }
            int r8 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r8, (int) r9)     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r9 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r9 = r9.getView()     // Catch:{ all -> 0x050f }
            android.view.ViewParent r9 = r9.getParent()     // Catch:{ all -> 0x050f }
            if (r9 == 0) goto L_0x0501
            boolean r10 = r9 instanceof android.view.ViewGroup     // Catch:{ all -> 0x050f }
            if (r10 == 0) goto L_0x0501
            r10 = r9
            android.view.ViewGroup r10 = (android.view.ViewGroup) r10     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r11 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r11 = r11.getView()     // Catch:{ all -> 0x050f }
            r10.removeView(r11)     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r10 = r14.n     // Catch:{ all -> 0x050f }
            if (r10 != 0) goto L_0x0381
            android.view.ViewGroup r9 = (android.view.ViewGroup) r9     // Catch:{ all -> 0x050f }
            r14.p = r9     // Catch:{ all -> 0x050f }
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r9 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r9 = r9.getView()     // Catch:{ all -> 0x050f }
            android.graphics.Bitmap r9 = com.google.android.gms.internal.ads.jh.a((android.view.View) r9)     // Catch:{ all -> 0x050f }
            android.widget.ImageView r10 = new android.widget.ImageView     // Catch:{ all -> 0x050f }
            android.app.Activity r11 = r14.i     // Catch:{ all -> 0x050f }
            r10.<init>(r11)     // Catch:{ all -> 0x050f }
            r14.k = r10     // Catch:{ all -> 0x050f }
            android.widget.ImageView r10 = r14.k     // Catch:{ all -> 0x050f }
            r10.setImageBitmap(r9)     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r9 = r14.h     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ri r9 = r9.t()     // Catch:{ all -> 0x050f }
            r14.j = r9     // Catch:{ all -> 0x050f }
            android.view.ViewGroup r9 = r14.p     // Catch:{ all -> 0x050f }
            android.widget.ImageView r10 = r14.k     // Catch:{ all -> 0x050f }
            r9.addView(r10)     // Catch:{ all -> 0x050f }
            goto L_0x0386
        L_0x0381:
            android.widget.PopupWindow r9 = r14.n     // Catch:{ all -> 0x050f }
            r9.dismiss()     // Catch:{ all -> 0x050f }
        L_0x0386:
            android.widget.RelativeLayout r9 = new android.widget.RelativeLayout     // Catch:{ all -> 0x050f }
            android.app.Activity r10 = r14.i     // Catch:{ all -> 0x050f }
            r9.<init>(r10)     // Catch:{ all -> 0x050f }
            r14.o = r9     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r9 = r14.o     // Catch:{ all -> 0x050f }
            r9.setBackgroundColor(r5)     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r9 = r14.o     // Catch:{ all -> 0x050f }
            android.view.ViewGroup$LayoutParams r10 = new android.view.ViewGroup$LayoutParams     // Catch:{ all -> 0x050f }
            r10.<init>(r7, r8)     // Catch:{ all -> 0x050f }
            r9.setLayoutParams(r10)     // Catch:{ all -> 0x050f }
            com.google.android.gms.ads.internal.aw.e()     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r9 = r14.o     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r9 = com.google.android.gms.internal.ads.jh.a((android.view.View) r9, (int) r7, (int) r8)     // Catch:{ all -> 0x050f }
            r14.n = r9     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r9 = r14.n     // Catch:{ all -> 0x050f }
            r9.setOutsideTouchable(r4)     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r9 = r14.n     // Catch:{ all -> 0x050f }
            r9.setTouchable(r4)     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r9 = r14.n     // Catch:{ all -> 0x050f }
            boolean r10 = r14.b     // Catch:{ all -> 0x050f }
            r10 = r10 ^ r4
            r9.setClippingEnabled(r10)     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r9 = r14.o     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r10 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r10 = r10.getView()     // Catch:{ all -> 0x050f }
            r9.addView(r10, r3, r3)     // Catch:{ all -> 0x050f }
            android.widget.LinearLayout r9 = new android.widget.LinearLayout     // Catch:{ all -> 0x050f }
            android.app.Activity r10 = r14.i     // Catch:{ all -> 0x050f }
            r9.<init>(r10)     // Catch:{ all -> 0x050f }
            r14.l = r9     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout$LayoutParams r9 = new android.widget.RelativeLayout$LayoutParams     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ all -> 0x050f }
            android.app.Activity r10 = r14.i     // Catch:{ all -> 0x050f }
            r11 = 50
            int r10 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r10, (int) r11)     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ all -> 0x050f }
            android.app.Activity r12 = r14.i     // Catch:{ all -> 0x050f }
            int r11 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r12, (int) r11)     // Catch:{ all -> 0x050f }
            r9.<init>(r10, r11)     // Catch:{ all -> 0x050f }
            java.lang.String r10 = r14.f2027a     // Catch:{ all -> 0x050f }
            int r11 = r10.hashCode()     // Catch:{ all -> 0x050f }
            switch(r11) {
                case -1364013995: goto L_0x0423;
                case -1012429441: goto L_0x0419;
                case -655373719: goto L_0x040f;
                case 1163912186: goto L_0x0406;
                case 1288627767: goto L_0x03fc;
                case 1755462605: goto L_0x03f2;
                default: goto L_0x03f1;
            }     // Catch:{ all -> 0x050f }
        L_0x03f1:
            goto L_0x042d
        L_0x03f2:
            java.lang.String r1 = "top-center"
            boolean r1 = r10.equals(r1)     // Catch:{ all -> 0x050f }
            if (r1 == 0) goto L_0x042d
            r1 = 1
            goto L_0x042e
        L_0x03fc:
            java.lang.String r1 = "bottom-center"
            boolean r1 = r10.equals(r1)     // Catch:{ all -> 0x050f }
            if (r1 == 0) goto L_0x042d
            r1 = 4
            goto L_0x042e
        L_0x0406:
            java.lang.String r2 = "bottom-right"
            boolean r2 = r10.equals(r2)     // Catch:{ all -> 0x050f }
            if (r2 == 0) goto L_0x042d
            goto L_0x042e
        L_0x040f:
            java.lang.String r1 = "bottom-left"
            boolean r1 = r10.equals(r1)     // Catch:{ all -> 0x050f }
            if (r1 == 0) goto L_0x042d
            r1 = 3
            goto L_0x042e
        L_0x0419:
            java.lang.String r1 = "top-left"
            boolean r1 = r10.equals(r1)     // Catch:{ all -> 0x050f }
            if (r1 == 0) goto L_0x042d
            r1 = 0
            goto L_0x042e
        L_0x0423:
            java.lang.String r1 = "center"
            boolean r1 = r10.equals(r1)     // Catch:{ all -> 0x050f }
            if (r1 == 0) goto L_0x042d
            r1 = 2
            goto L_0x042e
        L_0x042d:
            r1 = -1
        L_0x042e:
            r2 = 14
            r3 = 9
            r10 = 11
            r11 = 12
            r12 = 10
            switch(r1) {
                case 0: goto L_0x045e;
                case 1: goto L_0x045a;
                case 2: goto L_0x0454;
                case 3: goto L_0x044d;
                case 4: goto L_0x0446;
                case 5: goto L_0x043f;
                default: goto L_0x043b;
            }     // Catch:{ all -> 0x050f }
        L_0x043b:
            r9.addRule(r12)     // Catch:{ all -> 0x050f }
            goto L_0x0442
        L_0x043f:
            r9.addRule(r11)     // Catch:{ all -> 0x050f }
        L_0x0442:
            r9.addRule(r10)     // Catch:{ all -> 0x050f }
            goto L_0x0462
        L_0x0446:
            r9.addRule(r11)     // Catch:{ all -> 0x050f }
        L_0x0449:
            r9.addRule(r2)     // Catch:{ all -> 0x050f }
            goto L_0x0462
        L_0x044d:
            r9.addRule(r11)     // Catch:{ all -> 0x050f }
        L_0x0450:
            r9.addRule(r3)     // Catch:{ all -> 0x050f }
            goto L_0x0462
        L_0x0454:
            r1 = 13
            r9.addRule(r1)     // Catch:{ all -> 0x050f }
            goto L_0x0462
        L_0x045a:
            r9.addRule(r12)     // Catch:{ all -> 0x050f }
            goto L_0x0449
        L_0x045e:
            r9.addRule(r12)     // Catch:{ all -> 0x050f }
            goto L_0x0450
        L_0x0462:
            android.widget.LinearLayout r1 = r14.l     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.e r2 = new com.google.android.gms.internal.ads.e     // Catch:{ all -> 0x050f }
            r2.<init>(r14)     // Catch:{ all -> 0x050f }
            r1.setOnClickListener(r2)     // Catch:{ all -> 0x050f }
            android.widget.LinearLayout r1 = r14.l     // Catch:{ all -> 0x050f }
            java.lang.String r2 = "Close button"
            r1.setContentDescription(r2)     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r1 = r14.o     // Catch:{ all -> 0x050f }
            android.widget.LinearLayout r2 = r14.l     // Catch:{ all -> 0x050f }
            r1.addView(r2, r9)     // Catch:{ all -> 0x050f }
            android.widget.PopupWindow r1 = r14.n     // Catch:{ RuntimeException -> 0x04b9 }
            android.view.View r15 = r15.getDecorView()     // Catch:{ RuntimeException -> 0x04b9 }
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ RuntimeException -> 0x04b9 }
            android.app.Activity r2 = r14.i     // Catch:{ RuntimeException -> 0x04b9 }
            r3 = r6[r5]     // Catch:{ RuntimeException -> 0x04b9 }
            int r2 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r2, (int) r3)     // Catch:{ RuntimeException -> 0x04b9 }
            com.google.android.gms.internal.ads.ans.a()     // Catch:{ RuntimeException -> 0x04b9 }
            android.app.Activity r3 = r14.i     // Catch:{ RuntimeException -> 0x04b9 }
            r9 = r6[r4]     // Catch:{ RuntimeException -> 0x04b9 }
            int r3 = com.google.android.gms.internal.ads.lp.a((android.content.Context) r3, (int) r9)     // Catch:{ RuntimeException -> 0x04b9 }
            r1.showAtLocation(r15, r5, r2, r3)     // Catch:{ RuntimeException -> 0x04b9 }
            com.google.android.gms.internal.ads.n r15 = r14.m     // Catch:{ all -> 0x050f }
            if (r15 == 0) goto L_0x04a2
            com.google.android.gms.internal.ads.n r15 = r14.m     // Catch:{ all -> 0x050f }
            r15.N()     // Catch:{ all -> 0x050f }
        L_0x04a2:
            com.google.android.gms.internal.ads.pu r15 = r14.h     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ri r1 = com.google.android.gms.internal.ads.ri.a(r7, r8)     // Catch:{ all -> 0x050f }
            r15.a((com.google.android.gms.internal.ads.ri) r1)     // Catch:{ all -> 0x050f }
            r15 = r6[r5]     // Catch:{ all -> 0x050f }
            r1 = r6[r4]     // Catch:{ all -> 0x050f }
            r14.a(r15, r1)     // Catch:{ all -> 0x050f }
            java.lang.String r15 = "resized"
            r14.b(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x04b9:
            r15 = move-exception
            java.lang.String r1 = "Cannot show popup window: "
            java.lang.String r15 = r15.getMessage()     // Catch:{ all -> 0x050f }
            java.lang.String r15 = java.lang.String.valueOf(r15)     // Catch:{ all -> 0x050f }
            int r2 = r15.length()     // Catch:{ all -> 0x050f }
            if (r2 == 0) goto L_0x04cf
            java.lang.String r15 = r1.concat(r15)     // Catch:{ all -> 0x050f }
            goto L_0x04d4
        L_0x04cf:
            java.lang.String r15 = new java.lang.String     // Catch:{ all -> 0x050f }
            r15.<init>(r1)     // Catch:{ all -> 0x050f }
        L_0x04d4:
            r14.a(r15)     // Catch:{ all -> 0x050f }
            android.widget.RelativeLayout r15 = r14.o     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r1 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r1 = r1.getView()     // Catch:{ all -> 0x050f }
            r15.removeView(r1)     // Catch:{ all -> 0x050f }
            android.view.ViewGroup r15 = r14.p     // Catch:{ all -> 0x050f }
            if (r15 == 0) goto L_0x04ff
            android.view.ViewGroup r15 = r14.p     // Catch:{ all -> 0x050f }
            android.widget.ImageView r1 = r14.k     // Catch:{ all -> 0x050f }
            r15.removeView(r1)     // Catch:{ all -> 0x050f }
            android.view.ViewGroup r15 = r14.p     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r1 = r14.h     // Catch:{ all -> 0x050f }
            android.view.View r1 = r1.getView()     // Catch:{ all -> 0x050f }
            r15.addView(r1)     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.pu r15 = r14.h     // Catch:{ all -> 0x050f }
            com.google.android.gms.internal.ads.ri r14 = r14.j     // Catch:{ all -> 0x050f }
            r15.a((com.google.android.gms.internal.ads.ri) r14)     // Catch:{ all -> 0x050f }
        L_0x04ff:
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0501:
            java.lang.String r15 = "Webview is detached, probably in the middle of a resize or expand."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x0508:
            java.lang.String r15 = "Activity context is not ready, cannot get window or decor view."
            r14.a(r15)     // Catch:{ all -> 0x050f }
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            return
        L_0x050f:
            r14 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x050f }
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.ads.internal.gmsg.d.zza(java.lang.Object, java.util.Map):void");
    }
}
