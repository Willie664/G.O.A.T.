package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.gmsg.ae;
import com.google.android.gms.internal.ads.pu;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

final class v implements ae<pu> {

    /* renamed from: a  reason: collision with root package name */
    private final /* synthetic */ CountDownLatch f1294a;

    v(CountDownLatch countDownLatch) {
        this.f1294a = countDownLatch;
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        this.f1294a.countDown();
        ((pu) obj).getView().setVisibility(0);
    }
}
