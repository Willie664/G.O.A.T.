package com.google.android.gms.ads;

import android.os.RemoteException;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.internal.ads.apg;
import com.google.android.gms.internal.ads.apj;
import com.google.android.gms.internal.ads.aqb;
import com.google.android.gms.internal.ads.cj;
import com.google.android.gms.internal.ads.ma;
import javax.annotation.concurrent.GuardedBy;

@cj
public final class h {

    /* renamed from: a  reason: collision with root package name */
    private final Object f1200a = new Object();
    @GuardedBy("mLock")
    private apg b;
    @GuardedBy("mLock")
    private a c;

    public static abstract class a {
    }

    public final apg a() {
        apg apg;
        synchronized (this.f1200a) {
            apg = this.b;
        }
        return apg;
    }

    public final void a(apg apg) {
        synchronized (this.f1200a) {
            this.b = apg;
            if (this.c != null) {
                a aVar = this.c;
                ab.a(aVar, (Object) "VideoLifecycleCallbacks may not be null.");
                synchronized (this.f1200a) {
                    this.c = aVar;
                    if (this.b != null) {
                        try {
                            this.b.a((apj) new aqb(aVar));
                        } catch (RemoteException e) {
                            ma.a("Unable to call setVideoLifecycleCallbacks on video controller.", e);
                        }
                    }
                }
            }
        }
    }
}
