package com.onesignal;

import java.lang.Thread;
import org.json.JSONObject;

final class ao {

    static abstract class a {
        a() {
        }

        /* access modifiers changed from: package-private */
        public void a(int i, String str, Throwable th) {
        }

        /* access modifiers changed from: package-private */
        public void a(String str) {
        }
    }

    private static Thread a(final a aVar, final int i, final Throwable th) {
        if (aVar == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable() {
            final /* synthetic */ String c = null;

            public final void run() {
                aVar.a(i, this.c, th);
            }
        });
        thread.start();
        return thread;
    }

    private static Thread a(final a aVar, final String str) {
        if (aVar == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable() {
            public final void run() {
                aVar.a(str);
            }
        });
        thread.start();
        return thread;
    }

    /* access modifiers changed from: package-private */
    public static void a(String str, String str2, JSONObject jSONObject, a aVar, int i, String str3) {
        if (str2 == null || !ai.a((String) null)) {
            Thread[] threadArr = new Thread[1];
            final Thread[] threadArr2 = threadArr;
            final String str4 = str;
            final String str5 = str2;
            final JSONObject jSONObject2 = jSONObject;
            final a aVar2 = aVar;
            final int i2 = i;
            final String str6 = str3;
            Thread thread = new Thread(new Runnable() {
                public final void run() {
                    threadArr2[0] = ao.b(str4, str5, jSONObject2, aVar2, i2, str6);
                }
            }, "OS_HTTPConnection");
            thread.start();
            try {
                thread.join((long) (i + 5000));
                if (thread.getState() != Thread.State.TERMINATED) {
                    thread.interrupt();
                }
                if (threadArr[0] != null) {
                    threadArr[0].join();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void a(final String str, final JSONObject jSONObject, final a aVar) {
        new Thread(new Runnable() {
            public final void run() {
                ao.a(str, "POST", jSONObject, aVar, 120000, (String) null);
            }
        }).start();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:56:0x020e, code lost:
        r5 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x0210, code lost:
        r5 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0211, code lost:
        r0 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x021e, code lost:
        if ((r5 instanceof java.net.UnknownHostException) != false) goto L_0x0220;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x0221, code lost:
        r9 = com.onesignal.ai.h.WARN;
        com.onesignal.ai.a(r9, "OneSignalRestClient: " + r6 + " Error thrown from network stack. ", r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x025b, code lost:
        r0.disconnect();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0261, code lost:
        r2.disconnect();
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0207  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x020e A[ExcHandler: all (th java.lang.Throwable), Splitter:B:4:0x0027] */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x021c A[Catch:{ all -> 0x0213 }] */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x025b  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0261  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static java.lang.Thread b(java.lang.String r5, java.lang.String r6, org.json.JSONObject r7, com.onesignal.ao.a r8, int r9, java.lang.String r10) {
        /*
            r0 = 0
            r1 = -1
            com.onesignal.ai$h r2 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x0216 }
            java.lang.String r3 = "OneSignalRestClient: Making request to: https://onesignal.com/api/v1/"
            java.lang.String r4 = java.lang.String.valueOf(r5)     // Catch:{ Throwable -> 0x0216 }
            java.lang.String r3 = r3.concat(r4)     // Catch:{ Throwable -> 0x0216 }
            com.onesignal.ai.a((com.onesignal.ai.h) r2, (java.lang.String) r3)     // Catch:{ Throwable -> 0x0216 }
            java.net.URL r2 = new java.net.URL     // Catch:{ Throwable -> 0x0216 }
            java.lang.String r3 = "https://onesignal.com/api/v1/"
            java.lang.String r4 = java.lang.String.valueOf(r5)     // Catch:{ Throwable -> 0x0216 }
            java.lang.String r3 = r3.concat(r4)     // Catch:{ Throwable -> 0x0216 }
            r2.<init>(r3)     // Catch:{ Throwable -> 0x0216 }
            java.net.URLConnection r2 = r2.openConnection()     // Catch:{ Throwable -> 0x0216 }
            java.net.HttpURLConnection r2 = (java.net.HttpURLConnection) r2     // Catch:{ Throwable -> 0x0216 }
            r3 = 0
            r2.setUseCaches(r3)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r2.setConnectTimeout(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r2.setReadTimeout(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r9 = "SDK-Version"
            java.lang.String r3 = "onesignal/android/031008"
            r2.setRequestProperty(r9, r3)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r9 = 1
            if (r7 == 0) goto L_0x003d
            r2.setDoInput(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
        L_0x003d:
            if (r6 == 0) goto L_0x004c
            java.lang.String r3 = "Content-Type"
            java.lang.String r4 = "application/json; charset=UTF-8"
            r2.setRequestProperty(r3, r4)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r2.setRequestMethod(r6)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r2.setDoOutput(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
        L_0x004c:
            if (r7 == 0) goto L_0x007e
            java.lang.String r7 = r7.toString()     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r4 = "OneSignalRestClient: "
            r3.<init>(r4)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r3.append(r6)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r4 = " SEND JSON: "
            r3.append(r4)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r3.append(r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r3 = r3.toString()     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r3)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r9 = "UTF-8"
            byte[] r7 = r7.getBytes(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            int r9 = r7.length     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r2.setFixedLengthStreamingMode(r9)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.io.OutputStream r9 = r2.getOutputStream()     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            r9.write(r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
        L_0x007e:
            if (r10 == 0) goto L_0x00a6
            java.lang.String r7 = com.onesignal.am.f2741a     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r9 = "PREFS_OS_ETAG_PREFIX_"
            java.lang.String r3 = java.lang.String.valueOf(r10)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r9 = r9.concat(r3)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r7 = com.onesignal.am.b((java.lang.String) r7, (java.lang.String) r9, (java.lang.String) r0)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            if (r7 == 0) goto L_0x00a6
            java.lang.String r9 = "if-none-match"
            r2.setRequestProperty(r9, r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r3 = "OneSignalRestClient: Adding header if-none-match: "
            java.lang.String r7 = java.lang.String.valueOf(r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            java.lang.String r7 = r3.concat(r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r7)     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
        L_0x00a6:
            int r7 = r2.getResponseCode()     // Catch:{ Throwable -> 0x0210, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.VERBOSE     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = "OneSignalRestClient: After con.getResponseCode to: https://onesignal.com/api/v1/"
            java.lang.String r3 = java.lang.String.valueOf(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = r1.concat(r3)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r9 = 200(0xc8, float:2.8E-43)
            if (r7 == r9) goto L_0x0172
            r9 = 304(0x130, float:4.26E-43)
            if (r7 == r9) goto L_0x013b
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = "OneSignalRestClient: Failed request to: https://onesignal.com/api/v1/"
            java.lang.String r5 = java.lang.String.valueOf(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = r10.concat(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.io.InputStream r5 = r2.getErrorStream()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r5 != 0) goto L_0x00da
            java.io.InputStream r5 = r2.getInputStream()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
        L_0x00da:
            if (r5 == 0) goto L_0x0115
            java.util.Scanner r9 = new java.util.Scanner     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = "UTF-8"
            r9.<init>(r5, r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = "\\A"
            java.util.Scanner r5 = r9.useDelimiter(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            boolean r5 = r5.hasNext()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r5 == 0) goto L_0x00f4
            java.lang.String r5 = r9.next()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x00f6
        L_0x00f4:
            java.lang.String r5 = ""
        L_0x00f6:
            r9.close()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.WARN     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = "OneSignalRestClient: "
            r10.<init>(r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r10.append(r6)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = " RECEIVED JSON: "
            r10.append(r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r10.append(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = r10.toString()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x0135
        L_0x0115:
            com.onesignal.ai$h r5 = com.onesignal.ai.h.WARN     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = "OneSignalRestClient: "
            r9.<init>(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r9.append(r6)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = " HTTP Code: "
            r9.append(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r9.append(r7)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = " No response body!"
            r9.append(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r9 = r9.toString()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r5, (java.lang.String) r9)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
        L_0x0135:
            java.lang.Thread r5 = a((com.onesignal.ao.a) r8, (int) r7, (java.lang.Throwable) r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x0205
        L_0x013b:
            java.lang.String r5 = com.onesignal.am.f2741a     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r9 = "PREFS_OS_HTTP_CACHE_PREFIX_"
            java.lang.String r10 = java.lang.String.valueOf(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r9 = r9.concat(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = com.onesignal.am.b((java.lang.String) r5, (java.lang.String) r9, (java.lang.String) r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = "OneSignalRestClient: "
            r10.<init>(r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r6 != 0) goto L_0x0159
            java.lang.String r0 = "GET"
            goto L_0x015a
        L_0x0159:
            r0 = r6
        L_0x015a:
            r10.append(r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = " - Using Cached response due to 304: "
            r10.append(r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r10.append(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = r10.toString()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
        L_0x016c:
            java.lang.Thread r5 = a(r8, r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x0205
        L_0x0172:
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = "OneSignalRestClient: Successfully finished request to: https://onesignal.com/api/v1/"
            java.lang.String r5 = java.lang.String.valueOf(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = r0.concat(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.io.InputStream r5 = r2.getInputStream()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.util.Scanner r9 = new java.util.Scanner     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = "UTF-8"
            r9.<init>(r5, r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r5 = "\\A"
            java.util.Scanner r5 = r9.useDelimiter(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            boolean r5 = r5.hasNext()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r5 == 0) goto L_0x019d
            java.lang.String r5 = r9.next()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x019f
        L_0x019d:
            java.lang.String r5 = ""
        L_0x019f:
            r9.close()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai$h r9 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = "OneSignalRestClient: "
            r0.<init>(r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r6 != 0) goto L_0x01b0
            java.lang.String r1 = "GET"
            goto L_0x01b1
        L_0x01b0:
            r1 = r6
        L_0x01b1:
            r0.append(r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = " RECEIVED JSON: "
            r0.append(r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r0.append(r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = r0.toString()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r0)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r10 == 0) goto L_0x016c
            java.lang.String r9 = "etag"
            java.lang.String r9 = r2.getHeaderField(r9)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            if (r9 == 0) goto L_0x016c
            com.onesignal.ai$h r0 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r3 = "OneSignalRestClient: Response has etag of "
            r1.<init>(r3)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            r1.append(r9)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r3 = " so caching the response."
            r1.append(r3)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = r1.toString()     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r1)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = com.onesignal.am.f2741a     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = "PREFS_OS_ETAG_PREFIX_"
            java.lang.String r3 = java.lang.String.valueOf(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r1 = r1.concat(r3)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.am.a((java.lang.String) r0, (java.lang.String) r1, (java.lang.String) r9)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r9 = com.onesignal.am.f2741a     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r0 = "PREFS_OS_HTTP_CACHE_PREFIX_"
            java.lang.String r10 = java.lang.String.valueOf(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            java.lang.String r10 = r0.concat(r10)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            com.onesignal.am.a((java.lang.String) r9, (java.lang.String) r10, (java.lang.String) r5)     // Catch:{ Throwable -> 0x020b, all -> 0x020e }
            goto L_0x016c
        L_0x0205:
            if (r2 == 0) goto L_0x025e
            r2.disconnect()
            goto L_0x025e
        L_0x020b:
            r5 = move-exception
            r0 = r2
            goto L_0x0218
        L_0x020e:
            r5 = move-exception
            goto L_0x025f
        L_0x0210:
            r5 = move-exception
            r0 = r2
            goto L_0x0217
        L_0x0213:
            r5 = move-exception
            r2 = r0
            goto L_0x025f
        L_0x0216:
            r5 = move-exception
        L_0x0217:
            r7 = -1
        L_0x0218:
            boolean r9 = r5 instanceof java.net.ConnectException     // Catch:{ all -> 0x0213 }
            if (r9 != 0) goto L_0x023a
            boolean r9 = r5 instanceof java.net.UnknownHostException     // Catch:{ all -> 0x0213 }
            if (r9 == 0) goto L_0x0221
            goto L_0x023a
        L_0x0221:
            com.onesignal.ai$h r9 = com.onesignal.ai.h.WARN     // Catch:{ all -> 0x0213 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ all -> 0x0213 }
            java.lang.String r1 = "OneSignalRestClient: "
            r10.<init>(r1)     // Catch:{ all -> 0x0213 }
            r10.append(r6)     // Catch:{ all -> 0x0213 }
            java.lang.String r6 = " Error thrown from network stack. "
            r10.append(r6)     // Catch:{ all -> 0x0213 }
            java.lang.String r6 = r10.toString()     // Catch:{ all -> 0x0213 }
            com.onesignal.ai.a((com.onesignal.ai.h) r9, (java.lang.String) r6, (java.lang.Throwable) r5)     // Catch:{ all -> 0x0213 }
            goto L_0x0255
        L_0x023a:
            com.onesignal.ai$h r6 = com.onesignal.ai.h.INFO     // Catch:{ all -> 0x0213 }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ all -> 0x0213 }
            java.lang.String r10 = "OneSignalRestClient: Could not send last request, device is offline. Throwable: "
            r9.<init>(r10)     // Catch:{ all -> 0x0213 }
            java.lang.Class r10 = r5.getClass()     // Catch:{ all -> 0x0213 }
            java.lang.String r10 = r10.getName()     // Catch:{ all -> 0x0213 }
            r9.append(r10)     // Catch:{ all -> 0x0213 }
            java.lang.String r9 = r9.toString()     // Catch:{ all -> 0x0213 }
            com.onesignal.ai.a((com.onesignal.ai.h) r6, (java.lang.String) r9)     // Catch:{ all -> 0x0213 }
        L_0x0255:
            java.lang.Thread r5 = a((com.onesignal.ao.a) r8, (int) r7, (java.lang.Throwable) r5)     // Catch:{ all -> 0x0213 }
            if (r0 == 0) goto L_0x025e
            r0.disconnect()
        L_0x025e:
            return r5
        L_0x025f:
            if (r2 == 0) goto L_0x0264
            r2.disconnect()
        L_0x0264:
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ao.b(java.lang.String, java.lang.String, org.json.JSONObject, com.onesignal.ao$a, int, java.lang.String):java.lang.Thread");
    }

    public static void b(String str, JSONObject jSONObject, a aVar) {
        a(str, "PUT", jSONObject, aVar, 120000, (String) null);
    }

    public static void c(String str, JSONObject jSONObject, a aVar) {
        a(str, "POST", jSONObject, aVar, 120000, (String) null);
    }
}
