package com.onesignal;

import android.content.Context;
import org.json.JSONObject;

public final class ae implements Cloneable {

    /* renamed from: a  reason: collision with root package name */
    ad<Object, ae> f2720a = new ad<>("changed", false);
    boolean b;

    ae() {
        a();
    }

    private void a(boolean z) {
        boolean z2 = this.b != z;
        this.b = z;
        if (z2) {
            this.f2720a.b(this);
        }
    }

    /* access modifiers changed from: package-private */
    public final void a() {
        Context context = ai.b;
        a(ah.e());
    }

    public final JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("enabled", this.b);
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return jSONObject;
    }

    /* access modifiers changed from: protected */
    public final Object clone() {
        try {
            return super.clone();
        } catch (Throwable unused) {
            return null;
        }
    }

    public final String toString() {
        return b().toString();
    }
}
