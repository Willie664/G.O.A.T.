package com.onesignal;

import android.content.Context;
import com.onesignal.ai;

final class k {

    /* renamed from: a  reason: collision with root package name */
    public Context f2787a;
    public String b;
    public String c;
    public ai.i d;
    public ai.j e;

    k(Context context, String str, String str2, ai.i iVar, ai.j jVar) {
        this.f2787a = context;
        this.b = str;
        this.c = str2;
        this.d = iVar;
        this.e = jVar;
    }
}
