package com.onesignal;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import com.onesignal.NotificationExtenderService;
import com.onesignal.ac;
import com.onesignal.ai;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class q {

    static class a {

        /* renamed from: a  reason: collision with root package name */
        boolean f2802a;
        boolean b;
        boolean c;

        a() {
        }

        /* access modifiers changed from: package-private */
        public final boolean a() {
            return !this.f2802a || this.b || this.c;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:53:0x00c8  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00ca  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00de  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x00e8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static int a(com.onesignal.s r13) {
        /*
            boolean r0 = com.onesignal.ai.o()
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x0010
            boolean r0 = com.onesignal.ai.q()
            if (r0 == 0) goto L_0x0010
            r0 = 1
            goto L_0x0011
        L_0x0010:
            r0 = 0
        L_0x0011:
            r13.d = r0
            boolean r0 = r13.c
            if (r0 != 0) goto L_0x00be
            org.json.JSONObject r0 = r13.b
            java.lang.String r3 = "collapse_key"
            boolean r0 = r0.has(r3)
            if (r0 == 0) goto L_0x00be
            java.lang.String r0 = "do_not_collapse"
            org.json.JSONObject r3 = r13.b
            java.lang.String r4 = "collapse_key"
            java.lang.String r3 = r3.optString(r4)
            boolean r0 = r0.equals(r3)
            if (r0 == 0) goto L_0x0033
            goto L_0x00be
        L_0x0033:
            org.json.JSONObject r0 = r13.b
            java.lang.String r3 = "collapse_key"
            java.lang.String r0 = r0.optString(r3)
            android.content.Context r3 = r13.f2803a
            com.onesignal.ak r3 = com.onesignal.ak.a(r3)
            r4 = 0
            android.database.sqlite.SQLiteDatabase r5 = r3.b()     // Catch:{ Throwable -> 0x009e }
            java.lang.String r6 = "notification"
            java.lang.String[] r7 = new java.lang.String[r1]     // Catch:{ Throwable -> 0x009e }
            java.lang.String r3 = "android_notification_id"
            r7[r2] = r3     // Catch:{ Throwable -> 0x009e }
            java.lang.String r8 = "collapse_id = ? AND dismissed = 0 AND opened = 0 "
            java.lang.String[] r9 = new java.lang.String[r1]     // Catch:{ Throwable -> 0x009e }
            r9[r2] = r0     // Catch:{ Throwable -> 0x009e }
            r10 = 0
            r11 = 0
            r12 = 0
            android.database.Cursor r0 = r5.query(r6, r7, r8, r9, r10, r11, r12)     // Catch:{ Throwable -> 0x009e }
            boolean r3 = r0.moveToFirst()     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            if (r3 == 0) goto L_0x008a
            java.lang.String r3 = "android_notification_id"
            int r3 = r0.getColumnIndex(r3)     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            int r3 = r0.getInt(r3)     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            if (r3 == 0) goto L_0x008a
            com.onesignal.NotificationExtenderService$a r4 = r13.l     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            if (r4 == 0) goto L_0x007b
            com.onesignal.NotificationExtenderService$a r4 = r13.l     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            java.lang.Integer r4 = r4.b     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            if (r4 != 0) goto L_0x008a
        L_0x007b:
            com.onesignal.NotificationExtenderService$a r4 = r13.l     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            if (r4 != 0) goto L_0x0086
            com.onesignal.NotificationExtenderService$a r4 = new com.onesignal.NotificationExtenderService$a     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            r4.<init>()     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            r13.l = r4     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
        L_0x0086:
            com.onesignal.NotificationExtenderService$a r4 = r13.l     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
            r4.b = r3     // Catch:{ Throwable -> 0x0098, all -> 0x0096 }
        L_0x008a:
            if (r0 == 0) goto L_0x00be
            boolean r3 = r0.isClosed()
            if (r3 != 0) goto L_0x00be
            r0.close()
            goto L_0x00be
        L_0x0096:
            r13 = move-exception
            goto L_0x00b2
        L_0x0098:
            r3 = move-exception
            r4 = r0
            goto L_0x009f
        L_0x009b:
            r13 = move-exception
            r0 = r4
            goto L_0x00b2
        L_0x009e:
            r3 = move-exception
        L_0x009f:
            com.onesignal.ai$h r0 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x009b }
            java.lang.String r5 = "Could not read DB to find existing collapse_key!"
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r5, (java.lang.Throwable) r3)     // Catch:{ all -> 0x009b }
            if (r4 == 0) goto L_0x00be
            boolean r0 = r4.isClosed()
            if (r0 != 0) goto L_0x00be
            r4.close()
            goto L_0x00be
        L_0x00b2:
            if (r0 == 0) goto L_0x00bd
            boolean r1 = r0.isClosed()
            if (r1 != 0) goto L_0x00bd
            r0.close()
        L_0x00bd:
            throw r13
        L_0x00be:
            com.onesignal.NotificationExtenderService$a r0 = r13.l
            if (r0 == 0) goto L_0x00ca
            com.onesignal.NotificationExtenderService$a r0 = r13.l
            android.support.v4.app.NotificationCompat$Extender r0 = r0.f2706a
            if (r0 == 0) goto L_0x00ca
            r0 = 1
            goto L_0x00cb
        L_0x00ca:
            r0 = 0
        L_0x00cb:
            if (r0 != 0) goto L_0x00de
            org.json.JSONObject r0 = r13.b
            java.lang.String r3 = "alert"
            java.lang.String r0 = r0.optString(r3)
            boolean r0 = a((java.lang.String) r0)
            if (r0 == 0) goto L_0x00dc
            goto L_0x00de
        L_0x00dc:
            r0 = 0
            goto L_0x00df
        L_0x00de:
            r0 = 1
        L_0x00df:
            if (r0 == 0) goto L_0x00e4
            com.onesignal.l.a((com.onesignal.s) r13)
        L_0x00e4:
            boolean r0 = r13.c
            if (r0 != 0) goto L_0x0108
            a((com.onesignal.s) r13, (boolean) r2)
            org.json.JSONObject r0 = new org.json.JSONObject     // Catch:{ Throwable -> 0x0108 }
            org.json.JSONObject r2 = r13.b     // Catch:{ Throwable -> 0x0108 }
            java.lang.String r2 = r2.toString()     // Catch:{ Throwable -> 0x0108 }
            r0.<init>(r2)     // Catch:{ Throwable -> 0x0108 }
            java.lang.String r2 = "notificationId"
            java.lang.Integer r3 = r13.c()     // Catch:{ Throwable -> 0x0108 }
            r0.put(r2, r3)     // Catch:{ Throwable -> 0x0108 }
            org.json.JSONArray r0 = b((org.json.JSONObject) r0)     // Catch:{ Throwable -> 0x0108 }
            boolean r2 = r13.d     // Catch:{ Throwable -> 0x0108 }
            com.onesignal.ai.a((org.json.JSONArray) r0, (boolean) r1, (boolean) r2)     // Catch:{ Throwable -> 0x0108 }
        L_0x0108:
            java.lang.Integer r13 = r13.c()
            int r13 = r13.intValue()
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.q.a(com.onesignal.s):int");
    }

    static ac a(JSONObject jSONObject) {
        ac acVar = new ac();
        try {
            JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
            acVar.f2715a = jSONObject2.optString("i");
            acVar.c = jSONObject2.optString("ti");
            acVar.b = jSONObject2.optString("tn");
            acVar.v = jSONObject.toString();
            acVar.f = jSONObject2.optJSONObject("a");
            acVar.k = jSONObject2.optString("u", (String) null);
            acVar.e = jSONObject.optString("alert", (String) null);
            acVar.d = jSONObject.optString("title", (String) null);
            acVar.g = jSONObject.optString("sicon", (String) null);
            acVar.i = jSONObject.optString("bicon", (String) null);
            acVar.h = jSONObject.optString("licon", (String) null);
            acVar.l = jSONObject.optString("sound", (String) null);
            acVar.o = jSONObject.optString("grp", (String) null);
            acVar.p = jSONObject.optString("grp_msg", (String) null);
            acVar.j = jSONObject.optString("bgac", (String) null);
            acVar.m = jSONObject.optString("ledc", (String) null);
            String optString = jSONObject.optString("vis", (String) null);
            if (optString != null) {
                acVar.n = Integer.parseInt(optString);
            }
            acVar.r = jSONObject.optString("from", (String) null);
            acVar.u = jSONObject.optInt("pri", 0);
            String optString2 = jSONObject.optString("collapse_key", (String) null);
            if (!"do_not_collapse".equals(optString2)) {
                acVar.t = optString2;
            }
            a(acVar);
        } catch (Throwable th) {
            ai.a(ai.h.ERROR, "Error assigning OSNotificationPayload values!", th);
        }
        try {
            String optString3 = jSONObject.optString("bg_img", (String) null);
            if (optString3 != null) {
                JSONObject jSONObject3 = new JSONObject(optString3);
                acVar.s = new ac.b();
                acVar.s.f2717a = jSONObject3.optString("img");
                acVar.s.b = jSONObject3.optString("tc");
                acVar.s.c = jSONObject3.optString("bc");
            }
        } catch (Throwable th2) {
            ai.a(ai.h.ERROR, "Error assigning OSNotificationPayload.backgroundImageLayout values!", th2);
        }
        return acVar;
    }

    static a a(Context context, final Bundle bundle) {
        a aVar = new a();
        if (ai.a(bundle) == null) {
            return aVar;
        }
        aVar.f2802a = true;
        b(bundle);
        if (a(context, bundle, aVar)) {
            return aVar;
        }
        aVar.c = ai.a(context, a(bundle));
        if (!aVar.c && !a(bundle.getString("alert"))) {
            b(context, bundle);
            new Thread(new Runnable() {
                public final void run() {
                    Bundle bundle = bundle;
                    JSONArray jSONArray = new JSONArray();
                    jSONArray.put(q.a(bundle));
                    ai.a(jSONArray, false, false);
                }
            }, "OS_PROC_BUNDLE").start();
        }
        return aVar;
    }

    static JSONObject a(Bundle bundle) {
        JSONObject jSONObject = new JSONObject();
        for (String str : bundle.keySet()) {
            try {
                jSONObject.put(str, bundle.get(str));
            } catch (JSONException e) {
                ai.a(ai.h.ERROR, "bundleAsJSONObject error for key: ".concat(String.valueOf(str)), (Throwable) e);
            }
        }
        return jSONObject;
    }

    static void a(Context context, g gVar, NotificationExtenderService.a aVar) {
        ai.a(context);
        try {
            String a2 = gVar.a("json_payload");
            if (a2 == null) {
                ai.a(ai.h.ERROR, "json_payload key is nonexistent from mBundle passed to ProcessFromGCMIntentService: ".concat(String.valueOf(gVar)));
                return;
            }
            s sVar = new s(context);
            sVar.c = gVar.d("restoring");
            sVar.e = gVar.c("timestamp");
            sVar.b = new JSONObject(a2);
            if (sVar.c || !ai.a(context, sVar.b)) {
                if (gVar.e("android_notif_id")) {
                    aVar = new NotificationExtenderService.a();
                    aVar.b = gVar.b("android_notif_id");
                }
                sVar.l = aVar;
                a(sVar);
                if (sVar.c) {
                    ah.a(100);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static void a(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.delete("notification", "created_time < " + ((System.currentTimeMillis() / 1000) - 604800), (String[]) null);
    }

    private static void a(ac acVar) {
        if (acVar.f != null && acVar.f.has("actionButtons")) {
            JSONArray jSONArray = acVar.f.getJSONArray("actionButtons");
            acVar.q = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                ac.a aVar = new ac.a();
                aVar.f2716a = jSONObject.optString("id", (String) null);
                aVar.b = jSONObject.optString("text", (String) null);
                aVar.c = jSONObject.optString("icon", (String) null);
                acVar.q.add(aVar);
            }
            acVar.f.remove("actionSelected");
            acVar.f.remove("actionButtons");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:48:0x012c A[SYNTHETIC, Splitter:B:48:0x012c] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x013b A[SYNTHETIC, Splitter:B:55:0x013b] */
    /* JADX WARNING: Removed duplicated region for block: B:66:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void a(com.onesignal.s r10, boolean r11) {
        /*
            android.content.Context r0 = r10.f2803a
            org.json.JSONObject r1 = r10.b
            org.json.JSONObject r2 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0148 }
            org.json.JSONObject r3 = r10.b     // Catch:{ JSONException -> 0x0148 }
            java.lang.String r4 = "custom"
            java.lang.String r3 = r3.optString(r4)     // Catch:{ JSONException -> 0x0148 }
            r2.<init>(r3)     // Catch:{ JSONException -> 0x0148 }
            android.content.Context r3 = r10.f2803a     // Catch:{ JSONException -> 0x0148 }
            com.onesignal.ak r3 = com.onesignal.ak.a(r3)     // Catch:{ JSONException -> 0x0148 }
            r4 = 0
            android.database.sqlite.SQLiteDatabase r3 = r3.a()     // Catch:{ Exception -> 0x0122 }
            r3.beginTransaction()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            a((android.database.sqlite.SQLiteDatabase) r3)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            int r5 = r10.d()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r6 = -1
            if (r5 == r6) goto L_0x0052
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r6 = "android_notification_id = "
            r5.<init>(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            int r6 = r10.d()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.append(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            android.content.ContentValues r6 = new android.content.ContentValues     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r6.<init>()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r7 = "dismissed"
            r8 = 1
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r6.put(r7, r8)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r7 = "notification"
            r3.update(r7, r6, r5, r4)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            com.onesignal.f.a((android.database.sqlite.SQLiteDatabase) r3, (android.content.Context) r0)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x0052:
            android.content.ContentValues r5 = new android.content.ContentValues     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.<init>()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r6 = "notification_id"
            java.lang.String r7 = "i"
            java.lang.String r2 = r2.optString(r7)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r6, r2)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r2 = "grp"
            boolean r2 = r1.has(r2)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r2 == 0) goto L_0x0075
            java.lang.String r2 = "group_id"
            java.lang.String r6 = "grp"
            java.lang.String r6 = r1.optString(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x0075:
            java.lang.String r2 = "collapse_key"
            boolean r2 = r1.has(r2)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r2 == 0) goto L_0x0096
            java.lang.String r2 = "do_not_collapse"
            java.lang.String r6 = "collapse_key"
            java.lang.String r6 = r1.optString(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            boolean r2 = r2.equals(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r2 != 0) goto L_0x0096
            java.lang.String r2 = "collapse_id"
            java.lang.String r6 = "collapse_key"
            java.lang.String r6 = r1.optString(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x0096:
            java.lang.String r2 = "opened"
            java.lang.Integer r6 = java.lang.Integer.valueOf(r11)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r11 != 0) goto L_0x00ae
            java.lang.String r2 = "android_notification_id"
            int r6 = r10.d()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x00ae:
            java.lang.CharSequence r2 = r10.a()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r2 == 0) goto L_0x00c1
            java.lang.String r2 = "title"
            java.lang.CharSequence r6 = r10.a()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x00c1:
            java.lang.CharSequence r2 = r10.b()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r2 == 0) goto L_0x00d4
            java.lang.String r2 = "message"
            java.lang.CharSequence r10 = r10.b()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r2, r10)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x00d4:
            java.lang.String r10 = "google.sent_time"
            long r6 = android.os.SystemClock.currentThreadTimeMillis()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            long r6 = r1.optLong(r10, r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r8 = 1000(0x3e8, double:4.94E-321)
            long r6 = r6 / r8
            java.lang.String r10 = "google.ttl"
            r2 = 259200(0x3f480, float:3.63217E-40)
            int r10 = r1.optInt(r10, r2)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            long r8 = (long) r10     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            long r6 = r6 + r8
            java.lang.String r10 = "expire_time"
            java.lang.Long r2 = java.lang.Long.valueOf(r6)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r10, r2)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r10 = "full_data"
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            r5.put(r10, r1)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            java.lang.String r10 = "notification"
            r3.insertOrThrow(r10, r4, r5)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r11 != 0) goto L_0x0108
            com.onesignal.f.a((android.database.sqlite.SQLiteDatabase) r3, (android.content.Context) r0)     // Catch:{ Exception -> 0x011c, all -> 0x011a }
        L_0x0108:
            r3.setTransactionSuccessful()     // Catch:{ Exception -> 0x011c, all -> 0x011a }
            if (r3 == 0) goto L_0x0138
            r3.endTransaction()     // Catch:{ Throwable -> 0x0111 }
            return
        L_0x0111:
            r10 = move-exception
            com.onesignal.ai$h r11 = com.onesignal.ai.h.ERROR     // Catch:{ JSONException -> 0x0148 }
            java.lang.String r0 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r11, (java.lang.String) r0, (java.lang.Throwable) r10)     // Catch:{ JSONException -> 0x0148 }
            return
        L_0x011a:
            r10 = move-exception
            goto L_0x0139
        L_0x011c:
            r10 = move-exception
            r4 = r3
            goto L_0x0123
        L_0x011f:
            r10 = move-exception
            r3 = r4
            goto L_0x0139
        L_0x0122:
            r10 = move-exception
        L_0x0123:
            com.onesignal.ai$h r11 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x011f }
            java.lang.String r0 = "Error saving notification record! "
            com.onesignal.ai.a((com.onesignal.ai.h) r11, (java.lang.String) r0, (java.lang.Throwable) r10)     // Catch:{ all -> 0x011f }
            if (r4 == 0) goto L_0x0138
            r4.endTransaction()     // Catch:{ Throwable -> 0x0130 }
            return
        L_0x0130:
            r10 = move-exception
            com.onesignal.ai$h r11 = com.onesignal.ai.h.ERROR     // Catch:{ JSONException -> 0x0148 }
            java.lang.String r0 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r11, (java.lang.String) r0, (java.lang.Throwable) r10)     // Catch:{ JSONException -> 0x0148 }
        L_0x0138:
            return
        L_0x0139:
            if (r3 == 0) goto L_0x0147
            r3.endTransaction()     // Catch:{ Throwable -> 0x013f }
            goto L_0x0147
        L_0x013f:
            r11 = move-exception
            com.onesignal.ai$h r0 = com.onesignal.ai.h.ERROR     // Catch:{ JSONException -> 0x0148 }
            java.lang.String r1 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r1, (java.lang.Throwable) r11)     // Catch:{ JSONException -> 0x0148 }
        L_0x0147:
            throw r10     // Catch:{ JSONException -> 0x0148 }
        L_0x0148:
            r10 = move-exception
            r10.printStackTrace()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.q.a(com.onesignal.s, boolean):void");
    }

    private static boolean a(Context context, Bundle bundle, a aVar) {
        Intent a2 = NotificationExtenderService.a(context);
        boolean z = false;
        if (a2 == null) {
            return false;
        }
        a2.putExtra("json_payload", a(bundle).toString());
        a2.putExtra("timestamp", System.currentTimeMillis() / 1000);
        if (Integer.parseInt(bundle.getString("pri", "0")) > 9) {
            z = true;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            NotificationExtenderService.a(context, a2.getComponent(), 2071862121, a2, z);
        } else {
            context.startService(a2);
        }
        aVar.b = true;
        return true;
    }

    static boolean a(Bundle bundle, String str) {
        String trim = bundle.getString(str, "").trim();
        return trim.startsWith("http://") || trim.startsWith("https://");
    }

    private static boolean a(String str) {
        return (str != null && !"".equals(str)) && (ai.n() || ai.o() || !ai.q());
    }

    static JSONArray b(JSONObject jSONObject) {
        JSONArray jSONArray = new JSONArray();
        jSONArray.put(jSONObject);
        return jSONArray;
    }

    private static void b(Context context, Bundle bundle) {
        s sVar = new s(context);
        sVar.b = a(bundle);
        sVar.l = new NotificationExtenderService.a();
        sVar.l.b = -1;
        a(sVar, true);
    }

    private static void b(Bundle bundle) {
        String str;
        if (bundle.containsKey("o")) {
            try {
                JSONObject jSONObject = new JSONObject(bundle.getString("custom"));
                JSONObject jSONObject2 = jSONObject.has("a") ? jSONObject.getJSONObject("a") : new JSONObject();
                JSONArray jSONArray = new JSONArray(bundle.getString("o"));
                bundle.remove("o");
                for (int i = 0; i < jSONArray.length(); i++) {
                    JSONObject jSONObject3 = jSONArray.getJSONObject(i);
                    String string = jSONObject3.getString("n");
                    jSONObject3.remove("n");
                    if (jSONObject3.has("i")) {
                        str = jSONObject3.getString("i");
                        jSONObject3.remove("i");
                    } else {
                        str = string;
                    }
                    jSONObject3.put("id", str);
                    jSONObject3.put("text", string);
                    if (jSONObject3.has("p")) {
                        jSONObject3.put("icon", jSONObject3.getString("p"));
                        jSONObject3.remove("p");
                    }
                }
                jSONObject2.put("actionButtons", jSONArray);
                jSONObject2.put("actionSelected", "__DEFAULT__");
                if (!jSONObject.has("a")) {
                    jSONObject.put("a", jSONObject2);
                }
                bundle.putString("custom", jSONObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
