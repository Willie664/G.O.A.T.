package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import com.google.android.gms.common.GoogleApiAvailability;
import com.onesignal.ai;
import com.onesignal.ar;
import java.io.IOException;

abstract class at implements ar {
    /* access modifiers changed from: private */
    public static int b = 5;
    /* access modifiers changed from: private */
    public static int c = 10000;

    /* renamed from: a  reason: collision with root package name */
    private ar.a f2761a;
    private Thread d;
    private boolean e;

    at() {
    }

    /* access modifiers changed from: private */
    public boolean a(String str, int i) {
        try {
            String a2 = a(str);
            ai.a(ai.h.INFO, "Device registered, push token = ".concat(String.valueOf(a2)));
            this.f2761a.a(a2, 1);
            return true;
        } catch (IOException e2) {
            if (!"SERVICE_NOT_AVAILABLE".equals(e2.getMessage())) {
                ai.h hVar = ai.h.ERROR;
                ai.a(hVar, "Error Getting " + a() + " Token", (Throwable) e2);
                if (!this.e) {
                    this.f2761a.a((String) null, -11);
                }
                return true;
            } else if (i >= b - 1) {
                ai.h hVar2 = ai.h.ERROR;
                ai.a(hVar2, "Retry count of " + b + " exceed! Could not get a " + a() + " Token.", (Throwable) e2);
                return false;
            } else {
                ai.a(ai.h.INFO, "'Google Play services' returned SERVICE_NOT_AVAILABLE error. Current retry count: ".concat(String.valueOf(i)), (Throwable) e2);
                if (i != 2) {
                    return false;
                }
                this.f2761a.a((String) null, -9);
                this.e = true;
                return true;
            }
        } catch (Throwable th) {
            ai.h hVar3 = ai.h.ERROR;
            ai.a(hVar3, "Unknown error getting " + a() + " Token", th);
            this.f2761a.a((String) null, -12);
            return true;
        }
    }

    private static boolean a(String str, ar.a aVar) {
        boolean z;
        try {
            Float.parseFloat(str);
            z = true;
        } catch (Throwable unused) {
            z = false;
        }
        if (z) {
            return true;
        }
        ai.a(ai.h.ERROR, "Missing Google Project number!\nPlease enter a Google Project number / Sender ID on under App Settings > Android > Configuration on the OneSignal dashboard.");
        aVar.a((String) null, -6);
        return false;
    }

    private synchronized void b(final String str) {
        if (this.d == null || !this.d.isAlive()) {
            this.d = new Thread(new Runnable() {
                public final void run() {
                    int i = 0;
                    while (i < at.b && !at.this.a(str, i)) {
                        i++;
                        ah.a(at.c * i);
                    }
                }
            });
            this.d.start();
        }
    }

    /* access modifiers changed from: package-private */
    public abstract String a();

    /* access modifiers changed from: package-private */
    public abstract String a(String str);

    public final void a(Context context, String str, ar.a aVar) {
        this.f2761a = aVar;
        if (a(str, aVar)) {
            try {
                if (n.a()) {
                    b(str);
                    return;
                }
                if (!n.a()) {
                    if (n.b()) {
                        if (!am.b(am.f2741a, "GT_DO_NOT_SHOW_MISSING_GPS", false)) {
                            ah.a((Runnable) new Runnable() {
                                public final void run() {
                                    final Activity activity = a.b;
                                    if (activity != null && !ai.i.e) {
                                        String a2 = ah.a((Context) activity, "onesignal_gms_missing_alert_text", "To receive push notifications please press 'Update' to enable 'Google Play services'.");
                                        String a3 = ah.a((Context) activity, "onesignal_gms_missing_alert_button_update", "Update");
                                        String a4 = ah.a((Context) activity, "onesignal_gms_missing_alert_button_skip", "Skip");
                                        new AlertDialog.Builder(activity).setMessage(a2).setPositiveButton(a3, new DialogInterface.OnClickListener() {
                                            public final void onClick(DialogInterface dialogInterface, int i) {
                                                Activity activity = activity;
                                                try {
                                                    GoogleApiAvailability instance = GoogleApiAvailability.getInstance();
                                                    instance.getErrorResolutionPendingIntent(activity, instance.isGooglePlayServicesAvailable(ai.b), 9000).send();
                                                } catch (PendingIntent.CanceledException unused) {
                                                } catch (Throwable th) {
                                                    th.printStackTrace();
                                                }
                                            }
                                        }).setNegativeButton(a4, new DialogInterface.OnClickListener() {
                                            public final void onClick(DialogInterface dialogInterface, int i) {
                                                am.a(am.f2741a, "GT_DO_NOT_SHOW_MISSING_GPS", true);
                                            }
                                        }).setNeutralButton(ah.a((Context) activity, "onesignal_gms_missing_alert_button_close", "Close"), (DialogInterface.OnClickListener) null).create().show();
                                    }
                                }
                            });
                        }
                    }
                }
                ai.a(ai.h.ERROR, "'Google Play services' app not installed or disabled on the device.");
                this.f2761a.a((String) null, -7);
            } catch (Throwable th) {
                ai.h hVar = ai.h.ERROR;
                ai.a(hVar, "Could not register with " + a() + " due to an issue with your AndroidManifest.xml or with 'Google Play services'.", th);
                this.f2761a.a((String) null, -8);
            }
        }
    }
}
