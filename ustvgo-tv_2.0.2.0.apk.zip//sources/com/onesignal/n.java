package com.onesignal;

import android.content.pm.PackageManager;

final class n {
    static boolean a() {
        try {
            return ai.b.getPackageManager().getPackageInfo("com.google.android.gms", 128).applicationInfo.enabled;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    static boolean b() {
        try {
            PackageManager packageManager = ai.b.getPackageManager();
            String str = (String) packageManager.getPackageInfo("com.google.android.gms", 128).applicationInfo.loadLabel(packageManager);
            return str != null && !str.equals("Market");
        } catch (Throwable unused) {
            return false;
        }
    }
}
