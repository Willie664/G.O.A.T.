package com.onesignal;

import android.content.Context;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.onesignal.ai;
import java.lang.reflect.Field;

final class ax {

    /* renamed from: a  reason: collision with root package name */
    boolean f2764a = false;
    a b;
    Object c;
    Field d;
    private Context e;

    class a {

        /* renamed from: a  reason: collision with root package name */
        PurchasingListener f2765a;

        private a() {
        }

        /* synthetic */ a(ax axVar, byte b2) {
            this();
        }
    }

    ax(Context context) {
        this.e = context;
        try {
            Class<?> cls = Class.forName("com.amazon.device.iap.internal.d");
            this.c = cls.getMethod("d", new Class[0]).invoke((Object) null, new Object[0]);
            this.d = cls.getDeclaredField("f");
            this.d.setAccessible(true);
            this.b = new a(this, (byte) 0);
            this.b.f2765a = (PurchasingListener) this.d.get(this.c);
            this.f2764a = true;
            a();
        } catch (Throwable th) {
            ai.a(ai.h.ERROR, "Error adding Amazon IAP listener.", th);
        }
    }

    /* access modifiers changed from: package-private */
    public final void a() {
        PurchasingService.registerListener(this.e, this.b);
    }
}
