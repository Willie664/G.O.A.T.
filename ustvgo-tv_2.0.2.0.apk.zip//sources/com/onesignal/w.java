package com.onesignal;

import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.onesignal.ai;
import org.json.JSONException;
import org.json.JSONObject;

final class w {
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0056, code lost:
        r12 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0057, code lost:
        r0 = r11;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0059, code lost:
        r1 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x005a, code lost:
        r0 = r11;
        r11 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0079, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:?, code lost:
        return r11;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
        return r11;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0056 A[ExcHandler: all (th java.lang.Throwable), Splitter:B:3:0x001d] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:45:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.Integer a(android.database.sqlite.SQLiteDatabase r11, java.lang.String r12) {
        /*
            r0 = 0
            java.lang.String r2 = "notification"
            r1 = 1
            java.lang.String[] r3 = new java.lang.String[r1]     // Catch:{ Throwable -> 0x0060 }
            java.lang.String r4 = "android_notification_id"
            r5 = 0
            r3[r5] = r4     // Catch:{ Throwable -> 0x0060 }
            java.lang.String r4 = "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 1"
            java.lang.String[] r6 = new java.lang.String[r1]     // Catch:{ Throwable -> 0x0060 }
            r6[r5] = r12     // Catch:{ Throwable -> 0x0060 }
            r7 = 0
            r8 = 0
            r9 = 0
            r1 = r11
            r5 = r6
            r6 = r7
            r7 = r8
            r8 = r9
            android.database.Cursor r11 = r1.query(r2, r3, r4, r5, r6, r7, r8)     // Catch:{ Throwable -> 0x0060 }
            boolean r1 = r11.moveToFirst()     // Catch:{ Throwable -> 0x0059, all -> 0x0056 }
            if (r1 != 0) goto L_0x0032
            r11.close()     // Catch:{ Throwable -> 0x0059, all -> 0x0056 }
            if (r11 == 0) goto L_0x0031
            boolean r12 = r11.isClosed()
            if (r12 != 0) goto L_0x0031
            r11.close()
        L_0x0031:
            return r0
        L_0x0032:
            java.lang.String r1 = "android_notification_id"
            int r1 = r11.getColumnIndex(r1)     // Catch:{ Throwable -> 0x0059, all -> 0x0056 }
            int r1 = r11.getInt(r1)     // Catch:{ Throwable -> 0x0059, all -> 0x0056 }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ Throwable -> 0x0059, all -> 0x0056 }
            r11.close()     // Catch:{ Throwable -> 0x0050, all -> 0x0056 }
            if (r11 == 0) goto L_0x004e
            boolean r12 = r11.isClosed()
            if (r12 != 0) goto L_0x004e
            r11.close()
        L_0x004e:
            r11 = r1
            goto L_0x007c
        L_0x0050:
            r0 = move-exception
            r10 = r0
            r0 = r11
            r11 = r1
            r1 = r10
            goto L_0x0062
        L_0x0056:
            r12 = move-exception
            r0 = r11
            goto L_0x007d
        L_0x0059:
            r1 = move-exception
            r10 = r0
            r0 = r11
            r11 = r10
            goto L_0x0062
        L_0x005e:
            r12 = move-exception
            goto L_0x007d
        L_0x0060:
            r1 = move-exception
            r11 = r0
        L_0x0062:
            com.onesignal.ai$h r2 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x005e }
            java.lang.String r3 = "Error getting android notification id for summary notification group: "
            java.lang.String r12 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x005e }
            java.lang.String r12 = r3.concat(r12)     // Catch:{ all -> 0x005e }
            com.onesignal.ai.a((com.onesignal.ai.h) r2, (java.lang.String) r12, (java.lang.Throwable) r1)     // Catch:{ all -> 0x005e }
            if (r0 == 0) goto L_0x007c
            boolean r12 = r0.isClosed()
            if (r12 != 0) goto L_0x007c
            r0.close()
        L_0x007c:
            return r11
        L_0x007d:
            if (r0 == 0) goto L_0x0088
            boolean r11 = r0.isClosed()
            if (r11 != 0) goto L_0x0088
            r0.close()
        L_0x0088:
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.w.a(android.database.sqlite.SQLiteDatabase, java.lang.String):java.lang.Integer");
    }

    static void a(Context context, SQLiteDatabase sQLiteDatabase, String str, boolean z) {
        try {
            Cursor b = b(context, sQLiteDatabase, str, z);
            if (b != null && !b.isClosed()) {
                b.close();
            }
        } catch (Throwable th) {
            ai.a(ai.h.ERROR, "Error running updateSummaryNotificationAfterChildRemoved!", th);
        }
    }

    private static Cursor b(Context context, SQLiteDatabase sQLiteDatabase, String str, boolean z) {
        Context context2 = context;
        String str2 = str;
        Cursor query = sQLiteDatabase.query("notification", new String[]{"android_notification_id", "created_time"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{str2}, (String) null, (String) null, "_id DESC");
        int count = query.getCount();
        Cursor cursor = null;
        if (count == 0) {
            query.close();
            Integer a2 = a(sQLiteDatabase, str);
            if (a2 == null) {
                return query;
            }
            ((NotificationManager) context2.getSystemService("notification")).cancel(a2.intValue());
            ContentValues contentValues = new ContentValues();
            contentValues.put(z ? "dismissed" : "opened", 1);
            sQLiteDatabase.update("notification", contentValues, "android_notification_id = ".concat(String.valueOf(a2)), (String[]) null);
            return query;
        }
        SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase;
        if (count == 1) {
            query.close();
            if (a(sQLiteDatabase, str) == null) {
                return query;
            }
            try {
                Cursor query2 = ak.a(context).b().query("notification", v.f2812a, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{str2}, (String) null, (String) null, (String) null);
                try {
                    v.a(context2, query2, 0);
                    if (query2 != null && !query2.isClosed()) {
                        query2.close();
                    }
                } catch (Throwable th) {
                    th = th;
                    cursor = query2;
                    if (cursor != null && !cursor.isClosed()) {
                        cursor.close();
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                ai.a(ai.h.ERROR, "Error restoring notification records! ", th);
                cursor.close();
                return query;
            }
            return query;
        }
        try {
            query.moveToFirst();
            Long valueOf = Long.valueOf(query.getLong(query.getColumnIndex("created_time")));
            query.close();
            if (a(sQLiteDatabase, str) == null) {
                return query;
            }
            s sVar = new s(context2);
            sVar.c = true;
            sVar.e = valueOf;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("grp", str2);
            sVar.b = jSONObject;
            l.b(sVar);
            return query;
        } catch (JSONException unused) {
        }
    }
}
