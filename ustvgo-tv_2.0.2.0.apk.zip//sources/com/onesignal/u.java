package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.NotificationManagerCompat;
import com.onesignal.ai;
import org.json.JSONArray;
import org.json.JSONObject;

final class u {
    static void a(Context context, Intent intent) {
        if (a(intent)) {
            ai.a(context);
            c(context, intent);
            b(context, intent);
        }
    }

    private static void a(Context context, Intent intent, SQLiteDatabase sQLiteDatabase) {
        String[] strArr;
        String str;
        String stringExtra = intent.getStringExtra("summary");
        if (stringExtra != null) {
            str = "group_id = ?";
            strArr = new String[]{stringExtra};
        } else {
            str = "android_notification_id = " + intent.getIntExtra("notificationId", 0);
            strArr = null;
        }
        sQLiteDatabase.update("notification", b(intent), str, strArr);
        f.a(sQLiteDatabase, context);
    }

    private static void a(JSONArray jSONArray, String str, SQLiteDatabase sQLiteDatabase) {
        Cursor query = sQLiteDatabase.query("notification", new String[]{"full_data"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{str}, (String) null, (String) null, (String) null);
        if (query.getCount() > 1) {
            query.moveToFirst();
            do {
                try {
                    jSONArray.put(new JSONObject(query.getString(query.getColumnIndex("full_data"))));
                } catch (Throwable unused) {
                    ai.a(ai.h.ERROR, "Could not parse JSON of sub notification in group: ".concat(String.valueOf(str)));
                }
            } while (query.moveToNext());
        }
        query.close();
    }

    private static boolean a(Intent intent) {
        return intent.hasExtra("onesignal_data") || intent.hasExtra("summary") || intent.hasExtra("notificationId");
    }

    private static ContentValues b(Intent intent) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(intent.getBooleanExtra("dismissed", false) ? "dismissed" : "opened", 1);
        return contentValues;
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x006b A[SYNTHETIC, Splitter:B:22:0x006b] */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0081 A[SYNTHETIC, Splitter:B:33:0x0081] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x008f  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x009b A[SYNTHETIC, Splitter:B:40:0x009b] */
    /* JADX WARNING: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void b(android.content.Context r7, android.content.Intent r8) {
        /*
            java.lang.String r0 = "summary"
            java.lang.String r0 = r8.getStringExtra(r0)
            java.lang.String r1 = "dismissed"
            r2 = 0
            boolean r1 = r8.getBooleanExtra(r1, r2)
            r3 = 0
            if (r1 != 0) goto L_0x0043
            org.json.JSONObject r4 = new org.json.JSONObject     // Catch:{ Throwable -> 0x003f }
            java.lang.String r5 = "onesignal_data"
            java.lang.String r5 = r8.getStringExtra(r5)     // Catch:{ Throwable -> 0x003f }
            r4.<init>(r5)     // Catch:{ Throwable -> 0x003f }
            java.lang.String r5 = "notificationId"
            java.lang.String r6 = "notificationId"
            int r6 = r8.getIntExtra(r6, r2)     // Catch:{ Throwable -> 0x003f }
            r4.put(r5, r6)     // Catch:{ Throwable -> 0x003f }
            java.lang.String r5 = "onesignal_data"
            java.lang.String r4 = r4.toString()     // Catch:{ Throwable -> 0x003f }
            r8.putExtra(r5, r4)     // Catch:{ Throwable -> 0x003f }
            org.json.JSONObject r4 = new org.json.JSONObject     // Catch:{ Throwable -> 0x003f }
            java.lang.String r5 = "onesignal_data"
            java.lang.String r5 = r8.getStringExtra(r5)     // Catch:{ Throwable -> 0x003f }
            r4.<init>(r5)     // Catch:{ Throwable -> 0x003f }
            org.json.JSONArray r4 = com.onesignal.q.b((org.json.JSONObject) r4)     // Catch:{ Throwable -> 0x003f }
            goto L_0x0044
        L_0x003f:
            r4 = move-exception
            r4.printStackTrace()
        L_0x0043:
            r4 = r3
        L_0x0044:
            com.onesignal.ak r5 = com.onesignal.ak.a(r7)
            android.database.sqlite.SQLiteDatabase r5 = r5.a()     // Catch:{ Exception -> 0x0077 }
            r5.beginTransaction()     // Catch:{ Exception -> 0x0071, all -> 0x006f }
            if (r1 != 0) goto L_0x0056
            if (r0 == 0) goto L_0x0056
            a((org.json.JSONArray) r4, (java.lang.String) r0, (android.database.sqlite.SQLiteDatabase) r5)     // Catch:{ Exception -> 0x0071, all -> 0x006f }
        L_0x0056:
            a((android.content.Context) r7, (android.content.Intent) r8, (android.database.sqlite.SQLiteDatabase) r5)     // Catch:{ Exception -> 0x0071, all -> 0x006f }
            if (r0 != 0) goto L_0x0066
            java.lang.String r0 = "grp"
            java.lang.String r0 = r8.getStringExtra(r0)     // Catch:{ Exception -> 0x0071, all -> 0x006f }
            if (r0 == 0) goto L_0x0066
            com.onesignal.w.a(r7, r5, r0, r1)     // Catch:{ Exception -> 0x0071, all -> 0x006f }
        L_0x0066:
            r5.setTransactionSuccessful()     // Catch:{ Exception -> 0x0071, all -> 0x006f }
            if (r5 == 0) goto L_0x008d
            r5.endTransaction()     // Catch:{ Throwable -> 0x0085 }
            goto L_0x008d
        L_0x006f:
            r7 = move-exception
            goto L_0x0099
        L_0x0071:
            r0 = move-exception
            r3 = r5
            goto L_0x0078
        L_0x0074:
            r7 = move-exception
            r5 = r3
            goto L_0x0099
        L_0x0077:
            r0 = move-exception
        L_0x0078:
            com.onesignal.ai$h r5 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x0074 }
            java.lang.String r6 = "Error processing notification open or dismiss record! "
            com.onesignal.ai.a((com.onesignal.ai.h) r5, (java.lang.String) r6, (java.lang.Throwable) r0)     // Catch:{ all -> 0x0074 }
            if (r3 == 0) goto L_0x008d
            r3.endTransaction()     // Catch:{ Throwable -> 0x0085 }
            goto L_0x008d
        L_0x0085:
            r0 = move-exception
            com.onesignal.ai$h r3 = com.onesignal.ai.h.ERROR
            java.lang.String r5 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r3, (java.lang.String) r5, (java.lang.Throwable) r0)
        L_0x008d:
            if (r1 != 0) goto L_0x0098
            java.lang.String r0 = "from_alert"
            boolean r8 = r8.getBooleanExtra(r0, r2)
            com.onesignal.ai.a((android.content.Context) r7, (org.json.JSONArray) r4, (boolean) r8)
        L_0x0098:
            return
        L_0x0099:
            if (r5 == 0) goto L_0x00a7
            r5.endTransaction()     // Catch:{ Throwable -> 0x009f }
            goto L_0x00a7
        L_0x009f:
            r8 = move-exception
            com.onesignal.ai$h r0 = com.onesignal.ai.h.ERROR
            java.lang.String r1 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r1, (java.lang.Throwable) r8)
        L_0x00a7:
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.u.b(android.content.Context, android.content.Intent):void");
    }

    private static void c(Context context, Intent intent) {
        if (intent.getBooleanExtra("action_button", false)) {
            NotificationManagerCompat.from(context).cancel(intent.getIntExtra("notificationId", 0));
            context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        }
    }
}
