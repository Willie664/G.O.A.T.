package com.onesignal;

import org.json.JSONObject;

public final class af {

    /* renamed from: a  reason: collision with root package name */
    ae f2721a;
    ae b;

    private JSONObject a() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("from", this.b.b());
            jSONObject.put("to", this.f2721a.b());
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return jSONObject;
    }

    public final String toString() {
        return a().toString();
    }
}
