package com.onesignal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.a;
import com.google.android.gms.location.LocationRequest;
import com.onesignal.ai;
import com.onesignal.e;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

class p {

    /* renamed from: a  reason: collision with root package name */
    static String f2796a;
    protected static final Object b = new Object() {
    };
    static g c;
    /* access modifiers changed from: private */
    public static m d;
    /* access modifiers changed from: private */
    public static Location e;
    /* access modifiers changed from: private */
    public static Context f;
    private static e g;
    private static ConcurrentHashMap<a, d> h = new ConcurrentHashMap<>();
    private static Thread i;
    private static boolean j;

    enum a {
        STARTUP,
        PROMPT_LOCATION,
        SYNC_SERVICE
    }

    static class b {
        static Location a(GoogleApiClient googleApiClient) {
            synchronized (p.b) {
                if (!googleApiClient.b()) {
                    return null;
                }
                Location a2 = com.google.android.gms.location.d.b.a(googleApiClient);
                return a2;
            }
        }

        static void a(GoogleApiClient googleApiClient, LocationRequest locationRequest, com.google.android.gms.location.c cVar) {
            try {
                synchronized (p.b) {
                    if (googleApiClient.b()) {
                        com.google.android.gms.location.d.b.a(googleApiClient, locationRequest, cVar);
                    }
                }
            } catch (Throwable th) {
                ai.a(ai.h.WARN, "FusedLocationApi.requestLocationUpdates failed!", th);
            }
        }
    }

    static class c implements GoogleApiClient.b, GoogleApiClient.c {
        private c() {
        }

        /* synthetic */ c(byte b) {
            this();
        }

        public final void a(int i) {
            p.b();
        }

        public final void a(Bundle bundle) {
            synchronized (p.b) {
                PermissionsActivity.b = false;
                if (p.e == null) {
                    Location unused = p.e = b.a(p.d.f2793a);
                    if (p.e != null) {
                        p.c(p.e);
                    }
                }
                p.c = new g(p.d.f2793a);
            }
        }

        public final void a(ConnectionResult connectionResult) {
            p.b();
        }
    }

    interface d {
        a a();

        void a(f fVar);
    }

    static class e extends HandlerThread {

        /* renamed from: a  reason: collision with root package name */
        Handler f2798a = new Handler(getLooper());

        e() {
            super("OSH_LocationHandlerThread");
            start();
        }
    }

    static class f {

        /* renamed from: a  reason: collision with root package name */
        Double f2799a;
        Double b;
        Float c;
        Integer d;
        Boolean e;
        Long f;

        f() {
        }
    }

    static class g implements com.google.android.gms.location.c {

        /* renamed from: a  reason: collision with root package name */
        private GoogleApiClient f2800a;

        g(GoogleApiClient googleApiClient) {
            this.f2800a = googleApiClient;
            long j = ai.f() ? 270000 : 570000;
            LocationRequest a2 = LocationRequest.a();
            LocationRequest.a(j);
            a2.d = true;
            a2.c = j;
            LocationRequest.a(j);
            a2.b = j;
            if (!a2.d) {
                double d = (double) a2.b;
                Double.isNaN(d);
                a2.c = (long) (d / 6.0d);
            }
            double d2 = (double) j;
            Double.isNaN(d2);
            long j2 = (long) (d2 * 1.5d);
            LocationRequest.a(j2);
            a2.e = j2;
            a2.f2609a = 102;
            b.a(this.f2800a, a2, this);
        }

        public final void a(Location location) {
            Location unused = p.e = location;
            ai.a(ai.h.INFO, "Location Change Detected");
        }
    }

    p() {
    }

    static void a() {
        if (i == null) {
            try {
                synchronized (b) {
                    h();
                    if (g == null) {
                        g = new e();
                    }
                    if (d != null) {
                        if (e != null) {
                            if (e != null) {
                                c(e);
                            }
                        }
                    }
                    c cVar = new c((byte) 0);
                    m mVar = new m(new GoogleApiClient.a(f).a((com.google.android.gms.common.api.a<? extends a.d.C0065d>) com.google.android.gms.location.d.f2614a).a((GoogleApiClient.b) cVar).a((GoogleApiClient.c) cVar).a(g.f2798a).a());
                    d = mVar;
                    mVar.a();
                }
            } catch (Throwable th) {
                ai.a(ai.h.WARN, "Location permission exists but there was an error initializing: ", th);
                b();
            }
        }
    }

    private static void a(long j2) {
        am.a(am.f2741a, "OS_LAST_LOCATION_TIME", j2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x0074 A[Catch:{ Throwable -> 0x007c }] */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0078 A[Catch:{ Throwable -> 0x007c }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void a(android.content.Context r4, boolean r5, com.onesignal.p.d r6) {
        /*
            f = r4
            java.util.concurrent.ConcurrentHashMap<com.onesignal.p$a, com.onesignal.p$d> r0 = h
            com.onesignal.p$a r1 = r6.a()
            r0.put(r1, r6)
            boolean r0 = com.onesignal.ai.h
            if (r0 != 0) goto L_0x0013
            b()
            return
        L_0x0013:
            java.lang.String r0 = "android.permission.ACCESS_FINE_LOCATION"
            int r0 = com.onesignal.e.a.a((android.content.Context) r4, (java.lang.String) r0)
            r1 = -1
            if (r0 != r1) goto L_0x0025
            java.lang.String r1 = "android.permission.ACCESS_COARSE_LOCATION"
            int r1 = com.onesignal.e.a.a((android.content.Context) r4, (java.lang.String) r1)
            r2 = 1
            j = r2
        L_0x0025:
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 23
            if (r2 >= r3) goto L_0x0038
            if (r0 == 0) goto L_0x0034
            if (r1 == 0) goto L_0x0034
            r4 = 0
            r6.a(r4)
            return
        L_0x0034:
            a()
            return
        L_0x0038:
            if (r0 == 0) goto L_0x0081
            android.content.pm.PackageManager r6 = r4.getPackageManager()     // Catch:{ Throwable -> 0x007c }
            java.lang.String r4 = r4.getPackageName()     // Catch:{ Throwable -> 0x007c }
            r0 = 4096(0x1000, float:5.74E-42)
            android.content.pm.PackageInfo r4 = r6.getPackageInfo(r4, r0)     // Catch:{ Throwable -> 0x007c }
            java.lang.String[] r4 = r4.requestedPermissions     // Catch:{ Throwable -> 0x007c }
            java.util.List r4 = java.util.Arrays.asList(r4)     // Catch:{ Throwable -> 0x007c }
            java.lang.String r6 = "android.permission.ACCESS_FINE_LOCATION"
            boolean r6 = r4.contains(r6)     // Catch:{ Throwable -> 0x007c }
            if (r6 == 0) goto L_0x005b
            java.lang.String r4 = "android.permission.ACCESS_FINE_LOCATION"
        L_0x0058:
            f2796a = r4     // Catch:{ Throwable -> 0x007c }
            goto L_0x0068
        L_0x005b:
            java.lang.String r6 = "android.permission.ACCESS_COARSE_LOCATION"
            boolean r4 = r4.contains(r6)     // Catch:{ Throwable -> 0x007c }
            if (r4 == 0) goto L_0x0068
            if (r1 == 0) goto L_0x0068
            java.lang.String r4 = "android.permission.ACCESS_COARSE_LOCATION"
            goto L_0x0058
        L_0x0068:
            java.lang.String r4 = f2796a     // Catch:{ Throwable -> 0x007c }
            if (r4 == 0) goto L_0x0072
            if (r5 == 0) goto L_0x0072
            com.onesignal.PermissionsActivity.a()     // Catch:{ Throwable -> 0x007c }
            return
        L_0x0072:
            if (r1 != 0) goto L_0x0078
            a()     // Catch:{ Throwable -> 0x007c }
            return
        L_0x0078:
            b()     // Catch:{ Throwable -> 0x007c }
            return
        L_0x007c:
            r4 = move-exception
            r4.printStackTrace()
            return
        L_0x0081:
            a()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.p.a(android.content.Context, boolean, com.onesignal.p$d):void");
    }

    private static void a(f fVar) {
        Thread thread;
        HashMap hashMap = new HashMap();
        synchronized (p.class) {
            hashMap.putAll(h);
            h.clear();
            thread = i;
        }
        for (a aVar : hashMap.keySet()) {
            ((d) hashMap.get(aVar)).a(fVar);
        }
        if (thread != null && !Thread.currentThread().equals(thread)) {
            thread.interrupt();
        }
        if (thread == i) {
            synchronized (p.class) {
                if (thread == i) {
                    i = null;
                }
            }
        }
        a(System.currentTimeMillis());
    }

    static boolean a(Context context) {
        if (!(e.a.a(context, "android.permission.ACCESS_FINE_LOCATION") == 0 || e.a.a(context, "android.permission.ACCESS_COARSE_LOCATION") == 0) || !ai.h) {
            return false;
        }
        aq.a(context, ((ai.f() ? 300 : 600) * 1000) - (System.currentTimeMillis() - am.b(am.f2741a, "OS_LAST_LOCATION_TIME", -600000)));
        return true;
    }

    static void b() {
        PermissionsActivity.b = false;
        synchronized (b) {
            if (d != null) {
                d.b();
            }
            d = null;
        }
        a((f) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x002b, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void c() {
        /*
            java.lang.Object r0 = b
            monitor-enter(r0)
            com.onesignal.m r1 = d     // Catch:{ all -> 0x002c }
            if (r1 == 0) goto L_0x002a
            com.onesignal.m r1 = d     // Catch:{ all -> 0x002c }
            com.google.android.gms.common.api.GoogleApiClient r1 = r1.f2793a     // Catch:{ all -> 0x002c }
            boolean r1 = r1.b()     // Catch:{ all -> 0x002c }
            if (r1 != 0) goto L_0x0012
            goto L_0x002a
        L_0x0012:
            com.onesignal.m r1 = d     // Catch:{ all -> 0x002c }
            com.google.android.gms.common.api.GoogleApiClient r1 = r1.f2793a     // Catch:{ all -> 0x002c }
            com.onesignal.p$g r2 = c     // Catch:{ all -> 0x002c }
            if (r2 == 0) goto L_0x0021
            com.google.android.gms.location.a r2 = com.google.android.gms.location.d.b     // Catch:{ all -> 0x002c }
            com.onesignal.p$g r3 = c     // Catch:{ all -> 0x002c }
            r2.a(r1, r3)     // Catch:{ all -> 0x002c }
        L_0x0021:
            com.onesignal.p$g r2 = new com.onesignal.p$g     // Catch:{ all -> 0x002c }
            r2.<init>(r1)     // Catch:{ all -> 0x002c }
            c = r2     // Catch:{ all -> 0x002c }
            monitor-exit(r0)     // Catch:{ all -> 0x002c }
            return
        L_0x002a:
            monitor-exit(r0)     // Catch:{ all -> 0x002c }
            return
        L_0x002c:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x002c }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.p.c():void");
    }

    /* access modifiers changed from: private */
    public static void c(Location location) {
        double longitude;
        f fVar = new f();
        fVar.c = Float.valueOf(location.getAccuracy());
        fVar.e = Boolean.valueOf(!ai.f());
        fVar.d = Integer.valueOf(j ^ true ? 1 : 0);
        fVar.f = Long.valueOf(location.getTime());
        if (j) {
            fVar.f2799a = Double.valueOf(new BigDecimal(location.getLatitude()).setScale(7, RoundingMode.HALF_UP).doubleValue());
            longitude = new BigDecimal(location.getLongitude()).setScale(7, RoundingMode.HALF_UP).doubleValue();
        } else {
            fVar.f2799a = Double.valueOf(location.getLatitude());
            longitude = location.getLongitude();
        }
        fVar.b = Double.valueOf(longitude);
        a(fVar);
        a(f);
    }

    static /* synthetic */ int d() {
        return 30000;
    }

    private static void h() {
        Thread thread = new Thread(new Runnable() {
            public final void run() {
                try {
                    p.d();
                    Thread.sleep(30000);
                    ai.a(ai.h.WARN, "Location permission exists but GoogleApiClient timed out. Maybe related to mismatch google-play aar versions.");
                    p.b();
                    p.a(p.f);
                } catch (InterruptedException unused) {
                }
            }
        }, "OS_GMS_LOCATION_FALLBACK");
        i = thread;
        thread.start();
    }
}
