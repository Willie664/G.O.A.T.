package com.onesignal;

public final class av {

    public static final class a {
        public static final int action0 = 2131296268;
        public static final int action_container = 2131296276;
        public static final int action_divider = 2131296278;
        public static final int action_image = 2131296279;
        public static final int action_text = 2131296285;
        public static final int actions = 2131296286;
        public static final int adjust_height = 2131296296;
        public static final int adjust_width = 2131296297;
        public static final int async = 2131296310;
        public static final int auto = 2131296311;
        public static final int blocking = 2131296322;
        public static final int bottom = 2131296323;
        public static final int browser_actions_header_text = 2131296324;
        public static final int browser_actions_menu_item_icon = 2131296325;
        public static final int browser_actions_menu_item_text = 2131296326;
        public static final int browser_actions_menu_items = 2131296327;
        public static final int browser_actions_menu_view = 2131296328;
        public static final int cancel_action = 2131296331;
        public static final int center = 2131296332;
        public static final int chronometer = 2131296337;
        public static final int dark = 2131296351;
        public static final int email = 2131296373;
        public static final int end = 2131296377;
        public static final int end_padder = 2131296378;
        public static final int forever = 2131296392;
        public static final int grayscale = 2131296397;
        public static final int icon = 2131296403;
        public static final int icon_group = 2131296405;
        public static final int icon_only = 2131296406;
        public static final int info = 2131296409;
        public static final int italic = 2131296414;
        public static final int left = 2131296425;
        public static final int light = 2131296426;
        public static final int line1 = 2131296428;
        public static final int line3 = 2131296429;
        public static final int match_parent = 2131296435;
        public static final int media_actions = 2131296436;
        public static final int none = 2131296451;
        public static final int normal = 2131296452;
        public static final int notification_background = 2131296453;
        public static final int notification_main_column = 2131296454;
        public static final int notification_main_column_container = 2131296455;
        public static final int os_bgimage_notif_bgimage = 2131296458;
        public static final int os_bgimage_notif_bgimage_align_layout = 2131296459;
        public static final int os_bgimage_notif_bgimage_right_aligned = 2131296460;
        public static final int os_bgimage_notif_body = 2131296461;
        public static final int os_bgimage_notif_title = 2131296462;
        public static final int radio = 2131296492;
        public static final int right = 2131296498;
        public static final int right_icon = 2131296499;
        public static final int right_side = 2131296500;
        public static final int standard = 2131296540;
        public static final int start = 2131296541;
        public static final int status_bar_latest_event_content = 2131296542;
        public static final int tag_transition_group = 2131296548;
        public static final int text = 2131296549;
        public static final int text2 = 2131296550;
        public static final int time = 2131296557;
        public static final int title = 2131296559;
        public static final int toolbar = 2131296562;
        public static final int top = 2131296563;
        public static final int wide = 2131296582;
        public static final int wrap_content = 2131296586;
    }

    public static final class b {
        public static final int browser_actions_context_menu_page = 2131427358;
        public static final int browser_actions_context_menu_row = 2131427359;
        public static final int notification_action = 2131427384;
        public static final int notification_action_tombstone = 2131427385;
        public static final int notification_media_action = 2131427386;
        public static final int notification_media_cancel_action = 2131427387;
        public static final int notification_template_big_media = 2131427388;
        public static final int notification_template_big_media_custom = 2131427389;
        public static final int notification_template_big_media_narrow = 2131427390;
        public static final int notification_template_big_media_narrow_custom = 2131427391;
        public static final int notification_template_custom_big = 2131427392;
        public static final int notification_template_icon_group = 2131427393;
        public static final int notification_template_lines_media = 2131427394;
        public static final int notification_template_media = 2131427395;
        public static final int notification_template_media_custom = 2131427396;
        public static final int notification_template_part_chronometer = 2131427397;
        public static final int notification_template_part_time = 2131427398;
        public static final int onesignal_bgimage_notif_layout = 2131427400;
    }
}
