package com.onesignal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.onesignal.ai;

final class c implements d {

    /* renamed from: a  reason: collision with root package name */
    static String f2783a;

    c() {
    }

    public final String a(Context context) {
        try {
            AdvertisingIdClient.Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            f2783a = advertisingIdInfo.isLimitAdTrackingEnabled() ? "OptedOut" : advertisingIdInfo.getId();
            return f2783a;
        } catch (Throwable th) {
            ai.a(ai.h.INFO, "Error getting Google Ad id: ", th);
            return null;
        }
    }
}
