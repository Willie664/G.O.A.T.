package com.onesignal;

import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.support.v4.app.NotificationCompat;
import java.util.Map;
import java.util.TreeMap;

final class t {

    /* renamed from: a  reason: collision with root package name */
    static final String f2811a = Integer.toString(49);

    static void a(Context context, int i) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                StatusBarNotification[] activeNotifications = ((NotificationManager) context.getSystemService("notification")).getActiveNotifications();
                int length = (activeNotifications.length - 49) + i;
                if (length > 0) {
                    TreeMap treeMap = new TreeMap();
                    for (StatusBarNotification statusBarNotification : activeNotifications) {
                        if (!a(statusBarNotification)) {
                            treeMap.put(Long.valueOf(statusBarNotification.getNotification().when), Integer.valueOf(statusBarNotification.getId()));
                        }
                    }
                    for (Map.Entry value : treeMap.entrySet()) {
                        ai.a(((Integer) value.getValue()).intValue());
                        length--;
                        if (length <= 0) {
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            b(context, i);
        } catch (Throwable unused) {
            b(context, i);
        }
    }

    static boolean a(StatusBarNotification statusBarNotification) {
        return (statusBarNotification.getNotification().flags & NotificationCompat.FLAG_GROUP_SUMMARY) != 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:48:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void b(android.content.Context r10, int r11) {
        /*
            com.onesignal.ak r10 = com.onesignal.ak.a(r10)
            r0 = 0
            android.database.sqlite.SQLiteDatabase r1 = r10.b()     // Catch:{ Throwable -> 0x0075 }
            java.lang.String r2 = "notification"
            r10 = 1
            java.lang.String[] r3 = new java.lang.String[r10]     // Catch:{ Throwable -> 0x0075 }
            r10 = 0
            java.lang.String r4 = "android_notification_id"
            r3[r10] = r4     // Catch:{ Throwable -> 0x0075 }
            java.lang.StringBuilder r10 = com.onesignal.ak.c()     // Catch:{ Throwable -> 0x0075 }
            java.lang.String r4 = r10.toString()     // Catch:{ Throwable -> 0x0075 }
            r5 = 0
            r6 = 0
            r7 = 0
            java.lang.String r8 = "_id"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0075 }
            r10.<init>()     // Catch:{ Throwable -> 0x0075 }
            java.lang.String r9 = f2811a     // Catch:{ Throwable -> 0x0075 }
            r10.append(r9)     // Catch:{ Throwable -> 0x0075 }
            r10.append(r11)     // Catch:{ Throwable -> 0x0075 }
            java.lang.String r9 = r10.toString()     // Catch:{ Throwable -> 0x0075 }
            android.database.Cursor r10 = r1.query(r2, r3, r4, r5, r6, r7, r8, r9)     // Catch:{ Throwable -> 0x0075 }
            int r0 = r10.getCount()     // Catch:{ Throwable -> 0x0070, all -> 0x006d }
            int r0 = r0 + -49
            int r0 = r0 + r11
            if (r0 > 0) goto L_0x004a
            if (r10 == 0) goto L_0x0049
            boolean r11 = r10.isClosed()
            if (r11 != 0) goto L_0x0049
            r10.close()
        L_0x0049:
            return
        L_0x004a:
            boolean r11 = r10.moveToNext()     // Catch:{ Throwable -> 0x0070, all -> 0x006d }
            if (r11 == 0) goto L_0x0061
            java.lang.String r11 = "android_notification_id"
            int r11 = r10.getColumnIndex(r11)     // Catch:{ Throwable -> 0x0070, all -> 0x006d }
            int r11 = r10.getInt(r11)     // Catch:{ Throwable -> 0x0070, all -> 0x006d }
            com.onesignal.ai.a((int) r11)     // Catch:{ Throwable -> 0x0070, all -> 0x006d }
            int r0 = r0 + -1
            if (r0 > 0) goto L_0x004a
        L_0x0061:
            if (r10 == 0) goto L_0x0088
            boolean r11 = r10.isClosed()
            if (r11 != 0) goto L_0x0088
            r10.close()
            return
        L_0x006d:
            r11 = move-exception
            r0 = r10
            goto L_0x0089
        L_0x0070:
            r11 = move-exception
            r0 = r10
            goto L_0x0076
        L_0x0073:
            r11 = move-exception
            goto L_0x0089
        L_0x0075:
            r11 = move-exception
        L_0x0076:
            com.onesignal.ai$h r10 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x0073 }
            java.lang.String r1 = "Error clearing oldest notifications over limit! "
            com.onesignal.ai.a((com.onesignal.ai.h) r10, (java.lang.String) r1, (java.lang.Throwable) r11)     // Catch:{ all -> 0x0073 }
            if (r0 == 0) goto L_0x0088
            boolean r10 = r0.isClosed()
            if (r10 != 0) goto L_0x0088
            r0.close()
        L_0x0088:
            return
        L_0x0089:
            if (r0 == 0) goto L_0x0094
            boolean r10 = r0.isClosed()
            if (r10 != 0) goto L_0x0094
            r0.close()
        L_0x0094:
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.t.b(android.content.Context, int):void");
    }
}
