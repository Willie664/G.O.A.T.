package com.onesignal;

import com.onesignal.bf;
import org.json.JSONException;
import org.json.JSONObject;

final class bc extends bf {
    bc() {
    }

    /* access modifiers changed from: protected */
    public final ba a(String str) {
        return new bb(str, true);
    }

    /* access modifiers changed from: package-private */
    public final bf.a a(boolean z) {
        return null;
    }

    /* access modifiers changed from: package-private */
    public final void a(JSONObject jSONObject) {
    }

    /* access modifiers changed from: package-private */
    public final boolean a() {
        return false;
    }

    /* access modifiers changed from: package-private */
    public final void b() {
        c();
    }

    /* access modifiers changed from: package-private */
    public final void b(String str) {
        ai.c(str);
    }

    /* access modifiers changed from: protected */
    public final void b(JSONObject jSONObject) {
        try {
            jSONObject.put("device_type", 11);
            jSONObject.putOpt("device_player_id", ai.i());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public final void b(boolean z) {
    }

    /* access modifiers changed from: protected */
    public final void c() {
        if (!(ai.j() == null && e() == null) && ai.i() != null) {
            a((Integer) 0).a();
        }
    }

    /* access modifiers changed from: protected */
    public final void c(JSONObject jSONObject) {
        if (jSONObject.has("identifier")) {
            ai.v();
        }
    }

    /* access modifiers changed from: protected */
    public final String d() {
        return ai.j();
    }

    /* access modifiers changed from: protected */
    public final void d(JSONObject jSONObject) {
        if (jSONObject.has("identifier")) {
            ai.u();
        }
    }
}
