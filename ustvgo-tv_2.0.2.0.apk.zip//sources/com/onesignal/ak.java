package com.onesignal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import com.onesignal.ai;
import java.util.ArrayList;

public final class ak extends SQLiteOpenHelper {

    /* renamed from: a  reason: collision with root package name */
    private static final String[] f2739a = {"CREATE INDEX notification_notification_id_idx ON notification(notification_id); ", "CREATE INDEX notification_android_notification_id_idx ON notification(android_notification_id); ", "CREATE INDEX notification_group_id_idx ON notification(group_id); ", "CREATE INDEX notification_collapse_id_idx ON notification(collapse_id); ", "CREATE INDEX notification_created_time_idx ON notification(created_time); ", "CREATE INDEX notification_expire_time_idx ON notification(expire_time); "};
    private static ak b;

    private ak(Context context) {
        super(context, "OneSignal.db", (SQLiteDatabase.CursorFactory) null, 3);
    }

    public static synchronized ak a(Context context) {
        ak akVar;
        synchronized (ak.class) {
            if (b == null) {
                b = new ak(context.getApplicationContext());
            }
            akVar = b;
        }
        return akVar;
    }

    private static void a(SQLiteDatabase sQLiteDatabase, String str) {
        try {
            sQLiteDatabase.execSQL(str);
        } catch (SQLiteException e) {
            e.printStackTrace();
        }
    }

    static StringBuilder c() {
        long currentTimeMillis = System.currentTimeMillis() / 1000;
        StringBuilder sb = new StringBuilder("created_time > " + (currentTimeMillis - 604800) + " AND dismissed = 0 AND opened = 0 AND is_summary = 0");
        if (am.b(am.f2741a, "OS_RESTORE_TTL_FILTER", true)) {
            sb.append(" AND expire_time > ".concat(String.valueOf(currentTimeMillis)));
        }
        return sb;
    }

    /* access modifiers changed from: package-private */
    public final synchronized SQLiteDatabase a() {
        int i = 0;
        while (true) {
            try {
            } catch (Throwable th) {
                i++;
                if (i < 5) {
                    SystemClock.sleep((long) (i * 400));
                } else {
                    throw th;
                }
            }
        }
        return getWritableDatabase();
    }

    /* access modifiers changed from: package-private */
    public final synchronized SQLiteDatabase b() {
        int i = 0;
        while (true) {
            try {
            } catch (Throwable th) {
                i++;
                if (i < 5) {
                    SystemClock.sleep((long) (i * 400));
                } else {
                    throw th;
                }
            }
        }
        return getReadableDatabase();
    }

    public final void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE notification (_id INTEGER PRIMARY KEY,notification_id TEXT,android_notification_id INTEGER,group_id TEXT,collapse_id TEXT,is_summary INTEGER DEFAULT 0,opened INTEGER DEFAULT 0,dismissed INTEGER DEFAULT 0,title TEXT,message TEXT,full_data TEXT,created_time TIMESTAMP DEFAULT (strftime('%s', 'now')),expire_time TIMESTAMP);");
        for (String execSQL : f2739a) {
            sQLiteDatabase.execSQL(execSQL);
        }
    }

    /* JADX INFO: finally extract failed */
    public final void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        ai.a(ai.h.WARN, "SDK version rolled back! Clearing OneSignal.db as it could be in an unexpected state.");
        Cursor rawQuery = sQLiteDatabase.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", (String[]) null);
        try {
            ArrayList<String> arrayList = new ArrayList<>(rawQuery.getCount());
            while (rawQuery.moveToNext()) {
                arrayList.add(rawQuery.getString(0));
            }
            for (String str : arrayList) {
                if (!str.startsWith("sqlite_")) {
                    sQLiteDatabase.execSQL("DROP TABLE IF EXISTS ".concat(String.valueOf(str)));
                }
            }
            rawQuery.close();
            onCreate(sQLiteDatabase);
        } catch (Throwable th) {
            rawQuery.close();
            throw th;
        }
    }

    public final void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        if (i < 2) {
            try {
                a(sQLiteDatabase, "ALTER TABLE notification ADD COLUMN collapse_id TEXT;");
                a(sQLiteDatabase, "CREATE INDEX notification_group_id_idx ON notification(group_id); ");
            } catch (SQLiteException e) {
                ai.a(ai.h.ERROR, "Error in upgrade, migration may have already run! Skipping!", (Throwable) e);
                return;
            }
        }
        if (i < 3) {
            a(sQLiteDatabase, "ALTER TABLE notification ADD COLUMN expire_time TIMESTAMP;");
            a(sQLiteDatabase, "UPDATE notification SET expire_time = created_time + 259200;");
            a(sQLiteDatabase, "CREATE INDEX notification_expire_time_idx ON notification(expire_time); ");
        }
    }
}
