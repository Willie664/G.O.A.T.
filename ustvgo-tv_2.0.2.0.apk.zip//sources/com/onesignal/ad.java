package com.onesignal;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

final class ad<ObserverType, StateType> {

    /* renamed from: a  reason: collision with root package name */
    List<Object> f2718a = new ArrayList();
    private String b;
    private boolean c;

    ad(String str, boolean z) {
        this.b = str;
        this.c = z;
    }

    /* access modifiers changed from: package-private */
    public final void a(ObserverType observertype) {
        this.f2718a.add(observertype);
    }

    /* access modifiers changed from: package-private */
    public final boolean b(final StateType statetype) {
        boolean z = false;
        for (final Object next : this.f2718a) {
            if (next instanceof WeakReference) {
                next = ((WeakReference) next).get();
            }
            if (next != null) {
                try {
                    final Method declaredMethod = next.getClass().getDeclaredMethod(this.b, new Class[]{statetype.getClass()});
                    declaredMethod.setAccessible(true);
                    if (this.c) {
                        ah.a((Runnable) new Runnable() {
                            public final void run() {
                                try {
                                    declaredMethod.invoke(next, new Object[]{statetype});
                                } catch (Throwable th) {
                                    th.printStackTrace();
                                }
                            }
                        });
                    } else {
                        declaredMethod.invoke(next, new Object[]{statetype});
                    }
                    z = true;
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
        }
        return z;
    }
}
