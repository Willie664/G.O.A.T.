package com.onesignal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.NotificationManagerCompat;
import android.telephony.TelephonyManager;
import com.onesignal.ai;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class ah {
    ah() {
    }

    static int a() {
        try {
            Class.forName("com.amazon.device.messaging.ADM");
            return 2;
        } catch (ClassNotFoundException unused) {
            return 1;
        }
    }

    private static int a(Context context) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), 0).targetSdkVersion;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 15;
        }
    }

    static int a(Context context, int i, String str) {
        try {
            UUID.fromString(str);
            if ("b2f7f966-d8cc-11e4-bed1-df8f05be55ba".equals(str) || "5eb5a37e-b458-11e3-ac11-000c2940e62c".equals(str)) {
                ai.a(ai.h.ERROR, "OneSignal Example AppID detected, please update to your app's id found on OneSignal.com");
            }
            if (i == 1) {
                ai.a(ai.h.WARN, "Both GCM & FCM Libraries detected! Please remove the deprecated GCM library.");
            }
            if (Build.VERSION.SDK_INT >= 26) {
                a(context);
            }
            return 1;
        } catch (Throwable th) {
            ai.a(ai.h.FATAL, "OneSignal AppId format is invalid.\nExample: 'b2f7f966-d8cc-11e4-bed1-df8f05be55ba'\n", th);
            return -999;
        }
    }

    static String a(Context context, String str) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData.getString(str);
        } catch (Throwable th) {
            ai.a(ai.h.ERROR, "", th);
            return null;
        }
    }

    static String a(Context context, String str, String str2) {
        Resources resources = context.getResources();
        int identifier = resources.getIdentifier(str, "string", context.getPackageName());
        return identifier != 0 ? resources.getString(identifier) : str2;
    }

    static void a(int i) {
        try {
            Thread.sleep((long) i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    static void a(Runnable runnable) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            runnable.run();
        } else {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }

    static boolean a(String str) {
        return str != null && !str.matches("^[0-9]");
    }

    static long[] a(JSONObject jSONObject) {
        try {
            Object opt = jSONObject.opt("vib_pt");
            JSONArray jSONArray = opt instanceof String ? new JSONArray((String) opt) : (JSONArray) opt;
            long[] jArr = new long[jSONArray.length()];
            for (int i = 0; i < jSONArray.length(); i++) {
                jArr[i] = jSONArray.optLong(i);
            }
            return jArr;
        } catch (JSONException unused) {
            return null;
        }
    }

    static Uri b(Context context, String str) {
        int identifier;
        StringBuilder sb;
        Resources resources = context.getResources();
        String packageName = context.getPackageName();
        if (!a(str) || (identifier = resources.getIdentifier(str, "raw", packageName)) == 0) {
            identifier = resources.getIdentifier("onesignal_default_sound", "raw", packageName);
            if (identifier == 0) {
                return null;
            }
            sb = new StringBuilder("android.resource://");
        } else {
            sb = new StringBuilder("android.resource://");
        }
        sb.append(packageName);
        sb.append("/");
        sb.append(identifier);
        return Uri.parse(sb.toString());
    }

    static Integer b() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) ai.b.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo == null) {
            return null;
        }
        int type = activeNetworkInfo.getType();
        return (type == 1 || type == 9) ? 0 : 1;
    }

    static String c() {
        try {
            String networkOperatorName = ((TelephonyManager) ai.b.getSystemService("phone")).getNetworkOperatorName();
            if ("".equals(networkOperatorName)) {
                return null;
            }
            return networkOperatorName;
        } catch (Throwable th) {
            th.printStackTrace();
            return null;
        }
    }

    static String d() {
        String language = Locale.getDefault().getLanguage();
        if (language.equals("iw")) {
            return "he";
        }
        if (language.equals("in")) {
            return "id";
        }
        if (language.equals("ji")) {
            return "yi";
        }
        if (!language.equals("zh")) {
            return language;
        }
        return language + "-" + Locale.getDefault().getCountry();
    }

    static boolean e() {
        try {
            return NotificationManagerCompat.from(ai.b).areNotificationsEnabled();
        } catch (Throwable unused) {
            return true;
        }
    }
}
