package com.onesignal;

import org.json.JSONException;

final class bd extends ba {
    bd(String str, boolean z) {
        super(str, z);
    }

    private int d() {
        int optInt = this.f2771a.optInt("subscribableStatus", 1);
        if (optInt < -2) {
            return optInt;
        }
        if (!this.f2771a.optBoolean("androidPermission", true)) {
            return 0;
        }
        return !this.f2771a.optBoolean("userSubscribePref", true) ? -2 : 1;
    }

    /* access modifiers changed from: package-private */
    public final ba a(String str) {
        return new bd(str, false);
    }

    /* access modifiers changed from: protected */
    public final void a() {
        try {
            this.b.put("notification_types", d());
        } catch (JSONException unused) {
        }
    }

    /* access modifiers changed from: package-private */
    public final boolean b() {
        return d() > 0;
    }
}
