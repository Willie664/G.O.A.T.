package com.onesignal;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

abstract class ba {
    private static final String[] c = {"lat", "long", "loc_acc", "loc_type", "loc_bg", "loc_time_stamp", "ad_id"};
    private static final Set<String> d = new HashSet(Arrays.asList(c));
    private static final Object e = new Object() {
    };

    /* renamed from: a  reason: collision with root package name */
    JSONObject f2771a;
    JSONObject b;
    private String f;

    ba(String str, boolean z) {
        String str2;
        String str3;
        this.f = str;
        if (z) {
            String str4 = am.f2741a;
            String b2 = am.b(str4, "ONESIGNAL_USERSTATE_DEPENDVALYES_" + this.f, (String) null);
            if (b2 == null) {
                this.f2771a = new JSONObject();
                try {
                    if (this.f.equals("CURRENT_STATE")) {
                        str2 = am.f2741a;
                        str3 = "ONESIGNAL_SUBSCRIPTION";
                    } else {
                        str2 = am.f2741a;
                        str3 = "ONESIGNAL_SYNCED_SUBSCRIPTION";
                    }
                    int a2 = am.a(str2, str3);
                    boolean z2 = true;
                    if (a2 == -2) {
                        a2 = 1;
                        z2 = false;
                    }
                    this.f2771a.put("subscribableStatus", a2);
                    this.f2771a.put("userSubscribePref", z2);
                } catch (JSONException unused) {
                }
            } else {
                try {
                    this.f2771a = new JSONObject(b2);
                } catch (JSONException e2) {
                    e2.printStackTrace();
                }
            }
            String str5 = am.f2741a;
            String b3 = am.b(str5, "ONESIGNAL_USERSTATE_SYNCVALYES_" + this.f, (String) null);
            if (b3 == null) {
                try {
                    this.b = new JSONObject();
                    this.b.put("identifier", am.b(am.f2741a, "GT_REGISTRATION_ID", (String) null));
                } catch (JSONException e3) {
                    e3.printStackTrace();
                }
            } else {
                this.b = new JSONObject(b3);
            }
        } else {
            this.f2771a = new JSONObject();
            this.b = new JSONObject();
        }
    }

    private Set<String> a(ba baVar) {
        try {
            if (this.f2771a.optLong("loc_time_stamp") == baVar.f2771a.getLong("loc_time_stamp")) {
                return null;
            }
            baVar.b.put("loc_bg", baVar.f2771a.opt("loc_bg"));
            baVar.b.put("loc_time_stamp", baVar.f2771a.opt("loc_time_stamp"));
            return d;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static JSONObject a(JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, Set<String> set) {
        JSONObject a2;
        synchronized (e) {
            a2 = o.a(jSONObject, jSONObject2, jSONObject3, set);
        }
        return a2;
    }

    /* access modifiers changed from: package-private */
    public abstract ba a(String str);

    /* access modifiers changed from: package-private */
    public final JSONObject a(ba baVar, boolean z) {
        a();
        baVar.a();
        JSONObject a2 = a(this.b, baVar.b, (JSONObject) null, a(baVar));
        if (!z && a2.toString().equals("{}")) {
            return null;
        }
        try {
            if (!a2.has("app_id")) {
                a2.put("app_id", this.b.optString("app_id"));
            }
            if (this.b.has("email_auth_hash")) {
                a2.put("email_auth_hash", this.b.optString("email_auth_hash"));
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return a2;
    }

    /* access modifiers changed from: protected */
    public abstract void a();

    /* access modifiers changed from: package-private */
    public final void a(JSONObject jSONObject, JSONObject jSONObject2) {
        if (jSONObject != null) {
            a(this.f2771a, jSONObject, this.f2771a, (Set<String>) null);
        }
        if (jSONObject2 != null) {
            a(this.b, jSONObject2, this.b, (Set<String>) null);
            b(jSONObject2, (JSONObject) null);
        }
        if (jSONObject != null || jSONObject2 != null) {
            c();
        }
    }

    /* access modifiers changed from: package-private */
    public final ba b(String str) {
        ba a2 = a(str);
        try {
            a2.f2771a = new JSONObject(this.f2771a.toString());
            a2.b = new JSONObject(this.b.toString());
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return a2;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0023 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:28:0x007f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(org.json.JSONObject r7, org.json.JSONObject r8) {
        /*
            r6 = this;
            java.lang.Object r0 = e
            monitor-enter(r0)
            java.lang.String r1 = "tags"
            boolean r1 = r7.has(r1)     // Catch:{ all -> 0x0081 }
            if (r1 == 0) goto L_0x007f
            org.json.JSONObject r1 = r6.b     // Catch:{ all -> 0x0081 }
            java.lang.String r2 = "tags"
            boolean r1 = r1.has(r2)     // Catch:{ all -> 0x0081 }
            if (r1 == 0) goto L_0x0029
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0023 }
            org.json.JSONObject r2 = r6.b     // Catch:{ JSONException -> 0x0023 }
            java.lang.String r3 = "tags"
            java.lang.String r2 = r2.optString(r3)     // Catch:{ JSONException -> 0x0023 }
            r1.<init>(r2)     // Catch:{ JSONException -> 0x0023 }
            goto L_0x002e
        L_0x0023:
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ all -> 0x0081 }
            r1.<init>()     // Catch:{ all -> 0x0081 }
            goto L_0x002e
        L_0x0029:
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ all -> 0x0081 }
            r1.<init>()     // Catch:{ all -> 0x0081 }
        L_0x002e:
            java.lang.String r2 = "tags"
            org.json.JSONObject r7 = r7.optJSONObject(r2)     // Catch:{ all -> 0x0081 }
            java.util.Iterator r2 = r7.keys()     // Catch:{ all -> 0x0081 }
        L_0x0038:
            boolean r3 = r2.hasNext()     // Catch:{ Throwable -> 0x007f }
            if (r3 == 0) goto L_0x0064
            java.lang.Object r3 = r2.next()     // Catch:{ Throwable -> 0x007f }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Throwable -> 0x007f }
            java.lang.String r4 = ""
            java.lang.String r5 = r7.optString(r3)     // Catch:{ Throwable -> 0x007f }
            boolean r4 = r4.equals(r5)     // Catch:{ Throwable -> 0x007f }
            if (r4 == 0) goto L_0x0054
            r1.remove(r3)     // Catch:{ Throwable -> 0x007f }
            goto L_0x0038
        L_0x0054:
            if (r8 == 0) goto L_0x005c
            boolean r4 = r8.has(r3)     // Catch:{ Throwable -> 0x007f }
            if (r4 != 0) goto L_0x0038
        L_0x005c:
            java.lang.String r4 = r7.optString(r3)     // Catch:{ Throwable -> 0x007f }
            r1.put(r3, r4)     // Catch:{ Throwable -> 0x007f }
            goto L_0x0038
        L_0x0064:
            java.lang.String r7 = r1.toString()     // Catch:{ Throwable -> 0x007f }
            java.lang.String r8 = "{}"
            boolean r7 = r7.equals(r8)     // Catch:{ Throwable -> 0x007f }
            if (r7 == 0) goto L_0x0078
            org.json.JSONObject r7 = r6.b     // Catch:{ Throwable -> 0x007f }
            java.lang.String r8 = "tags"
            r7.remove(r8)     // Catch:{ Throwable -> 0x007f }
            goto L_0x007f
        L_0x0078:
            org.json.JSONObject r7 = r6.b     // Catch:{ Throwable -> 0x007f }
            java.lang.String r8 = "tags"
            r7.put(r8, r1)     // Catch:{ Throwable -> 0x007f }
        L_0x007f:
            monitor-exit(r0)     // Catch:{ all -> 0x0081 }
            return
        L_0x0081:
            r7 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0081 }
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ba.b(org.json.JSONObject, org.json.JSONObject):void");
    }

    /* access modifiers changed from: package-private */
    public abstract boolean b();

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x00e0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c() {
        /*
            r8 = this;
            java.lang.Object r0 = e
            monitor-enter(r0)
            java.lang.String r1 = "pkgs"
            org.json.JSONObject r2 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            boolean r2 = r2.has(r1)     // Catch:{ Throwable -> 0x00e0 }
            if (r2 == 0) goto L_0x0014
            org.json.JSONObject r2 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONArray r2 = r2.getJSONArray(r1)     // Catch:{ Throwable -> 0x00e0 }
            goto L_0x0019
        L_0x0014:
            org.json.JSONArray r2 = new org.json.JSONArray     // Catch:{ Throwable -> 0x00e0 }
            r2.<init>()     // Catch:{ Throwable -> 0x00e0 }
        L_0x0019:
            org.json.JSONArray r3 = new org.json.JSONArray     // Catch:{ Throwable -> 0x00e0 }
            r3.<init>()     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONObject r4 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r5.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r5.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r6 = "_d"
            r5.append(r6)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r5 = r5.toString()     // Catch:{ Throwable -> 0x00e0 }
            boolean r4 = r4.has(r5)     // Catch:{ Throwable -> 0x00e0 }
            r5 = 0
            if (r4 == 0) goto L_0x006f
            org.json.JSONObject r4 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r6.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r6.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r7 = "_d"
            r6.append(r7)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r6 = r6.toString()     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONArray r4 = r4.getJSONArray(r6)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r4 = com.onesignal.o.a(r4)     // Catch:{ Throwable -> 0x00e0 }
            r6 = 0
        L_0x0054:
            int r7 = r2.length()     // Catch:{ Throwable -> 0x00e0 }
            if (r6 >= r7) goto L_0x006e
            java.lang.String r7 = r2.getString(r6)     // Catch:{ Throwable -> 0x00e0 }
            boolean r7 = r4.contains(r7)     // Catch:{ Throwable -> 0x00e0 }
            if (r7 != 0) goto L_0x006b
            java.lang.Object r7 = r2.get(r6)     // Catch:{ Throwable -> 0x00e0 }
            r3.put(r7)     // Catch:{ Throwable -> 0x00e0 }
        L_0x006b:
            int r6 = r6 + 1
            goto L_0x0054
        L_0x006e:
            r2 = r3
        L_0x006f:
            org.json.JSONObject r3 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r4.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r4.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r6 = "_a"
            r4.append(r6)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r4 = r4.toString()     // Catch:{ Throwable -> 0x00e0 }
            boolean r3 = r3.has(r4)     // Catch:{ Throwable -> 0x00e0 }
            if (r3 == 0) goto L_0x00af
            org.json.JSONObject r3 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r4.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r4.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r6 = "_a"
            r4.append(r6)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r4 = r4.toString()     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONArray r3 = r3.getJSONArray(r4)     // Catch:{ Throwable -> 0x00e0 }
        L_0x009f:
            int r4 = r3.length()     // Catch:{ Throwable -> 0x00e0 }
            if (r5 >= r4) goto L_0x00af
            java.lang.Object r4 = r3.get(r5)     // Catch:{ Throwable -> 0x00e0 }
            r2.put(r4)     // Catch:{ Throwable -> 0x00e0 }
            int r5 = r5 + 1
            goto L_0x009f
        L_0x00af:
            org.json.JSONObject r3 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            r3.put(r1, r2)     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONObject r2 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r3.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r3.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r4 = "_a"
            r3.append(r4)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r3 = r3.toString()     // Catch:{ Throwable -> 0x00e0 }
            r2.remove(r3)     // Catch:{ Throwable -> 0x00e0 }
            org.json.JSONObject r2 = r8.b     // Catch:{ Throwable -> 0x00e0 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x00e0 }
            r3.<init>()     // Catch:{ Throwable -> 0x00e0 }
            r3.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r1 = "_d"
            r3.append(r1)     // Catch:{ Throwable -> 0x00e0 }
            java.lang.String r1 = r3.toString()     // Catch:{ Throwable -> 0x00e0 }
            r2.remove(r1)     // Catch:{ Throwable -> 0x00e0 }
        L_0x00e0:
            java.lang.String r1 = com.onesignal.am.f2741a     // Catch:{ all -> 0x0118 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = "ONESIGNAL_USERSTATE_SYNCVALYES_"
            r2.<init>(r3)     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = r8.f     // Catch:{ all -> 0x0118 }
            r2.append(r3)     // Catch:{ all -> 0x0118 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0118 }
            org.json.JSONObject r3 = r8.b     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0118 }
            com.onesignal.am.a((java.lang.String) r1, (java.lang.String) r2, (java.lang.String) r3)     // Catch:{ all -> 0x0118 }
            java.lang.String r1 = com.onesignal.am.f2741a     // Catch:{ all -> 0x0118 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = "ONESIGNAL_USERSTATE_DEPENDVALYES_"
            r2.<init>(r3)     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = r8.f     // Catch:{ all -> 0x0118 }
            r2.append(r3)     // Catch:{ all -> 0x0118 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0118 }
            org.json.JSONObject r3 = r8.f2771a     // Catch:{ all -> 0x0118 }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0118 }
            com.onesignal.am.a((java.lang.String) r1, (java.lang.String) r2, (java.lang.String) r3)     // Catch:{ all -> 0x0118 }
            monitor-exit(r0)     // Catch:{ all -> 0x0118 }
            return
        L_0x0118:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0118 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ba.c():void");
    }
}
