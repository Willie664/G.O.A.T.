package com.onesignal;

import android.os.Build;

final class i {
    static g a() {
        return Build.VERSION.SDK_INT >= 26 ? new j() : new h();
    }
}
