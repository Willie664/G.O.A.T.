package com.onesignal;

import android.app.job.JobParameters;
import android.app.job.JobService;

abstract class al extends JobService {
    al() {
    }

    /* access modifiers changed from: package-private */
    public abstract void a(JobService jobService, JobParameters jobParameters);

    public boolean onStartJob(final JobParameters jobParameters) {
        if (jobParameters.getExtras() == null) {
            return false;
        }
        new Thread(new Runnable() {
            public final void run() {
                al.this.a(this, jobParameters);
                al.this.jobFinished(jobParameters, false);
            }
        }, "OS_JOBSERVICE_BASE").start();
        return true;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }
}
