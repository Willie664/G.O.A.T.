package com.onesignal;

import android.os.PersistableBundle;

final class j implements g<PersistableBundle> {

    /* renamed from: a  reason: collision with root package name */
    private PersistableBundle f2786a;

    j() {
        this.f2786a = new PersistableBundle();
    }

    j(PersistableBundle persistableBundle) {
        this.f2786a = persistableBundle;
    }

    public final /* bridge */ /* synthetic */ Object a() {
        return this.f2786a;
    }

    public final String a(String str) {
        return this.f2786a.getString(str);
    }

    public final void a(String str, Long l) {
        this.f2786a.putLong(str, l.longValue());
    }

    public final void a(String str, String str2) {
        this.f2786a.putString(str, str2);
    }

    public final Integer b(String str) {
        return Integer.valueOf(this.f2786a.getInt(str));
    }

    public final Long c(String str) {
        return Long.valueOf(this.f2786a.getLong(str));
    }

    public final boolean d(String str) {
        return this.f2786a.getBoolean(str, false);
    }

    public final boolean e(String str) {
        return this.f2786a.containsKey(str);
    }
}
