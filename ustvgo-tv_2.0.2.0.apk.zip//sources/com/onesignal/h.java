package com.onesignal;

import android.os.Bundle;

final class h implements g<Bundle> {

    /* renamed from: a  reason: collision with root package name */
    private Bundle f2785a;

    h() {
        this.f2785a = new Bundle();
    }

    h(Bundle bundle) {
        this.f2785a = bundle;
    }

    public final /* bridge */ /* synthetic */ Object a() {
        return this.f2785a;
    }

    public final String a(String str) {
        return this.f2785a.getString(str);
    }

    public final void a(String str, Long l) {
        this.f2785a.putLong(str, l.longValue());
    }

    public final void a(String str, String str2) {
        this.f2785a.putString(str, str2);
    }

    public final Integer b(String str) {
        return Integer.valueOf(this.f2785a.getInt(str));
    }

    public final Long c(String str) {
        return Long.valueOf(this.f2785a.getLong(str));
    }

    public final boolean d(String str) {
        return this.f2785a.getBoolean(str, false);
    }

    public final boolean e(String str) {
        return this.f2785a.containsKey(str);
    }
}
