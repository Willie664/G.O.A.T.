package com.onesignal;

class OSSubscriptionChangedInternalObserver {
    OSSubscriptionChangedInternalObserver() {
    }

    public void changed(OSSubscriptionState oSSubscriptionState) {
        ag agVar = new ag();
        agVar.b = ai.n;
        agVar.f2722a = (OSSubscriptionState) oSSubscriptionState.clone();
        if (ai.b().b(agVar)) {
            OSSubscriptionState oSSubscriptionState2 = (OSSubscriptionState) oSSubscriptionState.clone();
            ai.n = oSSubscriptionState2;
            am.a(am.f2741a, "ONESIGNAL_SUBSCRIPTION_LAST", oSSubscriptionState2.c);
            am.a(am.f2741a, "ONESIGNAL_PLAYER_ID_LAST", oSSubscriptionState2.d);
            am.a(am.f2741a, "ONESIGNAL_PUSH_TOKEN_LAST", oSSubscriptionState2.e);
            am.a(am.f2741a, "ONESIGNAL_PERMISSION_ACCEPTED_LAST", oSSubscriptionState2.b);
        }
    }
}
