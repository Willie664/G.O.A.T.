package com.onesignal;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.widget.RemoteViews;
import com.facebook.ads.AdError;
import com.onesignal.ai;
import com.onesignal.av;
import com.onesignal.e;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.URL;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class l {

    /* renamed from: a  reason: collision with root package name */
    private static Context f2788a;
    private static String b;
    private static Resources c;
    private static Class<?> d;
    private static boolean e;

    static class a {

        /* renamed from: a  reason: collision with root package name */
        NotificationCompat.Builder f2792a;
        boolean b;

        private a() {
        }

        /* synthetic */ a(byte b2) {
            this();
        }
    }

    private static PendingIntent a(int i, Intent intent) {
        return e ? PendingIntent.getBroadcast(f2788a, i, intent, 134217728) : PendingIntent.getActivity(f2788a, i, intent, 134217728);
    }

    private static Intent a(int i, JSONObject jSONObject, String str) {
        return b(i).putExtra("onesignal_data", jSONObject.toString()).putExtra("summary", str);
    }

    private static Bitmap a() {
        return a(a("ic_onesignal_large_icon_default"));
    }

    private static Bitmap a(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        try {
            int dimension = (int) c.getDimension(17104902);
            int dimension2 = (int) c.getDimension(17104901);
            int height = bitmap.getHeight();
            int width = bitmap.getWidth();
            if (width > dimension2 || height > dimension) {
                if (height > width) {
                    dimension2 = (int) (((float) dimension) * (((float) width) / ((float) height)));
                } else if (width > height) {
                    dimension = (int) (((float) dimension2) * (((float) height) / ((float) width)));
                }
                return Bitmap.createScaledBitmap(bitmap, dimension2, dimension, true);
            }
        } catch (Throwable unused) {
        }
        return bitmap;
    }

    private static Bitmap a(String str) {
        Bitmap bitmap;
        try {
            bitmap = BitmapFactory.decodeStream(f2788a.getAssets().open(str));
        } catch (Throwable unused) {
            bitmap = null;
        }
        if (bitmap != null) {
            return bitmap;
        }
        try {
            for (String str2 : Arrays.asList(new String[]{".png", ".webp", ".jpg", ".gif", ".bmp"})) {
                try {
                    bitmap = BitmapFactory.decodeStream(f2788a.getAssets().open(str + str2));
                    continue;
                } catch (Throwable unused2) {
                }
                if (bitmap != null) {
                    return bitmap;
                }
            }
            int d2 = d(str);
            if (d2 != 0) {
                return BitmapFactory.decodeResource(c, d2);
            }
        } catch (Throwable unused3) {
        }
        return null;
    }

    private static Integer a(JSONObject jSONObject, String str) {
        if (jSONObject == null) {
            return null;
        }
        try {
            if (jSONObject.has(str)) {
                return Integer.valueOf(new BigInteger(jSONObject.optString(str), 16).intValue());
            }
            return null;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static void a(Context context) {
        Class cls;
        f2788a = context;
        b = context.getPackageName();
        c = f2788a.getResources();
        PackageManager packageManager = f2788a.getPackageManager();
        Intent intent = new Intent(f2788a, NotificationOpenedReceiver.class);
        intent.setPackage(f2788a.getPackageName());
        if (packageManager.queryBroadcastReceivers(intent, 0).size() > 0) {
            e = true;
            cls = NotificationOpenedReceiver.class;
        } else {
            cls = NotificationOpenedActivity.class;
        }
        d = cls;
    }

    static /* synthetic */ void a(Context context, JSONObject jSONObject, List list, List list2) {
        try {
            JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
            if (jSONObject2.has("a")) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject("a");
                if (jSONObject3.has("actionButtons")) {
                    JSONArray optJSONArray = jSONObject3.optJSONArray("actionButtons");
                    for (int i = 0; i < optJSONArray.length(); i++) {
                        JSONObject jSONObject4 = optJSONArray.getJSONObject(i);
                        list.add(jSONObject4.optString("text"));
                        list2.add(jSONObject4.optString("id"));
                    }
                }
            }
        } catch (Throwable th) {
            ai.a(ai.h.ERROR, "Failed to parse JSON for custom buttons for alert dialog.", th);
        }
        if (list.size() == 0 || list.size() < 3) {
            list.add(ah.a(context, "onesignal_in_app_alert_ok_button_text", "Ok"));
            list2.add("__DEFAULT__");
        }
    }

    private static void a(NotificationCompat.Builder builder) {
        builder.setOnlyAlertOnce(true).setDefaults(0).setSound((Uri) null).setVibrate((long[]) null).setTicker((CharSequence) null);
    }

    private static void a(RemoteViews remoteViews, JSONObject jSONObject, int i, String str, String str2) {
        Integer a2 = a(jSONObject, str);
        if (a2 != null) {
            remoteViews.setTextColor(i, a2.intValue());
            return;
        }
        int identifier = c.getIdentifier(str2, "color", b);
        if (identifier != 0) {
            remoteViews.setTextColor(i, e.a.a(f2788a, identifier));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x004e A[SYNTHETIC, Splitter:B:21:0x004e] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0054 A[SYNTHETIC, Splitter:B:24:0x0054] */
    /* JADX WARNING: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void a(com.onesignal.ak r3, java.lang.String r4, int r5) {
        /*
            r0 = 0
            android.database.sqlite.SQLiteDatabase r3 = r3.a()     // Catch:{ Throwable -> 0x0044 }
            r3.beginTransaction()     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            android.content.ContentValues r1 = new android.content.ContentValues     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            r1.<init>()     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            java.lang.String r2 = "android_notification_id"
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            r1.put(r2, r5)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            java.lang.String r5 = "group_id"
            r1.put(r5, r4)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            java.lang.String r4 = "is_summary"
            r5 = 1
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            r1.put(r4, r5)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            java.lang.String r4 = "notification"
            r3.insertOrThrow(r4, r0, r1)     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            r3.setTransactionSuccessful()     // Catch:{ Throwable -> 0x003e, all -> 0x003c }
            if (r3 == 0) goto L_0x0051
            r3.endTransaction()     // Catch:{ Throwable -> 0x0033 }
            return
        L_0x0033:
            r3 = move-exception
            com.onesignal.ai$h r4 = com.onesignal.ai.h.ERROR
            java.lang.String r5 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r4, (java.lang.String) r5, (java.lang.Throwable) r3)
            return
        L_0x003c:
            r4 = move-exception
            goto L_0x0052
        L_0x003e:
            r4 = move-exception
            r0 = r3
            goto L_0x0045
        L_0x0041:
            r4 = move-exception
            r3 = r0
            goto L_0x0052
        L_0x0044:
            r4 = move-exception
        L_0x0045:
            com.onesignal.ai$h r3 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x0041 }
            java.lang.String r5 = "Error adding summary notification record! "
            com.onesignal.ai.a((com.onesignal.ai.h) r3, (java.lang.String) r5, (java.lang.Throwable) r4)     // Catch:{ all -> 0x0041 }
            if (r0 == 0) goto L_0x0051
            r0.endTransaction()     // Catch:{ Throwable -> 0x0033 }
        L_0x0051:
            return
        L_0x0052:
            if (r3 == 0) goto L_0x0060
            r3.endTransaction()     // Catch:{ Throwable -> 0x0058 }
            goto L_0x0060
        L_0x0058:
            r3 = move-exception
            com.onesignal.ai$h r5 = com.onesignal.ai.h.ERROR
            java.lang.String r0 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r5, (java.lang.String) r0, (java.lang.Throwable) r3)
        L_0x0060:
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.l.a(com.onesignal.ak, java.lang.String, int):void");
    }

    private static void a(a aVar, Notification notification) {
        if (aVar.b) {
            try {
                Object newInstance = Class.forName("android.app.MiuiNotification").newInstance();
                Field declaredField = newInstance.getClass().getDeclaredField("customizedIcon");
                declaredField.setAccessible(true);
                declaredField.set(newInstance, Boolean.TRUE);
                Field field = notification.getClass().getField("extraNotification");
                field.setAccessible(true);
                field.set(notification, newInstance);
            } catch (Throwable unused) {
            }
        }
    }

    static void a(s sVar) {
        Notification notification;
        JSONObject jSONObject;
        Bitmap bitmap;
        String str;
        RemoteViews remoteViews;
        s sVar2 = sVar;
        a(sVar2.f2803a);
        if (sVar2.c || !sVar2.d || a.b == null) {
            SecureRandom secureRandom = new SecureRandom();
            int intValue = sVar.c().intValue();
            JSONObject jSONObject2 = sVar2.b;
            String optString = jSONObject2.optString("grp", (String) null);
            a c2 = c(sVar);
            NotificationCompat.Builder builder = c2.f2792a;
            a(jSONObject2, builder, intValue, (String) null);
            int i = 2;
            try {
                if (Build.VERSION.SDK_INT >= 16) {
                    String optString2 = jSONObject2.optString("bg_img", (String) null);
                    if (optString2 != null) {
                        jSONObject = new JSONObject(optString2);
                        bitmap = c(jSONObject.optString("img", (String) null));
                    } else {
                        bitmap = null;
                        jSONObject = null;
                    }
                    if (bitmap == null) {
                        bitmap = a("onesignal_bgimage_default_image");
                    }
                    if (bitmap != null) {
                        RemoteViews remoteViews2 = new RemoteViews(f2788a.getPackageName(), av.b.onesignal_bgimage_notif_layout);
                        remoteViews2.setTextViewText(av.a.os_bgimage_notif_title, b(jSONObject2));
                        remoteViews2.setTextViewText(av.a.os_bgimage_notif_body, jSONObject2.optString("alert"));
                        a(remoteViews2, jSONObject, av.a.os_bgimage_notif_title, "tc", "onesignal_bgimage_notif_title_color");
                        a(remoteViews2, jSONObject, av.a.os_bgimage_notif_body, "bc", "onesignal_bgimage_notif_body_color");
                        if (jSONObject == null || !jSONObject.has("img_align")) {
                            int identifier = c.getIdentifier("onesignal_bgimage_notif_image_align", "string", b);
                            str = identifier != 0 ? c.getString(identifier) : null;
                        } else {
                            str = jSONObject.getString("img_align");
                        }
                        if ("right".equals(str)) {
                            remoteViews = remoteViews2;
                            remoteViews2.setViewPadding(av.a.os_bgimage_notif_bgimage_align_layout, -5000, 0, 0, 0);
                            remoteViews.setImageViewBitmap(av.a.os_bgimage_notif_bgimage_right_aligned, bitmap);
                            remoteViews.setViewVisibility(av.a.os_bgimage_notif_bgimage_right_aligned, 0);
                            remoteViews.setViewVisibility(av.a.os_bgimage_notif_bgimage, 2);
                        } else {
                            remoteViews = remoteViews2;
                            remoteViews.setImageViewBitmap(av.a.os_bgimage_notif_bgimage, bitmap);
                        }
                        builder.setContent(remoteViews);
                        builder.setStyle((NotificationCompat.Style) null);
                    }
                }
            } catch (Throwable th) {
                ai.a(ai.h.ERROR, "Could not set background notification image!", th);
            }
            boolean z = true;
            if (!(sVar2.l == null || sVar2.l.f2706a == null)) {
                try {
                    Field declaredField = NotificationCompat.Builder.class.getDeclaredField("mNotification");
                    declaredField.setAccessible(true);
                    Notification notification2 = (Notification) declaredField.get(builder);
                    sVar2.j = Integer.valueOf(notification2.flags);
                    sVar2.k = notification2.sound;
                    builder.extend(sVar2.l.f2706a);
                    Notification notification3 = (Notification) declaredField.get(builder);
                    Field declaredField2 = NotificationCompat.Builder.class.getDeclaredField("mContentText");
                    declaredField2.setAccessible(true);
                    Field declaredField3 = NotificationCompat.Builder.class.getDeclaredField("mContentTitle");
                    declaredField3.setAccessible(true);
                    sVar2.f = (CharSequence) declaredField2.get(builder);
                    sVar2.g = (CharSequence) declaredField3.get(builder);
                    if (!sVar2.c) {
                        sVar2.i = Integer.valueOf(notification3.flags);
                        sVar2.h = notification3.sound;
                    }
                } catch (Throwable th2) {
                    th2.printStackTrace();
                }
            }
            if (sVar2.c) {
                a(builder);
            }
            if (optString == null) {
                i = 1;
            }
            t.a(f2788a, i);
            if (optString != null) {
                builder.setContentIntent(a(secureRandom.nextInt(), b(intValue).putExtra("onesignal_data", jSONObject2.toString()).putExtra("grp", optString)));
                builder.setDeleteIntent(a(secureRandom.nextInt(), c(intValue).putExtra("grp", optString)));
                builder.setGroup(optString);
                try {
                    builder.setGroupAlertBehavior(1);
                } catch (Throwable unused) {
                }
                if (Build.VERSION.SDK_INT <= 17 || Build.VERSION.SDK_INT >= 24 || sVar2.c) {
                    z = false;
                }
                if (z && sVar2.h != null && !sVar2.h.equals(sVar2.k)) {
                    builder.setSound((Uri) null);
                }
                notification = builder.build();
                if (z) {
                    builder.setSound(sVar2.h);
                }
                a(sVar2, c2);
            } else {
                builder.setContentIntent(a(secureRandom.nextInt(), b(intValue).putExtra("onesignal_data", jSONObject2.toString())));
                builder.setDeleteIntent(a(secureRandom.nextInt(), c(intValue)));
                notification = builder.build();
            }
            if (optString == null || Build.VERSION.SDK_INT > 17) {
                a(c2, notification);
                NotificationManagerCompat.from(f2788a).notify(intValue, notification);
                return;
            }
            return;
        }
        final JSONObject jSONObject3 = sVar2.b;
        final Activity activity = a.b;
        final int intValue2 = sVar.c().intValue();
        activity.runOnUiThread(new Runnable() {
            public final void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle(l.b(jSONObject3));
                builder.setMessage(jSONObject3.optString("alert"));
                ArrayList arrayList = new ArrayList();
                final ArrayList arrayList2 = new ArrayList();
                l.a((Context) activity, jSONObject3, (List) arrayList, (List) arrayList2);
                final Intent a2 = l.b(intValue2);
                a2.putExtra("action_button", true);
                a2.putExtra("from_alert", true);
                a2.putExtra("onesignal_data", jSONObject3.toString());
                if (jSONObject3.has("grp")) {
                    a2.putExtra("grp", jSONObject3.optString("grp"));
                }
                AnonymousClass1 r4 = new DialogInterface.OnClickListener() {
                    public final void onClick(DialogInterface dialogInterface, int i) {
                        int i2 = i + 3;
                        if (arrayList2.size() > 1) {
                            try {
                                JSONObject jSONObject = new JSONObject(jSONObject3.toString());
                                jSONObject.put("actionSelected", arrayList2.get(i2));
                                a2.putExtra("onesignal_data", jSONObject.toString());
                                u.b(activity, a2);
                            } catch (Throwable unused) {
                            }
                        } else {
                            u.b(activity, a2);
                        }
                    }
                };
                builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public final void onCancel(DialogInterface dialogInterface) {
                        u.b(activity, a2);
                    }
                });
                for (int i = 0; i < arrayList.size(); i++) {
                    if (i == 0) {
                        builder.setNeutralButton((CharSequence) arrayList.get(i), r4);
                    } else if (i == 1) {
                        builder.setNegativeButton((CharSequence) arrayList.get(i), r4);
                    } else if (i == 2) {
                        builder.setPositiveButton((CharSequence) arrayList.get(i), r4);
                    }
                }
                AlertDialog create = builder.create();
                create.setCanceledOnTouchOutside(false);
                create.show();
            }
        });
    }

    private static void a(s sVar, a aVar) {
        Cursor cursor;
        Integer num;
        ArrayList<SpannableString> arrayList;
        Notification notification;
        String str;
        String str2;
        String str3;
        s sVar2 = sVar;
        a aVar2 = aVar;
        boolean z = sVar2.c;
        JSONObject jSONObject = sVar2.b;
        String optString = jSONObject.optString("grp", (String) null);
        SecureRandom secureRandom = new SecureRandom();
        PendingIntent a2 = a(secureRandom.nextInt(), c(0).putExtra("summary", optString));
        ak a3 = ak.a(f2788a);
        try {
            SQLiteDatabase b2 = a3.b();
            String[] strArr = {"android_notification_id", "full_data", "is_summary", "title", "message"};
            String str4 = "group_id = ? AND dismissed = 0 AND opened = 0";
            String[] strArr2 = {optString};
            if (!z && sVar.c().intValue() != -1) {
                str4 = str4 + " AND android_notification_id <> " + sVar.c();
            }
            int i = 1;
            try {
                cursor = b2.query("notification", strArr, str4, strArr2, (String) null, (String) null, "_id DESC");
                try {
                    if (cursor.moveToFirst()) {
                        arrayList = new ArrayList<>();
                        String str5 = null;
                        num = null;
                        while (true) {
                            if (cursor.getInt(cursor.getColumnIndex("is_summary")) == i) {
                                num = Integer.valueOf(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
                            } else {
                                String string = cursor.getString(cursor.getColumnIndex("title"));
                                if (string == null) {
                                    str3 = "";
                                } else {
                                    str3 = string + " ";
                                }
                                SpannableString spannableString = new SpannableString(str3 + cursor.getString(cursor.getColumnIndex("message")));
                                if (str3.length() > 0) {
                                    spannableString.setSpan(new StyleSpan(1), 0, str3.length(), 0);
                                }
                                arrayList.add(spannableString);
                                if (str5 == null) {
                                    str5 = cursor.getString(cursor.getColumnIndex("full_data"));
                                }
                            }
                            if (!cursor.moveToNext()) {
                                break;
                            }
                            i = 1;
                        }
                        if (z && str5 != null) {
                            jSONObject = new JSONObject(str5);
                        }
                    } else {
                        arrayList = null;
                        num = null;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                } catch (Throwable th) {
                    th = th;
                }
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
                if (num == null) {
                    num = Integer.valueOf(secureRandom.nextInt());
                    a(a3, optString, num.intValue());
                }
                PendingIntent a4 = a(secureRandom.nextInt(), a(num.intValue(), jSONObject, optString));
                if (arrayList == null || ((!z || arrayList.size() <= 1) && (z || arrayList.size() <= 0))) {
                    NotificationCompat.Builder builder = aVar2.f2792a;
                    builder.mActions.clear();
                    a(jSONObject, builder, num.intValue(), optString);
                    builder.setContentIntent(a4).setDeleteIntent(a2).setOnlyAlertOnce(z).setGroup(optString).setGroupSummary(true);
                    try {
                        builder.setGroupAlertBehavior(1);
                    } catch (Throwable unused) {
                    }
                    notification = builder.build();
                    a(aVar2, notification);
                } else {
                    int size = arrayList.size() + (z ^ true ? 1 : 0);
                    String optString2 = jSONObject.optString("grp_msg", (String) null);
                    if (optString2 == null) {
                        str = size + " new messages";
                    } else {
                        str = optString2.replace("$[notif_count]", String.valueOf(size));
                    }
                    NotificationCompat.Builder builder2 = c(sVar).f2792a;
                    if (z) {
                        a(builder2);
                    } else {
                        if (sVar2.h != null) {
                            builder2.setSound(sVar2.h);
                        }
                        if (sVar2.i != null) {
                            builder2.setDefaults(sVar2.i.intValue());
                        }
                    }
                    builder2.setContentIntent(a4).setDeleteIntent(a2).setContentTitle(f2788a.getPackageManager().getApplicationLabel(f2788a.getApplicationInfo())).setContentText(str).setNumber(size).setSmallIcon(b()).setLargeIcon(a()).setOnlyAlertOnce(z).setGroup(optString).setGroupSummary(true);
                    try {
                        builder2.setGroupAlertBehavior(1);
                    } catch (Throwable unused2) {
                    }
                    if (!z) {
                        builder2.setTicker(str);
                    }
                    NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();
                    if (!z) {
                        String charSequence = sVar.a() != null ? sVar.a().toString() : null;
                        if (charSequence == null) {
                            str2 = "";
                        } else {
                            str2 = charSequence + " ";
                        }
                        SpannableString spannableString2 = new SpannableString(str2 + sVar.b().toString());
                        if (str2.length() > 0) {
                            spannableString2.setSpan(new StyleSpan(1), 0, str2.length(), 0);
                        }
                        inboxStyle.addLine(spannableString2);
                    }
                    for (SpannableString addLine : arrayList) {
                        inboxStyle.addLine(addLine);
                    }
                    inboxStyle.setBigContentTitle(str);
                    builder2.setStyle(inboxStyle);
                    notification = builder2.build();
                }
                NotificationManagerCompat.from(f2788a).notify(num.intValue(), notification);
            } catch (Throwable th2) {
                th = th2;
                cursor = null;
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            cursor.close();
            throw th;
        }
    }

    private static void a(JSONObject jSONObject, NotificationCompat.Builder builder, int i, String str) {
        try {
            JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
            if (jSONObject2.has("a")) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject("a");
                if (jSONObject3.has("actionButtons")) {
                    JSONArray jSONArray = jSONObject3.getJSONArray("actionButtons");
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        JSONObject optJSONObject = jSONArray.optJSONObject(i2);
                        JSONObject jSONObject4 = new JSONObject(jSONObject.toString());
                        Intent b2 = b(i);
                        b2.setAction(String.valueOf(i2));
                        b2.putExtra("action_button", true);
                        jSONObject4.put("actionSelected", optJSONObject.optString("id"));
                        b2.putExtra("onesignal_data", jSONObject4.toString());
                        if (str != null) {
                            b2.putExtra("summary", str);
                        } else if (jSONObject.has("grp")) {
                            b2.putExtra("grp", jSONObject.optString("grp"));
                        }
                        builder.addAction(optJSONObject.has("icon") ? d(optJSONObject.optString("icon")) : 0, optJSONObject.optString("text"), a(i, b2));
                    }
                }
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    private static int b() {
        int e2 = e("ic_stat_onesignal_default");
        if (e2 != 0) {
            return e2;
        }
        int e3 = e("corona_statusbar_icon_default");
        if (e3 != 0) {
            return e3;
        }
        int e4 = e("ic_os_notification_fallback_white_24dp");
        if (e4 != 0) {
            return e4;
        }
        return 17301598;
    }

    /* access modifiers changed from: private */
    public static Intent b(int i) {
        Intent putExtra = new Intent(f2788a, d).putExtra("notificationId", i);
        return e ? putExtra : putExtra.addFlags(603979776);
    }

    private static Bitmap b(String str) {
        try {
            return BitmapFactory.decodeStream(new URL(str).openConnection().getInputStream());
        } catch (Throwable th) {
            ai.a(ai.h.WARN, "Could not download image!", th);
            return null;
        }
    }

    /* access modifiers changed from: private */
    public static CharSequence b(JSONObject jSONObject) {
        String optString = jSONObject.optString("title", (String) null);
        return optString != null ? optString : f2788a.getPackageManager().getApplicationLabel(f2788a.getApplicationInfo());
    }

    static void b(s sVar) {
        a(sVar.f2803a);
        a(sVar, (a) null);
    }

    private static Intent c(int i) {
        Intent putExtra = new Intent(f2788a, d).putExtra("notificationId", i).putExtra("dismissed", true);
        return e ? putExtra : putExtra.addFlags(402718720);
    }

    private static Bitmap c(String str) {
        if (str == null) {
            return null;
        }
        String trim = str.trim();
        return (trim.startsWith("http://") || trim.startsWith("https://")) ? b(trim) : a(str);
    }

    private static a c(s sVar) {
        NotificationCompat.Builder builder;
        JSONObject jSONObject = sVar.b;
        boolean z = false;
        a aVar = new a((byte) 0);
        try {
            builder = new NotificationCompat.Builder(f2788a, r.a(sVar));
        } catch (Throwable unused) {
            builder = new NotificationCompat.Builder(f2788a);
        }
        String optString = jSONObject.optString("alert", (String) null);
        NotificationCompat.Builder autoCancel = builder.setAutoCancel(true);
        int d2 = d(jSONObject.optString("sicon", (String) null));
        if (d2 == 0) {
            d2 = b();
        }
        autoCancel.setSmallIcon(d2).setStyle(new NotificationCompat.BigTextStyle().bigText(optString)).setContentText(optString).setTicker(optString);
        if (Build.VERSION.SDK_INT < 24 || !jSONObject.optString("title").equals("")) {
            builder.setContentTitle(b(jSONObject));
        }
        try {
            BigInteger c2 = c(jSONObject);
            if (c2 != null) {
                builder.setColor(c2.intValue());
            }
        } catch (Throwable unused2) {
        }
        try {
            builder.setVisibility(jSONObject.has("vis") ? Integer.parseInt(jSONObject.optString("vis")) : 1);
        } catch (Throwable unused3) {
        }
        Bitmap c3 = c(jSONObject.optString("licon"));
        if (c3 == null) {
            c3 = a("ic_onesignal_large_icon_default");
        }
        Bitmap a2 = c3 == null ? null : a(c3);
        if (a2 != null) {
            aVar.b = true;
            builder.setLargeIcon(a2);
        }
        Bitmap c4 = c(jSONObject.optString("bicon", (String) null));
        if (c4 != null) {
            builder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(c4).setSummaryText(optString));
        }
        if (sVar.e != null) {
            try {
                builder.setWhen(sVar.e.longValue() * 1000);
            } catch (Throwable unused4) {
            }
        }
        int optInt = jSONObject.optInt("pri", 6);
        int i = 4;
        int i2 = optInt > 9 ? 2 : optInt > 7 ? 1 : optInt > 4 ? 0 : optInt > 2 ? -1 : -2;
        builder.setPriority(i2);
        if (!(i2 < 0)) {
            if (jSONObject.has("ledc") && jSONObject.optInt("led", 1) == 1) {
                try {
                    builder.setLights(new BigInteger(jSONObject.optString("ledc"), 16).intValue(), AdError.SERVER_ERROR_CODE, 5000);
                    i = 0;
                } catch (Throwable unused5) {
                }
            }
            if (ai.l() && jSONObject.optInt("vib", 1) == 1) {
                if (jSONObject.has("vib_pt")) {
                    long[] a3 = ah.a(jSONObject);
                    if (a3 != null) {
                        builder.setVibrate(a3);
                    }
                } else {
                    i |= 2;
                }
            }
            String optString2 = jSONObject.optString("sound", (String) null);
            if (!"null".equals(optString2) && !"nil".equals(optString2)) {
                z = ai.m();
            }
            if (z) {
                Uri b2 = ah.b(f2788a, jSONObject.optString("sound", (String) null));
                if (b2 != null) {
                    builder.setSound(b2);
                } else {
                    i |= 1;
                }
            }
            builder.setDefaults(i);
        }
        aVar.f2792a = builder;
        return aVar;
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:6:0x0017 */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0021 A[Catch:{ Throwable -> 0x0027 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.math.BigInteger c(org.json.JSONObject r4) {
        /*
            r0 = 16
            r1 = 0
            java.lang.String r2 = "bgac"
            boolean r2 = r4.has(r2)     // Catch:{ Throwable -> 0x0017 }
            if (r2 == 0) goto L_0x0017
            java.math.BigInteger r2 = new java.math.BigInteger     // Catch:{ Throwable -> 0x0017 }
            java.lang.String r3 = "bgac"
            java.lang.String r4 = r4.optString(r3, r1)     // Catch:{ Throwable -> 0x0017 }
            r2.<init>(r4, r0)     // Catch:{ Throwable -> 0x0017 }
            return r2
        L_0x0017:
            android.content.Context r4 = f2788a     // Catch:{ Throwable -> 0x0027 }
            java.lang.String r2 = "com.onesignal.NotificationAccentColor.DEFAULT"
            java.lang.String r4 = com.onesignal.ah.a(r4, r2)     // Catch:{ Throwable -> 0x0027 }
            if (r4 == 0) goto L_0x0027
            java.math.BigInteger r2 = new java.math.BigInteger     // Catch:{ Throwable -> 0x0027 }
            r2.<init>(r4, r0)     // Catch:{ Throwable -> 0x0027 }
            return r2
        L_0x0027:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.l.c(org.json.JSONObject):java.math.BigInteger");
    }

    private static int d(String str) {
        if (str == null) {
            return 0;
        }
        String trim = str.trim();
        if (!ah.a(trim)) {
            return 0;
        }
        int e2 = e(trim);
        if (e2 != 0) {
            return e2;
        }
        try {
            return R.drawable.class.getField(str).getInt((Object) null);
        } catch (Throwable unused) {
            return 0;
        }
    }

    private static int e(String str) {
        return c.getIdentifier(str, "drawable", b);
    }
}
