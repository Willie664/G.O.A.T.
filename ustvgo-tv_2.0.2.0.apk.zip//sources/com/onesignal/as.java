package com.onesignal;

import android.content.Context;
import com.amazon.device.messaging.ADM;
import com.onesignal.ai;
import com.onesignal.ar;

public final class as implements ar {

    /* renamed from: a  reason: collision with root package name */
    private static ar.a f2759a = null;
    /* access modifiers changed from: private */
    public static boolean b = false;

    public static void a(String str) {
        if (f2759a != null) {
            b = true;
            f2759a.a(str, 1);
        }
    }

    public final void a(final Context context, String str, final ar.a aVar) {
        f2759a = aVar;
        new Thread(new Runnable() {
            public final void run() {
                ADM adm = new ADM(context);
                String registrationId = adm.getRegistrationId();
                if (registrationId == null) {
                    adm.startRegister();
                } else {
                    ai.a(ai.h.DEBUG, "ADM Already registered with ID:".concat(String.valueOf(registrationId)));
                    aVar.a(registrationId, 1);
                }
                try {
                    Thread.sleep(30000);
                } catch (InterruptedException unused) {
                }
                if (!as.b) {
                    ai.a(ai.h.ERROR, "com.onesignal.ADMMessageHandler timed out, please check that your have the receiver, service, and your package name matches(NOTE: Case Sensitive) per the OneSignal instructions.");
                    as.a((String) null);
                }
            }
        }).start();
    }
}
