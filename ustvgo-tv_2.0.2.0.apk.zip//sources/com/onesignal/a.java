package com.onesignal;

import android.app.Activity;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.ai;

final class a {

    /* renamed from: a  reason: collision with root package name */
    static boolean f2709a;
    static Activity b;
    static c c = new c();
    private static C0086a d;

    /* renamed from: com.onesignal.a$a  reason: collision with other inner class name */
    interface C0086a {
        void a(Activity activity);
    }

    static class b implements Runnable {
        /* access modifiers changed from: package-private */

        /* renamed from: a  reason: collision with root package name */
        public boolean f2710a;
        boolean b;

        private b() {
        }

        /* synthetic */ b(byte b2) {
            this();
        }

        public final void run() {
            if (a.b == null) {
                this.f2710a = true;
                ai.d();
                this.b = true;
            }
        }
    }

    static class c extends HandlerThread {

        /* renamed from: a  reason: collision with root package name */
        Handler f2711a = null;
        b b;

        c() {
            super("FocusHandlerThread");
            start();
            this.f2711a = new Handler(getLooper());
        }

        /* access modifiers changed from: package-private */
        public final void a(b bVar) {
            if (this.b == null || !this.b.f2710a || this.b.b) {
                this.b = bVar;
                this.f2711a.removeCallbacksAndMessages((Object) null);
                this.f2711a.postDelayed(bVar, 2000);
            }
        }
    }

    public static void a() {
        d = null;
    }

    static void a(Activity activity) {
        b = activity;
        if (d != null) {
            d.a(b);
        }
        d();
        c cVar = c;
        if ((cVar.b != null && cVar.b.f2710a) || f2709a) {
            f2709a = false;
            c cVar2 = c;
            if (cVar2.b != null) {
                boolean unused = cVar2.b.f2710a = false;
            }
            ai.e();
            return;
        }
        c.f2711a.removeCallbacksAndMessages((Object) null);
    }

    static void a(C0086a aVar) {
        if (b != null) {
            aVar.a(b);
        }
        d = aVar;
    }

    static void b() {
    }

    static void b(Activity activity) {
        if (activity == b) {
            b = null;
            e();
        }
        d();
    }

    static void c() {
    }

    static void c(Activity activity) {
        ai.h hVar = ai.h.DEBUG;
        ai.a(hVar, "onActivityStopped: " + activity.getClass().getName());
        if (activity == b) {
            b = null;
            e();
        }
        d();
    }

    private static void d() {
        String str;
        ai.h hVar = ai.h.DEBUG;
        StringBuilder sb = new StringBuilder("curActivity is NOW: ");
        if (b != null) {
            str = b.getClass().getName() + ":" + b;
        } else {
            str = "null";
        }
        sb.append(str);
        ai.a(hVar, sb.toString());
    }

    static void d(Activity activity) {
        ai.h hVar = ai.h.DEBUG;
        ai.a(hVar, "onActivityDestroyed: " + activity.getClass().getName());
        if (activity == b) {
            b = null;
            e();
        }
        d();
    }

    private static void e() {
        c.a(new b((byte) 0));
    }
}
