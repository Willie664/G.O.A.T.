package com.onesignal;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import com.amazon.device.iap.PurchasingListener;
import com.onesignal.aa;
import com.onesignal.an;
import com.onesignal.ao;
import com.onesignal.ar;
import com.onesignal.ax;
import com.onesignal.bf;
import com.onesignal.p;
import com.onesignal.z;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicLong;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ai {
    private static az A;
    private static ax B;
    private static ay C;
    private static d D = new c();
    private static int E;
    private static ah F;
    /* access modifiers changed from: private */
    public static String G;
    /* access modifiers changed from: private */
    public static boolean H;
    /* access modifiers changed from: private */
    public static boolean I;
    private static boolean J;
    /* access modifiers changed from: private */
    public static p.f K;
    private static Collection<JSONArray> L = new ArrayList();
    private static HashSet<String> M = new HashSet<>();
    /* access modifiers changed from: private */
    public static ArrayList<Object> N = new ArrayList<>();
    /* access modifiers changed from: private */
    public static boolean O;
    private static boolean P;
    private static ae Q;
    private static ad<Object, af> R;
    private static OSSubscriptionState S;
    private static ad<Object, ag> T;
    private static y U;
    private static f V;
    private static ar W;

    /* renamed from: a  reason: collision with root package name */
    static String f2723a;
    static Context b;
    static boolean c;
    static ExecutorService d;
    public static ConcurrentLinkedQueue<Runnable> e = new ConcurrentLinkedQueue<>();
    static AtomicLong f = new AtomicLong();
    public static String g = "native";
    static boolean h = true;
    static a i;
    static boolean j = false;
    static k k;
    static an.b l;
    static ae m;
    static OSSubscriptionState n;
    private static e o;
    private static e p;
    /* access modifiers changed from: private */
    public static String q;
    private static h r = h.NONE;
    private static h s = h.WARN;
    /* access modifiers changed from: private */
    public static String t = null;
    private static String u = null;
    /* access modifiers changed from: private */
    public static int v;
    private static boolean w;
    private static g x;
    private static long y = 1;
    private static long z = -1;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        Context f2728a;
        public i b;
        j c;
        boolean d;
        boolean e;
        public boolean f;
        boolean g;
        public boolean h;
        public int i;

        private a() {
            this.i = k.b;
        }

        /* synthetic */ a(byte b2) {
            this();
        }

        private a(Context context) {
            this.i = k.b;
            this.f2728a = context;
        }

        /* synthetic */ a(Context context, byte b2) {
            this(context);
        }
    }

    public interface b {
    }

    public enum c {
        ;
        

        /* renamed from: a  reason: collision with root package name */
        public static final int f2729a = 1;
        public static final int b = 2;
        public static final int c = 3;
        public static final int d = 4;

        static {
            e = new int[]{f2729a, b, c, d};
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        private int f2730a;
        private String b;

        d(int i, String str) {
            this.f2730a = i;
            this.b = str;
        }
    }

    public interface e {
    }

    static class f {

        /* renamed from: a  reason: collision with root package name */
        JSONArray f2731a;
        boolean b;
        ao.a c;

        f(JSONArray jSONArray) {
            this.f2731a = jSONArray;
        }
    }

    public interface g {
    }

    public enum h {
        NONE,
        FATAL,
        ERROR,
        WARN,
        INFO,
        DEBUG,
        VERBOSE
    }

    public interface i {
        void a(ab abVar);
    }

    public interface j {
    }

    public enum k {
        ;
        

        /* renamed from: a  reason: collision with root package name */
        public static final int f2733a = 1;
        public static final int b = 2;
        public static final int c = 3;

        static {
            d = new int[]{f2733a, b, c};
        }
    }

    static class l implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private Runnable f2734a;
        /* access modifiers changed from: private */
        public long b;

        l(Runnable runnable) {
            this.f2734a = runnable;
        }

        public final void run() {
            this.f2734a.run();
            ai.b(this.b);
        }
    }

    public static class m {

        /* renamed from: a  reason: collision with root package name */
        private String f2735a;
        private int b;

        m(int i, String str) {
            this.f2735a = str;
            this.b = i;
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(16:0|(1:2)|3|(1:5)|6|7|8|9|10|(4:13|(2:15|27)(1:28)|16|11)|26|17|18|(1:23)|24|25) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0080 */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0096 A[Catch:{ Throwable -> 0x00c3 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static /* synthetic */ void C() {
        /*
            android.content.Context r0 = b
            java.lang.String r0 = r0.getPackageName()
            android.content.Context r1 = b
            android.content.pm.PackageManager r1 = r1.getPackageManager()
            org.json.JSONObject r2 = new org.json.JSONObject
            r2.<init>()
            java.lang.String r3 = "app_id"
            java.lang.String r4 = f2723a
            r2.put(r3, r4)
            com.onesignal.d r3 = D
            android.content.Context r4 = b
            java.lang.String r3 = r3.a(r4)
            if (r3 == 0) goto L_0x0027
            java.lang.String r4 = "ad_id"
            r2.put(r4, r3)
        L_0x0027:
            java.lang.String r3 = "device_os"
            java.lang.String r4 = android.os.Build.VERSION.RELEASE
            r2.put(r3, r4)
            java.lang.String r3 = "timezone"
            java.util.Calendar r4 = java.util.Calendar.getInstance()
            java.util.TimeZone r4 = r4.getTimeZone()
            int r5 = r4.getRawOffset()
            java.util.Date r6 = new java.util.Date
            r6.<init>()
            boolean r6 = r4.inDaylightTime(r6)
            if (r6 == 0) goto L_0x004c
            int r4 = r4.getDSTSavings()
            int r5 = r5 + r4
        L_0x004c:
            int r5 = r5 / 1000
            r2.put(r3, r5)
            java.lang.String r3 = "language"
            java.lang.String r4 = com.onesignal.ah.d()
            r2.put(r3, r4)
            java.lang.String r3 = "sdk"
            java.lang.String r4 = "031008"
            r2.put(r3, r4)
            java.lang.String r3 = "sdk_type"
            java.lang.String r4 = g
            r2.put(r3, r4)
            java.lang.String r3 = "android_package"
            r2.put(r3, r0)
            java.lang.String r3 = "device_model"
            java.lang.String r4 = android.os.Build.MODEL
            r2.put(r3, r4)
            r3 = 0
            java.lang.String r4 = "game_version"
            android.content.pm.PackageInfo r0 = r1.getPackageInfo(r0, r3)     // Catch:{ NameNotFoundException -> 0x0080 }
            int r0 = r0.versionCode     // Catch:{ NameNotFoundException -> 0x0080 }
            r2.put(r4, r0)     // Catch:{ NameNotFoundException -> 0x0080 }
        L_0x0080:
            java.util.List r0 = r1.getInstalledPackages(r3)     // Catch:{ Throwable -> 0x00c3 }
            org.json.JSONArray r1 = new org.json.JSONArray     // Catch:{ Throwable -> 0x00c3 }
            r1.<init>()     // Catch:{ Throwable -> 0x00c3 }
            java.lang.String r4 = "SHA-256"
            java.security.MessageDigest r4 = java.security.MessageDigest.getInstance(r4)     // Catch:{ Throwable -> 0x00c3 }
            r5 = 0
        L_0x0090:
            int r6 = r0.size()     // Catch:{ Throwable -> 0x00c3 }
            if (r5 >= r6) goto L_0x00be
            java.lang.Object r6 = r0.get(r5)     // Catch:{ Throwable -> 0x00c3 }
            android.content.pm.PackageInfo r6 = (android.content.pm.PackageInfo) r6     // Catch:{ Throwable -> 0x00c3 }
            java.lang.String r6 = r6.packageName     // Catch:{ Throwable -> 0x00c3 }
            byte[] r6 = r6.getBytes()     // Catch:{ Throwable -> 0x00c3 }
            r4.update(r6)     // Catch:{ Throwable -> 0x00c3 }
            byte[] r6 = r4.digest()     // Catch:{ Throwable -> 0x00c3 }
            r7 = 2
            java.lang.String r6 = android.util.Base64.encodeToString(r6, r7)     // Catch:{ Throwable -> 0x00c3 }
            com.onesignal.an$b r7 = l     // Catch:{ Throwable -> 0x00c3 }
            org.json.JSONObject r7 = r7.e     // Catch:{ Throwable -> 0x00c3 }
            boolean r7 = r7.has(r6)     // Catch:{ Throwable -> 0x00c3 }
            if (r7 == 0) goto L_0x00bb
            r1.put(r6)     // Catch:{ Throwable -> 0x00c3 }
        L_0x00bb:
            int r5 = r5 + 1
            goto L_0x0090
        L_0x00be:
            java.lang.String r0 = "pkgs"
            r2.put(r0, r1)     // Catch:{ Throwable -> 0x00c3 }
        L_0x00c3:
            java.lang.String r0 = "net_type"
            java.lang.Integer r1 = com.onesignal.ah.b()
            r2.put(r0, r1)
            java.lang.String r0 = "carrier"
            java.lang.String r1 = com.onesignal.ah.c()
            r2.put(r0, r1)
            java.lang.String r0 = "rooted"
            boolean r1 = com.onesignal.aw.a()
            r2.put(r0, r1)
            com.onesignal.be r0 = com.onesignal.ap.a()
            r0.e(r2)
            com.onesignal.bc r0 = com.onesignal.ap.b()
            r0.e(r2)
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            java.lang.String r1 = "identifier"
            java.lang.String r2 = G
            r0.put(r1, r2)
            java.lang.String r1 = "subscribableStatus"
            int r2 = v
            r0.put(r1, r2)
            java.lang.String r1 = "androidPermission"
            boolean r2 = r()
            r0.put(r1, r2)
            java.lang.String r1 = "device_type"
            int r2 = E
            r0.put(r1, r2)
            com.onesignal.be r1 = com.onesignal.ap.a()
            r1.a((org.json.JSONObject) r0)
            boolean r0 = h
            if (r0 == 0) goto L_0x0123
            com.onesignal.p$f r0 = K
            if (r0 == 0) goto L_0x0123
            com.onesignal.p$f r0 = K
            com.onesignal.ap.a(r0)
        L_0x0123:
            com.onesignal.be r0 = com.onesignal.ap.a()
            r0.m()
            com.onesignal.bc r0 = com.onesignal.ap.b()
            r0.m()
            P = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.C():void");
    }

    private static boolean I() {
        if (c && d == null) {
            return false;
        }
        if (c || d != null) {
            return d != null && !d.isShutdown();
        }
        return true;
    }

    private static void J() {
        if (!P) {
            boolean z2 = true;
            P = true;
            if (ap.a().k() || ap.b().k()) {
                I = false;
            }
            AnonymousClass6 r1 = new p.d() {
                public final p.a a() {
                    return p.a.STARTUP;
                }

                public final void a(p.f fVar) {
                    p.f unused = ai.K = fVar;
                    boolean unused2 = ai.I = true;
                    ai.x();
                }
            };
            boolean z3 = i.d && !J;
            if (!J && !i.d) {
                z2 = false;
            }
            J = z2;
            p.a(b, z3, r1);
            H = false;
            if (l != null) {
                K();
            } else {
                an.a(new an.a() {
                    public final void a(an.b bVar) {
                        ai.l = bVar;
                        if (bVar.b != null) {
                            String unused = ai.q = ai.l.b;
                        }
                        am.a(am.f2741a, "GT_FIREBASE_TRACKING_ENABLED", ai.l.g);
                        am.a(am.f2741a, "OS_RESTORE_TTL_FILTER", ai.l.h);
                        Context context = ai.b;
                        JSONArray jSONArray = bVar.f;
                        if (Build.VERSION.SDK_INT >= 26 && jSONArray != null) {
                            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
                            HashSet hashSet = new HashSet();
                            int length = jSONArray.length();
                            for (int i = 0; i < length; i++) {
                                try {
                                    hashSet.add(r.a(context, notificationManager, jSONArray.getJSONObject(i)));
                                } catch (JSONException e) {
                                    ai.a(h.ERROR, "Could not create notification channel due to JSON payload error!", (Throwable) e);
                                }
                            }
                            for (NotificationChannel id : notificationManager.getNotificationChannels()) {
                                String id2 = id.getId();
                                if (id2.startsWith("OS_") && !hashSet.contains(id2)) {
                                    notificationManager.deleteNotificationChannel(id2);
                                }
                            }
                        }
                        ai.K();
                    }
                });
            }
        }
    }

    /* access modifiers changed from: private */
    public static void K() {
        if (W == null) {
            W = E == 2 ? new as() : new au();
        }
        W.a(b, q, new ar.a() {
            public final void a(String str, int i) {
                if (i > 0 ? ai.b(ai.v) : !(ap.a().e() != null || (ai.v != 1 && !ai.b(ai.v)))) {
                    int unused = ai.v = i;
                }
                String unused2 = ai.G = str;
                boolean unused3 = ai.H = true;
                OSSubscriptionState c = ai.e(ai.b);
                if (str != null) {
                    boolean equals = true ^ str.equals(c.e);
                    c.e = str;
                    if (equals) {
                        c.f2707a.b(c);
                    }
                }
                ai.x();
            }
        });
    }

    private static void L() {
        for (JSONArray a2 : L) {
            a(a2, false);
        }
        L.clear();
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002a, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized void M() {
        /*
            java.lang.Class<com.onesignal.ai> r0 = com.onesignal.ai.class
            monitor-enter(r0)
            com.onesignal.ai$g r1 = x     // Catch:{ all -> 0x002b }
            if (r1 != 0) goto L_0x0009
            monitor-exit(r0)
            return
        L_0x0009:
            com.onesignal.be r1 = com.onesignal.ap.a()     // Catch:{ all -> 0x002b }
            java.lang.String r1 = r1.e()     // Catch:{ all -> 0x002b }
            com.onesignal.be r2 = com.onesignal.ap.a()     // Catch:{ all -> 0x002b }
            boolean r2 = r2.a()     // Catch:{ all -> 0x002b }
            r3 = 0
            if (r2 != 0) goto L_0x001d
            r1 = r3
        L_0x001d:
            java.lang.String r2 = i()     // Catch:{ all -> 0x002b }
            if (r2 != 0) goto L_0x0025
            monitor-exit(r0)
            return
        L_0x0025:
            if (r1 == 0) goto L_0x0029
            x = r3     // Catch:{ all -> 0x002b }
        L_0x0029:
            monitor-exit(r0)
            return
        L_0x002b:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.M():void");
    }

    private static boolean N() {
        return am.b(am.f2741a, "ONESIGNAL_USER_PROVIDED_CONSENT", false);
    }

    private static boolean O() {
        return am.b(am.f2741a, "GT_FIREBASE_TRACKING_ENABLED", false);
    }

    private static long P() {
        return am.b(am.f2741a, "OS_LAST_SESSION_TIME", -31000);
    }

    private static boolean Q() {
        return (System.currentTimeMillis() - P()) / 1000 >= 30;
    }

    static ad<Object, af> a() {
        if (R == null) {
            R = new ad<>("onOSPermissionChanged", true);
        }
        return R;
    }

    static String a(Bundle bundle) {
        h hVar;
        String str;
        if (bundle.isEmpty()) {
            return null;
        }
        try {
            if (bundle.containsKey("custom")) {
                JSONObject jSONObject = new JSONObject(bundle.getString("custom"));
                if (jSONObject.has("i")) {
                    return jSONObject.optString("i", (String) null);
                }
                hVar = h.DEBUG;
                str = "Not a OneSignal formatted GCM message. No 'i' field in custom.";
            } else {
                hVar = h.DEBUG;
                str = "Not a OneSignal formatted GCM message. No 'custom' field in the bundle.";
            }
            a(hVar, str, (Throwable) null);
        } catch (Throwable th) {
            a(h.DEBUG, "Could not parse bundle, probably not a OneSignal notification.", th);
        }
        return null;
    }

    private static String a(JSONObject jSONObject) {
        try {
            return new JSONObject(jSONObject.optString("custom")).optString("i", (String) null);
        } catch (Throwable unused) {
            return null;
        }
    }

    public static void a(final int i2) {
        AnonymousClass8 r0 = new Runnable() {
            /* JADX WARNING: Removed duplicated region for block: B:25:0x00ad A[SYNTHETIC, Splitter:B:25:0x00ad] */
            /* JADX WARNING: Removed duplicated region for block: B:32:0x00cb A[SYNTHETIC, Splitter:B:32:0x00cb] */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public final void run() {
                /*
                    r12 = this;
                    android.content.Context r0 = com.onesignal.ai.b
                    com.onesignal.ak r0 = com.onesignal.ak.a(r0)
                    r1 = 0
                    android.database.sqlite.SQLiteDatabase r0 = r0.a()     // Catch:{ Throwable -> 0x008d, all -> 0x0088 }
                    r0.beginTransaction()     // Catch:{ Throwable -> 0x0086 }
                    java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r3 = "android_notification_id = "
                    r2.<init>(r3)     // Catch:{ Throwable -> 0x0086 }
                    int r3 = r4     // Catch:{ Throwable -> 0x0086 }
                    r2.append(r3)     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r3 = " AND opened = 0 AND dismissed = 0"
                    r2.append(r3)     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r2 = r2.toString()     // Catch:{ Throwable -> 0x0086 }
                    android.content.ContentValues r3 = new android.content.ContentValues     // Catch:{ Throwable -> 0x0086 }
                    r3.<init>()     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r4 = "dismissed"
                    r10 = 1
                    java.lang.Integer r5 = java.lang.Integer.valueOf(r10)     // Catch:{ Throwable -> 0x0086 }
                    r3.put(r4, r5)     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r4 = "notification"
                    int r1 = r0.update(r4, r3, r2, r1)     // Catch:{ Throwable -> 0x0086 }
                    if (r1 <= 0) goto L_0x0076
                    android.content.Context r1 = com.onesignal.ai.b     // Catch:{ Throwable -> 0x0086 }
                    int r2 = r4     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r3 = "notification"
                    java.lang.String[] r4 = new java.lang.String[r10]     // Catch:{ Throwable -> 0x0086 }
                    r5 = 0
                    java.lang.String r6 = "group_id"
                    r4[r5] = r6     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r5 = "android_notification_id = "
                    java.lang.String r2 = java.lang.String.valueOf(r2)     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r5 = r5.concat(r2)     // Catch:{ Throwable -> 0x0086 }
                    r6 = 0
                    r7 = 0
                    r8 = 0
                    r9 = 0
                    r2 = r0
                    android.database.Cursor r2 = r2.query(r3, r4, r5, r6, r7, r8, r9)     // Catch:{ Throwable -> 0x0086 }
                    boolean r3 = r2.moveToFirst()     // Catch:{ Throwable -> 0x0086 }
                    if (r3 == 0) goto L_0x0073
                    java.lang.String r3 = "group_id"
                    int r3 = r2.getColumnIndex(r3)     // Catch:{ Throwable -> 0x0086 }
                    java.lang.String r3 = r2.getString(r3)     // Catch:{ Throwable -> 0x0086 }
                    r2.close()     // Catch:{ Throwable -> 0x0086 }
                    if (r3 == 0) goto L_0x0076
                    com.onesignal.w.a(r1, r0, r3, r10)     // Catch:{ Throwable -> 0x0086 }
                    goto L_0x0076
                L_0x0073:
                    r2.close()     // Catch:{ Throwable -> 0x0086 }
                L_0x0076:
                    android.content.Context r1 = com.onesignal.ai.b     // Catch:{ Throwable -> 0x0086 }
                    com.onesignal.f.a((android.database.sqlite.SQLiteDatabase) r0, (android.content.Context) r1)     // Catch:{ Throwable -> 0x0086 }
                    r0.setTransactionSuccessful()     // Catch:{ Throwable -> 0x0086 }
                    if (r0 == 0) goto L_0x00b9
                    r0.endTransaction()     // Catch:{ Throwable -> 0x00b1 }
                    goto L_0x00b9
                L_0x0084:
                    r1 = move-exception
                    goto L_0x00c9
                L_0x0086:
                    r1 = move-exception
                    goto L_0x0091
                L_0x0088:
                    r0 = move-exception
                    r11 = r1
                    r1 = r0
                    r0 = r11
                    goto L_0x00c9
                L_0x008d:
                    r0 = move-exception
                    r11 = r1
                    r1 = r0
                    r0 = r11
                L_0x0091:
                    com.onesignal.ai$h r2 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x0084 }
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0084 }
                    java.lang.String r4 = "Error marking a notification id "
                    r3.<init>(r4)     // Catch:{ all -> 0x0084 }
                    int r4 = r4     // Catch:{ all -> 0x0084 }
                    r3.append(r4)     // Catch:{ all -> 0x0084 }
                    java.lang.String r4 = " as dismissed! "
                    r3.append(r4)     // Catch:{ all -> 0x0084 }
                    java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x0084 }
                    com.onesignal.ai.a((com.onesignal.ai.h) r2, (java.lang.String) r3, (java.lang.Throwable) r1)     // Catch:{ all -> 0x0084 }
                    if (r0 == 0) goto L_0x00b9
                    r0.endTransaction()     // Catch:{ Throwable -> 0x00b1 }
                    goto L_0x00b9
                L_0x00b1:
                    r0 = move-exception
                    com.onesignal.ai$h r1 = com.onesignal.ai.h.ERROR
                    java.lang.String r2 = "Error closing transaction! "
                    com.onesignal.ai.a((com.onesignal.ai.h) r1, (java.lang.String) r2, (java.lang.Throwable) r0)
                L_0x00b9:
                    android.content.Context r0 = com.onesignal.ai.b
                    java.lang.String r1 = "notification"
                    java.lang.Object r0 = r0.getSystemService(r1)
                    android.app.NotificationManager r0 = (android.app.NotificationManager) r0
                    int r1 = r4
                    r0.cancel(r1)
                    return
                L_0x00c9:
                    if (r0 == 0) goto L_0x00d7
                    r0.endTransaction()     // Catch:{ Throwable -> 0x00cf }
                    goto L_0x00d7
                L_0x00cf:
                    r0 = move-exception
                    com.onesignal.ai$h r2 = com.onesignal.ai.h.ERROR
                    java.lang.String r3 = "Error closing transaction! "
                    com.onesignal.ai.a((com.onesignal.ai.h) r2, (java.lang.String) r3, (java.lang.Throwable) r0)
                L_0x00d7:
                    throw r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.AnonymousClass8.run():void");
            }
        };
        if (b == null || I()) {
            h hVar = h.ERROR;
            a(hVar, "OneSignal.init has not been called. Could not clear notification id: " + i2 + " at this time - movingthis operation to a waiting task queue. The notification will still be canceledfrom NotificationManager at this time.", (Throwable) null);
            e.add(r0);
            return;
        }
        r0.run();
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x002b */
    /* JADX WARNING: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038 A[Catch:{ Throwable -> 0x003c }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void a(long r3) {
        /*
            org.json.JSONObject r0 = new org.json.JSONObject     // Catch:{ Throwable -> 0x003c }
            r0.<init>()     // Catch:{ Throwable -> 0x003c }
            java.lang.String r1 = "app_id"
            java.lang.String r2 = f2723a     // Catch:{ Throwable -> 0x003c }
            org.json.JSONObject r0 = r0.put(r1, r2)     // Catch:{ Throwable -> 0x003c }
            java.lang.String r1 = "type"
            r2 = 1
            org.json.JSONObject r0 = r0.put(r1, r2)     // Catch:{ Throwable -> 0x003c }
            java.lang.String r1 = "state"
            java.lang.String r2 = "ping"
            org.json.JSONObject r0 = r0.put(r1, r2)     // Catch:{ Throwable -> 0x003c }
            java.lang.String r1 = "active_time"
            org.json.JSONObject r3 = r0.put(r1, r3)     // Catch:{ Throwable -> 0x003c }
            java.lang.String r4 = "net_type"
            java.lang.Integer r0 = com.onesignal.ah.b()     // Catch:{ Throwable -> 0x002b }
            r3.put(r4, r0)     // Catch:{ Throwable -> 0x002b }
        L_0x002b:
            java.lang.String r4 = i()     // Catch:{ Throwable -> 0x003c }
            a((java.lang.String) r4, (org.json.JSONObject) r3)     // Catch:{ Throwable -> 0x003c }
            java.lang.String r4 = j()     // Catch:{ Throwable -> 0x003c }
            if (r4 == 0) goto L_0x003b
            a((java.lang.String) r4, (org.json.JSONObject) r3)     // Catch:{ Throwable -> 0x003c }
        L_0x003b:
            return
        L_0x003c:
            r3 = move-exception
            com.onesignal.ai$h r4 = com.onesignal.ai.h.ERROR
            java.lang.String r0 = "Generating on_focus:JSON Failed."
            a((com.onesignal.ai.h) r4, (java.lang.String) r0, (java.lang.Throwable) r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.a(long):void");
    }

    public static void a(Context context) {
        if (context == null) {
            a(h.WARN, "setAppContext(null) is not valid, ignoring!", (Throwable) null);
            return;
        }
        boolean z2 = b == null;
        b = context.getApplicationContext();
        if (z2) {
            am.a();
        }
    }

    public static void a(Context context, JSONArray jSONArray, boolean z2) {
        Intent launchIntentForPackage;
        if (!a((String) null)) {
            boolean z3 = false;
            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                try {
                    String optString = new JSONObject(jSONArray.getJSONObject(i2).optString("custom", (String) null)).optString("i", (String) null);
                    if (!M.contains(optString)) {
                        M.add(optString);
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("app_id", f(context));
                        jSONObject.put("player_id", context == null ? "" : am.b(am.f2741a, "GT_PLAYER_ID", (String) null));
                        jSONObject.put("opened", true);
                        new Thread(new Runnable("notifications/".concat(String.valueOf(optString)), jSONObject, new ao.a() {
                            /* access modifiers changed from: package-private */
                            public final void a(int i, String str, Throwable th) {
                                ai.a("sending Notification Opened Failed", i, th, str);
                            }
                        }) {

                            /* renamed from: a */
                            final /* synthetic */ String f2748a;
                            final /* synthetic */ JSONObject b;
                            final /* synthetic */ a c;

                            public final void run(
/*
Method generation error in method: com.onesignal.ao.1.run():void, dex: classes.dex
                            jadx.core.utils.exceptions.JadxRuntimeException: Method args not loaded: com.onesignal.ao.1.run():void, class status: UNLOADED
                            	at jadx.core.dex.nodes.MethodNode.getArgRegs(MethodNode.java:278)
                            	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:116)
                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:313)
                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                            	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                            	at java.util.ArrayList.forEach(ArrayList.java:1257)
                            	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:390)
                            	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                            	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:482)
                            	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:471)
                            	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:151)
                            	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:174)
                            	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                            	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:418)
                            	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                            	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                            	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                            	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                            	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                            	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                            	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                            	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                            	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:640)
                            	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                            	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                            	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                            	at jadx.core.codegen.InsnGen.addArgDot(InsnGen.java:91)
                            	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:697)
                            	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                            	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:311)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:68)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                            	at jadx.core.codegen.RegionGen.makeLoop(RegionGen.java:221)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                            	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                            	at java.util.ArrayList.forEach(ArrayList.java:1257)
                            	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:390)
                            	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                            	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:482)
                            	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:471)
                            	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:151)
                            	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:174)
                            	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                            	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:418)
                            	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                            	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                            	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:112)
                            	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:78)
                            	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:44)
                            	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:33)
                            	at jadx.core.codegen.CodeGen.generate(CodeGen.java:21)
                            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:61)
                            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
                            
*/
                        }).start();
                    }
                } catch (Throwable th) {
                    a(h.ERROR, "Failed to generate JSON to send notification opened.", th);
                }
            }
            if (C != null && O()) {
                ay ayVar = C;
                ab b2 = b(jSONArray, true, z2);
                if (ay.d == null) {
                    ay.d = new AtomicLong();
                }
                ay.d.set(System.currentTimeMillis());
                try {
                    Object a2 = ayVar.a(ayVar.b);
                    Method a3 = ay.a((Class) ay.f2766a);
                    Bundle bundle = new Bundle();
                    bundle.putString("source", "OneSignal");
                    bundle.putString("medium", "notification");
                    bundle.putString("notification_id", b2.f2714a.d.f2715a);
                    bundle.putString("campaign", ay.a(b2.f2714a.d));
                    a3.invoke(a2, new Object[]{"os_notification_opened", bundle});
                } catch (Throwable th2) {
                    th2.printStackTrace();
                }
            }
            boolean equals = "DISABLE".equals(ah.a(context, "com.onesignal.NotificationOpened.DEFAULT"));
            if (!equals) {
                z3 = a(context, jSONArray);
            }
            a(jSONArray, z2);
            if (!z2 && !z3 && !equals && !a((String) null) && (launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName())) != null) {
                launchIntentForPackage.setFlags(268566528);
                context.startActivity(launchIntentForPackage);
            }
        }
    }

    private static void a(final ab abVar) {
        ah.a((Runnable) new Runnable() {
            public final void run() {
                ai.i.b.a(abVar);
            }
        });
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(20:36|(1:38)|(1:40)(1:41)|42|43|44|45|46|47|(2:49|(1:51))(1:52)|53|(3:57|(1:59)|60)|61|(1:63)|64|(1:66)|67|(1:69)|70|(4:72|(2:75|73)|79|84)(1:83)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:46:0x0114 */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x011c A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x014a A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x016d A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0180 A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x018b A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x019a A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01b2 A[Catch:{ Throwable -> 0x01d4 }] */
    /* JADX WARNING: Removed duplicated region for block: B:83:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(com.onesignal.ai.a r7) {
        /*
            com.onesignal.ai$a r0 = c()
            boolean r0 = r0.h
            if (r0 == 0) goto L_0x0010
            com.onesignal.ai$a r0 = c()
            int r0 = r0.i
            r7.i = r0
        L_0x0010:
            i = r7
            android.content.Context r2 = r7.f2728a
            com.onesignal.ai$a r7 = i
            r0 = 0
            r7.f2728a = r0
            android.content.pm.PackageManager r7 = r2.getPackageManager()     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r1 = r2.getPackageName()     // Catch:{ Throwable -> 0x01d4 }
            r3 = 128(0x80, float:1.794E-43)
            android.content.pm.ApplicationInfo r7 = r7.getApplicationInfo(r1, r3)     // Catch:{ Throwable -> 0x01d4 }
            android.os.Bundle r7 = r7.metaData     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r1 = "onesignal_google_project_number"
            java.lang.String r1 = r7.getString(r1)     // Catch:{ Throwable -> 0x01d4 }
            if (r1 == 0) goto L_0x003c
            int r3 = r1.length()     // Catch:{ Throwable -> 0x01d4 }
            r4 = 4
            if (r3 <= r4) goto L_0x003c
            java.lang.String r1 = r1.substring(r4)     // Catch:{ Throwable -> 0x01d4 }
        L_0x003c:
            r3 = r1
            java.lang.String r1 = "com.onesignal.PrivacyConsent"
            java.lang.String r1 = r7.getString(r1)     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r4 = "ENABLE"
            boolean r1 = r4.equalsIgnoreCase(r1)     // Catch:{ Throwable -> 0x01d4 }
            boolean r4 = j     // Catch:{ Throwable -> 0x01d4 }
            if (r4 == 0) goto L_0x0057
            if (r1 != 0) goto L_0x0057
            com.onesignal.ai$h r1 = com.onesignal.ai.h.ERROR     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r4 = "Cannot change requiresUserPrivacyConsent() from TRUE to FALSE"
            a((com.onesignal.ai.h) r1, (java.lang.String) r4, (java.lang.Throwable) r0)     // Catch:{ Throwable -> 0x01d4 }
            goto L_0x0059
        L_0x0057:
            j = r1     // Catch:{ Throwable -> 0x01d4 }
        L_0x0059:
            java.lang.String r1 = "onesignal_app_id"
            java.lang.String r4 = r7.getString(r1)     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$i r5 = r7.b     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$j r6 = r7.c     // Catch:{ Throwable -> 0x01d4 }
            a((android.content.Context) r2)     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = j     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x0084
            boolean r7 = N()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x0084
            com.onesignal.ai$h r7 = com.onesignal.ai.h.VERBOSE     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r1 = "OneSignal SDK initialization delayed, user privacy consent is set to required for this application."
            a((com.onesignal.ai.h) r7, (java.lang.String) r1, (java.lang.Throwable) r0)     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.k r7 = new com.onesignal.k     // Catch:{ Throwable -> 0x01d4 }
            r1 = r7
            r1.<init>(r2, r3, r4, r5, r6)     // Catch:{ Throwable -> 0x01d4 }
            k = r7     // Catch:{ Throwable -> 0x01d4 }
            return
        L_0x0084:
            com.onesignal.ai$a r7 = c()     // Catch:{ Throwable -> 0x01d4 }
            i = r7     // Catch:{ Throwable -> 0x01d4 }
            r1 = 0
            r7.h = r1     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            r7.b = r5     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            r7.c = r6     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.an$b r7 = l     // Catch:{ Throwable -> 0x01d4 }
            r5 = 1
            if (r7 == 0) goto L_0x00a2
            com.onesignal.an$b r7 = l     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r7 = r7.b     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x00a2
            r7 = 1
            goto L_0x00a3
        L_0x00a2:
            r7 = 0
        L_0x00a3:
            if (r7 != 0) goto L_0x00a7
            q = r3     // Catch:{ Throwable -> 0x01d4 }
        L_0x00a7:
            com.onesignal.ah r7 = new com.onesignal.ah     // Catch:{ Throwable -> 0x01d4 }
            r7.<init>()     // Catch:{ Throwable -> 0x01d4 }
            F = r7     // Catch:{ Throwable -> 0x01d4 }
            int r7 = com.onesignal.ah.a()     // Catch:{ Throwable -> 0x01d4 }
            E = r7     // Catch:{ Throwable -> 0x01d4 }
            int r7 = E     // Catch:{ Throwable -> 0x01d4 }
            int r7 = com.onesignal.ah.a((android.content.Context) r2, (int) r7, (java.lang.String) r4)     // Catch:{ Throwable -> 0x01d4 }
            v = r7     // Catch:{ Throwable -> 0x01d4 }
            r3 = -999(0xfffffffffffffc19, float:NaN)
            if (r7 == r3) goto L_0x01d3
            boolean r7 = c     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x00ce
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$i r7 = r7.b     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x00cd
            L()     // Catch:{ Throwable -> 0x01d4 }
        L_0x00cd:
            return
        L_0x00ce:
            boolean r7 = r2 instanceof android.app.Activity     // Catch:{ Throwable -> 0x01d4 }
            w = r7     // Catch:{ Throwable -> 0x01d4 }
            f2723a = r4     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$a r3 = i     // Catch:{ Throwable -> 0x01d4 }
            boolean r3 = r3.g     // Catch:{ Throwable -> 0x01d4 }
            android.content.Context r4 = b     // Catch:{ Throwable -> 0x01d4 }
            if (r4 == 0) goto L_0x00e3
            java.lang.String r4 = com.onesignal.am.f2741a     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r6 = "OS_FILTER_OTHER_GCM_RECEIVERS"
            com.onesignal.am.a((java.lang.String) r4, (java.lang.String) r6, (boolean) r3)     // Catch:{ Throwable -> 0x01d4 }
        L_0x00e3:
            if (r7 == 0) goto L_0x00ef
            android.app.Activity r2 = (android.app.Activity) r2     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.a.b = r2     // Catch:{ Throwable -> 0x01d4 }
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.v.a(r7)     // Catch:{ Throwable -> 0x01d4 }
            goto L_0x00f1
        L_0x00ef:
            com.onesignal.a.f2709a = r5     // Catch:{ Throwable -> 0x01d4 }
        L_0x00f1:
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ Throwable -> 0x01d4 }
            y = r2     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ap.c()     // Catch:{ Throwable -> 0x01d4 }
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            android.app.Application r7 = (android.app.Application) r7     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.b r2 = new com.onesignal.b     // Catch:{ Throwable -> 0x01d4 }
            r2.<init>()     // Catch:{ Throwable -> 0x01d4 }
            r7.registerActivityLifecycleCallbacks(r2)     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r7 = "com.amazon.device.iap.PurchasingListener"
            java.lang.Class.forName(r7)     // Catch:{ ClassNotFoundException -> 0x0114 }
            com.onesignal.ax r7 = new com.onesignal.ax     // Catch:{ ClassNotFoundException -> 0x0114 }
            android.content.Context r2 = b     // Catch:{ ClassNotFoundException -> 0x0114 }
            r7.<init>(r2)     // Catch:{ ClassNotFoundException -> 0x0114 }
            B = r7     // Catch:{ ClassNotFoundException -> 0x0114 }
        L_0x0114:
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r7 = f((android.content.Context) r7)     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x014a
            java.lang.String r1 = f2723a     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = r7.equals(r1)     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x0154
            com.onesignal.ai$h r7 = com.onesignal.ai.h.DEBUG     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r1 = "APP ID changed, clearing user id as it is no longer valid."
            a((com.onesignal.ai.h) r7, (java.lang.String) r1, (java.lang.Throwable) r0)     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r7 = f2723a     // Catch:{ Throwable -> 0x01d4 }
            f((java.lang.String) r7)     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.be r7 = com.onesignal.ap.a()     // Catch:{ Throwable -> 0x01d4 }
            r7.l()     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.bc r7 = com.onesignal.ap.b()     // Catch:{ Throwable -> 0x01d4 }
            r7.l()     // Catch:{ Throwable -> 0x01d4 }
            g(r0)     // Catch:{ Throwable -> 0x01d4 }
            h(r0)     // Catch:{ Throwable -> 0x01d4 }
            r0 = -3660(0xfffffffffffff1b4, double:NaN)
            c((long) r0)     // Catch:{ Throwable -> 0x01d4 }
            goto L_0x0154
        L_0x014a:
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.f.a((int) r1, (android.content.Context) r7)     // Catch:{ Throwable -> 0x01d4 }
            java.lang.String r7 = f2723a     // Catch:{ Throwable -> 0x01d4 }
            f((java.lang.String) r7)     // Catch:{ Throwable -> 0x01d4 }
        L_0x0154:
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ae r7 = d((android.content.Context) r7)     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.OSPermissionChangedInternalObserver.a(r7)     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = w     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x0167
            java.lang.String r7 = i()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x017a
        L_0x0167:
            boolean r7 = Q()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x0170
            com.onesignal.ap.d()     // Catch:{ Throwable -> 0x01d4 }
        L_0x0170:
            long r0 = java.lang.System.currentTimeMillis()     // Catch:{ Throwable -> 0x01d4 }
            c((long) r0)     // Catch:{ Throwable -> 0x01d4 }
            J()     // Catch:{ Throwable -> 0x01d4 }
        L_0x017a:
            com.onesignal.ai$a r7 = i     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.ai$i r7 = r7.b     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x0183
            L()     // Catch:{ Throwable -> 0x01d4 }
        L_0x0183:
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = com.onesignal.az.a((android.content.Context) r7)     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x0194
            com.onesignal.az r7 = new com.onesignal.az     // Catch:{ Throwable -> 0x01d4 }
            android.content.Context r0 = b     // Catch:{ Throwable -> 0x01d4 }
            r7.<init>(r0)     // Catch:{ Throwable -> 0x01d4 }
            A = r7     // Catch:{ Throwable -> 0x01d4 }
        L_0x0194:
            boolean r7 = com.onesignal.ay.a()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 == 0) goto L_0x01a3
            com.onesignal.ay r7 = new com.onesignal.ay     // Catch:{ Throwable -> 0x01d4 }
            android.content.Context r0 = b     // Catch:{ Throwable -> 0x01d4 }
            r7.<init>(r0)     // Catch:{ Throwable -> 0x01d4 }
            C = r7     // Catch:{ Throwable -> 0x01d4 }
        L_0x01a3:
            android.content.Context r7 = b     // Catch:{ Throwable -> 0x01d4 }
            com.onesignal.au.a((android.content.Context) r7)     // Catch:{ Throwable -> 0x01d4 }
            c = r5     // Catch:{ Throwable -> 0x01d4 }
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.Runnable> r7 = e     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = r7.isEmpty()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x01d3
            com.onesignal.ai$1 r7 = new com.onesignal.ai$1     // Catch:{ Throwable -> 0x01d4 }
            r7.<init>()     // Catch:{ Throwable -> 0x01d4 }
            java.util.concurrent.ExecutorService r7 = java.util.concurrent.Executors.newSingleThreadExecutor(r7)     // Catch:{ Throwable -> 0x01d4 }
            d = r7     // Catch:{ Throwable -> 0x01d4 }
        L_0x01bd:
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.Runnable> r7 = e     // Catch:{ Throwable -> 0x01d4 }
            boolean r7 = r7.isEmpty()     // Catch:{ Throwable -> 0x01d4 }
            if (r7 != 0) goto L_0x01d3
            java.util.concurrent.ExecutorService r7 = d     // Catch:{ Throwable -> 0x01d4 }
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.Runnable> r0 = e     // Catch:{ Throwable -> 0x01d4 }
            java.lang.Object r0 = r0.poll()     // Catch:{ Throwable -> 0x01d4 }
            java.lang.Runnable r0 = (java.lang.Runnable) r0     // Catch:{ Throwable -> 0x01d4 }
            r7.submit(r0)     // Catch:{ Throwable -> 0x01d4 }
            goto L_0x01bd
        L_0x01d3:
            return
        L_0x01d4:
            r7 = move-exception
            r7.printStackTrace()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.a(com.onesignal.ai$a):void");
    }

    static void a(h hVar, String str) {
        a(hVar, str, (Throwable) null);
    }

    static void a(final h hVar, String str, Throwable th) {
        if (!(hVar.compareTo(s) > 0 || hVar == h.VERBOSE || hVar == h.DEBUG || hVar == h.INFO)) {
            if (hVar == h.WARN) {
                Log.w("OneSignal", str, th);
            } else if (hVar == h.ERROR || hVar == h.FATAL) {
                Log.e("OneSignal", str, th);
            }
        }
        if (hVar.compareTo(r) <= 0 && a.b != null) {
            try {
                final String str2 = str + "\n";
                if (th != null) {
                    StringWriter stringWriter = new StringWriter();
                    th.printStackTrace(new PrintWriter(stringWriter));
                    str2 = (str2 + th.getMessage()) + stringWriter.toString();
                }
                ah.a((Runnable) new Runnable() {
                    public final void run() {
                        if (a.b != null) {
                            new AlertDialog.Builder(a.b).setTitle(hVar.toString()).setMessage(str2).show();
                        }
                    }
                });
            } catch (Throwable th2) {
                Log.e("OneSignal", "Error showing logging message.", th2);
            }
        }
    }

    static /* synthetic */ void a(String str, int i2, Throwable th, String str2) {
        String str3 = "";
        if (str2 != null) {
            h hVar = h.INFO;
            if (hVar.compareTo(r) <= 0 || hVar.compareTo(s) <= 0) {
                str3 = "\n" + str2 + "\n";
            }
        }
        a(h.WARN, "HTTP code: " + i2 + " " + str + str3, th);
    }

    private static void a(String str, JSONObject jSONObject) {
        ao.c("players/" + str + "/on_focus", jSONObject, new ao.a() {
            /* access modifiers changed from: package-private */
            public final void a(int i, String str, Throwable th) {
                ai.a("sending on_focus Failed", i, th, str);
            }

            /* access modifiers changed from: package-private */
            public final void a(String str) {
                ai.d(0);
            }
        });
    }

    private static void a(JSONArray jSONArray, boolean z2) {
        if (i == null || i.b == null) {
            L.add(jSONArray);
        } else {
            a(b(jSONArray, true, z2));
        }
    }

    static void a(JSONArray jSONArray, boolean z2, ao.a aVar) {
        if (!a("sendPurchases()")) {
            if (i() == null) {
                f fVar = new f(jSONArray);
                V = fVar;
                fVar.b = z2;
                V.c = aVar;
                return;
            }
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("app_id", f2723a);
                if (z2) {
                    jSONObject.put("existing", true);
                }
                jSONObject.put("purchases", jSONArray);
                ao.a("players/" + i() + "/on_purchase", jSONObject, aVar);
                if (j() != null) {
                    ao.a("players/" + j() + "/on_purchase", jSONObject, (ao.a) null);
                }
            } catch (Throwable th) {
                a(h.ERROR, "Failed to generate JSON for sendPurchases.", th);
            }
        }
    }

    static void a(JSONArray jSONArray, boolean z2, boolean z3) {
        ab b2 = b(jSONArray, z2, z3);
        if (C != null && O()) {
            ay ayVar = C;
            try {
                Object a2 = ayVar.a(ayVar.b);
                Method a3 = ay.a((Class) ay.f2766a);
                Bundle bundle = new Bundle();
                bundle.putString("source", "OneSignal");
                bundle.putString("medium", "notification");
                bundle.putString("notification_id", b2.f2714a.d.f2715a);
                bundle.putString("campaign", ay.a(b2.f2714a.d));
                a3.invoke(a2, new Object[]{"os_notification_received", bundle});
                if (ay.c == null) {
                    ay.c = new AtomicLong();
                }
                ay.c.set(System.currentTimeMillis());
                ay.e = b2.f2714a.d;
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
        if (i == null || i.c == null) {
        }
    }

    public static void a(boolean z2) {
        if (b != null) {
            am.a(am.f2741a, "GT_VIBRATE_ENABLED", z2);
        }
    }

    private static boolean a(Context context, JSONArray jSONArray) {
        if (a((String) null)) {
            return false;
        }
        int length = jSONArray.length();
        boolean z2 = false;
        for (int i2 = 0; i2 < length; i2++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i2);
                if (jSONObject.has("custom")) {
                    JSONObject jSONObject2 = new JSONObject(jSONObject.optString("custom"));
                    if (jSONObject2.has("u")) {
                        String optString = jSONObject2.optString("u", (String) null);
                        if (!optString.contains("://")) {
                            optString = "http://".concat(String.valueOf(optString));
                        }
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(optString.trim()));
                        intent.addFlags(1476919296);
                        context.startActivity(intent);
                        z2 = true;
                    }
                }
            } catch (Throwable th) {
                h hVar = h.ERROR;
                a(hVar, "Error parsing JSON item " + i2 + "/" + length + " for launching a web URL.", th);
            }
        }
        return z2;
    }

    static boolean a(Context context, JSONObject jSONObject) {
        String a2 = a(jSONObject);
        return a2 == null || a(a2, context);
    }

    static boolean a(String str) {
        if (!j || N()) {
            return false;
        }
        if (str == null) {
            return true;
        }
        h hVar = h.WARN;
        a(hVar, "Method " + str + " was called before the user provided privacy consent. Your application is set to require the user's privacy consent before the OneSignal SDK can be initialized. Please ensure the user has provided consent before calling this method. You can check the latest OneSignal consent status by calling OneSignal.userProvidedPrivacyConsent()", (Throwable) null);
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0044  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004a  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x005a A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x005f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static boolean a(java.lang.String r11, android.content.Context r12) {
        /*
            r0 = 0
            if (r11 == 0) goto L_0x0063
            java.lang.String r1 = ""
            boolean r1 = r1.equals(r11)
            if (r1 == 0) goto L_0x000c
            goto L_0x0063
        L_0x000c:
            com.onesignal.ak r12 = com.onesignal.ak.a(r12)
            r1 = 0
            r2 = 1
            android.database.sqlite.SQLiteDatabase r3 = r12.b()     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            java.lang.String[] r5 = new java.lang.String[r2]     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            java.lang.String r12 = "notification_id"
            r5[r0] = r12     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            java.lang.String[] r7 = new java.lang.String[r2]     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            r7[r0] = r11     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            java.lang.String r4 = "notification"
            java.lang.String r6 = "notification_id = ?"
            r8 = 0
            r9 = 0
            r10 = 0
            android.database.Cursor r12 = r3.query(r4, r5, r6, r7, r8, r9, r10)     // Catch:{ Throwable -> 0x0039, all -> 0x0037 }
            boolean r3 = r12.moveToFirst()     // Catch:{ Throwable -> 0x0035 }
            if (r12 == 0) goto L_0x0048
            r12.close()
            goto L_0x0048
        L_0x0035:
            r3 = move-exception
            goto L_0x003b
        L_0x0037:
            r11 = move-exception
            goto L_0x005d
        L_0x0039:
            r3 = move-exception
            r12 = r1
        L_0x003b:
            com.onesignal.ai$h r4 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x005b }
            java.lang.String r5 = "Could not check for duplicate, assuming unique."
            a((com.onesignal.ai.h) r4, (java.lang.String) r5, (java.lang.Throwable) r3)     // Catch:{ all -> 0x005b }
            if (r12 == 0) goto L_0x0047
            r12.close()
        L_0x0047:
            r3 = 0
        L_0x0048:
            if (r3 == 0) goto L_0x005a
            com.onesignal.ai$h r12 = com.onesignal.ai.h.DEBUG
            java.lang.String r0 = "Duplicate GCM message received, skip processing of "
            java.lang.String r11 = java.lang.String.valueOf(r11)
            java.lang.String r11 = r0.concat(r11)
            a((com.onesignal.ai.h) r12, (java.lang.String) r11, (java.lang.Throwable) r1)
            return r2
        L_0x005a:
            return r0
        L_0x005b:
            r11 = move-exception
            r1 = r12
        L_0x005d:
            if (r1 == 0) goto L_0x0062
            r1.close()
        L_0x0062:
            throw r11
        L_0x0063:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.ai.a(java.lang.String, android.content.Context):boolean");
    }

    private static ab b(JSONArray jSONArray, boolean z2, boolean z3) {
        z zVar;
        int i2;
        int length = jSONArray.length();
        ab abVar = new ab();
        z zVar2 = new z();
        zVar2.f2815a = q();
        zVar2.b = z2;
        zVar2.c = jSONArray.optJSONObject(0).optInt("notificationId");
        String str = null;
        boolean z4 = true;
        for (int i3 = 0; i3 < length; i3++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i3);
                zVar2.d = q.a(jSONObject);
                if (str == null && jSONObject.has("actionSelected")) {
                    str = jSONObject.optString("actionSelected", (String) null);
                }
                if (z4) {
                    z4 = false;
                } else {
                    if (zVar2.f == null) {
                        zVar2.f = new ArrayList();
                    }
                    zVar2.f.add(zVar2.d);
                }
            } catch (Throwable th) {
                a(h.ERROR, "Error parsing JSON item " + i3 + "/" + length + " for callback.", th);
            }
        }
        abVar.f2714a = zVar2;
        abVar.b = new aa();
        abVar.b.b = str;
        abVar.b.f2712a = str != null ? aa.a.b : aa.a.f2713a;
        if (z3) {
            zVar = abVar.f2714a;
            i2 = z.a.b;
        } else {
            zVar = abVar.f2714a;
            i2 = z.a.f2816a;
        }
        zVar.e = i2;
        return abVar;
    }

    static ad<Object, ag> b() {
        if (T == null) {
            T = new ad<>("onOSSubscriptionChanged", true);
        }
        return T;
    }

    public static a b(Context context) {
        return new a(context, (byte) 0);
    }

    static /* synthetic */ void b(long j2) {
        if (f.get() == j2) {
            a(h.INFO, "Last Pending Task has ran, shutting down", (Throwable) null);
            d.shutdown();
        }
    }

    static void b(String str) {
        g(str);
        g();
        synchronized (N) {
            if (N.size() != 0) {
                new Thread(new Runnable() {
                    public final void run() {
                        bf.a a2 = ap.a().a(!ai.O);
                        if (a2.f2780a) {
                            boolean unused = ai.O = true;
                        }
                        synchronized (ai.N) {
                            Iterator it = ai.N.iterator();
                            while (it.hasNext()) {
                                it.next();
                                if (a2.b != null) {
                                    a2.toString().equals("{}");
                                }
                            }
                            ai.N.clear();
                        }
                    }
                }, "OS_GETTAGS_CALLBACK").start();
            }
        }
        OSSubscriptionState e2 = e(b);
        boolean z2 = !str.equals(e2.d);
        e2.d = str;
        if (z2) {
            e2.f2707a.b(e2);
        }
        if (V != null) {
            a(V.f2731a, V.b, V.c);
            V = null;
        }
        ap.b().b();
        aj.a(b, f2723a, str, c.f2783a);
    }

    public static void b(boolean z2) {
        if (b != null) {
            am.a(am.f2741a, "GT_SOUND_ENABLED", z2);
        }
    }

    static /* synthetic */ boolean b(int i2) {
        return i2 < -6;
    }

    public static a c() {
        if (i == null) {
            i = new a((byte) 0);
        }
        return i;
    }

    private static void c(long j2) {
        am.a(am.f2741a, "OS_LAST_SESSION_TIME", j2);
    }

    static void c(String str) {
        y yVar;
        h(str);
        if (b == null) {
            yVar = null;
        } else {
            if (U == null) {
                y yVar2 = new y();
                U = yVar2;
                yVar2.f2814a.a(new x());
            }
            yVar = U;
        }
        boolean z2 = !str.equals(yVar.b);
        yVar.b = str;
        if (z2) {
            yVar.f2814a.b(yVar);
        }
        try {
            ap.a().a(new JSONObject().put("parent_player_id", str));
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    public static void c(final boolean z2) {
        if (!a("setSubscription()")) {
            AnonymousClass7 r0 = new Runnable() {
                public final void run() {
                    OSSubscriptionState c = ai.e(ai.b);
                    boolean z = z2;
                    boolean z2 = c.c != z;
                    c.c = z;
                    if (z2) {
                        c.f2707a.b(c);
                    }
                    ap.a().b(z2);
                }
            };
            if (b == null || I()) {
                a(h.ERROR, "OneSignal.init has not been called. Moving subscription action to a waiting task queue.", (Throwable) null);
                l lVar = new l(r0);
                long unused = lVar.b = f.incrementAndGet();
                if (d == null) {
                    h hVar = h.INFO;
                    a(hVar, "Adding a task to the pending queue with ID: " + lVar.b, (Throwable) null);
                    e.add(lVar);
                } else if (!d.isShutdown()) {
                    h hVar2 = h.INFO;
                    a(hVar2, "Executor is still running, add to the executor with ID: " + lVar.b, (Throwable) null);
                    d.submit(lVar);
                }
            } else {
                r0.run();
            }
        }
    }

    private static ae d(Context context) {
        if (context == null) {
            return null;
        }
        if (Q == null) {
            ae aeVar = new ae();
            Q = aeVar;
            aeVar.f2720a.a(new OSPermissionChangedInternalObserver());
        }
        return Q;
    }

    /* access modifiers changed from: private */
    public static void d(long j2) {
        z = j2;
        if (b != null) {
            h hVar = h.INFO;
            a(hVar, "SaveUnsentActiveTime: " + z, (Throwable) null);
            am.a(am.f2741a, "GT_UNSENT_ACTIVE_TIME", j2);
        }
    }

    static boolean d() {
        w = false;
        c(System.currentTimeMillis());
        p.c();
        if (!c) {
            return false;
        }
        if (B != null) {
            ax axVar = B;
            if (axVar.f2764a) {
                try {
                    ax.a aVar = (PurchasingListener) axVar.d.get(axVar.c);
                    if (aVar != axVar.b) {
                        axVar.b.f2765a = aVar;
                        axVar.a();
                    }
                } catch (Throwable unused) {
                }
            }
        }
        if (y == -1) {
            return false;
        }
        double elapsedRealtime = (double) (SystemClock.elapsedRealtime() - y);
        Double.isNaN(elapsedRealtime);
        long j2 = (long) ((elapsedRealtime / 1000.0d) + 0.5d);
        y = SystemClock.elapsedRealtime();
        if (j2 >= 0 && j2 <= 86400) {
            if (b == null) {
                a(h.ERROR, "Android Context not found, please call OneSignal.init when your app starts.", (Throwable) null);
                return false;
            }
            boolean h2 = ap.a().h();
            boolean h3 = ap.b().h();
            if (h3) {
                h3 = ap.b().e() != null;
            }
            boolean z2 = h2 || h3;
            if (z2) {
                aq.a(b);
            }
            boolean z3 = p.a(b) || z2;
            long p2 = p() + j2;
            d(p2);
            if (p2 >= 60 && i() != null) {
                if (!z3) {
                    aq.a(b);
                }
                aq.a();
                return false;
            } else if (p2 >= 60) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: private */
    public static OSSubscriptionState e(Context context) {
        if (context == null) {
            return null;
        }
        if (S == null) {
            S = new OSSubscriptionState(d(context).b);
            d(context).f2720a.f2718a.add(new WeakReference(S));
            S.f2707a.a(new OSSubscriptionChangedInternalObserver());
        }
        return S;
    }

    static void e() {
        w = true;
        p.c();
        y = SystemClock.elapsedRealtime();
        if (Q()) {
            ap.d();
        }
        c(System.currentTimeMillis());
        J();
        if (A != null) {
            A.a();
        }
        v.a(b);
        d(b).a();
        if (C != null && O()) {
            ay ayVar = C;
            if (!(ay.c == null || ay.e == null)) {
                long currentTimeMillis = System.currentTimeMillis();
                if (currentTimeMillis - ay.c.get() <= 120000 && (ay.d == null || currentTimeMillis - ay.d.get() >= 30000)) {
                    try {
                        Object a2 = ayVar.a(ayVar.b);
                        Method a3 = ay.a((Class) ay.f2766a);
                        Bundle bundle = new Bundle();
                        bundle.putString("source", "OneSignal");
                        bundle.putString("medium", "notification");
                        bundle.putString("notification_id", ay.e.f2715a);
                        bundle.putString("campaign", ay.a(ay.e));
                        a3.invoke(a2, new Object[]{"os_notification_influence_open", bundle});
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            }
        }
        aq.b(b);
    }

    private static String f(Context context) {
        return context == null ? "" : am.b(am.f2741a, "GT_APP_ID", (String) null);
    }

    private static void f(String str) {
        if (b != null) {
            am.a(am.f2741a, "GT_APP_ID", str);
        }
    }

    static boolean f() {
        return w;
    }

    static void g() {
        if (x != null) {
            ah.a((Runnable) new Runnable() {
                public final void run() {
                    ai.M();
                }
            });
        }
    }

    private static void g(String str) {
        t = str;
        if (b != null) {
            am.a(am.f2741a, "GT_PLAYER_ID", t);
        }
    }

    static String h() {
        return f(b);
    }

    private static void h(String str) {
        u = str;
        if (b != null) {
            am.a(am.f2741a, "OS_EMAIL_ID", "".equals(u) ? null : u);
        }
    }

    static String i() {
        if (t == null && b != null) {
            t = am.b(am.f2741a, "GT_PLAYER_ID", (String) null);
        }
        return t;
    }

    static String j() {
        if ("".equals(u)) {
            return null;
        }
        if (u == null && b != null) {
            u = am.b(am.f2741a, "OS_EMAIL_ID", (String) null);
        }
        return u;
    }

    static boolean k() {
        return am.b(am.f2741a, "OS_FILTER_OTHER_GCM_RECEIVERS", false);
    }

    static boolean l() {
        return am.b(am.f2741a, "GT_VIBRATE_ENABLED", true);
    }

    static boolean m() {
        return am.b(am.f2741a, "GT_SOUND_ENABLED", true);
    }

    static boolean n() {
        return i == null || i.i == k.c;
    }

    static boolean o() {
        return i != null && i.i == k.b;
    }

    static long p() {
        if (z == -1 && b != null) {
            z = am.b(am.f2741a, "GT_UNSENT_ACTIVE_TIME", 0);
        }
        h hVar = h.INFO;
        a(hVar, "GetUnsentActiveTime: " + z, (Throwable) null);
        return z;
    }

    static boolean q() {
        return c && w;
    }

    static boolean r() {
        if (i.f) {
            return ah.e();
        }
        return true;
    }

    static void s() {
        if (p != null) {
            p = null;
        }
    }

    static void t() {
        if (p != null) {
            new d(c.d, "Failed due to network failure. Will retry on next sync.");
            p = null;
        }
    }

    static void u() {
        if (o != null) {
            o = null;
        }
    }

    static void v() {
        if (o != null) {
            new d(c.d, "Failed due to network failure. Will retry on next sync.");
            o = null;
        }
    }

    static /* synthetic */ void x() {
        h hVar = h.DEBUG;
        a(hVar, "registerUser: registerForPushFired:" + H + ", locationFired: " + I + ", remoteParams: " + l, (Throwable) null);
        if (H && I && l != null) {
            new Thread(new Runnable() {
                public final void run() {
                    try {
                        ai.C();
                        aj.a(ai.b, ai.f2723a, ai.t, c.f2783a);
                    } catch (JSONException e) {
                        ai.a(h.FATAL, "FATAL Error registering device!", (Throwable) e);
                    }
                }
            }, "OS_REG_USER").start();
        }
    }
}
