package com.onesignal;

import org.json.JSONObject;

public final class y implements Cloneable {

    /* renamed from: a  reason: collision with root package name */
    ad<Object, y> f2814a = new ad<>("changed", false);
    String b = ai.j();
    private String c = ap.b().e();

    y() {
    }

    private JSONObject a() {
        String str;
        Object obj;
        String str2;
        Object obj2;
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.b != null) {
                str = "emailUserId";
                obj = this.b;
            } else {
                str = "emailUserId";
                obj = JSONObject.NULL;
            }
            jSONObject.put(str, obj);
            if (this.c != null) {
                str2 = "emailAddress";
                obj2 = this.c;
            } else {
                str2 = "emailAddress";
                obj2 = JSONObject.NULL;
            }
            jSONObject.put(str2, obj2);
            jSONObject.put("subscribed", (this.b == null || this.c == null) ? false : true);
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return jSONObject;
    }

    /* access modifiers changed from: protected */
    public final Object clone() {
        try {
            return super.clone();
        } catch (Throwable unused) {
            return null;
        }
    }

    public final String toString() {
        return a().toString();
    }
}
