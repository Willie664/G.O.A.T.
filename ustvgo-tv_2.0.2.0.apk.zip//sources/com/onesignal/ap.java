package com.onesignal;

import com.onesignal.p;

final class ap {

    /* renamed from: a  reason: collision with root package name */
    private static be f2754a;
    private static bc b;

    static be a() {
        if (f2754a == null) {
            f2754a = new be();
        }
        return f2754a;
    }

    static void a(p.f fVar) {
        a().a(fVar);
        b().a(fVar);
    }

    static bc b() {
        if (b == null) {
            b = new bc();
        }
        return b;
    }

    static void c() {
        a().g();
        b().g();
    }

    static void d() {
        a().j();
        b().j();
    }
}
