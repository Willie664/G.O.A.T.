package com.onesignal;

public final class aa {

    /* renamed from: a  reason: collision with root package name */
    public int f2712a;
    public String b;

    public enum a {
        ;
        

        /* renamed from: a  reason: collision with root package name */
        public static final int f2713a = 1;
        public static final int b = 2;

        static {
            c = new int[]{f2713a, b};
        }
    }
}
