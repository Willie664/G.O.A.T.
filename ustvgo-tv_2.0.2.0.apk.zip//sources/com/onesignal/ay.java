package com.onesignal;

import android.content.Context;
import android.os.Bundle;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicLong;

final class ay {

    /* renamed from: a  reason: collision with root package name */
    static Class<?> f2766a;
    static AtomicLong c;
    static AtomicLong d;
    static ac e;
    Context b;
    private Object f;

    ay(Context context) {
        this.b = context;
    }

    static String a(ac acVar) {
        if (acVar.b.isEmpty() || acVar.c.isEmpty()) {
            return acVar.d != null ? acVar.d.substring(0, Math.min(10, acVar.d.length())) : "";
        }
        return acVar.b + " - " + acVar.c;
    }

    static Method a(Class cls) {
        try {
            return cls.getMethod("logEvent", new Class[]{String.class, Bundle.class});
        } catch (NoSuchMethodException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    static boolean a() {
        try {
            f2766a = Class.forName("com.google.firebase.analytics.FirebaseAnalytics");
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    private static Method b(Class cls) {
        try {
            return cls.getMethod("getInstance", new Class[]{Context.class});
        } catch (NoSuchMethodException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public final Object a(Context context) {
        if (this.f == null) {
            try {
                this.f = b(f2766a).invoke((Object) null, new Object[]{context});
            } catch (Throwable th) {
                th.printStackTrace();
                return null;
            }
        }
        return this.f;
    }
}
