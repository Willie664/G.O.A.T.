package com.onesignal;

import java.util.List;
import org.json.JSONObject;

public final class ac {

    /* renamed from: a  reason: collision with root package name */
    public String f2715a;
    public String b;
    public String c;
    public String d;
    public String e;
    public JSONObject f;
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public int n = 1;
    public String o;
    public String p;
    public List<a> q;
    public String r;
    public b s;
    public String t;
    public int u;
    public String v;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public String f2716a;
        public String b;
        public String c;
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public String f2717a;
        public String b;
        public String c;
    }
}
