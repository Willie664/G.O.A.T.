package com.onesignal.shortcutbadger.impl;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.onesignal.shortcutbadger.a;
import com.onesignal.shortcutbadger.a.b;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

public class OPPOHomeBader implements a {

    /* renamed from: a  reason: collision with root package name */
    private static int f2805a = -1;

    private static Class a(String str) {
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }

    private static Object a(Class cls, String str) {
        Method b;
        if (!(cls == null || a((Object) str) || (b = b(cls, str)) == null)) {
            b.setAccessible(true);
            try {
                return b.invoke((Object) null, (Object[]) null);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e2) {
                e2.printStackTrace();
            }
        }
        return null;
    }

    private static boolean a(Object obj) {
        return obj == null || obj.toString().equals("") || obj.toString().trim().equals("null");
    }

    private int b() {
        int i;
        if (f2805a >= 0) {
            return f2805a;
        }
        try {
            i = ((Integer) a(a("com.color.os.ColorBuild"), "getColorOSVERSION")).intValue();
        } catch (Exception unused) {
            i = 0;
        }
        if (i == 0) {
            try {
                String b = b("ro.build.version.opporom");
                if (b.startsWith("V1.4")) {
                    return 3;
                }
                if (b.startsWith("V2.0")) {
                    return 4;
                }
                if (b.startsWith("V2.1")) {
                    return 5;
                }
            } catch (Exception unused2) {
            }
        }
        f2805a = i;
        return i;
    }

    private static String b(String str) {
        BufferedReader bufferedReader;
        BufferedReader bufferedReader2 = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("getprop ".concat(String.valueOf(str))).getInputStream()), 1024);
            try {
                String readLine = bufferedReader.readLine();
                bufferedReader.close();
                b.a((Closeable) bufferedReader);
                return readLine;
            } catch (IOException unused) {
                b.a((Closeable) bufferedReader);
                return null;
            } catch (Throwable th) {
                th = th;
                bufferedReader2 = bufferedReader;
                b.a((Closeable) bufferedReader2);
                throw th;
            }
        } catch (IOException unused2) {
            bufferedReader = null;
            b.a((Closeable) bufferedReader);
            return null;
        } catch (Throwable th2) {
            th = th2;
            b.a((Closeable) bufferedReader2);
            throw th;
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:7|8|9) */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001e, code lost:
        if (r2.getSuperclass() != null) goto L_0x0020;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0020, code lost:
        r2 = r2.getSuperclass();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0019, code lost:
        return r2.getMethod(r3, (java.lang.Class[]) null);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0015 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.reflect.Method b(java.lang.Class r2, java.lang.String r3) {
        /*
        L_0x0000:
            r0 = 0
            if (r2 == 0) goto L_0x0025
            boolean r1 = a((java.lang.Object) r3)
            if (r1 == 0) goto L_0x000a
            goto L_0x0025
        L_0x000a:
            r2.getMethods()     // Catch:{ Exception -> 0x0015 }
            r2.getDeclaredMethods()     // Catch:{ Exception -> 0x0015 }
            java.lang.reflect.Method r1 = r2.getDeclaredMethod(r3, r0)     // Catch:{ Exception -> 0x0015 }
            return r1
        L_0x0015:
            java.lang.reflect.Method r1 = r2.getMethod(r3, r0)     // Catch:{ Exception -> 0x001a }
            return r1
        L_0x001a:
            java.lang.Class r1 = r2.getSuperclass()
            if (r1 == 0) goto L_0x0025
            java.lang.Class r2 = r2.getSuperclass()
            goto L_0x0000
        L_0x0025:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.shortcutbadger.impl.OPPOHomeBader.b(java.lang.Class, java.lang.String):java.lang.reflect.Method");
    }

    public final List<String> a() {
        return Collections.singletonList("com.oppo.launcher");
    }

    @TargetApi(11)
    public final void a(Context context, ComponentName componentName, int i) {
        if (i == 0) {
            i = -1;
        }
        Intent intent = new Intent("com.oppo.unsettledevent");
        intent.putExtra("pakeageName", componentName.getPackageName());
        intent.putExtra("number", i);
        intent.putExtra("upgradeNumber", i);
        if (com.onesignal.shortcutbadger.a.a.a(context, intent)) {
            context.sendBroadcast(intent);
        } else if (b() == 6) {
            try {
                Bundle bundle = new Bundle();
                bundle.putInt("app_badge_count", i);
                context.getContentResolver().call(Uri.parse("content://com.android.badge/badge"), "setAppBadgeCount", (String) null, bundle);
            } catch (Throwable unused) {
                throw new com.onesignal.shortcutbadger.b("unable to resolve intent: " + intent.toString());
            }
        }
    }
}
