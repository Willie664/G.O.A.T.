package com.onesignal.shortcutbadger.impl;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.onesignal.shortcutbadger.a;
import java.util.Collections;
import java.util.List;

public class ZukHomeBadger implements a {

    /* renamed from: a  reason: collision with root package name */
    private final Uri f2810a = Uri.parse("content://com.android.badge/badge");

    public final List<String> a() {
        return Collections.singletonList("com.zui.launcher");
    }

    @TargetApi(11)
    public final void a(Context context, ComponentName componentName, int i) {
        Bundle bundle = new Bundle();
        bundle.putInt("app_badge_count", i);
        context.getContentResolver().call(this.f2810a, "setAppBadgeCount", (String) null, bundle);
    }
}
