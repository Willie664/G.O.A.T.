package com.onesignal.shortcutbadger.impl;

import android.content.pm.ResolveInfo;
import com.onesignal.shortcutbadger.a;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class XiaomiHomeBadger implements a {

    /* renamed from: a  reason: collision with root package name */
    private ResolveInfo f2809a;

    public final List<String> a() {
        return Arrays.asList(new String[]{"com.miui.miuilite", "com.miui.home", "com.miui.miuihome", "com.miui.miuihome2", "com.miui.mihome", "com.miui.mihome2", "com.i.miui.launcher"});
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(2:8|9) */
    /* JADX WARNING: Code restructure failed: missing block: B:9:?, code lost:
        r2.set(r1, java.lang.Integer.valueOf(r10));
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0029 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(android.content.Context r8, android.content.ComponentName r9, int r10) {
        /*
            r7 = this;
            r0 = 1
            java.lang.String r1 = "android.app.MiuiNotification"
            java.lang.Class r1 = java.lang.Class.forName(r1)     // Catch:{ Exception -> 0x0031 }
            java.lang.Object r1 = r1.newInstance()     // Catch:{ Exception -> 0x0031 }
            java.lang.Class r2 = r1.getClass()     // Catch:{ Exception -> 0x0031 }
            java.lang.String r3 = "messageCount"
            java.lang.reflect.Field r2 = r2.getDeclaredField(r3)     // Catch:{ Exception -> 0x0031 }
            r2.setAccessible(r0)     // Catch:{ Exception -> 0x0031 }
            if (r10 != 0) goto L_0x001d
            java.lang.String r3 = ""
            goto L_0x0021
        L_0x001d:
            java.lang.Integer r3 = java.lang.Integer.valueOf(r10)     // Catch:{ Exception -> 0x0029 }
        L_0x0021:
            java.lang.String r3 = java.lang.String.valueOf(r3)     // Catch:{ Exception -> 0x0029 }
            r2.set(r1, r3)     // Catch:{ Exception -> 0x0029 }
            goto L_0x0075
        L_0x0029:
            java.lang.Integer r3 = java.lang.Integer.valueOf(r10)     // Catch:{ Exception -> 0x0031 }
            r2.set(r1, r3)     // Catch:{ Exception -> 0x0031 }
            goto L_0x0075
        L_0x0031:
            android.content.Intent r1 = new android.content.Intent
            java.lang.String r2 = "android.intent.action.APPLICATION_MESSAGE_UPDATE"
            r1.<init>(r2)
            java.lang.String r2 = "android.intent.extra.update_application_component_name"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = r9.getPackageName()
            r3.append(r4)
            java.lang.String r4 = "/"
            r3.append(r4)
            java.lang.String r9 = r9.getClassName()
            r3.append(r9)
            java.lang.String r9 = r3.toString()
            r1.putExtra(r2, r9)
            java.lang.String r9 = "android.intent.extra.update_application_message_text"
            if (r10 != 0) goto L_0x0061
            java.lang.String r2 = ""
            goto L_0x0065
        L_0x0061:
            java.lang.Integer r2 = java.lang.Integer.valueOf(r10)
        L_0x0065:
            java.lang.String r2 = java.lang.String.valueOf(r2)
            r1.putExtra(r9, r2)
            boolean r9 = com.onesignal.shortcutbadger.a.a.a(r8, r1)
            if (r9 == 0) goto L_0x0075
            r8.sendBroadcast(r1)
        L_0x0075:
            java.lang.String r9 = android.os.Build.MANUFACTURER
            java.lang.String r1 = "Xiaomi"
            boolean r9 = r9.equalsIgnoreCase(r1)
            if (r9 == 0) goto L_0x00fd
            android.content.pm.ResolveInfo r9 = r7.f2809a
            if (r9 != 0) goto L_0x009b
            android.content.Intent r9 = new android.content.Intent
            java.lang.String r1 = "android.intent.action.MAIN"
            r9.<init>(r1)
            java.lang.String r1 = "android.intent.category.HOME"
            r9.addCategory(r1)
            android.content.pm.PackageManager r1 = r8.getPackageManager()
            r2 = 65536(0x10000, float:9.18355E-41)
            android.content.pm.ResolveInfo r9 = r1.resolveActivity(r9, r2)
            r7.f2809a = r9
        L_0x009b:
            android.content.pm.ResolveInfo r9 = r7.f2809a
            if (r9 == 0) goto L_0x00fd
            java.lang.String r9 = "notification"
            java.lang.Object r9 = r8.getSystemService(r9)
            android.app.NotificationManager r9 = (android.app.NotificationManager) r9
            android.app.Notification$Builder r1 = new android.app.Notification$Builder
            r1.<init>(r8)
            java.lang.String r8 = ""
            android.app.Notification$Builder r8 = r1.setContentTitle(r8)
            java.lang.String r1 = ""
            android.app.Notification$Builder r8 = r8.setContentText(r1)
            android.content.pm.ResolveInfo r1 = r7.f2809a
            int r1 = r1.getIconResource()
            android.app.Notification$Builder r8 = r8.setSmallIcon(r1)
            android.app.Notification r8 = r8.build()
            java.lang.Class r1 = r8.getClass()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r2 = "extraNotification"
            java.lang.reflect.Field r1 = r1.getDeclaredField(r2)     // Catch:{ Exception -> 0x00f4 }
            java.lang.Object r1 = r1.get(r8)     // Catch:{ Exception -> 0x00f4 }
            java.lang.Class r2 = r1.getClass()     // Catch:{ Exception -> 0x00f4 }
            java.lang.String r3 = "setMessageCount"
            java.lang.Class[] r4 = new java.lang.Class[r0]     // Catch:{ Exception -> 0x00f4 }
            java.lang.Class r5 = java.lang.Integer.TYPE     // Catch:{ Exception -> 0x00f4 }
            r6 = 0
            r4[r6] = r5     // Catch:{ Exception -> 0x00f4 }
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r3, r4)     // Catch:{ Exception -> 0x00f4 }
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x00f4 }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ Exception -> 0x00f4 }
            r0[r6] = r10     // Catch:{ Exception -> 0x00f4 }
            r2.invoke(r1, r0)     // Catch:{ Exception -> 0x00f4 }
            r9.notify(r6, r8)     // Catch:{ Exception -> 0x00f4 }
            return
        L_0x00f4:
            r8 = move-exception
            com.onesignal.shortcutbadger.b r9 = new com.onesignal.shortcutbadger.b
            java.lang.String r10 = "not able to set badge"
            r9.<init>(r10, r8)
            throw r9
        L_0x00fd:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.shortcutbadger.impl.XiaomiHomeBadger.a(android.content.Context, android.content.ComponentName, int):void");
    }
}
