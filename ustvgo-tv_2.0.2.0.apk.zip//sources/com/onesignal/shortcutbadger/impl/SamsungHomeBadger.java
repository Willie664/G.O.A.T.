package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import com.onesignal.shortcutbadger.a;
import com.onesignal.shortcutbadger.a.b;
import java.util.Arrays;
import java.util.List;

public class SamsungHomeBadger implements a {

    /* renamed from: a  reason: collision with root package name */
    private static final String[] f2806a = {"_id", "class"};
    private DefaultBadger b;

    public SamsungHomeBadger() {
        if (Build.VERSION.SDK_INT >= 21) {
            this.b = new DefaultBadger();
        }
    }

    private static ContentValues a(ComponentName componentName, int i, boolean z) {
        ContentValues contentValues = new ContentValues();
        if (z) {
            contentValues.put("package", componentName.getPackageName());
            contentValues.put("class", componentName.getClassName());
        }
        contentValues.put("badgecount", Integer.valueOf(i));
        return contentValues;
    }

    public final List<String> a() {
        return Arrays.asList(new String[]{"com.sec.android.app.launcher", "com.sec.android.app.twlauncher"});
    }

    public final void a(Context context, ComponentName componentName, int i) {
        Cursor cursor;
        if (this.b == null || !DefaultBadger.a(context)) {
            Uri parse = Uri.parse("content://com.sec.badge/apps?notify=true");
            ContentResolver contentResolver = context.getContentResolver();
            try {
                cursor = contentResolver.query(parse, f2806a, "package=?", new String[]{componentName.getPackageName()}, (String) null);
                if (cursor != null) {
                    try {
                        String className = componentName.getClassName();
                        boolean z = false;
                        while (cursor.moveToNext()) {
                            contentResolver.update(parse, a(componentName, i, false), "_id=?", new String[]{String.valueOf(cursor.getInt(0))});
                            if (className.equals(cursor.getString(cursor.getColumnIndex("class")))) {
                                z = true;
                            }
                        }
                        if (!z) {
                            contentResolver.insert(parse, a(componentName, i, true));
                        }
                    } catch (Throwable th) {
                        th = th;
                        b.a(cursor);
                        throw th;
                    }
                }
                b.a(cursor);
            } catch (Throwable th2) {
                th = th2;
                cursor = null;
                b.a(cursor);
                throw th;
            }
        } else {
            this.b.a(context, componentName, i);
        }
    }
}
