package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.util.Log;
import com.onesignal.shortcutbadger.impl.AdwHomeBadger;
import com.onesignal.shortcutbadger.impl.ApexHomeBadger;
import com.onesignal.shortcutbadger.impl.DefaultBadger;
import com.onesignal.shortcutbadger.impl.EverythingMeHomeBadger;
import com.onesignal.shortcutbadger.impl.HuaweiHomeBadger;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.onesignal.shortcutbadger.impl.NovaHomeBadger;
import com.onesignal.shortcutbadger.impl.OPPOHomeBader;
import com.onesignal.shortcutbadger.impl.SamsungHomeBadger;
import com.onesignal.shortcutbadger.impl.SonyHomeBadger;
import com.onesignal.shortcutbadger.impl.VivoHomeBadger;
import com.onesignal.shortcutbadger.impl.ZukHomeBadger;
import com.onesignal.shortcutbadger.impl.a;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    private static final List<Class<? extends a>> f2804a = new LinkedList();
    private static final Object b = new Object();
    private static a c;
    private static ComponentName d;

    static {
        f2804a.add(AdwHomeBadger.class);
        f2804a.add(ApexHomeBadger.class);
        f2804a.add(NewHtcHomeBadger.class);
        f2804a.add(NovaHomeBadger.class);
        f2804a.add(SonyHomeBadger.class);
        f2804a.add(a.class);
        f2804a.add(HuaweiHomeBadger.class);
        f2804a.add(OPPOHomeBader.class);
        f2804a.add(SamsungHomeBadger.class);
        f2804a.add(ZukHomeBadger.class);
        f2804a.add(VivoHomeBadger.class);
        f2804a.add(EverythingMeHomeBadger.class);
    }

    public static void a(Context context, int i) {
        if (c != null || a(context)) {
            try {
                c.a(context, d, i);
            } catch (Exception e) {
                throw new b("Unable to execute badge", e);
            }
        } else {
            throw new b("No default launcher available");
        }
    }

    private static boolean a(Context context) {
        a aVar;
        Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launchIntentForPackage == null) {
            Log.e("ShortcutBadger", "Unable to find launch intent for package " + context.getPackageName());
            return false;
        }
        d = launchIntentForPackage.getComponent();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        ResolveInfo resolveActivity = context.getPackageManager().resolveActivity(intent, 65536);
        if (resolveActivity == null || resolveActivity.activityInfo.name.toLowerCase().contains("resolver")) {
            return false;
        }
        String str = resolveActivity.activityInfo.packageName;
        Iterator<Class<? extends a>> it = f2804a.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            try {
                aVar = (a) it.next().newInstance();
            } catch (Exception unused) {
                aVar = null;
            }
            if (aVar != null && aVar.a().contains(str)) {
                c = aVar;
                break;
            }
        }
        if (c != null) {
            return true;
        }
        c = Build.MANUFACTURER.equalsIgnoreCase("ZUK") ? new ZukHomeBadger() : Build.MANUFACTURER.equalsIgnoreCase("OPPO") ? new OPPOHomeBader() : Build.MANUFACTURER.equalsIgnoreCase("VIVO") ? new VivoHomeBadger() : new DefaultBadger();
        return true;
    }
}
