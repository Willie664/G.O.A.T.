package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import java.util.List;

public interface a {
    List<String> a();

    void a(Context context, ComponentName componentName, int i);
}
