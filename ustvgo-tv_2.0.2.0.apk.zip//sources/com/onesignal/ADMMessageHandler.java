package com.onesignal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.amazon.device.messaging.ADMMessageHandlerBase;
import com.onesignal.ai;

public class ADMMessageHandler extends ADMMessageHandlerBase {
    public ADMMessageHandler() {
        super("ADMMessageHandler");
    }

    /* access modifiers changed from: protected */
    public void onMessage(Intent intent) {
        Context applicationContext = getApplicationContext();
        Bundle extras = intent.getExtras();
        if (!q.a(applicationContext, extras).a()) {
            s sVar = new s(applicationContext);
            sVar.b = q.a(extras);
            q.a(sVar);
        }
    }

    /* access modifiers changed from: protected */
    public void onRegistered(String str) {
        ai.a(ai.h.INFO, "ADM registration ID: ".concat(String.valueOf(str)));
        as.a(str);
    }

    /* access modifiers changed from: protected */
    public void onRegistrationError(String str) {
        ai.a(ai.h.ERROR, "ADM:onRegistrationError: ".concat(String.valueOf(str)));
        if ("INVALID_SENDER".equals(str)) {
            ai.a(ai.h.ERROR, "Please double check that you have a matching package name (NOTE: Case Sensitive), api_key.txt, and the apk was signed with the same Keystore and Alias.");
        }
        as.a((String) null);
    }

    /* access modifiers changed from: protected */
    public void onUnregistered(String str) {
        ai.a(ai.h.INFO, "ADM:onUnregistered: ".concat(String.valueOf(str)));
    }
}
