package com.onesignal;

class OSPermissionChangedInternalObserver {
    OSPermissionChangedInternalObserver() {
    }

    static void a(ae aeVar) {
        if (!aeVar.b) {
            f.a(0, ai.b);
        }
        ap.a().c(ai.r());
    }

    /* access modifiers changed from: package-private */
    public void changed(ae aeVar) {
        a(aeVar);
        af afVar = new af();
        afVar.b = ai.m;
        afVar.f2721a = (ae) aeVar.clone();
        if (ai.a().b(afVar)) {
            ae aeVar2 = (ae) aeVar.clone();
            ai.m = aeVar2;
            am.a(am.f2741a, "ONESIGNAL_ACCEPTED_NOTIFICATION_LAST", aeVar2.b);
        }
    }
}
