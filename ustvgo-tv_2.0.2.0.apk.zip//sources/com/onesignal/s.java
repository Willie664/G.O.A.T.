package com.onesignal;

import android.content.Context;
import android.net.Uri;
import com.onesignal.NotificationExtenderService;
import java.security.SecureRandom;
import org.json.JSONObject;

final class s {

    /* renamed from: a  reason: collision with root package name */
    Context f2803a;
    JSONObject b;
    boolean c;
    boolean d;
    Long e;
    CharSequence f;
    CharSequence g;
    Uri h;
    Integer i;
    Integer j;
    Uri k;
    NotificationExtenderService.a l;

    s(Context context) {
        this.f2803a = context;
    }

    /* access modifiers changed from: package-private */
    public final CharSequence a() {
        return this.g != null ? this.g : this.b.optString("title", (String) null);
    }

    /* access modifiers changed from: package-private */
    public final CharSequence b() {
        return this.f != null ? this.f : this.b.optString("alert", (String) null);
    }

    /* access modifiers changed from: package-private */
    public final Integer c() {
        if (this.l == null) {
            this.l = new NotificationExtenderService.a();
        }
        if (this.l.b == null) {
            this.l.b = Integer.valueOf(new SecureRandom().nextInt());
        }
        return this.l.b;
    }

    /* access modifiers changed from: package-private */
    public final int d() {
        if (this.l == null || this.l.b == null) {
            return -1;
        }
        return this.l.b.intValue();
    }
}
