package com.onesignal;

import android.app.NotificationManager;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import com.onesignal.ai;
import com.onesignal.shortcutbadger.c;

final class f {

    /* renamed from: a  reason: collision with root package name */
    private static int f2784a = -1;

    static void a(int i, Context context) {
        if (a(context)) {
            try {
                c.a(context, i);
            } catch (Throwable unused) {
            }
        }
    }

    static void a(SQLiteDatabase sQLiteDatabase, Context context) {
        if (a(context) && ah.e()) {
            if (Build.VERSION.SDK_INT >= 23) {
                int i = 0;
                for (StatusBarNotification a2 : ((NotificationManager) context.getSystemService("notification")).getActiveNotifications()) {
                    if (!t.a(a2)) {
                        i++;
                    }
                }
                a(i, context);
                return;
            }
            Cursor query = sQLiteDatabase.query("notification", (String[]) null, ak.c().toString(), (String[]) null, (String) null, (String) null, (String) null, t.f2811a);
            int count = query.getCount();
            query.close();
            a(count, context);
        }
    }

    private static boolean a(Context context) {
        if (f2784a != -1) {
            return f2784a == 1;
        }
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null) {
                f2784a = "DISABLE".equals(bundle.getString("com.onesignal.BadgeCount")) ^ true ? 1 : 0;
            } else {
                f2784a = 1;
            }
        } catch (Throwable th) {
            f2784a = 0;
            ai.a(ai.h.ERROR, "Error reading meta-data tag 'com.onesignal.BadgeCount'. Disabling badge setting.", th);
        }
        return f2784a == 1;
    }
}
