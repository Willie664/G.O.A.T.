package com.onesignal;

public interface g<T> {
    T a();

    String a(String str);

    void a(String str, Long l);

    void a(String str, String str2);

    Integer b(String str);

    Long c(String str);

    boolean d(String str);

    boolean e(String str);
}
