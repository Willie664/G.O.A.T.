package com.onesignal;

import org.json.JSONObject;

public class OSSubscriptionState implements Cloneable {

    /* renamed from: a  reason: collision with root package name */
    ad<Object, OSSubscriptionState> f2707a = new ad<>("changed", false);
    boolean b;
    boolean c = ap.a().b();
    String d = ai.i();
    String e = ap.a().e();

    OSSubscriptionState(boolean z) {
        this.b = z;
    }

    private boolean b() {
        return this.d != null && this.e != null && this.c && this.b;
    }

    public final JSONObject a() {
        String str;
        Object obj;
        String str2;
        Object obj2;
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.d != null) {
                str = "userId";
                obj = this.d;
            } else {
                str = "userId";
                obj = JSONObject.NULL;
            }
            jSONObject.put(str, obj);
            if (this.e != null) {
                str2 = "pushToken";
                obj2 = this.e;
            } else {
                str2 = "pushToken";
                obj2 = JSONObject.NULL;
            }
            jSONObject.put(str2, obj2);
            jSONObject.put("userSubscriptionSetting", this.c);
            jSONObject.put("subscribed", b());
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return jSONObject;
    }

    /* access modifiers changed from: package-private */
    public void changed(ae aeVar) {
        boolean z = aeVar.b;
        boolean b2 = b();
        this.b = z;
        if (b2 != b()) {
            this.f2707a.b(this);
        }
    }

    /* access modifiers changed from: protected */
    public Object clone() {
        try {
            return super.clone();
        } catch (Throwable unused) {
            return null;
        }
    }

    public String toString() {
        return a().toString();
    }
}
