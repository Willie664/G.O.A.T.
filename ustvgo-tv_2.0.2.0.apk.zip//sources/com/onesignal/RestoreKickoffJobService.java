package com.onesignal;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;

public class RestoreKickoffJobService extends al {
    /* access modifiers changed from: package-private */
    public final void a(JobService jobService, JobParameters jobParameters) {
        Thread.currentThread().setPriority(10);
        ai.a((Context) this);
        v.b(getApplicationContext());
    }

    public /* bridge */ /* synthetic */ boolean onStartJob(JobParameters jobParameters) {
        return super.onStartJob(jobParameters);
    }

    public /* bridge */ /* synthetic */ boolean onStopJob(JobParameters jobParameters) {
        return super.onStopJob(jobParameters);
    }
}
