package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.onesignal.ai;
import com.onesignal.ao;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class az {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static int f2767a = -99;
    /* access modifiers changed from: private */
    public static Class<?> c;
    private ServiceConnection b;
    /* access modifiers changed from: private */
    public Object d;
    /* access modifiers changed from: private */
    public Method e;
    private Method f;
    /* access modifiers changed from: private */
    public Context g;
    /* access modifiers changed from: private */
    public ArrayList<String> h;
    /* access modifiers changed from: private */
    public boolean i = true;
    /* access modifiers changed from: private */
    public boolean j;

    az(Context context) {
        boolean z = false;
        this.j = false;
        this.g = context;
        this.h = new ArrayList<>();
        try {
            JSONArray jSONArray = new JSONArray(am.b("GTPlayerPurchases", "purchaseTokens", "[]"));
            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                this.h.add(jSONArray.get(i2).toString());
            }
            this.i = jSONArray.length() == 0 ? true : z;
            if (this.i) {
                this.i = am.b("GTPlayerPurchases", "ExistingPurchases", true);
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        a();
    }

    static /* synthetic */ Method a(Class cls) {
        for (Method method : cls.getMethods()) {
            Class<IBinder>[] parameterTypes = method.getParameterTypes();
            if (parameterTypes.length == 1 && parameterTypes[0] == IBinder.class) {
                return method;
            }
        }
        return null;
    }

    static /* synthetic */ void a(az azVar, ArrayList arrayList, final ArrayList arrayList2) {
        Method method;
        try {
            if (azVar.f == null) {
                Method[] methods = c.getMethods();
                int length = methods.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        method = null;
                        break;
                    }
                    method = methods[i2];
                    Class<Bundle>[] parameterTypes = method.getParameterTypes();
                    Class<?> returnType = method.getReturnType();
                    if (parameterTypes.length == 4 && parameterTypes[0] == Integer.TYPE && parameterTypes[1] == String.class && parameterTypes[2] == String.class && parameterTypes[3] == Bundle.class && returnType == Bundle.class) {
                        break;
                    }
                    i2++;
                }
                azVar.f = method;
                azVar.f.setAccessible(true);
            }
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("ITEM_ID_LIST", arrayList);
            Bundle bundle2 = (Bundle) azVar.f.invoke(azVar.d, new Object[]{3, azVar.g.getPackageName(), "inapp", bundle});
            if (bundle2.getInt("RESPONSE_CODE") == 0) {
                ArrayList<String> stringArrayList = bundle2.getStringArrayList("DETAILS_LIST");
                HashMap hashMap = new HashMap();
                Iterator<String> it = stringArrayList.iterator();
                while (it.hasNext()) {
                    JSONObject jSONObject = new JSONObject(it.next());
                    String string = jSONObject.getString("productId");
                    BigDecimal divide = new BigDecimal(jSONObject.getString("price_amount_micros")).divide(new BigDecimal(1000000));
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put("sku", string);
                    jSONObject2.put("iso", jSONObject.getString("price_currency_code"));
                    jSONObject2.put("amount", divide.toString());
                    hashMap.put(string, jSONObject2);
                }
                JSONArray jSONArray = new JSONArray();
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    String str = (String) it2.next();
                    if (hashMap.containsKey(str)) {
                        jSONArray.put(hashMap.get(str));
                    }
                }
                if (jSONArray.length() > 0) {
                    ai.a(jSONArray, azVar.i, (ao.a) new ao.a() {
                        public final void a(String str) {
                            az.this.h.addAll(arrayList2);
                            am.a("GTPlayerPurchases", "purchaseTokens", az.this.h.toString());
                            am.a("GTPlayerPurchases", "ExistingPurchases", true);
                            boolean unused = az.this.i = false;
                            boolean unused2 = az.this.j = false;
                        }
                    });
                }
            }
        } catch (Throwable th) {
            ai.a(ai.h.WARN, "Failed to track IAP purchases", th);
        }
    }

    static boolean a(Context context) {
        if (f2767a == -99) {
            f2767a = context.checkCallingOrSelfPermission("com.android.vending.BILLING");
        }
        try {
            if (f2767a == 0) {
                c = Class.forName("com.android.vending.billing.IInAppBillingService");
            }
            return f2767a == 0;
        } catch (Throwable unused) {
            f2767a = 0;
            return false;
        }
    }

    static /* synthetic */ Method b(Class cls) {
        for (Method method : cls.getMethods()) {
            Class<String>[] parameterTypes = method.getParameterTypes();
            if (parameterTypes.length == 4 && parameterTypes[0] == Integer.TYPE && parameterTypes[1] == String.class && parameterTypes[2] == String.class && parameterTypes[3] == String.class) {
                return method;
            }
        }
        return null;
    }

    /* access modifiers changed from: private */
    public void d() {
        if (!this.j) {
            new Thread(new Runnable() {
                public final void run() {
                    boolean unused = az.this.j = true;
                    try {
                        if (az.this.e == null) {
                            Method unused2 = az.this.e = az.b(az.c);
                            az.this.e.setAccessible(true);
                        }
                        Bundle bundle = (Bundle) az.this.e.invoke(az.this.d, new Object[]{3, az.this.g.getPackageName(), "inapp", null});
                        if (bundle.getInt("RESPONSE_CODE") == 0) {
                            ArrayList arrayList = new ArrayList();
                            ArrayList arrayList2 = new ArrayList();
                            ArrayList<String> stringArrayList = bundle.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                            ArrayList<String> stringArrayList2 = bundle.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                            for (int i = 0; i < stringArrayList2.size(); i++) {
                                String str = stringArrayList.get(i);
                                String string = new JSONObject(stringArrayList2.get(i)).getString("purchaseToken");
                                if (!az.this.h.contains(string) && !arrayList2.contains(string)) {
                                    arrayList2.add(string);
                                    arrayList.add(str);
                                }
                            }
                            if (arrayList.size() > 0) {
                                az.a(az.this, arrayList, arrayList2);
                            } else if (stringArrayList2.size() == 0) {
                                boolean unused3 = az.this.i = false;
                                am.a("GTPlayerPurchases", "ExistingPurchases", false);
                            }
                        }
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                    boolean unused4 = az.this.j = false;
                }
            }).start();
        }
    }

    /* access modifiers changed from: package-private */
    public final void a() {
        if (this.b == null) {
            this.b = new ServiceConnection() {
                public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                    try {
                        Method a2 = az.a((Class) Class.forName("com.android.vending.billing.IInAppBillingService$Stub"));
                        a2.setAccessible(true);
                        Object unused = az.this.d = a2.invoke((Object) null, new Object[]{iBinder});
                        az.this.d();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }

                public final void onServiceDisconnected(ComponentName componentName) {
                    int unused = az.f2767a = -99;
                    Object unused2 = az.this.d = null;
                }
            };
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            intent.setPackage("com.android.vending");
            this.g.bindService(intent, this.b, 1);
        } else if (this.d != null) {
            d();
        }
    }
}
