package com.onesignal;

import org.json.JSONObject;

public final class ag {

    /* renamed from: a  reason: collision with root package name */
    OSSubscriptionState f2722a;
    OSSubscriptionState b;

    private JSONObject a() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("from", this.b.a());
            jSONObject.put("to", this.f2722a.a());
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return jSONObject;
    }

    public final String toString() {
        return a().toString();
    }
}
