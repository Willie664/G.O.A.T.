package com.onesignal;

import android.support.v4.app.NotificationCompat;
import com.onesignal.ao;
import com.onesignal.bf;
import org.json.JSONException;
import org.json.JSONObject;

final class be extends bf {

    /* renamed from: a  reason: collision with root package name */
    static boolean f2772a;

    be() {
    }

    /* access modifiers changed from: protected */
    public final ba a(String str) {
        return new bd(str, true);
    }

    /* access modifiers changed from: package-private */
    public final bf.a a(boolean z) {
        bf.a aVar;
        if (z) {
            String i = ai.i();
            String h = ai.h();
            ao.a("players/" + i + "?app_id=" + h, (String) null, (JSONObject) null, new ao.a() {
                /* access modifiers changed from: package-private */
                public final void a(String str) {
                    be.f2772a = true;
                    try {
                        JSONObject jSONObject = new JSONObject(str);
                        if (jSONObject.has("tags")) {
                            synchronized (be.this.c) {
                                JSONObject a2 = be.this.a(be.this.g.b.optJSONObject("tags"), be.this.f().b.optJSONObject("tags"), (JSONObject) null);
                                be.this.g.b.put("tags", jSONObject.optJSONObject("tags"));
                                be.this.g.c();
                                be.this.f().b(jSONObject, a2);
                                be.this.f().c();
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, 60000, "CACHE_KEY_GET_TAGS");
        }
        synchronized (this.c) {
            aVar = new bf.a(f2772a, o.a(this.h.b, "tags"));
        }
        return aVar;
    }

    /* access modifiers changed from: package-private */
    public final void a(JSONObject jSONObject) {
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.putOpt("identifier", jSONObject.optString("identifier", (String) null));
            if (jSONObject.has("device_type")) {
                jSONObject2.put("device_type", jSONObject.optInt("device_type"));
            }
            jSONObject2.putOpt("parent_player_id", jSONObject.optString("parent_player_id", (String) null));
            JSONObject jSONObject3 = i().b;
            a(jSONObject3, jSONObject2, jSONObject3);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            JSONObject jSONObject4 = new JSONObject();
            if (jSONObject.has("subscribableStatus")) {
                jSONObject4.put("subscribableStatus", jSONObject.optInt("subscribableStatus"));
            }
            if (jSONObject.has("androidPermission")) {
                jSONObject4.put("androidPermission", jSONObject.optBoolean("androidPermission"));
            }
            JSONObject jSONObject5 = i().f2771a;
            a(jSONObject5, jSONObject4, jSONObject5);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public final boolean a() {
        return f().b();
    }

    /* access modifiers changed from: package-private */
    public final void b(String str) {
        ai.b(str);
    }

    /* access modifiers changed from: protected */
    public final void b(JSONObject jSONObject) {
    }

    /* access modifiers changed from: package-private */
    public final void b(boolean z) {
        try {
            i().f2771a.put("userSubscribePref", z);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public final boolean b() {
        return f().f2771a.optBoolean("userSubscribePref", true);
    }

    /* access modifiers changed from: protected */
    public final void c() {
        a((Integer) 0).a();
    }

    /* access modifiers changed from: protected */
    public final void c(JSONObject jSONObject) {
        if (jSONObject.has(NotificationCompat.CATEGORY_EMAIL)) {
            ai.v();
        }
    }

    public final void c(boolean z) {
        try {
            i().f2771a.put("androidPermission", z);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: protected */
    public final String d() {
        return ai.i();
    }

    /* access modifiers changed from: protected */
    public final void d(JSONObject jSONObject) {
        if (jSONObject.has(NotificationCompat.CATEGORY_EMAIL)) {
            ai.u();
        }
        if (jSONObject.has("identifier")) {
            ai.g();
        }
    }
}
