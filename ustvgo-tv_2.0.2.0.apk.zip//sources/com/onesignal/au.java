package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import com.google.android.gms.common.internal.ab;
import com.google.firebase.a;
import com.google.firebase.b;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

final class au extends at {

    /* renamed from: a  reason: collision with root package name */
    private a f2763a;

    au() {
    }

    static void a(Context context) {
        try {
            context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, FirebaseInstanceIdService.class), ah.a(context, "gcm_defaultSenderId", (String) null) == null ? 2 : 1, 1);
        } catch (IllegalArgumentException | NoClassDefFoundError unused) {
        }
    }

    /* access modifiers changed from: package-private */
    public final String a() {
        return "FCM";
    }

    /* access modifiers changed from: package-private */
    public final String a(String str) {
        if (this.f2763a == null) {
            b.a aVar = new b.a();
            aVar.e = str;
            aVar.b = ab.a("OMIT_ID", (Object) "ApplicationId must be set.");
            aVar.f2645a = ab.a("OMIT_KEY", (Object) "ApiKey must be set.");
            this.f2763a = a.a(ai.b, new b(aVar.b, aVar.f2645a, aVar.c, aVar.d, aVar.e, aVar.f, aVar.g, (byte) 0), "ONESIGNAL_SDK_FCM_APP_NAME");
        }
        return FirebaseInstanceId.getInstance(this.f2763a).a(str, "FCM");
    }
}
