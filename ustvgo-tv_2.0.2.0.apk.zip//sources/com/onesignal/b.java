package com.onesignal;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

final class b implements Application.ActivityLifecycleCallbacks {
    b() {
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
        a.b();
    }

    public final void onActivityDestroyed(Activity activity) {
        a.d(activity);
    }

    public final void onActivityPaused(Activity activity) {
        a.b(activity);
    }

    public final void onActivityResumed(Activity activity) {
        a.a(activity);
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public final void onActivityStarted(Activity activity) {
        a.c();
    }

    public final void onActivityStopped(Activity activity) {
        a.c(activity);
    }
}
