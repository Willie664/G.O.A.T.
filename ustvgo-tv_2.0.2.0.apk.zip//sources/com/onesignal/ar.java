package com.onesignal;

import android.content.Context;

public interface ar {

    public interface a {
        void a(String str, int i);
    }

    void a(Context context, String str, a aVar);
}
