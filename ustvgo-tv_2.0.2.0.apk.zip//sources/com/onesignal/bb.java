package com.onesignal;

import android.support.v4.app.NotificationCompat;

final class bb extends ba {
    bb(String str, boolean z) {
        super(NotificationCompat.CATEGORY_EMAIL.concat(String.valueOf(str)), z);
    }

    /* access modifiers changed from: package-private */
    public final ba a(String str) {
        return new bb(str, false);
    }

    /* access modifiers changed from: protected */
    public final void a() {
    }

    /* access modifiers changed from: package-private */
    public final boolean b() {
        return true;
    }
}
