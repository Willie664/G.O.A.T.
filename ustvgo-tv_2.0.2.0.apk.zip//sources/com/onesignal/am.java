package com.onesignal;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.ai;
import java.util.HashMap;

final class am {

    /* renamed from: a  reason: collision with root package name */
    public static final String f2741a = ai.class.getSimpleName();
    static HashMap<String, HashMap<String, Object>> b;
    public static a c = new a();

    public static class a extends HandlerThread {

        /* renamed from: a  reason: collision with root package name */
        public Handler f2742a;
        long b = 0;

        a() {
            super("OSH_WritePrefs");
            start();
            this.f2742a = new Handler(getLooper());
        }

        static /* synthetic */ void a(a aVar) {
            if (ai.b != null) {
                for (String next : am.b.keySet()) {
                    SharedPreferences.Editor edit = am.b(next).edit();
                    HashMap hashMap = am.b.get(next);
                    synchronized (hashMap) {
                        for (String str : hashMap.keySet()) {
                            Object obj = hashMap.get(str);
                            if (obj instanceof String) {
                                edit.putString(str, (String) obj);
                            } else if (obj instanceof Boolean) {
                                edit.putBoolean(str, ((Boolean) obj).booleanValue());
                            } else if (obj instanceof Integer) {
                                edit.putInt(str, ((Integer) obj).intValue());
                            } else if (obj instanceof Long) {
                                edit.putLong(str, ((Long) obj).longValue());
                            }
                        }
                        hashMap.clear();
                    }
                    edit.apply();
                }
                aVar.b = System.currentTimeMillis();
            }
        }
    }

    static {
        HashMap<String, HashMap<String, Object>> hashMap = new HashMap<>();
        b = hashMap;
        hashMap.put(f2741a, new HashMap());
        b.put("GTPlayerPurchases", new HashMap());
    }

    static int a(String str, String str2) {
        return ((Integer) a(str, str2, Integer.class, 1)).intValue();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0029, code lost:
        r3 = b(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002d, code lost:
        if (r3 == null) goto L_0x0096;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0035, code lost:
        if (r5.equals(java.lang.String.class) == false) goto L_0x003e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x003d, code lost:
        return r3.getString(r4, (java.lang.String) r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0044, code lost:
        if (r5.equals(java.lang.Boolean.class) == false) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0054, code lost:
        return java.lang.Boolean.valueOf(r3.getBoolean(r4, ((java.lang.Boolean) r6).booleanValue()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005b, code lost:
        if (r5.equals(java.lang.Integer.class) == false) goto L_0x006c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x006b, code lost:
        return java.lang.Integer.valueOf(r3.getInt(r4, ((java.lang.Integer) r6).intValue()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0072, code lost:
        if (r5.equals(java.lang.Long.class) == false) goto L_0x0083;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0082, code lost:
        return java.lang.Long.valueOf(r3.getLong(r4, ((java.lang.Long) r6).longValue()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0089, code lost:
        if (r5.equals(java.lang.Object.class) == false) goto L_0x0094;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0093, code lost:
        return java.lang.Boolean.valueOf(r3.contains(r4));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0094, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0096, code lost:
        return r6;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.Object a(java.lang.String r3, java.lang.String r4, java.lang.Class r5, java.lang.Object r6) {
        /*
            java.util.HashMap<java.lang.String, java.util.HashMap<java.lang.String, java.lang.Object>> r0 = b
            java.lang.Object r0 = r0.get(r3)
            java.util.HashMap r0 = (java.util.HashMap) r0
            monitor-enter(r0)
            java.lang.Class<java.lang.Object> r1 = java.lang.Object.class
            boolean r1 = r5.equals(r1)     // Catch:{ all -> 0x0099 }
            if (r1 == 0) goto L_0x001b
            boolean r1 = r0.containsKey(r4)     // Catch:{ all -> 0x0099 }
            if (r1 == 0) goto L_0x001b
            java.lang.Boolean r3 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x0099 }
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r3
        L_0x001b:
            java.lang.Object r1 = r0.get(r4)     // Catch:{ all -> 0x0099 }
            if (r1 != 0) goto L_0x0097
            boolean r2 = r0.containsKey(r4)     // Catch:{ all -> 0x0099 }
            if (r2 == 0) goto L_0x0028
            goto L_0x0097
        L_0x0028:
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            android.content.SharedPreferences r3 = b(r3)
            if (r3 == 0) goto L_0x0096
            java.lang.Class<java.lang.String> r0 = java.lang.String.class
            boolean r0 = r5.equals(r0)
            if (r0 == 0) goto L_0x003e
            java.lang.String r6 = (java.lang.String) r6
            java.lang.String r3 = r3.getString(r4, r6)
            return r3
        L_0x003e:
            java.lang.Class<java.lang.Boolean> r0 = java.lang.Boolean.class
            boolean r0 = r5.equals(r0)
            if (r0 == 0) goto L_0x0055
            java.lang.Boolean r6 = (java.lang.Boolean) r6
            boolean r5 = r6.booleanValue()
            boolean r3 = r3.getBoolean(r4, r5)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            return r3
        L_0x0055:
            java.lang.Class<java.lang.Integer> r0 = java.lang.Integer.class
            boolean r0 = r5.equals(r0)
            if (r0 == 0) goto L_0x006c
            java.lang.Integer r6 = (java.lang.Integer) r6
            int r5 = r6.intValue()
            int r3 = r3.getInt(r4, r5)
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            return r3
        L_0x006c:
            java.lang.Class<java.lang.Long> r0 = java.lang.Long.class
            boolean r0 = r5.equals(r0)
            if (r0 == 0) goto L_0x0083
            java.lang.Long r6 = (java.lang.Long) r6
            long r5 = r6.longValue()
            long r3 = r3.getLong(r4, r5)
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            return r3
        L_0x0083:
            java.lang.Class<java.lang.Object> r6 = java.lang.Object.class
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0094
            boolean r3 = r3.contains(r4)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            return r3
        L_0x0094:
            r3 = 0
            return r3
        L_0x0096:
            return r6
        L_0x0097:
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            return r1
        L_0x0099:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0099 }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.am.a(java.lang.String, java.lang.String, java.lang.Class, java.lang.Object):java.lang.Object");
    }

    public static void a() {
        a aVar = c;
        synchronized (aVar.f2742a) {
            aVar.f2742a.removeCallbacksAndMessages((Object) null);
            if (aVar.b == 0) {
                aVar.b = System.currentTimeMillis();
            }
            aVar.f2742a.postDelayed(new Runnable() {
                public final void run() {
                    a.a(a.this);
                }
            }, (aVar.b - System.currentTimeMillis()) + 200);
        }
    }

    public static void a(String str, String str2, long j) {
        a(str, str2, (Object) Long.valueOf(j));
    }

    private static void a(String str, String str2, Object obj) {
        HashMap hashMap = b.get(str);
        synchronized (hashMap) {
            hashMap.put(str2, obj);
        }
        a();
    }

    public static void a(String str, String str2, String str3) {
        a(str, str2, (Object) str3);
    }

    public static void a(String str, String str2, boolean z) {
        a(str, str2, (Object) Boolean.valueOf(z));
    }

    static long b(String str, String str2, long j) {
        return ((Long) a(str, str2, Long.class, Long.valueOf(j))).longValue();
    }

    /* access modifiers changed from: private */
    public static synchronized SharedPreferences b(String str) {
        synchronized (am.class) {
            if (ai.b == null) {
                ai.a(ai.h.WARN, "OneSignal.appContext null, could not read " + str + " from getSharedPreferences.", new Throwable());
                return null;
            }
            SharedPreferences sharedPreferences = ai.b.getSharedPreferences(str, 0);
            return sharedPreferences;
        }
    }

    static String b(String str, String str2, String str3) {
        return (String) a(str, str2, String.class, str3);
    }

    static boolean b(String str, String str2, boolean z) {
        return ((Boolean) a(str, str2, Boolean.class, Boolean.valueOf(z))).booleanValue();
    }
}
