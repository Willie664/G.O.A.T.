package com.onesignal;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import com.onesignal.NotificationExtenderService;

public class RestoreJobService extends JobIntentService {
    /* access modifiers changed from: protected */
    public final void a(Intent intent) {
        Bundle extras;
        if (intent != null && (extras = intent.getExtras()) != null) {
            q.a(getApplicationContext(), (g) new h(extras), (NotificationExtenderService.a) null);
        }
    }

    public final /* bridge */ /* synthetic */ boolean a() {
        return super.a();
    }

    public /* bridge */ /* synthetic */ IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    public /* bridge */ /* synthetic */ void onCreate() {
        super.onCreate();
    }

    public /* bridge */ /* synthetic */ void onDestroy() {
        super.onDestroy();
    }

    public /* bridge */ /* synthetic */ int onStartCommand(Intent intent, int i, int i2) {
        return super.onStartCommand(intent, i, i2);
    }
}
