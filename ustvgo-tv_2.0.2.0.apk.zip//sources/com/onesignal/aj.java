package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.customtabs.b;
import android.support.customtabs.d;
import android.support.customtabs.e;
import android.support.v7.widget.ActivityChooserView;
import java.security.SecureRandom;

final class aj {

    /* renamed from: a  reason: collision with root package name */
    private static boolean f2736a;

    static class a extends d {

        /* renamed from: a  reason: collision with root package name */
        private Context f2737a;
        private String b;

        a(Context context, String str) {
            this.f2737a = context;
            this.b = str;
        }

        public final void a(b bVar) {
            bVar.a();
            e a2 = bVar.a(new android.support.customtabs.a() {
                public final void a(int i, Bundle bundle) {
                    super.a(i, bundle);
                }

                public final void a(String str, Bundle bundle) {
                    super.a(str, bundle);
                }
            });
            if (a2 != null) {
                a2.a(Uri.parse("https://onesignal.com/android_frame.html" + this.b));
            }
        }

        public final void onServiceDisconnected(ComponentName componentName) {
        }
    }

    static void a(Context context, String str, String str2, String str3) {
        if (!f2736a && !ai.l.c && str2 != null) {
            try {
                Class.forName("android.support.customtabs.d");
                String str4 = "?app_id=" + str + "&user_id=" + str2;
                if (str3 != null) {
                    str4 = str4 + "&ad_id=" + str3;
                }
                f2736a = b.a(context, "com.android.chrome", new a(context, str4 + "&cbs_id=" + new SecureRandom().nextInt(ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED)));
            } catch (ClassNotFoundException unused) {
            }
        }
    }
}
