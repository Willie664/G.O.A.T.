package com.onesignal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import com.onesignal.a;

public class PermissionsActivity extends Activity {

    /* renamed from: a  reason: collision with root package name */
    static boolean f2708a;
    static boolean b;
    private static a.C0086a c;

    static void a() {
        if (!f2708a && !b) {
            AnonymousClass1 r0 = new a.C0086a() {
                public final void a(Activity activity) {
                    if (!activity.getClass().equals(PermissionsActivity.class)) {
                        Intent intent = new Intent(activity, PermissionsActivity.class);
                        intent.setFlags(131072);
                        activity.startActivity(intent);
                    }
                }
            };
            c = r0;
            a.a((a.C0086a) r0);
        }
    }

    private void b() {
        if (Build.VERSION.SDK_INT < 23) {
            finish();
        } else if (!f2708a) {
            f2708a = true;
            requestPermissions(new String[]{p.f2796a}, 2);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ai.a((Context) this);
        if (bundle == null || !bundle.getBoolean("android:hasCurrentPermissionsRequest", false)) {
            b();
        } else {
            f2708a = true;
        }
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (ai.c) {
            b();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        b = true;
        f2708a = false;
        if (i == 2) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                p.b();
            } else {
                p.a();
            }
        }
        a.a();
        finish();
    }
}
