package com.onesignal;

import com.facebook.ads.AdError;
import com.onesignal.ai;
import com.onesignal.ao;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class an {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static int f2744a;

    interface a {
        void a(b bVar);
    }

    static class b {
        String b;
        boolean c;
        boolean d;
        JSONObject e;
        JSONArray f;
        boolean g;
        boolean h;

        b() {
        }
    }

    static void a(final a aVar) {
        AnonymousClass1 r0 = new ao.a() {
            /* access modifiers changed from: package-private */
            public final void a(int i, String str, Throwable th) {
                if (i == 403) {
                    ai.a(ai.h.FATAL, "403 error getting OneSignal params, omitting further retries!");
                } else {
                    new Thread(new Runnable() {
                        public final void run() {
                            int a2 = (an.f2744a * 10000) + 30000;
                            if (a2 > 90000) {
                                a2 = 90000;
                            }
                            ai.h hVar = ai.h.INFO;
                            ai.a(hVar, "Failed to get Android parameters, trying again in " + (a2 / AdError.NETWORK_ERROR_CODE) + " seconds.");
                            ah.a(a2);
                            an.b();
                            an.a(aVar);
                        }
                    }, "OS_PARAMS_REQUEST").start();
                }
            }

            /* access modifiers changed from: package-private */
            public final void a(String str) {
                an.a(str, aVar);
            }
        };
        String str = "apps/" + ai.f2723a + "/android_params.js";
        String i = ai.i();
        if (i != null) {
            str = str + "?player_id=" + i;
        }
        ai.a(ai.h.DEBUG, "Starting request to get Android parameters.");
        new Thread(new Runnable(str, r0, "CACHE_KEY_REMOTE_PARAMS") {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ String f2750a;
            final /* synthetic */ a b;
            final /* synthetic */ String c;

            {
                this.f2750a = r1;
                this.b = r2;
                this.c = r3;
            }

            public final void run() {
                ao.a(this.f2750a, (String) null, (JSONObject) null, this.b, 60000, this.c);
            }
        }).start();
    }

    static /* synthetic */ void a(String str, a aVar) {
        try {
            final JSONObject jSONObject = new JSONObject(str);
            aVar.a(new b() {
                {
                    this.c = jSONObject.optBoolean("enterp", false);
                    this.d = jSONObject.optBoolean("use_email_auth", false);
                    this.e = jSONObject.optJSONObject("awl_list");
                    this.f = jSONObject.optJSONArray("chnl_lst");
                    this.g = jSONObject.optBoolean("fba", false);
                    this.h = jSONObject.optBoolean("restore_ttl_filter", true);
                    this.b = jSONObject.optString("android_sender_id", (String) null);
                }
            });
        } catch (NullPointerException | JSONException e) {
            ai.a(ai.h.FATAL, "Error parsing android_params!: ", e);
            ai.a(ai.h.FATAL, "Response that errored from android_params!: ".concat(String.valueOf(str)));
        }
    }

    static /* synthetic */ int b() {
        int i = f2744a;
        f2744a = i + 1;
        return i;
    }
}
