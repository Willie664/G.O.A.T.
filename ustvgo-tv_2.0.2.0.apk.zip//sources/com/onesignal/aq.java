package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import com.onesignal.ai;
import com.onesignal.e;
import com.onesignal.p;
import java.util.concurrent.atomic.AtomicBoolean;

final class aq {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static Long f2755a = 0L;
    private static AtomicBoolean b = new AtomicBoolean();
    private static Thread c;

    static class a extends c {

        /* renamed from: a  reason: collision with root package name */
        Service f2756a;

        a(Service service) {
            this.f2756a = service;
        }

        /* access modifiers changed from: protected */
        public final void a() {
            ai.a(ai.h.DEBUG, "LegacySyncRunnable:Stopped");
            this.f2756a.stopSelf();
        }
    }

    static class b extends c {

        /* renamed from: a  reason: collision with root package name */
        private JobService f2757a;
        private JobParameters b;

        b(JobService jobService, JobParameters jobParameters) {
            this.f2757a = jobService;
            this.b = jobParameters;
        }

        /* access modifiers changed from: protected */
        public final void a() {
            ai.a(ai.h.DEBUG, "LollipopSyncRunnable:JobFinished");
            this.f2757a.jobFinished(this.b, false);
        }
    }

    static abstract class c implements Runnable {
        c() {
        }

        /* access modifiers changed from: protected */
        public abstract void a();

        public final void run() {
            synchronized (aq.f2755a) {
                Long unused = aq.f2755a = 0L;
            }
            if (ai.i() == null) {
                a();
                return;
            }
            ai.f2723a = ai.h();
            ap.c();
            p.a(ai.b, false, new p.d() {
                public final p.a a() {
                    return p.a.SYNC_SERVICE;
                }

                public final void a(p.f fVar) {
                    if (fVar != null) {
                        ap.a(fVar);
                    }
                    ap.a().d(true);
                    ap.b().d(true);
                    aq.a();
                    c.this.a();
                }
            });
        }
    }

    static void a() {
        if (!b.get()) {
            synchronized (b) {
                b.set(true);
                long p = ai.p();
                if (p >= 60) {
                    ai.a(p);
                }
                b.set(false);
            }
        }
    }

    static void a(Context context) {
        ai.a(ai.h.VERBOSE, "scheduleSyncTask:SYNC_AFTER_BG_DELAY_MS: 120000");
        b(context, 120000);
    }

    static void a(Context context, long j) {
        ai.a(ai.h.VERBOSE, "scheduleLocationUpdateTask:delayMs: ".concat(String.valueOf(j)));
        b(context, j);
    }

    static void a(Context context, c cVar) {
        ai.a(context);
        Thread thread = new Thread(cVar, "OS_SYNCSRV_BG_SYNC");
        c = thread;
        thread.start();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0038, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void b(android.content.Context r3) {
        /*
            java.lang.Long r0 = f2755a
            monitor-enter(r0)
            r1 = 0
            java.lang.Long r1 = java.lang.Long.valueOf(r1)     // Catch:{ all -> 0x0039 }
            f2755a = r1     // Catch:{ all -> 0x0039 }
            boolean r1 = com.onesignal.p.a((android.content.Context) r3)     // Catch:{ all -> 0x0039 }
            if (r1 == 0) goto L_0x0013
            monitor-exit(r0)     // Catch:{ all -> 0x0039 }
            return
        L_0x0013:
            boolean r1 = d()     // Catch:{ all -> 0x0039 }
            if (r1 == 0) goto L_0x0028
            java.lang.String r1 = "jobscheduler"
            java.lang.Object r3 = r3.getSystemService(r1)     // Catch:{ all -> 0x0039 }
            android.app.job.JobScheduler r3 = (android.app.job.JobScheduler) r3     // Catch:{ all -> 0x0039 }
            r1 = 2071862118(0x7b7e1b66, float:1.3193991E36)
            r3.cancel(r1)     // Catch:{ all -> 0x0039 }
            goto L_0x0037
        L_0x0028:
            java.lang.String r1 = "alarm"
            java.lang.Object r1 = r3.getSystemService(r1)     // Catch:{ all -> 0x0039 }
            android.app.AlarmManager r1 = (android.app.AlarmManager) r1     // Catch:{ all -> 0x0039 }
            android.app.PendingIntent r3 = c(r3)     // Catch:{ all -> 0x0039 }
            r1.cancel(r3)     // Catch:{ all -> 0x0039 }
        L_0x0037:
            monitor-exit(r0)     // Catch:{ all -> 0x0039 }
            return
        L_0x0039:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0039 }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.aq.b(android.content.Context):void");
    }

    private static void b(Context context, long j) {
        synchronized (f2755a) {
            if (f2755a.longValue() == 0 || System.currentTimeMillis() + j <= f2755a.longValue()) {
                if (j < 5000) {
                    j = 5000;
                }
                if (d()) {
                    c(context, j);
                } else {
                    d(context, j);
                }
                f2755a = Long.valueOf(System.currentTimeMillis() + j);
            }
        }
    }

    static boolean b() {
        if (c == null || !c.isAlive()) {
            return false;
        }
        c.interrupt();
        return true;
    }

    private static PendingIntent c(Context context) {
        return PendingIntent.getService(context, 2071862118, new Intent(context, SyncService.class), 134217728);
    }

    private static void c(Context context, long j) {
        ai.a(ai.h.VERBOSE, "scheduleSyncServiceAsJob:atTime: ".concat(String.valueOf(j)));
        JobInfo.Builder builder = new JobInfo.Builder(2071862118, new ComponentName(context, SyncJobService.class));
        builder.setMinimumLatency(j).setRequiredNetworkType(1);
        if (d(context)) {
            builder.setPersisted(true);
        }
        try {
            ai.a(ai.h.INFO, "scheduleSyncServiceAsJob:result: ".concat(String.valueOf(((JobScheduler) context.getSystemService("jobscheduler")).schedule(builder.build()))));
        } catch (NullPointerException e) {
            ai.a(ai.h.ERROR, "scheduleSyncServiceAsJob called JobScheduler.jobScheduler which triggered an internal null Android error. Skipping job.", (Throwable) e);
        }
    }

    private static void d(Context context, long j) {
        ai.a(ai.h.VERBOSE, "scheduleServiceSyncTask:atTime: ".concat(String.valueOf(j)));
        ((AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM)).set(0, System.currentTimeMillis() + j + j, c(context));
    }

    private static boolean d() {
        return Build.VERSION.SDK_INT >= 21;
    }

    private static boolean d(Context context) {
        return e.a.a(context, "android.permission.RECEIVE_BOOT_COMPLETED") == 0;
    }
}
