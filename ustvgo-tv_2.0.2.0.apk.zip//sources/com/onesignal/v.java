package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import com.onesignal.ai;

final class v {

    /* renamed from: a  reason: collision with root package name */
    static final String[] f2812a = {"android_notification_id", "full_data", "created_time"};
    public static boolean b;

    private static Intent a(Intent intent, Cursor cursor) {
        int i = cursor.getInt(cursor.getColumnIndex("android_notification_id"));
        String string = cursor.getString(cursor.getColumnIndex("full_data"));
        intent.putExtra("json_payload", string).putExtra("android_notif_id", i).putExtra("restoring", true).putExtra("timestamp", Long.valueOf(cursor.getLong(cursor.getColumnIndex("created_time"))));
        return intent;
    }

    static void a(final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                Thread.currentThread().setPriority(10);
                v.b(context);
            }
        }, "OS_RESTORE_NOTIFS").start();
    }

    static void a(Context context, Cursor cursor, int i) {
        if (cursor.moveToFirst()) {
            boolean z = NotificationExtenderService.a(context) != null;
            do {
                if (z) {
                    Intent a2 = NotificationExtenderService.a(context);
                    a(a2, cursor);
                    NotificationExtenderService.a(context, a2.getComponent(), 2071862121, a2, false);
                } else {
                    RestoreJobService.a(context, new ComponentName(context, RestoreJobService.class), 2071862122, a(new Intent(), cursor), false);
                }
                if (i > 0) {
                    ah.a(i);
                }
            } while (cursor.moveToNext());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x004b A[SYNTHETIC, Splitter:B:25:0x004b] */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0058  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00d3  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x0101 A[SYNTHETIC, Splitter:B:68:0x0101] */
    /* JADX WARNING: Removed duplicated region for block: B:76:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:78:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void b(android.content.Context r14) {
        /*
            boolean r0 = com.onesignal.ah.e()
            if (r0 != 0) goto L_0x0007
            return
        L_0x0007:
            boolean r0 = b
            if (r0 == 0) goto L_0x000c
            return
        L_0x000c:
            r0 = 1
            b = r0
            com.onesignal.ai$h r0 = com.onesignal.ai.h.INFO
            java.lang.String r1 = "Restoring notifications"
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r1)
            com.onesignal.ak r0 = com.onesignal.ak.a(r14)
            r1 = 0
            android.database.sqlite.SQLiteDatabase r2 = r0.a()     // Catch:{ Throwable -> 0x0040, all -> 0x003c }
            r2.beginTransaction()     // Catch:{ Throwable -> 0x003a }
            com.onesignal.q.a((android.database.sqlite.SQLiteDatabase) r2)     // Catch:{ Throwable -> 0x003a }
            r2.setTransactionSuccessful()     // Catch:{ Throwable -> 0x003a }
            if (r2 == 0) goto L_0x004e
            r2.endTransaction()     // Catch:{ Throwable -> 0x002e }
            goto L_0x004e
        L_0x002e:
            r2 = move-exception
            com.onesignal.ai$h r3 = com.onesignal.ai.h.ERROR
            java.lang.String r4 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r3, (java.lang.String) r4, (java.lang.Throwable) r2)
            goto L_0x004e
        L_0x0037:
            r14 = move-exception
            goto L_0x00ff
        L_0x003a:
            r3 = move-exception
            goto L_0x0042
        L_0x003c:
            r14 = move-exception
            r2 = r1
            goto L_0x00ff
        L_0x0040:
            r3 = move-exception
            r2 = r1
        L_0x0042:
            com.onesignal.ai$h r4 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x0037 }
            java.lang.String r5 = "Error deleting old notification records! "
            com.onesignal.ai.a((com.onesignal.ai.h) r4, (java.lang.String) r5, (java.lang.Throwable) r3)     // Catch:{ all -> 0x0037 }
            if (r2 == 0) goto L_0x004e
            r2.endTransaction()     // Catch:{ Throwable -> 0x002e }
        L_0x004e:
            java.lang.StringBuilder r2 = com.onesignal.ak.c()
            int r3 = android.os.Build.VERSION.SDK_INT
            r4 = 23
            if (r3 < r4) goto L_0x0094
            java.lang.String r3 = "notification"
            java.lang.Object r3 = r14.getSystemService(r3)
            android.app.NotificationManager r3 = (android.app.NotificationManager) r3
            android.service.notification.StatusBarNotification[] r3 = r3.getActiveNotifications()     // Catch:{ Throwable -> 0x0094 }
            int r4 = r3.length     // Catch:{ Throwable -> 0x0094 }
            if (r4 != 0) goto L_0x0068
            goto L_0x0094
        L_0x0068:
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ Throwable -> 0x0094 }
            r4.<init>()     // Catch:{ Throwable -> 0x0094 }
            int r5 = r3.length     // Catch:{ Throwable -> 0x0094 }
            r6 = 0
        L_0x006f:
            if (r6 >= r5) goto L_0x0081
            r7 = r3[r6]     // Catch:{ Throwable -> 0x0094 }
            int r7 = r7.getId()     // Catch:{ Throwable -> 0x0094 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ Throwable -> 0x0094 }
            r4.add(r7)     // Catch:{ Throwable -> 0x0094 }
            int r6 = r6 + 1
            goto L_0x006f
        L_0x0081:
            java.lang.String r3 = " AND android_notification_id NOT IN ("
            r2.append(r3)     // Catch:{ Throwable -> 0x0094 }
            java.lang.String r3 = ","
            java.lang.String r3 = android.text.TextUtils.join(r3, r4)     // Catch:{ Throwable -> 0x0094 }
            r2.append(r3)     // Catch:{ Throwable -> 0x0094 }
            java.lang.String r3 = ")"
            r2.append(r3)     // Catch:{ Throwable -> 0x0094 }
        L_0x0094:
            com.onesignal.ai$h r3 = com.onesignal.ai.h.INFO
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "Querying DB for notifs to restore: "
            r4.<init>(r5)
            java.lang.String r5 = r2.toString()
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            com.onesignal.ai.a((com.onesignal.ai.h) r3, (java.lang.String) r4)
            android.database.sqlite.SQLiteDatabase r0 = r0.b()     // Catch:{ Throwable -> 0x00df }
            java.lang.String r6 = "notification"
            java.lang.String[] r7 = f2812a     // Catch:{ Throwable -> 0x00df }
            java.lang.String r8 = r2.toString()     // Catch:{ Throwable -> 0x00df }
            r9 = 0
            r10 = 0
            r11 = 0
            java.lang.String r12 = "_id DESC"
            java.lang.String r13 = com.onesignal.t.f2811a     // Catch:{ Throwable -> 0x00df }
            r5 = r0
            android.database.Cursor r2 = r5.query(r6, r7, r8, r9, r10, r11, r12, r13)     // Catch:{ Throwable -> 0x00df }
            r1 = 200(0xc8, float:2.8E-43)
            a(r14, r2, r1)     // Catch:{ Throwable -> 0x00da, all -> 0x00d7 }
            com.onesignal.f.a((android.database.sqlite.SQLiteDatabase) r0, (android.content.Context) r14)     // Catch:{ Throwable -> 0x00da, all -> 0x00d7 }
            if (r2 == 0) goto L_0x00f2
            boolean r14 = r2.isClosed()
            if (r14 != 0) goto L_0x00f2
            r2.close()
            return
        L_0x00d7:
            r14 = move-exception
            r1 = r2
            goto L_0x00f3
        L_0x00da:
            r14 = move-exception
            r1 = r2
            goto L_0x00e0
        L_0x00dd:
            r14 = move-exception
            goto L_0x00f3
        L_0x00df:
            r14 = move-exception
        L_0x00e0:
            com.onesignal.ai$h r0 = com.onesignal.ai.h.ERROR     // Catch:{ all -> 0x00dd }
            java.lang.String r2 = "Error restoring notification records! "
            com.onesignal.ai.a((com.onesignal.ai.h) r0, (java.lang.String) r2, (java.lang.Throwable) r14)     // Catch:{ all -> 0x00dd }
            if (r1 == 0) goto L_0x00f2
            boolean r14 = r1.isClosed()
            if (r14 != 0) goto L_0x00f2
            r1.close()
        L_0x00f2:
            return
        L_0x00f3:
            if (r1 == 0) goto L_0x00fe
            boolean r0 = r1.isClosed()
            if (r0 != 0) goto L_0x00fe
            r1.close()
        L_0x00fe:
            throw r14
        L_0x00ff:
            if (r2 == 0) goto L_0x010d
            r2.endTransaction()     // Catch:{ Throwable -> 0x0105 }
            goto L_0x010d
        L_0x0105:
            r0 = move-exception
            com.onesignal.ai$h r1 = com.onesignal.ai.h.ERROR
            java.lang.String r2 = "Error closing transaction! "
            com.onesignal.ai.a((com.onesignal.ai.h) r1, (java.lang.String) r2, (java.lang.Throwable) r0)
        L_0x010d:
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.v.b(android.content.Context):void");
    }

    static void c(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            ai.a(ai.h.INFO, "scheduleRestoreKickoffJob");
            ((JobScheduler) context.getSystemService("jobscheduler")).schedule(new JobInfo.Builder(2071862120, new ComponentName(context, RestoreKickoffJobService.class)).setOverrideDeadline(15000).setMinimumLatency(15000).build());
            return;
        }
        ai.a(ai.h.INFO, "scheduleRestoreKickoffAlarmTask");
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context.getPackageName(), NotificationRestoreService.class.getName()));
        PendingIntent service = PendingIntent.getService(context, 2071862120, intent, 268435456);
        ((AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM)).set(1, System.currentTimeMillis() + 15000, service);
    }
}
