package com.onesignal;

public final class ab {

    /* renamed from: a  reason: collision with root package name */
    public z f2714a;
    public aa b;
}
