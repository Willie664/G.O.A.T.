package com.onesignal;

import android.annotation.TargetApi;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.content.WakefulBroadcastReceiver;
import java.security.SecureRandom;

public class GcmBroadcastReceiver extends WakefulBroadcastReceiver {
    private static g a(Bundle bundle, g gVar) {
        gVar.a("json_payload", q.a(bundle).toString());
        gVar.a("timestamp", Long.valueOf(System.currentTimeMillis() / 1000));
        return gVar;
    }

    private void a() {
        if (isOrderedBroadcast()) {
            setResultCode(-1);
        }
    }

    @TargetApi(21)
    private static void a(Context context, Bundle bundle) {
        g a2 = a(bundle, i.a());
        ((JobScheduler) context.getSystemService("jobscheduler")).schedule(new JobInfo.Builder(new SecureRandom().nextInt(), new ComponentName(context.getPackageName(), GcmIntentJobService.class.getName())).setOverrideDeadline(0).setExtras((PersistableBundle) a2.a()).build());
    }

    private void b() {
        if (isOrderedBroadcast()) {
            abortBroadcast();
            setResultCode(-1);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0027, code lost:
        r7 = r7.getStringExtra("message_type");
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onReceive(android.content.Context r6, android.content.Intent r7) {
        /*
            r5 = this;
            android.os.Bundle r0 = r7.getExtras()
            if (r0 == 0) goto L_0x00f1
            java.lang.String r1 = "google.com/iid"
            java.lang.String r2 = "from"
            java.lang.String r2 = r0.getString(r2)
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x0016
            goto L_0x00f1
        L_0x0016:
            com.onesignal.ai.a((android.content.Context) r6)
            java.lang.String r1 = "com.google.android.c2dm.intent.RECEIVE"
            java.lang.String r2 = r7.getAction()
            boolean r1 = r1.equals(r2)
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L_0x0039
            java.lang.String r1 = "message_type"
            java.lang.String r7 = r7.getStringExtra(r1)
            if (r7 == 0) goto L_0x0037
            java.lang.String r1 = "gcm"
            boolean r7 = r1.equals(r7)
            if (r7 == 0) goto L_0x0039
        L_0x0037:
            r7 = 1
            goto L_0x003a
        L_0x0039:
            r7 = 0
        L_0x003a:
            r1 = 0
            if (r7 != 0) goto L_0x0040
            r7 = r1
            goto L_0x00cb
        L_0x0040:
            com.onesignal.q$a r7 = com.onesignal.q.a((android.content.Context) r6, (android.os.Bundle) r0)
            boolean r4 = r7.a()
            if (r4 == 0) goto L_0x004c
            goto L_0x00cb
        L_0x004c:
            java.lang.String r4 = "licon"
            boolean r4 = com.onesignal.q.a((android.os.Bundle) r0, (java.lang.String) r4)
            if (r4 != 0) goto L_0x0067
            java.lang.String r4 = "bicon"
            boolean r4 = com.onesignal.q.a((android.os.Bundle) r0, (java.lang.String) r4)
            if (r4 != 0) goto L_0x0067
            java.lang.String r4 = "bg_img"
            java.lang.String r4 = r0.getString(r4, r1)
            if (r4 == 0) goto L_0x0065
            goto L_0x0067
        L_0x0065:
            r4 = 0
            goto L_0x0068
        L_0x0067:
            r4 = 1
        L_0x0068:
            if (r4 != 0) goto L_0x0076
            com.onesignal.g r2 = com.onesignal.i.a()
            com.onesignal.g r0 = a((android.os.Bundle) r0, (com.onesignal.g) r2)
            com.onesignal.q.a((android.content.Context) r6, (com.onesignal.g) r0, (com.onesignal.NotificationExtenderService.a) r1)
            goto L_0x00cb
        L_0x0076:
            java.lang.String r1 = "pri"
            java.lang.String r4 = "0"
            java.lang.String r1 = r0.getString(r1, r4)
            int r1 = java.lang.Integer.parseInt(r1)
            r4 = 9
            if (r1 <= r4) goto L_0x0087
            goto L_0x0088
        L_0x0087:
            r2 = 0
        L_0x0088:
            if (r2 != 0) goto L_0x0094
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 26
            if (r1 < r2) goto L_0x0094
        L_0x0090:
            a((android.content.Context) r6, (android.os.Bundle) r0)
            goto L_0x00cb
        L_0x0094:
            android.content.ComponentName r1 = new android.content.ComponentName     // Catch:{ IllegalStateException -> 0x00c3 }
            java.lang.String r2 = r6.getPackageName()     // Catch:{ IllegalStateException -> 0x00c3 }
            java.lang.Class<com.onesignal.GcmIntentService> r3 = com.onesignal.GcmIntentService.class
            java.lang.String r3 = r3.getName()     // Catch:{ IllegalStateException -> 0x00c3 }
            r1.<init>(r2, r3)     // Catch:{ IllegalStateException -> 0x00c3 }
            com.onesignal.h r2 = new com.onesignal.h     // Catch:{ IllegalStateException -> 0x00c3 }
            r2.<init>()     // Catch:{ IllegalStateException -> 0x00c3 }
            com.onesignal.g r2 = a((android.os.Bundle) r0, (com.onesignal.g) r2)     // Catch:{ IllegalStateException -> 0x00c3 }
            android.content.Intent r3 = new android.content.Intent     // Catch:{ IllegalStateException -> 0x00c3 }
            r3.<init>()     // Catch:{ IllegalStateException -> 0x00c3 }
            java.lang.Object r2 = r2.a()     // Catch:{ IllegalStateException -> 0x00c3 }
            android.os.Bundle r2 = (android.os.Bundle) r2     // Catch:{ IllegalStateException -> 0x00c3 }
            android.content.Intent r2 = r3.replaceExtras(r2)     // Catch:{ IllegalStateException -> 0x00c3 }
            android.content.Intent r1 = r2.setComponent(r1)     // Catch:{ IllegalStateException -> 0x00c3 }
            a_(r6, r1)     // Catch:{ IllegalStateException -> 0x00c3 }
            goto L_0x00cb
        L_0x00c3:
            r1 = move-exception
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 21
            if (r2 < r3) goto L_0x00f0
            goto L_0x0090
        L_0x00cb:
            if (r7 != 0) goto L_0x00d1
            r5.a()
            return
        L_0x00d1:
            boolean r6 = r7.c
            if (r6 != 0) goto L_0x00ec
            boolean r6 = r7.b
            if (r6 == 0) goto L_0x00da
            goto L_0x00ec
        L_0x00da:
            boolean r6 = r7.f2802a
            if (r6 == 0) goto L_0x00e8
            boolean r6 = com.onesignal.ai.k()
            if (r6 == 0) goto L_0x00e8
            r5.b()
            return
        L_0x00e8:
            r5.a()
            return
        L_0x00ec:
            r5.b()
            return
        L_0x00f0:
            throw r1
        L_0x00f1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.GcmBroadcastReceiver.onReceive(android.content.Context, android.content.Intent):void");
    }
}
