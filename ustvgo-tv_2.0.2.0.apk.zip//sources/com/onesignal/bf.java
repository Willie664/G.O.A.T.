package com.onesignal;

import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.NotificationCompat;
import com.onesignal.ai;
import com.onesignal.ao;
import com.onesignal.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

abstract class bf {

    /* renamed from: a  reason: collision with root package name */
    private ArrayList<ai.b> f2774a = new ArrayList<>();
    boolean b;
    protected final Object c = new Object() {
    };
    AtomicBoolean d = new AtomicBoolean();
    HashMap<Integer, b> e = new HashMap<>();
    protected boolean f = false;
    protected ba g;
    protected ba h;
    private final Object i = new Object() {
    };

    static class a {

        /* renamed from: a  reason: collision with root package name */
        boolean f2780a;
        JSONObject b;

        a(boolean z, JSONObject jSONObject) {
            this.f2780a = z;
            this.b = jSONObject;
        }
    }

    class b extends HandlerThread {

        /* renamed from: a  reason: collision with root package name */
        int f2781a;
        Handler b = null;
        int c;

        b(int i) {
            super("OSH_NetworkHandlerThread");
            this.f2781a = i;
            start();
            this.b = new Handler(getLooper());
        }

        private Runnable c() {
            if (this.f2781a != 0) {
                return null;
            }
            return new Runnable() {
                public final void run() {
                    if (!bf.this.d.get()) {
                        bf.this.d(false);
                    }
                }
            };
        }

        /* access modifiers changed from: package-private */
        public final void a() {
            if (bf.this.b) {
                synchronized (this.b) {
                    this.c = 0;
                    this.b.removeCallbacksAndMessages((Object) null);
                    this.b.postDelayed(c(), 5000);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public final boolean b() {
            boolean hasMessages;
            synchronized (this.b) {
                boolean z = this.c < 3;
                boolean hasMessages2 = this.b.hasMessages(0);
                if (z && !hasMessages2) {
                    this.c++;
                    this.b.postDelayed(c(), (long) (this.c * 15000));
                }
                hasMessages = this.b.hasMessages(0);
            }
            return hasMessages;
        }
    }

    bf() {
    }

    static /* synthetic */ void a(bf bfVar) {
        bfVar.f().f2771a.remove("logoutEmail");
        bfVar.h.f2771a.remove("email_auth_hash");
        bfVar.h.b.remove("parent_player_id");
        bfVar.h.c();
        bfVar.g.f2771a.remove("email_auth_hash");
        bfVar.g.b.remove("parent_player_id");
        String optString = bfVar.g.b.optString(NotificationCompat.CATEGORY_EMAIL);
        bfVar.g.b.remove(NotificationCompat.CATEGORY_EMAIL);
        ap.b().j();
        ai.a(ai.h.INFO, "Device successfully logged out of email: ".concat(String.valueOf(optString)));
        ai.s();
    }

    static /* synthetic */ void a(bf bfVar, int i2) {
        if (i2 == 403) {
            ai.a(ai.h.FATAL, "403 error updating player, omitting further retries!");
            bfVar.o();
        } else if (!bfVar.a((Integer) 0).b()) {
            bfVar.o();
        }
    }

    private void a(String str, final JSONObject jSONObject, final JSONObject jSONObject2) {
        if (str == null) {
            Iterator<ai.b> it = this.f2774a.iterator();
            while (it.hasNext()) {
                if (it.next() != null) {
                    new ai.m(-1, "Unable to update tags: the current user is not registered with OneSignal");
                }
            }
            this.f2774a.clear();
            return;
        }
        final ArrayList arrayList = (ArrayList) this.f2774a.clone();
        this.f2774a.clear();
        ao.b("players/".concat(String.valueOf(str)), jSONObject, new ao.a() {
            /* access modifiers changed from: package-private */
            public final void a(int i, String str, Throwable th) {
                ai.h hVar = ai.h.WARN;
                ai.a(hVar, "Failed last request. statusCode: " + i + "\nresponse: " + str);
                synchronized (bf.this.c) {
                    if (bf.a(i, str, "No user with this id found")) {
                        bf.b(bf.this);
                    } else {
                        bf.a(bf.this, i);
                    }
                }
                if (jSONObject.has("tags")) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        if (((ai.b) it.next()) != null) {
                            new ai.m(i, str);
                        }
                    }
                }
            }

            /* access modifiers changed from: package-private */
            public final void a(String str) {
                synchronized (bf.this.c) {
                    bf.this.g.a(jSONObject2, jSONObject);
                    bf.this.d(jSONObject);
                }
                JSONObject jSONObject = ap.a().a(false).b;
                if (jSONObject.has("tags") && jSONObject != null) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        it.next();
                    }
                }
            }
        });
    }

    static boolean a(int i2, String str, String str2) {
        if (i2 == 400 && str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                return jSONObject.has("errors") && jSONObject.optString("errors").contains(str2);
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
        return false;
    }

    static /* synthetic */ void b(bf bfVar) {
        ai.s();
        bfVar.l();
        bfVar.c();
    }

    private void b(final String str, final JSONObject jSONObject, final JSONObject jSONObject2) {
        String str2;
        if (str == null) {
            str2 = "players";
        } else {
            str2 = "players/" + str + "/on_session";
        }
        this.f = true;
        b(jSONObject);
        ao.c(str2, jSONObject, new ao.a() {
            /* access modifiers changed from: package-private */
            public final void a(int i, String str, Throwable th) {
                synchronized (bf.this.c) {
                    bf.this.f = false;
                    ai.h hVar = ai.h.WARN;
                    ai.a(hVar, "Failed last request. statusCode: " + i + "\nresponse: " + str);
                    if (bf.a(i, str, "not a valid device_type")) {
                        bf.b(bf.this);
                    } else {
                        bf.a(bf.this, i);
                    }
                }
            }

            /* access modifiers changed from: package-private */
            public final void a(String str) {
                synchronized (bf.this.c) {
                    bf.this.f = false;
                    bf.this.g.a(jSONObject2, jSONObject);
                    try {
                        JSONObject jSONObject = new JSONObject(str);
                        if (jSONObject.has("id")) {
                            String optString = jSONObject.optString("id");
                            bf.this.b(optString);
                            ai.a(ai.h.INFO, "Device registered, UserId = ".concat(String.valueOf(optString)));
                        } else {
                            ai.h hVar = ai.h.INFO;
                            ai.a(hVar, "session sent, UserId = " + str);
                        }
                        bf.this.i().f2771a.put("session", false);
                        bf.this.i().c();
                        bf.this.d(jSONObject);
                    } catch (Throwable th) {
                        ai.a(ai.h.ERROR, "ERROR parsing on_session or create JSON Response.", th);
                    }
                }
            }
        });
    }

    private boolean b() {
        return (f().f2771a.optBoolean("session") || d() == null) && !this.f;
    }

    private void c(String str) {
        String str2 = "players/" + str + "/email_logout";
        JSONObject jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = this.g.f2771a;
            if (jSONObject2.has("email_auth_hash")) {
                jSONObject.put("email_auth_hash", jSONObject2.optString("email_auth_hash"));
            }
            JSONObject jSONObject3 = this.g.b;
            if (jSONObject3.has("parent_player_id")) {
                jSONObject.put("parent_player_id", jSONObject3.optString("parent_player_id"));
            }
            jSONObject.put("app_id", jSONObject3.optString("app_id"));
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        ao.c(str2, jSONObject, new ao.a() {
            /* access modifiers changed from: package-private */
            public final void a(int i, String str, Throwable th) {
                ai.h hVar = ai.h.WARN;
                ai.a(hVar, "Failed last request. statusCode: " + i + "\nresponse: " + str);
                if (bf.a(i, str, "already logged out of email")) {
                    bf.a(bf.this);
                } else if (bf.a(i, str, "not a valid device_type")) {
                    bf.b(bf.this);
                } else {
                    bf.a(bf.this, i);
                }
            }

            /* access modifiers changed from: package-private */
            public final void a(String str) {
                bf.a(bf.this);
            }
        });
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0071, code lost:
        if (r8 != false) goto L_0x0077;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0073, code lost:
        a(r0, r3, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0076, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0077, code lost:
        b(r0, r3, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x007a, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void c(boolean r8) {
        /*
            r7 = this;
            java.lang.String r0 = r7.d()
            boolean r1 = r7.n()
            if (r1 == 0) goto L_0x0010
            if (r0 == 0) goto L_0x0010
            r7.c((java.lang.String) r0)
            return
        L_0x0010:
            com.onesignal.ba r1 = r7.g
            if (r1 != 0) goto L_0x0017
            r7.g()
        L_0x0017:
            r1 = 0
            if (r8 != 0) goto L_0x0022
            boolean r8 = r7.b()
            if (r8 == 0) goto L_0x0022
            r8 = 1
            goto L_0x0023
        L_0x0022:
            r8 = 0
        L_0x0023:
            java.lang.Object r2 = r7.c
            monitor-enter(r2)
            com.onesignal.ba r3 = r7.g     // Catch:{ all -> 0x007b }
            com.onesignal.ba r4 = r7.f()     // Catch:{ all -> 0x007b }
            org.json.JSONObject r3 = r3.a((com.onesignal.ba) r4, (boolean) r8)     // Catch:{ all -> 0x007b }
            com.onesignal.ba r4 = r7.g     // Catch:{ all -> 0x007b }
            org.json.JSONObject r4 = r4.f2771a     // Catch:{ all -> 0x007b }
            com.onesignal.ba r5 = r7.f()     // Catch:{ all -> 0x007b }
            org.json.JSONObject r5 = r5.f2771a     // Catch:{ all -> 0x007b }
            r6 = 0
            org.json.JSONObject r4 = r7.a((org.json.JSONObject) r4, (org.json.JSONObject) r5, (org.json.JSONObject) r6)     // Catch:{ all -> 0x007b }
            if (r3 != 0) goto L_0x0069
            com.onesignal.ba r8 = r7.g     // Catch:{ all -> 0x007b }
            r8.a((org.json.JSONObject) r4, (org.json.JSONObject) r6)     // Catch:{ all -> 0x007b }
            java.util.ArrayList<com.onesignal.ai$b> r8 = r7.f2774a     // Catch:{ all -> 0x007b }
            java.util.Iterator r8 = r8.iterator()     // Catch:{ all -> 0x007b }
        L_0x004c:
            boolean r0 = r8.hasNext()     // Catch:{ all -> 0x007b }
            if (r0 == 0) goto L_0x0062
            java.lang.Object r0 = r8.next()     // Catch:{ all -> 0x007b }
            com.onesignal.ai$b r0 = (com.onesignal.ai.b) r0     // Catch:{ all -> 0x007b }
            if (r0 == 0) goto L_0x004c
            com.onesignal.be r0 = com.onesignal.ap.a()     // Catch:{ all -> 0x007b }
            r0.a((boolean) r1)     // Catch:{ all -> 0x007b }
            goto L_0x004c
        L_0x0062:
            java.util.ArrayList<com.onesignal.ai$b> r8 = r7.f2774a     // Catch:{ all -> 0x007b }
            r8.clear()     // Catch:{ all -> 0x007b }
            monitor-exit(r2)     // Catch:{ all -> 0x007b }
            return
        L_0x0069:
            com.onesignal.ba r1 = r7.f()     // Catch:{ all -> 0x007b }
            r1.c()     // Catch:{ all -> 0x007b }
            monitor-exit(r2)     // Catch:{ all -> 0x007b }
            if (r8 != 0) goto L_0x0077
            r7.a((java.lang.String) r0, (org.json.JSONObject) r3, (org.json.JSONObject) r4)
            return
        L_0x0077:
            r7.b(r0, r3, r4)
            return
        L_0x007b:
            r8 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x007b }
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.bf.c(boolean):void");
    }

    private boolean n() {
        return f().f2771a.optBoolean("logoutEmail", false);
    }

    private void o() {
        JSONObject a2 = this.g.a(this.h, false);
        if (a2 != null) {
            c(a2);
        }
        if (f().f2771a.optBoolean("logoutEmail", false)) {
            ai.t();
        }
    }

    /* access modifiers changed from: protected */
    public abstract ba a(String str);

    /* access modifiers changed from: package-private */
    public abstract a a(boolean z);

    /* access modifiers changed from: protected */
    public final b a(Integer num) {
        b bVar;
        synchronized (this.i) {
            if (!this.e.containsKey(num)) {
                this.e.put(num, new b(num.intValue()));
            }
            bVar = this.e.get(num);
        }
        return bVar;
    }

    /* access modifiers changed from: protected */
    public final JSONObject a(JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3) {
        JSONObject a2;
        synchronized (this.c) {
            a2 = o.a(jSONObject, jSONObject2, jSONObject3, (Set<String>) null);
        }
        return a2;
    }

    /* access modifiers changed from: package-private */
    public final void a(p.f fVar) {
        ba i2 = i();
        try {
            i2.b.put("lat", fVar.f2799a);
            i2.b.put("long", fVar.b);
            i2.b.put("loc_acc", fVar.c);
            i2.b.put("loc_type", fVar.d);
            i2.f2771a.put("loc_bg", fVar.e);
            i2.f2771a.put("loc_time_stamp", fVar.f);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public abstract void a(JSONObject jSONObject);

    /* access modifiers changed from: package-private */
    public abstract boolean a();

    /* access modifiers changed from: package-private */
    public abstract void b(String str);

    /* access modifiers changed from: protected */
    public abstract void b(JSONObject jSONObject);

    /* access modifiers changed from: package-private */
    public abstract void b(boolean z);

    /* access modifiers changed from: protected */
    public abstract void c();

    /* access modifiers changed from: protected */
    public abstract void c(JSONObject jSONObject);

    /* access modifiers changed from: protected */
    public abstract String d();

    /* access modifiers changed from: protected */
    public abstract void d(JSONObject jSONObject);

    /* access modifiers changed from: package-private */
    public final void d(boolean z) {
        this.d.set(true);
        c(z);
        this.d.set(false);
    }

    /* access modifiers changed from: package-private */
    public final String e() {
        return f().b.optString("identifier", (String) null);
    }

    /* access modifiers changed from: package-private */
    public final void e(JSONObject jSONObject) {
        JSONObject jSONObject2 = i().b;
        a(jSONObject2, jSONObject, jSONObject2);
    }

    /* access modifiers changed from: protected */
    public final ba f() {
        synchronized (this.c) {
            if (this.h == null) {
                this.h = a("TOSYNC_STATE");
            }
        }
        return this.h;
    }

    /* access modifiers changed from: package-private */
    public final void g() {
        synchronized (this.c) {
            if (this.g == null) {
                this.g = a("CURRENT_STATE");
            }
        }
        f();
    }

    /* access modifiers changed from: package-private */
    public final boolean h() {
        boolean z = false;
        if (this.h == null) {
            return false;
        }
        synchronized (this.c) {
            if (this.g.a(this.h, b()) != null) {
                z = true;
            }
            this.h.c();
        }
        return z;
    }

    /* access modifiers changed from: protected */
    public final ba i() {
        if (this.h == null) {
            this.h = this.g.b("TOSYNC_STATE");
        }
        c();
        return this.h;
    }

    /* access modifiers changed from: package-private */
    public final void j() {
        try {
            synchronized (this.c) {
                i().f2771a.put("session", true);
                i().c();
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public final boolean k() {
        return i().f2771a.optBoolean("session");
    }

    /* access modifiers changed from: package-private */
    public final void l() {
        this.g.b = new JSONObject();
        this.g.c();
    }

    /* access modifiers changed from: package-private */
    public final void m() {
        boolean z = !this.b;
        this.b = true;
        if (z) {
            c();
        }
    }
}
