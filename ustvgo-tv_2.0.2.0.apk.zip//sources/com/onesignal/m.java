package com.onesignal;

import com.google.android.gms.common.api.GoogleApiClient;

final class m {

    /* renamed from: a  reason: collision with root package name */
    final GoogleApiClient f2793a;
    private final Class b;

    m(GoogleApiClient googleApiClient) {
        this.f2793a = googleApiClient;
        this.b = googleApiClient.getClass();
    }

    /* access modifiers changed from: package-private */
    public final void a() {
        try {
            this.b.getMethod("connect", new Class[0]).invoke(this.f2793a, new Object[0]);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public final void b() {
        try {
            this.b.getMethod("disconnect", new Class[0]).invoke(this.f2793a, new Object[0]);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }
}
