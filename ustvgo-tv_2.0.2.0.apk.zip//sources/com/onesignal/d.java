package com.onesignal;

import android.content.Context;

interface d {
    String a(Context context);
}
