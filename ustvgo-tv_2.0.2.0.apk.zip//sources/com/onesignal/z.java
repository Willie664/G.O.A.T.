package com.onesignal;

import java.util.List;

public final class z {

    /* renamed from: a  reason: collision with root package name */
    public boolean f2815a;
    public boolean b;
    public int c;
    public ac d;
    public int e;
    public List<ac> f;

    public enum a {
        ;
        

        /* renamed from: a  reason: collision with root package name */
        public static final int f2816a = 1;
        public static final int b = 2;
        public static final int c = 3;

        static {
            d = new int[]{f2816a, b, c};
        }
    }
}
